/*
 * @(#)CliBundle_it.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;
import lbj.Cli.*;

/**
 * The <code>CliBundle_it</code> class provides the Italian locale for
 * the <code>Cli</code> class.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */


public class CliBundle_it extends ListResourceBundle {
    public Object[][] getContents() {
        return contents;
    }

    // LOCALIZE THIS

    public static final Qualifier ENCOD =
        new Qualifier('e',"enc",null,"codice",Cli.AR_VALREQ | Cli.AR_ENC,
            String.class,"codice");

    private static final Qualifier IND_FILE =      // default indirect argument
        new Qualifier(' ',"@",null,"file",Cli.AR_IND |
            Cli.AR_VALREQ,String.class,"file indiretto",
            new Qualifier[] {ENCOD}
        );
    private static final Qualifier[] DEF_IND = {   // default restricted arguments
        IND_FILE,
    };

    private static final Qualifier[] DEF_ARGS = {  // default arguments
        IND_FILE,
        new Qualifier(' ',"stampa-arg",   null,"",0,void.class,"stampa argomenti"),
        new Qualifier(' ',"aiuto",        null,"",0,void.class,"stampa aiuto"),
        new Qualifier(' ',"uso",          null,"",0,void.class,"uso"),
        new Qualifier(' ',"uso-breve",    null,"",0,void.class,"uso breve"),
        new Qualifier(' ',"uso-verboso",  null,"",0,void.class,"uso verboso"),
        new Qualifier(' ',"uso-completo", null,"",0,void.class,"uso completo"),
        new Qualifier(' ',"versione",     null,"",0,void.class,"versione"),
    };

    private static final String[] MSGTAB = {
        "SUCCESS, operazione eseguita",       //  0
        "MISNAME, nome mancante",             //  1
        "SECURITY, operazione non autorizzata",//  2
        "UNKARG, argomento sconosciuto",      //  3
        "MISVAL, valore mancante",            //  4
        "SEQUENCE, fuori sequenza",           //  5
        "ILLNAME, nome illegale",             //  6
        "STRNOCL, stringa non chiusa",        //  7
        "NOCLO, lista non chiusa",            //  8
        "NOCORE, memoria insufficiente",      //  9
        "UNEXP,  carattere inatteso",         // 10
        "MISPAR, parametro mancante",         // 11
        "MISQUAL, qualificatore mancante",    // 12
        "ILLTYPE, tipo illegale",             // 13
        "AMBNAME, nome ambiguo",              // 14
        "IOERR, errore di io",                // 15
        "INIT, non inizalizzato",             // 16
        "ILLIND, argomento indiretto illegale", // 17
        "NOCBK, callback assente",            // 18
        "REPQUAL, qualificatore ripetuto",    // 19
        "NOLIST, lista non permessa",         // 20
        "ILLQUAL, qualificatore illegale",    // 21
        "ILLATTR, attributo illegale",        // 22
        "NOCMD, nome di comando mancante",    // 23
        "NULLCMD, comando vuoto",             // 24
        "NEST, annidamento infinito di file indiretti",  // 25
        "UNKCMD, comando sconosciuto",        // 26
        "ILLVAL, valore illegale",            // 27
        "ILLPAR, parametro illegale",         // 28
        "RANGE, fuori limiti",                // 29
        "ILLNUM, numero illegale",            // 30
        "OUTLIMIT, limiti eceeduti",          // 31
        "ILLFILE, file illegale",             // 32
        "INVDEF, definizione di comando non valida", // 33
        "NORES, risorsa mancante",            // 34
        "INDFILE, errore in file indiretto",  // 35
        "NOINIT, inizalizzazone fallita",     // 36
    };

    private static final Object[][] contents = {
        {"DEFARGS", DEF_ARGS},
        {"DEFIND",  DEF_IND},
        {"MSGTAB",  MSGTAB},

        // LOCALIZE THIS

        {"USAGE", "Uso:"},
        {"BRIEFREM", "Usare %s;%s per maggiore assistenza."},
        {"USGALL", "%t>;Usare %2s %sm;."},
        {"QU_DISPLAY", "per vedere gli argomenti"},
        {"QU_USAGE", "per normali informazioni d'uso"},
        {"QU_BRIEF", "per succinte informazioni d'uso"},
        {"QU_VERBOSE", "per complete informazioni d'uso"},
        {"QU_ALL", "per tutte le informazioni d'uso"},
        {"QU_HELP", "per aiuto"},
        {"QU_VERSION", "per vedere la versione"},
        {"EMPTY", ""},
        {"YESNO", "s\u00EC|no"},
        {"VALUES", new String[] {"no","s\u00EC","falso","vero","O","I"}},
        {"BOH","??"},
        {"ASSIST", "%%%s-W-USE, usare %s;%s per maggiore assistenza"},
        {"SORRYH", "spiacente, aiuto non disponibile"},
        {"SORRYV", "spiacente, versione non disponibile"},
        {"ONFILE", "sul file"},
        {"OR", "o"},
        {"ARGUMENT", "argomento"},
        {"INT8",  "intero 8-bit con segno"},
        {"INT16", "intero 16-bit con segno"},
        {"INT32", "intero 32-bit con segno"},
        {"INT64", "intero 64-bit con segno"},
        {"UNINT8",  "intero 8-bit senza segno"},
        {"UNINT16", "intero 16-bit senza segno"},
        {"UNINT32", "intero 32-bit senza segno"},
        {"UNINT64", "intero 64-bit senza segno"},
        {"BOOL",  "booleano"},
        {"CHAR",  "carattere"},
        {"FLOAT",  "reale"},
        {"DOUBLE",  "reale doppia precisione"},
        {"STRING",  "stringa"},
        {"DATE",  "data/ora"},
        {"NOVALUE",  "nessun valore"},

        // END OF MATERIAL TO LOCALIZE
    };
}
