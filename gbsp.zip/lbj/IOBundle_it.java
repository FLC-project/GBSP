/*
 * @(#)IOBundle_it.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;

/**
 * The <code>IOBundle_it</code> class provides the Italian locale for
 * the <code>IOError</code> class.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

public class IOBundle_it extends ListResourceBundle {
    public Object[][] getContents() {
        return contents;
    }

    // LOCALIZE THIS

    public static final String[] MSGTAB = {
        "SUCCESS, operazione eseguita",                //  0
        "IOERR, errore di i/o",                        //  1
        "ILLFILE, file illegale",                      //  2
        "OUTLIMIT, limiti eceeduti",                   //  3
        "NOCORE, memoria insufficiente",               //  4
        "NOTOPEN, file no aperto",                     //  5
        "MISMATCH, file cambiato nel frattempo",       //  6
        "RENAME, rinomina del file fallita",           //  7
        "ISOPEN, file aperto",                         //  8
        "NOLOC, file non individuato",                 //  9
        "EXECERR, esecuzione comando fallita" ,        // 10
        "CIRCDEF, definizione circolare ",             // 11
        "INVOP, operazione invalida",                  // 12
        "NOFILE, file inesistente",                    // 13

        "NOSPACE, spazio insufficiente nel record",    // 14
        "NOREC, record mancante",                      // 15
        "NOCHAR, carattere mancante",                  // 16
        "ILLCODE, codice sconosciuto o mancante",      // 17
        "NOOPN, ) non bilanciata",                     // 18
        "NOCLO, ( non chiusa",                         // 19
        "NONUM, numero mancante",                      // 20
        "TOOLOW, numero troppo piccolo",               // 21
        "OUTREC, cursore fouri dal record",            // 22
        "NOTAB, tabulazione assente",                  // 23
        "TOOLRG, numero troppo grande",                // 24
        "MISMATCH, format e lista di i/o inconguenti", // 25
        "FORMAT, format illegale",                     // 26
        "STREAM, file e output callback assenti",      // 27
        "SYSTEM, errore di sistema",                   // 28
        "LOCALE, locale assente",                      // 29
        "NEGNUM, numero negativo",                     // 30
        "NEST, ricursione infinita",                   // 31
        "MISCMA, virgola mancante",                    // 32
        "IOLIST, lista di i/o illegale",               // 33
        "EXHAUSTED, lista di i/o esaurita",            // 34
        "INIT, non inizializzato",                     // 35
        "ILLTYPE, tipo illegale",                      // 36
        "INDEX, indice illegale",                      // 37
        "VALUE, valore illegale",                      // 38
        "RESOURCE, risorsa mancante",                  // 39
        "PRINTERR, errore di i/o su PrintStream",      // 40
        "NOTMAIN, file principale non trovato",        // 41
        "NOCREA, il file non pu\u00f2 essere creato",  // 42
        "ILLCLASS,  classe illegale",                  // 43
        "SECURITY, operazione non autorizzata",        // 44
        "SETTIME, cambio data fallito",                // 45
        "LONGLINE, linea troppo lunga",                // 46
        "ENDOFFILE, fine del file",                    // 47
        "TOOMANY, troppi errori",                      // 48

        "ERRDET, errori riscontrati: ",                // 49
        "DELFAIL, cancellazione del file fallita",     // 50
    };

    private static final Object[][] contents = {
        {"MSGTAB",   MSGTAB},
        {"ONFILE",   "file"},
        {"POSITION", "alla posizione"},
        {"ONFORMAT", "nel format"},
        {"PAGE",     "Pagina"},
        {"EOF",      "fine"},
        {"INFO",     "INFO"},
        {"WARNING",  "AVVERTIMENTO"},
        {"ERROR",    "ERRORE"},
        {"FATAL",    "ERRORE FATALE"},
        {"ERRDET",   "Errori riscontrati:"},
        {"WARNINGS", "avvertimenti"},
        {"ERRORS",   "errori"},
        {"FATALS",   "errori fatali"},
    };

    // END OF MATERIAL TO LOCALIZE
}
