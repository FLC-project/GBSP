/*
 * @(#)Prg.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import java.net.*;

/**
 * The <code>Prg</code> class provides program control functionalities.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

public class Prg extends SecurityManager {
    /* Codes of host systems. */

    /** The VAX_VMS host system code. */
    public static final int VAX_VMS   = 0;

    /** The SPERRY2 host system code. */
    public static final int SPERRY2   = 1;

    /** The PCDOS host system code. */
    public static final int PCDOS     = 2;

    /** The HP_UX host system code. */
    public static final int HP_UX     = 3;

    /** The DECULTRIX host system code. */
    public static final int DECULTRIX = 4;

    /** The SUN_OS host system code. */
    public static final int SUN_OS    = 5;

    /** The NT host system code. */
    public static final int NT        = 6;

    /** The Linux host system code. */
    public static final int LINUX     = 7;

    /* Codes of operating systems. */

    /** The WIN operating system code. */
    public static final int WIN       = 1;

    /** The UNIX operating system code. */
    public static final int UNIX      = 2;

    /** The VMS operating system code. */
    public static final int VMS       = 3;

    /** The OS100 operating system code. */
    public static final int OS100     = 4;

    /** The map of operating systems for host systems. */
    private static final int[] OSMAP =
            {VMS,OS100,WIN,UNIX,UNIX,UNIX,WIN,UNIX};

    /** The current host system code. */
    public static int host = 0;

    /** The current operating system code. */
    public static int os = 0;

    /** The name of the host. */
    public static String hostname;

    /**
     * Determine the current host and the current operating system.
     */

    static {
        hostname = System.getProperty("os.name");
        if (hostname.equals("HP-UX")) host = HP_UX;
        else if (hostname.startsWith("Windows")) host = NT;
        else if (hostname.startsWith("Linux")) host = LINUX;
        else host = VAX_VMS;
        os = OSMAP[host];
        if (System.getProperty("file.separator").charAt(0) == '/')
            os = UNIX;
    }

    /**
     * Determine if the program is running interactively.
     * A program is running interactively if the shell from which it has
     * been run is interactive, e.g. in Unix if a tty command issued before
     * running the program reported a /dev/tty. Note that this is independent
     * on the fact that a program can have its standard files redirected,
     * although this might prevent it from actually interacting with the
     * terminal. The java VM redirects the standard files in the usual
     * way.
     */

    /* For Unix, a file which is /dev/tty always exists and it is readable,
     * but when opening it, an error is reported if the program is running
     * in batch mode.
     * This is a viable way to discover if it is interactive.
     */

    public static boolean interactive(){
        boolean inter = true;

        if (os != UNIX) return true;         // not implemented for
        File tty = new File("/dev/tty");     // .. other OSs
        FileReader in;
        try {
            in = new FileReader(tty);
        } catch (FileNotFoundException e){
            inter = false;
        }
        return inter;
    }

    /**
     * Deliver the class of the main program.
     *
     * @return     string of the class
     */

    public static String getMainClass(){
        Throwable th = new Throwable();            // determine class
        CharArrayWriter cw =                       // .. of program
            new CharArrayWriter();
        PrintWriter pw = new PrintWriter(cw);
        th.printStackTrace(pw);
        String st = cw.toString();
        int start = st.indexOf(".main(");
        if (start < 0){                            // not found (e.g. HP bug)
            Prg cc = new Prg();
            Class<?>[] stack = cc.getClassContext();  // search in class context
            Class[] pars = new Class[] {String[].class};
            for (int i = 0; i < stack.length; i++){
                Method m = null;
                try {
                    m = stack[i].getMethod("main",pars);
                } catch (NoSuchMethodException e){
                }
                if (m != null) return stack[i].getName();
            }
            return null;
        }
        int end = start;
        start = st.lastIndexOf("at ",start) + 3;
        if (start < 0) return null;
        return st.substring(start,end);
    }

    /**
     * Deliver the name of the main program.
     *
     * @param      cl string of the class of the main program
     * @return     name of the main
     */

    public static String getMainName(String cl){
        int start = cl.lastIndexOf('.') + 1;
        return cl.substring(start);
    }

    /**
     * Deliver the version of the main program.
     *
     * @param      cl string of the class of the main program
     * @return     string of the version, null if error
     */

    public static String getMainVersion(String cl){
        String ver = "";
        try {
            Class c = Class.forName((String)cl);
            Package pkg = c.getPackage();
            if (pkg != null) {
                ver = pkg.getImplementationVersion();
                if (ver == null) ver = "";
            }
        } catch (ClassNotFoundException e){
            ver = null;
        }
        return ver;
    }

    /**
     * Deliver the filespec of the main program.
     *
     * @param      cl string of the class of the main program
     * @return     string of the filespec
     */

    public static String getMainFile(String cl){
        URL u;
        u = ClassLoader.getSystemResource
            (cl.replace('.', '/') +".class");
        return u.toString();
    }
}
