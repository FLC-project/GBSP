/*
 * @(#)IntSet.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;

/**
 * The <code>IntSet</code> class provides sets of integers optimised
 * for sets whose values come in a limited amount of ranges.
 * IntSet objects can be reused (which means that memory is kept instead of
 * being released so as to have it next time).
 *
 * @author  Angelo Borsotti
 * @version 1.0   04 Nov 1998
 */


/* A set is represented by a resizable array which contains ranges
 * represented as pairs of values. They are kept ordered to simplify
 * and speed up the operations.
 *
 * The operations are performed in such a way not to allocate temporary
 * storage, and use instead the existing arrays. A write and a read
 * indexes are kept on the array of the first operand. When an attempt
 * is made to insert a range and those indexes are equal, the unread
 * part is moved down so as to make room for the insertion.
 * When possible, blocks of ranges are inserted instead of a single one.
 *
 * Union (add) is implemented as a merge of two ordered lists of ranges:
 * all ranges which do not overlap are transferred into the resulting
 * array, and the ones which overlap are merged. Once two overlapping
 * ranges have been detected, all the subsequent ones which overlap are
 * scanned and a single one inserted.
 * A special case is made for the union (and subtraction) of a single
 * range (and in particular a single element) since in that case it is
 * possible to locate the impacted range (if any) by using binary search.
 *
 * The operations are performed by visiting the arrays representing the
 * operands in parallel. Some of them could be improved by performing
 * a binary search in the iteration to seek the elements which need
 * be operated.
 */

public class IntSet implements Serializable, Cloneable, Comparable, Iterable<Integer> {

    /**
     * The maximum index.
     *
     * @serial
     */
    int max;

    /**
     * The array holding the ranges.
     *
     * @serial
     */
    int[] set;

    /** SUID form JDK 1.2 */
    private static final long serialVersionUID = 5932595248052886861L;

    /** The trace flags. */
    private static int trc;

    static final int FL_A = 1 << ('a'-0x60);
    static final int FL_B = 1 << ('b'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public static void settrc(String s){
        trc = 0;
        for (int i = 0; i < s.length(); i++){
            trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Construct an empty set.
     */

    public IntSet(){
        this.set = new int[10];
    }

    /**
     * Construct a set containing the specified element.
     *
     * @param      el element
     */

    public IntSet(int el){
        this();
        this.max = 2;
        this.set[0] = el;
        this.set[1] = el;
    }

    /**
     * Construct a set containing the specified range.
     *
     * @param      lo lower bound (included)
     * @param      up upper bound (included)
     */

    public IntSet(int lo, int up){
        this();
        this.max = 2;
        this.set[0] = lo;
        this.set[1] = up;
    }

    /**
     * Construct a set containing the specified set.
     *
     * @param      set the set
     */

    public IntSet(IntSet set){
        if (set == null){
            this.set = new int[10];
        } else {
            this.set = (int[])(set.set.clone());
            this.max = set.max;
        }
    }

    /**
     * Construct a set containing a compact copy of the specified set.
     *
     * @param      set the set
     * @param      n extra capacity (number of ranges)
     */

    public IntSet(IntSet set, int n){
        int len = (set == null) ? 0 : set.max;
        this.set = new int[len + n*2];
        if (set != null){
            System.arraycopy(set.set,0,this.set,0,set.max);
            this.max = set.max;
        }
    }

    /**
     * Clone this object.
     *
     * @return     a copy of the object
     */

    public Object clone(){
        IntSet t = null;
        try {
            t = (IntSet)super.clone();
            t.set = (int[])this.set.clone();
        } catch (CloneNotSupportedException e){
        }
        return t;
    }

    /**
     * Deliver a string representing the ranges in an array.
     *
     * @param      st string
     * @param      buf the array
     * @param      start start index
     * @param      end end index
     * @param      chr <code>true</code> to represent elements as chars
     */

    public void toString(Str st, int[] buf, int start, int end,
        boolean chr){
        st.append('{');
        boolean first = true;
        int lower = 0;
        int upper = 0;
        if (buf == null){            // single range
            lower = start;
            upper = end;
            start = 0;
            end = 2;
        }
        for (int i = start; i < end; i +=2){
            if (buf != null){
                lower = buf[i];
                upper = buf[i+1];
            }
            if (!first) st.append(", ");
            first = false;
            if (lower == Integer.MAX_VALUE){
                st.append("max");
            } else if (lower == Integer.MIN_VALUE){
                st.append("min");
            } else if (chr){
                int l = st.length;
                st.append((char)lower);
                st.strQuoted(st.buffer,l,1,st);
                st.cutInsert(l,1,(char[])null,0,0,0);
            } else {
                st.append(Integer.toString(lower));
            }
            if (lower != upper){
                st.append(':');
                if (upper == Integer.MAX_VALUE){
                    st.append("max");
                } else if (upper == Integer.MIN_VALUE){
                    st.append("min");
                } else if (chr){
                    int l = st.length;
                    st.append((char)upper);
                    st.strQuoted(st.buffer,l,1,st);
                    st.cutInsert(l,1,(char[])null,0,0,0);
                } else {
                    st.append(Integer.toString(upper));
                }
            }
        }
        st.append('}');
    }

    /**
     * Deliver a string representing this object.
     *
     * @param      st string
     * @param      chr <code>true</code> to represent elements as chars
     */

    public void toString(Str st, boolean chr){
        toString(st,this.set,0,this.max,chr);
    }

    /**
     * Deliver a string representing this object.
     *
     * @param      chr <code>true</code> to represent elements as chars
     * @return     the string
     */

    public String toString(boolean chr){
        Str st = new Str();
        toString(st,this.set,0,this.max,chr);
        return st.toString();
    }

    /**
     * Deliver a string representing this object.
     */

    public String toString(){
        Str st = new Str();
        toString(st,this.set,0,this.max,false);
        return st.toString();
    }

    /**
     * Deliver a string representing the ranges in an array.
     *
     * @param      buf the array
     * @param      start start index
     * @param      end end index
     * @param      chr <code>true</code> to represent elements as chars
     */

    public String toString(int[] buf, int start, int end, boolean chr){
        Str st = new Str();
        toString(st,buf,start,end,chr);
        return st.toString();
    }

    /**
     * Deliver the lowest value contained in this set.
     *
     * @return     the value
     * @exception  NoSuchElementException if the set is empty
     */

    public int first(){
        if (this.max == 0) throw new NoSuchElementException();
        return this.set[0];
    }

    /**
     * Deliver the highest value contained in this set.
     *
     * @return     the value
     * @exception  NoSuchElementException if the set is empty
     */

    public int last(){
        if (this.max == 0) throw new NoSuchElementException();
        return this.set[this.max-1];
    }

    /**
     * Deliver the number of elements present in this set.
     *
     * @return     number of elements
     */

    public long size(){
        long n = 0;
        for (int i = 0; i < this.max; i += 2){
            int lower = this.set[i];
            int upper = this.set[i+1];
            n += (long)upper - (long)lower + 1;
        }
        return n;
    }

    /**
     * Deliver the number of elements present in this set and that
     * fall within the specified interval.
     *
     * @param      lo lower bound (included)
     * @param      up upper bound (included)
     * @return     number of elements
     */

    public long size(int lo, int up){
        if (up < lo) return 0;
        int l = 0;
        int h = this.max - 2;
        int m = 0;
        int v = 0;
        int[] p = this.set;
        if ((h < 0) || (up < p[0])) return 0;
        if (lo > p[h+1]) return 0;
        while (l <= h){                    // binary search
            m = (l + (h - l) / 2) & ~1 ;   // middle index, no overflow
            v = p[m];
            if (lo < v){                   // it is above
                h = m - 2;
            } else if (lo > v){            // it is below
                l = m + 2;
            } else {                       // found
                l = m + 2;
                break;
            }
        }
        l -= 2;
        if (l < 0) l = 0;
        if ((FL_A & trc) != 0){
            Trc.out.println("size: " + l);
        }
        long n = 0;
        for (int i = l; i < this.max; i += 2){
            int lower = p[i];
            int upper = p[i+1];
            if (up < lower) break;         // all past interval from now on
            if (lo > upper) continue;
            if (lo > lower) lower = lo;    // take intersection
            if (up < upper) upper = up;
            n += (long)upper - (long)lower + 1;
        }
        return n;
    }

    /**
     * Deliver an array containing the elements of this set.
     *
     * @return     the array
     */

    public int[] toArray(){
        int[] arr = new int[(int)size()];
        int n = 0;
        for (int i = 0; i < this.max; i += 2){
            for (int j = this.set[i]; j <= this.set[i+1]; j++){
                arr[n++] = j;
            }
        }
        return arr;
    }

    /**
     * Store in the specified array the elements of this set and
     * return it, or an extended copy of it if it is shorter than needed.
     *
     * @param      arr the array
     * @return     the array, or a resized copy
     */

    public int[] toArray(int[] arr){
        int len = (int)size();
        if (len == 0) return arr;
        if ((arr == null) || (len > arr.length)){
            arr = new int[len];
        }
        int n = 0;
        for (int i = 0; i < this.max; i +=2){
            for (int j = this.set[i]; j <= this.set[i+1]; j++){
                arr[n++] = j;
            }
        }
        return arr;
    }

    /**
     * Store in the specified array the ranges of this set. No storing
     * is done if the array is null.
     *
     * @param      arr the array
     * @return     the number of ranges * 2
     */

    public int toRanges(int[] arr){
        if (arr == null) return this.max;
        System.arraycopy(this.set,0,arr,0,this.max);
        return this.max;
    }

    /**
     * Empty this set.
     */

    public void clear(){
        this.max = 0;
    }

    /**
     * Assign the specified element to this set.
     *
     * @param      el element
     */

    public void assign(int el){
        this.max = 2;
        if (this.max > this.set.length){
            this.set = new int[this.max];
        }
        this.set[0] = el;
        this.set[1] = el;
    }

    /**
     * Assign the specified range to this set.
     *
     * @param      lo lower bound (included)
     * @param      up upper bound (included)
     */

    public void assign(int lo, int up){
        this.max = 2;
        if (this.max > this.set.length){
            this.set = new int[this.max];
        }
        this.set[0] = lo;
        this.set[1] = up;
    }

    /**
     * Assign the contents of the specified set to this one.
     *
     * @param      src source set
     */

    public void assign(IntSet src){
        this.max = 0;
        if (src != null){
            this.max = src.max;
            if (this.max > this.set.length){
                this.set = new int[this.max];
            }
            System.arraycopy(src.set,0,this.set,0,src.max);
        }
    }

    /**
     * Assign this set with the contents of the specified array.
     *
     * @param      arr source array
     */

    public void assign(int[] arr){
        this.max = 0;
        if (arr != null){
            for (int i = 0; i < arr.length; i++){
                this.add(arr[i],arr[i]);
            }
        }
    }

    /**
     * Assign this set with the contents of the specified array of ranges.
     *
     * @param      arr source array
     */

    public void assignRanges(int[] arr){
        this.max = 0;
        if (arr != null){
            this.max = arr.length;
            System.arraycopy(arr,0,this.set,0,arr.length);
        }
    }

    /**
     * Test if this set is equal to the specified object.
     * It delivers <code>true</code> when the argument is not
     * <code>null</code> and is an <code>IntSet</code> object that contains
     * the same elements.
     *
     * @param      other the object to compare
     * @return     true if equal
     */

    public boolean equals(Object other){
        if (this == other) return true;
        if (other == null) return false;
        if (!(other instanceof IntSet)) return false;
        IntSet s = (IntSet)other;
        return equals(s);
    }

    /**
     * Test if this set is equal to a set containing only the specified
     * element.
     *
     * @param      el element
     * @return     <code>true</code> if equal
     */

    public boolean equals(int el){
        if (this.max != 2) return false;
        if (this.set[0] != el) return false;
        if (this.set[1] != el) return false;
        return true;
    }

    /**
     * Test if this set is equal to a set containing only the specified
     * range.
     *
     * @param      lo lower bound (included)
     * @param      up upper bound (included)
     * @return     <code>true</code> if equal
     */

    public boolean equals(int lo, int up){
        if (this.max != 2) return false;
        if (this.set[0] != lo) return false;
        if (this.set[1] != up) return false;
        return true;
    }

    /**
     * Test if this set is equal to the specified one.
     *
     * @param      set the set to compare
     * @return     <code>true</code> if equal
     */

    public boolean equals(IntSet set){
        if (this == set) return true;
        if (set == null) return false;
        if (this.max != set.max) return false;
        for (int i = 0; i < this.max; i++){
            if (this.set[i] != set.set[i]) return false;
        }
        return true;
    }

    /**
     * Compare this object with the specified object. This set is lower
     * than the specified one if it has at least an element which is
     * lower than an element of the other one, having discarded all
     * elements which are present in both.
     *
     * @param   other the object to compare
     * @return  &lt; = or &gt; 0 if this set precedes, is equal or
     *          follows the other.
     */

    public int compareTo(Object other){
        if (other == null) return 1;
        IntSet set = (IntSet)other;
        int n = this.max;
        if (set.max < n) n = set.max;
        int t1[] = this.set;
        int t2[] = set.set;
        int i = 0;
        int j = 0;
        while (n-- != 0) {
            int v1 = t1[i++];
            int v2 = t2[j++];
            if (v1 != v2) return v1 - v2;
        }
        return this.max - set.max;
     }

    /**
     * Return the hashcode for this object.
     *
     * @return     hash code value
     */

    public int hashCode(){
        int h = 0;
        //for (int i = 0; i < this.max; i++){
        //    h = 31*h + this.set[i];
        //}
        int len = this.max;
        if (len > 0){
            h = this.set[0] + this.set[len >> 1] +
                this.set[len - 1] + len;
        }
        return h;
    }

    /**
     * Test if this set is empty.
     *
     * @return     <code>true</code> if it is empty
     */

    public boolean isEmpty(){
        return this.max == 0;
    }

    /**
     * Test if the specified element belongs to this set.
     *
     * @param      el element
     * @return     <code>true</code> if it belongs, <code>false</code> otherwise
     */

    public boolean contains(int el){
        return contains(el,el);
    }

    /**
     * Test if the specified range of elements belongs to this set.
     *
     * @param      lo lower bound (included)
     * @param      up upper bound (included)
     * @return     <code>true</code> if it belongs, <code>false</code> otherwise
     */

    public boolean contains(int lo, int up){
        int l = 0;
        int h = this.max - 2;
        int[] set = this.set;
        if ((h < 0) || (up < set[0])) return false;
        if (lo > set[h+1]) return false;
        int i = 0;
        while (l <= h){                           // binary search
            i = l + (h - l) / 2;                  // middle index, no overflow
            if ((i & 1) != 0) i--;
            if (lo <= set[i+1]) h = i-2;          // it is above
            if (set[i] <= up) l = i+2;            // it is below
        }
        if ((FL_A & trc) != 0){
            Trc.out.println("contains: " + l + " " + h + " " + i);
        }
        if (l-2 > h){                             // found one which intersects
            return (set[i] <= lo) &&
                (up <= set[i+1]);
        }
        return false;
    }

    /**
     * Test if the specified elements belong to this set. I.e.
     * return <code>true</code> if the specified set is a subset
     * of this one.
     *
     * @param      set the elements
     */

    public boolean contains(IntSet set){
        if (set == null) return true;
        for (int i = 0; i < set.max; i += 2){
            if (!contains(set.set[i],set.set[i+1])){
                return false;
            }
        }
        return true;
    }

    /**
     * Test if the specified set intersects with this one.
     *
     * @param      set set
     * @return     <code>true</code> if it intersects, <code>false</code> otherwise
     */

    public boolean intersects(IntSet set){
        if (set == null){
            return false;
        }
        if ((FL_A & trc) != 0){
            Trc.out.println("intersects: " + toString() +
                " and " + set.toString());
        }
        int[] s = this.set;
        int[] t = set.set;
        if (this.max == 0){                      // s empty
            return false;
        }
        if (set.max == 0){                       // t empty
            return false;
        }
        if (t[0] > s[this.max-1]){               // t      ----
                                                 //    ---       s
            return false;
        }
        if (s[0] > t[set.max-1]){                // t  ----
                                                 //         ---  s
            return false;
        }

        int i = 0;                               // index in first
        int j = 0;                               // index in second
        while ((i < this.max) && (j < set.max)){
            if (s[i+1] < t[j]){                  // s[i] < t[j]
                i += 2;
                continue;
            }
            if (t[j+1] < s[i]){                  // t[j] < s[i]
                j += 2;
                continue;
            }
            return true;                         // they intersect
        }
        return false;
    }


    /**
     * Add the specifed element to this set. Calls can be chained
     * to initialize this set with a sequence of values.
     *
     * @param      el element
     * @return     this set
     */

    public IntSet add(int el){
        add(el,el);
        return this;
    }

    /**
     * Add the specifed range to this set. Calls can be chained
     * to initialize this set with a sequence of values.
     *
     * @param      lo lower bound (included)
     * @param      up upper bound (included)
     * @return     this set
     */

    /* Since there can be many ranges which overlap the given one, the
     * lowest one is found. To do it there is a need to seek the range
     * which includes the lower bound. A special case occurs when the lower
     * bound is not in any range (or not adjecent to the lower bound of
     * a range), but it is adjacent to the upper bound of one.
     * When the range is found, it is merged with the specified one,
     * and all the following ones which overlap with the result or are
     * adjacent to it are merged also.
     */

    public IntSet add(int lo, int up){
        if ((FL_A & trc) != 0){
            Trc.out.println("add: " + lo + " " + up + " to " +
                toString());
        }
        if (up < lo) return this;                 // (lo:up) empty
        int[] set = this.set;
        int l = 0;                                // binary search of lo
        int h = this.max - 2;
        int min = l;
        int i = 0;
        sea: {
            if ((h < 0) || (up < set[0])) break sea;
            if (lo > set[h+1]){
                i = h;
                l = this.max;
            } else {
                while (l <= h){                   // binary search
                    i = l + (h - l) / 2;          // middle index, no overflow
                    if ((i & 1) != 0) i--;
                    if (lo <= set[i+1]) h = i-2;  // it is above
                    if (set[i] <= lo) l = i+2;    // it is below. N.B. lo
               }
            }
            if (l-2 <= h){                        // not found
                if (l > i) i += 2;                // insert below
                if (i > min){
                    if ((set[i-1] != Integer.MAX_VALUE) &&
                        (lo == set[i-1] + 1)){    // adjacent to the previous
                        i -= 2;
                    }
                }
            }
        }
        ins: {
            if (i >= this.max) break ins;
            int lower = set[i];
            int upper = set[i+1];
            if (upper != Integer.MAX_VALUE){
                if (lo > upper + 1){              // s < (lo:up)
                    break ins;
                }
            }
            if ((lower <= lo) && (up <= upper)){  // (lo:up) in s
                return this;
            }
            if (up != Integer.MAX_VALUE){
                if (up + 1 < lower){              // (lo:up) < s
                    break ins;
                }
            }
            if (lo < lower){                      // (lo:up) overlaps s
                lower = lo;
                set[i] = lower;                   // .. and extends before
            }
            if (up <= upper){                     // (lo:up) does not extend
                return this;                      // .. after s
            }
            upper = up;
            set[i+1] = upper;
            int j = i+2;
            int upp = upper;
            if (upper != Integer.MAX_VALUE) upp++;
            for (; j < this.max; j += 2){         // remove the elements which
                if (set[j] > upp){                // .. now overlap the
                    break;                        // .. updated one
                }
            }
            if ((j - i) > 2){                     // there are some which
                if (set[j-1] > upper){            // .. overlap
                    set[i+1] = set[j-1];
                }
                if (this.max - j > 0){
                    System.arraycopy(set,j,set,i+2,this.max-j);
                }
            }
            this.max -= j-i-2;
            return this;
        } // ins
        if (this.max >= set.length-1){
            int curLen = set.length;
            int newlen = curLen + 10;
            if (newlen < 0){
                throw new OutOfMemoryError();
            }
            int[] p = new int[newlen];
            System.arraycopy(set,0,p,0,i);
            System.arraycopy(set,i,p,i+2,this.max-i);
            this.set = p;
            set = p;
        } else {
            if (max-i > 0){
                System.arraycopy(set,i,set,i+2,this.max-i);
            }
        }
        set[i] = lo;
        set[i+1] = up;
        this.max += 2;
        if ((FL_A & trc) != 0){
            Trc.out.println("add end: " + toString());
        }
        return this;
    }

    /**
     * Store in this set the union of it with the specified one.
     * Calls can be chained to initialize this set with a sequence of values.
     *
     * @param      set the set to add
     * @return     this set
     */

    public IntSet add(IntSet set){
        if (set == null) return this;
        if ((FL_A & trc) != 0){
            Trc.out.println("add: " + toString() + " and " + set);
        }
        int[] s = this.set;
        int[] t = set.set;
        int i = 0;                               // index in first
        int j = 0;                               // index in second
        int k = 0;                               // index in result
        int p;
        while ((i < this.max) && (j < set.max)){
            p = i;
            for (; (i < this.max) &&             // all s[i] < t[j]
                (s[i+1] < t[j]); i += 2){
            }
            if (i > p){                          // some to add
                if ((FL_A & trc) != 0){
                    Trc.out.println("add: ins s");
                }
                k = insert(k,i,s,p,i);
                s = this.set;
                continue;
            }
            p = j;
            for (; (j < set.max) &&              // all t[j] < s[i]
                (t[j+1] < s[i]); j += 2){
            }
            if (j > p){                          // some to add
                if ((FL_A & trc) != 0){
                    Trc.out.println("add: ins t");
                }
                k = insert(k,i,t,p,j);
                s = this.set;
                if (k > i) i = k;
                continue;
            }
            if ((FL_A & trc) != 0){
                Trc.out.println("add: ins overlapping");
            }
            p = i;
            if (t[j] < s[p]) s[p] = t[j];        // they intersect
            if (t[j+1] > s[p+1]) s[p+1] = t[j+1];
            i += 2;
            j += 2;
            k = insert(k,i,s,p,i);
            p = k - 2;
            s = this.set;
            boolean change = false;
            do {                                 // merge all the overlapping ones
                if ((FL_B & trc) != 0){
                    Trc.out.println("overlapping " + i + " " +
                        ((i < this.max) ?
                            toString(null,s[i],s[i+1],false) : "") +
                        " " + j + " " +
                        ((j < set.max) ?
                            toString(null,t[j],t[j+1],false) : ""));
                }
                change = false;
                if (i < this.max){
                    if ((s[i] >= s[p]) && (s[i] <= s[p+1])){
                        if (s[i+1] > s[p+1]) s[p+1] = s[i+1];
                        i += 2;
                        change = true;
                        continue;
                    }
                }
                if (j < set.max){
                    if ((t[j] >= s[p]) && (t[j] <= s[p+1])){
                        if (t[j+1] > s[p+1]) s[p+1] = t[j+1];
                        j += 2;
                        change = true;
                        continue;
                    }
                }
            } while (change);
            if ((FL_B & trc) != 0){
                Trc.out.println("add: loop " + i + " " + j);
            }
        }
        if (i < this.max){                       // some to add
            if ((FL_A & trc) != 0){
                Trc.out.println("add: ins tail s");
            }
            k = insert(k,this.max,s,i,this.max);
        } else if (j < set.max){
            if ((FL_A & trc) != 0){
                Trc.out.println("add: ins tail t");
            }
            k = insert(k,i,t,j,set.max);
        }
        this.max = k;
        return this;
    }

    /**
     * Copies in this set the specified ranges in an optimal way.
     * When the first range is adiacent to the last one stored,
     * it is merged with it. When the ranges are located in this
     * set, they are in the region from k (included) to i (excluded).
     * If the reference to the source array is <code>null</code>,
     * then the p and j argument represent a single range to include.
     *
     * @param      k index at which to place the ranges
     * @param      i index of the part not to overwrite
     * @param      t source array containing the ranges
     * @param      p start index of ranges to copy
     * @param      j end index of ranges to copy
     * @return     index of the end of insertion
     */

    private int insert(int k, int i, int[] t, int p, int j){
        int[] s = this.set;

        if ((FL_A & trc) != 0){
            Trc.out.println("ins: " + toString(t,p,j,false) +
                ((s == t) ? " shift" : " copy"));
            Trc.out.println("into: " + toString(this.set,0,k,false) +
                "|" + k + " " + i + "|" +
                toString(this.set,i,this.max,false));
        }
        if ((FL_B & trc) != 0){
            Trc.out.println("ins: " + k + " " + i + " " + p + " " + j +
                ((s == t) ? " shift" : " copy"));
        }
        int lo;
        int up;
        if (t == null){                  // single range
            lo = p;
            up = j;
            p = 0;
            j = 2;
        } else {
            lo = t[p];
            up = t[p+1];
        }
        if ((k > 0) &&                   // check adjacency of 1st
            (lo == s[k-1] + 1)){         // adjacent
            s[k-1] = up;                 // n.b. the previous is not
            p += 2;                      // .. the max
            if ((FL_A & trc) != 0){
                Trc.out.println("glued: " + p);
            }
        }
        if (j > p){                      // some more to add
            int room = j - p;            // compute extra room needed
            if (i < this.max){           // in the hole
                room -= i - k;
            } else {                     // at the end
                room -= this.set.length - k;
            }
            if ((FL_B & trc) != 0){
                Trc.out.println("check space " + j + " " + p +
                    " " + i + " " + k + " " + this.set.length +
                    " " + this.max + " => " + room);
            }
            if (room > 0){               // make room
                if ((FL_B & trc) != 0){
                    Trc.out.println("opened: " + room);
                }
                if (k > this.set.length - (j - p) -    // end index
                    (this.max - i)){                   // .. beyond array
                    int curLen = this.set.length;      // .. resize
                    int newlen = curLen + room + 10;
                    if (newlen < 0){
                        throw new OutOfMemoryError();
                    }
                    s = new int[newlen];
                    if ((FL_A & trc) != 0){
                        Trc.out.println("resized: " + curLen +
                            " to: " + newlen);
                    }
                    if (k > 0){
                        System.arraycopy(this.set,0,s,0,k);
                    }
                    if (this.max-i > 0){
                        System.arraycopy(this.set,i,s,i+room,this.max-i);
                        this.max += room;
                    }
                    this.set = s;
                } else {                               // enlarge hole
                    if (this.max-i > 0){
                        if ((FL_A & trc) != 0){
                            Trc.out.println("widened");
                        }
                        System.arraycopy(s,i,s,i+room,this.max-i);
                        this.max += room;
                    }
                }
            }
            if ((k < p) || (t != s)){    // not in place
                if ((FL_A & trc) != 0){
                    Trc.out.println("copied");
                }
                if (t == null){
                    s[k] = lo;
                    s[k+1] = up;
                } else {
                    System.arraycopy(t,p,s,k,j-p);
                }
            }
            k += j - p;
        }
        if ((FL_A & trc) != 0){
            if (k > i) i = k;
            Trc.out.println("end ins: " + toString(s,0,k,false) +
                "|" + k + " " + i + "|" + toString(s,i,this.max,false));
        }
        return k;
    }

    /**
     * Store in this set the union of it with the specified one.
     * Same as <code>add(IntSet)</code>.
     *
     * @param      set the set to add
     */

    public void addAll(IntSet set){
        add(set);
    }

    /**
     * Retain only the elements which also belong to the specifed set.
     * Same as <code>and(IntSet)</code>.
     *
     * @param      set the set of elements to be retained
     */

    public void retainAll(IntSet set){
        and(set);
    }

    /**
     * Store in this set the intersection of it with the specified element.
     *
     * @param      el element
     */

    public void and(int el){
        if (contains(el)){       // it contains the element
            assign(el);          // reduce this set to it
        } else {
            clear();
        }
    }

    /**
     * Store in this set the intersection of it with the specified range.
     *
     * @param      lo lower bound (included)
     * @param      up upper bound (included)
     */

    public void and(int lo, int up){
        if ((FL_A & trc) != 0){
            Trc.out.println("and: " + lo + " " + up + " to " +
            toString());
        }
        if (this.max == 0){                      // s empty
            return;
        }
        if (up < lo) return;                     // (lo:up) empty
        int[] s = this.set;
        if (lo > s[this.max-1]){                 // lo      ----
            this.max = 0;                        //    ---       s
            return;
        }
        if (s[0] > up){                          // up  ----
            this.max = 0;                        //         ---  s
            return;
        }

        int i = 0;                               // index in first
        int k = 0;                               // index in result
        while (i < this.max){
            if (s[i+1] < lo){                    // s[i] < lo
                i += 2;
                continue;
            }
            if (up < s[i]){                      // up < s[i]
                break;
            }
            int slo = s[i];
            if (lo > slo) slo = lo;              // they intersect
            int sup = s[i+1];
            int supt = up;
            if (supt <= sup){                    // lo:up .....---
                if ((FL_A & trc) != 0){          //          ------- s
                    Trc.out.println("and: ins tail s");
                }
                k = insert(k,i,null,slo,supt);
                s = this.set;
                if (k > i) i = k;
                if (supt < sup){
                    s[i] = supt + 1;             // keep tail as current
                } else {
                    i += 2;
                }
                break;
            } else {                             // store tail of s[i]
                int p = i;
                s[p] = slo;
                s[p+1] = sup;
                i += 2;
                if ((FL_A & trc) != 0){
                    Trc.out.println("and: ins tail s");
                }
                k = insert(k,i,s,p,i);
                s = this.set;
            }
        }
        this.max = k;
    }

    /**
     * Store in this set the intersection of it with the specified one.
     *
     * @param      set the set to intersect
     */

    /* When s[i] has elements beyond t[j+1], it must be kept to be
     * intersected with the subsequent t's. For sake of simplicity,
     * the current intersection is stored without taking into account
     * what would eventually happen to s[i], which could also disappear.
     */

    public void and(IntSet set){
        if (set == null){
            this.max = 0;
            return;
        }
        if ((FL_A & trc) != 0){
            Trc.out.println("and: " + toString() +
                " and " + set.toString());
        }
        int[] s = this.set;
        int[] t = set.set;
        if (this.max == 0){                      // s empty
            return;
        }
        if (set.max == 0){
            this.max = 0;                        // t empty
            return;
        }
        if (t[0] > s[this.max-1]){               // t      ----
            this.max = 0;                        //    ---       s
            return;
        }
        if (s[0] > t[set.max-1]){                // t  ----
            this.max = 0;                        //         ---  s
            return;
        }

        int i = 0;                               // index in first
        int j = 0;                               // index in second
        int k = 0;                               // index in result
        while ((i < this.max) && (j < set.max)){
            if (s[i+1] < t[j]){                  // s[i] < t[j]
                i += 2;
                continue;
            }
            if (t[j+1] < s[i]){                  // t[j] < s[i]
                j += 2;
                continue;
            }
            int lo = s[i];
            if (t[j] > lo) lo = t[j];            // they intersect
            int up = s[i+1];
            int upt = t[j+1];
            if (upt <= up){                      // t .....---
                if ((FL_A & trc) != 0){          //       ------- s
                    Trc.out.println("and: ins tail s");
                }
                k = insert(k,i,null,lo,upt);
                s = this.set;
                if (k > i) i = k;
                if (upt < up){
                    s[i] = upt + 1;              // keep tail as current
                } else {
                    i += 2;
                }
                j += 2;
            } else {                             // store tail of s[i]
                int p = i;
                s[p] = lo;
                s[p+1] = up;
                i += 2;
                if ((FL_A & trc) != 0){
                    Trc.out.println("and: ins tail s");
                }
                k = insert(k,i,s,p,i);
                s = this.set;
            }
        }
        this.max = k;
    }

    /**
     * Remove the specifed element from this set.
     *
     * @param      el element
     */

    public void sub(int el){
        sub(el,el);
    }

    /**
     * Remove the specifed range from this set.
     *
     * @param      lo lower bound (included)
     * @param      up upper bound (included)
     */

    public void sub(int lo, int up){
        if ((FL_A & trc) != 0){
            Trc.out.println("sub: " + lo + " " + up + " to " +
                toString());
        }
        if (up < lo) return;                      // (lo:up) empty
        int[] s = this.set;
        int i = 0;                               // index in first
        int k = 0;                               // index in result
        while (i < this.max){
            int p = i;
            for (; (i < this.max) &&             // all s[i] < t[j]
                (s[i+1] < lo); i += 2){
            }
            if (i > p){                          // some to add
                if ((FL_A & trc) != 0){
                    Trc.out.println("sub: ins s");
                }
                k = insert(k,i,s,p,i);
                s = this.set;
                continue;
            }
            if (up < s[i]) break;                // up < s[i]
            if ((lo <= s[i]) &&                  // lo:up ----------
                (s[i+1] <= up)){                 //          ---- s[i]
                i += 2;
                continue;
            }
            if (lo <= s[i]){                     // lo:up -----
                if (up != Integer.MAX_VALUE){    //          ----- s[i]
                    s[i] = up + 1;
                }
                break;
            }
            if (up >= s[i+1]){                   // lo:up   -------
                p = i;                           //       -------  s[i]
                if (lo  != Integer.MIN_VALUE){
                    s[i+1] = lo - 1;
                }
                i += 2;
                if ((FL_A & trc) != 0){
                    Trc.out.println("sub: ins head s");
                }
                k = insert(k,i,s,p,i);
                s = this.set;
                continue;
            }
            p = i;                               // lo:up   ---
            if ((FL_A & trc) != 0){              //       --------- s[i]
                Trc.out.println("sub: ins split s");
            }
            k = insert(k,i,null,s[p],lo-1);
            s = this.set;
            if (k > i) i = k;
            if (up != Integer.MAX_VALUE){
                s[i] = up + 1;
            }
        }
        if (i < this.max){                       // tail to add
            if ((FL_A & trc) != 0){
                Trc.out.println("sub: ins tail s");
            }
            k = insert(k,this.max,s,i,this.max);
        }
        this.max = k;
    }

    /**
     * Remove the specified set from this one.
     *
     * @param      set the set to remove
     */

    public void sub(IntSet set){
        if (set == null) return;
        if ((FL_A & trc) != 0){
            Trc.out.println("sub: " + toString() +
                " and " + set.toString());
        }
        int[] s = this.set;
        int[] t = set.set;
        int i = 0;                               // index in first
        int j = 0;                               // index in second
        int k = 0;                               // index in result
        while ((i < this.max) && (j < set.max)){
            int p = i;
            for (; (i < this.max) &&             // all s[i] < t[j]
                (s[i+1] < t[j]); i += 2){
            }
            if (i > p){                          // some to add
                if ((FL_A & trc) != 0){
                    Trc.out.println("sub: ins s");
                }
                k = insert(k,i,s,p,i);
                s = this.set;
                continue;
            }
            p = j;
            for (; (j < set.max) &&              // all t[j] < s[i]
                (t[j+1] < s[i]); j += 2){
            }
            if (j > p){                          // some to skip
                continue;
            }
            if ((t[j] <= s[i]) &&                // t[j] ----------
                (s[i+1] <= t[j+1])){             //         ---- s[i]
                i += 2;
                continue;
            }
            if (t[j] <= s[i]){                      // t[j] -----
                if (t[j+1] != Integer.MAX_VALUE){   //         ----- s[i]
                    s[i] = t[j+1] + 1;
                }
                j += 2;
                continue;
            }
            if (t[j+1] >= s[i+1]){               // t[j]   -------
                p = i;                           //      -------  s[i]
                if (t[j]  != Integer.MIN_VALUE){
                    s[i+1] = t[j] - 1;
                }
                i += 2;
                if ((FL_A & trc) != 0){
                    Trc.out.println("sub: ins head s");
                }
                k = insert(k,i,s,p,i);
                s = this.set;
                continue;
            }
            p = i;                               // t[j]   ---
            if ((FL_A & trc) != 0){              //      --------- s[i]
                Trc.out.println("sub: ins split s");
            }
            k = insert(k,i,null,s[p],t[j]-1);
            s = this.set;
            if (k > i) i = k;
            if (t[j+1] != Integer.MAX_VALUE){
                s[i] = t[j+1] + 1;
            }
            j += 2;
        }
        if (i < this.max){                       // tail to add
            if ((FL_A & trc) != 0){
                Trc.out.println("sub: ins tail s");
            }
            k = insert(k,this.max,s,i,this.max);
        }
        this.max = k;
    }

    /**
     * Remove the specifed elements from this set.
     * Same as <code>sub(IntSet)</code>.
     *
     * @param      set the elements to be removed
     */

    public void remove(IntSet set){
        sub(set);
    }

    /**
     * Remove the specifed element from this set.
     * Same as <code>sub(int)</code>.
     *
     * @param      el element
     */

    public void remove(int el){
        sub(el,el);
    }

    /**
     * Store in this set the exclusive union of this set with the
     * specified element.
     *
     * @param      el element
     */

    public void xor(int el){
        xor(el,el);
    }

    /**
     * Store in this set the exclusive union of this set with the
     * specified range.
     *
     * @param      lo lower bound (included)
     * @param      up upper bound (included)
     */

    public void xor(int lo, int up){
        if ((FL_A & trc) != 0){
            Trc.out.println("xor: " + lo + " " + up + " and " +
                toString());
        }
        int[] s = this.set;
        int i = 0;                               // index in first
        int k = 0;                               // index in result
        int p;
        boolean tail = true;
        while (i < this.max){
            p = i;
            for (; (i < this.max) &&             // all s[i] < lo
                (s[i+1] < lo); i += 2){
            }
            if (i > p){                          // some to add
                if ((FL_A & trc) != 0){
                    Trc.out.println("xor: ins s");
                }
                k = insert(k,i,s,p,i);
                s = this.set;
                continue;
            }
            if (up < s[i]){                      // add lo:up
                if ((FL_A & trc) != 0){
                    Trc.out.println("xor: ins t");
                }
                k = insert(k,i,null,lo,up);
                s = this.set;
                if (k > i) i = k;
                tail = false;
                break;
            }

            if ((FL_A & trc) != 0){
                Trc.out.println("xor: ins overlapping");
            }
            tail = false;
            if (lo < s[i]){                          // lo:up -----...
                k = insert(k,i,null,lo,s[i]-1);      //          --... s[i]
                s = this.set;
                if (k > i) i = k;
                lo = s[i];
            } else if (s[i] < lo){                   // lo:up   ---...
                k = insert(k,i,null,s[i],lo-1);      //       -----... s[i]
                s = this.set;
                if (k > i) i = k;
                s[i] = lo;
            }
            if (s[i+1] > up){                        // lo:up ...---
                s[i] = up + 1;                       //       ...------ s[i]
                tail = false;
                break;
            } else if (up > s[i+1]){                 // lo:up ...------
                lo = s[i+1] + 1;                     //       ...---    s[i]
                i += 2;
                tail = true;
            } else {
                i += 2;
                tail = false;
                break;
            }
        }
        if (i < this.max){                       // some to add
            if ((FL_A & trc) != 0){
                Trc.out.println("xor: ins tail s");
            }
            k = insert(k,this.max,s,i,this.max);
        } else if (tail){
            if ((FL_A & trc) != 0){
                Trc.out.println("xor: ins tail t");
            }
            k = insert(k,i,null,lo,up);
        }
        this.max = k;
        if ((FL_A & trc) != 0){
            Trc.out.println("xor: res: " + toString());
        }
    }

    /**
     * Store in this set the exclusive union of this set with the
     * specified one.
     *
     * @param      set the set to xor
     */

    public void xor(IntSet set){
        if (set == null) return;
        if ((FL_A & trc) != 0){
            Trc.out.println("xor: " + toString() +
                " and " + set.toString());
        }
        int[] s = this.set;
        int[] t = (int[])set.set.clone();
        int i = 0;                               // index in first
        int j = 0;                               // index in second
        int k = 0;                               // index in result
        int p;
        while ((i < this.max) && (j < set.max)){
            p = i;
            for (; (i < this.max) &&             // all s[i] < t[j]
                (s[i+1] < t[j]); i += 2){
            }
            if (i > p){                          // some to add
                if ((FL_A & trc) != 0){
                    Trc.out.println("xor: ins s");
                }
                k = insert(k,i,s,p,i);
                s = this.set;
                continue;
            }
            p = j;
            for (; (j < set.max) &&              // all t[j] < s[i]
                (t[j+1] < s[i]); j += 2){
            }
            if (j > p){                          // some to add
                if ((FL_A & trc) != 0){
                    Trc.out.println("xor: ins t");
                }
                k = insert(k,i,t,p,j);
                s = this.set;
                if (k > i) i = k;
                continue;
            }
            if ((FL_A & trc) != 0){
                Trc.out.println("xor: ins overlapping");
            }
            if (t[j] < s[i]){                        // t[j] -----...
                k = insert(k,i,null,t[j],s[i]-1);    //         --... s[i]
                s = this.set;
                if (k > i) i = k;
                t[j] = s[i];
            } else if (s[i] < t[j]){                 // t[j]   ---...
                k = insert(k,i,null,s[i],t[j]-1);    //      -----... s[i]
                s = this.set;
                if (k > i) i = k;
                s[i] = t[j];
            }
            if (s[i+1] > t[j+1]){                    // t[j] ...---
                s[i] = t[j+1] + 1;                   //      ...------ s[i]
                j += 2;
            } else if (t[j+1] > s[i+1]){             // t[j] ...------
                t[j] = s[i+1] + 1;                   //      ...---    s[i]
                i += 2;
            } else {
                j += 2;
                i += 2;
            }
        }
        if (i < this.max){                       // some to add
            if ((FL_A & trc) != 0){
                Trc.out.println("xor: ins tail s");
            }
            k = insert(k,this.max,s,i,this.max);
        } else if (j < set.max){
            if ((FL_A & trc) != 0){
                Trc.out.println("xor: ins tail t");
            }
            k = insert(k,i,t,j,set.max);
        }
        this.max = k;
    }

    /**
     * An iterator over this object.
     */

    public class IntSetIter implements Iterator<Integer> {

        /** The reference to the next range. */
        private int toVisit;
      
        /** The reference to the next element. */
        private int nextElem;

        /**
         * Construct a new iterator.
         */

        public IntSetIter(){
            if (IntSet.this.max > 0){
                this.nextElem = IntSet.this.set[0];
            }
        }

        /**
         * Tell if the iteration has elements left to visit.
         *
         * @return     <code>true</code> if there are elements.
         */

        public boolean hasNext(){
            return this.toVisit < IntSet.this.max;
        }

        /**
         * Return the next element to visit. It is not failsafe: no
         * changes must be dune while visiting this set.
         *
         * @return     the next element, 0 if there are no more elements
         */

        public Integer next(){
            int el = 0;
            if (this.toVisit < IntSet.this.max){
                el = this.nextElem;
                if (this.nextElem == IntSet.this.set[this.toVisit+1]){
                    this.toVisit += 2;
                    if (this.toVisit < IntSet.this.max){
                        this.nextElem = IntSet.this.set[this.toVisit];
                    }
                } else {
                    this.nextElem++;
                }
            }
            return el;
        }

        public void remove(){
            throw new UnsupportedOperationException();
        }
    }

    /**
     * Return an iterator over the elements in this set. The elements
     * are delivered in no particular order.
     *
     * @return  reference to the iterator
     */

    public Iterator<Integer> iterator() {
        return new IntSetIter();
    }
}
