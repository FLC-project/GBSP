/*
 * @(#)ParserGen.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;
import lbj.HashBag.*;
import lbj.HashTbl.*;
import lbj.ParserLexer.*;
import lbj.ParserNode.*;

/**
 * The <code>ParserGen</code> class provides a generator of the parsing
 * tables for the parser engine.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */


class ParserGen {

    /** Whether chain rules reduction must be made. */
    static final int CHAIN_RULES = 1 << 20;

    static final int SINGLETON_RULES = 1 << 21;
    static final int NO_LOOKAHEADS = 1 << 22;
    static final int BASIC = 1 << 23;
    static final int FORCED = 1 << 25;      // extra_data is 24
    static final int SINGLETONS = 1 << 27;  // singleton made with singmap
    static final int GE = 1 << 26;          // generate Aycock tables
    static final int NOGROUPS = 1 << 28;    // do not change rules of groups
    static final int GES = 1 << 29;         // generate Aycock tables with split rules

    static final int LRGROUPS = 1 << 19;         // generate LR group rules

    /** The mode. */
    int mode;

    void traceGenMode(){
        Trc.out.printf("mode: %s\n",genModeToString(this.mode));
    }

    static String genModeToString(int mode){
        return
            ((CHAIN_RULES & mode) != 0 ? " chain" : "") + 
            ((SINGLETON_RULES & mode) != 0 ? " singletonrules" : "") + 
            ((NO_LOOKAHEADS & mode) != 0 ? " nolookahead" : "") +
            ((BASIC & mode) != 0 ? " basic" : "") +
            ((FORCED & mode) != 0 ? " forced" : "") +
            ((SINGLETONS & mode) != 0 ? " singletons" : "") +
            ((NOGROUPS & mode) != 0 ? " nogroups" : "") +
            ((GE & mode) != 0 ? " e-dfa" : "") +
            ((GES & mode) != 0 ? " e-split-dfa" : "") +
            ((ParserTables.LEFTGROUPS & mode) != 0 ? " leftgroups" : "");
    }

    /** The number of nonterminals. */
    int ntNum;

    /** The reference to the grammar. */
    ParserGrammar gram;

    /** The lexer object for error reporting. */
    private ParserLexer lex;

    /** The parser tables. */
    ParserTables tab;

    /** The table of the director sets for rules. */
    byte[][] directors;

    /** The table of the director sets for nonterminals. */
    byte[][] directorsNt;

    /** The table of the FIRST sets. */
    byte[][] first;

    /** The table of the FOLLOW sets. */
    byte[][] follow;

    /** Whether groups are treated directly in the engine. */
    boolean foldGroups;

    /** The origin grammar (GE and GES modes). */
    ParserGen orig;

    /** The trace flags. */
    int trc;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    e   normal trace
     * </pre></blockquote><p>
     */

    static final int FL_E = 1 << ('e'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /** 
     * Construct a parser generator for the specified grammar and lexicon.
     *
     * @param      gram reference to the grammar
     * @param      aut reference to the automaton of the lexicon
     */

    ParserGen(ParserGrammar gram, ParserTables aut){
        this.trc = gram.trc;
        this.gram = gram;
        this.lex = gram.lex;
        this.tab = aut;
    }

    /** 
     * Generate a parsing engine.
     */

    public void genParser(){
        if ((FL_E & this.trc) != 0){
            Trc.out.printf("genParser mode %s\n",genModeToString(this.mode));
        }
        ParserTables cloned = null;
        int mode = this.mode;
        if (((GE | GES) & this.mode) != 0){
            cloned = (ParserTables)this.tab.clone();
        }

        ParserDic st = prepareGrammar(null);  // add enveloping rule, allocate
        predictTables();                      // generate directors
        encodeGrammar();                      // generate the parsing tables
        if (((GE | GES) & this.mode) != 0){               // generate origin grammar and ..
            this.orig = new ParserGen(this.gram,cloned);  // .. map of rules new->origin
            this.orig.mode = mode;
            this.orig.mode &= ~(GE | GES);
            this.orig.prepareGrammar(st);                 // add enveloping rule, allocate
            this.orig.predictTables();                    // generate directors
            this.orig.encodeGrammar();                    // generate the parsing tables
            this.tab.originTables = this.orig.tab;
            buildRuleMap();
        }
    }

    /** 
     * Prepare the grammar for the generation of the parsing tables.
     * Envelop the starting symbol in a rule which appends a newly
     * introduced lexeme at the end.
     * Determine the number of rules and build the ruleIndex, ntStrings,
     * ntToRule and ntKind tables and allocate the remaining ones.
     */

    /* It builds a table containing the grammar nonterminals which are
     * not internal, ordered lexicographically, followed by the internal
     * ones and ended by the newly introduced starting symbol.
     * This is the table of the nonterminals on which the remaining part
     * of the generation operates.
     * The nonterminals are assigned numbers according to the lexicographical ordering,
     * but the table is not ordered.
     * However, since the other tables are filled using such numbers, they are
     * actually ordered.
     */

    private ParserDic prepareGrammar(ParserDic st){
        if (st == null){
            st = this.gram.ntDic.                       // new start symbol
               newParserDic(null,ParserDic.NTER);
            st.status |= ParserNode.GRAM;
            ParserNode n1 = this.gram.newNode(          // its rule
                ParserNode.S_TER,this.gram.start_sy.point);
            n1.def = new ParserDic(ParserDic.TER,new Str("EOF"));
            n1.def.tokNum = this.tab.numOfToks;
            n1.def.attr |= ParserNode.LIT_TOK;
            ParserNode n2 = this.gram.newNode(
                ParserNode.S_NT,this.gram.start_sy.point);
            n2.def = this.gram.start_sy;                // <S> EOF
            n2.suc = n1;
            st.def = n2;
            if ((FL_E & this.trc) != 0){
                Trc.out.println("prepareGrammar " + st +
                    " " + ((ParserNode.INTER & st.status) != 0) +
                   " " + st.kind);
            }
        }

        this.foldGroups = ((NOGROUPS|ParserTables.LEFTGROUPS) & this.mode) == 0;  // enable direct treatment of groups

        // build a table with the grammar nonterminals followed
        // by the ones of groups

        // count nonterminals

        this.ntNum = 1;                                 // for the top one
        /*
        since there is a token eof, the enclosing rule never produces the empty string
        if ((GE & this.mode) != 0){
            if ((ParserNode.EM & this.gram.start_sy.status) != 0){
                if ((ParserNode.EO & this.gram.start_sy.status) == 0){
                    this.ntNum++;                       // for the epsilon one
                }
            }
        }
        */
        for (ParserDic h = this.gram.ntDic.head;        // scan grammar nt's, and count them
            h != null; h = h.suc){
            if ((ParserNode.GRAM & h.status) == 0){
                continue;
            }
            this.ntNum++;
            if ((GE & this.mode) != 0){
                if ((ParserNode.EM & h.status) != 0){
                    if ((ParserNode.EO & h.status) == 0){
                        this.ntNum++;                   // for the epsilon one
                    }
                }
            }
        }
        this.ntTab = new ParserDic[this.ntNum];
        this.ntNum = 0;
        for (ParserDic h = this.gram.ntDic.head;        // fill ntTab with non-internals first
            h != null; h = h.suc){
            if (((ParserNode.GRAM & h.status) == 0) ||  // non grammar one
                ((ParserNode.INTER & h.status) != 0)){  // groups
                continue;
            }
            this.ntTab[this.ntNum++] = h;
            if ((GE & this.mode) != 0){
                if ((ParserNode.EM & h.status) != 0){
                    if ((ParserNode.EO & h.status) == 0){
                        this.ntTab[this.ntNum++] = h;   // for the epsilon one
                    }
                }
            }
        }
        ParserDic[] ordNt = new ParserDic[this.ntNum];  // order non-internals by names
        System.arraycopy(this.ntTab,0,ordNt,0,this.ntNum);
        Arrays.sort(ordNt,0,this.ntNum);
        for (int i = 0; i < this.ntNum; i++){           // assign numbers as of ordering,
                                                        // .. but do not order ntTab
            if ((GE & this.mode) != 0){
                if ((i > 0) && (ordNt[i] == ordNt[i-1])){
                    continue;                           // epsilon one
                }
            }
            ordNt[i].ntNum = i;                         // assign them a progressive number
        }

        int firstGroup = this.ntNum;                    // first of groups
        for (ParserDic h = this.gram.ntDic.head;        // fill ntTab with internals and ..
            h != null; h = h.suc){                      // .. enumerate them
            if (((ParserNode.GRAM & h.status) == 0) ||  // non a grammar one
                ((ParserNode.INTER & h.status) == 0)){  // not a group
                continue;
            }
            h.ntNum = this.ntNum;
            this.ntTab[this.ntNum++] = h;
            if ((GE & this.mode) != 0){
                if ((ParserNode.EM & h.status) != 0){
                    if ((ParserNode.EO & h.status) == 0){
                        this.ntTab[this.ntNum++] = h;   // for the epsilon one
                    }
                }
            }
        }
        st.ntNum = this.ntNum;                          // insert top one at the end of ntTab
        this.ntTab[this.ntNum++] = st;
        /*
        if ((GE & this.mode) != 0){
            if ((ParserNode.EM & this.gram.start_sy.status) != 0){
                if ((ParserNode.EO & this.gram.start_sy.status) == 0){
                    this.ntTab[this.ntNum++] = st;
                }
            }
        }
        */

        ParserTables tab = this.tab;                    // reference to tables object
        tab.ntNrGroups = firstGroup;                    // number of first group

        tab.numOfNts = this.ntNum;                      // number of nonterminals
        tab.ntStrings = new String[this.ntNum];         // table with their names
        tab.ntToRule = new char[this.ntNum];            // allocate other tables
        tab.ntKind = new byte[this.ntNum];

        tab.split = new byte[(this.tab.numOfNts +       // allocate flags of splitted nts
        BITSBYTE - 1) / BITSBYTE];
        tab.epsilon = new byte[(tab.numOfNts +          // allocate array of nullable nts
        BITSBYTE - 1) / BITSBYTE];
        tab.eonly = new byte[(tab.numOfNts +            // allocate array of nts that produce only the empty string
        BITSBYTE - 1) / BITSBYTE];

        // determine the relocation of rules and the size of the encoded grammar

        if ((FL_E & this.trc) != 0){
            Trc.out.printf("relocation of rules\n");
        }
        int prios = 0;                                  // number of priorities
        int loc = 1;                                    // loc counter in encoded grammar
        int ruleCounter = 0;                            // counter of rules: each
                                                        // .. alternative counts as a rule
        /*
        for (int i = 0; i < this.ntNum; i++){           // scan all nonterminals
            ParserDic h = this.ntTab[i];
            if ((ParserNode.AIN & h.status) != 0){
                Trc.out.printf("ain: %s\n",h);
            }
        }
        */

        for (int i = 0; i < this.ntNum; i++){           // scan all nonterminals
            ParserDic h = this.ntTab[i];
            if ((FL_E & this.trc) != 0){
                Trc.out.printf("nt: %s %d loc %d rule %d\n",
                    h,h.ntNum,loc,ruleCounter);
            }
            boolean Ae = false;
            if ((GE & this.mode) != 0){
                if ((i > 0) && (h == this.ntTab[i-1])){              // a split nt
                    Ae = true;
                    tab.ntStrings[h.ntNum+1] = tab.ntStrings[h.ntNum];
                    tab.ntKind[h.ntNum+1] = tab.ntKind[h.ntNum];
                    tab.split[h.ntNum >>> ParserTables.NSHIFTB] |=
                        (1 << (h.ntNum & ParserTables.MASKB));
                    tab.split[h.ntNum+1 >>> ParserTables.NSHIFTB] |=
                        (1 << (h.ntNum+1 & ParserTables.MASKB));
                    tab.epsilon[h.ntNum+1 >>> ParserTables.NSHIFTB] |=
                        (1 << (h.ntNum+1 & ParserTables.MASKB));
                    if ((FL_E & this.trc) != 0){
                        Trc.out.println("nt-split: " + h.ntNum);
                    }
                    if ((GES & this.mode) == 0){
                        tab.ntToRule[h.ntNum+1] = tab.ntToRule[h.ntNum];
                        continue;
                    }
                    tab.ntToRule[h.ntNum+1] = (char)ruleCounter;  // record nr of its first rule
                    if ((FL_E & this.trc) != 0){
                        Trc.out.printf("ntToRule i: %d %d\n",
                            h.ntNum+1,ruleCounter);
                    }
                }
                if ((i == this.ntNum-1) || (h != this.ntTab[i+1])){  // does not have a split one
                    if ((ParserNode.EO & h.status) != 0){
                        tab.epsilon[h.ntNum >>> ParserTables.NSHIFTB] |=
                            (1 << (h.ntNum & ParserTables.MASKB));
                    }
                }
            } else {
                if ((ParserNode.EO & h.status) != 0){
                    tab.eonly[h.ntNum >>> ParserTables.NSHIFTB] |=
                        (1 << (h.ntNum & ParserTables.MASKB));
                }
            }
            if (!Ae){
                if (h == st){                           // remember start location of the
                    tab.startRule = loc;                // .. starting symbol
                }
                tab.ntToRule[h.ntNum] = (char)ruleCounter;  // record nr of its first rule
                tab.ntStrings[h.ntNum] =                // record name of nonterminal
                    String.valueOf(h.code);
                tab.ntKind[h.ntNum] = h.grKind;         // store its kind
                if ((FL_E & this.trc) != 0){
                    Trc.out.printf("ntToRule i: %d %d\n",
                        h.ntNum,ruleCounter);
                }
            }

            boolean overflow = false;
            if (h.def == null) continue;                // undefined
            for (ParserNode a = h.def;                  // scan alternative
                a != null; a = a.alt){

                if ((GE & this.mode) == 0){
                    if (this.foldGroups){
                        if (tab.ntKind[h.ntNum] == ParserTables.REP){
                            if (a.alt != null) continue;    // skip first rule of {}+
                        } else if (tab.ntKind[h.ntNum] == ParserTables.REL){
                            if (a.alt == null) continue;    // skip second rule of {}(l:)
                        }
                    }
                    if ((LRGROUPS & this.mode) != 0){
                        if ((tab.ntKind[h.ntNum] == ParserTables.REP) ||
                            (tab.ntKind[h.ntNum] == ParserTables.REL)){
                            if (a.alt == null) continue;    // skip second rule of {}+ and {}(l:)
                        }
                    }
                }
                boolean erule = true;
                if ((GES & this.mode) != 0){                // determine if the rule applies to this nt
                    // determine if rule produces the empty string
                    boolean eorule = true;
                    for (ParserNode s = a; s != null; s = s.suc){
                        if (s.kind == ParserNode.S_TER){        // terminal
                            if (s.def == this.gram.dic_emp){
                                continue;                       // skip empty
                            }
                            eorule = false;
                            erule = false;
                            break;
                        }
                        ParserDic d = s.def;
                        if (d == null) continue;
                        if ((ParserNode.EO & d.status) == 0){
                            eorule = false;
                        }
                        if ((ParserNode.EM & d.status) == 0){
                            erule = false;
                            break;
                        }
                    }
                    // a rule that produces only the empty string is good for Ae only
                    if (i < this.ntNum-1){
                        if (h == this.ntTab[i+1]){      // has a split one, and is A
                            if (eorule) continue;
                        }
                    }
                    if (i > 0){
                        if (h == this.ntTab[i-1]){      // has a split one, and is Ae
                            if (!erule) continue;
                        }
                    }
                }

                if ((FL_E & this.trc) != 0){
                    Trc.out.printf("placing rule at: %d\n",loc);
                }
                ruleCounter++;
                if ((FL_E & this.trc) != 0){
                    Trc.out.printf("new ruleCounter: %d\n",ruleCounter);
                }
                int startloc = loc;
                int rlen = 0;                           // determine rule length
                int epsilon = 0;
                for (ParserNode s = a; s != null; s = s.suc){
                    if (s.prio > 0) prios++;
                    if ((s.kind == ParserNode.S_TER) &&
                        (s.def == this.gram.dic_emp)){
                        continue;                       // skip empty
                    }
                    rlen++;                             // compute length of rule
                    if (rlen < 0) overflow = true;
                    if ((GE & this.mode) != 0){
                        ParserDic d = s.def;
                        if (d == null) continue;
                        if ((ParserNode.EM & d.status) != 0){
                            if ((ParserNode.EO & d.status) == 0){
                                epsilon++;
                            }
                        }
                    }
                }
                if ((GE & this.mode) == 0){
                    if (this.foldGroups){
                        if ((tab.ntKind[h.ntNum] == ParserTables.REL)){
                            rlen++;                     // one term more
                            if (rlen < 0) overflow = true;
                            // applies only to the first rule, the second is skipped
                        }
                    }
                    if ((LRGROUPS & this.mode) != 0){
                        if (tab.ntKind[h.ntNum] == ParserTables.RES){
                            if (rlen > 0){              // second rule
                                rlen--;                 // one term less
                            }
                        }
                    }
                }
                rlen++;                                 // gramRule
                if (rlen < 0) overflow = true;
                if (rlen > Character.MAX_VALUE){        // overflow check
                    overflow = true;
                }
                loc += rlen;
                if ((loc & 0xc0000000) != 0) overflow = true;
                comb: if ((GE & this.mode) != 0){
                    if ((FL_E & this.trc) != 0){
                        Trc.out.printf("prepass epsilon: %s epsilon %d %b %s rlen %d\n",
                            h,epsilon,erule,a,rlen);
                    }
                    int nr = 1 << epsilon;
                    if ((GES & this.mode) != 0){
                        if (i > 0 && h == this.ntTab[i-1]){   // has a split one, and is Ae
                            break comb;
                        }
                        if (epsilon == 0) break comb;
                        if (erule) nr--;                      // last rule has all Ae's
                        if (nr == 1) break comb;
                    }
                    if (epsilon >= 31) overflow = true;
                    long extra = rlen * (nr - 1);
                    if (extra > Integer.MAX_VALUE) overflow = true;
                    if ((FL_E & this.trc) != 0){
                        Trc.out.printf("prepass extra %d %d\n",extra,nr);
                        Trc.out.printf("placing comb rules at: %d\n",loc);
                    }
                    loc += (int)extra;
                    if ((loc & 0xc0000000) != 0) overflow = true;
                    if ((GES & this.mode) != 0){              // count all rules
                        ruleCounter += nr - 1;
                        if ((FL_E & this.trc) != 0){
                            Trc.out.printf("new ruleCounter comb: %d\n",ruleCounter);
                        }
                    }
                }
            }
            if (overflow){
                this.lex.message(ParserLexer.ERR_EXCPRS,
                    null,h.point);
                throw this.lex.excObj;
            }
        }
        if ((FL_E & this.trc) != 0){
            Trc.out.println("prepass loc: " + loc);
            Trc.out.println("ruleCounter: " + ruleCounter);
            Trc.out.println("ntNum: " + this.ntNum);
        }
        if (tab.numOfToks + loc < 0){                   // overflow in token codes
            this.lex.message(ParserLexer.ERR_EXCPRS,
                null,ParserLexer.MSG_AT_EOF);
            throw this.lex.excObj;
        }

        tab.grammar = new char[loc];                    // allocate grammar
        this.directors =                                // allocate directors
            new byte[ruleCounter][];
        tab.ruleToNt = new char[ruleCounter];           // map of nonterminal nrs
        tab.ruleIndex = new int[ruleCounter];           // allocate index of rules
        tab.ruleLen = new char[ruleCounter];            // rule lengths
        tab.numOfRules = ruleCounter - 1;               // number of rules
        tab.numOfSyms = tab.numOfToks + tab.ntNrGroups;
        tab.priLocs = new int[prios];                   // priorities
        tab.priVals = new int[prios];
        for (ParserDic h = this.gram.ntDic.head;        // compute attributes
            h != null; h = h.suc){
            if (h.def == null) continue;                // no definition
            if ((ParserNode.CYC & h.status) != 0){      // cyclic
                tab.attr |= ParserTables.CYC;
            }
        }

        return st;
    }

    /** The table of the grammar nonterminals. Needed to visit them in definition ordering. */
    ParserDic[] ntTab;

    /** The empty director. */
    private byte[] emptyDirSet;

    /**
     * Build the prediction tables. The first, follow, director, directorNt
     * are built to be always not null, but are meant to be constant, i.e.
     * not to be changed after they have been built.
     */

    /* The directors tell what lexemes could be found if a rule is applied.
     * Formally, for <A> ::= rule, its director is FIRST(rule FOLLOW(A)).
     * Since each alternative is effectively a rule, the director sets
     * are attached to alternatives.
     * They are computed as described in the Dragon Book with the exception
     * that FIRST does not contain the empty string, (except for nts that
     * generate only the empty string) which was inserted in FIRST in the
     * Dragon Book only to simplify the definition of FOLLOW and of the
     * directors not having another means to remember the nonterminals which
     * generate the empty string. Since here the attribute EM tells it, there
     * is no need to have it in these relations, which contain only the terminals
     * that can start or follow.
     * Note that, formally speaking, a set of terminals cannot contain the
     * empty string, which is not a terminal, but a string.
     * Note, however, that there is also a relation FIRST_k(X), which is the
     * set of the strings |s| <= k that are the prefixes of X. With k = 1
     * we have the set of terminals or the empty string that can begin X.
     * FOLLOW does not have this problem since it does not have the empty
     * string in it also in the Dragon Book.
     */

    private void predictTables(){
        if ((FL_E & this.trc) != 0){
            Trc.out.println("predictTables");
        }
        /*
        if ((GE & this.mode) != 0){
            if ((GES & this.mode) == 0){
                return;
            }
        }
        */

        emptyDirSet = allocTermSet();
        byte[][] ntMatrix = boolMtxAlloc(this.ntNum);

        this.first = doFirst(ntMatrix);              // compute FIRST
        byte[][] first = this.first;

        boolMtxClear(ntMatrix);
        this.follow = doFollow(ntMatrix,first);      // compute FOLLOW

        if ((FL_E & this.trc) != 0){
            Trc.out.println("DIRECTOR");
        }

        // compute DIRECTOR

        this.directorsNt = new byte[this.ntNum][];   // allocate the nt's ones
        int ruleCounter = 0;
        for (int i = 0; i < this.ntNum; i++){        // scan all nonterminals
            ParserDic h = this.ntTab[i];
            int num = h.ntNum;
            if ((GE & this.mode) != 0){
                if ((i > 0) && (h == this.ntTab[i-1])){   // the split nt
                    continue;
                }
            }
            if (h.def == null) continue;             // undefined

            this.directorsNt[num] = allocTermSet();
            termSetUnion(this.directorsNt[num],
                this.first[num]);
            if ((ParserNode.EM & h.status) != 0){    // generates the empty
                termSetUnion(this.directorsNt[num],
                    this.follow[num]);
            }

            // compute then the director for each rule (i.e. alternative)
            for (ParserNode a = h.def;               // scan all alternatives
                a != null; a = a.alt){
                if ((FL_E & this.trc) != 0){
                    Trc.out.println(h + " ::= " +
                        a.toString(ParserNode.REP_ALT |
                        ParserNode.EXP_GRO));
                }
                if ((GE & this.mode) == 0){
                    if (this.foldGroups){
                        if (tab.ntKind[num] == ParserTables.REP){
                            if (a.alt != null) continue;    // skip first rule of {}+
                        } else if (tab.ntKind[num] == ParserTables.REL){
                            if (a.alt == null) continue;    // skip second rule of {}(l:)
                        }
                    }
                    if ((LRGROUPS & this.mode) != 0){
                        if ((tab.ntKind[num] == ParserTables.REP) ||
                            (tab.ntKind[num] == ParserTables.REL)){
                            if (a.alt == null) continue;    // skip second rule of {}+ and {}(l:)
                        }
                    }
                }
                byte[] director = null;
                ParserNode s = a;
                scan: for (; s != null; s = s.suc){  // scan all successors
                    switch (s.kind){
                    case ParserNode.S_TER:           // a terminal
                        if (s.def == this.gram.dic_emp){
                            break;
                        }
                        if (director == null){
                            director = allocTermSet();
                        }
                        termSetUnion(director,       // starts with itself
                            s.def.tokNum);
                        break scan;
                    default:
                        if ((ParserNode.LEXEME &     // a lexeme
                            s.def.status) != 0){
                            if (director == null){
                                director = allocTermSet();
                            }
                            termSetUnion(director,   // starts with itself
                                s.def.tokNum);
                            break scan;
                        }
                        ParserDic hh = s.def;
                        if (hh != null){
                            if (director == null){
                                director = allocTermSet();
                            }
                            termSetUnion(director,   // starts with the first
                                first[hh.ntNum]);    // .. of hh
                        }
                        if ((ParserNode.EM &         // stop at the first
                            hh.status) == 0){        // which is not transparent
                            break scan;
                        }
                        break;
                    }
                }
                if (s == null){                      // alternative which
                    if (director == null){           // .. produces empty
                        director = allocTermSet();
                    }
                    termSetUnion(director,           // starts with what
                        this.follow[num]);           // .. follows
                }
                if ((FL_E & this.trc) != 0){
                    Trc.out.println(termSetToStr(director));
                }
                this.directors[ruleCounter++] = director;
            }
        }
        for (int i = 0; i < this.directors.length; i++){
            if (this.directors[i] == null){          // create always one
                this.directors[i] = emptyDirSet;
            }
        }
    }

    /** 
     * Build the relation FIRST. Determine for each nonterminal the set of
     * tokens made by the first token of all the strings generated by it.
     * To compute it, a matrix is used to remember the nonterminals that
     * are generated as first symbols, so that a closure can be made to
     * compute the tokens that they can transitively generate.
     *
     * @param      ntMatrix reference to the temporary matrix of nonterminals
     * @return     reference to the array of the FIRST sets
     */

    private byte[][] doFirst(byte[][] ntMatrix){
        if ((FL_E & this.trc) != 0){
            Trc.out.println("FIRST");
        }
        byte[][] first = new byte[this.ntNum][];
        for (int i = 0; i < this.ntNum; i++){        // scan all nonterminals
            ParserDic h = this.ntTab[i];
            if ((GE & this.mode) != 0){
                if ((i > 0) && (h == this.ntTab[i-1])){
                    continue;                        // Ae
                }
            }
            if (h.def == null) continue;             // undefined
            for (ParserNode a = h.def; a != null;    // scan all alternatives
                a = a.alt){
                if ((FL_E & this.trc) != 0){
                    Trc.out.println(h + " ::= " +
                        a.toString(ParserNode.REP_ALT |
                        ParserNode.EXP_GRO));
                }
                scan: for (ParserNode s = a;         // scan all successors
                    s != null; s = s.suc){
                    switch (s.kind){
                    case ParserNode.S_TER:           // a terminal
                        if (s.def == this.gram.dic_emp){
                            break;
                        }
                        if (first[h.ntNum] == null){
                            first[h.ntNum] = allocTermSet();
                        }
                        termSetUnion(first[h.ntNum], // h starts also with it
                            s.def.tokNum);
                        break scan;
                    default:
                        if ((ParserNode.LEXEME &     // a lexeme
                            s.def.status) != 0){
                            if (first[h.ntNum] == null){
                                first[h.ntNum] = allocTermSet();
                            }
                            termSetUnion(            // h starts also with it
                                first[h.ntNum],s.def.tokNum);
                            break scan;
                        }
                        ParserDic hh = s.def;
                        if (hh != null){
                            boolMtxSet(ntMatrix,h.ntNum,hh.ntNum);
                        }
                        if ((ParserNode.EM &         // stop at the first ..
                            hh.status) == 0){        // .. not transparent one
                            break scan;
                        }
                        break;
                    }
                }
            }
        }
        boolMtxClosure(ntMatrix);                    // perform closure
        for (int i = 0; i < this.ntNum; i++){        // scan all nonterminals
            ParserDic h = this.ntTab[i];             // .. and synthetize FIRST
            if ((GE & this.mode) != 0){
                if ((i > 0) && (h == this.ntTab[i-1])){
                    continue;
                }
            }
            for (int j = 0; j < this.ntNum; j++){
                ParserDic k = this.ntTab[j];
                if ((GE & this.mode) != 0){
                    if ((j > 0) && (k == this.ntTab[j-1])){
                        continue;
                    }
                }
                if (!boolMtxIn(ntMatrix,             // k does not occur as FIRST
                    h.ntNum,k.ntNum)){               // in some alternatives of h
                    continue;
                }
                if (first[h.ntNum] == null){
                    first[h.ntNum] = allocTermSet();
                }
                termSetUnion(first[h.ntNum],         // add all k's FIRST to h's
                    first[k.ntNum]);
            }
        }
        for (int i = 0; i < first.length; i++){
            if (first[i] == null){                   // create always one
                first[i] = emptyDirSet;
            }
        }
        if ((FL_E & this.trc) != 0){
            for (int i = 0; i < this.ntNum; i++){
                ParserDic h = this.ntTab[i];
                Trc.out.println(h + ": " +
                    termSetToStr(first[h.ntNum]));
            }
        }

        this.tab.firsts = new BitSet[this.ntNum];
        for (int i = 0; i < first.length; i++){
            this.tab.firsts[i] = new BitSet(this.tab.numOfToks+1);
            for (int j = 0; j < this.tab.numOfToks+1; j++){
                if (termSetIn(first[i],j)){
                    this.tab.firsts[i].set(j);
                }
            }
        }

        return first;
    }

    /** 
     * Build the relation FIRST, but using the encoded grammar.
     * This serves for the GES case, but can serve also for all the other cases
     * in which the encoded grammar is different from the original one.
     *
     * @return     reference to the array of the FIRST sets
     */

    byte[][] doFirstEnc(){
        if ((FL_E & this.trc) != 0){
            Trc.out.println("FIRST encoded");
        }
        byte[][] ntMatrix = boolMtxAlloc(this.ntNum);
        byte[][] first = new byte[this.ntNum][];
        ParserTables tab = this.tab;

        if ((FL_E & this.trc) != 0){
            Trc.out.printf("ntToRule");
            for (int i = 0; i < tab.ntToRule.length; i++){
                Trc.out.printf(" %d",(int)tab.ntToRule[i]);
            }
            Trc.out.printf("\n");
            Trc.out.printf("ruleToNt");
            for (int i = 0; i < tab.ruleToNt.length; i++){
                Trc.out.printf(" %d",(int)tab.ruleToNt[i]);
            }
            Trc.out.printf("\n");
            Trc.out.printf("strings %s\n",Arrays.toString(tab.ntStrings));
        }
        for (int i = 0; i < tab.ntToRule.length; i++){   // scan all nonterminals
            for (int rulenr = tab.ntToRule[i];           // visit all its rules
                (rulenr < tab.ruleToNt.length) &&
                (tab.ruleToNt[rulenr] == i); rulenr++){
                if ((FL_E & this.trc) != 0){
                    Trc.out.printf("%s\n",tab.ruleToString(tab.ruleIndex[rulenr],false));
                }
                for (int p = tab.ruleIndex[rulenr]; tab.grammar[p] < tab.ruleBase; p++){  // visit rule
                    int v = tab.grammar[p];
                    if (v >= tab.tokBase){               // terminal
                        if (first[i] == null){
                            first[i] = allocTermSet();
                        }
                        termSetUnion(first[i],           // h starts also with it
                            v-tab.tokBase);
                        break;
                    }
                    // nonterminal
                    boolMtxSet(ntMatrix,i,v);
                    if ((tab.nullable[v>>>ParserTables.NSHIFTB] &
                        (1 << (v & ParserTables.MASKB))) == 0){  // not a nullable nt: stop at the first ..
                        break;                           // .. not transparent one
                    }
                }
            }
        }
        boolMtxClosure(ntMatrix);                        // perform closure
        for (int i = 0; i < tab.ntToRule.length; i++){   // scan all nonterminals and synthetize FIRST
            for (int j = 0; j < tab.ntToRule.length; j++){
                if (!boolMtxIn(ntMatrix,                 // j does not occur as FIRST
                    i,j)){                               // in some alternatives of i
                    continue;
                }
                if (first[i] == null){
                    first[i] = allocTermSet();
                }
                termSetUnion(first[i],               // add all k's FIRST to h's
                    first[j]);
            }
        }
        for (int i = 0; i < first.length; i++){
            if (first[i] == null){                   // create always one
                first[i] = emptyDirSet;
            }
        }
        if ((FL_E & this.trc) != 0){
            for (int i = 0; i < tab.ntToRule.length; i++){
                Trc.out.printf("%s: %s\n",tab.gramSymToString(i),termSetToStr(first[i]));
            }
        }

        BitSet[] firsts = new BitSet[this.ntNum];
        for (int i = 0; i < first.length; i++){
            firsts[i] = new BitSet(this.tab.numOfToks+1);
            for (int j = 0; j < this.tab.numOfToks+1; j++){
                if (termSetIn(first[i],j)){
                    firsts[i].set(j);
                }
            }
            /*
            if ((GE & this.mode) == 0){
                if (!firsts[i].equals(tab.firsts[i])){
                    Trc.out.printf("first diff nt: %s %s %s\n",
                        tab.ntLitName(i),tokSetToString(firsts[i]),tokSetToString(tab.firsts[i]));
                }
            }
            */
        }
        this.tab.firsts = firsts;
        return first;
    }
    private String tokSetToString(BitSet s){
        String res = "";
        int len = s.length();
        for (int i = 0; i < len; i++){
            if (!s.get(i)) continue;
            if (res.length() > 0) res += " ";
            res += this.tab.tokLitName(i);
        }
        return "{" + res + "}";
    }

    /** 
     * Build the relation FOLLOW. Determine for each nonterminal the set of
     * tokens made by the first token of all the strings that can follow
     * all the occurrences of it.
     * To compute it, a matrix is used to remember the nonterminals that
     * a rule generates as last symbols, so that a closure can be made to
     * propagate onto them the terminal that can follow the rule.
     *
     * @param      ntMatrix reference to the temporary matrix of nonterminals
     * @param      first reference to the array of FIRST sets
     * @return     reference to the array of the FOLLOW sets
     */

    private byte[][] doFollow(byte[][] ntMatrix, byte[][] first){
        if ((FL_E & this.trc) != 0){
            Trc.out.println("FOLLOW");
        }
        byte[][] follow = new byte[this.ntNum][];
        for (int i = 0; i < this.ntNum; i++){        // scan all nonterminals
            ParserDic h = this.ntTab[i];
            if ((GE & this.mode) != 0){
                if ((i > 0) && (h == this.ntTab[i-1])){
                    continue;
                }
            }
            if (h.def == null) continue;             // undefined
            for (ParserNode a = h.def;               // scan all alternatives
                a != null; a = a.alt){
                if ((FL_E & this.trc) != 0){
                    Trc.out.println(h + " ::= " +
                        a.toString(ParserNode.REP_ALT |
                        ParserNode.EXP_GRO));
                }
                for (ParserNode p = a;               // scan all successors
                    p != null; p = p.suc){
                    if (p.kind == ParserNode.S_TER){ // a terminal
                        continue;
                    }
                    if ((ParserNode.LEXEME &         // a lexeme
                        p.def.status) != 0){
                        continue;
                    }
                    ParserDic k = p.def;
                    ParserNode s = p.suc;
                    scan: for (; s != null; s = s.suc){   // scan all successors
                        switch (s.kind){
                        case ParserNode.S_TER:            // a terminal
                            if (s.def == this.gram.dic_emp){
                                break;
                            }
                            if (follow[k.ntNum] == null){
                                follow[k.ntNum] = allocTermSet();
                            }
                            if ((FL_E & this.trc) != 0){
                                Trc.out.println(k + " -> " + s);
                            }
                            termSetUnion(follow[k.ntNum], // k followed by it
                                s.def.tokNum);
                            break scan;
                        default:
                            if ((ParserNode.LEXEME &      // a lexeme
                                s.def.status) != 0){
                                if (follow[k.ntNum] == null){
                                    follow[k.ntNum] = allocTermSet();
                                }
                                if ((FL_E & this.trc) != 0){
                                    Trc.out.println(k + " -> " + s);
                                }
                                termSetUnion(             // k followed by it
                                    follow[k.ntNum],s.def.tokNum);
                                break scan;
                            }
                            ParserDic hh = s.def;
                            if (hh != null){
                                if (follow[k.ntNum] == null){
                                    follow[k.ntNum] = allocTermSet();
                                }
                                if ((FL_E & this.trc) != 0){
                                    Trc.out.println(k + " -> " +
                                        termSetToStr(first[hh.ntNum]));
                                }
                                termSetUnion(             // k followed by
                                    follow[k.ntNum],      // .. the FIRSTs of hh
                                    first[hh.ntNum]);
                            }
                            if ((ParserNode.EM &          // stop at the first
                                hh.status) == 0){         // .. not transparent
                                break scan;
                            }
                            break;
                        }
                    }
                    if (s == null){                       // all successors of k EM
                        boolMtxSet(ntMatrix,              // add to FOLLOW h
                           h.ntNum,k.ntNum);
                    }
                }
            }
        }
        boolMtxClosure(ntMatrix);                    // perform closure
        for (int i = 0; i < this.ntNum; i++){        // scan all nonterminals
            ParserDic h = this.ntTab[i];             // .. and synthetize FOLLOW
            if ((GE & this.mode) != 0){
                if ((i > 0) && (h == this.ntTab[i-1])){
                    continue;
                }
            }
            for (int j = 0; j < this.ntNum; j++){
                ParserDic k = this.ntTab[j];
                if ((GE & this.mode) != 0){
                    if ((j > 0) && (k == this.ntTab[j-1])){
                        continue;
                    }
                }
                if (!boolMtxIn(ntMatrix,             // k does not occur as FOLLOW
                    h.ntNum,k.ntNum)){               // in some alternatives of h
                    continue;
                }
                if (follow[k.ntNum] == null){
                    follow[k.ntNum] = allocTermSet();
                }
                termSetUnion(follow[k.ntNum],        // add all h's FOLLOW to k's
                    follow[h.ntNum]);
            }
        }
        if (follow[this.ntNum-1] == null){           // put EOF in FOLLOW of enclosing start
            follow[this.ntNum-1] = allocTermSet();
        }
        termSetUnion(follow[this.ntNum-1],tab.numOfToks);
        for (int i = 0; i < follow.length; i++){
            if (follow[i] == null){                  // create always one
                follow[i] = emptyDirSet;
            }
        }

        if ((FL_E & this.trc) != 0){
            for (int i = 0; i < this.ntNum; i++){
                ParserDic h = this.ntTab[i];
                Trc.out.println(h + ": " +
                    termSetToStr(follow[h.ntNum]));
            }
        }
        return follow;
    }

    /** 
     * Build the relation FOLLOW, but using the encoded grammar.
     * This serves for the GES case, but can serve also for all the other cases
     * in which the encoded grammar is different from the original one.
     *
     * @param      first reference to the array of FIRST sets
     * @return     reference to the array of the FOLLOW sets
     */

    private byte[][] doFollowEnc(byte[][] first){
        if ((FL_E & this.trc) != 0){
            Trc.out.println("FOLLOW encoded");
        }
        byte[][] ntMatrix = boolMtxAlloc(this.ntNum);
        byte[][] follow = new byte[this.ntNum][];
        ParserTables tab = this.tab;

        for (int i = 0; i < tab.ntToRule.length; i++){   // scan all nonterminals
            for (int rulenr = tab.ntToRule[i];           // visit all its rules
                (rulenr < tab.ruleToNt.length) &&
                (tab.ruleToNt[rulenr] == i); rulenr++){
                if ((FL_E & this.trc) != 0){
                    Trc.out.printf("%s\n",tab.ruleToString(tab.ruleIndex[rulenr],false));
                }
                for (int p = tab.ruleIndex[rulenr]; tab.grammar[p] < tab.ruleBase; p++){  // visit rule
                    int v = tab.grammar[p];
                    if (v >= tab.tokBase){               // terminal
                        continue;
                    }
                    // nonterminal
                    int s = p + 1;
                    scan: for (; tab.grammar[s] < tab.ruleBase; s++){   // scan all successors
                        int gs = tab.grammar[s];
                        if (gs >= tab.tokBase){                         // terminal
                            if (follow[v] == null){
                                follow[v] = allocTermSet();
                            }
                            if ((FL_E & this.trc) != 0){
                                Trc.out.printf("%s -> %s\n",
                                    tab.gramSymToString(v),tab.gramSymToString(gs));
                            }
                            termSetUnion(follow[v],      // v followed by it
                                gs - tab.tokBase);
                            break scan;
                        } else {
                            if (follow[v] == null){
                                follow[v] = allocTermSet();
                            }
                            if ((FL_E & this.trc) != 0){
                                Trc.out.printf("%s -> %s\n",
                                    tab.gramSymToString(v),termSetToStr(first[gs]));
                            }
                            termSetUnion(                // v followed by
                                follow[v],               // .. the FIRSTs of gs
                                first[gs]);
                            if ((tab.nullable[gs>>>ParserTables.NSHIFTB] &
                                (1 << (gs & ParserTables.MASKB))) == 0){  // not a nullable nt: stop at the first ..
                                break scan;                               // .. not transparent one
                            }
                        }
                    }
                    if (tab.grammar[s] >= tab.ruleBase){  // all successors of gs EM
                        boolMtxSet(ntMatrix,              // add to FOLLOW i
                           i,v);
                    }
                }
            }
        }

        boolMtxClosure(ntMatrix);                        // perform closure
        for (int i = 0; i < tab.ntToRule.length; i++){   // scan all nonterminals and synthetize FOLLOW
            for (int j = 0; j < tab.ntToRule.length; j++){
                if (!boolMtxIn(ntMatrix,                 // j does not occur as FOLLOW
                    i,j)){                               // in some alternatives of i
                    continue;
                }
                if (follow[j] == null){
                    follow[j] = allocTermSet();
                }
                termSetUnion(follow[j],follow[i]);       // add all i's FOLLOW to j's
            }
        }
        if (follow[this.ntNum-1] == null){           // put EOF in FOLLOW of enclosing start
            follow[this.ntNum-1] = allocTermSet();
        }
        termSetUnion(follow[this.ntNum-1],tab.numOfToks);
        for (int i = 0; i < follow.length; i++){
            if (follow[i] == null){                  // create always one
                follow[i] = emptyDirSet;
            }
        }

        if ((FL_E & this.trc) != 0){
            for (int i = 0; i < tab.ntToRule.length; i++){
                Trc.out.printf("%s: %s\n",
                    tab.gramSymToString(i),termSetToStr(follow[i]));
            }
        }
        return follow;
    }

    /**
     * Build the prediction tables using the encoded grammar.
     */

    private void predictTablesEnc(){
        if ((FL_E & this.trc) != 0){
            Trc.out.println("predictTablesEnc");
        }

        this.first = doFirstEnc();              // compute FIRST
        byte[][] first = this.first;

        this.follow = doFollowEnc(first);       // compute FOLLOW

        if ((FL_E & this.trc) != 0){
            Trc.out.println("DIRECTOR");
        }

        // compute DIRECTOR

        if ((FL_E & this.trc) != 0){
            Trc.out.printf("computing directors\n");
        }
        this.directorsNt = new byte[this.ntNum][];      // allocate the nt's ones
        int ruleCounter = 0;
        for (int i = 0; i < tab.ntToRule.length; i++){  // scan all nonterminals
            if ((FL_E & this.trc) != 0){
                Trc.out.printf("nt: %s\n",tab.gramSymToString(i));
            }
            this.directorsNt[i] = allocTermSet();
            termSetUnion(this.directorsNt[i],
                this.first[i]);

            if ((tab.nullable[i>>>ParserTables.NSHIFTB] &
                (1 << (i & ParserTables.MASKB))) != 0){  // generates the empty
                termSetUnion(this.directorsNt[i],
                    this.follow[i]);
            }

            // compute then the director for each rule
            for (int rulenr = tab.ntToRule[i];           // visit all its rules
                (rulenr < tab.ruleToNt.length) &&
                (tab.ruleToNt[rulenr] == i); rulenr++){
                if ((FL_E & this.trc) != 0){
                    Trc.out.printf("%s\n",
                        tab.ruleToString(tab.ruleIndex[rulenr],false));
                }
                byte[] director = null;
                int s = tab.ruleIndex[rulenr];
                scan: for (; tab.grammar[s] < tab.ruleBase; s++){  // visit rule
                    int gs = tab.grammar[s];
                    if (gs >= tab.tokBase){          // terminal
                        if (director == null){
                            director = allocTermSet();
                        }
                        termSetUnion(director,       // starts with itself
                            gs - tab.tokBase);
                        break scan;
                    } else {                         // nonterminal
                        if (director == null){
                            director = allocTermSet();
                        }
                        termSetUnion(director,       // starts with the first
                            first[gs]);              // .. of v
                        if ((tab.nullable[gs>>>ParserTables.NSHIFTB] &
                            (1 << (gs & ParserTables.MASKB))) == 0){  // not a nullable nt: stop at the first ..
                            break scan;                               // .. not transparent one
                        }
                    }
                }
                if (tab.grammar[s] >= tab.ruleBase){  // alternative which
                    if (director == null){            // .. produces empty
                        director = allocTermSet();
                    }
                    termSetUnion(director,            // starts with what
                        this.follow[i]);              // .. follows
                }
                if ((FL_E & this.trc) != 0){
                    Trc.out.println(termSetToStr(director));
                }
                this.directors[rulenr] = director;
            }
        }
        for (int i = 0; i < this.directors.length; i++){
            if (this.directors[i] == null){          // create always one
                this.directors[i] = emptyDirSet;
            }
        }
    }


    /** The number of bits per byte */
    private static final int BITSBYTE = 8;

    /**
     * Allocate a bit set.
     */

    private byte[] allocTermSet(){
        return new byte[(this.tab.numOfToks + 1 + BITSBYTE - 1) / BITSBYTE];
    }

    /**
     * Add the specified element to the specified set.
     *
     * @param      set bit set
     * @param      el element
     */

    private void termSetUnion(byte[] set, int el){
        set[el >>> ParserTables.NSHIFTB] |=
            (1 << (el & ParserTables.MASKB));
    }

    /**
     * Add the elements of a set to another.
     *
     * @param      set destination set to add to
     * @param      s sorce set
     */

    private void termSetUnion(byte[] set, byte[] s){
        if (s == null) return;
        for (int i = 0; i < set.length; i++){
            set[i] |= s[i];
        }
    }

    /**
     * Test if an element belongs to a set.
     *
     * @param      set set
     * @param      el element
     */

    private boolean termSetIn(byte[] set, int el){
        if (set == null) return false;
        return (set[el >>> ParserTables.NSHIFTB] &
            (1 << (el & ParserTables.MASKB))) != 0;
    }

    /**
     * Deliver a string that represents a set of terminals.
     *
     * @param      set set
     * @return     string
     */

    Str termSetToStr(byte[] set){
        Str s = new Str("{");
        boolean first = true;
        if (set != null){
            for (int i = 0; i <= this.tab.numOfToks; i++){
                if ((set[i >>> 3] & (1 << (i & 0x7))) != 0){
                    if (!first) s.append(", ");
                    first = false;
                    s.append(this.tab.tokLitName(i));
                }
            }
        }
        s.append("}");
        return s;
    }

    /**
     * Deliver a string that represents a boolean matrix.
     *
     * @param      mat matrix
     * @return     string
     */

    private String boolMtxToStr(byte[][] mat){
        StringBuffer s = new StringBuffer();
        boolean first = true;
        if (mat != null){
            for (int i = 0; i < mat.length; i++){      // visit rows
                for (int j = 0; j < mat.length; j++){  // visit columns
                    if ((mat[i][j >>> ParserTables.NSHIFTB] &   // element true
                        (1 << (j & ParserTables.MASKB))) != 0){
                        if (!first) s.append(", ");
                        first = false;
                        s.append("(" + Integer.toString(i) + "," +
                            Integer.toString(j) + ")");
                    }
                }
            }
        }
        return s.toString();
    }

    /**
     * Create a boolean square matrix. The matrix is represented as an
     * array of <code>m</code> references to byte[] arrays containing
     * the rows.
     *
     * @param      m height and width of the matrix
     * @return     matrix
     */

    private byte[][] boolMtxAlloc(int m){
        byte[][] mat = new byte[m][];
        int width = (m + BITSBYTE - 1) / BITSBYTE;  // width of row in bytes
        for (int i = 0; i < m; i++){                // allocate rows
            mat[i] = new byte[width];
        }
        return mat;
    }

    /**
     * Set an element of a boolean matrix to <code>true</code>.
     *
     * @param      mat matrix
     * @param      x row number of the element
     * @param      y column number of the element
     */

    private void boolMtxSet(byte[][] mat, int x, int y){
        mat[x][y >>> ParserTables.NSHIFTB] |=
            (1 << (y & ParserTables.MASKB));
    }

    /**
     * Test if an element of a boolean matrix is <code>true</code>.
     *
     * @param      mat matrix
     * @param      x row number of the element
     * @param      y column number of the element
     */

    private boolean boolMtxIn(byte[][] mat, int x, int y){
        return (mat[x][y >>> ParserTables.NSHIFTB] &
            (1 << (y & ParserTables.MASKB))) != 0;
    }

    /**
     * Empty a boolean matrix.
     *
     * @param      mat matrix
     */

    private void boolMtxClear(byte[][] mat){
        for (int i = 0; i < mat.length; i++){
            for (int j = 0; j < mat[i].length; j++){
                mat[i][j] = 0;
            }
        }
    }

    /**
     * Perform the transitive and reflexive closure on a boolean matrix.
     *
     * @param      mat matrix
     */

    private void boolMtxClosure(byte[][] mat){
        int nrel = mat.length;                    // height and width
        if (nrel == 0) return;
        /*
        int len = mat[0].length;                  // width in bytes of rows
        byte[] prev = new byte[len];
        boolean change;
        do {
            change = false;                       // no changes yet
            for (int i = 0; i < nrel; i++){
                byte[] m = mat[i];
                for (int k = 0; k < len; k++){    // save row
                    prev[k] = m[k];
                }
                for (int j = 0; j < nrel; j++){
                    if ((m[j >>> ParserTables.NSHIFTB] &  // mat[i,j] true
                        (1 << (j & ParserTables.MASKB))) != 0){
                        byte[] q = mat[j];
                        for (int k = 0; k < len; k++){
                            m[k] |= q[k];         // add to mat[i] mat[j]
                        }
                    }
                }
                for (int k = 0; k < len; k++){    // compare
                    if (prev[k] != m[k]){
                        change = true;            // something changed
                        break;
                    }
                }
            }
        } while (change);
        */
        // Warshall
        int l = mat[0].length;
        for (int j = 0; j < nrel; j++){
            for (int i = 0; i < nrel; i++){
                byte[] mi = mat[i];
                if ((mi[j >>> ParserTables.NSHIFTB] &  // mat[i,j] true
                    (1 << (j & ParserTables.MASKB))) != 0){
                    byte[] mj = mat[j];
                    // perform byte-by-byte or'ing
                    for (int k = 0; k < l; k++){
                        mi[k] |= mj[k];
                    }
                }
            }
        }
        for (int i = 0; i < nrel; i++){  // set all elements in diagonal
            mat[i][i >>> ParserTables.NSHIFTB] |=
                (1 << (i & ParserTables.MASKB));
        }
    }

    /* Encoding the grammar
     *
     * The source grammar is represented by a number of arrays:
     *
     *      grammar 
     *    -----------
     *    |  ....   |                            ntToRule     ruleToNt
     *    |---------|                           ----------    --------
     *    |  ntNr ---*------------------------->| ruleNr |-*->| ntNr |
     *    |---------| \     singmap             | ruleNr | |  | ntNr |
     *    | ......  |  \   ---------                       |  | .... |
     *    |---------|   `->| ntNr  |                       |  |------|
     *    |  rule   |                    ruleIndex         |
     *    |  ....   |                    ---------         |  ruleLen
     *    |---------|                  .-| index |<--------*  --------
     *    |  rule   |<----------------'                    `->| len  |
     *    |  rule   | rules of a same nt
     *
     * The grammar is represented as an array of encoded rules.
     * This allows to represent the dot of an item by using the index in the
     * grammar array.
     * The maximum size of a grammar is 2**30-1, which allows to represent
     * points in the grammar with 30 bits leaving two for marks, used by
     * several algorithms. In practice, this is not a restriction.
     * The rules are placed in the array one after another:
     *
     *           ruleBase
     *           rule
     *           ...
     *           rule
     *
     * The ruleBase at the beginning allows to find the beginning of the
     * first rule. Even more important, it makes the index 0 reserved.
     * Since the end of items lists is recognized by a dot which is 0,
     * this value cannot be used as index in the grammar, which would instead
     * be the case if the first rule were placed right at the beginning.
     *
     * A rule:  <A> ::= B0 B1 ... Bn | C0 C1 ... Cm | ...
     *
     * is represented as:
     *
     *            B0               nonterminal number of B0 or base + token nr
     *            ...
     *            Bn
     *            rule nr          encoded ruleNr of the first rule of A
     *            C0               next rule of A
     *            ...
     *            Cm
     *            rule nr          encoded ruleNr of the second rule of A
     *            ....             next rule of A
     *
     * A symbol which is a token is represented as tokBase + tokNr.
     * Since in the engine there is a need to tell if the values got from
     * the grammar are tokens or nonterminals, and also if the dot is
     * at the end of a rule, all these values are distinguisheable.
     * There is a need to encode tokens, nonterminals and rules together,
     * and 64K values are enough.
     * If this were a restriction, then two elements could be used, the first
     * containing ruleBase and the second the ruleNr.
     * These values are encoded as follows:
     *
     *     0             |tokBase                |ruleBase
     *     +-------------+-----------------------+--------
     *      nonterminals  tokens (including EOF)  rules
     *
     * Since symbols of rules are followed by a values >= ruleBase, it is possible
     * to determine the rule which an index in the grammar refers to.
     * Rule numbers (ruleNr) denote rules, numbered from 0 upwards in order of
     * definition in the grammar.
     *
     * A symbol Bi which is a nonterminal is represented as its nonterminal
     * number. A table indexed by nonterminal numbers contains the indexes
     * of the first rules of nonterminals.
     * There is actually another table like that, which is built by reducing
     * singletons: it contains the token or the nonterminal to which the
     * singletons reduce.
     * The rule number is the sequence number the rule has when enumerating
     * the rules in the grammar, considering each alternative of a nonterminal
     * as a rule.
     * It serves to access the director set of that rule, to get its ntNr,
     * the rule length, etc.
     *
     * An enclosing rule is added: «&n» ::= start-symbol EOF, which is the very
     * last rule in the grammar, and «&n» is a newly introduced (and last numbered)
     * nonterminal.
     *
     * The encoding of the grammar is designed so as to improve the speed
     * of the operations which are more frequent:
     *
     * - to detect that the dot is at the end. This is needed in many
     *   places in the engine. A sentinel is chosen because it allows
     *   to detect it having only the value of the dot (storing instead
     *   the length of rules in front of them would require to represent
     *   the dot as the index of the beginning of a rule plus an offset).
     *   The sentinel is a value which can be recognized not to be a
     *   nonterminal nor a token, be either some property of the rule or
     *   what is at the beginning of the next rule.
     * - to determine the ntNr (or the index of its first rule) of an item
     *   which has the dot at the end. This occurs in completer to get the
     *   number of the nonterminal to complete. 
     *   To avoid to scan back the rule, there should be something at the
     *   end. At that point there is no other information available than
     *   the dot in the grammar.
     * - to get the start index of all the rules of a nonterminal.
     *   This can be done by keeping a counter, initialised to the number
     *   of the first rule of the nonterminal, taken from ntToRule, and
     *   incremented at each iteration. The index of the rule is taken
     *   then from ruleIndex. The loop stops when ruleToNt[ruleNr] != ntNr
     *   or ruleNr >= numOfRules.
     * - to get the start index of a rule. This occurs in the predictor.
     *   It occurs also in ParserTables.getRule. It is done by using ruleIndex.
     * - to map grammar values to their singleton reduction, singmap[] maps
     *   also tokens to tokens, which spares to make a test when mapping.
     *
     * These are the methods which access the encoded grammar and what they get:
     *
     *   ParserTables
     *
     *   traceGrammar   sentinel ruleNr. To find the boundary of a rule,
     *                  seeks down the sentinel
     *   ruleToString   seeks down the sentinel ruleNr to get the ntNr and
     *                  the start of the rule
     *   nextRule       seeks down the sentinel ruleNr to locate the start
     *                  of the next rule
     *   ruleNr         steps over alternatives (of group rules) with ruleLen
     *   getRule        delivers the rule index
     *
     *   ParserEngine
     *
     *   nestAmbiguity  sentinel ruleNr to get ntNr
     *   showTree       sentinel ruleNr to get ntNr and determine altNr
     *   closure        sentinel ruleNr to get ntNr to compare against singmap.
     *                  Gets ntNr's from the grammar to make completions and
     *                  access directors
     *   predictor      accesses all rules of a same nt got from singmap with
     *                  the technique above, ruleNr to get director, index of
     *                  each rule to store in predicted items
     *   leftParse      sentinel ruleNr to get ruleNr
     *   encodeTree     sentinel ruleNr to get ntNr and also ruleNr
     *
     * To save space, the grammar is represented as a char[], and sentinels
     * with a char value. This means that the number of tokens plus that of
     * nonterminals plus that of rules is at most 64k. This is considerably
     * high for all practical cases. Consequently, ruleLen, ruleNr, ntNr
     * are < 64k and thus the tables which hold them are also represented as
     * char[].
     *
     * The places where grammar elements are accessed by knowing the
     * start index of a rule are marked in the source code of this parser as
     * "gramRule".
     *
     * It would be possible to keep one internal representation only for the
     * grammar, while here we have two (the internal form and the encoded one).
     * The encoded one is very compact one, it needs extra time to process, but
     * it is devised to keep the Earley items compact as well.
     * The internal representation of the grammar (ParserNode's and ParserDic's)
     * is easier to build and walk and to apply several algorithms on it.
     *
     * The check to reject grammar encodings which overflow is that the highest value
     * is that of EOF, which is numOfToks + tokBase.
     *
     * To test encoding, encoded grammars are decoded and the result compared
     * with the recorded, expected one
     *
     * The nonterminals which are not internal are assigned numbers according
     * to the ordering of their names. This serves to speed up the mapping from
     * nonterminal names into their numbers, which is an API method.
     * However, the grammar is encoded in the same ordering as the BNF so
     * as to make tracing easier to read.
     *
     * We store in the encoded grammar nonterminal numbers instead of
     * rule numbers because the latter require a larger array to get to
     * rule indexes, and provide no benefits.
     *
     * The placement of rule number in the grammar is not the same as in Accent
     * for some good reasons. One is that rules are scanned in reverse ordering
     * when building the parse tree, and the rule number is needed at the end of
     * the scan to be stored in derivations.
     *
     * In the encoded grammar the number of rules numOfRules does not take into account the
     * enclosing rule. This is actually correct because they are the rules present in the
     * grammar as such, while the enclosing one is added internally for convenience.
     * For the headers of groups this is not a problem because the enclosing rule does not
     * have any groups, so when an header is < numOfRules it can safely mean rule and when
     * >= it means group.
     * Perhaps it is numOfNts that is not entirely correct since it rekons also the enclosing one.
     *
     * Many director sets are duplicated, be they the ones of rules or
     * nonterminals or FOLLOW. Therefore, they must be accessed thru some
     * table which allows to store only once the ones which are equal.
     * It is common to have 60% of duplication (e.g. only 40 over 100 are
     * distinct).
     * A solution is to store them as a sequence of bytes in an array one
     * after another with no doublets and access them thru table indexes.
     * The indexes can be stored as char[], thus halving their sizes.
     * Another solution is to use a comb-vector. Since the values are booleans,
     * the check vector is sufficient.
     * For pascal the former requires 2090 bytes, the second 2316.
     * A comb-vector is also better than bitsets because its size depends on the
     * elements, and not on the dimensions.
     * The directors are actually transposed to obtain tables that can be
     * indexed with token numbers and deliver the applicable rules (LL tables,
     * see below).
     */

    /**
     * Build the encoded grammar.
     */

    private void encodeGrammar(){
        if ((FL_E & this.trc) != 0){
            Trc.out.printf("encodeGrammar groups %s\n",this.foldGroups);
        }

        if ((BASIC & this.mode) != 0){
           this.mode |= NO_LOOKAHEADS;
        }
        ParserTables tab = this.tab;                  // reference to tables object
        int tokBase = this.ntNum;                     // base of encoded tokNr
        tab.tokBase = tokBase;
        tab.ruleBase = tokBase + tab.numOfToks + 1;   // base of encoded ruleNr
        if ((FL_E & this.trc) != 0){
            Trc.out.printf("encodeGrammar ntNum %d numOfToks %d tokBase %d ruleBase %d\n",
                this.ntNum,tab.numOfToks,tab.tokBase,tab.ruleBase);
        }

        // unique overflow check for tokNr, ntNr and ruleNr < 64k

        if (tab.ruleBase + tab.numOfRules + 1 >       // rules: numOfRules + 1
            Character.MAX_VALUE){                     // overflow check
            this.lex.message(ParserLexer.ERR_EXCPRS,
                null,ParserLexer.MSG_AT_EOF);
            throw this.lex.excObj;
        }
        tab.singmap = new char[tab.ruleBase];         // allocate singleton table
        for (int i = 0; i < tab.numOfToks + 1; i++){  // store tokens, also EOF
            tab.singmap[i+tokBase] = (char)(i+tokBase);
        }
        int prinr = 0;
        long[] priArr = new long[tab.priLocs.length]; // allocate priority table
        int nrShift = 32;                             // shifts for locs in priArr

        tab.nullable = new byte[(tab.numOfNts +       // allocate array of nullable nts
            BITSBYTE - 1) / BITSBYTE];

        tab.cyclic = new byte[(tab.numOfNts +         // allocate array of cyclic nts
            BITSBYTE - 1) / BITSBYTE];

        tab.storeLex = new byte[(tab.grammar.length +    // allocate array store lexeme flags
            BITSBYTE - 1) / BITSBYTE];
        tab.storePoint = new byte[(tab.grammar.length +  // allocate array store point flags
            BITSBYTE - 1) / BITSBYTE];

        int[] singatt = new int[tab.ruleBase];        // attr of the chain end

        for (int i = 0; i < this.ntNum; i++){         // compute singletons
            ParserDic h = this.ntTab[i];
            int rs = h.ntNum;
            // it seems not so simple to bypass the singmap: if we do not enter the
            // code below, we do not store the lexing (point, etc.) attributes ... well, the
            // code below computes the attrs for the singleton ends, it does not store them in
            // the tables, but in singatt only, which seems to be accessed only when there are singletons
            if ((BASIC & this.mode) == 0){
                if ((SINGLETONS & this.mode) != 0){
                    ParserDic hh = h;                     // reduce singletons
                    ParserDic last = null;                // last in partial chain
                    ParserNode dd = null;
                    sing: do {
                        dd = hh.def;
                        if (dd.alt != null) break;        // it has several alternatives
                        if (dd.suc != null) break;        // it has several elements
                        if (dd.kind == ParserNode.S_TER){
                            if (dd.def == this.gram.dic_emp) break;
                            hh = dd.def;
                            break;
                        }
                        if (last != null){                // not the first in the chain
                            ParserDic k = h;              // detect cycles
                            do {                          // scan the chain to detect if hh present
                                if (k == hh){             // already ..
                                    break sing;           // .. encountered
                                }
                                if (k == last) break;
                                k = k.def.def;
                            } while (true);
                        }
                        last = hh;
                        hh = dd.def;                      // step to next in chain
                    } while ((ParserNode.GRAM & hh.status) != 0);
                    if ((ParserNode.LEXEME &              // lexeme
                        hh.status) != 0){
                        rs = hh.tokNum + tokBase;
                        int att = this.gram.storeAttr(dd.def.attr,dd.attr);
                        if (att == 0){
                            if ((ParserNode.LIT_TOK & dd.def.attr) == 0){
                                att = ParserNode.LEX_STR_STORE |
                                    ParserNode.LEX_POINT_STORE;
                            }
                        }
                        singatt[h.ntNum] = att;           // attr of chain end
                        if ((FL_E & this.trc) != 0){
                            Trc.out.println("map lexeme " +
                                h + " " + hh + " " + Integer.toHexString(att));
                        }
                    } else {                              // nonterminal
                        rs = hh.ntNum;
                        if ((FL_E & this.trc) != 0){
                            Trc.out.println("map nt " +
                                h + " " + hh);
                        }
                    }
                }
            }
            // there should be no need for this check since tokens encodings should
            // have already been checked as a whole
            if (rs > Character.MAX_VALUE){            // overflow check
                this.lex.message(ParserLexer.ERR_EXCPRS,
                    null,h.point);
                throw this.lex.excObj;
            }
            tab.singmap[h.ntNum] = (char)rs;
            if ((FL_E & this.trc) != 0){
                Trc.out.println("sing map " + h.ntNum + ": " + rs);
            }
        }

        // encode the rules
        int loc = 0;
        tab.grammar[loc++] = (char)tab.ruleBase;      // first entry: sentinel
        int ruleCounter = 0;

        for (int i = 0; i < this.ntNum; i++){         // scan all nonterminals
            ParserDic h = this.ntTab[i];
            if ((FL_E & this.trc) != 0){
                Trc.out.println("---nt---: " + h + " " +
                    h.ntNum + " loc: " + loc + " " +
                    h.def.toString(ParserNode.REP_RULE));
            }
            if ((GE & this.mode) != 0){
                if ((i > 0) && (h == this.ntTab[i-1])){
                    tab.singmap[h.ntNum+1] = (char)(h.ntNum+1);
                    if ((GES & this.mode) == 0){
                        continue;
                    }
                }
            }
            if (h.def == null) continue;              // undefined
            if ((ParserNode.EM & h.status) != 0){     // nullable
                tab.nullable[h.ntNum >>> ParserTables.NSHIFTB] |=
                    (1 << (h.ntNum & ParserTables.MASKB));
                // this is redefined later in the GES case
            }

            if ((ParserNode.CYC & h.status) != 0){     // cyclic
                tab.cyclic[h.ntNum >>> ParserTables.NSHIFTB] |=
                    (1 << (h.ntNum & ParserTables.MASKB));
            }

            int altNum = 0;                           // number of alternative
            for (ParserNode a = h.def; a != null;     // encode all alternatives
                a = a.alt){
                altNum++;
                int num = h.ntNum;
                if ((FL_E & this.trc) != 0){
                    Trc.out.printf("nt %s alt loc %d\n",h,loc);
                }
                if ((GE & this.mode) == 0){
                    if (this.foldGroups){
                        if (tab.ntKind[num] == ParserTables.REP){
                            if (a.alt != null) continue;    // skip first rule of {}+
                        } else if (tab.ntKind[num] == ParserTables.REL){
                            if (a.alt == null) continue;    // skip second rule of {}(l:)
                        }
                    }
                    if ((LRGROUPS & this.mode) != 0){
                        if ((tab.ntKind[num] == ParserTables.REP) ||
                            (tab.ntKind[num] == ParserTables.REL)){
                            if (a.alt == null) continue;    // skip second rule of {}+ and {}(l:)
                        }
                    }
                }

                boolean erule = true;
                boolean eorule = true;
                if ((GES & this.mode) != 0){                // determine if the rule applies to this nt
                    // determine if rule produces the empty string
                    for (ParserNode s = a; s != null; s = s.suc){
                        if (s.kind == ParserNode.S_TER){        // terminal
                            if (s.def == this.gram.dic_emp){
                                continue;                       // skip empty
                            }
                            eorule = false;
                            erule = false;
                            break;
                        }
                        ParserDic d = s.def;
                        if (d == null) continue;
                        if ((ParserNode.EO & d.status) == 0){
                            eorule = false;
                        }
                        if ((ParserNode.EM & d.status) == 0){
                            erule = false;
                            break;
                        }
                    }
                    // a rule that produces only the empty string is good for Ae only
                    if (i < this.ntNum-1){
                        if (h == this.ntTab[i+1]){   // has a split one, and is A
                            if (eorule) continue;
                        }
                    }
                    if (i > 0){
                        if (h == this.ntTab[i-1]){   // has a split one, and is Ae
                            num ++;
                            if (!erule) continue;
                        }
                    }
                }

                tab.ruleToNt[ruleCounter] = (char)num;
                if ((FL_E & this.trc) != 0){
                    Trc.out.println("alt " + a);
                }
                int altprio = 0;
                int rlen = 0;                         // rule length
                int epsilon = 0;
                int startloc = loc;
                tab.ruleIndex[ruleCounter] = loc;     // store start index
                //- in the case of Ae ::= make this below generate the rule with all Ae's in it and with
                //  the appropriate rulenr as sentinel
                //- for a rule <A> ::= "" or <A> ::= <B> with B EO, make sure that the appropriate rule
                //  is generated
                //- make sure that in preparegrammar the rule nrs are computed in the same way as here

                int eleNum = 0;                       // number of element in alternative
                for (ParserNode s = a; s != null;     // encode the alternative
                    s = s.suc){
                    eleNum++;
                    if ((FL_E & this.trc) != 0){
                        Trc.out.println("suc " + s + " " +
                            ((ParserNode.LEXEME & s.def.status) != 0) +
                            " " + loc + " kind: " + s.kind +
                            " |" + String.valueOf(s.def.code) + "| node " + s.toString(0));
                    }
                    if (s.prio > 0){                  // priority defined
                        if (s == a){
                            altprio = s.prio;
                        } else {
                            priArr[prinr++] =
                                ((long)loc << nrShift) | (long)s.prio;
                        }
                    }
                    switch (s.kind){
                    case ParserNode.S_TER:            // a terminal
                        if (s.def == this.gram.dic_emp){
                            continue;                 // skip empty
                        }
                        storeResAttrs(s.def.attr,     // record storage attrs
                            s.attr,loc);
                        tab.grammar[loc++] =
                            (char)(s.def.tokNum + tokBase);
                        if ((FL_E & this.trc) != 0){
                            Trc.out.println("ter " + loc +
                                " " + (int)tab.grammar[loc-1]);
                        }
                        break;
                    default:
                        if ((ParserNode.LEXEME &      // a lexeme
                            s.def.status) != 0){
                            storeResAttrs(s.def.attr, // record storage attrs
                                s.attr,loc);
                            tab.grammar[loc++] =
                                (char)(s.def.tokNum + tokBase);
                            if ((FL_E & this.trc) != 0){
                                Trc.out.println("nt lexeme " +
                                    loc + " " + (int)tab.grammar[loc-1]);
                            }
                        } else {                      // a nonterminal
                            if ((FL_E & this.trc) != 0){
                                Trc.out.println("nt " + s +
                                    " " + s.def.ntNum);
                            }
                            // this should be done when there is singleton reduction
                            if ((CHAIN_RULES & this.mode) == 0){
                                int sing = tab.singmap[s.def.ntNum];
                                if (sing != s.def.ntNum){          // singleton
                                    storeStorage(
                                        singatt[s.def.ntNum],loc); // record storage attrs
                                }
                            }

                            int ntnr = (char)s.def.ntNum;
                            if ((GES & this.mode) != 0){
                                if (erule && !eorule){
                                    if (i > 0 && h == this.ntTab[i-1]){   // has a split one, and is Ae
                                        ntnr++;
                                    }
                                }
                            }

                            tab.grammar[loc++] = (char)ntnr;
                            if ((GE & this.mode) == 0){
                                if (this.foldGroups){
                                    if ((tab.ntKind[num] == ParserTables.REP) ||
                                        (tab.ntKind[num] == ParserTables.RES)){
                                        tab.grammar[loc-1] =
                                            (char)a.def.ntNum;  // in {}+ simulate a &1 &1
                                    }
                                }
                            }
                            if ((FL_E & this.trc) != 0){
                                Trc.out.println("nt " +
                                    loc + " " + (int)tab.grammar[loc-1]);
                            }
                            if ((GE & this.mode) != 0){
                                ParserDic d = s.def;
                                if (d != null){
                                    if ((ParserNode.EM & d.status) != 0){
                                        if ((ParserNode.EO & d.status) == 0){
                                            epsilon++;
                                        }
                                    }
                                }
                            }
                        }
                        break;
                    }
                    rlen++;
                }
                if ((GE & this.mode) == 0){
                    if (this.foldGroups){
                        if (tab.ntKind[num] == ParserTables.REL){
                            tab.grammar[loc++] = (char)a.def.ntNum;  // add a &1
                            rlen++;
                        }
                    }
                    if ((LRGROUPS & this.mode) != 0){
                        if (tab.ntKind[num] == ParserTables.RES){
                            if (rlen > 0){              // second rule
                                rlen--;                 // one term less
                                tab.grammar[loc-2] = tab.grammar[loc-1];
                                loc--;
                                if ((FL_E & this.trc) != 0){
                                    Trc.out.printf("one element removed rlen %s loc %s\n",rlen,loc);
                                }
                            }
                        }
                    }
                }

                if (altprio > 0){                       // prio on alternative
                    priArr[prinr++] =
                        ((long)loc << nrShift) | (long)altprio;
                }
                if ((FL_E & this.trc) != 0){
                    Trc.out.printf("rule sentinel at %d rule %d\n",loc,ruleCounter);
                }
                tab.grammar[loc++] =                    // store encoded ruleNr
                    (char)(ruleCounter + tab.ruleBase);
                /*
                if (rlen > Character.MAX_VALUE){      // overflow check
                    this.lex.message(ParserLexer.ERR_EXCPRS,
                        null,h.point);
                    throw this.lex.excObj;
                }
                */
                tab.ruleLen[ruleCounter++] = (char)rlen;
                // copy here 2**eplsilon times the rule
                comb: if ((GE & this.mode) != 0){
                    int nr = 1 << epsilon;
                    if ((GES & this.mode) != 0){
                        if (i > 0 && h == this.ntTab[i-1]){   // has a split one, and is Ae
                            break comb;
                        }
                        if (epsilon == 0) break comb;
                        if (erule) nr--;                // last rule has all Ae's
                    }
                    int endloc = loc;
                    if ((FL_E & this.trc) != 0){
                        Trc.out.println("epsilon " + epsilon);
                    }
                    for (int e = 1; e < nr; e++){
                        int w = epsilon;
                        if ((FL_E & this.trc) != 0){
                            Trc.out.printf("rule at %d\n",loc);
                        }
                        int startrule = loc;
                        for (int x = startloc; x < endloc; x++){
                            int sym = tab.grammar[x];
                            if (sym < tokBase){      // nonterminal
                                if ((tab.split[sym >>> ParserTables.NSHIFTB] &
                                    (1 << (sym & ParserTables.MASKB))) != 0){ // has an epsilon one
                                    if (((1 << --w) & e) != 0){
                                        sym++;
                                    }
                                }
                            }
                            tab.grammar[loc] = (char)sym;
                            if ((this.tab.storeLex[x >>> ParserTables.NSHIFTB] &
                                (1 << (x & ParserTables.MASKB))) != 0){
                                this.tab.storeLex[loc >>> ParserTables.NSHIFTB] |=
                                    (1 << (loc & ParserTables.MASKB));
                            }
                            if ((this.tab.storePoint[x >>> ParserTables.NSHIFTB] &
                                (1 << (x & ParserTables.MASKB))) != 0){
                                this.tab.storePoint[loc >>> ParserTables.NSHIFTB] |=
                                    (1 << (loc & ParserTables.MASKB));
                            }
                            loc++;
                        }
                        if ((GES & this.mode) != 0){
                            tab.grammar[loc-1] =                      // store encoded ruleNr
                                (char)(ruleCounter + tab.ruleBase);
                            if ((FL_E & this.trc) != 0){
                                Trc.out.printf("rule sentinel at %d rule %d\n",loc-1,ruleCounter);
                            }
                            tab.ruleLen[ruleCounter] = (char)rlen;
                            tab.ruleToNt[ruleCounter] = (char)num;
                            tab.ruleIndex[ruleCounter] = startrule;   // store start index
                            ruleCounter++;
                        }
                    }
                }
            }
        }
        if ((GE & this.mode) == 0){
            if (this.foldGroups){                      // fix kinds of bodies
                for (int i = 0; i < this.ntNum; i++){
                    if (tab.ntKind[i] <= ParserTables.REL){ // repetition group
                        int amp1 = tab.body(i);
                        tab.ntKind[amp1] = ParserTables.BOR;
                    }
                }
            }
            if ((LRGROUPS & this.mode) != 0){   // fix kinds of bodies
                for (int i = 0; i < this.ntNum; i++){
                    if (tab.ntKind[i] <= ParserTables.REL){ // repetition group
                        // body() works also with the changes to the rules above
                        int amp1 = tab.body(i);
                        tab.ntKind[amp1] = ParserTables.BOR;
                    }
                }
            }
        } else {
            tab.nullable = tab.epsilon;                // use the epsilon one, which is the right one
        }

        if ((FL_E & this.trc) != 0){
            Trc.out.println("startRule: " + tab.startRule);
        }
        Arrays.sort(priArr,0,priArr.length);           // sort prios
        long mask = 0x0ffffffffL;
        for (int i = 0; i < priArr.length; i++){
            tab.priLocs[i] = (int)(priArr[i] >>> nrShift);
            tab.priVals[i] = (char)(priArr[i] & mask);
        }

        // it would be better to compute now first, follow, etc. using the encoded grammar,
        // which could be different from the original one because of changes applied to make
        // parsing easier

        if ((FL_E & this.trc) != 0){
            Trc.out.printf("encoded grammar tokBase %d ruleBase %d\n",
                this.tab.tokBase,this.tab.ruleBase);
            for (int i = 1; i < this.tab.grammar.length;){         // trace the rules
                while (this.tab.grammar[i] < this.tab.ruleBase){       // gramRule
                    int e = this.tab.grammar[i];
                    Trc.out.print(i + " " + this.tab.symToString(e));
                    Trc.out.println();
                    i++;
                }
                int ruleNr = this.tab.grammar[i] - this.tab.ruleBase;
                int nt = this.tab.ruleToNt[ruleNr];
                Trc.out.println(i + " " + (int)this.tab.grammar[i++] +
                    " nt: " + this.tab.ntLitName(nt) + " rule: " + ruleNr);
                Trc.out.println();
            }
        }


        if ((GES & this.mode) == 0){
            buildDirSet();                   // build director sets
        } else {
            // doFirstEnc();                 // recompute FIRST
            predictTablesEnc();              // recompute lookaheads with the modified grammar
            buildDirSet();                   // build director sets
        }

        // buid table of singleton chains size for encodetree: the sizes of the
        // phrases in the tree, including the singleton chains that are reconstructed

        // it is not clear what are singleton chains with groups: a group should break the
        // chain, except perhaps {a}
        tab.singsize = new char[tab.ruleIndex.length];
        for (int i = 0; i < tab.ruleIndex.length; i++){
            int n = 0;
            int sym = tab.ruleToNt[i];
            int kind = tab.ntKind[sym];                  // kind
            grp: if (kind <= ParserTables.REL){          // repetition group
                n = tab.ruleIndex[i];                    // &0 ::= ...
                switch (kind){
                case ParserTables.RES:                   // {alpha}*, {alpha}(0:)
                    if (tab.ntToRule[sym] == i){
                        break grp;                       // &0 ::= ""
                    }
                    break;
                }
                int osym = tab.grammar[n];               // &1, gramRule
                n = 0;
                sym = osym;
                // this should always be true
                if (osym < tab.ruleBase){                // dot not at beginning
                    sym = tab.singmap[osym];             // take the symbol
                }
                if (osym == sym) continue;               // not a singleton
                while (sym != osym){                     // compute size of phrases
                    n += 2;
                    if (osym >= tab.ntNrGroups) n++;     // a group
                    osym = tab.grammar[tab.ruleIndex[tab.ntToRule[osym]]];
                }
                if (n > Character.MAX_VALUE){
                    this.lex.message(ParserLexer.ERR_EXCPRS,
                        null,ParserLexer.MSG_AT_EOF);
                    throw this.lex.excObj;
                }
                tab.singsize[i] = (char)n;
                continue;
            }
            for (int j = tab.ruleIndex[i]; tab.grammar[j] < tab.ruleBase; j++){
                int osym = tab.grammar[j];
                sym = osym;
                // this should always be true
                if (osym < tab.ruleBase){                // dot not at beginning
                    sym = tab.singmap[osym];             // take the symbol
                }
                if (osym == sym) continue;               // not a singleton
                while (sym != osym){                     // compute size of phrases
                    n += 2;
                    if (osym >= tab.ntNrGroups) n++;     // a group
                    osym = tab.grammar[tab.ruleIndex[tab.ntToRule[osym]]];
                }
            }
            if (n > Character.MAX_VALUE){
                this.lex.message(ParserLexer.ERR_EXCPRS,
                    null,ParserLexer.MSG_AT_EOF);
                throw this.lex.excObj;
            }
            tab.singsize[i] = (char)n;
        }

        tabSize();
        if ((FL_E & this.trc) != 0){
            Trc.out.println("--- grammar ---");
            tab.traceGrammar();
            Trc.out.println("-- rules --");
            for (int i = 0; i < tab.ruleIndex.length; i++){
                Trc.out.println(tab.ruleToString(tab.ruleIndex[i],false));
            }
        }
        if ((GE & this.mode) != 0){
            if ((GES & this.mode) == 0){
                buildStates();
            }
        }

        // build the comb vector for the priorities

        if (tab.priLocs.length > 0){
            if ((FL_E & this.trc) != 0){
                Trc.out.printf("--- table for priorities --- nr rules %s\n",tab.numOfRules);
            }
            ArrayList<Integer> locs = new ArrayList<Integer>();
            ArrayList<Integer> vals = new ArrayList<Integer>();
            int mapi = 0;
            tab.priMaps = new int[100];
            // find longest rule
            int longest = 0;
            for (int i = 0; i < tab.ruleIndex.length; i++){
                if (tab.ruleLen[i] > longest) longest = tab.ruleLen[i];
            }
            PrioTerms[] priTerms = new PrioTerms[longest];      // allocate temporary vector for terms
            for (int i = 0; i < longest; i++){
                priTerms[i] = new PrioTerms();
            }
            boolean priOnRule = false;
            int size = 0;
            for (int i = 0; i < tab.ruleIndex.length; i++){
                // find prios on terms
                for (int j = 0; j < longest; j++){              // initialize sort vector
                    priTerms[j].index = j;
                    priTerms[j].prio = 0;
                }
                boolean found = false;
                int p = tab.ruleIndex[i];
                for (int j = 0; j < tab.ruleLen[i]; j++){
                    int pri = Arrays.binarySearch(tab.priLocs,p++);
                    if (pri >= 0){
                        priTerms[j].prio = tab.priVals[pri];
                        found = true;
                    }
                }
                if (found){                      // this rule has prios on terms
                    locs.add(tab.ruleIndex[i]);
                    vals.add(mapi);
                    Arrays.sort(priTerms,0,tab.ruleLen[i],new Comparator<PrioTerms>(){
                        public int compare(PrioTerms t1, PrioTerms t2){
                            if (t1.prio != t2.prio) return t2.prio - t1.prio;
                            if (t1.index != t2.index) return t1.index - t2.index;
                            return 0;
                    }});
                    if (mapi + tab.ruleLen[i] >= tab.priMaps.length){
                        int newlen = mapi + tab.ruleLen[i];
                        tab.priMaps = Arrays.copyOf(tab.priMaps,newlen);
                    }
                    for (int j = 0; j < tab.ruleLen[i]; j++){
                        tab.priMaps[mapi++] = priTerms[j].index;
                    }
                }
                int end = tab.ruleIndex[i] + tab.ruleLen[i];    // index of sentinel
                int pri = Arrays.binarySearch(tab.priLocs,end);
                if (pri >= 0){                                  // the rule has a priority
                    locs.add(end);
                    vals.add(tab.priVals[pri]);
                }
            }
            tab.priLocs = new int[locs.size()];
            tab.priVals = new int[locs.size()];
            for (int i = 0; i < tab.priLocs.length; i++){
                tab.priLocs[i] = locs.get(i);
                tab.priVals[i] = vals.get(i);
            }
            tab.priMaps = Arrays.copyOf(tab.priMaps,mapi);
            if ((FL_E & this.trc) != 0){
                Trc.out.printf("priorities\n");
                for (int i = 0; i < tab.ruleIndex.length; i++){
                    int t = Arrays.binarySearch(tab.priLocs,tab.ruleIndex[i]);
                    int r = Arrays.binarySearch(tab.priLocs,tab.ruleIndex[i]+tab.ruleLen[i]);
                    if (t >= 0 || r >= 0){
                        Trc.out.printf("   rule %s",i);
                    }
                    if (t >= 0){
                        for (int k = 0, z = tab.priVals[t]; k < tab.ruleLen[i]; k++, z++){
                            Trc.out.printf(" %s",tab.priMaps[z]);
                        }
                    }
                    if (r >= 0){
                        Trc.out.printf(" on alt: %s",tab.priVals[r]);
                    }
                    if (t >= 0 || r >= 0){
                        Trc.out.printf("\n");
                    }
                }
            }
        }
    }

    /**
     * The object to sort priorities on terms.
     */

    private static class PrioTerms {
        int index;
        int prio;
    }

    /**
     * Determine the resulting storage attributes and record them
     * in the storage maps.
     *
     * @param   def default attributes
     * @param   att current attributes
     * @param   loc index in the maps
     */

    private void storeResAttrs(int def, int att, int loc){
        if ((FL_E & this.trc) != 0){
            Trc.out.println("storeResAttrs " +
                Integer.toHexString(def) + " " +
                Integer.toHexString(att));
        }
        int a = this.gram.storeAttr(def,att);
        if (a == 0){
            if ((ParserNode.LIT_TOK & def) == 0){
                a = ParserNode.LEX_STR_STORE |
                    ParserNode.LEX_POINT_STORE;
            }
        }
        storeStorage(a,loc);
    }

    /**
     * Record the storage attributes in the storage maps.
     *
     * @param   att attributes
     * @param   loc index in the maps
     */

    private void storeStorage(int att, int loc){
        if ((FL_E & this.trc) != 0){
            Trc.out.println("storeStorage " +
                Integer.toHexString(att));
        }
        if ((ParserNode.LEX_STR_STORE & att) != 0){
            if ((FL_E & this.trc) != 0){
                Trc.out.printf("storeStorage storeLex\n");
            }
            this.tab.storeLex[loc >>> ParserTables.NSHIFTB] |=
                (1 << (loc & ParserTables.MASKB));
        }
        if ((ParserNode.LEX_POINT_STORE & att) != 0){
            if ((FL_E & this.trc) != 0){
                Trc.out.printf("storeStorage storePoint\n");
            }
            this.tab.storePoint[loc >>> ParserTables.NSHIFTB] |=
                (1 << (loc & ParserTables.MASKB));
        }
    }

    /**
     * Build the director sets and the LL parse tables.
     */

    /* First, the applicable rules for each nonterminal are determined.
     * If chain rules reduction is enabled, they include only the leaves of chain
     * ends.
     * Then, the LL tables are build for each nonterminal by visiting the
     * directors of its rules and placing the rule numbers in a table of
     * IntSet's indexed by token numbers. The table is reused for all
     * nonterminals.
     * The rulesets so built are placed in a hash table to remove duplicates.
     * 
     * The LL table of a nonterminal is indexed by token numbers, and contains
     * the rules that can be applied for each token.
     * When for a token there is only one applicable rule, the rule is stored
     * directly in the indexed element. When there are several, the offset (with
     * respect to the table base, and negated) to a place where the set of rules
     * is kept is stored instead.
     *
     * tokNr  table of a nonterminal
     *       ----------
     *       :        :
     *       |--------|
     *    i  | ruleNr |      the one rule that can generate:  token_i alpha
     *       |--------|
     *       :        :
     *       |--------|
     *    j  |    ----+---.  several rules that generate: token_j alpha
     *       :        :   |  index relative to the start of this table
     *       |--------|   |
     *       |   nr   |<--'
     *       | ruleNr |
     *       | ruleNr |
     *       |  ...   |
     *       |--------|
     *
     * An entry which is >= 0 is a single rule number, one which is < 0
     * is the negated offset with respect to the base of the table to
     * a place containing a set of rules.
     *
     * The director (and LL table) of the enveloping rule is never used.
     * The effect of having such a rule is only to insert in the directors
     * of some nonterminals an EOF. However, it hardly takes space, and
     * besides that, not having it would make a special case to cater for.
     *
     * The nonterminals which are LL(1) are marked as such by testing that
     * the directors of their rules are all disjoint (which is simple after
     * having combed them). The grammar is flagged as LL1 if all are LL.
     *
     * Note that the table elements for all tokens (including the EOF) are
     * defined so as not to make a special case for EOF.
     *
     * The LL tables are compressed in a comb vector. A first attempt is made
     * to place the rulesets within the comb vector, or at the end of it.
     * This allows to use the holes in it, and also to store rulesets that
     * are referred to by several LL tables only once.
     * In practice, although many nonterminals apply the same rule for many
     * tokens, making a partition of the tokens in disjoint sets does not
     * avail (as it does instead in a lexer when building character classes).
     * The resulting partitions contain normally only one element.
     * The first attempt is made on the ground that having all rulesets of
     * a table at the end of it makes the table dense and large, thus
     * decreasing compression. Fitting them into holes overcomes this.
     * A second attempt could be made to allocate the rulesets at the end
     * of each table which has some. However, this would help only when
     * there would be no sufficient bits in the table entries to accomodate
     * rules and rulesets (e.g. if the table were a char[]).
     *
     * The LL tables and the FOLLOW tables are packed into a unique comb
     * vector. In order to have only one vector that can deliver the lookup
     * of every symbol (i.e. what is at the items' dot in the grammar), the
     * tokens are placed in it too. In all cases, testing the check value
     * allows to know if the requested token is a lookup for the given
     * symbol. Moreover, when the symbol is a nonterminal, accessing the
     * merged table, the numbers of the rules that start with it can be
     * obtained. Table(symbol,token) is:
     *
     *   symbol         check value
     *
     *   tokens:        present if symbol = token
     *   nonterminals:  present if has rules with the token in their director
     *   rules:         present if the token belongs to FOLLOW (all rules of
     *                  a same nonterminal share the same values)
     *
     * To place the values for the tokens in the comb vector, a diagonal
     * matrix is built.
     * The values for the tokens and the rules are never accessed (only a
     * test is done to check that they are defined). Therefore, that part
     * of the merged table is not kept (only the base is kept).
     * When there is only one token, and a nonterminal has several rules
     * for it, the offset of the ruleset has index 1.
     * Since to tell that an entry is a reference to a ruleset, its value
     * is negated, and becomes -1. Thus, as hole values, -1 cannot be used.
     * The maximum integer is then used.
     * Such hole value never occurs because we store rule numbers (which are
     * lower than that) or negative offsets with respect to the current base.
     * Rows folding is enabled: a table of a nonterminal can never be the
     * same as that of another since it contains its rule numbers, but
     * FOLLOW tables are shared among many rules.
     * This organization of the lookup table allows to test whether a token
     * belongs to the lookup set of a symbol in a simple way in the engine:
     *
     *    idx = labase[symbol];
     *    if (lacheck[idx+token] != (char)idx) ... not present
     *
     * Keeping dedicated tables allows to save some 10% of space, but makes
     * the test more complex:
     *
     *    if (symbol < ruleBase){             // not at end of rule
     *        if (((symbol >= tokBase) &&
     *            (symbol != tokBase + token)) ||
     *            ((symbol < tokBase) &&
     *            (llcheck[llbase[symbol]+token] != (char)idx))){
     *            ... not present
     *        }
     *    } else {
     *        idx = followIndex[ruleToNt[symbol-ruleBase]];
     *        if (followCheck[idx+token] != idx) ... not present
     *    }
     *
     * Check values in the comb vector are kept on 16 bits integers (char)
     * because this almost halves the comb size without affecting much the
     * compression.
     * There are grammars in which the tables are longer than 64k: this is
     * due to the LL tables that exceed the 64k limit. E.g. an html grammar
     * is close to it. All the more, the NO_LOOKAHEADS is a problem too
     * because it generates tables in which for every nonterminal have all
     * entries that are non-holes, and that do overflow.
     * With FOLD_COLS the size does not reduce much, except when lookaheads
     * are disabled. Pascal: from 522 to 516, html: from 31987 to 32085
     * (in this case it is even larger).
     * For the LL tables, with chain rules reduction enabled, we make the
     * closure of the rules predicted by a nonterminal and the nonterminals
     * that are in front of its rules so as to determine the rules that are
     * at the end of the chains, which are the only ones that we take.
     * With lookaheads disabled there is a difference in the LL tables:
     * they have many more rules for each (nonterminal,token) pair.
     * They are the same for all tokens for a nonterminal, but the row
     * for a nonterminal has many less holes than with lookaheads enabled.
     * A mid way could be to store the full set of its rules only for the
     * tokens that can begin at least one rule, but this is not exactly
     * the same as disabling the lookaheads: it produces a different behaviour
     * when a token is not one generated by a nonterminal.
     * Note that first we build for each nonterminal the set of its rules
     * making an appropriate closure. Then, we determine the subset of it
     * that has to be predicted for each terminal.
     * Thus, we store the base in an int[] table.
     * Concerning the table that holds the values, we could use a char[].
     * With it, we have 64k values to store individual rules and offsets
     * to rulesets.
     * The best we could do is to have a dynamic value that holds the border
     * between them. When a value is higher than the border, it denotes an
     * offset (which is the value - border). We should determine the highest
     * number of rule that occurs as a single rule. What remains from it
     * to 64k are the values for the rulesets. Whether this is sufficient
     * is hard to tell. When border + offset > 64k we can try to append the
     * rulesets at the end of each table. However, also this one is not
     * guaranteed to succeed. For a mid-size language such as Pascal the size
     * of tables with int[] is 5770 and 3834 with char[].
     * The saving does not pay off the risk.
     *
     * Measurements show that this speeds up the engine by 1-2%.
     * With basic = true all directors become inactive since they are full.
     * This makes the comb quite large. However, basic serves only in
     * debugging.
     *
     * The encoded grammar is visited, not the origin one so as to cater
     * for che changes done in groups. In so doing, groups are not rekoned
     * as non-ll constructs (which is not the case where they represented
     * by left recursive rules).
     *
     * Disabling lookaheads
     *
     * Lookaheads are disabled by making all the entries of the LL table of a
     * each nonterminal refer to the full set of its applicable rules.
     * Moreover, the LL tables for tokens and rules are made full.
     * This makes the predictor insert items for all rules, the scanner and
     * the completer advance the dot in front of any symbol and past any
     * symbol.
     * There is no need to optimize here sharing sets or allocating them
     * after all the subtables.
     * Disabling lookaheads increases considerably the number of items
     * genearated and slows down a lot the engine. With some grammars (e.g.
     * the html one) this could result in running off memory and in very
     * high parse times.
     *
     * For Earley parsing, when lookaheads are enabled, the predictor and the
     * completer inserts items that surely generate the next token, and therefore
     * the scanner does not need to check it (but it checks what token is after it).
     * When lookaheads are disabled, this is no longer true, and then the scanner
     * needs to check that the items to place in the kernel actually generate the
     * current token.
     * I have made the scanner test it always. It should be removed, or commented
     * out in the production engine
     */

    /* buildDirSet produces the LL tables and packs them together with the follow
     * ones into a single comb vector. The director sets have already been computed
     */

    private void buildDirSet(){
        if ((FL_E & this.trc) != 0){
            Trc.out.println("buildDirSet");
        }
        ParserTables tab = this.tab;                  // reference to tables object
        long size;

        // build the comb-vector for the director sets

        int hole = Integer.MAX_VALUE;

        // build follow lists for nonterminals as a table of (index,value) sequences,
        // using 1 as value (any value is good since it is not stored). This is needed
        // to build the follow lists for rules

        int[][] lists = new int[this.follow.length][];
        int[] full = null;
        if ((NO_LOOKAHEADS & this.mode) != 0){
            full = new int[(tab.numOfToks + 1)*2 + 1];
            full[0] = tab.numOfToks + 1;
            int k = 1;
            for (int j = 0; j <= tab.numOfToks; j++){ // full table
                full[k++] = j;
                full[k++] = 1;
            }
        }
        for (int i = 0; i < this.follow.length; i++){ // build follow for ..
            if ((NO_LOOKAHEADS & this.mode) != 0){    // .. nonterminals
                lists[i] = full;                      // disable lookaheads
                continue;
            }
            byte[] set = this.follow[i];
            if (set == null) continue;
            int n = 0;                                // determine length
            for (int j = 0; j <= tab.numOfToks; j++){
                if ((set[j >>> 3] & (1 << (j & 0x7))) != 0){
                    n++;
                }
            }
            int[] t = new int[n*2 + 1];               // allocate the table
            lists[i] = t;
            t[0] = tab.numOfToks + 1;                 // fill it
            n = 1;
            for (int j = 0; j <= tab.numOfToks; j++){
                if ((set[j >>> 3] & (1 << (j & 0x7))) != 0){
                    t[n++] = j;
                    t[n++] = 1;
                }
            }
        }

        // then build follow for rules
        int[][] larules = new int[tab.numOfRules + 1][];  // includes the enclosing
        for (int i = 0; i < larules.length; i++){
            larules[i] = lists[tab.ruleToNt[i]];
        }

        // then build lookaheads for tokens
        int[][] latoks = new int[tab.numOfToks + 1][];    // tokens
        for (int i = 0; i < latoks.length; i++){
            if ((NO_LOOKAHEADS & this.mode) != 0){
                latoks[i] = full;
            } else {
                latoks[i] = new int[3];                   // diagonal matrix
                latoks[i][0] = tab.numOfToks + 1;
                latoks[i][1] = i;
                latoks[i][2] = 1;
            }
        }

        int[][] chaintable = new int[this.ntNum][];   // allocate chain table
        IntSet[] llrules = new IntSet[this.ntNum];    // rules of each nt
        build_lle(chaintable,hole,llrules);           // build the tables

        CombVector comb;

        // build sets of rules, for the ll(n,t) = s, with |s| > 1

        int[][] llvect = new int[this.ntNum][];       // allocate ll vectors
        HashBag rtable = new HashBag();               // ruleset table
        build_llvect(llrules,llvect,rtable);
        RuleSet[] rmap = new RuleSet[rtable.size()];  // map of rulesets
        Iterator it = rtable.iterator();
        while (it.hasNext()){
            RuleSet e = (RuleSet)(it.next());
            rmap[e.number] = e;
        }
        try {
            for (int w = 0; w < 2; w++){
                comb = new CombVector(hole,
                    CombVector.HOLES_ACCESSED |
                    CombVector.FOLD_ROWS |
                    CombVector.PAIRS);
                comb.checkBits = 16;                  // check values in 16 bits
                comb.merge(llvect);                   // store ll tables of nts
                //comb.sanityCheck();
                int lasize = comb.tabMerged.length;   // length of nonterminal part
                int[] latable = null;
                if (w == 0){                          // first try
                    latable = fit_rulesets(llvect,rmap,comb); // fit then the rulesets
                    //if (latable == null){           // unsuccessful, never occurs
                    //    build_llapp(llvect,rmap);   // build appended tables
                    //    continue;                   // try again
                    //}
                }
                // from now on, we are interested only in the check value
                comb.merge(latoks);                   // store tables of toks
                comb.merge(larules);                  // store tables of rules
                if ((FL_E & this.trc) != 0){
                    Trc.out.println("ll tables:");
                    comb.statistics();
                }
                if (w == 0){                          // first try
                    tab.latable = latable;            // LL tables
                } else {
                    tab.latable = new int[lasize];    // copy LL tables
                    for (int i = 0; i < tab.latable.length; i++){
                        tab.latable[i] = comb.tabMerged[i];
                    }
                }
                tab.lacheck = new char[comb.check.length];  // their check values
                for (int i = 0; i < tab.lacheck.length; i++){
                    tab.lacheck[i] = (char)comb.check[i];
                }
                tab.labase = new int[comb.base.length];     // their base values
                for (int i = 0; i < tab.labase.length; i++){
                    tab.labase[i] = comb.base[i];
                }

                /*
                if ((FL_E & this.trc) != 0){
                    size = 0L;
                    size += 4 + tab.latable.length * 4;
                    size += 4 + tab.lacheck.length * 2;
                    size += 4 + tab.labase.length * 4;
                    Trc.out.println("LL size: try " + w + " " + size);
                }
                */
                break;
            }
        } catch (OutOfMemoryError exc){
            this.lex.message(ParserLexer.ERR_EXCPRS,
                null,ParserLexer.MSG_AT_EOF);
            throw this.lex.excObj;
        }

        if ((FL_E & this.trc) != 0){
            for (int i = 0; i < tab.ntToRule.length; i++){    // scan all nonterminals ..
                int idx = tab.labase[i];
                Trc.out.printf("LL for: %s %d\n",tab.gramSymToString(i),idx);
                if (idx == -1) continue;
                for (int j = 0; j <= tab.numOfToks; j++){     // scan tokens
                    if (tab.lacheck[idx+j] != (char)idx) continue;  // no rule
                    Trc.out.printf("  %s ",tab.gramSymToString(j+tab.tokBase));
                    int ri = tab.latable[idx+j];              // rule / ovf zone
                    if (ri >= 0){                             // rule
                        Trc.out.printf("rule %d\n",ri);
                    } else {                                  // ovf zone
                        ri = idx - ri;
                        Trc.out.printf("ruleset %d\n",ri);
                    }
                }
                tab.traceLLTable(i,Trc.wrt);
            }
            for (int i = 0; i < tab.labase.length; i++){
                if (i < tab.tokBase){
                    Trc.out.println(tab.symToString(i));
                } else if (i < tab.ruleBase){
                    Trc.out.println(tab.symToString(i) + " " +
                        tab.dirSetToStr(tab.labase[i],tab.lacheck));
                } else {
                    int ruleNr = i - tab.ruleBase;
                    Trc.out.println("rule: " + ruleNr + " " +
                        tab.ntLitName(tab.ruleToNt[ruleNr]) + " " +
                        tab.dirSetToStr(tab.labase[i],tab.lacheck));
                }
            }
        }

        // this counts unit rules. Chain reduction is finer than this because it builds tables
        // for each token, and for a same nonterminal there could be tables that benefit from
        // reduction and others not. However, this can give an idea if chain reduction is worth

        if ((CHAIN_RULES & this.mode) != 0){
            comb = new CombVector(hole,                   // compress chain table
                CombVector.HOLES_ACCESSED |
                CombVector.FOLD_ROWS |
                CombVector.PAIRS);

            comb.checkBits = 16;                          // check values in 16 bits
            try {
                comb.merge(chaintable);                   // store tables of nts
                //comb.sanityCheck();
                if ((FL_E & this.trc) != 0){
                    Trc.out.println("chain tables:");
                    comb.statistics();
                }
                if (comb.tabMerged.length >= Character.MAX_VALUE){
                   throw new OutOfMemoryError();
                }
            } catch (OutOfMemoryError exc){
                this.lex.message(ParserLexer.ERR_EXCPRS,
                    null,ParserLexer.MSG_AT_EOF);
                throw this.lex.excObj;
            }
            tab.chaintable = new char[comb.tabMerged.length];    // chain-end tables
            for (int i = 0; i < tab.chaintable.length; i++){
                tab.chaintable[i] = (char)comb.tabMerged[i];
            }
            tab.chainLentable = new char[comb.tabMerged.length]; // chain length tables
            for (int i = 0; i < tab.chaintable.length; i++){
               tab.chainLentable[i] = (char)(comb.tabMerged[i] >>> 16);
            }
            tab.chaincheck = new char[comb.check.length];        // their check values
            for (int i = 0; i < tab.chaincheck.length; i++){
                 tab.chaincheck[i] = (char)comb.check[i];
            }
            tab.chainbase = new char[comb.base.length];          // their base values
            for (int i = 0; i < tab.chainbase.length; i++){
                tab.chainbase[i] = (char)comb.base[i];
            }

            tab.chainrules = new byte[(tab.numOfRules +          // allocate bitset of rules
            BITSBYTE) / BITSBYTE];                               // .. that have a chain term
            boolean chainterm = false;
            for (int i = 0; i < tab.grammar.length; i++){        // scan all rules
                int sy = tab.grammar[i];
                if (sy < tab.tokBase){       // nonterminal
                    int idx = tab.chainbase[sy];
                    if (idx != Character.MAX_VALUE){
                        chainterm = true;
                    }
                } else if (sy >= tab.ruleBase){
                    if (chainterm){
                        sy -= tab.ruleBase;
                        if ((FL_E & this.trc) != 0){
                             Trc.out.println("chain rule: " +
                                 tab.ruleToString(tab.ruleIndex[sy],false));
                        }
                        tab.chainrules[sy >>> ParserTables.NSHIFTB] |=
                            (1 << (sy & ParserTables.MASKB));
                    }
                    chainterm = false;
                }
            }
        }
        if ((FL_E & this.trc) != 0){
            size = 0L;
            size += 4 + tab.latable.length * 4;
            size += 4 + tab.lacheck.length * 2;
            size += 4 + tab.labase.length * 4;
            Trc.out.println("LL size: " + size);
            if (tab.chainbase != null){
                size = 0L;
                size += 4 + tab.chaintable.length * 2;
                size += 4 + tab.chainLentable.length * 2;
                size += 4 + tab.chaincheck.length * 2;
                size += 4 + tab.chainbase.length * 2;
                size += 4 + tab.chainrules.length;
                Trc.out.println("chain size: " + size);

                Trc.out.println("chaintable: " + (tab.chaintable.length * 2));
                Trc.out.println("chainLentable: " + (tab.chainLentable.length * 2));
                Trc.out.println("chaincheck: " + (tab.chaincheck.length * 2));
                Trc.out.println("chainbase: " + (tab.chainbase.length * 2));
                Trc.out.println("chainrules: " + (tab.chainrules.length * 2));
            }
        }
    }

    private static void showMatrix(String s, int[][] matrix){
        Trc.out.println("static int[][] " + s + " = new int[][]");
        Trc.out.println("{");
        for (int i = 0; i < matrix.length; i++){
            int[] tab = matrix[i];
            if (tab == null){
                Trc.out.print("   null");
            } else {
                Trc.out.print("   {");
                for (int j = 0; j < tab.length; j++){
                    if (j > 0) Trc.out.print(",");
                    Trc.out.print((int)tab[j]);
                }
                Trc.out.print("}");
            }
            if (i < matrix.length-1) Trc.out.print(",");
            Trc.out.println();
        }
        Trc.out.println("};");
    }

    /** The array holding the dot value of the items lists. */
    private int[] dot;

    /** The array holding the subpointer value of the items lists. */
    private int[] sub;

    /** The index of the slot following the last item. */
    private int enditem;

    /** The index of the end of the first items list. */
    private int end1list;

    /**
     * Build the applicable rules for each nonterminal and the chain-end
     * tables.
     *
     * @param   chaintable return chain-end tables
     * @param   hole hole value
     * @param   llrules return vector of the applicable rules
     */

    /*
     * When chain rules reduction is disabled, an item list with one item
     * for each rule of the nonterminal is built. When it is enabled, the
     * list contains the closure with respect to chain rules (i.e. it
     * contains an item for each rule at the end of the chain as well as
     * the intermediate ones).
     * Items contain the rule number as dot value instead of the index in
     * the grammar because that allows easily to get both the first symbol
     * in the RHS and the LHS also.
     * We then simulate the matching of a token, no matter what that token
     * is. This means that we collect all the rules that can be applied for
     * all possible tokens.
     *
     * The items for unit rules (for nonterminals) are marked with the highest
     * bit set in their dot in the first items list. This serves to skip them when
     * building the LL tables. Such items are kept in the first items list because
     * they serve to build it and to perform the completion to build the second
     * items list. To mark the items in the first list which are used to build the
     * kernel of the second, the sub field is used. This spares to process
     * several times a same item since the first list is scanned and when an
     * item is found that generates an item in the kernel of the second, the
     * first list is scanned to collect similar items that contribute to that
     * kernel. Such items are marked so as not to be visited again.
     *
     * There are no undefined nonterminals to worry about here.
     */

    private void build_lle(int[][] chaintable, int hole, IntSet[] llrules){
        if ((FL_E & this.trc) != 0){
            Trc.out.println("build_lle");
        }
        //this.mode |= CHAIN_RULES;
        if ((BASIC & this.mode) == 0){
            if ((CHAIN_RULES & this.mode) == 0){
                if ((FORCED & this.mode) == 0){
                // it seems perhaps that I have enabled it because it is reasoneable to have
                // it as default or because it was simpler for the test ...
                    this.mode |= CHAIN_RULES | SINGLETON_RULES;
                }
            }
        }
        //Trc.out.println((this.mode & (CHAIN_RULES | SINGLETON_RULES)) != 0);
        //this.mode &= ~CHAIN_RULES;
        //this.mode |= SINGLETON_RULES;
        //this.mode |= NO_LOOKAHEADS;

        this.tab.mode = this.mode;                      // remember the mode in the tables
        if ((FL_E & this.trc) != 0){
            traceGenMode();
        }

        tab.chaintokens = new boolean[tab.numOfRules+1];

        ParserTables tab = this.tab;                    // reference to tables object
        tab.chaingroups = true;

        boolean[] nonchain = new boolean[this.ntNum];   // nts referred in nonchain rules
        int[] ruletok = new int[tab.ruleBase];          // last rule for unit tokens

        int[] chaintmp = new int[tab.ruleBase*2+1];
        dot = new int[100];
        sub = new int[100];
        for (int i = 0; i < this.ntNum; i++){           // scan all nonterminals
            ParserDic h = this.ntTab[i];
            int num = h.ntNum;
            if ((GES & this.mode) != 0){
                if (i > 0 && h == this.ntTab[i-1]){     // Ae
                    num++;
                }
            }
            if ((FL_E & this.trc) != 0){
                Trc.out.printf("processing nt: %s\n",tab.gramSymToString(num));
            }

            boolean haspri = hasPrios(num);

            this.enditem = 0;                           // first free entry
            this.end1list = Integer.MAX_VALUE;
            for (int rulenr = tab.ntToRule[num];        // scan all alternatives
                (rulenr < tab.numOfRules + 1) &&
                (tab.ruleToNt[rulenr] == num); rulenr++){
                additem(rulenr,0,0);                    // insert an item for each rule
            }
            //if (!tab.chaingroups){
            //    if (tab.ntKind[num] != 0){       // a group
            //        nonchain[num] = true;
            //    }
            //}

            // there is a need to check better that a group does not really have
            // chain tables

            if ((FL_E & this.trc) != 0){
                Trc.out.println("first kernel built");
            }

            boolean singsing = false;
            clo: if ((CHAIN_RULES & this.mode) != 0){
                if ((SINGLETON_RULES & this.mode) != 0){
                    if (this.enditem > 1) break clo;   // more than one item added
                }
                if (haspri){
                    if ((FL_E & this.trc) != 0){
                        Trc.out.printf("build_lle skip, priorities\n");
                    }
                    break clo;
                }

                int enditm = this.enditem;
                for (int cur = 0; cur < this.enditem; cur++){  // perform the closure
                    if (this.dot[cur] < 0) continue;           // invalidated
                    int sy = tab.grammar[
                        tab.ruleIndex[this.dot[cur]]];         // first symbol of rule
                    if ((FL_E & this.trc) != 0){
                        Trc.out.printf("build_lle closure %s dot %s\n",
                            tab.gramSymToString(sy),this.dot[cur]);
                    }
                    add: if ((sy < tab.tokBase) &&                  // nonterminal
                        (tab.ruleLen[this.dot[cur]] == 1)){    // a unit rule
                        if (!tab.chaingroups){
                            // do not chain reduce groups
                            if (tab.ntKind[sy] != 0){
                                if ((FL_E & this.trc) != 0){
                                    Trc.out.printf("build_lle skip group %s\n",tab.gramSymToString(sy));
                                }
                                continue;
                            }
                        }

                        if (hasPrios(sy)){
                            this.enditem = enditm;
                            if ((FL_E & this.trc) != 0){
                                Trc.out.printf("build_lle abort nt %s\n",this.enditem);
                            }
                            for (int curr = 0; curr < this.enditem; curr++){  // remove invalid marks
                                this.dot[curr] &= 0x7fffffff;
                            }
                            break;
                        }
                        int rn = 0;
                        for (int rulenr = tab.ntToRule[sy];    // add all the rules of ..
                            (rulenr < tab.numOfRules + 1) &&   // .. that nonterminal
                            (tab.ruleToNt[rulenr] == sy); rulenr++){
                            additem(rulenr,0,0);
                            if ((SINGLETON_RULES & this.mode) != 0){
                               rn++;
                            }
                        }
                        int rlen = tab.ruleLen[this.dot[cur]];
                        this.dot[cur] |= 0x80000000;           // invalidate current
                        if ((SINGLETON_RULES & this.mode) != 0){
                            if ((rn != 1) || (rlen != 1)){   // several rules or not a unit rule
                                break clo;
                            }
                        }
                    }
                }
                singsing = true;
            } // clo

            if ((SINGLETON_RULES & this.mode) != 0){
                // this is not clear: singing = false when there are more than one rule for the
                // nonterminal, or rules that are not unit rules, but this refers to a single item.
                // We could have in the kernel several items. We set chaintokens = true for all the
                // rules that have a rhs that is a token. But why do not we do it when there is only
                // one such rule?
                if (!singsing){
                    for (int cur = 0; cur < this.enditem; cur++){  // do not reduce unit token rules
                        if (this.dot[cur] < 0) continue;           // invalidated
                        int rulenr = this.dot[cur];
                        if ((FL_E & this.trc) != 0){
                            Trc.out.println("??: " + cur + " " + itemToString(cur));
                        }
                        if (tab.ruleLen[rulenr] == 1){             // unit rule
                            if (tab.grammar[tab.ruleIndex[rulenr]]
                                >= tab.tokBase){
                                tab.chaintokens[rulenr] = true;
                                if ((FL_E & this.trc) != 0){
                                    Trc.out.printf("chaintokens %s true\n",rulenr);
                                }
                            }
                        }
                    }
                }
            }

            int endFirst = this.enditem;
            this.end1list = this.enditem;
            if (!tab.chaingroups){
                if (tab.ntKind[num] == 0){
                    build_ctable(h,hole,chaintable,ruletok,chaintmp);  // build chain-end
                }
            } else {
                build_ctable(h,hole,chaintable,ruletok,chaintmp);  // build chain-end
            }
            for (int cur = 0; cur < endFirst; cur++){          // determine ll
                if (this.dot[cur] < 0) continue;               // invalidated
                int rulenr = this.dot[cur];
                if ((CHAIN_RULES & this.mode) != 0){
                    tk: if (tab.ruleLen[rulenr] == 1){         // unit rule
                        int sy = tab.grammar[tab.ruleIndex[rulenr]];
                        if (sy >= tab.tokBase){                // unit token
                            if (tab.chaintokens[rulenr]) break tk;
                            if (ruletok[sy] != rulenr){        // rule discarted by
                                if ((FL_E & this.trc) != 0){   // .. ambiguity resolution
                                    Trc.out.println("discarted: " +
                                        itemToString(cur));
                                }
                                continue;
                            }
                        }
                    }
                }

                if ((FL_E & this.trc) != 0){
                    Trc.out.printf("build_lle llrules\n");
                }
                if (llrules[num] == null){                  // store rule for
                    llrules[num] = new IntSet(rulenr);      // .. this nt
                } else {
                    llrules[num].add(rulenr);
                }
                for (int j = tab.ruleIndex[rulenr];; j++){  // scan rule
                    int sy = tab.grammar[j];
                    if (sy >= tab.ruleBase) break;          // end
                    if (sy < tab.tokBase){                  // nonterminal
                        if ((FL_E & this.trc) != 0){
                            Trc.out.println("  marked: " +
                               tab.symToString(sy));
                        }
                        nonchain[sy] = true;                // referred by a ..
                    }                                       // .. nonchain rule
                }
            }
        }

        for (int i = 0; i < nonchain.length; i++){    // remove useless ll tables
            if (!nonchain[i]){                        // referred to by no table
                if ((FL_E & this.trc) != 0){
                    Trc.out.println("removing ll: " + tab.symToString(i));
                }
                llrules[i] = null;
            }
        }

        if ((FL_E & this.trc) != 0){
            Trc.out.println("LL rules:");
            /*
            for (int i = 0; i < this.ntNum; i++){     // scan all nonterminals
                ParserDic h = this.ntTab[i];
                Trc.out.printf("llrules ??? %d: %s num %d %s\n",i,h,h.ntNum,tab.gramSymToString(i));
            }
            for (int i = 0; i < this.ntNum; i++){     // scan all nonterminals
                ParserDic h = this.ntTab[i];
                Trc.out.println("llrules for: " + h);
                if (llrules[h.ntNum] == null){
                    Trc.out.println("  null");
                    continue;
                }
                int[] arr = llrules[h.ntNum].toArray();
                int setsize = (int)(llrules[h.ntNum].size());
                for (int k = 0; k < setsize; k++){
                    Trc.out.println("  -> " +
                        tab.ruleToString(tab.ruleIndex[arr[k]],
                        false));
                }
            }
            */
            for (int i = 0; i < tab.ntToRule.length; i++){     // scan all nonterminals
                Trc.out.printf("llrules for: %s\n",tab.gramSymToString(i));
                if (llrules[i] == null){
                    Trc.out.println(" null");
                    continue;
                }
                int[] arr = llrules[i].toArray();
                int setsize = (int)(llrules[i].size());
                for (int k = 0; k < setsize; k++){
                    Trc.out.println("  -> " +
                        tab.ruleToString(tab.ruleIndex[arr[k]],
                        false));
                }
            }

            Trc.out.println("chain-end tables:");
            for (int j = 0; j < this.ntNum; j++){
                Trc.out.printf("%s: %s\n",j,tab.gramSymToString(j));
                int[] ctable = chaintable[j];
                if (ctable == null){
                    Trc.out.printf("    null\n");
                    continue;
                }
                for (int k = 1; k < ctable.length; k++){
                    int sy = ctable[k];
                    int el = ctable[++k];
                    int weight = el >>> 16;
                    el &= 0xffff;
                    Trc.out.printf("   %s: %s weight %s\n",tab.gramSymToString(sy),
                        tab.ruleToString(tab.ruleIndex[el],false),
                        weight);
                }
            }
            Trc.out.println("build_lle end");
        }
        ntChainClasses(llrules);                // build chain classes
    }

    private boolean hasPrios(int nt){
        boolean res = false;
        if (this.tab.priLocs.length > 0){
            for (int rulenr = tab.ntToRule[nt];                // check that all rules of ..
                (rulenr < this.tab.numOfRules + 1) &&          // .. that nonterminal do not ..
                (this.tab.ruleToNt[rulenr] == nt); rulenr++){  // .. have priorities
                int end = tab.ruleIndex[rulenr] + tab.ruleLen[rulenr];
                int p = Arrays.binarySearch(                   // index of prio in priVals
                    tab.priLocs,end);
                if (p >= 0){
                    res = true;
                    break;
                }
            }
        }
        if ((FL_E & this.trc) != 0){
            Trc.out.printf("hasPrios %s %s\n",this.tab.gramSymToString(nt),res);
        }
        return res;
    }

    /**
     * Build the chain equivalence classes. Each class is made by a nonterminal
     * and the ones that are at the LHS of its applicable rules. When a nonterminal
     * has only unit rules, its name appears in their class even if it is never
     * used as such. This, however, does not make any harm.
     *
     * @param   llrules vector of the applicable rules
     */

    // then rekon the vector for classes in the parserables size
    private void ntChainClasses(IntSet[] llrules){
        int[] pset = new int[this.ntNum];         // path halving set number
        int[] psize = new int[this.ntNum];        // path halving set size
        for (int i = 0; i < this.ntNum; i++){     // initialise
            pset[i] = i;                          // p(v) = v
            psize[i] = 1;                         // size(v) = 1
        }
        int r = 0;
        for (int i = 0; i < this.ntNum; i++){     // visit edges then
            if (llrules[i] == null){              // no edges
                continue;
            }
            int[] arr = llrules[i].toArray();
            for (int k = 0; k < arr.length; k++){
                int n1 = i;
                int n2 = tab.ruleToNt[arr[k]];
                if ((FL_E & this.trc) != 0){
                    Trc.out.printf("now: %s to %s%n",
                        this.tab.ntLitName(n1),this.tab.ntLitName(n2));
                }
                if (n1 == n2){                    // self-loop
                    if ((FL_E & this.trc) != 0){
                        Trc.out.println("self-loop");
                    }
                    continue;
                }
                int root1 = n1;                   // determine first root
                while ((r = pset[pset[root1]]) != pset[root1]){
                    pset[root1] = r;
                    root1 = r;
                }
                root1 = pset[root1];
                int root2 = n2;                   // determine second root
                while ((r = pset[pset[root2]]) != pset[root2]){
                    pset[root2] = r;
                    root2 = r;
                }
                root2 = pset[root2];
                if (root1 == root2){              // already connected
                    continue;
                }
                if (psize[root1] < psize[root2]){     // first smaller
                    pset[root1] = root2;              // attach to second
                    psize[root2] += psize[root1];
                    if ((FL_E & this.trc) != 0){
                        Trc.out.printf("join %s %s%n",
                            this.tab.ntLitName(root1),this.tab.ntLitName(root2));
                    }
                } else {                              // second smaller
                    pset[root2] = root1;
                    psize[root1] += psize[root2];
                    if ((FL_E & this.trc) != 0){
                        Trc.out.printf("join %s %s%n",
                            this.tab.ntLitName(root2),this.tab.ntLitName(root1));
                    }
                }
            }
        }
        if ((FL_E & this.trc) != 0){
            Trc.out.println("pset " + Arrays.toString(pset));
        }
        int[] comps = new int[this.ntNum];        // component numbers
        for (int i = 0; i < this.ntNum; i++){
            comps[i] = -1;
        }
        int n = 0;                                // label nodes
        for (int i = 0; i < this.ntNum; i++){
            int root = i;                         // determine root
            while ((r = pset[pset[root]]) != pset[root]){
                pset[root] = r;
                root = r;
            }
            root = pset[root];
            if (comps[root] >= 0){                // already assigned
                comps[i] = comps[root];
            } else {
                comps[i] = n;
                comps[root] = n++;
            }
        }
        this.tab.chainClasses = new char[this.ntNum];
        for (int i = 0; i < this.ntNum; i++){
            this.tab.chainClasses[i] = (char)comps[i];
        }
        this.tab.chainClassesNr = n;
        if ((FL_E & this.trc) != 0){
            for (int i = 0; i < n; i++){          // trace the classes
                Trc.out.printf("class: %d",i);
                for (int j = 0; j < this.ntNum; j++){
                    if (this.tab.chainClasses[j] == i){
                        Trc.out.printf(" %s",this.tab.ntLitName(j));
                    }
                }
                Trc.out.printf("%n");
            }
        }
    }

    /**
     * Deliver a string representing the specified item.
     *
     * @param   itm index of the item
     */

    private String itemToString(int itm){
        int dt = this.dot[itm];
        if (dt < 0) dt &= 0x7ffffff;
        int dot = this.tab.ruleIndex[dt];
        if (itm >= this.end1list){         // in the second list
            dot += this.tab.ruleLen[dt];
        }
        return itm + ": " +
            this.tab.ruleToString(dot,true) +
            ", " + this.sub[itm] + (this.dot[itm] < 0 ? "*" : "");
    }

    /**
     * Add an item to the current list. If an item with the same dot
     * (ruleNr here) is already present, do not insert a new one,
     * but determine which subpointer wins between the one already
     * present and the new one.
     *
     * @param   dt dot value
     * @param   su subpointer value
     * @param   start start index of the current list
     */

    private int additem(int dt, int su, int start){
        int itm;
        done: {
            for (int i = start; i < this.enditem; i++){
                if ((this.dot[i] & 0x7fffffff) == dt){  // found
                    if (this.sub[i] != su){             // ambiguous
                        int rule = this.dot[this.sub[i]];
                        int rule1 = this.dot[su];
                        if (resolveAmbig(this.sub[i],su)){
                            this.sub[i] = su;           // second wins
                        }
                    }
                    itm = i;
                    break done;
                }
            }
            int curlen = this.dot.length;         // create new item
            if (this.enditem == curlen){          // extend array for items list
                int newlen = curlen + 100;
                if (newlen < 0){
                    this.lex.message(ParserLexer.ERR_EXCPRS,
                        null,ParserLexer.MSG_AT_EOF);
                    throw this.lex.excObj;
                }
                int[] p = new int[newlen];
                System.arraycopy(this.dot,0,p,0,curlen);
                this.dot = p;
                p = new int[newlen];
                System.arraycopy(this.sub,0,p,0,curlen);
                this.sub = p;
            }
            itm = this.enditem++;                 // advance item count
            this.dot[itm] = dt;                   // store values
            this.sub[itm] = su;
        } // done
        if ((FL_E & this.trc) != 0){
            Trc.out.println("additem: " + itemToString(itm));
        }
        return itm;
    }

    /**
     * Determine which rule wins between two that can apply and whose
     * match is represented by two items.
     *
     * @param   su index of the first item
     * @param   su1 index of the second item
     * @return  <code>true</code> if the second rule wins
     */

    private boolean resolveAmbig(int su, int su1){
        int rule = this.dot[su];
        int rule1 = this.dot[su1];
        if ((FL_E & this.trc) != 0){
            Trc.out.println("resolveAmbig: " + rule + " " + rule1);
        }
        ParserTables tab = this.tab;             // reference to tables object
        int dot = tab.ruleIndex[rule] + 1;       // dot of end rule
        int dot1 = tab.ruleIndex[rule1] + 1;
        int pri = 0;
        int pri1 = 0;
        boolean priosPres = false;
        if (tab.priLocs.length > 0){
            int p = Arrays.binarySearch(         // index of prio in priVals
                tab.priLocs,dot);
            if (p >= 0){
                pri = tab.priVals[p];            // priority of first choice
                priosPres = true;
            }
            p = Arrays.binarySearch(
                tab.priLocs,dot1);
            if (p >= 0){
                pri1 = tab.priVals[p];           // priority of second choice
                 priosPres = true;
            }
        }
        if ((FL_E & this.trc) != 0){
            Trc.out.printf("resolve:  %s %s prios %s %s dots %s %s\n",
                tab.ruleToString(dot,false),
                tab.ruleToString(dot1,false),
                pri,pri1,dot,dot1);
        }
        boolean second = dot1 < dot;
        if (priosPres){
            second = pri1 > pri;
            if ((FL_E & this.trc) != 0){
                Trc.out.printf("second %s\n",second);
            }
        }
        win: if (second){
            if ((FL_E & this.trc) != 0){
                Trc.out.println("second wins");
            }
            for (int i = su1; i != 0; i = this.sub[i]){
                if (su == i) break win;          // old contained in new
            }                                    // .. keep old, i.e. shorter
            return true;
        }
        return false;
    }

    /**
     * Build the chain-end table of a nonterminal out of the closure of
     * the items list of its rules with respect to those that are unit rules.
     * It stores also the last unit rule that leads to tokens according to
     * ambiguity resolution. It serves to eliminate doublets from the LL
     * tables.
     *
     * @param   h reference to the nonterminal
     * @param   hole hole value for the table
     * @param   chaintable array of all chain-end tables
     * @param   ruletok array that records the last rule in the chain from
     *          h to the unit token in index (if such a rule exists)
     * @param   chaintmp temporary array to build chain tables
     */

    /* It takes all items which have a nonnegative entry, they are the ones
     * for non-chain rules or unit token rules, and simulate the completion
     * for each of them. The kernel is made by all items which have a rule with
     * the same LHS, or, for unit token rules, the same token.
     * When the nonterminal for this items list has no chain rules, no
     * completions are done, and the chain-end table is not built.
     * A special case occurs when there is a unit token rule because in
     * such a case the chain-end entry must be set anyway, as if a completion
     * had been done.
     * Since there is no item which has the dot in front of the top
     * nonterminal to complete, there is a need to remember the completers
     * and to solve ambiguity when there are many.
     * It does not initialize ruletok because it is consulted only for the
     * elements that are written here.
     */

    private void build_ctable(ParserDic h, int hole,
        int[][] chaintable, int[] ruletok, int[] chaintmp){
        ParserTables tab = this.tab;                    // reference to tables object
        if ((FL_E & this.trc) != 0){
            Trc.out.printf("build_ctable start %s\n",h);
        }

        // this is not done so as to spare it when there is no chain
        // What is the difference? its base would be -1, and not if it is
        // created below
        //   chaintable[h.ntNum] = new int[tab.ruleBase];
        //   Arrays.fill(chaintable[h.ntNum],hole);

        int[] ctable = chaintmp;
        int clength = 0;
        int start = this.enditem;
        for (int cur = 0; cur < start; cur++){          // build chain-ends
            if (this.dot[cur] < 0) continue;            // invalidated
            if (this.sub[cur] < 0) continue;            // already visited
            int rulenr = this.dot[cur];
            int sy = tab.ruleToNt[rulenr];              // LHS of this rule
            un: {
                if (tab.ruleLen[rulenr] == 1){          // unit rule
                    int s = tab.grammar[tab.ruleIndex[rulenr]];
                    if (s >= tab.tokBase){
                        if (tab.chaintokens[rulenr]) break un;
                        sy = s;                         // unit token rule
                        break un;
                    }
                }
                if (sy == h.ntNum) continue;            // top-level item
            }

            if ((FL_E & this.trc) != 0){
                Trc.out.println("kernel for: " + tab.gramSymToString(sy));
            }
            // build the kernel of the second list
            this.enditem = start;                       // initialize second list
            additem(rulenr,0,start);                    // simulate final item
            for (int j = cur+1; j < start; j++){        // add all other
                if (this.dot[j] < 0) continue;          // .. items with the
                rulenr = this.dot[j];                   // .. same symbol
                int sym = tab.ruleToNt[rulenr];         // LHS
                if (tab.ruleLen[rulenr] == 1){
                    int s = tab.grammar[tab.ruleIndex[rulenr]];
                    if (s >= tab.tokBase){              // token here
                        if (!tab.chaintokens[rulenr]){
                            sym = s;
                        }
                    }
                }
                if (sym != sy) continue;
                additem(rulenr,0,start);                // simulate final item
                this.sub[j] = -1;                       // no longer visit it
            }
            int kernel = this.enditem;                  // end of kernel
            if ((FL_E & this.trc) != 0){
                Trc.out.println("end kernel");
            }
            int endcompl = -1;
            for (int j = start; j < this.enditem; j ++){   // closure of completion
                if ((FL_E & this.trc) != 0){
                    Trc.out.println("completions for: " +
                        itemToString(j));
                }
                boolean added = false;
                int nt = tab.ruleToNt[this.dot[j]];     // LHS of this item
                for (int k = 0; k < start; k ++){       // seek items to complete
                    rulenr = this.dot[k];
                    if (rulenr >= 0) continue;          // and end rule
                    rulenr &= 0x7fffffff;
                    int sym = tab.grammar[tab.ruleIndex[rulenr]];
                    if (sym == nt){                     // complete it
                        int itm = additem(rulenr,j,start);
                        if (sym == h.ntNum){
                            endcompl = this.sub[itm];
                        }
                        added = true;
                    }
                }
                if (!added){                            // top item
                    if (endcompl < 0){                  // not yet encountered
                        endcompl = j;
                    } else {                            // ambiguous
                        if (resolveAmbig(endcompl,j)){
                            endcompl = j;               // second wins
                        }
                    }
                }
            }
            if ((FL_E & this.trc) != 0){
                Trc.out.println("endcompl: " + endcompl);
            }
            ce: if ((this.enditem > kernel) ||          // some completions done
                // this test to be removed if chain-ends no tokens
                (sy >= tab.tokBase)){                   // unit token
                if (clength == 0){
                    Arrays.fill(ctable,hole);
                }
                int weight = 0;                         // determine path to chain-end
                for (int j = endcompl; j != 0; j = this.sub[j]){
                    if ((FL_E & this.trc) != 0){
                        Trc.out.println("path: " + itemToString(j));
                    }
                    if (this.sub[j] == 0){              // last one
                        if (sy >= tab.tokBase){         // chain-end is token
                            ruletok[sy] = this.dot[j];  // remember last rule
                            // this is to remove unit token rules in chain-ends
                            // but there is a need to measure how much it slows down
                            // break ce;
                        } else {
                            break;                      // do not count last one
                        }
                    }
                    int s = tab.ruleToNt[this.dot[j]];
                    if (tab.chaingroups){
                        if (s < tab.tokBase){
                            if ((tab.ntKind[s] == ParserTables.OPT) || // optional group
                                (tab.ntKind[s] == ParserTables.OBO)){ // optional body
                                continue;
                            }
                        }
                    }
                    int w = 2;
                    if (s >= tab.ntNrGroups) w++;   // a group
                    weight += w;
                    if (weight > Character.MAX_VALUE){
                        this.lex.message(ParserLexer.ERR_EXCPRS,
                            null,ParserLexer.MSG_AT_EOF);
                        throw this.lex.excObj;
                    }
                }
                rulenr = this.dot[endcompl];            // rule of top nt that
                if ((FL_E & this.trc) != 0){            // .. starts the path
                    Trc.out.println("chain-end: " +
                        tab.gramSymToString(sy) + " <- " +
                        tab.ruleToString(this.tab.ruleIndex[rulenr],
                            false) + " " + weight);
                }
                ctable[sy] = rulenr | (weight << 16);   // store rule and weight
                clength++;
            }
        }
        if (clength > 0){                               // create pairs
            int[] cpairs = new int[clength*2+1];
            cpairs[0] = tab.ruleBase;
            clength = 1;
            for (int j = 0; j < ctable.length; j++){
                if (ctable[j] != hole){
                    cpairs[clength++] = j;
                    cpairs[clength++] = ctable[j];
                }
            }
            chaintable[h.ntNum] = cpairs;
            if ((FL_E & this.trc) != 0){
                Trc.out.printf("chain pairs for %s\n",h);
                for (int i = 1; i < cpairs.length; i += 2){
                    int rulenr = cpairs[i+1] & 0xffff;
                    Trc.out.printf("%s: %s rule %s\n",
                        cpairs[i],tab.gramSymToString(cpairs[i]),
                        tab.ruleToString(this.tab.ruleIndex[rulenr],
                            false));
                }
            }
        }
        if ((FL_E & this.trc) != 0){
            Trc.out.printf("build_ctable end %s\n",h);
        }
    }

    /**
     * Build the LL table of each nonterminal out of the sets of rules headed
     * by tokens. The table has the index,value pairs format.
     * Build also the hashtable of the rulesets. Mark each nonterminal as
     * LL1 if there is at most one rule applicable for each token.
     * Mark the grammar as LL1 is all nonterminals are so.
     *
     * @param   llrules vector of the applicable rules of each nonterminal
     * @param   llvect return tables
     * @param   rtable return hashtable of the rulesets
     */

    /* It scans all nonterminals. Each nonterminal i has in llrules[i] a reference to
     * an IntSet of all the rule numbers of it (inlcuding the ones at the end of chains,
     * if chain rules reduction is enabled). Note that the set contains all rules
     * regardless of the tokens headed by them.
     * It takes in turn one such set of rules, and the directors for the rules, which
     * is the IntSet of all the tokens that start each rule.
     * It builds an array, indexed by tokens, of the rules applicable for each token
     * by taking a rule in the set, and adding it to the sets of all tokens that have
     * it in their director. I.e. it distributes the rules in llrules[i] over tokens (possibly
     * duplicating them when applicable for several tokens).
     * The object that it creates are then the sets of rules (ruleset's) that are applicable
     * for each token (for the nonterminal at hand).
     * It takes then the rulesets that contain more than one rule, and numbers them sequentially.
     * It builds then an array containing: the number of tokens, then pairs of: token number,
     * rule number (if only one) or negated ruleset number (if several rules applicable).
     */

    private void build_llvect(IntSet[] llrules,
        int[][] llvect, HashBag rtable){
        if ((FL_E & this.trc) != 0){
            Trc.out.println("build_llvect");
        }
        //check_cat();
        this.gram.attr |= ParserNode.LL1;                 // a LL1 grammar
        ParserTables tab = this.tab;
        IntSet[] ruleset = new IntSet[tab.numOfToks+1];   // temp rule sets
        int[] vect = new int[(tab.numOfToks+1)*2+1];      // allocate temp ll
        int[] arr = new int[10];                          // temp rule sets array
        for (int i = 0; i < this.ntNum; i++){             // scan all nonterminals
            ParserDic h = this.ntTab[i];                  // build rulesets for this nonterminal
            int nt = h.ntNum;
            if ((GES & this.mode) != 0){
                if (i > 0 && h == this.ntTab[i-1]){       // Ae
                    nt++;
                }
            }
            if (llrules[nt] == null) continue;
            if ((NO_LOOKAHEADS & this.mode) != 0){
                for (int k = 0; k < ruleset.length; k++){ // all rules of it
                    ruleset[k] = llrules[nt];
                }
            } else {
                for (int k = 0; k < ruleset.length; k++){ // initialize
                    if (ruleset[k] != null) ruleset[k].clear();
                }
                arr = llrules[nt].toArray(arr);           // get rules
                int n = (int)(llrules[nt].size());
                for (int k = 0; k < n; k++){              // scan the rules of ..
                    int rulenr = arr[k];                  // .. this nonterminal
                    byte[] set = this.directors[rulenr];  // enrol this rule
                    if (set == null) continue;            // .. on the tokens of its director
                    if ((FL_E & this.trc) != 0){
                        Trc.out.printf("rule: %s %s\n",
                            this.tab.ruleToString(this.tab.ruleIndex[rulenr],false),
                            termSetToStr(set));
                    }
                    for (int j = 0; j <= tab.numOfToks; j++){
                        if ((set[j >>> 3] & (1 << (j & 0x7))) == 0){
                            continue;
                        }
                        if (ruleset[j] == null){              // store rule that
                            ruleset[j] = new IntSet(rulenr);  // .. leads to this
                        } else {                              // .. token
                            ruleset[j].add(rulenr);
                        }
                        if ((FL_E & this.trc) != 0){
                            Trc.out.printf("... %s rule: %s %s\n",h,j,rulenr);
                        }
                    }
                }
            }

            // create its ll table as index,value pairs and make rulesets
            // unique. Indexes are token numbers and values are positive
            // rule numbers (rulesets with one element only), or negative
            // rulesets numbers

            h.attr |= ParserNode.LL1;
            // what is the use of this? probably because combvector wants it
            vect[0] = tab.numOfToks + 2;               // length
            int num = 1;
            RuleSet r = new RuleSet();
            for (int j = 0; j < ruleset.length; j++){  // scan its rulesets
                if (ruleset[j] == null) continue;
                int n = (int)(ruleset[j].size());
                if (n == 0) continue;
                vect[num++] = j;                       // index: token number
                if (n == 1){
                    int rulenr = ruleset[j].first();
                    // when it is < 0? it seems it is never so
                    if (rulenr >= 0){
                        vect[num++] = rulenr;          // one value
                    }
                    continue;
                } else {                               // several values
                    h.attr &= ~ParserNode.LL1;
                    this.gram.attr &= ~ParserNode.LL1; // not a LL1 grammar
                }
                r.set = ruleset[j];
                RuleSet d = (RuleSet)rtable.search(r);
                if (d == null){                        // not present
                    d = new RuleSet();
                    d.set = new IntSet(r.set,0);
                    d.number = rtable.size();          // number of the ruleset
                    rtable.add(d);
                }
                vect[num++] = -d.number-1;
            }
            int[] table = new int[num];
            System.arraycopy(vect,0,table,0,num);
            llvect[nt] = table;

            if ((FL_E & this.trc) != 0){
                Trc.out.print("llvect: " + h + ":");
                if (llvect[nt] == null){
                    Trc.out.println(" null");
                    continue;
                }
                for (int k = 0; k < llvect[nt].length; k++){
                    int el = llvect[nt][k];
                    Trc.out.print(" " + el);
                }
                Trc.out.println();
                int[] p = llvect[nt];
                for (int k = 1; k < p.length; k++){
                    int idx = p[k++];
                    Trc.out.print(tab.tokLitName(idx) + " -> ");
                    if (p[k] >= 0){
                        Trc.out.println(tab.ruleToString(tab.ruleIndex[p[k]],
                            false));
                    } else {
                        int l = -p[k] - 1;
                        Trc.out.println(l);
                    }
                }
            }
        }
        if ((FL_E & this.trc) != 0){
            rtable.trace();
            Trc.out.println("build_llvect end");
        }
    }

    /**
     * Try to fit the rulesets in the merge table of a comb vector.
     *
     * @param   llvect ll tables in index.value form
     * @param   rmap map of the rulesets
     * @param   comb comb vector
     * @return  new merge table, <code>null</code> if fit not possible
     */

    /* In order to store shared rulesets only once, rulesets are allocated
     * at an index which is higher than the highest base index among those
     * of the referring tables. They cannot be allocated stright at the
     * highest base index because the offset must be stored as a negative
     * value, and thus cannot be zero. To do it, rulesets are visited and
     * the highest base recorded in them.
     * When allocating a ruleset, the piece of the table starting at its
     * (highest) referring table index are visited, and a best fit searched.
     * When a hole that can contain it is found: if the hole has exactly the
     * right size, the search stops; otherwise, if it has a size which is
     * lower than that of the last remembered it replaces the remembered one.
     * To cater for holes at the end of the merge table, the last non-hole
     * element is found, and the remaining part considered as free.
     * Rulesets that cannot fit in the table are allocated at the end. It is
     * sufficient to keep a location counter and simulate the allocation.
     * After all rulesets have been allocated, the table is enlarged and the
     * ones to be appended are copied at the end of it.
     *
     * In the comb vector other tables are stored besides the strict ll ones.
     * However, only the check vector is needed for these other tables.
     * To fit them, the comber needs to write their values in the merge table.
     * Such a merge table has less holes than the actual ones. For optimal
     * use of holes, the merge table is cloned right after combing the first
     * tables, and used then to fit the rulesets.
     */

    private int[] fit_rulesets(int[][] llvect, RuleSet[] rmap,
        CombVector comb){
        if ((FL_E & this.trc) != 0){
            Trc.out.printf("fit_rulesets\n");
        }

        int[] merge = new int[comb.tabMerged.length];
        System.arraycopy(comb.tabMerged,0,merge,  // make a copy of the merge table
            0,comb.tabMerged.length);
        int hole = comb.holeValue;
        for (int i = 0; i < llvect.length; i++){  // determine highest table ..
            int[] p = llvect[i];                  // .. for rulesets
            if (p == null) continue;
            for (int k = 1; k < p.length; k++){
                int v = p[++k];
                if (v < 0){
                    v = -v - 1;
                    if (rmap[v].index < comb.base[i]){
                        rmap[v].index = comb.base[i];
                    }
                }
            }
            if ((FL_E & this.trc) != 0){
                Trc.out.println("base: " + this.tab.ntLitName(i) +
                    " " + comb.base[i]);
            }
        }
        int extend = merge.length;
        for (int i = merge.length-1; i >= 0; i--){
            if (merge[i] != hole){                // determine end of ..
                extend = i + 1;                   // .. used part
                break;
            }
        }
        if ((FL_E & this.trc) != 0){
            Trc.out.println("comb size: " + merge.length +
                " end used: " + extend);
        }
        int endused = extend;
        int[] arr = new int[10];
        for (int j = 0; j < rmap.length; j++){    // fit then the rulesets ..
            RuleSet i = rmap[j];                  // .. one by one
            int bestfit = Integer.MAX_VALUE;
            int fitindex = -1;
            int setsize = (int)(i.set.size()) + 1;
            if ((FL_E & this.trc) != 0){
                Trc.out.println("fitting: " + i + " " + setsize);
            }
            int end = endused;                    // determine end of allowed place

            for (int k = i.index+1; k < end; k++){   // find a hole, ..
                if ((k-i.index) == hole) continue;   // .. do not use offset 0, ..
                if (merge[k] == hole){               // .. it cannot be negated, ..
                    int w = k+1;                     // .. and values that are holes
                    for (; w < end; w++){
                        if (merge[w] != hole) break;
                    }
                    w -= k;
                    if ((FL_E & this.trc) != 0){
                        Trc.out.println("hole: " + k + " " + w);
                    }
                    if (w == setsize){               // found the right one
                        fitindex = k;
                        break;
                    } else if ((w > setsize) && (w < bestfit)){
                        fitindex = k;                // remember the best
                        bestfit = w;
                    }
                }
            }
            if ((FL_E & this.trc) != 0){
                Trc.out.println("fitindex " + fitindex +
                    " end " + end + " extend " + extend +
                    " endused " + endused);
            }
            app: if (fitindex < 0){                  // no place found
                if (end == endused){                 // could be appended
                    fitindex = extend;               // append
                    break app;
                }
                return null;                         // never occurs
            }
            i.index = fitindex;
            if (fitindex < endused){                 // within the table
                arr = i.set.toArray(arr);            // copy the set
                unitTokenSort(arr,setsize-1);
                merge[fitindex++] = --setsize;       // number of rules
                for (int k = 0; k < setsize; k++){
                    merge[fitindex++] = arr[k];      // store rules
                }
            } else {                                 // appended: do it later
                fitindex = extend;
                extend += setsize;
            }
        }
        for (int i = 0; i < llvect.length; i++){     // store offsets now
            int[] p = llvect[i];
            if (p == null) continue;
            for (int k = 1; k < p.length; k++){
                int idx = p[k++];                    // token nr.
                int v = p[k];
                if (v < 0){
                    v = -v - 1;
                    int off = comb.base[i] - rmap[v].index;
                    merge[comb.base[i] + idx] = off; // rewrite value in the merge table

                    /* code to flag the references to tables that contain a mixture
                       of rules of different nonterminals. Not used because that happens
                       in the majority of cases, and therefore is of little use to the
                       predictor

                    if ((CHAIN_RULES & this.mode) != 0){
                        if ((FL_E & this.trc) != 0){
                            Trc.out.printf("fit mixed: %s%n",this.tab.ntLitName(i));
                        }
                        int setsize = (int)(rmap[v].set.size());
                        arr = rmap[v].set.toArray(arr);            // copy the set
                        for (int j = 0; j < setsize; j++){
                            if (this.tab.ruleToNt[arr[j]] != i){
                                if ((FL_E & this.trc) != 0){
                                    Trc.out.printf("fit mixed->: %s%n",
                                        this.tab.ruleToString(tab.ruleIndex[arr[j]],false));
                                }
                                break;
                            }
                        }
                    }
                    */

                }
            }
        }
        if ((FL_E & this.trc) != 0){
            Trc.out.println("extend: " + extend + " " +
                merge.length);
        }
        if (merge.length >= extend){            // table already larger ..
            extend = merge.length;              // .. all sets within it
        }
        // why do I create a new array? the idea was to fit the tables in the comb
        int[] latable = new int[extend];        // allocate return table
        for (int i = 0; i < merge.length; i++){ // copy table (including holes ..
            latable[i] = merge[i];              // .. at the end)
        }

        for (int j = 0; j < rmap.length; j++){  // append the rulesets that
            RuleSet i = rmap[j];                // .. go at the end
            if (i.index >= endused){
                if ((FL_E & this.trc) != 0){
                    Trc.out.println("appending: " + i);
                }
                int setsize = (int)(i.set.size()) + 1;
                arr = i.set.toArray(arr);       // copy the set
                unitTokenSort(arr,setsize-1);
                int fitindex = i.index;
                latable[fitindex++] = --setsize;    // number of rules
                for (int k = 0; k < setsize; k++){
                    latable[fitindex++] = arr[k];   // store rules
                }
            }
        }
        return latable;
    }

    /**
     * Reorder an array of rules putting first a unit token rule, if
     * any is present in it.
     *
     * @param   arr array
     * @param   size number of significant elements
     */

    private void unitTokenSort(int[] arr, int size){
        ParserTables tab = this.tab;
        int u = -1;
        int rulenr = 0;
        for (int i = 0; i < size; i++){               // find unit token rule
            rulenr = arr[i];
            int ruleIndex = tab.ruleIndex[rulenr];
            if ((tab.ruleLen[rulenr] == 1) &&
                (tab.grammar[ruleIndex] >= tab.tokBase)){  // unit token rule
                u = i;
                break;
            }
        }
        if (u <= 0) return;                           // not present or already first
        if ((FL_E & this.trc) != 0){
            Trc.out.println("unitTokenSort before");
            for (int i = 0; i < size; i++){
                Trc.out.printf("i: %d %s%n",i,
                    tab.ruleToString(tab.ruleIndex[arr[i]],false));
            }
        }
        System.arraycopy(arr,0,arr,1,u);              // move the ones before
        arr[0] = rulenr;                              // put the unit token rule first
        if ((FL_E & this.trc) != 0){
            Trc.out.println("unitTokenSort after");
            for (int i = 0; i < size; i++){
                Trc.out.printf("i: %d %s%n",i,
                    tab.ruleToString(tab.ruleIndex[arr[i]],false));
            }
        }
    }

    /**
     * Trasform the ll tables in the index,value form with rulesets fit
     * in the merge table into ll tables with rulesets appended to each
     * table.
     *
     * @param   llvect ll tables in index.value form
     * @param   rmap map of the rulesets
     */

    /* There is a need to append to the table of each nonterminal the rulesets
     * that are used by it, and to do that only once for each ruleset.
     * This is important because a same ruleset could apply for many terminals.
     * Moreover, there is a need to produce tables in the (index,value) format,
     * with increasing indexes.
     * To do it, we use an array indexed by ruleset numbers in which we first
     * mark the ones used, then we simulate the allocation one by one, and
     * store in it the offsets at which they will be placed. Then we replace
     * in the table at hand rulesets with offsets, and lastly we resize the
     * table and place the rulesets at the end.
     */

    /*
    private void build_llapp(int[][] llvect, RuleSet[] rmap){
        if ((FL_E & this.trc) != 0){
            Trc.out.println("build_llapp tables");
        }
        int[] ruleSetMap = new int[rmap.length];
        int[] arr = new int[10];
        for (int i = 0; i < llvect.length; i++){  // visit the tables and
            int[] p = llvect[i];                  // .. build the new ones
            if (p == null) continue;
            if ((FL_E & this.trc) != 0){
                Trc.out.print("nt: " + this.tab.ntLitName(i) + " " + p[0]);
                for (int k = 1; k < p.length; k++){
                    Trc.out.print(" (" + p[k] + "," + p[++k] + ")");
                }
                Trc.out.println();
            }

            Arrays.fill(ruleSetMap,-1);
            // store 0 in the ruleSetMap entries for rules used
            // in this nonterminal
            for (int k = 1; k < p.length; k++){
                int v = p[++k];
                if (v < 0){
                    v = -v - 1;
                    ruleSetMap[v] = 0;
                }
            }

            // allocate the rulesets and store in ruleSetMap entries
            // their offsets so that they are ordered
            int newlen = p.length;                // determine the length
            int lc = tab.numOfToks + 1;           // indexes of rules in ovf zone
            for (int k = 0; k < ruleSetMap.length; k++){
                if (ruleSetMap[k] < 0) continue;  // not used
                int setsize = (int)(rmap[k].set.size()) + 1;
                ruleSetMap[k] = lc;
                lc += setsize;
                if ((newlen + setsize * 2) < 0){
                    this.lex.message(ParserLexer.ERR_EXCPRS,
                        null,ParserLexer.MSG_AT_EOF);
                    throw this.lex.excObj;
                }
                newlen += setsize * 2;            // rules and their number
            }
            if (newlen == p.length) continue;     // unchanged

            // replace rulesets numbers with their offsets
            for (int k = 1; k < p.length; k++){
                int v = p[++k];
                if (v < 0){
                    v = -v - 1;
                    p[k] = -ruleSetMap[v];        // offset to ovf zone
                }
            }

            // add then the rulesets at the end
            int[] t = new int[newlen];            // allocate new table
            System.arraycopy(p,0,t,0,p.length);
            newlen = p.length;
            for (int k = 0; k < ruleSetMap.length; k++){
                if (ruleSetMap[k] < 0) continue;  // not used
                int setsize = (int)(rmap[k].set.size());
                arr = rmap[k].set.toArray(arr);   // copy the set
                lc = ruleSetMap[k];
                t[newlen++] = lc++;
                t[newlen++] = setsize;            // number of rules
                for (int w = 0; w < setsize; w++){
                    t[newlen++] = lc++;
                    t[newlen++] = arr[w];         // store rules
                }
            }
            t[0] = lc;                            // new length
            llvect[i] = t;
            if ((FL_E & this.trc) != 0){
                Trc.out.print("appended nt: " + this.tab.ntLitName(i) + " " + t[0]);
                for (int k = 1; k < t.length; k++){
                    Trc.out.print(" (" + t[k] + "," + t[++k] + ")");
                }
                Trc.out.println();
            }
        }
    }
    */

    /** A set of rules. */
    private static class RuleSet extends HashNode {

        /** The reference to the next element. */
        private RuleSet suc;

        /** The number of the ruleset. */
        private int number;

        /** The index where it is stored. */
        private int index;

        /** The set of rules. */
        private IntSet set;

        /**
         * Deliver a string representing this ruleset.
         */

        public String toString(){
            return this.number + " " + this.set.toString() + " " + this.index;
        }

        /**
         * Determine if this object is equal to the specified object.
         * It delivers <code>true</code> when the argument is not
         * <code>null</code> and is a <code>RuleSet</code> object that
         * contains the same set.
         *
         * @param   other the object to compare
         * @return  true if equal
         */

        public boolean equals(Object other){
            if (this == other) return true;
            if (other == null) return false;
            RuleSet s = (RuleSet)other;
            return equals(s.set);
        }

        /**
         * Determine if this object contains a set which is equal to
         * the specified one.
         *
         * @param   s set
         */

        public boolean equals(IntSet s){
            return this.set.equals(s);
        }

        /**
         * Return the hashcode for this object.
         *
         * @return  hash code value
         */

        public int hashCode(){
            return this.set.hashCode();
        }
    }

   /**
     * Compute the size of the parsing tables and store it in
     * the engine.
     */

    private void tabSize(){
        ParserTables tab = this.tab;
        long size = 0;
        size += 4 + tab.grammar.length * 2;
        if ((GES & this.mode) == 0){          // no directors, LR tables are used
            size += 4 + tab.latable.length * 4;
            size += 4 + tab.lacheck.length * 2;
            size += 4 + tab.labase.length * 4;
        }

        if (tab.chaintable != null){
            size += 4 + tab.chaintable.length * 2;
            size += 4 + tab.chaincheck.length * 2;
            size += 4 + tab.chainbase.length * 2;
            size += 4 + tab.chainLentable.length * 2;
        }
        size += 4 + tab.ruleToNt.length * 2;
        size += 4 + tab.ntToRule.length * 2;
        size += 4 + tab.ruleLen.length * 2;
        if (tab.chaintable == null){
            size += 4 + tab.singmap.length * 2;
            size += 4 + tab.singsize.length * 2;
        }
        size += 4 + tab.ruleIndex.length * 4;
        size += 4 + tab.ntKind.length;
        size += 4 + tab.nullable.length;
        size += 4 + tab.priLocs.length * 2;
        size += 4 + tab.priVals.length * 2;
        tab.prsSize = size;
    }


    StateTable states;
    private int[] curstate;
    private int[] back;
    private int itmNr;

    private void traceState(){
        for (int i = 0; i < this.itmNr; i++){   // trace its items
            Trc.out.println(sitemToString(i));
        }
    }
    private String sitemToString(int i){
        ParserTables tab = this.tab;
        String s = Integer.toString(i) +
            " [" + tab.ruleToString(this.curstate[i],true) +
            ", " + this.back[i] + "]";
        return s;
    }
    private String sitemToString(int i, int[] itmlist){
        ParserTables tab = this.tab;
        String s = Integer.toString(i) +
            " [" + tab.ruleToString(itmlist[i],true) +
            ", " + this.back[i] + "]";
        return s;
    }

    private static final int QUANTUM = 20;
    private int addItem(int dot, int back, boolean donly){
        int itm = 0;
        int end = this.itmNr;
        int off = -1;
        int[] dt = this.curstate;
        int[] ba = this.back;
        if (donly){
            while ((++off < end) &&          // search duplicates
                (dt[off] != dot));
        } else {
            while ((++off < end) &&          // search duplicates
                ((dt[off] != dot) ||
                (ba[off] != back)));
        }
        if (off < end){                  // already present
            itm = off;
            if (donly){
                this.back[itm] = back;
            }
            if ((FL_E & this.trc) != 0){
                if (donly){
                    Trc.out.println(sitemToString(itm));
                } else {
                    Trc.out.print(itm + " [" + this.curstate[itm] +
                       ", " + this.back[itm] + "]");
                }
                Trc.out.println("already present");
            }
        } else {
            if (this.itmNr >= this.curstate.length){
                int newlen = this.curstate.length + QUANTUM;
                if ((FL_E & this.trc) != 0){
                    Trc.out.println("resize " + newlen);
                }
                if (newlen < 0){
                    throw new OutOfMemoryError();
                }
                int[] n = new int[newlen];
                System.arraycopy(this.curstate,0,n,0,this.curstate.length);
                this.curstate = n;
                n = new int[newlen];
                System.arraycopy(this.back,0,n,0,this.back.length);
                this.back = n;
            }
            this.curstate[this.itmNr] = dot;
            this.back[this.itmNr] = back;
            itm = this.itmNr;
            this.itmNr++;
            if ((FL_E & this.trc) != 0){
                if (donly){
                    Trc.out.println(sitemToString(itm));
                } else {
                    Trc.out.println(itm + " [" + this.curstate[itm] +
                       ", " + this.back[itm] + "]");
                }
            }
        }
        return itm;
    }

    boolean basic;
    private void buildStates(){
        if ((FL_E & this.trc) != 0){
            Trc.out.println("buildStates");
        }
        ParserTables tab = this.tab;         // reference to tables object
        this.states = new StateTable();
        this.states.tab = tab;
        this.curstate = new int[QUANTUM];    // array to build the state
        this.back = new int[QUANTUM];
        this.itmNr = 0;
        boolean edfa = true;
        boolean esplit = true;
        // with edfa = false, the LR(0) states are produced
        // with esplit = false, states are not split

        if ((FL_E & this.trc) != 0){
            Trc.out.print("scanner: ");
        }
        int itm = addHItem(tab.startRule,0,true);
        int ssy = this.ntNum - 1;
        if ((tab.split[ssy >>> ParserTables.NSHIFTB] &
            (1 << (ssy & ParserTables.MASKB))) != 0){ // has an epsilon one
            int serule = tab.startRule + 3;           // second rule of enclosing
            itm = addHItem(serule,0,true);
        }
        closure(edfa);
        if ((FL_E & this.trc) != 0){
            this.traceState();
        }
        addState(esplit);
        State[] gotos = new State[tab.ruleBase];
        State cur = this.states.head;                   // build the next ones
        while (cur != null){
            if ((FL_E & this.trc) != 0){
                Trc.out.println("processing state: " + cur.number);
            }
            Arrays.fill(gotos,null);
            int nextNr = 0;
            cur.director = allocTermSet();
            for (int i = 0; i < cur.items.length; i++){ // scan its items
                int sym = tab.grammar[cur.items[i]];
                if (sym >= tab.ruleBase){               // dot at end
                    cur.director = null;
                    continue;
                }
                if (!this.basic){
                    sym = tab.singmap[sym];
                }
                dir: if (cur.director != null){
                    if (sym >= tab.tokBase){            // token
                        termSetUnion(cur.director,
                            sym - tab.tokBase);
                    } else {
                        termSetUnion(cur.director,
                            this.directorsNt[sym]);
                    }
                }

                if ((FL_E & this.trc) != 0){
                    Trc.out.println("item: " + sitemToString(i,cur.items));
                }
                if (gotos[sym] == null){                // take items for sym
                    this.itmNr = 0;
                    for (int j = i; j < cur.items.length; j++){
                        int s = tab.grammar[cur.items[j]];
                        if (s >= tab.ruleBase) continue;   // dot at end
                        if (!this.basic){
                            s = tab.singmap[s];
                        }
                        if (s != sym) continue;
                        if ((FL_E & this.trc) != 0){
                            Trc.out.print("scanner: ");
                        }
                        itm = addHItem(cur.items[j]+1,0,true);
                    }
                    closure(edfa);
                    if ((FL_E & this.trc) != 0){
                        Trc.out.println("next:");
                        traceState();
                    }
                    gotos[sym] = addState(esplit);
                    nextNr++;
                }
            }
            if (nextNr > 0){
                cur.syms = new int[nextNr];
                cur.nexts = new State[nextNr];
                nextNr = 0;
                for (int i = 0; i < gotos.length; i++){   // store goto
                    if (gotos[i] != null){
                        cur.syms[nextNr] = i;
                        cur.nexts[nextNr++] = gotos[i];
                    }
                }
            }
            // to test performance:
            cur.nextState = (State[])gotos.clone();

            cur = cur.suc;
        }
        this.states.table = new State[this.states.stateNr];
        // build temporary table 
        for (State s = this.states.head; s != null; s = s.suc){
            this.states.table[s.number] = s;
        }
        if ((FL_E & this.trc) != 0){
            Trc.out.println("end build states");
            this.states.trace();
        }
        // then check this with Dragon
        // LR(0) states seems generated properly

        int size = 0;
        int[][] tabs = new int[this.states.stateNr-1][];
        for (int i = 0; i < tabs.length; i++){
            State s = this.states.table[i+1];
            tabs[i] = new int[s.nextState.length];
            for (int j = 0; j < tabs[i].length; j++){
                if (s.nextState[j] != null){
                    tabs[i][j] = s.nextState[j].number;
                }
            }
            for (int j = 0; j < s.items.length; j++){
                int p = s.items[j];
                int sy = tab.grammar[p];
                if (sy < tab.ruleBase) continue;
                size += 2;
            }
        }
        //CombVector c = new CombVector();
        //c.settrc("d");
        //c.combVector(tabs,true,0);
        //Trc.out.println("states: " + this.states.stateNr +
        //" size: " + size);
        //Trc.out.printf("buildStates %d states %d %n",(System.nanoTime() - t0)/1000,this.states.stateNr);
    }

    // add an item, with the dot skipped over all Ae's
    private int addHItem(int dot, int back, boolean donly){
        ParserTables tab = this.tab;         // reference to tables object
        do {
            int g = tab.grammar[dot];
            if (g >= tab.ruleBase) break;       // dot at end
            if (!this.basic){
                g = tab.singmap[g];
            }
            if (g >= tab.tokBase) break;        // dot at a token
            if ((tab.epsilon[g >>> ParserTables.NSHIFTB] &
                (1 << (g & ParserTables.MASKB))) == 0) break;
            dot++;
        } while (true);
        return addItem(dot,back,donly);
    }

    private void closure(boolean edfa){
        ParserTables tab = this.tab;         // reference to tables object
        int ruleBase = tab.ruleBase;
        int tokBase = tab.tokBase;
        char[] grammar = tab.grammar;
        for (int i = 0; i < this.itmNr; i++){   // apply predictor and completer
            int l = grammar[this.curstate[i]];
            if (l >= ruleBase) continue;        // dot at end
            if (!this.basic){
                l = tab.singmap[l];
            }
            if (l >= tokBase) continue;         // dot at a token
            if ((FL_E & this.trc) != 0){
                Trc.out.println("predictors for: " + i);
            }
            // dot at a nonterminal
            int rulenr = tab.ntToRule[l];
            for (int a = tab.ruleIndex[tab.ntToRule[l]];  // add all its rules
                // why not tab.numOfRules + 1 as in the other places?
                (rulenr < tab.numOfRules) &&
                (tab.ruleToNt[rulenr] == l);){

                if ((FL_E & this.trc) != 0){
                    Trc.out.print("predictor: ");
                }
                nins: {
                    // do not add predictions if the rule produces only the empty string
                    eps: {
                        for (int p = a; grammar[p] < ruleBase; p++){  // gramRule
                            int v = grammar[p];
                            if (!this.basic){
                                v = tab.singmap[v];
                            }
                            if (v >= tokBase) break eps;           // terminal
                            if ((tab.epsilon[v >>> ParserTables.NSHIFTB] &
                                (1 << (v & ParserTables.MASKB))) == 0){
                                break eps;
                            }
                        }
                        break nins;            // rule for Ae
                    }
                    // there should not be the case in which I insert a rule with the dot
                    // advanced at the end because it would be an Ae rule

                    // N.B. add it with the dot advanced over all Ae's
                    int itm = addHItem(a,1,true);
                }
                a += tab.ruleLen[rulenr]+1;        // index of next rule
                if (a >= grammar.length) break;
                int g = a;
                while (grammar[g] < ruleBase) g++; // gramRule
                rulenr = grammar[g] - ruleBase;
            }
            if (!edfa) continue;
            // skip if it produces only the empty string
            if ((tab.epsilon[l >>> ParserTables.NSHIFTB] &
                (1 << (l & ParserTables.MASKB))) == 0) continue;

            int p = this.curstate[i];
            if ((FL_E & this.trc) != 0){
                Trc.out.print("completer-e: ");
            }
            int itm = addHItem(p+1,this.back[i],true);
        }
    }

    private State addState(boolean esplit){
        State res = null;
        if (!esplit){
            Arrays.sort(this.curstate,0,this.itmNr);
            if (this.states.addUnique(this.curstate,this.itmNr)){
                if ((FL_E & this.trc) != 0){
                    Trc.out.println("added state: " +
                        this.states.lastAdded.number);
                }
            }
            res = this.states.lastAdded;
        } else {
            // temporary quick inefficient implementation
            int j = 0;
            int[] tmp = new int[this.curstate.length];
            for (int i = 0; i < this.itmNr; i++){
                if (this.back[i] == 0){
                    tmp[j++] = this.curstate[i];
                }
            }
            Arrays.sort(tmp,0,j);
            if (this.states.addUnique(tmp,j)){
                if ((FL_E & this.trc) != 0){
                    Trc.out.println("added kernel state: " +
                        this.states.lastAdded.number);
                }
                State kernel = this.states.lastAdded;
                kernel.nonkernel = kernel;
                res = kernel;
                j = 0;
                for (int i = 0; i < this.itmNr; i++){
                    if (this.back[i] != 0){
                        tmp[j++] = this.curstate[i];
                    }
                }
                if (j > 0){
                    // perhaps it is possible here to use an array of bools: set the ones
                    // that are in the set, and then scan and collect them. Or proabably
                    // a bit set (of integers), which could be faster to clear.
                    Arrays.sort(tmp,0,j);
                    // why put it in the hash table?
                    if (this.states.addUnique(tmp,j)){
                        if ((FL_E & this.trc) != 0){
                            Trc.out.println("added nonkernel state: " +
                                this.states.lastAdded.number);
                        }
                    }
                    kernel.nonkernel = this.states.lastAdded;
                }
            } else {
                res = this.states.lastAdded;
            }
        }
        return res;
    }

    static class State extends HashNode {

        /** The reference to the next element. */
        private State suc;

        /** The reference to the items. */
        int[] items;

        /** The number of the state. */
        int number;

        /** The symbols to move to the next states. */
        private int[] syms;

        /** The next states. */
        private State[] nexts;

        /** The numbers of the next states. */
        // to test performance
        State[] nextState;

        /** The director. */
        byte[] director;

        /** The associated non-kernal state. */
        State nonkernel;

        State(int n, int[] arr, int len){
            this.number = n;
            this.items = new int[len];
            System.arraycopy(arr,0,this.items,0,len);
        }

        public String toString(){
            Str st = new Str();
            st.append(Integer.toString(this.number));
            st.append(": [");
            for (int i = 0; i < this.items.length; i++){
                st.append(Integer.toString(this.items[i]));
                if (i < this.items.length - 1){
                    st.append(", ");
                }
            }
            st.append("]");
            return st.toString();
        }
        public boolean equals(Object other){
            if (this == other) return true;
            if (other == null) return false;
            State s = (State)other;
            return equals(s.items,s.items.length);
        }
        public boolean equals(int[] arr, int len){
            if (this.items.length != len){
                return false;
            }
            for (int i = 0; i < len; i++){
                if (this.items[i] != arr[i]){
                    return false;
                }
            }
            return true;
        }
        public int hashCode(){
            return hashCode(this.items,this.items.length);
        }
        public int hashCode(int[] arr, int len){
            int h = 0;
            for (int i = 0; i < len; i++){
                int c = arr[i];
                h = 31*h + c;
            }
            return h;
        }
        public State next(int sym){
            if (this.syms == null) return null;
            for (int i = 0; i < this.syms.length; i++){
                if (this.syms[i] == sym){
                    return this.nexts[i];
                }
            }
            return null;
        }
    }

    /* private? */ class StateTable extends HashBag {

        /** The head of the ordered list. */
        private State head;

        /** The last of the list. */
        private State last;

        /** The last element added. */
        private State lastAdded;

        /** The current number of states. */
        private int stateNr = 1;
        // state nr 0 not used because 0 not allowed in the items lists as dot
        // probably possible when a comb-vector is used and then the state base
        // could be used instead of number as dot

        /** The reference to the parsing tables. */
        private ParserTables tab;

        /** The resulting array of states. */
        State[] table;

        /**
         * Search an element with the given items.
         *
         * @param   arr reference to an array of items
         * @param   len number of items
         * @return  reference to the element, <code>null</code> if not found
         */

        State search(int[] arr, int len){
            if (this.elemNr == 0) return null;
            int hvalue = (((State)this.elementNode)
                .hashCode(arr,len) & 0x7FFFFFFF)
                % this.hdir.length;
            HashNode pr = null;
            HashNode e = null;
            State d = null;
            sea: for (e = this.hdir[hvalue];
                e != null; e = e.hlink){              // scan the chain
                d = (State)e;
                if (d.equals(arr,len)) break sea;
                pr = e;
            }
            if (e == null) d = null;
            return d;
        }

        /**
         * Ensure that this table contains an element whose code
         * and kind are the same as the those passed as argument.
         * If it is not yet present, it allocates a new element for it.
         * It appends the new element at the end of the ordered list.
         *
         * @param   arr reference to an array of items
         * @param   len number of items
         * @return  <code>true</code> if the element has been inserted
         */

        boolean addUnique(int[] arr, int len){
            State h = search(arr,len);
            this.lastAdded = (State)h;
            if (h != null) return false;
            h = new State(this.stateNr++,arr,len); // allocate entry
            add(h);
            State d = (State)h;
            this.lastAdded = d;
            if (this.last == null) this.head = d;  // append to list
            else this.last.suc = d;
            this.last = d;
            return true;
        }

        /**
         * Trace this table.
         */

        public void trace(){
            for (State s = this.head; s != null; s = s.suc){
                Trc.out.print("state: " + s.number);
                if (s.nonkernel == null){
                    Trc.out.println(" nonkernel");
                } else {
                    Trc.out.println(" kernel" + ((s.nonkernel != s) ?
                        ", nonkernel: " + s.nonkernel.number : " "));
                }
                for (int i = 0; i < s.items.length; i++){   // trace its items
                    Trc.out.println("[" +
                        this.tab.ruleToString(s.items[i],true) + "]");
                }
                if ((s.nonkernel != null) && (s.nonkernel != s)){
                    Trc.out.println("\"\" -> " + s.nonkernel.number);
                }
                if (s.syms == null) continue;
                for (int i = 0; i < s.syms.length; i++){    // trace its nexts
                    Trc.out.println(this.tab.gramSymToString(s.syms[i]) +
                        " -> " + s.nexts[i].number);
                }
                if (s.director != null){
                    Trc.out.println(termSetToStr(s.director));
                }
            }
        }
    }

    /**
     * Build the map from rules in the GES modified grammar to the rules in the origin grammar.
     */

    private void buildRuleMap(){
        // build the map of the nts to the origin ones in the non-modified grammar
        ParserTables tab = this.tab;
        if ((FL_E & this.trc) != 0){
            //Trc.out.printf("actual grammar\n");
            //traceGenMode();
            //tab.traceGrammar();
            //Trc.out.printf("origin grammar\n");
            //this.orig.traceGenMode();
            //tab.originTables.traceGrammar();
            Trc.out.printf("remapping nts\n");
        }
        int[] mapnt = new int[tab.ntStrings.length];
        for (int i = 0; i < tab.ntStrings.length; i++){      // visit all nts
            String nts = tab.ntStrings[i];
            int ont = -1;
            for (int j = 0; j < tab.originTables.ntStrings.length; j++){  // find corresponding one
                if (nts.equals(tab.originTables.ntStrings[j])){
                    ont = j;
                    break;
                }
            }
            if (ont < 0){
                Trc.out.printf("!! unmapped nt: %s\n",nts);
            }
            if ((FL_E & this.trc) != 0){
                Trc.out.printf("nt: %s %d to %s %d\n",
                    nts,i,tab.originTables.ntStrings[ont],ont);
            }
            mapnt[i] = ont;
        }
        if ((FL_E & this.trc) != 0){
            Trc.out.printf("remapping rules\n");
            Trc.out.printf("--origin grammar-----\n");
            Trc.out.printf("-------\n");
        }
        tab.toOriginRule = new int[this.tab.ruleIndex.length];
        for (int i = 0; i < tab.ruleIndex.length; i++){      // visit all rules
            if ((FL_E & this.trc) != 0){
                Trc.out.printf("rule %d: %s\n",i,tab.ruleToString(tab.ruleIndex[i],false));
            }
            // get the corresponding nt in the origin grammar
            int nt = tab.ruleToNt[i];
            int ont = mapnt[nt];
            // scan the rules of this nt in the origin grammar and find the one that
            // matches the current one
            boolean found = false;
            ru: for (int rulenr = tab.originTables.ntToRule[ont];    // scan all rules of nt
                (rulenr < tab.originTables.numOfRules + 1) &&
                (tab.originTables.ruleToNt[rulenr] == ont); rulenr++){
                if (tab.ruleLen[i] != tab.originTables.ruleLen[rulenr]){
                    continue;
                }
                int o = tab.originTables.ruleIndex[rulenr];
                for (int p = tab.ruleIndex[i]; tab.grammar[p] < tab.ruleBase; p++, o++){
                    int el = tab.grammar[p];
                    int oel = tab.originTables.grammar[o];
                    if (el >= tab.tokBase){                   // token
                        if (oel < tab.originTables.tokBase){  // nt
                            continue ru;
                        }
                        if (el - tab.tokBase == oel - tab.originTables.tokBase){
                            continue;                         // same token
                        }
                        continue ru;                          // different token
                    }
                    if (oel >= tab.originTables.tokBase){     // token
                        continue ru;
                    }
                    if (mapnt[el] == oel){                    // same nt
                        continue;
                    }
                    continue ru;
                }
                tab.toOriginRule[i] = rulenr;
                found = true;
                if ((FL_E & this.trc) != 0){
                    Trc.out.printf("mapped to %d: %s\n",
                        rulenr,tab.originTables.ruleToString(
                        tab.originTables.ruleIndex[rulenr],false));
                }
            } // ru
            if (!found){
                Trc.out.printf("!! unmapped rule: %s\n",tab.ruleToString(tab.ruleIndex[i],false));
            }
        }
    }
}
