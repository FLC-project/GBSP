/*
 * @(#)ParserLRTables.jpp       1.0 2020/07/24
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;

/**
 * The <code>ParserLRTables</code> class represents the LR tables.
 *
 * @author  Angelo Borsotti
 * @version 1.0   24 Jul 2020
 */

/*
 * Class dependencies:
 *     class FAtables
 *     class LR0FAtables extends FAtables
 *     class LR01FAtables extends LR0FAtables
 *     class LR1FAtables extends LR01FAtables
 *     class LALRFAtables extends LR01FAtables
 *     class LALRRNFAtables extends LALRFAtables
 *     class ELR1FAtables extends LALRFAtables
 *     class ELR1PFAtables extends ELR1FAtables
 *     class ELR1RNFAtables extends ELR1PFAtables
 *     class LALRGRNFAtables extends LALRRNFAtables
 */

public class ParserLRTables implements Serializable {

    /** The reference to the generated parser lr tables. */
    FAtables lrTables;

    /** 
     * Get the value of the entry at the specified index in the specified bitstring.
     *
     * @param      arr bitstring
     * @param      idx index
     * @return     value, <code>true</code> or <code>false</code>
     */

    private static boolean boolGet(byte[] arr, int idx){
        return (arr[idx>>>ParserTables.NSHIFTB] &
            (1 << (idx & ParserTables.MASKB))) != 0;
    }

    /**
     * The FA data.
     */

    class FAtables implements Serializable {

        /** The parser tables. */
        ParserTables tab;

        /** The options. */
        String options;

        /** The status of the states. */
        protected int[] stateStatus;

        /** The number of states. */
        protected int stateNr = 0;

        /** The final state status. */
        protected static final int ACCEPTING = 1 << 0;

        /**
         * Deliver a string representing the status.
         *
         * @param   status
         * @return  string
         */

        protected String statusToString(int status){
            StringBuilder sb = new StringBuilder();
            if ((ACCEPTING & status) != 0){
                if (sb.length() > 0) sb.append(" ,");
                sb.append("A");
            }
            return sb.toString();
        }

        /**
         * Trace the LR tables.
         */

        void trace(PrintWriter trc){
        }

        /**
         * Trace the statistics of the LR tables.
         */

        void statis(PrintWriter trc){
        }

        /**
         * Return the size of the FA data that are needed at parse time.
         *
         * @return  size
         */

        int size(){
            return arraySize(this.stateStatus);
        }
    }

    /**
     * The LR(0) data.
     */

    /* The compressed table
     *
     * Each entry is a cell indexed with a state number and a symbol.
     * It can contain a single value or several values, each denoting a shift or
     * a reduction.
     * The contents of the cell is:
     *
     *    >= 0:  a single value
     *    < 0:   the negated index of an array of values. In the compressed table, at
     *           -index there is the length of the array, followed by its elements
     *
     * Each value represents:
     *
     *    b30 = 0:  shift:
     *                 b29: whether to save the string of the token
     *                 b28: whether to save its point
     *                 others: state number
     *    b30 = 1:  reduce:
     *                 others: rule number (and/or other data, depending on the parser)
     *
     * Since a shift to state 0 never occurs, 0 is used as hole value.
     * N.B. the parsers access the goto part of the tables (the entries for nonterminals)
     * also in its holes.
     *
     * N.B. in a LR pilot, states are always reached with edges labelled with the same symbol.
     */

    /** The number of the first bit of the field that contains the number of elements
     *  before the dot in a reduction in the compressed tables. */
    static final int BEFSHIFTS = 20;

    /** The mask of the field that contains the number of elements. */
    static final int BEFMASK = 0x3FF;

    /** The flag that marks a value as a reduction. */
    static final int ISREDUCE = 1 << 30;

    /** The mask of the rule number in a reduction value . */
    static final int RULEMASK = 0x7FFFF;

    /** The flag that marks a value as one to save the lexeme. */
    static final int SAVELEX = 1 << 29;

    /** The flag that marks a value as one to save the position. */
    static final int SAVEPOS = 1 << 28;

    /** The mask of the rule number in a reduction value. */
    static final int RULEFIXED = 0x80000;

    /** The number of shifts to get the nt in a reduction value. */
    static final int NTSHIFTS = 9;

    /** The mask to get the nt in a reduction value. */
    static final int NTMASK = 0x3FF;

    /** The mask to get the rhl in a reduction value. */
    static final int RHLMASK = 0x3FF;

    /** The mask to get the machine state number from a reduction in the compressed table. */
    static final int MACMASK = 0x1FF;

    /** The mask of the fields that contains the number of the state in a shift. */
    static final int STATEMASK = 0xFFFFFFF;

    class LR0FAtables extends FAtables implements Serializable {

        /** The compressed table. */
        public int[] LRtable;

        /** The check values of the compressed table. */
        public int[] LRcheck;

        /** The base indexes of the compressed table. */
        public int[] LRbase;

        /** The shift-reduce conflicts status. */
        protected static final int CONFLICT_SR = 1 << 1;

        /** The reduce-reduce conflicts status. */
        protected static final int CONFLICT_RR = 1 << 2;

        /**
         * Deliver a string representing the status.
         *
         * @param   status
         * @return  string
         */

        @Override
        protected String statusToString(int status){
            return lr0StatusToString(status);
        }

        /**
         * Deliver a string representing the status (non overriden one).
         *
         * @param   status
         * @return  string
         */

        protected String lr0StatusToString(int status){
            StringBuilder sb = new StringBuilder();
            sb.append(super.statusToString(status));
            if ((CONFLICT_SR & status) != 0){
                if (sb.length() > 0) sb.append(" ,");
                sb.append("s/r");
            }
            if ((CONFLICT_RR & status) != 0){
                if (sb.length() > 0) sb.append(" ,");
                sb.append("r/r");
            }
            return sb.toString();
        }

        /**
         * Deliver a string representing the reduction as stored in the compressed tables.
         *
         * @param   var reduction
         * @return  string
         */

        protected String comprReduToString(int val){
            val &= ~ISREDUCE;
            return String.format("r%d",val);
        }

        /**
         * Deliver a string representing the actions of the specified state and input
         * from the specified compressed tables.
         *
         * @param   state the state
         * @param   sym the input
         * @param   combtable comb table
         * @param   combcheck comb check
         * @param   combbase comb base
         * @return  string
         */

        String actionToString(int state, int sym, int[] combtable, int[] combcheck, int[] combbase){
            StringBuilder str = new StringBuilder();
            int bas = combbase[state];
            int start = bas+sym;
            int ele = combcheck[start] == bas ? combtable[start] : 0;
            if (ele == 0) return null;
            int len = 1;
            if (ele < 0){            // array of actions
                ele = -ele;
                len = combtable[ele++];
                start = ele;
            }
            for (int k = 0; k < len; k++){
                if (str.length() > 0) str.append(" ");
                int val = combtable[start+k];
                if (val >= ISREDUCE){
                    str.append(comprReduToString(val));
                } else {
                    String lex = (val & SAVELEX) != 0 ? "l" : "";
                    String point = (val & SAVEPOS) != 0 ? "p" : "";
                    val &= ~(SAVELEX | SAVEPOS);
                    str.append(String.format("s%d%s%s",val,lex,point));
                }
            }
            return str.toString();
        }

        /**
         * Deliver a string representing the actions of the specified state and input.
         *
         * @param   state the state
         * @param   sym the input
         * @return  string
         */

        String actionToString(int state, int sym){
            return actionToString(state,sym,this.LRtable,this.LRcheck,this.LRbase);
        }

        /**
         * Trace the LR tables.
         */

        @Override
        void trace(PrintWriter trc){
            traceTables(trc);
        }

        /**
         * Trace the LR tables (not overridden one).
         */

        void traceTables(PrintWriter trc){
            int nsym = tab.numOfToks + 1 + tab.numOfNts;
            for (int i = 0; i < this.stateNr; i++){
                trc.printf("%s:",i);
                String status = statusToString(this.stateStatus[i]);
                if (status.length() > 0) trc.printf("%s",status);
                String sep = " ";
                for (int j = 0; j < nsym; j++){
                    String action = actionToString(i,j);
                    if (action != null){
                        trc.printf("%s%s: %s",sep,tab.gramSymToString(j),action);
                        sep = "; ";
                    }
                }
                trc.printf("\n");
            }
        }

        /**
         * Trace the statistics of the LR tables.
         */

        void statis(PrintWriter trc){
            trc.printf("pilot statistics");
            trc.printf("\n");
            trc.printf("grammar size: %s",this.tab.grammar.length);
            trc.printf("\n");
            trc.printf("states: %s",this.stateNr);
            trc.printf("\n");
            trc.printf("size: %s",size());
            trc.printf("\n");
            int nred = 0;
            int nshift = 1;
            int nsym = tab.numOfToks + 1 + tab.numOfNts;
            for (int i = 0; i < this.stateNr; i++){
                for (int j = 0; j < nsym; j++){
                    int bas = this.LRbase[i];
                    int start = bas+j;
                    int ele = this.LRcheck[start] == bas ? this.LRtable[start] : 0;
                    if (ele == 0) continue;
                    int len = 1;
                    if (ele < 0){            // array of actions
                        ele = -ele;
                        len = this.LRtable[ele++];
                        start = ele;
                    }
                    for (int k = 0; k < len; k++){
                        int val = this.LRtable[start+k];
                        if (val >= ISREDUCE){
                            nred++;
                        } else {
                            nshift++;
                        }
                    }
                }
            }
            trc.printf("shifts: %s reductions %s",nshift,nred);
            trc.printf("\n");
        }

        /**
         * Return the size of the FA data that are needed at parse time.
         *
         * @return  size
         */

        @Override
        int size(){
            int res = 0;
            res += arraySize(this.LRtable);
            res += arraySize(this.LRcheck);
            res += arraySize(this.LRbase);
            return res;
        }
    }

    /**
     * The common part of LR(0) and LR(1) data.
     */

    class LR01FAtables extends LR0FAtables implements Serializable {
    }

    /**
     * The LR(1) data.
     */

    class LR1FAtables extends LR01FAtables implements Serializable {
    }

    /**
     * The LALR(0) data.
     */

    class LALRFAtables extends LR01FAtables implements Serializable {

        /** The variant of LR. 0: no isles, 1: isles. */
        protected int lr1kind = 1;

        /** The length of the longest rule. */
        int longestRule;
    }

    /**
     * The Right-nulled FA based on LALR(0) data.
     */

    /* The compressed table
     *
     *   reductions:
     *       b20-b29: number of symbols before the dot
     *       others:  rule number
     */

    class LALRRNFAtables extends LALRFAtables implements Serializable {

        /** The variant of LR. 0: no isles, 1: canonical isles, 2: isles, 3. isles+disambiguation */
        // protected int lr1kind = 1;

        /** The map of the states that are frontiers of deterministic isles. */
        byte[] isFrontierStates;

        /** The map from frontier states to their mirror ones. */
        int[] frontierMap;

        /** The table of accessing symbols. */
        int[] accessingSym;

        /** Whether the state is a frontier one. */
        protected static final int ISFRONTIER = 1 << 4;

        /** Whether it is adequate and reaches only adequate states. */
        protected static final int ISLALR = 1 << 5;

        /** The table of the number of (non)cyclic nullable rule. */
        int[] ncycNulRule;

        /**
         * Deliver a string representing the reduction as stored in the compressed tables.
         *
         * @param   var reduction
         * @return  string
         */

        @Override
        protected String comprReduToString(int val){
            int bef = (val >> BEFSHIFTS) & BEFMASK;
            val &= RULEMASK;
            return String.format("r%d,%d",val,bef);
        }

        /**
         * Deliver a string representing the status.
         *
         * @param   status
         * @return  string
         */

        @Override
        protected String statusToString(int status){
            StringBuilder sb = new StringBuilder();
            sb.append(super.statusToString(status));
            if ((ISFRONTIER & status) != 0){
                if (sb.length() > 0) sb.append(",");
                sb.append("F");
            }
            if ((ISLALR & status) != 0){
                if (sb.length() > 0) sb.append(",");
                sb.append("I");
            }
            return sb.toString();
        }

        /**
         * Trace the LR tables.
         */

        @Override
        void trace(PrintWriter trc){
            int nsym = tab.numOfToks + 1 + tab.numOfNts;
            for (int i = 0; i < this.stateNr; i++){
                int status = this.stateStatus[i];
                if ((status & ISFRONTIER) != 0){
                    trc.printf("%s+",i);
                    if (this.frontierMap != null){
                        if (i < this.frontierMap.length){
                            if (this.frontierMap[i] != 0){
                                trc.printf("%s",this.frontierMap[i]);
                            }
                        }
                    }
                } else if ((status & ISLALR) != 0){
                    trc.printf("%s=",i);
                } else {
                    trc.printf("%s:",i);
                    String stat = statusToString(status);
                    if (stat.length() > 0) trc.printf("%s",stat);
                }
                String sep = " ";
                for (int j = 0; j < nsym; j++){
                    String action = actionToString(i,j);
                    if (action != null){
                        trc.printf("%s%s: %s",sep,tab.gramSymToString(j),action);
                        sep = "; ";
                    }
                }
                trc.printf("\n");
            }
        }

        /**
         * Trace the statistics of the LR tables.
         */

        void statis(PrintWriter trc){
            super.statis(trc);
            int front = 0;
            int lalr = 0;
            for (int i = 0; i < this.stateNr; i++){
                int status = this.stateStatus[i];
                if ((status & ISFRONTIER) != 0){
                    front++;
                } else if ((status & ISLALR) != 0){
                    lalr++;
                }
            }
            trc.printf("frontiers: %s adequate: %s isles: %.2f%%",
                front,lalr,(double)(front+lalr)*100/this.stateNr);
            trc.printf("\n");
        }

        /**
         * Return the size of the FA data that are needed at parse time.
         *
         * @return  size
         */

        @Override
        int size(){
            int res = super.size();;
            res += arraySize(this.isFrontierStates);
            res += arraySize(this.frontierMap);
            res += arraySize(this.accessingSym);
            res += arraySize(ncycNulRule);
            return res;
        }
    }

    /**
     * The ELR(1) data.
     */

    /* The compressed table
     *
     *   reductions:
     *       others: index of reduction item in state
     */

    class ELR1FAtables extends LALRRNFAtables implements Serializable {

        /**
         * Deliver a string representing the status.
         *
         * @param   status
         * @return  string
         */

        @Override
        protected String statusToString(int status){
            return lr0StatusToString(status);
        }

        /**
         * Trace the LR tables.
         */

        @Override
        void trace(PrintWriter trc){
            traceTables(trc);
        }
    }

    /**
     * The ELR(1)+ data.
     */

    /* The compressed table
     *                            elr1kind
     *
     *   reductions:     1      2      3,4       5
     *       b20-b29:   ri      ri     ri        nt
     *       b19:       fix     fix    
     *       b10-b18:                  nt
     *       others:    nt      rn     rhl       ri+1 or 0 (+1 because 0 reserved)
     *   ri:  index of reduction item in state
     *   rn:  rule number
     *   fix: set if rule without REs (i.e. fixed length rule)
     *   rhl: rhl of the reduction item
     *
     *      3                   2                   1                   0
     *    1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
     *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *   | |1|   ri              |1|  elr1kind = 1: nt, 2: rn            |  elr1kind = 1,2
     *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *   | |1|   ri              |     nt            |     rhl           |  elr1kind = 3,4
     *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *   | |1|   nt              | ri.left LEFTMARK = 0 ? ri+1 : 0       |  elr1kind = 5
     *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *
     *   elr1kind:                                                        leftptrsOn rhlOn fix pilot1
     *      0: elr1 Crespi's book
     *      1: elr1+ with leftptrs                                           yes
     *      2: elr1++ with leftptrs and reductions of fixed rules            yes            yes
     *      3: elr1 pilot III, with leftptrs and rhls                        yes       yes
     *      4: elr1+++ parser III, with leftptrs and rhls and fixed rules    yes       yes  yes
     *      5: elr1 pilot I in draft 11                                                          yes
     */

    class ELR1PFAtables extends ELR1FAtables implements Serializable {

        /** The variant of ELR1+. */
        protected int elr1kind = 2;

        /** Table that tells the rules that have REs in their right part. */
        byte[] ruleRE;

        /** The hop table: for each state a vector of leftpointer, one for each item. */
        int[][] stateHop;

        /** Whether rhl in items contains the reduction length (or always 0). */
        protected boolean rhlOn;

        /**
         * Deliver a string representing the reduction as stored in the compressed tables.
         *
         * @param   var reduction
         * @return  string
         */

        @Override
        protected String comprReduToString(int val){
            int bef = (val >> BEFSHIFTS) & BEFMASK;
            switch (this.elr1kind){
            case 1: case 2:
                val &= RULEMASK;
                return String.format("r%s,%s",bef,val);
            case 3: case 4:
                int nt = (val >> NTSHIFTS) & NTMASK;
                val &= RHLMASK;
                return String.format("r%s%s,%s",bef,nt,val);
            case 5:
                val &= RULEMASK;
                return String.format("r%s%s",bef,val);
            }
            return null;
        }

        /**
         * Trace the LR tables.
         */

        @Override
        void trace(PrintWriter trc){
            super.trace(trc);
            if (this.stateHop != null){
                trc.printf("-- stateHop--");
                trc.printf("\n");
                for (int i = 0; i < this.stateHop.length; i++){
                    String str = "  state " + i;
                    for (int j = 0; j < this.stateHop[i].length; j++){
                        str += " " + j + ":" + this.stateHop[i][j];
                    }
                    trc.printf("%s\n",str);
                }
            }
        }

        /**
         * Return the size of the FA data that are needed at parse time.
         *
         * @return  size
         */

        @Override
        int size(){
            int res = super.size();;
            res += arraySize(this.ruleRE);
            res += arraySize(this.stateHop);
            return res;
        }
    }

    /**
     * The ELR(1) RN data for the RNGLR parser that uses ELR1 data.
     */

    /* The compressed table
     *
     *   reductions:
     *       b20-b29:   index of reduction item in state
     *       b19:       m whether the reduction rule is empty (if set)
     *       b10-b18:   nt
     *       others:    machine state number
     *
     *      3                   2                   1                   0
     *    1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
     *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *   | |1|  reduction item   |m|    nt           |   mac state       |
     *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *
     * The rnTails:
     *    for each machine state it contains the array of all its rn tails. Each rn tail
     *    is a sequence of nonterminals (numbers).
     * The ntRnTails:
     *    for each nonterminal it contains the array of all its rn tails.
     * The hop table:
     *    for each state it contains an array indexed with its item numbers; its elements
     *    are either -1: no leftpointers, or the index in the stateHopt table where its
     *    leftpointers are stored (-1 terminated).
     *
     * elr1kind:
     *    1:  LALR pilot, with isles
     *    2:  LR1 pilot, no isles
     */

    class ELR1RNFAtables extends ELR1PFAtables implements Serializable {

        /** The rn tails of each machine state. */
        int[][][] rnTails;

        /** The rn tails of each nonterminal. */
        int[][][] ntRnTails;

        /** The hop table. */
        int[][] stateHops;

        /** The hop table array. */
        int[] stateHopt;

        /** The number of the initial machine state for each nonterminal. */
        int[] ntMacStart;

        /** The lengths of the reductions for each machine accepting state, if fixed, -1 otherwise. */
        int[] derlen;

        /** The lengths of the reductions for each machine reduction and accepting state, if fixed, -1 otherwise. */
        int[] rnDerlen;

        /** The maximum rnDerlen. */
        int maxRnDerlen;

        /** The machine state names. */
        String[] macnames;

        /**
         * Deliver a string representing the status.
         *
         * @param   status
         * @return  string
         */

        @Override
        protected String statusToString(int status){
            StringBuilder sb = new StringBuilder();
            sb.append(super.statusToString(status));
            if ((ISFRONTIER & status) != 0){
                if (sb.length() > 0) sb.append(",");
                sb.append("F");
            }
            if ((ISLALR & status) != 0){
                if (sb.length() > 0) sb.append(",");
                sb.append("I");
            }
            return sb.toString();
        }

        /**
         * Deliver a string representing the reduction as stored in the compressed tables.
         *
         * @param   var reduction
         * @return  string
         */

        @Override
        protected String comprReduToString(int val){
            int itnr = (val >> BEFSHIFTS) & BEFMASK;
            String fix = "";
            if ((val & RULEFIXED) != 0) fix = "e";
            int nt = (val >> NTSHIFTS) & NTMASK;
            int macsn = val & MACMASK;
            return String.format("r%s%s,%s,%s",fix,nt,itnr,macsn);
        }

        /**
         * Trace the LR tables.
         */

        @Override
        void trace(PrintWriter trc){
            super.trace(trc);
            trc.printf("-- rn tails --");
            trc.printf("\n");
            for (int i = 0; i < this.rnTails.length; i++){
                if (this.rnTails[i] == null) continue;
                String str = "  mac state " + this.macnames[i];
                for (int j = 0; j < this.rnTails[i].length; j++){
                    if (j > 0){
                        str += ",";
                    }
                    if (this.rnTails[i][j].length == 0){
                        str += " \"\"";
                    } else {
                        for (int k = 0; k < this.rnTails[i][j].length; k++){
                            str += " " + tab.gramSymToString(this.rnTails[i][j][k]);
                        }
                    }
                }
                trc.printf("%s\n",str);
            }
            trc.printf("-- nonterminals rn tails --");
            trc.printf("\n");
            for (int i = 0; i < this.ntRnTails.length; i++){
                if (this.ntRnTails[i] == null) continue;
                String str = "  nt " + tab.gramSymToString(i);
                for (int j = 0; j < this.ntRnTails[i].length; j++){
                    if (j > 0){
                        str += ",";
                    }
                    if (this.ntRnTails[i][j].length == 0){
                        str += " \"\"";
                    } else {
                        for (int k = 0; k < this.ntRnTails[i][j].length; k++){
                            str += " " + tab.gramSymToString(this.ntRnTails[i][j][k]);
                        }
                    }
                }
                trc.printf("%s\n",str);
            }

            trc.printf("-- stateHops --");
            trc.printf("\n");
            for (int i = 0; i < this.stateHops.length; i++){
                String str = "  state " + i;
                for (int j = 0; j < this.stateHops[i].length; j++){
                    str += " " + j + ":";
                    int idx = this.stateHops[i][j];
                    if (idx < 0){
                        str += "-";
                    } else {
                        for (int k = idx; this.stateHopt[k] >= 0; k++){
                            if (k > idx) str += ",";
                            str += this.stateHopt[k];
                        }
                    }
                }
                trc.printf("%s\n",str);
            }

            trc.printf("-- nonterminals initial mac states --");
            trc.printf("\n");
            for (int i = 0; i < this.ntMacStart.length; i++){
                trc.printf("%s %s: %s\n",i,tab.gramSymToString(i),this.ntMacStart[i]);
            }

            if (this.elr1kind == 1){
                trc.printf("-- frontiers --");
                trc.printf("\n");
                for (int i = 0; i < this.stateNr; i++){
                    if (boolGet(this.isFrontierStates,i)){
                        trc.printf("frontier %s\n",i);
                    }
                }
                trc.printf("-- fixed reductions --");
                trc.printf("\n");
                for (int i = 0; i < this.derlen.length; i++){
                    if (this.derlen[i] == -1 && this.rnDerlen[i] == -1) continue;
                    trc.printf("%s: %s rn %s\n",this.macnames[i],this.derlen[i],this.rnDerlen[i]);
                }
            }
        }

        /**
         * Return the size of the FA data that are needed at parse time.
         *
         * @return  size
         */

        @Override
        int size(){
            int res = super.size();;
            res += arraySize(this.rnTails);
            res += arraySize(this.ntRnTails);
            res += arraySize(this.stateHops);
            res += arraySize(this.stateHopt);
            res += arraySize(this.ntMacStart);
            res += arraySize(this.derlen);
            res += arraySize(this.rnDerlen);
            for (int i = 0; i < this.macnames.length; i++){
                res += this.macnames[i].length() + 2 + 8;
            }
            return res;
        }
    }

    /**
     * The LALRGRN(1) RN data for the RNGLR parser that uses LALRGRN data.
     */

    /* The compressed table
     *
     *   reductions:
     *       b18-b29:   index of reduction item in state or nr.el. before dot
     *       b17:       m whether the reduction rule is empty (if set)
     *       b0-b16:    rule number or nonterminal
     *
     *      3                   2                   1                   0
     *    1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
     *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *   | |1|  nr.el. before dot    |m|  rule number+ruleBase           |  fixed rule
     *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *   | |1|  reduction item       |m|       nonterminal               |  variable length rule
     *   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *
     *   This tells:
     *      - whether the reduction is fixed, and then how many elements before the dot,
     *        and the rule number
     *      - otherwise, the reduction item to access the hop table, and the nt to make
     *        the nt shift
     */

    /** The number of the first bit of the field that contains the number of elements
     *  before the dot or the reduction item. */
    static final int ELSHIFTS = 18;

    /** The mask of the field that contains the nr. of elements or the reduction item. */
    static final int ELMASK = 0xFFF;

    /** The mask of the field that contains the rule or nonterminal. */
    static final int GPMASK = 0x1FFFF;

    /** The mask of the rule number in a reduction value. */
    static final int EMPTYMASK = 0x20000;

    class LALRGRNFAtables extends LALRRNFAtables implements Serializable {

        /** The hop table. */
        // int[][] stateHops;        // only if not ONE_PTR in ParserLR

        /** The hop table array. */
        // int[] stateHopt;          // same

        /** The compressed hop table. */
        public int[] hopTable;

        /** The check values of the compressed hop table. */
        public int[] hopCheck;

        /** The base indexes of the compressed hop table. */
        public int[] hopBase;

        /** The highest item number that has a leftpointer. */
        public int maxLeft;

        /** The cyclic rules. */
        public byte[] ruleCyc;

        /** The nonterminals that have all rules cyclic. */
        public byte[] allCyc;

        /** The items in states. */
        /* It has an index first, followed by the items of each state, preceded by their number. */
        public int[] stateDots;

        /**
         * Deliver a string representing the reduction as stored in the compressed tables.
         *
         * @param   var reduction
         * @return  string
         */

        @Override
        protected String comprReduToString(int val){
            int itnr = (val >> ELSHIFTS) & ELMASK;
            String m = "";
            if ((val & EMPTYMASK) != 0) m = "e";
            int gp = val & GPMASK;
            String str = "";
            if (gp >= tab.ruleBase){
                str += gp - tab.ruleBase + "#";
            } else {
                str += tab.gramSymToString(gp) + "i";
            }
            return String.format("r%s%s%s",m,str,itnr);
        }

        /**
         * Return the size of the FA data that are needed at parse time.
         *
         * @return  size
         */

        @Override
        int size(){
            int res = super.size();;
            // res += arraySize(this.stateHops);
            // res += arraySize(this.stateHopt);
            res += arraySize(this.hopTable);
            res += arraySize(this.hopCheck);
            res += arraySize(this.hopBase);
            res += arraySize(this.stateDots);
            return res;
        }

        /**
         * Trace the LR tables.
         */

        @Override
        void trace(PrintWriter trc){
            super.trace(trc);
            // hop
            if (this.hopBase != null){
                boolean heading = true;
                for (int i = 0; i < this.stateNr; i++){
                    if (this.hopBase[i] < 0) continue;    // no hops
                    String sep = " ";
                    boolean first = true;
                    for (int j = 0; j < this.maxLeft; j++){
                        int bas = this.hopBase[i];
                        int start = bas+j;
                        int ele = this.hopCheck[start] == bas ? this.hopTable[start] : -1;
                        if (ele < 0) continue;
                        if (heading){
                            trc.printf("-- hops --");
                            trc.printf("\n");
                            heading = false;
                        }
                        if (first){
                            trc.printf("%s:",i);
                            first = false;
                        }
                        trc.printf("%s%s:%s",sep,j,ele);
                        sep = "; ";
                    }
                    if (!first) trc.printf("\n");
                }
            }
            if (this.stateDots != null){
                trc.printf("-- items --");
                trc.printf("\n");
                for (int i = 0; i < this.stateNr; i++){
                    trc.printf("  state %s",i);
                    trc.printf("\n");
                    int loc = this.stateDots[i];
                    int n = this.stateDots[loc++];
                    for (int j = 0; j < n; j++){
                        trc.printf("    %s   %s",this.tab.ruleToString(this.stateDots[loc],true),
                            this.tab.ruleEbnfToString(this.stateDots[loc],true));
                        trc.printf("\n");
                        loc++;
                    }
                }
            }
        }
    }

    private static int arraySize(int[] arr){
        if (arr == null) return 0;
        return arr.length * 4 + 4;
    }
    private static int arraySize(byte[] arr){
        if (arr == null) return 0;
        return arr.length + 4;
    }
    private static int arraySize(int[][] arr){
        if (arr == null) return 0;
        int res = arr.length * 4 + 4;
        for (int i = 0; i < arr.length; i++){
            res += arraySize(arr[i]);
        }
        return res;
    }
    private static int arraySize(int[][][] arr){
        if (arr == null) return 0;
        int res = arr.length * 4 + 4;
        for (int i = 0; i < arr.length; i++){
            res += arraySize(arr[i]);
        }
        return res;
    }
}
