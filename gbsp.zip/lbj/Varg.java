/*
 * @(#)Varg.java       1.0 98/11/04
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.text.*;
import java.util.*;
import java.math.*;
import java.lang.reflect.*;

/**
 * The <code>Varg</code> class provides support for construction of
 * lists of a variable number of arguments.
 * 
 *
 * @author  Angelo Borsotti
 * @version 1.0   04 Nov 1998
 */

public class Varg{

    /** The pointer to the array of arguments. */
    public Vargument[] list;

    /** The number of arguments in the list. */
    public int argNr;

    /**
     * An argument.
     */

    public static class Vargument {

        /** The type of the element. */
        byte    type;

        /** The integral value of the element. */
        long    integral;

        /** The floating point value of the element. */
        double  real;

        /** The reference value of the element. */
        Object  obj;

        /** The slice length of the element. */
        int     length;

    }

    /* The constants for the type of elements. Keep equal to the ones
     * defined in Formatter.
     */

    /** The boolean type. */
    public static final byte FRM_BOOL    =  0;

    /** The character type. */
    public static final byte FRM_CHAR    =  1;

    /** The byte type. */
    public static final byte FRM_BYTE    =  2;

    /** The short type. */
    public static final byte FRM_SHORT   =  3;

    /** The int type. */
    public static final byte FRM_INT     =  4;

    /** The long type. */
    public static final byte FRM_LONG    =  5;

    /** The float type. */
    public static final byte FRM_FLOAT   =  6;

    /** The double type. */
    public static final byte FRM_DOUBLE  =  7;

    /** The byte[] type. */
    public static final byte FRM_BYTES   =  8;

    /** The char[] type. */
    public static final byte FRM_CHARS   =  9;

    /** The String type. */
    public static final byte FRM_STRING  = 10;

    /** The StringBuffer type. */
    public static final byte FRM_STRBUF  = 11;

    /** The Date type. */
    public static final byte FRM_DATE    = 12;

    /** The Object type. */
    public static final byte FRM_OBJ     = 13;

    /** The String as array type. */
    public static final byte FRM_ASTRING = 14;

    /** The StringBuffer as array type. */
    public static final byte FRM_ASTRBUF = 15;

    /** The BigInteger type. */
    public static final byte FRM_BIGINT  = 17;

    /** The BigDecimal type. */
    public static final byte FRM_BIGDEC  = 18;

    /** The constant object denoting an error in inline calls. */
    private static final Varg ERR_OBJ = new Varg();  // error object

    /**
     * Guarantee that there is a free element in the array of the list.
     * Enlarge it if needed. Set the result accordingly so as to allow all
     * <code>v</code> methods exit when an error occurs.
     *
     * @return     -1 if error
     */

    private int ensureCapacity(){
        int   len = 0;
        int   newlen = 0;

        if (this == ERR_OBJ) return -1;
        alloc: try {
            if (this.list != null){
                len = this.list.length;
            }
            if (this.argNr >= len){
                newlen = len + ALLOC_QUANTUM;
                if (newlen < 0){               // overflow
                    this.argNr = 0;
                    len = -1;
                    break alloc;
                }
                Vargument[] newList = new Vargument[newlen];
                if (this.list != null){
                    System.arraycopy(this.list,0,newList,0,len);
                }
                this.list = newList;
            }
            if (this.list[this.argNr] == null){
                this.list[this.argNr] = new Vargument();
            }
        } catch (OutOfMemoryError exc){
            this.argNr = 0;
            len = -1;
        }
        return len;
    }

    /** The allocation granularity of elements. */
    protected static final int ALLOC_QUANTUM = 5;

    /**
     * Register a boolean value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(boolean v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_BOOL;
        this.list[this.argNr++].integral = v ? 1 : 0;
        return this;
    }

    /**
     * Register a Boolean value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(Boolean v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_BOOL;
        this.list[this.argNr++].integral = v.booleanValue() ? 1 : 0;
        return this;
    }

    /**
     * Register a character value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(char v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_CHAR;
        this.list[this.argNr++].integral = (char)v;
        return this;
    }

    /**
     * Register a Character value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(Character v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_CHAR;
        this.list[this.argNr++].integral = v.charValue();
        return this;
    }

    /**
     * Register a byte value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(byte v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_BYTE;
        this.list[this.argNr++].integral = v;
        return this;
    }

    /**
     * Register a Byte value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(Byte v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_BYTE;
        this.list[this.argNr++].integral = v.byteValue();
        return this;
    }

    /**
     * Register a short value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(short v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_SHORT;
        this.list[this.argNr++].integral = v;
        return this;
    }

    /**
     * Register a Short value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(Short v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_SHORT;
        this.list[this.argNr++].integral = v.shortValue();
        return this;
    }

    /**
     * Register an int value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(int v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_INT;
        this.list[this.argNr++].integral = v;
        return this;
    }

    /**
     * Register an Integer value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(Integer v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_INT;
        this.list[this.argNr++].integral = v.intValue();
        return this;
    }

    /**
     * Register a long value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(long v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_LONG;
        this.list[this.argNr++].integral = v;
        return this;
    }

    /**
     * Register a Long value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(Long v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_LONG;
        this.list[this.argNr++].integral = v.longValue();
        return this;
    }

    /**
     * Register a BigInteger value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(BigInteger v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_BIGINT;
        this.list[this.argNr++].obj = v;
        return this;
    }

    /**
     * Register a float value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(float v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_FLOAT;
        this.list[this.argNr++].real = v;
        return this;
    }

    /**
     * Register a Float value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(Float v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_FLOAT;
        this.list[this.argNr++].real = v.floatValue();
        return this;
    }

    /**
     * Register a double value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(double v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_DOUBLE;
        this.list[this.argNr++].real = v;
        return this;
    }

    /**
     * Register a Double value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(Double v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_DOUBLE;
        this.list[this.argNr++].real = v.doubleValue();
        return this;
    }

    /**
     * Register a BigDecimal value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(BigDecimal v){
        if (ensureCapacity() < 0) return ERR_OBJ;
        this.list[this.argNr].type = FRM_BIGDEC;
        this.list[this.argNr++].obj = v;
        return this;
    }

    /**
     * Register a byte[] value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(byte[] v){
        return v(v,0,(v == null)? 0 : v.length);
    }

    /**
     * Register a byte[] slice value in the list with a start index
     * of 0. The length must not he greater thant that of the value.
     *
     * @param      v value
     * @param      length of the slice
     * @return     this
     */

    public Varg v(byte[] v, int length){
        return v(v,0,length);
    }

    /**
     * Register a byte[] slice value in the list. The indexes
     * must denote a valid slice.
     *
     * @param      v value
     * @param      start index (inclusive)
     * @param      end index (non inclusive)
     * @return     this
     */

    public Varg v(byte[] v, int start, int end){
        Vargument p;
        if (ensureCapacity() < 0) return ERR_OBJ;
        p = this.list[this.argNr];
        p.type = FRM_BYTES;
        p.obj = v;
        p.integral = start;
        if (v != null) p.length = v.length;
        else p.length = 0;
        if ((start < 0) || (end-start < 0) || (end > p.length)){
            this.argNr = 0;                  // empty the list
            return ERR_OBJ;
        } else {
            p.length = end-start;
            this.argNr++;
        }
        return this;
    }

    /**
     * Register a char[] value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(char[] v){
        return v(v,0,(v == null)? 0 : v.length);
    }

    /**
     * Register a char[] slice value in the list with a start index
     * of 0. The length must not he greater thant that of the value.
     *
     * @param      v value
     * @param      length of the slice
     * @return     this
     */

    public Varg v(char[] v, int length){
        return v(v,0,length);
    }

    /**
     * Register a char[] slice value in the list. The indexes
     * must denote a valid slice.
     *
     * @param      start index (inclusive)
     * @param      end index (non inclusive)
     * @return     this
     */

    public Varg v(char[] v, int start, int end){
        Vargument p;
        if (ensureCapacity() < 0) return ERR_OBJ;
        p = this.list[this.argNr];
        p.type = FRM_CHARS;
        p.obj = v;
        p.integral = start;
        if (v != null) p.length = v.length;
        else p.length = 0;
        if ((start < 0) || (end-start < 0) || (end > p.length)){
            this.argNr = 0;                  // empty the list
            return ERR_OBJ;
        } else {
            p.length = end-start;
            this.argNr++;
        }
        return this;
    }

    /**
     * Register a Str value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(Str v){
        return v(v.buffer,0,(v == null)? 0 : v.length);
    }

    /**
     * Register a Str slice value in the io list with a start index
     * of 0. The length must not he greater thant that of the value.
     *
     * @param      v value
     * @param      length of the slice
     * @return     this
     */

    public Varg v(Str v, int length){
        return v(v.buffer,0,length);
    }

    /**
     * Register a Str slice value in the io list. The indexes
     * must denote a valid slice.
     *
     * @param      start index (inclusive)
     * @param      end index (non inclusive)
     * @return     this
     */

    public Varg v(Str v, int start, int end){
        return v(v.buffer,start,end);
    }

    /**
     * Register a String value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(String v){
        return v(v,0,(v == null)? 0 : v.length());
    }

    /**
     * Register a String slice value in the list with a start index
     * of 0. The length must not he greater thant that of the value.
     *
     * @param      v value
     * @param      length of the slice
     * @return     this
     */

    public Varg v(String v, int length){
        return v(v,0,length);
    }

    /**
     * Register a String slice value in the list. The indexes
     * must denote a valid slice.
     *
     * @param      v value
     * @param      start index (inclusive)
     * @param      end index (non inclusive)
     * @return     this
     */

    public Varg v(String v, int start, int end){
        Vargument p;
        if (ensureCapacity() < 0) return ERR_OBJ;
        p = this.list[this.argNr];
        p.type = FRM_STRING;
        p.obj = v;
        p.integral = start;
        if (v != null) p.length = v.length();
        else p.length = 0;
        if ((start < 0) || (end-start < 0) || (end > p.length)){
            this.argNr = 0;                  // empty the list
            return ERR_OBJ;
        } else {
            p.length = end-start;
            this.argNr++;
        }
        return this;
    }

    /**
     * Register a StringBuffer value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(StringBuffer v){
        return v(v,0,(v == null)? 0 : v.length());
    }

    /**
     * Register a String slice value in the list with a start index
     * of 0. The length must not he greater thant that of the value.
     *
     * @param      v value
     * @param      length of the slice
     * @return     this
     */

    public Varg v(StringBuffer v, int length){
        return v(v,0,length);
    }

    /**
     * Register a StringBuffer slice value in the list. The indexes
     * must denote a valid slice.
     *
     * @param      v value
     * @param      start index (inclusive)
     * @param      end index (non inclusive)
     * @return     this
     */

    public Varg v(StringBuffer v, int start, int end){
        Vargument p;
        if (ensureCapacity() < 0) return ERR_OBJ;
        p = this.list[this.argNr];
        p.type = FRM_STRBUF;
        p.obj = v;
        p.integral = start;
        if (v != null) p.length = v.length();
        else p.length = 0;
        if ((start < 0) || (end-start < 0) || (end > p.length)){
            this.argNr = 0;                  // empty the list
            return ERR_OBJ;
        } else {
            p.length = end-start;
            this.argNr++;
        }
        return this;
    }

    /**
     * Register a Date value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(Date v){
        Vargument p;
        if (ensureCapacity() < 0) return ERR_OBJ;
        p = this.list[this.argNr];
        p.type = FRM_DATE;
        p.obj = v;
        p.integral = 0;
        p.length = 0;
        this.argNr++;
        return this;
    }

    /**
     * Register a Number value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(Number v){
        Vargument p;
        if (ensureCapacity() < 0) return ERR_OBJ;
        Class c = v.getClass();
        p = this.list[this.argNr];
        if (c == Byte.class){
            p.type = FRM_BYTE;
            p.integral = v.intValue();
        } else if (c == Short.class){
            p.type = FRM_SHORT;
            p.integral = v.shortValue();
        } else if (c == Integer.class){
            p.type = FRM_INT;
            p.integral = v.intValue();
        } else if (c == Long.class){
            p.type = FRM_LONG;
            p.integral = v.longValue();
        } else if (c == Float.class){
            p.type = FRM_FLOAT;
            p.real = v.floatValue();
        } else if (c == Double.class){
            p.type = FRM_DOUBLE;
            p.real = v.doubleValue();
        }
        this.argNr++;
        return this;
    }

    /**
     * Register an Object value in the list.
     *
     * @param      v value
     * @return     this
     */

    public Varg v(Object v){
        Vargument p;
        if (ensureCapacity() < 0) return ERR_OBJ;
        p = this.list[this.argNr];
        p.obj = v;
        p.type = FRM_OBJ;
        p.integral = 0;
        if ((v != null) && (v.getClass().isArray())){
            p.length = Array.getLength(v);
        } else {
            p.length = -1;
        }
        this.argNr++;
        return this;
    }

    /**
     * Register an Object slice value in the list with a start index
     * of 0. The length must not he greater thant that of the value.
     *
     * @param      v value
     * @param      length of the slice
     * @return     this
     */

    public Varg v(Object v, int length){
        return v(v,0,length);
    }

    /**
     * Register an Object slice value in the list. The indexes are
     * not checked.
     *
     * @param      v value
     * @param      start index (inclusive)
     * @param      end index (non inclusive)
     * @return     this
     */

    public Varg v(Object v, int start, int end){
        Vargument p;
        if (ensureCapacity() < 0) return ERR_OBJ;
        p = this.list[this.argNr];
        p.type = FRM_OBJ;
        p.obj = v;
        p.integral = start;
        p.length = end-start;
        if ((start < 0) || (end-start < 0)){
            this.argNr = 0;                  // empty the list
            return ERR_OBJ;
        } else {
            this.argNr++;
        }
        return this;
    }

    /**
     * Trace the list.
     */

    public void listTrace(){
        String    s;
        byte      t;
        Vargument e;

        if (this.list == null){
            Trc.out.println("list empty");
            return;
        }
        Trc.out.println("list present: " + this.argNr +
           " capacity: " + this.list.length);
        for (int i = 0; i < this.argNr; i++){
            e = this.list[i];
            t = e.type;
            Trc.out.print(i);
            switch (t){
            case FRM_BOOL:   s = "boolean"; break;
            case FRM_CHAR:   s = "char"; break;
            case FRM_BYTE:   s = "byte"; break;
            case FRM_SHORT:  s = "short"; break;
            case FRM_INT:    s = "int"; break;
            case FRM_LONG:   s = "long"; break;
            case FRM_FLOAT:  s = "float"; break;
            case FRM_DOUBLE: s = "double"; break;
            case FRM_BYTES:  s = "byte[]"; break;
            case FRM_CHARS:  s = "char[]"; break;
            case FRM_STRING: s = "String"; break;
            case FRM_STRBUF: s = "StringBuffer"; break;
            case FRM_DATE:   s = "Date"; break;
            case FRM_OBJ:    s = "Object"; break;
            case FRM_BIGINT: s = "BigInteger"; break;
            case FRM_BIGDEC: s = "BigDecimal"; break;
            default:         s = "unknown";
            }
            Trc.out.print(" " + s + " type: " + t + " ");
            if (t <= FRM_LONG){
                Trc.out.print(e.integral);
            } else if ((t == FRM_FLOAT) ||
                (t == FRM_DOUBLE)){
                Trc.out.print(e.real);
            } else {
                if (e.obj != null){
                    Trc.out.print(e.obj.toString());
                } else {
                    Trc.out.print("null");
                }
                Trc.out.print(" " + e.integral + " : " +
                    e.length);
            }
            Trc.out.println();
        }
    }

    /*
    public static void main(String[] args){
        Varg va = new Varg();
        va.v(1).v("abc");
        va.listTrace();
        va.v(3).v(4).v(5);
        va.listTrace();
        va.v(6);
        va.listTrace();

        Varg va1 = new Varg();
        va1.v("abc",0,-2).v(1);
        va1.listTrace();
    }
    */
}
