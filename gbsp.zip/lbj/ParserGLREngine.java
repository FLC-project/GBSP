/*
 * @(#)ParserGLRengine.jpp       1.0 2020/07/14
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;
import java.io.*;
import lbj.ParserEngine;

/**
 * The <code>ParserGLRengine</code> class provides the common data and methods for all the
 * GLR parser engines
 *
 * @author  Angelo Borsotti
 * @version 1.0   14 Jul 2020
 */


// whether hashing for addsym used
// whether the sppf symbol nodes are linked with the other ones of the same nt (instead of a unique list)
// whether an autoaging for addsym used
// whether the strings of the tokens are saved in a list
// whether the standard node and edge adding technique has to be used
// whether the search is done testing first the first edge of a node

// whether the reducer that for each path applies all reductions is used

// whether the entries in the rwl represent all reductions from a state

abstract class ParserGLRengine extends ParserEngine {

    /** The version. */
    static String version = "V1.7";

    /** The name of the algorithm. */
    String algo;

    static final int NODE_EDGES = QUANTUM;
    static final int EDGE_TO = 1;
    static final int EDGE_SPPF = 2;
    static final int FL_A = 1 << ('a'-0x60);
    static final int FL_B = 1 << ('b'-0x60);
    static final int FL_C = 1 << ('c'-0x60);
    static final int FL_D = 1 << ('d'-0x60);
    static final int FL_G = 1 << ('g'-0x60);
    static final int FL_H = 1 << ('h'-0x60);
    static final int FL_I = 1 << ('i'-0x60);
    static final int FL_M = 1 << ('m'-0x60);
    static final int FL_O = 1 << ('o'-0x60);
    static final int FL_V = 1 << ('v'-0x60);
    static final int FL_W = 1 << ('w'-0x60);
    static final int FL_X = 1 << ('x'-0x60);
    static final int FL_Y = 1 << ('y'-0x60);
    static final int FL_Z = 1 << ('z'-0x60);

    /** 
     * Deliver the token number of the EOF.
     *
     * @return     token number
     */

    int eofTokNr(){
        return this.tab.numOfToks;
    }

    //------------ The parse tables --------------

    /** The length of the longest rule. */
    int longestRule;

    /** 
     * Trace the pilot using the specified writer.
     *
     * @param      trc writer
     */

    void tracePilot(PrintWriter trc){
        trc.printf("parse tables");
        trc.printf("\n");
        ParserLRTables lrt = (ParserLRTables)this.tab.pilot;
        lrt.lrTables.trace(trc);
    }

    /** 
     * Deliver a string representing the specified rule.
     *
     * @param      rule rule
     */

    String ruleToString(int rule){
        return this.tab.ruleToString(this.tab.ruleIndex[rule],false);
    }

    //------------ The GSS and SPPF --------------

    /* The GSS and SPPF.
     *
     * Each GSS node has a state number and a list of edges. To represent it with an array
     * we use two parallel arrays, the first holding the state number and the second as
     * a header of a list of edges, contained in the same arrays.
     * Edges have a node and a SPPF link, and to make a list of them, a next.
     * Note that edges are added only on the current level of GSS, so if we want to remove
     * an entire given level we can do so knowing that there are no pieces in other levels
     * that are edges belonging to the given one.
     *
     *            stateNode   links         sppf
     *     node   state-nr    edges-index
     *     edge   node-index  next-index    sppf-link
     *
     * These arrays are allocated in blocks. Representing sppf links with indexes into
     * some array that would contain the parse tree, we can put all these values in a
     * unique array:
     *
     *     node   state-nr
     *            edges-index
     *     edge   node-index
     *            next-index
     *            sppf-link
     *
     * References to nodes and edges are then integer indexes. To get the directory and
     * block indexes of a node (or edge) with reference i:
     *
     *     directory index:   i >>> NSHF       index in block: i & MSK
     *
     *     this.gssDir[i>>>NSHF][i&MSK]
     *
     * To have node numbers as consecutive numbers, place the fields of nodes in blocks
     * putting first all state fields of all nodes of a same block, then all edges fields,
     * and so on. The same for edges. Since nodes and blocks may have a different number
     * of fields, two block arrays: one for nodes and another for edges are used.
     */

    /** The number of gss nodes allocated. */
    int gssNodeLength;

    /** The index of the first free gss node. */
    int gssNodeNr;

    /** The number of gss edges allocated. */
    int gssEdgeLength;

    /** The index of the first free gss edge. */
    int gssEdgeNr;

    /** The block array for the nodes. */
    int[][] gssNodeDir;

    /** The block array for the edges. */
    int[][] gssEdgeDir;

    /** The default number of fields of nodes. */
    int NODE_FIELDS = 2;

    /** The default number of fields of edges. */
    int EDGE_FIELDS = 3;

    /**
     * Enlarge the gss nodes or edges by one block.
     *
     * @param    kind 0: nodes, 1: edges
     */

    void enlargeGSS(int kind){
        int[][] dir = (kind == 0) ? this.gssNodeDir : this.gssEdgeDir;
        int length = (kind == 0) ? this.gssNodeLength: this.gssEdgeLength;
        int nr = (kind == 0) ? this.gssNodeNr: this.gssEdgeNr;
        ;
        if (dir == null){                   // first time
            dir = new int[16][];
            nr = 1;                         // 0 never used, it means null
        }
        int dirindex = length >> NSHF;
        if (dirindex >= dir.length){
            dir = Arrays.copyOf(dir,dir.length << 1);
            ;
        }
        length += QUANTUM;
        if (length < 0){
            throw new OutOfMemoryError();
        }
        int nrFields = (kind == 0) ? NODE_FIELDS : 1;
        dir[dirindex] = new int[QUANTUM*nrFields];
        // TRACE(M,"enlarge: block %d size %d free %d length %d\n",dirindex,QUANTUM,nr,length);
        if (kind == 0){
            this.gssNodeDir = dir;
            this.gssNodeLength = length;
            this.gssNodeNr = nr;
        } else {
            this.gssEdgeDir = dir;
            this.gssEdgeLength = length;
            this.gssEdgeNr = nr;
        }
        // TRACE(M,"enlarge end: %s\n",gssBlocksToString());
        ;
    }

    /**
     * Deliver a string representing the number GSS blocks.
     *
     * @return   string
     */

    String gssBlocksToString(){
        int tot = gssSize();
        int nrFields = 1;
        int nodeblks = 0;
        if (this.gssNodeDir != null){
            for (int i = 0; i < this.gssNodeDir.length; i++){
                if (this.gssNodeDir[i] == null) break;
                nodeblks++;
            }
        }
        int edgeblks = 0;
        if (this.gssEdgeDir != null){
            for (int i = 0; i < this.gssEdgeDir.length; i++){
                if (this.gssEdgeDir[i] == null) break;
                edgeblks++;
            }
        }
        return String.format("gss %d nodes blocks %d of %d free %d - " +
            "edges blocks %d of %d free %d - gssNodeNr %d gssEdgeNr %d",
            gssSize(),nodeblks,QUANTUM*NODE_FIELDS,this.gssNodeLength-this.gssNodeNr,
            edgeblks,QUANTUM*nrFields,this.gssEdgeLength-this.gssEdgeNr,
            this.gssNodeNr,this.gssEdgeNr);
    }

    /**
     * Deliver a string representing the GSS blocks.
     *
     * @param    kind 0: nodes, 1: edges
     * @return   string
     */

    String blocksToString(int kind){
        StringBuilder str = new StringBuilder();
        int[][] dir = kind == 0 ? this.gssNodeDir : gssEdgeDir;
        for (int i = 0; i < dir.length; i++){
            if (dir[i] == null) break;
            if (str.length() > 0) str.append(' ');
            str.append(dir[i].length);
        }
        return str.toString();
    }

    /**
     * Deliver the size of the GSS.
     *
     * @return   size
     */

    int gssSize(){
        int size = 0;
        size += arraySize(this.gssNodeDir);
        size += arraySize(this.gssEdgeDir);
        return size;
    }

    /**
     * Deliver the size of the specified integer array.
     *
     * @param    arr array
     * @return   size
     */

    int arraySize(int[] arr){
        if (arr == null) return 0;
        return arr.length * 4;
    }

    /**
     * Deliver the size of the specified integer block array.
     *
     * @param    arr array
     * @return   size
     */

    int arraySize(int[][] arr){
        if (arr == null) return 0;
        int res = arr.length * 4;
        for (int i = 0; i < arr.length; i++){
            if (arr[i] != null) res += arr[i].length * 4;
        }
        return res;
    }

    /**
     * Enlarge the block array of edges so as to have an element at the specified
     * index.
     *
     * @param   idx index
     */

    void enlargeEdges(int idx){
        int curblocks = 0;
        if (this.gssEdgeDir != null){
            curblocks = this.gssEdgeDir.length;   // length of block directories
        }
        int hiblock = (idx >>> NSHF) + 1;         // number of blocks needed
        // TRACE(M,"enlargeEdges: hiblock %d idx %d\n",
        //     hiblock,idx);
        if (hiblock > curblocks){                 // enlarge block directory
            int newblocks = hiblock;
            newblocks--;                          // ceil it to the next power of 2
            newblocks |= (newblocks >> 1);
            newblocks |= (newblocks >> 2);
            newblocks |= (newblocks >> 4);
            newblocks |= (newblocks >> 8);
            newblocks |= (newblocks >>16);
            newblocks++;
            // TRACE(M,"enlargeEdges: newblocks %d\n",newblocks);
            if (newblocks < 0){
                throw new OutOfMemoryError();
            }
            int[][] n = new int[newblocks][];
            if (this.gssEdgeDir != null){
                System.arraycopy(this.gssEdgeDir,0,n,0,curblocks);
            }
            this.gssEdgeDir = n;
        }
        int block = ((this.gssEdgeLength - 1) >> NSHF) + 1;
        while (block < hiblock){            // allocate now the blocks
            // TRACE(M,"enlargeEdges: allocate %d to %d\n",
            //     block,hiblock);
            this.gssEdgeDir[block++] = new int[QUANTUM];
            if (block < 0){
                throw new OutOfMemoryError();
            }
            this.gssEdgeLength += QUANTUM;
        }
        // TRACE(M,"enlarge end: %s\n",gssBlocksToString());
        ;
    }

    /* Sentinels
     *
     * Each level in GSS nodes is delimited by sentinels. A sentinel is made by a couple
     * of special nodes that have the following data:
     *
     *            first field             second field
     *  sentinel  - level - 1             head of symbol list of previous level
     *            - end index of nodes    end index of edges
     *  first node   <- levelGss
     *  N.B. The end indexes are set in the sentinel of the current level only when the
     *  sentinel of the next is created.
     *  The end index of nodes is the first index after the next sentinel.
     */

    /** Whether makeSentinel allocates all hash directories. */
    boolean hashsentinel = true;

    /** Whether makeSentinel allocates the edges hash directories. */
    boolean hashsentineledgedir = false;

    /**
     * Add a sentinel to the GSS.
     */

    void makeSentinel(){
        ;
        // Trc.out.printf("lev: %d levelGss %d absLevelGss %d\n",
        //    this.level,this.levelGss,this.absLevelGss);
        int nodesnr = this.gssNodeNr-this.levelGss;
        int edgesnr = this.gssEdgeNr-this.levelEdgeGss;
        // Trc.out.printf("%d %d %s\n",this.level,this.gssNodeNr,
        //    this.tab.tokLitName(this.currentToken));
        // Trc.out.printf("level %d nodes %d edges %d\n",this.level,
        //    this.gssNodeNr-this.levelGss,this.gssEdgeNr-this.levelEdgeGss);
        // Trc.out.printf("level %d mem %d\n",this.level,
        //    (this.gssNodeNr-this.levelGss)*3+this.gssEdgeNr-this.levelEdgeGss);
        // Trc.out.printf("lev: %d tree %d\n",this.level,this.loc);
        // Trc.out.printf("lev: %d gss %d nodes %d edges %d %s\n",
        //    this.level,gssSize(),this.gssNodeNr-this.levelGss,
        //    this.gssEdgeNr-this.levelEdgeGss,gssBlocksToString());
        if (this.gssNodeNr >= this.gssNodeLength){
            enlargeGSS(0);
        }
        int s = this.gssNodeNr++;
        gssNodeDir[(s)>>>NSHF][((s)&MSK)] = -this.level-1;      // mark this node as sentinel
        if (this.gssNodeNr >= this.gssNodeLength){
            enlargeGSS(0);
        }
        int n = this.gssNodeNr++;
        gssNodeDir[(n)>>>NSHF][((n)&MSK)] = -1;                               // mark this node as sentinel
        if (this.level > 0){
            gssNodeDir[(this.levelGss-1)>>>NSHF][((this.levelGss-1)&MSK)] = -this.gssNodeNr;  // update end index of nodes
            gssNodeDir[(this.levelGss-1)>>>NSHF][((this.levelGss-1)&MSK)+NODE_EDGES] = this.gssEdgeNr;   // store end index of edges
        }
        gssNodeDir[(n)>>>NSHF][((n)&MSK)+NODE_EDGES] = 0;                                // clear it
        ;
        ;
        ;
        if (this.level > 0){
            ;
        }
        // Trc.out.printf("level %d sentinel at %d\n",this.level-1,this.gssNodeNr);
        ;

        // it would be better to allocate them in each parser
        if (this.hashsentinel){
            if (this.sppfsymhdir == null){
                this.sppfsymhdir = new int[64];
                this.sppfrulehdir = new int[64];
                this.edgeshlink = new int[256];
                this.edgeshdata = new int[256];
                this.edgeshdir = new int[64];
                this.nodeshdir = new int[64];
                this.nodeshlink = new int[256];
            } else {
                // it would be better to enlarge each one according to its elements
                if (edgesnr >>> 2 > this.sppfsymhdir.length){
                    int newlen = floor2(edgesnr) >>> 2;
                    if (this.sppfsymhdir.length < newlen){
                        this.sppfsymhdir = new int[newlen];   // 1/4 of elements
                        this.sppfrulehdir = new int[newlen];  // 1/4 of elements
                        this.edgeshdir = new int[newlen];     // 1/4 of elements
                        ;
                    }
                }
                if (nodesnr >>> 2 > this.nodeshdir.length){
                    int newlen = floor2(nodesnr) >>> 2;
                    if (this.nodeshdir.length < newlen){
                        this.nodeshdir = new int[newlen];     // 1/4 of elements
                        ;
                    }
                }
            }
        }
        if (this.hashsentineledgedir){
            if (this.edgeshdir == null){
                this.edgeshlink = new int[256];
                this.edgeshdata = new int[256];
                this.edgeshdir = new int[64];
            } else {
                if (edgesnr >>> 2 > this.sppfsymhdir.length){
                    int newlen = floor2(edgesnr) >>> 2;
                    if (this.edgeshdir.length < newlen){
                        this.edgeshdir = new int[newlen];     // 1/4 of elements
                        ;
                    }
                }
            }
        }
    }

    /**
     * Deliver the closest lower power of 2 of the specified number.
     *
     * @param    a number
     * @return   lower power of 2
     */

    static int floor2(int x){
        int floor = x;
        floor |= (floor >> 1);
        floor |= (floor >> 2);
        floor |= (floor >> 4);
        floor |= (floor >> 8);
        floor |= (floor >> 16);
        floor -= (floor >>> 1);
        return floor;
    }

    /* The hash directory of nodes. */
    int[] nodeshdir;

    /* The hash links of nodes. */
    int[] nodeshlink;

    /* The hash directory of edges. */
    int[] edgeshdir;

    /* The hash links of edges. */
    int[] edgeshlink;

    /* The hash data of edges. */
    int[] edgeshdata;

    /* The hash directory of sppf symbol nodes. */
    int[] sppfsymhdir;

    /* The hash directory of sppf rule nodes. */
    int[] sppfrulehdir;
    /**
     * Deliver a string representing the specified sentinel.
     *
     * @param    s index of the sentinel
     * @return   string
     */

    protected String sentinelToString(int s){
        return String.format("sentinel: %d: (level %d), %d: (endnodes %d, endedges %d)",
            s,-gssNodeDir[(s)>>>NSHF][((s)&MSK)]-1,s+1,-gssNodeDir[(s+1)>>>NSHF][((s+1)&MSK)]-2,gssNodeDir[(s+1)>>>NSHF][((s+1)&MSK)+NODE_EDGES]);
    }

    /**
     * Trace the sentinels in the GSS.
     */

    void traceSentinels(){
        for (int i = 0; i != -1; i = -gssNodeDir[(i+1)>>>NSHF][((i+1)&MSK)]-2){
            int lev = this.level;
            if (i < this.levelGss-2){
                lev = -gssNodeDir[(i)>>>NSHF][((i)&MSK)]-1;
            }
            ;
        }
    }

    /** The number of the current level. */
    int level;

    /** The initial node index of the current level. */
    int levelGss;

    /** The initial edge index of the current level. */
    int levelEdgeGss;

    /** The difference between the current and the absolute level. */
    int delta;

    /** The absolute start index of the first node in current level. */
    int absLevelGss;

    /** The difference between the current and the absolute level for edges. */
    int deltaEdges;

    /** The absolute start index of the first node in current level. */
    int absLevelGssEdges;
    /**
     * Add a new node to the GSS with an edge to the specified node.
     *
     * @param    state state or dot
     * @param    to end node of the edge
     * @param    tree sppf of the edge
     * @return   index of the node
     */

    int newGSSENode(int state, int to, int tree){
        return 0;
    }

    /**
     * Add a new node to the GSS.
     *
     * @param    state state or dot
     * @return   index of the node
     */

    int newGSSNode(int state){
        if (this.gssNodeNr >= this.gssNodeLength){
            enlargeGSS(0);
        }
        int n = this.gssNodeNr++;
        gssNodeDir[(n)>>>NSHF][((n)&MSK)] = state;
        gssNodeDir[(n)>>>NSHF][((n)&MSK)+NODE_EDGES] = 0;
        this.stater[state] = n;
        ;
        return n;
    }

    /* The autoaging array that tells if a node with the state in index is already
     * present in the current level. */
    int[] stater;

    /* The index of the edge, if added, -1 otherwise. */
    int addedEdge;

    /* The number of nodes added. */
    int addNodeNr;

    /**
     * Add a new node to the GSS, optionally if it is not already there,
     * with an edge to the specified node.
     *
     * @param    st state or dot
     * @param    le end node of the edge
     * @param    sppf sppf of the edge
     * @param    dupl 0: no duplication check
     * @return   index of the node
     */

    int addNode(int st, int le, int sppf, int dupl){
        return 0;
    }

    /**
     * Search an edge from the specified start node to the specified end node.
     *
     * @param    itm start node of the edge
     * @param    le end node of the edge
     * @return   index of the node
     */

    int searchNodeEdge(int itm, int le){
        return 0;
    }

    /**
     * Add an edge from the specified start node to the specified end node with
     * the specified sppf.
     *
     * @param    from start node of the edge
     * @param    to end node of the edge
     * @param    tree sppf of the edge
     * @return   index of the edge
     */

    int addGSSLink(int from, int to, int tree){
        ;
        int l = 0;
        got: {
            if (from > 0){
                for (int i = gssNodeDir[(from)>>>NSHF][((from)&MSK)+NODE_EDGES] & 0x7fffffff; i != 0; i = gssEdgeDir[(i)>>>NSHF][((i)&MSK)]){
                    if (gssEdgeDir[(i+EDGE_TO)>>>NSHF][((i+EDGE_TO)&MSK)] == to){     // already present
                        break got;
                    }
                }
            }
            if (this.gssEdgeNr+EDGE_FIELDS > this.gssEdgeLength){
                enlargeGSS(1);
            }
            l = this.gssEdgeNr;
            this.gssEdgeNr = l + EDGE_FIELDS;
            gssEdgeDir[(l+EDGE_TO)>>>NSHF][((l+EDGE_TO)&MSK)] = to;
            gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = 0;
            gssEdgeDir[(l+EDGE_SPPF)>>>NSHF][((l+EDGE_SPPF)&MSK)] = tree;
            ;
        } // got
        if (l > 0){
            gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = gssNodeDir[(from)>>>NSHF][((from)&MSK)+NODE_EDGES] & 0x7fffffff;
            gssNodeDir[(from)>>>NSHF][((from)&MSK)+NODE_EDGES] = l;
        }
        ;
        return l;
    }

    /**
     * Deliver the level of the specified GSS node.
     *
     * @param    node index of the node
     * @return   number of the level
     */

    int nodeToLevel(int node){
        while (gssNodeDir[(node)>>>NSHF][((node)&MSK)] >= 0) node--;
        node --;
        return - gssNodeDir[(node)>>>NSHF][((node)&MSK)];
    }

    /**
     * Deliver a string representing the specified edge.
     *
     * @param    edge index of the edge
     * @param    tok token, if the edge has one
     * @return   string
     */

    String edgeToString(int edge, int tok){
        return null;
    }

    /**
     * Deliver a string representing the specified edge.
     *
     * @param    edge index of the edge
     * @return   string
     */

    String GSSEdgeToString(int edge){
        String str = null;
        int el = gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)];
        if (el < 0){
            str = getLexeme(getLexNr(el));
        } else {
            str = Integer.toString(el & ~HEADF);
        }
        return String.format("%d next %d to %d sppf %s",
            edge,gssEdgeDir[(edge)>>>NSHF][((edge)&MSK)],gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)],str);
    }

    /**
     * Deliver a string representing the specified node.
     *
     * @param    node index of the node
     * @return   string
     */

    String GSSNodeToString(int node){
        return GSSNodeToString(node,false);
    }

    /**
     * Deliver a string representing the specified node.
     *
     * @param    node index of the node
     * @param    abbr <code>true</code> if abbraviated, <code>false</code> otherwise
     * @return   string
     */

    String GSSNodeToString(int node, boolean abbr){
        StringBuilder str = new StringBuilder();
        int state = gssNodeDir[(node)>>>NSHF][((node)&MSK)];
        String sym = GSSsymbol(state);
        if (abbr){
            str.append(String.format("node state %s/%d ->",GSSlabel(state),nodeToLevel(node)));
        } else {
            str.append(String.format("node %d state %s sym %s edges to:",
                node,GSSlabel(state),sym));
        }
        for (int l = gssNodeDir[(node)>>>NSHF][((node)&MSK)+NODE_EDGES] & 0x7fffffff; l != 0; l = gssEdgeDir[(l)>>>NSHF][((l)&MSK)]){
            int to = gssEdgeDir[(l+EDGE_TO)>>>NSHF][((l+EDGE_TO)&MSK)];
            int tostate = gssNodeDir[(to)>>>NSHF][((to)&MSK)];
            if (abbr){
                str.append(' ');
                str.append(tostate);
                str.append('/');
                str.append(nodeToLevel(to));
            } else {
                str.append(String.format(" %s:%d(%s)%d",sym,to,GSSlabel(tostate),gssEdgeDir[(l+EDGE_SPPF)>>>NSHF][((l+EDGE_SPPF)&MSK)]));
            }
        }
        return str.toString();
    }

    /**
     * Deliver a string representing the specified label, which is the label iteself
     * or the nonterminal that it denotes (if the label denotes one).
     *
     * @param    l label
     * @return   string
     */

    String GSSlabel(int l){
        if ((l & 0x40000000) == 0){
            String lalr = "";
            // if (BOOL_GET(tablalr.isLALRStates,l)) lalr = "l";
            return String.format("%d%s",l,lalr);
        } else {                      // bookeeping node
            l &= 0x3fffffff;
            int nt = l >> 20;
            int m = l & 0xfffff;
            return String.format("%s_%d",this.tab.gramSymToString(nt),m);
        }
    }

    /**
     * Deliver a string representing the specified GSS sppf.
     *
     * @param    s index of the sppf
     * @return   string
     */

    String sppfSymToString(int s){
        int link = gssEdgeDir[(s)>>>NSHF][((s)&MSK)];
        int cover = gssEdgeDir[(s+1)>>>NSHF][((s+1)&MSK)] & ~HEADSYM;
        String covertree = null;
        if ((cover & HEADTREE) != 0){
            int tree = cover & ~HEADTREE;
            covertree = String.format("tree: %d",tree);
        } else {
            covertree = String.format("cover: %d",cover);
        }
        int remap = gssEdgeDir[(s+2)>>>NSHF][((s+2)&MSK)];
        int nt = gssEdgeDir[(s+3)>>>NSHF][((s+3)&MSK)];
        String visited = (nt & (1 << 29)) != 0 ? "visited" : "";
        String tovisit = (nt & (1 << 28)) != 0 ? "tovisit" : "";

        nt &= 0xfffffff;
        String label = null;
        if ((nt & UNLABELLED) != 0){
            label = "unlabelled";
        } else {
            label = this.tab.ntStrings[nt];
        }
        return String.format("%d link: %d %s remap: %d nt: %s %s %s",
            s,link,covertree,remap,label,visited,tovisit);
    }

    /** The flag marking the nt of the sppf as unlabelled. */
    static int UNLABELLED = 0x8000000;

    /**
     * Deliver a string representing the specified GSS sppf rule node.
     *
     * @param    r index of the sppf
     * @return   string
     */

    String sppfRuleToString(int r){
        return sppfRuleToString(r,true);
    }

    /**
     * Deliver a string representing the specified GSS sppf rule node.
     *
     * @param    r index of the sppf
     * @param    full <code>true</code> to include the index and rule
     * @return   string
     */

    String sppfRuleToString(int r, boolean full){
        int len = ruleNodeLen(r) - 2;
        int rule = gssEdgeDir[(r+1)>>>NSHF][((r+1)&MSK)] & 0xfffffff;
        StringBuilder str = new StringBuilder();
        if (full){
            int link = 0;
            link = gssEdgeDir[(r)>>>NSHF][((r)&MSK)] & ~HEADSYM;
            str.append(String.format("%d link: %d rule: %s %d elements:",
                r,link,this.tab.ruleToString(this.tab.ruleIndex[rule],false),len));
        }
        str.append(this.tab.gramSymToString(this.tab.ruleToNt[rule]));
        str.append(r);
        str.append(" ->");
        for (int i = 0; i < len; i++){
            if (full || i > 0){
                str.append(' ');
            }
            int el = gssEdgeDir[(r+i+2)>>>NSHF][((r+i+2)&MSK)];
            if (el == 0){                   // nullable nt
                int p = this.tab.ruleIndex[rule];
                int gp = this.tab.grammar[p+i];
                // str.append("e-nt");
                str.append(this.tab.gramSymToString(gp));
                str.append("e");
            } else if (el == -1){           // invalid
                str.append("?");
            } else if (el < 0){             // token
                int tk = getLexNr(el);
                str.append(getLexeme(tk));
                long pt = getPoint(el);
                String pts = pt >= 0 ? Long.toString(pt) : "";
                str.append(pts);
            } else if ((el & HEADF) != 0){  // already built
                el &= ~HEADF;
                int nt = getNt(el);
                str.append(this.tab.gramSymToString(nt));
                str.append(el);
                str.append("t");
            } else {
                int nt = gssEdgeDir[(el-1)>>>NSHF][((el-1)&MSK)];
                str.append(this.tab.gramSymToString(nt));
                str.append(el);
            }
        }
        return str.toString();
    }

    /**
     * Trace the list (i.e. the GSS level) that starts at the specified index.
     *
     * @param    start index of the sentinel
     */

    void traceItemsList(int start){
        Trc.out.printf("list: %d\n",-gssNodeDir[(start)>>>NSHF][((start)&MSK)]-1);
        start += 2;
        for (int i = start; i < this.gssNodeNr; i++){   // scan list
            if (gssNodeDir[(i)>>>NSHF][((i)&MSK)] < 0) break;                  // not the current list: sentinel
            Trc.out.printf("%s\n",itemToString(i));
        }
    }

    /**
     * Trace all the lists (i.e. the GSS levels).
     */

    void traceItemsLists(){
        for (int i = 0; i < this.gssNodeNr; i++){   // scan all lists
            if (gssNodeDir[(i)>>>NSHF][((i)&MSK)] < 0){                    // sentinel
                Trc.out.printf("list: %d\n",-gssNodeDir[(i)>>>NSHF][((i)&MSK)]-1);
                i++;
            } else {
                Trc.out.printf("%s\n",itemToString(i));
            }
        }
    }

    /**
     * Check the consistency of the GSS and print a message if it it not consistent.
     *
     * @param    msg message
     * @return   <code>false</code> if inconsistent, and <code>true</code> otherwise
     */

    protected boolean checkEGSS(String msg){
        boolean res = true;
        return res;
    }

    /** 
     * Build a fragment of forest in the GSS collecting the elements that are present
     * in the specified path, adding the rn tail if any and putting them in a (so called)
     * SPPF rule node (which is just a derivation here rather than a rule), creating also
     * a SPPF symbol node if one is not already present with the desired cover, or return
     * one if an identical one already exists.
     *
     * @param   path edges of the reduction path
     * @param   symNode: index of the symbol node, if already present, 0 to create one
     * @param   mutated <code>true</code> if the path is in forward ordering and contains
     *          edge indexes, <code>false</code> if reverse ordering and contains sppf indexes
     * @return  index of the sppf node
     */

    /* The cover of the derivation to be added is represented with the index of the
     * level at which its first element starts.
     * A hash table links all the GSS SPPFs and allows to find quicly one that has the
     * desired nt and cover.
     * Another hash table links all the rule nodes that have the desired nt and elements
     * and allows to find quickly if the desired rule node is already present.
     */

    int addSymGSSnode(int[] path, int symNode, boolean mutated){
        if (mutated){
        } else {
            ;
        }
        int len = path[0];
        int rule = path[len+3];
        if (rule == -1) rule = tab.ruleToNt.length - 1;
        int tonode = path[len+1];
        int lhs = this.tab.ruleToNt[rule];

        ;

        if (!mutated){                        // replace indexes of edges with sppfs in path
            for (int i = path[0]; i > 0; i--){
                ;
                path[i] = gssEdgeDir[(path[i]+EDGE_SPPF)>>>NSHF][((path[i]+EDGE_SPPF)&MSK)];
            }
        }

        int rlen = (int)this.tab.ruleLen[rule];
        if (len < rlen){                                   // there are e-nts
            System.arraycopy(path,1,path,rlen-len+1,len);  // shift down
            int d = this.tab.ruleIndex[rule] + len;        // index in grammar of the first
            for (int i = rlen-len; i > 0; i--, d++){       // .. nullable in rn tail
                // int nt = this.tab.grammar[d];
                path[i] = 0;
            }
            len = rlen;
        }

        // - here I need to know the level in which the end node lies, but could I use the end node
        //   in place of the level number for the cover? not quite sure.
        // - when the path length is 1 this test is simpler: either the end node is in the current
        //   level or it is in the previous one
        // - with large sentinels we have the absolute level numbers, so we use them; the gss index
        //   of the lookback level should also be ok, even in case of popping because the lookback
        //   level is not popped
        int tonodeLev = tonode--;
        while (gssNodeDir[(tonodeLev)>>>NSHF][((tonodeLev)&MSK)] >= 0) tonodeLev--; 

        int targetSentinel = tonodeLev - 1;
        int thislev = this.levelGss - 2;
        if (gssNodeDir[(targetSentinel)>>>NSHF][((targetSentinel)&MSK)] == gssNodeDir[(thislev)>>>NSHF][((thislev)&MSK)]){    // empty string
            tonodeLev = 0;
            ;
            return 0;
        }
        int start = this.gssEdgeNr;
        int lastRule = 0;
        // simpler solution, with the link
        // there are cases in which we know already the symbol node, so skip search
        int hfunct = (lhs + tonodeLev) & (this.sppfsymhdir.length - 1);
        int hfunctrule = 0;
        sy: if (symNode == 0){
            ;
            for (int z = this.sppfsymhdir[hfunct];
                z >= this.absLevelGssEdges; z = this.edgeshlink[z-this.absLevelGssEdges]){
                int s = z - this.deltaEdges;
                if ((gssEdgeDir[(s+3)>>>NSHF][((s+3)&MSK)] == lhs) &&
                    ((gssEdgeDir[(s+1)>>>NSHF][((s+1)&MSK)] & ~HEADSYM) == tonodeLev)){    // found
                    symNode = s + 4;
                    ;
                    break;
                }
            }

        } else {
            ;
        }
        hfunctrule = rule + symNode;
        if (symNode == 0) hfunctrule += this.gssEdgeNr + 4;
        for (int i = len, p = this.tab.ruleIndex[rule]; i > 0; i--, p++){
            if (path[i] == 0) continue;      // empty nt
            int nt = this.tab.grammar[p];
            if (nt < this.tab.tokBase){      // it is a nt
                if ((path[i] & ~HEADTREE) == this.etrees[nt]) continue;  // empty nt
            }
            hfunctrule = 31*hfunctrule + path[i];
        }
        hfunctrule &= this.sppfsymhdir.length - 1;
        boolean createRule = false;
        boolean embeddedRule = false;
        boolean symadded = false;
        doit: if (symNode == 0){          // create it
            symadded = true;
            // compute length of node
            int nrfields = 6 + len;
            // enlarge block if no sufficient space available
            ;
            if (this.gssEdgeNr+nrfields > this.gssEdgeLength){
                enlargeEdges(this.gssEdgeNr+nrfields);
                /*
                TRACE(M,"addSymGSSnode enlarged %d blocks: %s\n",
                    this.gssEdgeNr,gssBlocksToString());
                */
            }
            int next = 0;
            int z = this.gssEdgeNr - this.levelEdgeGss;      // relative to level
            if (z >= this.edgeshlink.length){
                int newlen = z << 1;
                if (z < this.edgeshlink.length << 1){        // extend at least twice
                    newlen = this.edgeshlink.length << 1;
                }
                // this perhaps also in other places in which an unknown amount is needed
                this.edgeshlink = Arrays.copyOf(this.edgeshlink,newlen);
                this.edgeshdata = Arrays.copyOf(this.edgeshdata,newlen);
            }
            this.edgeshlink[z] = this.sppfsymhdir[hfunct];   // insert at beginning
            this.sppfsymhdir[hfunct] = this.gssEdgeNr + this.deltaEdges;
            // use edgeshdata[] to hold the tail of the list of rules
            this.edgeshdata[z] = this.gssEdgeNr + 4;
            ;

            gssEdgeDir[(this.gssEdgeNr+1)>>>NSHF][((this.gssEdgeNr+1)&MSK)] = tonodeLev | HEADSYM;   // cover
            // what does it mean that I use it for the level?
            gssEdgeDir[(this.gssEdgeNr+2)>>>NSHF][((this.gssEdgeNr+2)&MSK)] = 0;                     // remapping, used now for the level
            gssEdgeDir[(this.gssEdgeNr+3)>>>NSHF][((this.gssEdgeNr+3)&MSK)] = lhs;
            this.gssEdgeNr += 4;
            // create embedded rule node
            symNode = this.gssEdgeNr;
            createRule = true;
            embeddedRule = true;
            lastRule = this.gssEdgeNr;
            ;
            sppfsize += 8;
        } else {
            // check if it has the same rule
            // here check that the children are the same, and perhaps also the rule number.
            // - what would happen if the nonterminal has two rules that are different but have the
            //   same children? It would occur only if it has two identical rules

            // - But then I could in brnglr avoid to check duplicated rules (because there is
            //   a check in encode). No: extra derivations get added to the forest.

            ;

            //addsymgssrulenr = 0;
            //addsymgssruleelnr = 0;
            hloop: for (int z = this.sppfrulehdir[hfunctrule];
                z >= this.absLevelGssEdges; z = this.edgeshlink[z-this.absLevelGssEdges]){
                //addsymgssrulenr++;
                if (this.edgeshdata[z-this.absLevelGssEdges] != symNode) continue;
                int ri = z - this.deltaEdges;
                if ((gssEdgeDir[(ri+1)>>>NSHF][((ri+1)&MSK)] & ~HEADF) != rule) continue;
                int end = ri + 2 + len;          // end of rule
                for (int i = ri + 2, j = len, p = this.tab.ruleIndex[rule];
                    i < end; i++, j--, p++){
                    if (path[j] == 0) continue;      // empty nt
                    int nt = this.tab.grammar[p];
                    if (nt < this.tab.tokBase){      // it is a nt
                        if ((path[j] & ~HEADTREE) == this.etrees[nt]) continue;  // empty nt
                    }
                    if (path[j] != gssEdgeDir[(i)>>>NSHF][((i)&MSK)]) continue hloop;
                }
                ;
                break doit;
            }
            // lastRule = symNode;
            // there is no such a child, create it
            createRule = true;
        } // doit
        int startrule = -1;
        if (createRule){
            ;
            lastRule = this.edgeshdata[symNode - this.levelEdgeGss - 4];
            if (!embeddedRule){                    // append it to the list for this symbol node
                gssEdgeDir[(lastRule)>>>NSHF][((lastRule)&MSK)] = this.gssEdgeNr | HEADSYM;
                // update the tail of rules in the entry relative to the top of symbol node
                this.edgeshdata[symNode - this.levelEdgeGss - 4] = this.gssEdgeNr;
                ;
                // enlarge blocks if no sufficient space available
                ;
                if (this.gssEdgeNr+len+2 > this.gssEdgeLength){
                    enlargeEdges(this.gssEdgeNr+len+2);
                    /*
                    TRACE(M,"addSymGSSnode enlarged %d blocks: %s\n",
                        this.gssEdgeNr,gssBlocksToString());
                    */
                }
            }
            int z = this.gssEdgeNr - this.levelEdgeGss;      // relative to level
            if (z >= this.edgeshlink.length){
                int newlen = z << 1;
                if (z < this.edgeshlink.length << 1){        // extend at least twice
                    newlen = this.edgeshlink.length << 1;
                }
                this.edgeshlink = Arrays.copyOf(this.edgeshlink,newlen);
                this.edgeshdata = Arrays.copyOf(this.edgeshdata,newlen);
            }
            this.edgeshlink[z] = this.sppfrulehdir[hfunctrule];  // insert at beginning
            this.sppfrulehdir[hfunctrule] = this.gssEdgeNr + this.deltaEdges;
            // set entry relative to the rule node
            this.edgeshdata[z] = symNode;
            ;
            ;
            startrule = this.gssEdgeNr;
            gssEdgeDir[(this.gssEdgeNr)>>>NSHF][((this.gssEdgeNr)&MSK)] = HEADSYM;     // next rule
            this.gssEdgeNr++;
            int hdr = rule;
            // int kind = this.tab.ntKind[lhs];
            // if (kind <= ParserTables.REF){         // repetition group
            //    hdr = len + this.tab.numOfRules;
            // }
            gssEdgeDir[(this.gssEdgeNr)>>>NSHF][((this.gssEdgeNr)&MSK)] = HEAD | hdr;
            this.gssEdgeNr++;
            sppfsize += 4;
            ;
            for (int i = len; i > 0; i--){
                int sppf = path[i];
                gssEdgeDir[(this.gssEdgeNr)>>>NSHF][((this.gssEdgeNr)&MSK)] = sppf;
                this.gssEdgeNr++;
                sppfsize += 2;
                ;
            }
            ;
        }
        ;
        return symNode;
    }


    /** The autoaging array that tells if a sppf for the nt in index is already present
     * in the level. */
    int[] sppfer;
    /**
     * Deliver a string representing the symbol/state of the specified GSS node.
     *
     * @param      l index of the node
     * @return     string
     */

    String GSSsymbol(int l){
        ParserLRTables lrt = (ParserLRTables)this.tab.pilot;
        if (lrt.lrTables != null){
            return "" + l;
        }
        l &= 0x3fffffff;
        int nt = l >> 20;
        int m = l & 0xfffff;
        return String.format("%s_%d",this.tab.gramSymToString(nt),m);
    }


    /**
     * Trace the portion of GSS delimited by the specified start and end indexes
     * using the specified stream.
     *
     * @param      trc stream
     * @param      start start index in the GSS
     * @param      end end index in the GSS
     */

    void traceEGSS(PrintWriter trc, int start, int end){
        traceEGSS(trc,start,end,false);
    }

    /**
     * Trace the portion of GSS delimited by the specified start and end indexes
     * using the specified stream.
     *
     * @param      trc stream
     * @param      start start index in the GSS
     * @param      end end index in the GSS
     * @param      edges <code>true</code> to trace also the edges, <code>false</code>
     *             to trace only the nodes
     */

    void traceEGSS(PrintWriter trc, int start, int end, boolean edges){
        int startedge = 1;
        int endedge = 1;
        int lev = 0;
        if (start > 0){
            // get the end edges of the preceding level, which is the start of the first
            // to trace
            int prevlev = start - 1;
            while (gssNodeDir[(prevlev)>>>NSHF][((prevlev)&MSK)] >= 0) prevlev--;
            endedge = gssNodeDir[(prevlev)>>>NSHF][((prevlev)&MSK)+NODE_EDGES] & 0x7fffffff;
        }
        for (int i = start; i < end; i++){
            if (gssNodeDir[(i)>>>NSHF][((i)&MSK)] < 0){
                int list = 0;
                lev = -gssNodeDir[(i)>>>NSHF][((i)&MSK)];
                list = gssNodeDir[(i)>>>NSHF][((i)&MSK)+NODE_EDGES] & 0x7fffffff;
                trc.printf("i: %d level %d --- %s\n",
                    i,lev,sentinelToString(i));
                i++;
                if (i+1 < end && edges){
                    startedge = endedge;
                    endedge = gssNodeDir[(i)>>>NSHF][((i)&MSK)+NODE_EDGES] & 0x7fffffff;
                    if (i + 1 == this.levelGss){
                        endedge = this.gssEdgeNr;
                    }
                    if (endedge == 0) endedge = this.gssEdgeNr;
                    if (startedge == 0) startedge = 1;
                    // trace all the objects in the edges array, i.e. edges and sppfs
                    for (int j = startedge; j < endedge;){
                        int second = gssEdgeDir[(j+1)>>>NSHF][((j+1)&MSK)];
                        if (second < 0){                    // symbol node
                            traceEsppf(trc,j);
                            j += symNodeLen(j);
                        } else if ((second & HEADF) != 0){  // rule node
                            trc.printf("    rule %s\n",sppfRuleToString(j));
                            int rlen = ruleNodeLen(j);
                            /*
                            for (int k = 0; k < rlen; k++){
                                trc.printf("    rule j: %d %d\n",
                                    j+k,SPPFGSS(j+k));
                            }
                            */
                            j += rlen;
                        } else {                            // edge
                            trc.printf("    edge %s\n",GSSEdgeToString(j));
                            /*
                            for (int k = 0; k < EDGE_FIELDS; k++){
                                trc.printf("    edge j: %d %d\n",j+k,SPPFGSS(j+k));
                            }
                            */
                            j += EDGE_FIELDS;
                        }
                    }
                }
            } else {
                String s = "";
                try {
                    s = GSSNodeToString(i);
                } catch (Throwable t){
                    s = "inconsistent";
                    t.printStackTrace();
                }
                trc.printf("i: %d %s edge %d\n",i,s,gssNodeDir[(i)>>>NSHF][((i)&MSK)+NODE_EDGES] & 0x7fffffff);
                int ed = gssNodeDir[(i)>>>NSHF][((i)&MSK)+NODE_EDGES] & 0x7fffffff;
            }
        }
    }

    /**
     * Trace the specified gss sppf.
     *
     * @param      trc stream
     * @param      j start of sppf
     */

    protected void traceEsppf(PrintWriter trc, int j){
        trc.printf("    sym %s\n",sppfSymToString(j));
        /*
        for (int k = 0; k < 4; k++){
            trc.printf("    sym%s j: %d %d\n",isSymNode ? "*" : "",
                j+k,SPPFGSS(j+k));
        }
        */
    }

    /**
     * Deliver a string representing the specified item as level[state].
     *
     * @param      item item (node)
     * @return     string
     */

    String iToString(int item){
        return String.format("%d[%s]",nodeToLevel(item),GSSlabel(gssNodeDir[(item)>>>NSHF][((item)&MSK)]));
    }

    /**
     * Deliver a string representing the list of edges of the specified item.
     *
     * @param      item item (node)
     * @return     string
     */

    String esToString(int item){
        String str = "";
        for (int e = gssNodeDir[(item)>>>NSHF][((item)&MSK)+NODE_EDGES] & 0x7fffffff; e != 0; e = gssEdgeDir[(e)>>>NSHF][((e)&MSK)] & 0xfffffff){
            if (str.length() > 0) str += ", ";
            str += eToString(item,e);
        }
        return str;
    }

    /**
     * Deliver a string representing the specified edge item as to<--from, with
     * items represented as level[state].
     *
     * @param      from item
     * @param      edge edge
     * @return     string
     */

    String eToString(int from, int edge){
        return String.format("%s<--%s",iToString(gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)]),iToString(from));
    }

    /**
     * Trace the edges of the current level.
     */

    void traceEdgeLevel(){
        traceEdges(this.levelEdgeGss,this.gssEdgeNr,0,this.levelGss,this.gssNodeNr);
    }

    /**
     * Trace all the edges.
     */

    void traceEdges(){
        traceEdges(1,this.gssEdgeNr,0,0,this.gssNodeNr);
    }

    /**
     * Trace the edges between the specified indexes.
     *
     * @param      start start index
     * @param      end end index
     */

    void traceEdges(int start, int end){
        for (int i = start; i < end;){
            int second = gssEdgeDir[(i+1)>>>NSHF][((i+1)&MSK)];
            if (second < 0){                    // symbol node
                traceEdgeSppf(i);
                i += symNodeLen(i);
            } else if ((second & HEADF) != 0){  // rule node
                Trc.out.printf("%d: rule %s\n",
                    i,sppfRuleToString(i));
                i += ruleNodeLen(i);
            } else {
                Trc.out.printf("%d: edge %s\n",
                    i,GSSEdgeToString(i));
                i += EDGE_FIELDS;
            }
        }
    }

    /**
     * Trace the specified sppf.
     *
     * @param      i start of the sppf
     */

    protected void traceEdgeSppf(int i){
        Trc.out.printf("%d: sym %s\n",
            i,sppfSymToString(i));
    }

    /**
     * Trace the edges that lie within the specified indexes.
     *
     * @param      start start index
     * @param      end end index
     * @param      prev last sppf in the list of sppfs
     * @param      nstart index of the first node
     * @param      nend index of the last node
     */

    void traceEdges(int start, int end, int prev, int nstart, int nend){
        Trc.out.printf("edges list %d:%d nodes %d:%d\n",start,end,nstart,nend);
        traceEdges(start,end);
    }

    /**
     * Deliver a string representing the sppf of the specified edge.
     *
     * @param      edge edge
     * @return     string
     */

    String edgeSppfToString(int edge){
        int sppf = gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)];
        String str = null;
        if (sppf == 0){
            str = "";
        } else if (sppf < 0){
            str = getLexeme(getLexNr(sppf));
        } else if ((sppf & HEADF) != 0){  // already built
            str = String.format("*%d",sppf & ~HEADF);
        } else {
            str = String.format("%s",sppfSymToString(sppf-4));
        }
        return String.format("[%d %s]",sppf,str);
    }


    //------------ The tokens --------------

    /** The number that represents the EOF. */
    int EOF;
    /** The current token number. */
    int currentToken;

    /** The number of the last token got. */
    int myToken;

    // whether the parser can save and reuse tokens for another run
    /**
     * Deliver the next token.
     * It can be used only on grammars that have an unambiguous lexes.
     *
     * @return     number of the token
     */

    /* The scheme of the tokenizer is:
     *
     *    int tokenizer(){
     *        int res = super.tokenizer();
     *        if (this.myToken != this.tab.numOfToks){
     *            if (this.sourceTokenList.length() > 0) this.sourceTokenList.append(" ");
     *            this.sourceTokenList.append(this.lex.toString());
     *        }
     *        return res;
     *    }
     */

    @Override
    int tokenizer(){
        if ((USE_RETAINED_TOKENS & this.mode) != 0){
            if (this.saveTokensCur == null){
                this.saveTokensCur = this.saveTokensHead;
            } else {
                this.saveTokensCur = this.saveTokensCur.next;
            }
            int tok = this.tab.numOfToks;
            if (this.saveTokensCur != null) tok = this.saveTokensCur.token;
            this.numOfTokens++;
            return tok;
        }
        ParserTables tab = this.tab;
        if (tab.ignore >= 0){
            this.delim = tab.ignore;
        }
        if (this.delim < 0){
            this.delim = this.tab.symNr('n',"delimiter");
        }

        int res = -1;
        doit: do {
            int set = this.lex.lex();
            if (this.lex.eof()){
                ;
                res = this.tab.numOfToks;
                break doit;
            } else {
                if (set == 0){
                    ;
                    break doit;
                }
                res = this.tab.tokLists[set][0];   // earliest preferred
            }
            ;
        } while (res == this.delim);
        ;
        if ((RETAIN_TOKENS & this.mode) != 0){
            ParserSavedToken save = new ParserSavedToken();
            save.token = res;
            save.pos = this.lex.index();
            if (res != this.tab.numOfToks){    // eof
                save.string = new char[this.lex.stream.cursor - this.lex.stream.markPos];
                System.arraycopy(this.lex.stream.buffer,this.lex.stream.markPos,
                    save.string,0,save.string.length);
            }
            if (this.saveTokensTail == null){
                this.saveTokensHead = save;
            } else {
                this.saveTokensTail.next = save;
            }
            this.saveTokensTail = save;
        }
        this.numOfTokens++;
        //Trc.out.printf("token %s %s %s size %s\n",this.numOfTokens,
        //   this.tab.gramSymToString(res+this.tab.tokBase),this.lex.toString(),stackLength());
        return res;
    }

    /** The head of the list of the saved tokens. */
    ParserSavedToken saveTokensHead;

    /** The tail of the list of the saved tokens. */
    ParserSavedToken saveTokensTail;

    /** The current element in the list of the saved tokens. */
    ParserSavedToken saveTokensCur;

    /** A saved token. */
    class ParserSavedToken {

        /** The reference to the next element. */
        ParserSavedToken next;

        /** The number of the token. */
        int token;

        /** The string of the token. */
        char[] string;

        /** The position of the token. */
        long pos;
    }
    /**
     * Take the current token and save it in the token pool saving its string and/or
     * point as requested by its shift action.
     *
     * @param      act shift action
     * @return     encoding of the token for the parse tree
     */

    static int maxpooled;
    int pooled;
    int saveToken(int act){
        int res = 0;
        boolean lexstore = (act & ParserLRTables.SAVELEX) != 0;
        boolean pointstore = (act & ParserLRTables.SAVEPOS) != 0;
        ;
        if ((USE_RETAINED_TOKENS & this.mode) != 0){
            tl: {
                int lexNr = 0;
                if (lexstore){
                    if (this.pool == null){
                        this.pool = new ParserPool();  // allocate string pool
                    }
                    lexNr = this.pool.addUnique(this.saveTokensCur.string,
                        0,this.saveTokensCur.string.length);
                    this.pooled++;
                    ;
                }
                int tokNr = this.saveTokensCur.token;
                long point = this.saveTokensCur.pos;
                if (!pointstore){                         // do not store point
                    long tk = lexNr * this.tab.numOfToks + tokNr + 1;
                    if ((tk & 0xe0000000) == 0){          // packing possible
                        res = (int)tk | TOK_ELEM;
                        break tl;
                    }
                    point = -1L;
                }
                if (!lexstore) lexNr = -1;
                int lastTok = addToken(lexNr,tokNr,point);
                res = lastTok | TOK_ELEM;
            } // tl
            ;
            ;
            return res;
        }
        tl: {
            BufReader stream = this.lex.stream;
            int lexNr = 0;
            if (lexstore){
                if (this.pool == null){
                    this.pool = new ParserPool();  // allocate string pool
                }
                lexNr = this.pool.addUnique(stream.buffer,
                    stream.markPos,
                    stream.cursor - stream.markPos);
                this.pooled++;
                ;
            }
            int tokNr = this.currentToken;
            long point = stream.index - stream.end + stream.markPos;
            if (!pointstore){                         // do not store point
                long tk = lexNr * this.tab.numOfToks + tokNr + 1;
                if ((tk & 0xe0000000) == 0){          // packing possible
                    res = (int)tk | TOK_ELEM;
                    break tl;
                }
                point = -1L;
            }
            if (!lexstore) lexNr = -1;
            int lastTok = addToken(lexNr,tokNr,point);
            res = lastTok | TOK_ELEM;
        } // tl
        ;
        ;
        return res;
    }
    //------------ The reductions --------------

    /**
     * Deliver a string representing the specified reductions.
     *
     * @param      actstart start of the array of actions
     * @param      actlen length of the array of actions
     * @return     string
     */

    String redsToString(int actstart, int actlen){
        StringBuilder s = new StringBuilder();
        for (int j = 0; j < actlen; j++){
            ParserLRTables lrt = (ParserLRTables)this.tab.pilot;
            ParserLRTables.LR0FAtables fa = (ParserLRTables.LR0FAtables)lrt.lrTables;
            int act = fa.LRtable[actstart+j];
            if (act < ParserLRTables.ISREDUCE) continue; // not a reduction
            if (j > 0) s.append(" ");
            s.append(fa.comprReduToString(act));
        }
        return s.toString();
    }

    /** The index of the current reduction in the rwl. */
    int currentRed;

    /** The reduction worklist (rwl). */
    int[] reduceWl;

    /** The insertion index in the rwl. */
    int reduceWli;

    /** The extraction index in the rwl. */
    int reduceWldp;

    /** The number of entries of each element in the rwl. */
    static final int RWLSIZE = 4;

    /** The absolute index in the rwl. */
    int absReduceWli = 1;
    /**
     * Add an element in the rwl representing all the reductions in the specified action.
     *
     * @param      node node from which the reduction has to be done
     * @param      actstart start index of the action array
     * @param      actlen length of the action array
     * @param      start edge down which the reduction path starts
     */

    void addAllReductions(int node, int actstart, int actlen, int start){
        if (this.reduceWli >= this.reduceWl.length){
            if (this.reduceWldp > this.reduceWl.length/QUEUE_THRES_1){  // shift down, if worth
                System.arraycopy(this.reduceWl,this.reduceWldp,this.reduceWl,
                    0,this.reduceWli-reduceWldp);
                this.reduceWli -= this.reduceWldp;
                this.reduceWldp = 0;
            } else {                        // enlarge
                this.reduceWl = Arrays.copyOf(this.reduceWl,
                    this.reduceWl.length+this.reduceWl.length/QUEUE_THRES_2);
            }
        }
        this.reduceWl[this.reduceWli++] = node;
        this.reduceWl[this.reduceWli++] = actstart;
        this.reduceWl[this.reduceWli++] = actlen;
        this.reduceWl[this.reduceWli++] = start;
        ;
        ;
    }

    /**
     * Deliver a string representing the entry in the rwl at the specified index.
     *
     * @param      r inded
     * @return     string
     */

    String redAllToString(int r){
        int v = this.reduceWl[r++];
        int actstart = this.reduceWl[r++];
        int actlen = this.reduceWl[r++];
        int start = this.reduceWl[r];
        return String.format("%d(%s),%d,%s",
            v,redsToString(actstart,actlen),start,
            start != 0 ? edgeToString(Math.abs(start),0) : "");
    }
    /** The array of reusable paths for reductions. */
    // path reuse can only be done keeping a stack because of recursion
    int[][] reusablePaths;

    /** The length of the significant part in the reusable paths array. */
    int reusablePathsLength;

    /** The reusable path iterator. */
    int[] pathIterator;

    /** The reusable path. */
    int[] reusablePath;

    /**
     * Deliver a string representing the specified path.
     *
     * @param      path path
     * @return     string
     */

    String pathToString(int[] path){
        StringBuilder str = new StringBuilder();
        if (path == null){
            str.append("no path");
        } else {
            int length = path[0];
            int tonode = path[length+1];
            int node = path[length+2];
            int rule = path[length+3];
            str.append(String.format("from %d rule %d len: %d to %d: %d",
                node,rule,length,tonode,node));
            for (int i = 1; i < length+1; i++){
                str.append("-");
                str.append(gssEdgeDir[(path[i]+EDGE_TO)>>>NSHF][((path[i]+EDGE_TO)&MSK)]);
            }
            str.append(String.format("(%d",gssNodeDir[(node)>>>NSHF][((node)&MSK)]));
            for (int i = 1; i < length+1; i++){
                str.append("-");
                str.append(gssNodeDir[(gssEdgeDir[(path[i]+EDGE_TO)>>>NSHF][((path[i]+EDGE_TO)&MSK)])>>>NSHF][((gssEdgeDir[(path[i]+EDGE_TO)>>>NSHF][((path[i]+EDGE_TO)&MSK)])&MSK)]);
            }
            str.append("), ");
            str.append(ruleToString(rule));
        }
        return str.toString();
    }

    /**
     * Trace the specified path.
     *
     * @param      path path
     */

    void tracePath(int[] path){
        if (path == null){
            Trc.out.printf("no path");
        } else {
            int length = path[0];
            int tonode = path[length+1];
            int from = path[length+2];
            int rule = path[length+3];
            Trc.out.printf("from %d rule %s len: %d to %d\n",
                from,ruleToString(rule),length,tonode);
            for (int i = 1; i < length+1; i++){
                Trc.out.printf("  %s\n",edgeToString(path[i],0));
            }
        }
    }

    //------------ The common data of the algorithms  --------------

    /** The array to hold the shifts. */
    int[] potter;

    /** The number of times the lr static mode is executed. */
    static int lrsmode;

    /** The number of times the lr static mode loop is executed. */
    static int lrsmode1;

    /** The number of times the lr dynamic mode is executed. */
    static int lrdmode;

    /** The number of times the nondeterministic (general)  mode is executed. */
    static int ndetmode;

    /** The number of times the main loop is executed. */
    static int mloopnr;

    /** The current parsing mode, 0: general, 1: lr static, 2: lr dynamic. */
    int pmode;

    /** The tokens parsed for each parsing mode. */
    static int[] modetoks = new int[3];   // ndet, lr static, lr dynamic

    /** The reductions done for each parsing mode. */
    static int[] modereds = new int[3];

    /** The size of the edges produced. */
    static int edgesize;

    /** The size of the GSS sppfs produced. */
    static int sppfsize;

    //------------ The encoding of the forest  --------------

    /* Forest formats
     *
     * There are a number of formats, that do not depend on the parser, but on the kind
     * of derivations, e.g. flat vs structured.
     *
     * The format in the final forest is:
     *
     *   +0  0:       normal, structured
     *       1:       dirty or binarized
     *       2:       flat
     *
     *   symbol node (present only when ambiguous):
     *
     *   +0  head:    HEADSYM | number of alternatives
     *   +1           index of first alternative
     *   +.           .....
     *   +n           index of last alternative
     *
     *   rule node:
     *
     *   flat
     *   +0  head:    HEAD | ELR_TREE | nt(b9-b0) | len(b28-b10)
     *   +1           elements
     *
     *   structured:
     *   +0  head:    HEAD | < numOfRules: rule number, >= ntNrGroups: non-repetition group
     *                       else rep. group: der.length + numOfRules
     *   +1           elements
     *   +n  backlink myEarley only, group: index of the symbol after the group, not present
     *                if not group, and used by its access methods
     *
     *   elements:
     *
     *   < 0          token
     *   tree         index of a sppf node
     *
     *   HEADF: b30-b31
     *   HEAD:  b30
     *   HEADSYM: b31
     *   ELR_TREE: b29
     *   ELR_TREE_NT:  b9-b0
     *   ELR_TREE_LEN: b28-b10
     *
     * The headers flags are needed only to allow to have unique trace methods that
     * work easily on all kinds of forests, and to allow trace made by scanning
     * forests sequentially, and to spot easily errors.
     * There are a number of other formats, that are needed by some parsers only,
     * like, e.g. the dirty one, which are described in the appropriate files.
     */

    /** The mask of the field that holds the nonterminal in rule headers. */
    static final int ELR_TREE_NT = 0x3ff;

    /** The number of shifts to get the length from rule headers. */
    static final int ELR_TREE_SHF = 10;

    /** The mask of the field that holds the length of derivation in rule headers. */
    static final int ELR_TREE_LEN = 0x1ffffc00;

    /** The flag that marks flat derivations in rule headers. */
    static final int ELR_TREE = 0x20000000;

    /** The index of etrees of nullable nonterminal derivations. */
    int[] etrees;

    /** The reusable array to hold the indexes of rules of symbol nodes. */
    int[] ruleptrs;

    /** The initial size of the encode queue. */
    // this is almost never enlarged, even with recursive rules
    static final int QUEUE_INITIAL = 1024;

    /** The first threshold to enlarge the encode queue. */
    static final int QUEUE_THRES_1 = 8;

    /** The second threshold to enlarge the encode queue. */
    static final int QUEUE_THRES_2 = 1;

    /** The encode queue. */
    int[] encodequeue = new int[QUEUE_INITIAL];
    /** The reusable stack for encoding the forest. */
    int[] encodetreestack;

    /** The index in the GSS of the bottom of the LR stack. */
    int LRstackBottom;

    /** The index in the tree of the part last encoded by LR encoding. */
    int LRtree;

    /**
     * Push an element on the LR stack with the specified data.
     *
     * @param      state state
     * @param      tree sppf
     */

    void pushLRstack(int state, int tree){
        ;
        if (this.gssEdgeNr+3 > this.gssEdgeLength){
            enlargeEdges(this.gssEdgeNr+3);
            ;
            /*
            TRACE(M,"pushLRstack enlarged %d blocks: %s\n",
                this.gssEdgeNr,gssBlocksToString());
            */
        }
        gssEdgeDir[(this.gssEdgeNr)>>>NSHF][((this.gssEdgeNr)&MSK)] = state;
        this.gssEdgeNr++;
        gssEdgeDir[(this.gssEdgeNr)>>>NSHF][((this.gssEdgeNr)&MSK)] = this.level;   // to share etrees
        this.gssEdgeNr++;
        gssEdgeDir[(this.gssEdgeNr)>>>NSHF][((this.gssEdgeNr)&MSK)] = tree;
        this.gssEdgeNr++;
        this.lrItems++;
    }

    /**
     * Trace the LR stack;
     *
     * @param      stackBottom index of the bottom of the stack
     */

    void traceLRstack(int stackBottom){
        Trc.out.printf("stack");
        for (int i = stackBottom; i < this.gssEdgeNr; i += 3){
            Trc.out.printf(" %d:(%d,%d",i,gssEdgeDir[(i)>>>NSHF][((i)&MSK)],gssEdgeDir[(i+1)>>>NSHF][((i+1)&MSK)]);
            int t = gssEdgeDir[(i+2)>>>NSHF][((i+2)&MSK)];
            String s = "EOF";
            if (t < 0){
                s = getLexeme(getLexNr(t));
            } else if (t > 0){
                if (isAlt(t)){
                    s = getLitName(this.tree[(t+1)>>>NSHF][((t+1)&MSK)]);
                } else {
                    s = getLitName(t) + t;
                }
            }
            Trc.out.printf(",%s)",s);
        }
        Trc.out.printf("\n");
    }


    /** The value of the derivation fields which denotes header. */
    static final int HEADTREE = 0x40000000;

    /* Whether the new structure of groups is used in the forest. */
    // in the stack, states and the nts of their derivations are packed
    static final int LRS_STATE_MASK = 0xfffff;
    static final int LRS_NT_SHIFT = 20;
    /**
     * Trace the forest as row data.
     */

    public void traceForestRaw(){
        Trc.out.printf("start %d length %d\n",this.treeStart,this.treeLen);
        for (int i = 1; i < this.loc; i++){
            Trc.out.printf("%d: %d\n",i,this.tree[(i)>>>NSHF][((i)&MSK)]);
        }
    }

    /**
     * Trace the forest from the beginning to the specified index;
     *
     * @param      len end index
     */

    @Override
    protected void traceTree(int len){
        traceTree(1,len);
    }

    /**
     * Trace the fores between the specified indexes.
     *
     * @param      start start index
     * @param      end end index
     */

    void traceTree(int start, int end){
        Trc.out.printf("traceTree encoded tree: %d:%d\n",start,end);
        ParserTables savetab = this.tab;
        if (this.tab.originTables != null){
            this.tab = this.tab.originTables;
        }
        int derstart = start;
        for (int i = start; i < end; i++){
            int el = this.tree[(i)>>>NSHF][((i)&MSK)];
            Trc.out.printf("%d: %d",i,el);
            if (i == derstart){
                if ((el & HEADF) == HEAD){
                    el &= ~HEAD;
                    Trc.out.printf(" %d %d %b %b",el,getLength(i),
                        isGroup(i),isRepGroup(i));
                    if (!isRepGroup(i)){
                        Trc.out.printf(" %s",tab.ntLitName(tab.ruleToNt[el]));
                    }
                    derstart = i + getLength(i) + 1;
                    // Trc.out.printf("-1- derstart %d i: %d len %d nr %d len %d",
                    //     derstart,i,getLength(i),this.tab.numOfRules,(int)this.tab.ruleLen[el]);
                } else if ((el & HEADF) == HEADSYM){
                    Trc.out.printf(" sym");
                    int nrrules = el & ~HEADSYM;
                    derstart = i + 1 + nrrules;  // for the array of rules
                    //Trc.out.printf("-2- derstart %d",derstart);
                }
            } else if (el == -1){
                Trc.out.printf(" !!");
            } else if (el < 0){
                int ln;
                Str st = new Str();              // trace lexeme
                String str;
                ln = getLexNr(el);
                str = getLexeme(ln);
                Str.strLit(str.toCharArray(),0,
                    str.length(),st);
                Trc.out.printf(" %s",st);
            }
            Trc.out.printf("\n");
        }
        this.tab = savetab;
        Trc.out.printf("traceTree end\n");
    }


    /**
     * Trace the forest using the specified stream and with the specified mode.
     *
     * @param      trc stream
     * @param      mode of tracing
     */

    @Override
    void traceTree(PrintWriter trc, int mode){
        traceTree(trc,mode,1);
    }

    /**
     * Trace the forest using the specified stream and with the specified mode starting
     * at the specified index.
     *
     * @param      trc stream
     * @param      der start index
     * @param      mode of tracing
     */

    void traceTree(PrintWriter trc, int mode, int der){
        ParserTables savetab = this.tab;
        if (this.tab.originTables != null){
            this.tab = this.tab.originTables;
        }
        if (this.treeLen <= 1) return;      // no tree
        int len = this.treeLen;
        int[] ntCounts = null;
        if (mode == 1 || mode == 2){
            ntCounts = new int[this.tab.numOfSyms+1+len];
            // not correct if sym node
            // ntCounts[getSymNr(this.treeStart)]++;
            // the problem is that we now have forward and backward references, so we
            // cannot update the ntCounts along tracing: we must build it upfront

            int symseq = 0;
            for (int i = der; i < len;){        // scan the tree
                int h = this.tree[(i)>>>NSHF][((i)&MSK)];
                if ((h & HEADF) == HEADSYM){        // symbol node
                    ntCounts[this.tab.numOfSyms+1+i] = symseq++;      // enumerate symbol nodes
                    int nrrules = h & ~HEADSYM;
                    i += nrrules + 1;
                    /*
                    for (int j = i; j != 0; j = TREE(j) & ~HEADSYM){
                        int d = j + 1;
                        int ref = this.tab.numOfSyms;    // use last for all groups
                        if (!isGroup(d) && mode == 1){
                            ref = getSymNr(d);
                        }
                        ntCounts[this.tab.numOfSyms+1+d] = ntCounts[ref]++;
                        i = j + getLength(j+1) + 2;
                    }
                    */
                } else {
                    int t = 0;
                    try {
                        t = getLength(i);                // length of phrase of derivation
                    } catch (IllegalArgumentException exc){
                        Trc.out.printf("!! i %d tree %d\n",i,this.tree[(i)>>>NSHF][((i)&MSK)]);
                        throw exc;
                    }
                    int d = i;
                    int ref = this.tab.numOfSyms;    // use last for all groups
                    if (!isGroup(d) && mode == 1){
                        ref = getSymNr(d);
                    }
                    ntCounts[this.tab.numOfSyms+1+d] = ntCounts[ref]++;
                    i += t + 1;                 // step to next derivation
                }
            }
        }

        for (int i = der; i < len;){            // scan the tree
            int h = this.tree[(i)>>>NSHF][((i)&MSK)];
            // if ((FL_V & this.trc) != 0){
            //     Trc.out.printf("traceTree %d: %h %d\n",i,h,h & ~HEADF);
            // }
            if ((h & HEADF) == HEADSYM){        // symbol node
                traceDer(i,trc,mode,ntCounts);  // trace it
                /*
                for (int j = i; j != 0; j = TREE(j) & ~HEADSYM){
                    if ((FL_V & this.trc) != 0){
                        Trc.out.printf("traceTree rule %d\n",j);
                    }
                    traceDer(j+1,trc,mode,ntCounts);  // trace it
                    i = j + getLength(j+1) + 2;
                    if ((FL_V & this.trc) != 0){
                        Trc.out.printf("traceTree next %d\n",i);
                    }
                }
                */
                i += (h & ~HEADSYM) + 1;
            } else {
                int t = getLength(i);           // length of phrase of derivation
                traceDer(i,trc,mode,ntCounts);  // trace it
                i += t + 1;                     // step to next derivation
            }
        }
        this.tab = savetab;
    }

    /**
     * Trace the specified derivation using the specified stream and with the specified
     * mode.
     * This is the same as the ParserEngine one, but does not change the ntCounts.
     *
     * @param      der start index
     * @param      trc stream
     * @param      mode of tracing
     * @param      ntCounts array of counters of nonterminals
     */

    @Override
    protected void traceDer(int der, PrintWriter trc, int mode, int[] ntCounts){
        trc.printf("%s\n",derToString(der,mode,ntCounts));
    }

    /** Whether the alternatives must be shown. */
    boolean showAlt;

    /**
     * Deliver a string representing the specified derivation.
     *
     * @param      der start index
     * @return     string
     */

    String derToString(int der){
        return derToString(der,0,null);
    }

    /**
     * Deliver a string representing the specified derivation with the specified
     * mode and array of nonterminal counters.
     *
     * @param      der start index
     * @param      mode mode of tracing
     * @param      ntCounts array of counters of nonterminals
     * @return     string
     */

    String derToString(int der, int mode, int[] ntCounts){
        ParserTables savetab = this.tab;
        if (this.tab.originTables != null){
            this.tab = this.tab.originTables;
        }
        String strd = "";
        if (isAlt(der)){                    // symbol node
            if (mode == 0 || mode == 2){
                strd += String.format("%d: ~%s~:",der,getLitName(this.tree[(der+1)>>>NSHF][((der+1)&MSK)]));
            } else if (mode == 3){
                strd += String.format("%d: ~%s~%s:",der,
                    getLitName(this.tree[(der+1)>>>NSHF][((der+1)&MSK)]),derKindToString(der));
            } else if (mode == 4){
                String nthtml = Str.toHtml(getLitName(this.tree[(der+1)>>>NSHF][((der+1)&MSK)]));
                strd += String.format("%d: ~<a name=%s>%s</a>~:",der,nthtml,nthtml);
            } else {
                strd += String.format("%s",getDerLit(der,ntCounts));
            }
            String sep = " ";
            int nrrules = this.tree[(der)>>>NSHF][((der)&MSK)] & ~HEADSYM;
            for (int j = 0; j < nrrules; j++){
                int elem = this.tree[(der+j+1)>>>NSHF][((der+j+1)&MSK)];
                if (mode == 0 || mode == 2 || mode == 4){
                    strd += String.format("%s%d",sep,elem);
                } else if (mode == 3){
                    strd += String.format("%s%d%s",sep,elem,derKindToString(elem));
                } else {
                    strd += String.format("%s%s",sep,getDerLit(elem,ntCounts));
                }
                sep = ", ";
            }
            /*
            for (int j = der; j != 0; j = TREE(j) & ~HEADSYM){
                if (mode == 0 || mode == 2){
                    strd += String.format("%s~%d~",sep,j+1);
                } else {
                    strd += String.format("%s%s",sep,getDerLit(j+1,ntCounts));
                }
                sep = ", ";
            }
            */
        } else {
            try {
                checkDer(der);                          // check index
            } catch (Throwable exc){
                Trc.out.printf("!!! index in tree: %d: %d len %d head: %b\n",
                    der,this.tree[(der)>>>NSHF][((der)&MSK)],this.treeLen,(this.tree[(der)>>>NSHF][((der)&MSK)] & HEADF) == HEAD);
                exc.printStackTrace();
                System.exit(1);
                return strd;
            }
            if (mode == 0 || mode == 2 || mode == 4){
                if (this.showAlt){                      // show the alternative nr
                    // test if the nt has several rules
                    String altStr = "";
                    if (!isRepGroup(der) && !isAlt(der)){
                        int rn = getRuleNr(der);
                        int lhs = this.tab.ruleToNt[rn];
                        int firstrule = this.tab.ntToRule[lhs];
                        if (firstrule < this.tab.ruleToNt.length-1){
                            if (this.tab.ruleToNt[firstrule+1] == lhs){  // it has several rules
                                altStr = "|" + (rn-firstrule);
                            }
                        }
                    }
                    if (mode == 4){
                        strd += String.format("<a name=%d>%d</a>: %s%s ::=",   // derivation number and name
                            der,der,Str.toHtml(getLitName(der)),altStr);       // .. of nonterminal
                    } else {
                        strd += String.format("%d: %s%s ::=",   // derivation number and name
                            der,getLitName(der),altStr);        // .. of nonterminal
                    }
                } else {
                    if (mode == 4){
                        strd += String.format("<a name=%d>%d</a>: %s ::=",     // derivation number and name
                            der,der,Str.toHtml(getLitName(der)));              // .. of nonterminal
                    } else {
                        strd += String.format("%d: %s ::=",     // derivation number and name
                            der,getLitName(der));               // .. of nonterminal
                    }
                }
                // der + ": " +              
                //    getLitName(der) + " ::=");
            } else if (mode == 3){
                strd += String.format("%d: %s%s ::=",           // derivation number and name
                    der,getLitName(der),derKindToString(der));  // .. of nonterminal
            } else {
                if (isRepGroup(der)){
                    strd += "{}*";
                } else if (isGroup(der)){
                    strd += "{}";
                } else if (mode == 1){
                    strd += getLitName(der);
                }
                strd += ntCounts[this.tab.numOfSyms+1+der];
                strd += String.format("%s ::=",getDerLit(der,ntCounts));
            }
            int t = getLength(der);                 // length of phrase of derivation
            Str st = new Str();
            // strd += "("+(der+1)+":"+(der+1+t)+")";
            for (int i = der+1; i < der+1+t; i++){  // scan the derivation
                strd += " ";
                int s = this.tree[(i)>>>NSHF][((i)&MSK)];                    // take symbol
                if (s == -1){                       // invalid
                    strd += "!!-";
                } else if (s < 0){                  // token
                    int ln;
                    String str;
                    ln = getLexNr(s);
                    st.length = 0;                  // trace lexeme
                    str = getLexeme(ln);
                    Str.strLit(str.toCharArray(),0,
                        str.length(),st);
                    if (mode <= 1 || mode == 3){
                        long pt = getPoint(s);
                        String pts = (pt < 0) ? "" : Long.toString(pt);
                        strd += st.toString() + pts;
                    }
                    if (mode == 2){
                        strd += st.toString() + "," + getPoint(s);
                    }
                    if (mode == 4){
                        strd += Str.toHtml(st.toString());
                    }
                } else {                            // another derivation
                    if (mode == 0 || mode == 2 || mode == 3 || mode == 4){
                        try {
                            if (isAlt(s)){
                                if (mode == 4){
                                    strd += String.format("~<a href=#%s>%s>/a>~",s,s);    // its derivation index
                                } else {
                                    strd += String.format("~%s~",s);    // its derivation index
                                }
                            } else {
                                checkDer(s);                        // check index
                                if (mode == 4){
                                    strd += String.format("\u00ab<a href=#%d>%d</a>\u00bb",s,s);  // <<  >>
                                } else {
                                    strd += String.format("\u00ab%d\u00bb",s);  // <<  >>
                                }
                            }
                        } catch (Throwable exc){
                            Trc.out.printf("!!! index: %d tree %d treelen %d head: %b exc %s strd %s\n",
                                i,this.tree[(i)>>>NSHF][((i)&MSK)],this.treeLen,(this.tree[(i)>>>NSHF][((i)&MSK)] & HEADF) == HEAD,exc,strd);
                            exc.printStackTrace();
                            System.exit(1);
                        }
                        if (mode == 3){
                            strd += derKindToString(s);
                        }
                    } else {
                        if (isAlt(s)){
                            strd += getDerLit(s,ntCounts);
                        } else {
                            try {
                                checkDer(s);                        // check index
                            } catch (Throwable exc){
                                Trc.out.printf("!!! index: %d tree  %d treelen %d head: %b exc %s\n",
                                    i,this.tree[(i)>>>NSHF][((i)&MSK)],this.treeLen,(this.tree[(i)>>>NSHF][((i)&MSK)] & HEADF) == HEAD,exc);
                                exc.printStackTrace();
                                return strd;
                            }
                            if (isGroup(s)){
                                if (isRepGroup(s)){
                                    strd += "{}*";
                                } else {
                                    strd += "{}";
                                }
                            } else {
                                strd += getLitName(s);
                            }
                            strd += ntCounts[this.tab.numOfSyms+1+s];
                            strd += getDerLit(s,ntCounts);
                        }
                    }
                }
            }
        }
        //trc.printf(" [%s]",forestToStringAbbr(der));
        //strd += "  #" + forestToStringAbbr(der);
        this.tab = savetab;
        return strd;
    }

    protected String forestToString(int root, boolean paren){
        TreeSet<Integer> visited = new TreeSet<Integer>();
        StringBuilder str = new StringBuilder();
        forestToString(root,visited,paren,0,str);
        return str.toString();
    }
    protected String forestToStringAbbr(int root){
        TreeSet<Integer> visited = new TreeSet<Integer>();
        StringBuilder str = new StringBuilder();
        forestToString(root,visited,false,50,str);
        return str.toString();
    }

    /**
     * Add a string representing the specified derivation with the specified
     * mode and array of nonterminal counters to the specified string builder
     *
     * @param      root index of the root of the forest
     * @param      visited visited flags
     * @param      paren <code>true</code> to add parentheses, <code>false</code> otherwise
     * @param      str string builder
     */

    /* I think that the yield of a forest should be the list of leaves reacheable from
     * the root, following all (or just one) alternative.
     * The forest is visited in preorder, and the string built along the way. When a symbol node
     * is encountered, the first alternative that does not refer to an already visited symbol or
     * derivation is taken.
     * If no alternative is good, then decree unsuccess, the piece of string done is removed, and
     * the building restarted.
     * I am not sure that this occurs at the moment, but I am handling it in case it could or
     * it will in the future.
     * When a derivation is encountered that refers to an already visited symbol node or derivation,
     * unsuccess is decreed as before.
     * Removes the marks when unwinding so as to allow another alternative to succeed.
     */

    protected boolean forestToString(int root, TreeSet<Integer> visited, boolean paren,
        int maxlen, StringBuilder str){
        boolean res = true;
        int length = str.length();
        //Trc.out.printf("visit %d\n",root);
        visited.add(root);
        doit: if (isAlt(root)){                    // symbol node
            int nrrules = this.tree[(root)>>>NSHF][((root)&MSK)] & ~HEADSYM;
            for (int j = 0; j < nrrules; j++){
                int node = root+j+1;
                if (visited.contains(this.tree[(node)>>>NSHF][((node)&MSK)])) continue;
                //if (paren) str.append(String.format("~{\n"));
                boolean b = forestToString(this.tree[(node)>>>NSHF][((node)&MSK)],visited,paren,maxlen,str);
                //if (paren) str.append(String.format("}~\n"));
                if (b) break doit;
            }
            res = false;
        } else {
            if (paren) str.append(String.format("%s ::= {\n",getLitName(root)));
            int t = getLength(root);                  // length of phrase of derivation
            for (int i = root+1; i < root+1+t; i++){  // scan the derivation
                int s = this.tree[(i)>>>NSHF][((i)&MSK)];                      // take symbol
                if (s < 0){                           // token
                    String tok = null;
                    tok = getLexeme(getLexNr(s));
                    if (maxlen == 0){                 // no limit
                        if (str.length() > 0) str.append(" ");
                        str.append(tok);
                    } else {
                        if (str.length() + tok.length() + 1 <= maxlen){
                            if (str.length() > 0) str.append(" ");
                            str.append(tok);
                        } else {
                            if (str.length() > 0) str.append(" ");
                            str.append(tok);
                            int len = str.length();
                            int todelete = len - maxlen + 3;
                            str.replace((len - todelete)/2,(len+todelete)/2,"...");
                        }
                    }
                } else {
                    if (visited.contains(s)){
                        res = false;
                        break doit;
                    }
                    if (!forestToString(s,visited,paren,maxlen,str)){
                        res = false;
                        break doit;
                    }
                }
            }
            if (paren) str.append(String.format("}\n"));
        }
        visited.remove(root);
        if (!res) str.setLength(length);
        //Trc.out.printf("return %d res %b\n",root,res);
        return res;
    }

    /**
     * Deliver a string representing the specified kind of nonterminal.
     *
     * @param      kind kind
     * @return     string
     */

    String kindToString(int kind){
        switch(kind){
        case ParserTables.REP : return "REP";
        case ParserTables.RES : return "RES";
        case ParserTables.REL : return "REL";
        case ParserTables.RER : return "RER";
        case ParserTables.REU : return "REU";
        case ParserTables.REF : return "REF";
        case 0 : return "0";
        case ParserTables.GRO : return "GRO";
        case ParserTables.OPT : return "OPT";
        case ParserTables.BOD : return "BOD";
        case ParserTables.OBO : return "OBO";
        case ParserTables.BOR : return "BOR";
        case ParserTables.BOO : return "BOO";
        }
        return null;
    }

    /**
     * Deliver a string representing the kind of the specified derivation.
     *
     * @param      der derivation
     * @return     string
     */

    String derKindToString(int der){
        int hdr = 0;
        if (isAlt(der)){
            int first = this.tree[(der+1)>>>NSHF][((der+1)&MSK)];
            hdr = checkDer(first);
        } else {
            hdr = checkDer(der);
        }
        int nt = tab.ruleToNt[hdr];
        int kind = tab.ntKind[nt];
        if (kind != 0){
            return "." + kindToString(kind);
        }
        return "";
    }

    /**
     * Deliver a string representing the kind of the specified derivation.
     *
     * @param      der derivation
     * @param      ntCounts array of counters of nonterminals
     * @return     string
     */

    String getDerLit(int der, int[] ntCounts){
        String res = "";
        if (isAlt(der)){
            res = "~" + getLitName(this.tree[(der+1)>>>NSHF][((der+1)&MSK)]) + "~";
        } else if (isRepGroup(der)){
            res = "{}*";
        } else if (isGroup(der)){
            res = "{}";
        } else {
            res = getLitName(der);
        }
        res += ntCounts[tab.numOfSyms+1+der];
        return res;
    }

    /**
     * Deliver a string representing the kind of the specified derivation.
     *
     * @param      der derivation
     * @return     string
     */

    String getDerLit(int der){
        String res = "";
        if (isAlt(der)){
            res = "~" + getLitName(this.tree[(der+1)>>>NSHF][((der+1)&MSK)]) + "~";
        } else if (isRepGroup(der)){
            res = "{}*";
        } else if (isGroup(der)){
            res = "{}";
        } else {
            res = getLitName(der);
        }
        return res;
    }

    /**
     * Deliver a length of the specified derivation.
     *
     * @param      der derivation
     * @return     length
     */

    public int getLength(int der){
        int h = checkDer(der);                 // check index
        if ((h & ELR_TREE) != 0){              // flat
            h &= ELR_TREE_LEN;
            h >>= ELR_TREE_SHF;
        } else if (h < this.tab.numOfRules){   // not a repetition group
            h = this.tab.ruleLen[h];           // fixed length
        } else {                               // repetition group
            h -= this.tab.numOfRules;          // decode the length
        }
        return h;
    }

    /**
     * Deliver the number of the symbol of the specified element.
     *
     * @param      ele element
     * @return     number
     */

    public int getSymNr(int ele){
        ParserTables tab = this.tab;
        if (ele < 0){                              // token
            int tn;
            tn = getTokNr(ele);
            return tn;                             // return it
        } else {
            int hdr = this.tree[(ele)>>>NSHF][((ele)&MSK)];
            if ((hdr & HEADF) == HEADSYM){         // symbol node
                ele++;
                ele = this.tree[(ele)>>>NSHF][((ele)&MSK)];                   // index of first derivation
            }
            int h = checkDer(ele);                 // check index
            int nrNt = 0;                          // number of nonterminal
            if ((h & ELR_TREE) != 0){              // flat
                h &= ELR_TREE_NT;
                nrNt = h;                          // number of nonterminal
            } else if ((h >= this.tab.numOfRules) ||            // repetition group
                (this.tab.ruleToNt[h] >= this.tab.ntNrGroups)){ // non-repetition group
                return -1;
            } else {
                nrNt = tab.ruleToNt[h];            // number of nonterminal
            }
            return nrNt + tab.numOfToks;           // return symbol number
        }
    }

    /**
     * Deliver a string representing the nonterminal of the specified derivation.
     *
     * @param      der derivation
     * @return     string
     */

    // redefined here to support flat derivations
    String getLitName(int der){
        int h = checkDer(der);                 // check index
        String name;
        ParserTables tab = this.tab;
        if ((h & ELR_TREE) != 0){              // flat
            int ntNr = h & ELR_TREE_NT;        // number of nonterminal of rule
            return tab.ntLitName(ntNr);
        } else if (h >= tab.numOfRules){       // repetition group
            return "\u00ab&*\u00bb";
        } else {
            int ntNr = tab.ruleToNt[h];        // number of nonterminal of rule
            if (ntNr >= tab.ntNrGroups){
                return "\u00ab&\u00bb";
            }
            return tab.ntLitName(ntNr);
        }
    }

    /**
     * Deliver the length of the specified sppf gss symbol node.
     *
     * @param      r index of the node
     * @return     string
     */

    protected int symNodeLen(int r){
        return 4;
    }

    /**
     * Deliver the length of the specified sppf gss rule node.
     *
     * @param      r index of the node
     * @return     string
     */

    // length of derivation: stored in two bits as length + 1. When the two bits are
    // 0, the length is that of the rule (to support rule nodes that are full, not
    // just the binary ones)

    /** Mask of the length. */
    static int HEADDERLEN = 0x3;

    /** Number of shifts to get the length. */
    static int HEADDERSHF = 28;

    // update then traceder if used on the sppf
    protected int ruleNodeLen(int r){
        int len = gssEdgeDir[(r+1)>>>NSHF][((r+1)&MSK)] & ~HEADF;
        int l = (len >> HEADDERSHF) & HEADDERLEN;
        if (l > 0){
            return l + 1;
        }
        len &= 0xfffffff;
        // if (len < this.tab.numOfRules){        // not a repetition group
            len = this.tab.ruleLen[len];       // fixed length
        // } else {                               // repetition group
        //     len -= this.tab.numOfRules;        // decode the length
        // }
        return len + 2;
    }

    /**
     * Generate the forest from the GSS sppfs at the specified index.
     *
     * @param      root index of the sppf.
     * @return     index in the forest
     */

    /* encodetree visites the sppfs (a graph, mostly a dag) creating the nodes in the final
     * forest along with the visit while remembering the positions, and resolving references
     * in the second pass done on the final forest.
     * The algorithm with the queue is not slower than the one with the two passes.
     */

    protected int encodetree(int root){
        ;
        if (this.ruleptrs == null){
            this.ruleptrs = new int[20];
        }
        // int visited = 1 << 28;
        this.treeLen = this.loc;
        if ((root & HEADF) == HEAD){         // already done
            ;
            this.treeStart = root & ~HEADF;
            return root & ~HEADF;
        }
        // here we know that the rule derives the empty string because the cover is 0
        if (gssEdgeDir[(root-3)>>>NSHF][((root-3)&MSK)] == HEADSYM){        // empty rule
            int lhs = gssEdgeDir[(root-1)>>>NSHF][((root-1)&MSK)] & 0xfffffff;
            if (this.etrees[lhs] != 0){
                ;
                this.treeStart = this.etrees[lhs];
                return this.etrees[lhs];
            }
        }
        int loc = this.loc;
        int start = loc;
        // int visitedNr = 0;              // nr of nodes visited

        int dp = 0;
        int qp = 0;
        if ((gssEdgeDir[(root-3)>>>NSHF][((root-3)&MSK)] & HEADTREE) == 0){  // not already encoded
            this.encodequeue[qp++] = root-4;     // enqueue root
            // SPPFGSS(root-1) |= visited;
        }
        while (dp != qp){                        // while queue not empty
            int i = this.encodequeue[dp++];      // dequeue
            // int el = SPPFGSS(i+3);
            // visitedNr++;
            ;

            // make sure that derivations for a same empty rule has one single instance in the
            // final parse tree
            // int lhs = -1;
            // if (SPPFGSS(i+1) == HEADSYM){     // empty rule
            if (gssEdgeDir[(i+1)>>>NSHF][((i+1)&MSK)] == HEADSYM){        // empty rule
                int el = gssEdgeDir[(i+3)>>>NSHF][((i+3)&MSK)];
                int lhs = el & 0xfffffff;
                if (this.etrees[lhs] != 0){      // already encountered
                    ;
                    continue;
                } else {
                    ;
                }
            }

            int nrrules = 0;
            // SPPFGSS(i+2) = this.loc;                     // remapping
            gssEdgeDir[(i+2)>>>NSHF][((i+2)&MSK)] = this.loc;                        // set it to consider allocated
            ;

            // I must allocate/copy the symbol node only if it has > 1 rules,
            // but I do not know it, and neither I know how many they are so as to allocate
            // the table of its rules. I first allocate/copy the rules and then the symbol
            // node, but I must remember somewhere the locations of the symbol nodes ... it
            // would had been better to link the rules in a list instead of having a table
            // of symbol nodes in the final parse tree.
            // But then all rules would have a field in them for the link, also the ones that
            // belong to symbol nodes that have only one rule.

            for (int j = i + 4; j != 0; j = gssEdgeDir[(j)>>>NSHF][((j)&MSK)] & ~HEADSYM){
                int len = gssEdgeDir[(j+1)>>>NSHF][((j+1)&MSK)] & ~HEADF;
                int rule = len;
                // if (len < this.tab.numOfRules){        // not a repetition group
                    ;
                    len = this.tab.ruleLen[rule];         // fixed length
                // } else {                               // repetition group
                //    len -= this.tab.numOfRules;         // decode the length
                // }
                ;
    
                // reserve space in tree for rule
                loc = this.loc;
                // save the start address of this rule
                if (nrrules >= this.ruleptrs.length){
                    this.ruleptrs =  Arrays.copyOf(this.ruleptrs,nrrules << 1);
                }
                this.ruleptrs[nrrules++] = loc;
                this.loc += len + 1;
                if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                    enlargeTree(this.loc);
                }
                // copy header
                ;
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = rule | HEAD;
                loc++;

                int startrule = loc;
                ;
                int elstart = j + 2;
                for (int k = j + 2; k < j + 2 + len; k++){
                    int el = gssEdgeDir[(k)>>>NSHF][((k)&MSK)];
                    ;
                    this.tree[(loc)>>>NSHF][((loc)&MSK)] = el;
                    loc++;
                    if (el == -1){
                        Trc.out.printf("invalid at: %d lev %d j %d i %d\n",k,this.level,j,i);
                    }
                    if (el == 0){                           // nullable nt
                        ;
                        continue;
                    }
                    if ((el & HEADF) != 0) continue;       // token or already built
                    if ((gssEdgeDir[(el-3)>>>NSHF][((el-3)&MSK)] & HEADTREE) != 0){  // already built
                        continue;
                    }
                    // if ((SPPFGSS(el-1) & visited) != 0){
                    //    continue;
                    // }
                    if (gssEdgeDir[(el-2)>>>NSHF][((el-2)&MSK)] != 0){
                        continue;
                    }

                    ;
                    // SPPFGSS(el-1) |= visited;
                    gssEdgeDir[(el-2)>>>NSHF][((el-2)&MSK)] = -1;  // mark
                    if (qp >= this.encodequeue.length){
                        if (dp > this.encodequeue.length/QUEUE_THRES_1){  // shift down, if worth
                            System.arraycopy(this.encodequeue,dp,this.encodequeue,0,qp-dp);
                            qp -= dp;
                            dp = 0;
                        } else {                        // enlarge
                            this.encodequeue = Arrays.copyOf(this.encodequeue,
                                this.encodequeue.length+this.encodequeue.length/QUEUE_THRES_2);
                        }
                    }
                    this.encodequeue[qp++] = el-4;      // enqueue it
                }
                startrule = loc - startrule;                // nr of elements copied
                ;
                if (startrule < this.tab.ruleLen[rule]){    // nr of elements < rule length
                    // store references to nullable nt's in final parse tree
                    for (int k = startrule; k < this.tab.ruleLen[rule]; k++){
                        ;
                        this.tree[(loc)>>>NSHF][((loc)&MSK)] = 0;
                        loc++;
                    }
                }
            }
            // store then the symbol node
            if (nrrules > 1){
                ;
                // SPPFGSS(i+2) = this.loc;                // remap it to symbol node
                gssEdgeDir[(i+2)>>>NSHF][((i+2)&MSK)] = this.loc;                // remap it to symbol node
                loc = this.loc;
                this.loc += nrrules + 1;
                if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                    enlargeTree(this.loc);
                }
                ;
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = nrrules | HEADSYM;          // number of rules
                for (int j = 0; j < nrrules; j++){      // copy the rules
                    loc++;
                    this.tree[(loc)>>>NSHF][((loc)&MSK)] = this.ruleptrs[j];
                }
            }
        }
        /*
        #ifdef ENCODEMARKS
        int vis = 0;
        for (int i = this.symnodeList; i > 0; i = SPPFGSS(i)){
            int el = SPPFGSS(i+3);
            if ((el & visited) != 0){
                vis++;
            }
        }
        if (vis != visitedNr){
            Trc.out.printf("!!!! marked %d visitedNr %d\n",vis,visitedNr);
            return 0;
        }
        #endif
        */
        // for (int i = this.symnodeList; i > earliest; i = SPPFGSS(i)){
        //     SPPFGSS(i+3) &= ~visited;
        // }

        // scan the rules stored above in the final parse tree and remap the references to symbol
        // nodes in the edges blocks to the ones in the parse tree
        ;

        // SPPFGSS(root-1) &= ~visited;
        loc = this.loc;
        for (int i = start; i < loc;){                 // scan the tree
            int h = this.tree[(i)>>>NSHF][((i)&MSK)];
            if ((h & HEADF) == HEADSYM){               // symbol node
                int len = h & ~HEADSYM;
                this.altNum += len;
                i += len + 1;
            } else {
                int len = h & ~HEADF;                  // length of phrase of derivation
                int rule = len;
                ;
                // if (len < this.tab.numOfRules){     // not a repetition group
                    len = this.tab.ruleLen[len];       // fixed length
                // } else {                            // repetition group
                //    len -= this.tab.numOfRules;      // decode the length
                // }
                i++;
                int end = i + len;
                int elstart = i;
                for (; i < end; i++){
                    int el = this.tree[(i)>>>NSHF][((i)&MSK)];
                    ;
                    if ((el & HEADF) == HEAD){          // already built
                        el &= ~HEAD;
                    } else if (el == 0){                // e-tree
                        int d = this.tab.ruleIndex[rule] + i - elstart;   // index in grammar
                        int nt = this.tab.grammar[d];
                        ;
                        if (this.etrees[nt] == 0){      // not already encountered
                            this.etrees[nt] = encodeEtree(nt);
                        }
                        el = this.etrees[nt];
                    } else if (el > 0){
                        ;
                        // SPPFGSS(el-1) &= ~visited;
                        if ((gssEdgeDir[(el-3)>>>NSHF][((el-3)&MSK)] & HEADTREE) != 0){     // already built
                            el = gssEdgeDir[(el-3)>>>NSHF][((el-3)&MSK)] & ~(HEADTREE | HEADSYM);
                        } else {
                            if (gssEdgeDir[(el-3)>>>NSHF][((el-3)&MSK)] == HEADSYM){        // empty rule
                                int lhs = gssEdgeDir[(el-1)>>>NSHF][((el-1)&MSK)] & 0xfffffff;
                                el = this.etrees[lhs];
                                // how can I be sure that it has already been encoded?
                                if (this.etrees[lhs] == 0){
                                    Trc.out.printf("!! encodetree ref empty %d\n",
                                        -this.etrees[lhs]);
                                    el = -this.etrees[lhs];
                                    el = gssEdgeDir[(el-2)>>>NSHF][((el-2)&MSK)];
                                }
                                ;
                            } else {
                                el = gssEdgeDir[(el-2)>>>NSHF][((el-2)&MSK)];
                            }
                        }
                    }
                    this.tree[(i)>>>NSHF][((i)&MSK)] = el;
                }
                this.derNum++;
                this.eleNum += len;
            }
        }
        /*
        #ifdef ENCODEMARKS
        for (int i = this.symnodeList; i > 0; i = SPPFGSS(i)){
            int el = SPPFGSS(i+3);
            SPPFGSS(i+3) &= ~visited;                   // clear marks
        }
        #endif
        */
        this.treeLen = this.loc;
        this.treeStart = gssEdgeDir[(root-2)>>>NSHF][((root-2)&MSK)];               // not "start" when it has several rules
        ;

        // return start;
        return treeStart;
    }

    /**
     * Generate the forest for the empty derivation of the specified nonterminal.
     *
     * @param      root nonterminal
     * @return     index in the forest
     */

    int encodeEtree(int root){
        return 0;
    }

    /**
     * Generate the forest for the specified rule with its elements in the LR stack.
     *
     * @param      rule rule
     * @return     index in the forest
     */

    int encodeLRtree(int rule){
        ;
        // on the stack there are n values, where n is the length of the rule,
        // each being a token or a derivation

        int sym = this.tab.ruleToNt[rule];
        int kind = this.tab.ntKind[sym];
        // do not handle groups for the time being
        kind = 0;
        ;

        int len = this.tab.ruleLen[rule];
        int beforerule = this.gssEdgeNr - (len * 3) - 2;  // level of stack before rule
        if (beforerule > this.LRstackBottom &&
            gssEdgeDir[(beforerule)>>>NSHF][((beforerule)&MSK)] == this.level){           // empty yield
            ;
            if (this.etrees[sym] == 0){
                this.etrees[sym] = this.loc;
            } else {
                return this.etrees[sym];    // return already encoded e-tree
            }
        }

        int newloc = this.loc;
        int start = newloc;
        doit: {
            int hdr = rule;
            if (this.tab.toOriginRule != null){
                hdr = this.tab.toOriginRule[hdr];
                ;
            }
            if (kind == ParserTables.OPT){        // optional group
                ;
                if (len != 0){                    // &1 present
                    int der = this.gssEdgeNr - 1; // stack top, value
                    der = gssEdgeDir[(der)>>>NSHF][((der)&MSK)];           // its body
                    start = der;
                    newloc = der;
                    break doit;                   // skip
                }
                hdr = this.tab.numOfRules;
            } else if (kind == ParserTables.BOD){ // its body
                hdr = this.tab.numOfRules + 1;
            }
            newloc += len + 1;

            if (((newloc-1) >>> NSHF) >= this.treeBlocks){
                enlargeTree(newloc);
            }
            int loc = this.loc;
            //  if (kind != 0) newloc++;                 // backlink

            // store header
            ;
            this.tree[(loc)>>>NSHF][((loc)&MSK)] = hdr | HEAD;
            loc++;

            // visit the stack for this rule
            for (int i = this.gssEdgeNr - (len * 3) + 2; i < this.gssEdgeNr; i += 3){
                int val = gssEdgeDir[(i)>>>NSHF][((i)&MSK)];
                // store value            
                if ((val & HEADF) == HEAD) val &= ~HEAD;
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = val;                  // store header
                ;
                loc++;
            }
            this.eleNum += newloc - start - 1;
            this.derNum++;
            this.treeLen = newloc;
            this.treeStart = this.loc;
            this.loc = newloc;
        } // doit
        return start;
    }

    /**
     * Generate the forest for the specified rule collecting the trees of each element,
     * and encoding the ones that are not yet so (instead of creating a node with its sppf),
     * which happens when the previous levels are not LR.
     *
     * @param      rule rule
     * @param      rootnode starting node
     * @return     index in the forest
     */

    protected int encodeLRdyntree(int rule, int rootnode){
        ;
        // on the gss there is a linear path with n values, where n is the length of the rule,
        // each being a token or a derivation

        int sym = this.tab.ruleToNt[rule];
        int kind = this.tab.ntKind[sym];
        // do not handle groups for the time being
        kind = 0;
        ;

        // detect if it is an etree
        int len = this.tab.ruleLen[rule];
        int node = rootnode;
        this.LRstackBottom = node;
        boolean etree = true;
        for (int i = 0; i < len; i++){
            int edge = gssNodeDir[(node)>>>NSHF][((node)&MSK)+NODE_EDGES] & 0x7fffffff;
            edge &= ~0x80000000;
            if (gssEdgeDir[(edge)>>>NSHF][((edge)&MSK)] != 0){
                ;
                return -1;
            }
            node = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
            if (node < this.levelGss){            // in a previous level
                etree = false;
            }
        }
        if (etree){                                // empty yield
            ;
            if (this.etrees[sym] == 0){
                this.etrees[sym] = this.loc;
            } else {
                return this.etrees[sym];           // return already encoded e-tree
            }
        }
        node = rootnode;
        for (int i = 0; i < len; i++){
            int edge = gssNodeDir[(node)>>>NSHF][((node)&MSK)+NODE_EDGES] & 0x7fffffff;
            int sppf = gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)];
            if (sppf == 0){                        // e-tree
                int d = this.tab.ruleIndex[rule] + len - i - 1;   // index in grammar
                int nt = this.tab.grammar[d];
                ;
                if (this.etrees[nt] == 0){         // not already encountered
                    this.etrees[nt] = encodeEtree(nt);
                }
                gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)] = this.etrees[nt] | HEAD;
                ;
            } else if ((sppf & HEADF) == 0){       // not yet encoded
                gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)] = encodetree(sppf) | HEAD;
                ;
            }
            node = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
        }

        int newloc = this.loc;
        int start = newloc;
        doit: {
            int hdr = rule;
            if (kind == ParserTables.OPT){        // optional group
                ;
                if (len != 0){                    // &1 present
                int der = this.gssEdgeNr - 1;     // stack top, value
                    der = gssEdgeDir[(der)>>>NSHF][((der)&MSK)];           // its body
                    start = der;
                    newloc = der;
                    break doit;                   // skip
                }
                hdr = this.tab.numOfRules;
            } else if (kind == ParserTables.BOD){ // its body
                hdr = this.tab.numOfRules + 1;
            }
            newloc += len + 1;
            if (((newloc-1) >>> NSHF) >= this.treeBlocks){
                enlargeTree(newloc);
            }
            int loc = this.loc;
            // if (kind != 0) newloc++;                 // backlink
            // store header
            ;
            this.tree[(loc)>>>NSHF][((loc)&MSK)] = hdr | HEAD;
            loc++;

            // visit the gss for this rule
            node = rootnode;
            for (int i = len-1; i >= 0; i--){
                int edge = gssNodeDir[(node)>>>NSHF][((node)&MSK)+NODE_EDGES] & 0x7fffffff;
                int val = gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)];
                if ((val & HEADF) == HEAD) val &= ~HEAD;
                // store value            
                int l = loc + i;
                this.tree[(l)>>>NSHF][((l)&MSK)] = val;                  // store element
                ;
                node = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
            }
            this.LRstackBottom = node;
            this.eleNum += newloc - start - 1;
            this.derNum++;
            this.treeLen = newloc;
            this.treeStart = this.loc;
            this.loc = newloc;
        } // doit
        ;
        return start;
    }

    /** Whether the forest is cleaned before returning. */
    public boolean doCleanForest = false;
}
