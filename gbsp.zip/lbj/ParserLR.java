/*
 * @(#)ParserLR.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;
import lbj.HashBag.*;
import lbj.HashTbl.*;
import lbj.ParserLexer.*;
import lbj.ParserNode.*;
import lbj.ParserGen.*;
import lbj.ParserBnf.*;
import lbj.ParserGrammar.*;
import lbj.ParserLRTables.*;
import java.lang.reflect.*;

/**
 * The <code>ParserLR</code> class provides a generator of the various kinds of LR parsing
 * tables for the parser engine.
 *
 * @author  Angelo Borsotti
 * @version 1.0   1 Mar 2020
 */

/*
 * Class dependencies:
 *     class FA extends HashBag
 *         class Trans
 *         class State extends HashNode         number, transList, status
 *     class LR0FA extends FA                                    buildPilot, closure
 *         class Item                           index, dot
 *         class LR0State extends State         itemList
 *     class LR01FA extends LR0FA                                buildLalrLa, detectsublalr(), isTokenAmbiguous
 *         class LR1Item extends Item           la
 *         class LR01State extends LR0State     accessingSymbol 
 *     class LR1FA extends LR01FA                                closure
 *         class LR1State extends LR01State
 *     class LALRFA extends LR01FA
 *         class LALRState extends LR01State    + pennello
 *     class LALRRNFA extends LALRFA
 *         class LALRRNState extends LALRState  beforeDots
 *     class NFA extends LR0FA
 *         class NFAItem extends Item
 *         class NFAState extends LR0State      machines
 *     class MDFA extends NFA
 *         class MDFATrans extends Trans
 *         class MDFAState extends NFAState     machines
 *     class ELR1FA extends LR1FA
 *         class ELR1Item extends LR1Item
 *         class ELR1State extends LR1State
 *     class ELR1PFA extends ELR1FA
 *         class ELR1PItem extends ELR1Item     left, rhl
 *     class ELR1RNFA extends ELR1PFA
 *         class ELR1RNItem extends ELR1Item    leftSet
 *         class ELR1RNState extends ELR1State
 *     class LALRGRNFA extends LR1FA                             isTokenAmbiguous
 *         class LALRGRNItem extends LR1Item    leftPtr
 *         class LALRGRNState extends LALRRNState
 *
 * - LR0FA additem treats groups, but its closure not, which is correct since its items
 *   do not have lookaheads.
 *   LALR here uses the buildstates of LR0, that has no lookaheads, which are added after.
 *   In parserlalr build_lalr computes the lookaheads for all items, so the ones of groups
 *   are there and are correctly computed, irrespectively on what lookahead the items had
 *   before. The step-by-step algorithm computes also them from scratch adding lookaheads
 *   when it adds items treating also groups and treating groups also when making the
 *   closure.
 *   LALR here puts lookaheads only on reductions: buildstates adds items created with
 *   newadvitem, that LR1 redefines to add the lookaheads, but LALR not, so a LR0 pilot
 *   is produced. It does not use the step-by-step one, so it does not matter if the closure
 *   treats groups, not even additem adds lookaheads.
 *
 * - each FA can decide to keep transitions ordered or not when adding them. By default they
 *   are kept ordered. This is controlled by the field transOrdered.
 *   This changes the order in which states are generated.
 *   If a FA does not want them ordered when adding them, it can (and it is a good idea)
 *   order them when the states are completed. 
 * - items are kept unordered when adding them, and each FA orders them when states are
 *   completed.
 *
 * - the tables that are used by the parsers are a compressed form of the transition tables
 *   plus some other tables, depending on the parser.
 *   The reductions in the compressed tables contain data that depend on the parser.
 *   Each redefine the method storeReductions(), that fill the reduction part of the tables,
 *   and comprReduToString() that delivers a string representing a reduction.
 *
 * - the FAs that have isles have a common superclass: LR01FA, which is also the superclass
 *   of all the ones that have LALR lookaheads. The corresponding table class is LALRRNFAtables,
 *   that has the fields for isles.
 *
 * - the accessing symbol is a general field, and has been added to LR01State to help
 *   several subclasses to have it.
 *
 * - the items in states are ordered because, starting with a state with ordered items,
 *   any next state is obtained by advancing the items, which means that the new ones
 *   are ordered too.
 *
 * These are the methods that can be overridden by subclasses. A subclass overrides a method
 * of a superclass when it must do some specific actions and when the subclass does not
 * override the methods of the superclass that call it.
 * Each FA (class) can have dedicated classes for arcs, states, possibly items, and can
 * inherit them from another FA. When it does, it must override the methods newState(),
 * newTrans(), newItem(), newAdvItem(), addItem().
 * (N.B newtrans is currently not overridden because up to now there are no general methods
 * that add transitions).
 * If transitions or items or states are redefined, probably there is a need for dedicated
 * constructors
 *
 * classes for items:
 *      when adding items, the notion of equality is different from the one needed when
 *      comparing states.     E.g. for some FAs items with the same dot have their lookaheads merged.
 *      equals():             tell if items equal when comparing states
 *      equivalent():         tell if items equal when adding items during the building of a state
 *      compareTo():          compares two items to tell which is prior
 *      isFinal():            tell if it is final
 *      isInitial():          tell if it is initial
 *      isAdequate():         tell if it is adequate
 *      toStates():           deliver the next states it leads to
 *      lhs():                deliver the nonterminal the item belongs to
 *      toString():           string representation of item
 *
 * classes for states:
 *      equals():             tell if state is equal to another
 *      hashCode():           hash code of state
 *      toString():           string representation of state
 *      statusToString():     deliver a string representing the status of a state
 *      addItem():            add an item in buildpilot, closure and by some additem
 *      sortItems():          sort the items
 *      findConflicts():      determine if there are conflicts
 *      header():             string representation of the header of the state in tracing
 *      trace():              trace the state
 *
 * classes for FAs
 *      tokSetToString():     string representation of a set of tokens
 *      newItem():            deliver a new item in buildpilot, closure and by some additem
 *      newAdvItem():         deliver an item that is the successor of a given one in buildpilot
 *                            and buildLalrLa
 *      newState():           create a new state
 *      addUnique():          add a state, if not already present
 *      closure():            perform the closure of the list of items of a state
 *      storeReductions():    fill the reduction part of the compressed table
 *      comprReduToString():  deliver a string representing a reduction in the compressed table
 *      trace():              trace the tables
 *      size():               deliver the size of the generated data
 *      build():              build the tables
 *
 * N.B. Some of these methods are defined in the classes contained in ParserLRTables, that
 * hold the data that are needed at parse time.
 *
 * - specific classes can have additional methods that can be overridden by their subclasses
 * - the Java subclassing is a bit unflexible here, but the main problem is that it is difficult
 *   to tell what superclasses methods are called when a subclass one is exectuted, and even more,
 *   there are methods that are similar to the superclass ones, but not identical, which means
 *   that either the superclass ones are stuffed with tests to support also the subclasses
 *   beheviours (but that is not always possible, e.g. when it depends on fields that are present
 *   only in subclasses), or they are just copied and specialized (which is also not much good
 *   because it makes difficult to spot what is different from their superclass versions).
 * - the methods of the items allow to have only one implementation of the builtPilot() and
 *   detectSubLalr() methods; there is instead a need for a dedicated closure() ones in some
 *   classes because a general one would have very little in it: it need to know all
 *   the predictions:
 *     - for normal items, take the ones with the dot in front of a nonterminal,
 *       add one advanced item for each predicted rule, lookahead = follow
 *       (or'ed with first of item if BOR for groups)
 *     - for machines, an item has a number of successors, some of which are for
 *       nonterminals. For each of the latter, an advanced item is added, with
 *       the dot = initial state of machine, lookaheads = first of the initial item
 *       or'ed with the item lookaheads if the machine is nullable
 *
 * - the states that become dangling when the isles are plugged in are not removed. Perhaps
 *   there is no need to remove them if the compact tables are then built and they are
 *   not included in them ... but probably it is better to remove them
 *
 * Resulting data
 *
 *    The data that are needed at parse time are delivered in the companion objects in ParserLRTables.
 *    ParserLR outputs objects that contain only the tables, and not all the data needed to build
 *    them. This allows to serialize the parser tables without a need for having also all the
 *    files that generate them.
 *
 * Testing
 *
 *   ParserTst35 contains the testing of the pilots. There are test cases for all the grammars
 *   and the pilots, and the resulting statistics.


... to structure better ParserLR, interfaces could be used instead of inheritance ...
    It contains fields and methods, and some methods call some others that need to be
    specialized in subclasses. Default interface methods at most can call some getter
    method to access some instance values, which is not what a normal method does.
    So, define a class with the main fields and methods such as build(), and a number
    of classes, one for each kind of LR, all implementing a same interface that defines
    the methods that must be specialized. Then, to have a LR, instantiate the general
    one and store into one of its fields a reference to the specialized one.
    Moreover, generate an instance of the parse-time tables. For these it is more complex
    not to use class inheritance. They contain mostly fields. Perhaps I can avoid to
    make the classes inherit, and implement inheritance defining for each class a
    field that is a reference to a set of fields. So, each LR table would be a class
    that contains references to objects that contain a set of data for each specific
    feature of the class. E.g. basic data, compressed tables, isles, hops, rn tails, etc.
    Each class of LR tables would have a field for each one of these extra data that
    it needs. Perhaps it is clearer, even though accessing the extra data would be more
    lengthy.

... when building the states of a pilot, and adding the predicted items, we do the same
    adding of items in all states that have an item with the dot in front of the same
    nt, possibly with different lookaheads or leftpointers. It should be possible to
    factor out this in some way.
    This is done in split dfas, but it could be possible to do it also in the non-split
    ones perhaps if we put a link in states to some container of predicted items (well,
    several links, one for each item that has predicted items), or perhaps if we do
    not store them at all, and compute them on the fly when needed.
    They are not needed to test unicity of states, not when lookaheads or pointers are
    irrelevant for equality.
    They are needed to determine the items of the next states.
    Not storing them serves only to save memory, which could be important only when
    very large FAs are built.

 */


//------ New classes, that allow to subclass then to cope with all the variants of FAs

class ParserLR implements Serializable {

    /** The LR0 FA kind. */
    static final int LR0 = 0;

    /** The LR1 FA kind. */
    static final int LR1 = 1;

    /** The LALR FA kind. */
    static final int LALR = 2;

    /** The LALR Right-Nullable FA kind. */
    static final int LALRRN = 3;

    /** The ELR1 FA kind. */
    static final int ELR1 = 4;

    /** The ELR1+ FA kind. */
    static final int ELR1P = 5;

    /** The ELR1-RN FA kind. */
    static final int ELR1RN = 6;

    /** The LALRG-RN FA kind. */
    static final int LALRGRN = 7;

    /** The kind. */
    int kind;

    /** The options. */
    String options;

    /** The parser tables. */
    ParserTables tab;

    /** The parser analyzer. */
    ParserBnf prs;

    /** The trace flags. */
    int trc;

    /** The generated FA object. */
    FA fa;

    /** The generated tables. */
    ParserLRTables pilot;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    c   conflicts
     *    d   states
     *    e   main trace
     *    f   detailed trace
     *    h   machines
     *    l   LALR building
     *    s   cyclic rules, derived nts, isles
     * </pre></blockquote><p>
     */

    static final int FL_C = 1 << ('c'-0x60);
    static final int FL_D = 1 << ('d'-0x60);
    static final int FL_E = 1 << ('e'-0x60);
    static final int FL_F = 1 << ('f'-0x60);
    static final int FL_H = 1 << ('h'-0x60);
    static final int FL_L = 1 << ('l'-0x60);
    static final int FL_S = 1 << ('s'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Print the stack of calls.
     *
     * @param      msg sting to be printed before the calls
     */

    private static void calls(String msg){
        Trc.out.printf("%s\n",msg);
        Throwable th = new Throwable();
        th.printStackTrace();
    }

    /** Whether the debugging is enabled. */
    static boolean debugEnabled;

    /** 
     * Construct a LR generator for the specified and lexicon.
     *
     * @param      tab reference to the grammar
     * @param      kind kind of FA
     * @param      options variants
     */

    ParserLR(ParserTables tab, int kind, String options){
        this.tab = tab;
        this.kind = kind;
        this.options = options;
    }

    /** 
     * Construct a LR generator.
     */

    ParserLR(){
    }

    /** The number of bits in a byte. */
    private static final int BITSBYTE = 8;

    /** 
     * Deliver a bitstring with the specified number of elements.
     *
     * @param      n number of elements
     * @return     bitstring
     */

    private static byte[] newBits(int n){
        return new byte[(n + BITSBYTE - 1) / BITSBYTE];
    }

    /** 
     * Get the value of the entry at the specified index in the specified bitstring.
     *
     * @param      arr bitstring
     * @param      idx index
     * @return     value, <code>true</code> or <code>false</code>
     */

    private static boolean boolGet(byte[] arr, int idx){
        return (arr[idx>>>ParserTables.NSHIFTB] &
            (1 << (idx & ParserTables.MASKB))) != 0;
    }

    /** 
     * Set the entry to true at the specified index in the specified bitstring.
     *
     * @param      arr bitstring
     * @param      idx index
     */

    private static void boolSet(byte[] arr, int idx){
        arr[idx>>>ParserTables.NSHIFTB] |=
            (1 << (idx & ParserTables.MASKB));
    }

    /** 
     * Set the entry to false at the specified index in the specified bitstring.
     *
     * @param      arr bitstring
     * @param      idx index
     */

    private static void boolClear(byte[] arr, int idx){
        arr[idx>>>ParserTables.NSHIFTB] &=
            ~(1 << (idx & ParserTables.MASKB));
    }

    /** 
     * Deliver the element at the end of the singleton chain of the specified
     * element, if singletons are enabled and if the element is not the
     * body of a group.
     *
     * @param      gp element
     * @return     element at the end of chain
     */

    private int toSingleton(int gp){
        int res = gp;
        doit: {
            if (gp < this.tab.tokBase){
                if (this.tab.ntKind[gp] == ParserTables.BOR ||
                    this.tab.ntKind[gp] == ParserTables.BOO ||
                    this.tab.ntKind[gp] == ParserTables.BOD ||
                    gp == this.tab.grammar[this.tab.startRule]){
                    break doit;
                }
            }
            res = this.tab.singmap[gp];
        }
        return res;
    }

    /**
     * A vector of integers.
     */

    private static class IntVector implements Serializable {

        /** The container. */
        private ArrayList<Integer> arr;

        /** 
         * Construct an object.
         */

        IntVector(){
            this.arr = new ArrayList<Integer>();
        }

        /** 
         * Deliver a clone of this object.
         *
         * @return   reference to the clone
         */

        public IntVector clone(){
            IntVector res = new IntVector();
            res.arr = new ArrayList<Integer>();
            res.arr.addAll(this.arr);
            return res;
        }

        /** 
         * Remove all the elements from this object.
         */

        void clear(){
            this.arr.clear();
        }

        /** 
         * Append the specified value to this object.
         *
         * @param   value value
         */

        void add(int value){
            this.arr.add(value);
        }

        /** 
         * Append the specified value to this object if not already present.
         *
         * @param   value value
         */

        void unite(int value){
            int size = this.arr.size();
            for (int i = 0; i < size; i++){
                if (this.arr.get(i) == value){
                    return;
                }
            }
            this.arr.add(value);
        }

        /** 
         * Append all the value of the specified object to this object if not already present.
         *
         * @param   vec vector
         */

        void unite(IntVector vec){
            int size = vec.size();
            for (int i = 0; i < size; i++){
                unite(vec.get(i));
            }
        }

        /** 
         * Deliver the number of values contained in this objects.
         *
         * @return   number of values
         */

        int size(){
            return this.arr.size();
        }

        /** 
         * Deliver the number of values contained in this objects.
         *
         * @return   number of values
         */

        int length(){
            return this.arr.size();
        }

        /** 
         * Deliver the value at the specified index.
         *
         * @return     number of values
         * @exception  IndexOutOfBoundsException if the index is out of range
         */

        int get(int idx){
            return this.arr.get(idx);
        }

        /** 
         * Deliver a string representing this object.
         *
         * @return   string
         */

        public String toString(){
            return this.arr.toString();
        }

        /** 
         * Tell if this object is equal to the specified one.
         *
         * @parm     other other object
         * @return   <code>true</code> if equal, <code>false</code> otherwise
         */

        boolean equals(IntVector other){
            return this.arr.equals(other);
        }

        /** 
         * Sort the values of this object in ascending order.
         */

        void sort(){
            if (this.arr.size() <= 1) return;
            Integer[] sarr = new Integer[this.arr.size()];
            this.arr.toArray(sarr);
            Arrays.sort(sarr);
            this.arr.clear();
            for (int i = 0; i < sarr.length; i++){
                this.arr.add(sarr[i]);
            }
        }
    }

    /**
     * The FA: table of states and all other data.
     */

    class FA extends HashBag {

        /** The reference to the generated parser lr tables. */
        protected FAtables lrt;

        /** The head of the ordered list. */
        protected State head;

        /** The last of the list. */
        protected State last;

        /** The last element added. */
        protected State lastAdded;

        /** The resulting array of states. */
        protected State[] table;

        /** Whether the transitions are kept ordered. */
        protected boolean transOrdered = true;

        /**
         * A transition (edge) from a state to another.
         */

        protected class Trans {

            /** The reference to the next one. */
            private Trans next;

            /** The next state. */
            protected State nextState;

            /** The symbol on the edge. */
            protected int sym;

            /**
             * Deliver a new transition with the specified symbol and next state.
             *
             * @param   sym symbol
             * @param   next next state
             * @return  transition
             */

            Trans(int sym, State next){
                this.sym = sym;
                this.nextState = next;
            }

            /**
             * Deliver a string representing this object.
             *
             * @return  string
             */

            public String toString(){
                return String.format("-%s->%s",
                    tab.gramSymToString(this.sym),this.nextState.number);
            }
        }

        /**
         * A state.
         */

        protected class State extends HashNode {

            /** The reference to the next element. */
            protected State suc;

            /** The number of the state. */
            protected int number;

            /** The list of edges. */
            protected Trans transList;

            /** The status. */
            protected int status;

            /**
             * Deliver a new state with the specified number.
             *
             * @param   number
             * @return  state
             */

            State(int n){
                this.number = n;
            }

            /**
             * Deliver a new state.
             *
             * @return  state
             */

            State(){
            }

            /**
             * Deliver a string representing this object.
             *
             * @return  string
             */

            public String toString(){
                Str st = new Str();
                st.append(Integer.toString(this.number));
                return st.toString();
            }

            /**
             * Tell if this object is equal to the specified one.
             *
             * @param   other object
             * @return  <code>true</code> if equal, <code>false</code> otherwise
             */

            public boolean equals(Object other){
                if (this == other) return true;
                if (other == null) return false;
                State s = (State)other;
                return true;
            }

            /**
             * Deliver the hash value of this object.
             *
             * @return  hash value
             */

            public int hashCode(){
                return 0;
            }

            /**
             * Add a transition, if not already present, keeping the transitions ordered.
             *
             * @param   tr transition
             * @return  reference to the added transition
             */

            protected Trans addTrans(Trans tr){
                Trans res = null;
                boolean found = false;
                Trans prev = null;
                // add it in sorted order
                for (Trans t = this.transList; t != null; t = t.next){
                    if (t.sym == tr.sym && t.nextState == tr.nextState){   // do not add duplicates
                        res = t;
                        found = true;
                        break;
                    }
                    if (transOrdered && tr.sym < t.sym) break;
                    prev = t;
                }
                if (!found){
                    if (prev == null){
                        tr.next = this.transList;
                        this.transList = tr;
                    } else {
                        tr.next = prev.next;
                        prev.next = tr;
                    }
                    res = tr;
                }
                return res;
            }

            /**
             * Order the transitions.
             *
             * @param   sym symbol
             * @param   next next state
             * @return  transition
             */

            protected void transOrder(){
                Trans ord = null;                   // ordered transitions
                Trans nextTr = null;;
                for (Trans tr = this.transList; tr != null;){
                    nextTr = tr.next;
                    Trans pr = null;
                    Trans cur = ord;
                    while (cur != null){            // seek insertion point
                        int lo_cur = cur.sym;
                        int lo_tr = tr.sym;
                        if (lo_cur > lo_tr){        // point found
                            break;
                        }
                        pr = cur;
                        cur = cur.next;
                    }
                    if (pr == null){                // insert at beginning
                        tr.next = ord;
                        ord = tr;
                    } else {                        // insert in the middle
                        tr.next = cur;
                        pr.next = tr;
                    }
                    tr = nextTr;
                }
                this.transList = ord;
            }

            /**
             * Deliver a string representing the name of this state.
             *
             * @return  string
             */

            protected String name(){
                return Integer.toString(this.number);
            }

            /**
             * Deliver a string representing the header of the state in tracing.
             *
             * @return  string
             */

            protected String header(){
                String status = lrt.statusToString(this.status);
                String nam = name();
                return String.format("\nstate: %s%s",this.number,
                    status.length()==0?"":" " + status,
                    nam.length()==0?"":" " + nam);
            }

            /**
             * Trace this state.
             */

            void trace(){
                Trc.out.printf("%s\n",header());
                if (this.transList != null){
                    Trc.out.printf("  transitions\n");
                    for (Trans t = this.transList; t != null; t = t.next){    // trace its transitions
                        Trc.out.printf("    %s\n",t.toString());
                    }
                }
            }
        }

        /**
         * Deliver a new state.
         *
         * @param   sym accessing symbol
         * @return  state
         */

        // FA
        protected State newState(int sym){
            return new State();
        }

        /**
         * Trace this FA.
         */

        // FA
        public void trace(){
            for (State s = this.head; s != null; s = s.suc){
                s.trace();
            }
        }

        /**
         * Deliver a string representi this FA.
         */

        // FA
        public String toString(){
            String str = "";
            for (State s = this.head; s != null; s = s.suc){
                for (Trans t = s.transList; t != null; t = t.next){    // visit edges
                    if (str != "") str += ",";
                    String en = t.sym >= tab.tokBase ? tab.tokLitName(t.sym - tab.tokBase) : 
                        tab.ntStrings[t.sym];
                    en = Str.toHtml(en);
                    en = Str.strQuoted(en);
                    str += String.format("%s-%s->%s",s.number,
                        en,t.nextState.number);
                }
            }
            return str;
        }

        /**
         * Mark the states that have conflicts.
         */

        // FA
        protected void findConflicts(){
        }

        /**
         * Build the FA.
         *
         * @return  FA
         */

        // FA
        void build(){
            this.lrt.stateStatus = new int[this.lrt.stateNr];
            for (State s = this.head; s != null; s = s.suc){
                this.lrt.stateStatus[s.number] = s.status;
            }
        }
    }

    //--------- LR(0) ----------------

    /**
     * The LR(0).
     */

    class LR0FA extends FA implements Serializable {

        /**
         * An item.
         */

        protected class Item {

            /** The reference to the next item. */
            protected Item next;

            /** The index of the item. */
            protected int index;

            /** The dot in the rule. */
            protected int dot;

            /**
             * Deliver a new item with the specified dot.
             *
             * @param   dot dot
             * @return  item
             */

            Item(int dot){
                this.dot = dot;
            }

            /**
             * Tell if this object is equal to the specified one.
             *
             * @param   other object
             * @return  <code>true</code> if equal, <code>false</code> otherwise
             */

            boolean equals(Item other){
                return this.dot == other.dot;
            }

            /**
             * Tell if this object is equivalent to the specified one when building next states.
             *
             * @param   other object
             * @return  <code>true</code> if equivalent, <code>false</code> otherwise
             */

            boolean equivalent(Item other){
                return this.dot == other.dot;
            }

            /**
             * Compare this object with the specified one.
             *
             * @param      other the object to compare
             * @return     &lt; = or &gt; 0 if it precedes, is equal or follows the other
             */

            int compareTo(Item other){
                return this.dot - other.dot;
            }

            /**
             * Deliver a string representing this object.
             *
             * @return  string
             */

            public String toString(){
                return String.format("%s [%s]",this.index,tab.ruleToString(this.dot,true));
            }

            /**
             * Tell if this object is a final one.
             *
             * @return  <code>true</code> if final, <code>false</code> otherwise
             */

            boolean isFinal(){
                int gp = tab.grammar[this.dot];
                return gp >= tab.ruleBase;
            }

            /**
             * Tell if this object is an initial one.
             *
             * @return  <code>true</code> if initial, <code>false</code> otherwise
             */

            boolean isInitial(){
                int gp = tab.grammar[this.dot-1];
                return gp >= tab.ruleBase;
            }

            /**
             * Tell if this object is adequate (i.e. it has a unique predecessor).
             *
             * @return  <code>true</code> if adequate, <code>false</code> otherwise
             */

            boolean isAdequate(){
                return true;
            }

            /**
             * Deliver the next states that this item leads to.
             *
             * @param   state the state of the item
             * @return  array of next states, null if the item is final
             */

            State[] toStates(State state){
                int gp = tab.grammar[this.dot];
                if (gp >= tab.ruleBase){         // final
                    return null;
                }
                gp = toSingleton(gp);
                for (Trans t = state.transList; t != null; t = t.next){
                    if (t.sym == gp){
                        State next = t.nextState;
                        return new State[]{next};
                    }
                }
                return null;
            }

            /**
             * Deliver the nonterminal of this item.
             *
             * @return  nonterminal
             */

            int lhs(){
                int end = this.dot;
                while (tab.grammar[end] < tab.ruleBase) end++;
                return tab.ruleToNt[tab.grammar[end]-tab.ruleBase];
            }
        }

        /**
         * A state.
         */

        protected class LR0State extends State {

            /** The reference to the head of the list of items. */
            protected Item itemList;

            /**
             * Deliver a new state with the specified number
             *
             * @param   n number
             * @return  state
             */

            protected LR0State(int n){
                super(n);
            }

            /**
             * Deliver a new state.
             *
             * @return  state
             */

            protected LR0State(){
            }

            /**
             * Tell if this object is equal to the specified one.
             *
             * @param   other object
             * @return  <code>true</code> if equal, <code>false</code> otherwise
             */

            @Override
            public boolean equals(Object other){
                if (this == other) return true;
                if (other == null) return false;
                Item i1 = this.itemList;
                Item i2 = ((LR0State)other).itemList;
                for (; i1 != null && i2 != null; i1 = i1.next, i2 = i2.next){
                    if (!i1.equals(i2)) return false;
                }
                if (i1 != null || i2 != null) return false;
                return true;
            }

            /**
             * Deliver the hash value of this object.
             *
             * @return  hash value
             */

            @Override
            public int hashCode(){
                int h = 0;
                for (Item i = this.itemList; i != null; i = i.next){
                    int c = i.dot;
                    h = 31*h + c;
                }
                return h;
            }

            /**
             * Deliver a string representing this object.
             *
             * @return  string
             */

            @Override
            public String toString(){
                Str st = new Str();
                st.append(super.toString());
                st.append(": [");
                for (Item i = this.itemList; i != null; i = i.next){
                    if (i != this.itemList) st.append(", ");
                    st.append(i.toString());
                }
                st.append("]");
                return st.toString();
            }

            /**
             * Trace this state.
             */

            @Override
            void trace(){
                super.trace();
                Trc.out.printf("  items\n");
                for (Item i = this.itemList; i != null; i = i.next){   // trace its items
                    Trc.out.printf("    %s\n",i);
                }
            }

            /**
             * Append an item if not already present.
             *
             * @param   item item
             * @return  reference to the added or existing item
             */

            protected Item appendItem(Item item){
                Item res = null;
                boolean found = false;
                Item prev = null;
                for (Item i = this.itemList; i != null; i = i.next){
                    if (i.equivalent(item)){
                        res = i;
                        found = true;
                        break;
                    }
                    prev = i;
                }
                if (!found){               // add the specified item
                    if (prev == null){
                        this.itemList = item;
                        item.index = 0;
                    } else {
                        prev.next = item;
                        item.index = prev.index + 1;
                    }
                    res = item;
                }
                return res;
            }

            /**
             * Add an item if not already present and if the grammar has group items,
             * and the item is that of a group, add the additional group item.
             *
             * @param   item item
             * @return  reference to the added item
             */

            protected Item addItem(Item item){
                Item itm1 = appendItem(item);
                Item res = null;
                Item itm2 = null;
                gr: if ((tab.mode & ParserGen.NOGROUPS) == 0){   // has group items
                    if (itm1 != item) break gr;                  // already added both
                    int sy = tab.grammar[item.dot];
                    int p = item.dot-1;
                    int gp = tab.grammar[p];
                    if (gp >= tab.ruleBase){                // added a predicted item
                        break gr;
                    }
                    if (gp < tab.tokBase &&                 // nt
                        tab.ntKind[gp] == ParserTables.BOR){
                        if (sy < tab.ruleBase){             // old item ... . &1 &1
                        if (tab.grammar[p+2] <              // &1 &1 . &1 ...
                            tab.ruleBase) break gr;         // add extra final item
                            p++;                            // insert a &1 &1 .
                        } else {                            // old item ... &1 . &1
                            p--;                            // insert a &1 . &1
                        }
                        itm2 = appendItem(newItem(p+1));
                    }
                } // gr
                res = itm1;
                return res;
            }

            /**
             * Sort the list of items.
             */

            protected void sortItems(){
                Item res = null;
                for (Item i = this.itemList; i != null;){
                    Item next = i.next;
                    Item prev = null;
                    // add it to res in sorted order
                    for (Item j = res; j != null; j = j.next){
                        if (i.compareTo(j) < 0) break;
                        prev = j;
                    }
                    if (prev == null){     // prepend
                        i.next = res;
                        res = i;
                    } else {               // append to prev
                        i.next = prev.next;
                        prev.next = i;
                    }
                    i = next;
                }
                this.itemList = res;
                int index = 0;             // set the indexes
                for (Item i = this.itemList; i != null; i = i.next){
                    i.index = index++;
                }
            }

            /**
             * Tell if there are conflicts, and in such a case mark them in the state.
             */

            protected void findConflicts(){
                int shfnr = 0;
                int rednr = 0;
                for (Item i = this.itemList; i != null; i = i.next){
                    int gp = tab.grammar[i.dot];
                    if (gp >= tab.ruleBase){        // reduce item
                        rednr++;
                    } else {
                        shfnr++;
                    }
                }
                if (shfnr > 0 && rednr > 0){        // there are shifts
                    // shift-reduce conflict
                    this.status |= LR0FAtables.CONFLICT_SR;
                }
                if (rednr > 1){      // there are several reduction: reduce-reduce conflict
                    this.status |= LR0FAtables.CONFLICT_RR;
                }
            }
        }

        /**
         * Search a state that is equal to the specified one.
         *
         * @param   other the other state
         * @return  reference to the state, <code>null</code> if not found
         */

        // LR0FA
        protected LR0State search(LR0State other){
            if (this.elemNr == 0) return null;
            int hvalue = (other.hashCode() & 0x7FFFFFFF)
                % this.hdir.length;
            HashNode pr = null;
            HashNode e = null;
            LR0State d = null;
            sea: for (e = this.hdir[hvalue];
                e != null; e = e.hlink){              // scan the chain
                d = (LR0State)e;
                if (d.equals(other)) break sea;
                pr = e;
            }
            if (e == null) d = null;
            return d;
        }

        /**
         * Ensure that this FA contains an element that is equal to the specified one.
         * If it is not yet present, add it.
         * It appends the new element at the end of the ordered list.
         *
         * @param   state reference to the state to add
         * @return  <code>true</code> if the element has been inserted
         */

        // LR0FA
        protected boolean addUnique(LR0State state){
            state.sortItems();
            LR0State h = search(state);
            this.lastAdded = (LR0State)h;
            if (h != null){                         // found
                return false;
            }
            h = state;
            h.number = this.lrt.stateNr++;
            add(h);
            this.lastAdded = h;
            if (this.last == null) this.head = h;   // append to list
            else this.last.suc = h;
            this.last = h;
            h.findConflicts();                      // determine if there are conflicts
            return true;
        }

        /**
         * Deliver a new item with the specified dot.
         *
         * @param   dot dot
         * @return  item
         */

        // LR0FA
        protected Item newItem(int dot){
            return new Item(dot);
        }

        /**
         * Deliver a new item with the dot advanced with respect to the specified one.
         *
         * @param   other other item
         * @return  item
         */

        // LR0FA
        protected Item newAdvItem(Item other){
            return new Item(other.dot + 1);
        }

        /**
         * Deliver a new item with the dot advanced with respect to the specified one
         * for the specified symbol (used when there are machines).
         *
         * @param   other other item
         * @param   sym symbol
         * @return  item
         */

        // LR0FA
        protected Item newAdvItem(Item other, int sym){
            int gp = tab.grammar[other.dot];
            if (gp >= tab.ruleBase){         // final
                return null;
            }
            if (gp != sym) return null;
            return newAdvItem(other);
        }

        /**
         * Deliver a new state;
         *
         * @param   sym accessing symbol
         * @return  state
         */

        // LR0FA
        @Override
        protected LR0State newState(int sym){
            return new LR0State();
        }

        /**
         * Deliver the shifts of the specified state into the specified array.
         *
         * @param   state state
         * @param   shifts array in which the shifts are delivered
         * @param   shift array used to make the shifts unique
         * @return  number of shifts
         */

        // LR0FA
        protected int getShifts(LR0State state, int[] shifts, boolean[] shif){
            int shiftsnr = 0;
            Arrays.fill(shif,false);
            // determine the shifts, i.e. symbols for transitions
            for (Item i = state.itemList; i != null; i = i.next){ // scan its items
                int sym = tab.grammar[i.dot];
                if (sym >= tab.ruleBase){               // dot at end
                    continue;
                }
                sym = toSingleton(sym);
                if (!shif[sym]) shifts[shiftsnr++] = sym;
                shif[sym] = true;
            }
            return shiftsnr;
        }

        /**
         * Build the pilot.
         *
         * @param   startdot dot of the initial item
         */

        // LR0FA
        protected void buildPilot(int startdot){
            // build the first state
            LR0State state = newState(0);
            state.addItem(newItem(startdot));
            closure(state);                            // add predicted items, etc.
            addUnique(state);                          // add a state with these items
            // visit the initial state and the ones generated after it
            // to create all other states
            int[] shifts = new int[tab.ruleBase];           // shifts
            boolean[] shif = new boolean[tab.ruleBase];     // nts and tokens present in shifts
            for (LR0State cur = (LR0State)this.head; cur != null; cur = (LR0State)cur.suc){
                // collect the symbols that make transitions of this state
                int shiftsnr = getShifts(cur,shifts,shif);
                // there can be several items with the dot in front of the same symbol
                for (int n = 0; n < shiftsnr; n++){         // for all symbols at the dots
                    LR0State nextstate = newState(shifts[n]);
                    // add an advanced item to the new state for each origin one
                    for (Item i = cur.itemList; i != null; i = i.next){ // scan its items
                        // get the next dot for the specified shifts[n] symbol
                        Item adv = newAdvItem(i,shifts[n]);
                        if (adv != null) nextstate.addItem(adv);
                    }
                    closure(nextstate);
                    addUnique(nextstate);
                    nextstate = (LR0State)this.lastAdded;
                    cur.addTrans(new Trans(shifts[n],nextstate));
                }
            }
            this.table = new LR0State[this.lrt.stateNr];
            // build table of states
            for (State s = this.head; s != null; s = s.suc){
                this.table[s.number] = s;
            }
        }

        /**
         * Perform the closure of the list of items of the specified state, adding the items
         * predicted by them.
         *
         * @param      state state
         */

        // LR0FA
        protected void closure(LR0State state){
            int ruleBase = tab.ruleBase;
            int tokBase = tab.tokBase;
            char[] grammar = tab.grammar;
            for (Item i = state.itemList; i != null; i = i.next){
                // apply predictor
                process: {
                    int l = grammar[i.dot];
                    if (l >= ruleBase) break process;   // dot at end
                    l = toSingleton(l);
                    if (l >= tokBase) break process;    // dot at a token
                    // dot at a nonterminal
                    // add the predicted items
                    for (int rulenr = tab.ntToRule[l];  // add all its rules
                        (rulenr < tab.ruleToNt.length) &&
                        (tab.ruleToNt[rulenr] == l); rulenr++){
                        state.addItem(newItem(tab.ruleIndex[rulenr]));
                    }
                } // process
            }
        }

        /**
         * Scan the items of the specified state and store in the specified array
         * the save bits.
         *
         * @param    s state
         * @param    save array
         */

        // LR0FA
        protected void storeSaveBits(LR0State s, int[] save){
            for (Item j = s.itemList; j != null; j = j.next){
                int dot = j.dot;
                int sym = tab.grammar[dot];
                if (sym >= tab.ruleBase) continue;
                sym = toSingleton(sym);
                if (sym < tab.tokBase) continue;
                // dot in front of token
                if (boolGet(tab.storeLex,dot)){  // string to be stored
                    save[sym] |= ParserLRTables.SAVELEX;
                }
                if (boolGet(tab.storePoint,dot)){  // point to be stored
                    save[sym] |= ParserLRTables.SAVEPOS;
                }
            }
        }

        /**
         * Scan the items of the specified state and store in the specified row
         * at all places the rules to reduce.
         *
         * @param    s state
         * @param    row row
         */

        // LR0FA
        protected void storeReductions(LR0State s, IntVector[] row){
            int nrtokens = tab.numOfToks + 1;          // + 1 for eof
            for (Item j = s.itemList; j != null; j = j.next){
                int gp = tab.grammar[j.dot];
                if (gp >= tab.ruleBase){               // reduce item
                    int rulenr = gp - tab.ruleBase;
                    for (int k = 0; k < nrtokens; k++){
                        int val = ParserLRTables.ISREDUCE | rulenr;
                        row[k+tab.tokBase].add(val);
                    }
                }
            }
        }

        /**
         * Compact the LR tables in a comb vector.
         */

        // LR0FA
        protected void compactTables(){
            int[][] tabs = new int[this.lrt.stateNr][];    // tables before compression
            int nrtokens = tab.numOfToks + 1;          // + 1 for eof
            int nsym = nrtokens + tab.numOfNts;
            int[] save = new int[nsym];                // string/point saving flags
            int[] arrays = new int[100];               // overflow area for value arrays
            int i_arrays = 1;                          // 0 index reserved
            int[] arrindex = new int[nsym];            // indexes of value arrays into arrays
            IntVector[] row = new IntVector[nsym];     // row before compression
            for (int j = 0; j < row.length; j++){
                row[j] = new IntVector();
            }

            for (int i = 0; i < this.lrt.stateNr; i++){
                LR0State s = (LR0State)this.table[i];

                // build the save bits for all the tokens of this state
                Arrays.fill(save,0);
                storeSaveBits(s,save);

                // build the row for this state, with a slot for each symbol
                // containing the transitions first (shifts) and then the reductions
                for (int j = 0; j < row.length; j++){
                    row[j].clear();
                }
                // store the shifts
                if (s.transList != null){
                    for (Trans t = s.transList; t != null; t = t.next){
                        int sym = t.sym;
                        int val = t.nextState.number;
                        if (sym >= tab.tokBase) val |= save[sym];
                        row[sym].add(val);
                    }
                }
                // store the reductions
                storeReductions(s,row);

                // now we have in row the arrays, let's store the ones that have
                // more than one value
                Arrays.fill(arrindex,-1);
                int nval = 0;
                for (int j = 0; j < row.length; j++){
                    int size = row[j].size();
                    if (size == 0) continue;
                    if (size > 1){
                        if (i_arrays + size + 1 >= arrays.length){  // enlarge
                             arrays =  Arrays.copyOf(arrays,i_arrays + size + 100);
                        }
                        arrindex[j] = i_arrays;
                        arrays[i_arrays++] = size;
                        for (int k = 0; k < size; k++){
                            arrays[i_arrays++] = row[j].get(k);
                        }
                    }
                    nval++;
                }

                tabs[i] = new int[nval*2 + 1];
                int k = 0;
                tabs[i][k++] = row.length;  // length
                for (int j = 0; j < row.length; j++){
                    int size = row[j].size();
                    if (size == 0) continue;
                    if (size == 1){
                        tabs[i][k++] = j;
                        tabs[i][k++] = row[j].get(0);
                    } else {
                        tabs[i][k++] = j;
                        tabs[i][k++] = -arrindex[j];
                    }
                }
            }

            CombVector comb = new CombVector(0,
                CombVector.HOLES_ACCESSED |
                CombVector.FOLD_ROWS |
                CombVector.PAIRS);
            // comb.settrc("a");
            comb.merge(tabs);
            if (i_arrays > 1){                    // there is an overflow table
                int len = comb.tabMerged.length;
                comb.tabMerged = Arrays.copyOf(comb.tabMerged,len + i_arrays);
                System.arraycopy(arrays,0,comb.tabMerged,len,i_arrays);
                for (int i = 0; i < len; i++){
                    if (comb.tabMerged[i] < 0){   // relocate references to arrays
                        comb.tabMerged[i] -= len;
                    }
                }
            }
            ((LR0FAtables)this.lrt).LRtable = comb.tabMerged;
            ((LR0FAtables)this.lrt).LRcheck = comb.check;
            ((LR0FAtables)this.lrt).LRbase = comb.base;

            findConflicts();
            // build the table of the statuses of states
            this.lrt.stateStatus = new int[this.lrt.stateNr];
            for (State s = this.head; s != null; s = s.suc){
                this.lrt.stateStatus[s.number] = s.status;
            }
        }

        /**
         * Build the LR0FA.
         */

        // LR0FA
        @Override
        void build(){
            super.build();
            buildPilot(tab.startRule);         // build the pilot
            compactTables();                   // produce the compact tables
        }
    }

    //--------- LR(0) with lookaheads ----------------

    /**
     * A table of lookaheads (i.e. sets of terminals) that stores read-only values
     * only once.
     */

    /* The the lookaheads are computed and then added to the table and then referred
     * to from items. Then they are never changed because they can be referred from
     * several places. When there is a need to change the lookaheads of an item, new
     * objects are created, and then added to the table.
     */

    private class LAtable {

        /** The array of lookaheads. */
        private BitSet[] table;

        /** The index to the free part of the array. */
        private int length;

        /** The has directory. */
        private int[] hdir;

        /** The vector of hash links. */
        private int[] hlink;

        /**
         * Deliver a new table.
         */

        LAtable(){
            this.table = new BitSet[10];
            this.length = 1;              // 0 as index means none
            this.hdir = new int[64];
            this.hlink = new int[this.table.length];
        }
        
        /**
         * Add the specified lookahead if not already present and deliver the index.
         *
         * @param    la lookahead
         * @return   reference to the lookahead
         */

        BitSet add(BitSet la){
            BitSet res = null;
            int hfunc = la.hashCode() & (this.hdir.length - 1);
            for (int z = this.hdir[hfunc]; z != 0; z = hlink[z]){
                if (this.table[z].equals(la)){    // found
                    res = this.table[z];
                    break;
                }
            }
            if (res == null){                      // not found
                if (this.length >= this.table.length){
                    this.table = Arrays.copyOf(this.table,this.table.length<<1);
                    this.hlink = Arrays.copyOf(this.hlink,this.hlink.length<<1);
                }
                this.table[this.length] = la;
                this.hlink[this.length] = this.hdir[hfunc];
                this.hdir[hfunc] = this.length;
                this.length++;
                res = la;
            }
            return la;
        }
    }

    /**
     * The common part of LR(0) and LR(1).
     */

    abstract class LR01FA extends LR0FA implements Serializable {

        /** The table of lookaheads. */
        protected LAtable latable = new LAtable();

        /**
         * An item.
         */

        protected class LR1Item extends Item {

            /** The lookahead. */
            protected BitSet la;

            /**
             * Deliver a new item with the specified dot and lookahead.
             *
             * @param   dot dot
             * @param   la lookahead
             * @return  item
             */

            protected LR1Item(int dot, BitSet la){
                super(dot);
                this.la = latable.add(la);
            }

            /**
             * Tell if this object is equal to the specified one.
             *
             * @param   other object
             * @return  <code>true</code> if equal, <code>false</code> otherwise
             */

            @Override
            boolean equals(Item other){
                return this.dot == other.dot && ((LR1Item)this).la.equals(((LR1Item)other).la);
            }

            /**
             * Tell if this object is equivalent to the specified one when building next states.
             *
             * @param   other object
             * @return  <code>true</code> if equivalent, <code>false</code> otherwise
             */

            @Override
            boolean equivalent(Item other){
                return this.dot == other.dot;
            }

            /**
             * Deliver a string representing this object.
             *
             * @return  string
             */

            @Override
            public String toString(){
                return String.format("%s [%s,%s]",this.index,
                    tab.ruleToString(this.dot,true),tokSetToString(this.la));
            }
        }

        /**
         * A state.
         */

        protected class LR01State extends LR0State {

            /** The symbol to access this state. */
            protected int accessingSymbol;
        }

        /**
         * Deliver a new item with the specified dot.
         *
         * @param   dot dot
         * @return  item
         */

        // LR01FA
        @Override
        protected LR1Item newItem(int dot){
            return new LR1Item(dot,new BitSet());
        }

        /**
         * Deliver a new item with the specified dot and lookaheads.
         *
         * @param   dot dot
         * @param   la lookahead
         * @return  item
         */

        // LR01FA
        protected LR1Item newItem(int dot, BitSet la){
            return new LR1Item(dot,la);
        }

        /**
         * Deliver a new item with the dot advanced with respect to the specified one.
         *
         * @param   other other item
         * @return  item
         */

        // LR01FA
        @Override
        protected LR1Item newAdvItem(Item other){
            return new LR1Item(other.dot + 1,((LR1Item)other).la);
        }

        /**
         * Deliver a new item with the dot advanced with respect to the specified one
         * for the specified symbol (used when there are machines).
         *
         * @param   other other item
         * @param   sym symbol
         * @return  item
         */

        // LR01FA
        @Override
        protected LR1Item newAdvItem(Item other, int sym){
            int gp = tab.grammar[other.dot];
            if (gp >= tab.ruleBase){         // final
                return null;
            }
            gp = toSingleton(gp);
            if (gp != sym) return null;
            return newAdvItem(other);
        }

        /**
         * Scan the items of the specified state and store in the specified row
         * at the lookahead places the rules to reduce.
         *
         * @param    s state
         * @param    row row
         */

        // LR01FA
        @Override
        protected void storeReductions(LR0State s, IntVector[] row){
            for (Item j = s.itemList; j != null; j = j.next){
                BitSet la = ((LR1Item)j).la;
                if (la == null) continue;
                int gp = tab.grammar[j.dot];
                if (gp >= tab.ruleBase){                // reduce item
                    int rulenr = gp - tab.ruleBase;
                    int len = la.length();
                    // n.b. reductions that have no lookaheads are removed
                    for (int k = 0; k < len; k++){
                        if (!la.get(k)) continue;
                        int val = ParserLRTables.ISREDUCE | rulenr;
                        row[k+tab.tokBase].add(val);
                    }
                }
            }
        }

        /**
         * Deliver a string representing the specified set of terminals.
         *
         * @return  s set
         * @return  string
         */

        // LR01FA
        protected String tokSetToString(BitSet s){
            String res = "";
            if (s == null) return res;
            int len = s.length();
            for (int i = 0; i < len; i++){
                if (!s.get(i)) continue;
                if (res.length() > 0) res += " ";
                res += tab.tokLitName(i);
            }
            return "{" + res + "}";
        }

        /**
         * For each nullable nonterminal tell the number of its first acyclic nullable rule,
         * and store it in the tables.
         */

        // LR01FA
        protected void firstNcycNulRule(){
            int[] ncycNulRule = new int[tab.numOfNts];
            LALRRNFAtables lr = (LALRRNFAtables)this.lrt;
            lr.ncycNulRule = ncycNulRule;

            // then visit each rule and find the first that is nullable and
            // not cyclic, otherwise the first that is nullable
            for (int i = 0; i < tab.numOfNts; i++){
                if (!boolGet(tab.nullable,i)) continue;     // not a nullable nt
                // scan all the rules of this nt

                int prevnullable = -1;
                int firstnullable = -1;
                l: for (int j = tab.ntToRule[i]; j < tab.ruleToNt.length; j++){
                    if (tab.ruleToNt[j] != i) break;
                    if (!boolGet(tab.nullableRules,j)) continue;
                    if (firstnullable < 0){          // record the first nullable, in case
                        firstnullable = j;           // there is only one rule
                    }
                    if (boolGet(tab.rulesSomeCyc,j)){
                        continue;
                    }
                    if (prevnullable < 0){
                        prevnullable = j;
                    } else {
                        boolean res = false;                   // if new wins
                        if (tab.priLocs.length > 0){
                            int idx = tab.ruleIndex[j] + tab.ruleLen[j];
                            int pri = 0;
                            int p = Arrays.binarySearch(       // index of prio in priVals
                                tab.priLocs,idx);
                            if (p >= 0) pri = tab.priVals[p];  // priority of first rule
                            idx = tab.ruleIndex[prevnullable] + tab.ruleLen[prevnullable];
                            int opri = 0;
                            p = Arrays.binarySearch(           // index of prio in priVals
                                tab.priLocs,idx);
                            if (p >= 0) opri = tab.priVals[p]; // priority of first rule
                            if (pri > opri){
                                res = true;
                            } else if (pri == opri){
                                if (j < prevnullable) res = true;
                            }
                            if (res){
                                prevnullable = j;
                            }
                        }
                    }                        

                }
                if (prevnullable >= 0){
                    ncycNulRule[i] = prevnullable;
                } else {
                    ncycNulRule[i] = firstnullable;
                }

            }
        }

        /** 
         * Visit a nonterminal and update the set of derived nonterminals
         * which have empty left or right contexts.
         *
         * @param      h number of the nonterminal
         * @param      hd number of the nonterminal whose cyclicity need be determined
         * @param      set set of derived nonterminals
         * @return     index of lowest element added to the set
         */

        // LR01FA
        private int nullNtNull(int h, int hd, IntVector set){
            int cur = set.size();
            // scan all the rules of this nt
            l: for (int j = tab.ntToRule[h];         // scan all alternatives
                j < tab.ruleToNt.length; j++){
                if (tab.ruleToNt[j] != h) break;
                boolean lefEmpty = true;             // if head produces empty
                for (int d = tab.ruleIndex[j]; tab.grammar[d] < tab.ruleBase; d++){
                    int el = tab.grammar[d];
                    if (el >= tab.tokBase){          // terminal
                        lefEmpty = false;
                        continue l;
                    } else {                         // nonterminal
                        if (lefEmpty){
                            boolean rigEmpty = true;         // determine what follows
                            ri: for (int r = d+1; tab.grammar[r] < tab.ruleBase; r++){
                                int el1 = tab.grammar[r];
                                if (el1 >= tab.tokBase){          // terminal
                                    rigEmpty = false;
                                    continue l;
                                } else {                         // nonterminal
                                    if (!boolGet(tab.nullable,el1)){  // not a nullable nt
                                        rigEmpty = false;
                                        break ri;
                                    }
                                    break;
                                }
                            }
                            add: if (rigEmpty){
                                int i = 0;
                                for (; i < set.size(); i++){
                                    if (set.get(i) == el) break add;
                                }
                                set.add(el);                          // add it
                            }
                        }
                        // this must be done here because otherwise when we encounter
                        // the nt that we are testing for cyclicity, we would not execute the
                        // code above, which is the one that tests the cyclicity
                        if (!boolGet(tab.nullable,el)){  // not a nullable nt
                            lefEmpty = false;
                        }
                    }
                }
            } // l;
            return cur;
        }

        /**
         * Reprocess the states with the step-by-step merging algorithm to compute LALR lookaheads.
         */

        // LR01FA
        protected void buildLalrLa(){
            boolean stateChanges = true;
            while (stateChanges){
                stateChanges = false;

                for (LR0State cur = (LR0State)this.head;
                    cur != null; cur = (LR0State)cur.suc){
                    // collect the symbols that make transitions of this state
                    for (Trans tr = cur.transList; tr != null; tr = tr.next){  // scan edges
                        LR0State nextstate = newState(tr.sym);
                        // add an advanced item to the new state for each origin one
                        for (Item i = cur.itemList; i != null; i = i.next){      // scan its items
                            Item adv = newAdvItem(i,tr.sym);
                            if (adv != null) nextstate.addItem(adv);
                        }
                        closure(nextstate);
                        LR0State h = (LR0State)tr.nextState;    // state to update
                        // the items must have the same order
                        nextstate.sortItems();
                        // merge the lookaheads
                        LR1Item i1 = (LR1Item)((LR0State)h).itemList;
                        LR1Item i2 = (LR1Item)nextstate.itemList;
                        for (; i1 != null; i1 = (LR1Item)i1.next, i2 = (LR1Item)i2.next){   // scan their items
                            int length = i2.la.length();
                            for (int j = 0; j < length; j++){
                                if (!i2.la.get(j)) continue;    // lookahead not present
                                if (!i1.la.get(j)){             // new present, old not
                                    stateChanges = true;
                                    i1.la.set(j);
                                }
                            }
                        }
                    }
                }
            }
        }

        /**
         * Detect the deterministic sub-dfas, and also the ones that contain cycles.
         */

        /* The exact condition for a state to be lalr is that it is not lalr if it
         * has more than one action for a symbol (i.e. is inadequate), or it refers to
         * other states that are not lalr. This caters for states that are connected
         * in a cycle, and that are adequate: all of them are lalr.
         * The frontier states are the ones that belong to an isle and are at the border
         * of it, i.e. are reached with edges from the outside of the isle.
         * The states that have edges to frontier states are called junction states (but
         * see below).
         * The algorithm is:
         *
         *    - mark all states that are adequate as lalr
         *    - unmark the initial, final and states of cyclic nonterminals
         *    - visit all states and remove the mark from the ones that refer to others that
         *      are unmarked cycling until no changes occur.
         *    - make sure that for marked states all reduction paths lie entirely in isles
         *      except for the last state (which is then a junction state). When that is the case
         *      (see below the algorithm) mark the entrance states in the isles as frontiers.
         *    - n.b. a state can act as a junction state when it has an edge to a frontier
         *      one, and act as a non-juction state when it has an edge to a non-frontier
         *      one (it depends on the GSS).
         *
         * The reason why states with reductions for cyclic nonterminals are not part of
         * isles is that when entering an isle we want to encode the parse tree as soon as
         * a reduction is made, and not at the end of the level, and to be able to do so,
         * a nonterminal must have only one reduction, and instead cyclic nonterminals have
         * more. If that occurred, we would need to add children to their forest, and that
         * cannot be done in the forest in the final tree. This would be the case , e.g., in
         * S -> A; A -> S | a if cycles were not disallowed in isles.
         *
         * To find the frontier states, I used an algorithm that traced the reduction paths,
         * i.e. visit all the states in each isle, and take the reductions that are in them.
         * For each reduction determine its derivation states: all the states between a lookback
         * (excluded) to the state with the reduction (included) must lie in the isle (they are
         * the ones that will be on the lr stack when the reduction is done. For the lookbacks
         * for which this holds, the successor of the lookback is marked as frontier.
         * I.e. in a state there is a reduction A -> X1 X2 ... *; in all its lookback states
         * there are items ... * A ... and A -> * X1 X2 ...
         * Thus, in the lookback states a path begins with transitions starting from X1 that reach
         * the state with the reduction.
         * The problem is that for some grammars the number and length of reduction paths is
         * very big, so I used a more efficient algorithm.
         * This occurs, e.g. in freepascal.bnf where reduction paths are very long.
         * I could stop to find the lookback state as soon as a state in the leftchain goes
         * out of the isle, or I could use the iterator instead of computing all of them at once,
         * but there is a simpler solution.
         * The problem is that a pilot having several states for a star instead of one with an
         * autoloop with all the alternatives that are in the star can become very large.
         * When in a star there are several alternatives (see, e.g.. tg32.132), there cannot
         * be such an autoloop because a state here is reached always with the same symbol.
         * E.g. <S> ::= a {b|c|d}*, from state 6 there is a path to 5,4,2, each one matching one
         * of the alternatives in the star (and there are also other paths).
         * Of course, this is not present in a pilot in which states can be reached with several
         * symbols, but that makes reductions more complex, and isles too (needing a canonical
         * LR pilot perhaps).
         * Note that a LR parser does not have this problem with reductions since there is only
         * one sequence of states to reduce, and the symbols are on the stack.
         * A LR pilot has states that are always reached with the same symbol, but a ELR1 one not.
         *
         * The new algorithm then marks as frontier states the one that are reached from states
         * outside isles only with arcs due to initial items.
         * Note that an isle state could then be reached from a nonisle one and marked as
         * frontier, but it could also be reached from isle states. It is important then that
         * the LR parsing mode is done only when started from junction states.
         */

        // LR01FA
        protected void detectSubLalr(){
            boolean[] mark = new boolean[this.lrt.stateNr];

            BitSet union = new BitSet();

            // mark the adequate states
            for (int i = 0; i < this.lrt.stateNr; i++){
                LR0State st = (LR0State)this.table[i];
                // union of tokens for which there is a shift or a reduce,
                // numbering tokens from zero (only tokens can have several actions)
                union.clear();
                boolean adequate = true;
                for (Trans t = st.transList; t != null; t = t.next){
                    int sym = t.sym;
                    if (sym >= tab.tokBase){                 // token
                        union.set(sym-tab.tokBase);
                    }
                }
                for (Item it = st.itemList; it != null; it = it.next){      // scan its items
                    LR1Item item = (LR1Item)it;
                    if (!item.isFinal()) continue;                          // not a final one
                    if (item.la == null || item.la.isEmpty()) continue;
                    // n.b. reductions that have no lookaheads are not considered
                    if (union.intersects(item.la)){
                        adequate = false;
                        break;
                    }
                    union.or(item.la);
                    if (!item.isAdequate()){
                        adequate = false;
                        break;
                    }
                }
                if (isTokenAmbiguous(union)){     // set of tokens ambiguous
                    adequate = false;
                }
                if (adequate){
                    mark[i] = true;
                }
            }

            // the accepting state has a reduction to state 0 that does not appear in
            // the LALR tables because it has no lookaheads. Detect it and unmark it.
            // It is also the one that is reached with a shift for EOF.
            for (int i = 0; i < this.lrt.stateNr; i++){
                if (!mark[i]) continue;
                LR0State st = (LR0State)this.table[i];
                for (Trans t = st.transList; t != null; t = t.next){
                    if (t.sym == tab.numOfToks + tab.tokBase){       // EOF
                        mark[t.nextState.number] = false;
                        break;
                    }
                }
            }
            // unmark initial state then
            mark[0] = false;
            // unmark then the states that have reductions for cyclic nonterminals
            for (int i = 0; i < this.lrt.stateNr; i++){
                if (!mark[i]) continue;
                LR0State st = (LR0State)this.table[i];
                for (Item it = st.itemList; it != null; it = it.next){      // scan its items
                    LR1Item item = (LR1Item)it;
                    if (!item.isFinal()) continue;                          // not a final one
                    int lhs = item.lhs();
                    if (boolGet(tab.cyclic,lhs)){     // a cyclic nt
                        mark[i] = false;
                        break;
                    }
                }
            }

            // then propagate the inadequacy
            int changes = 1;
            while (changes > 0){
                changes = 0;
                // unmark states that have transitions to non-lalr states
                for (int i = 0; i < this.lrt.stateNr; i++){
                    if (!mark[i]) continue;
                    State st = this.table[i];
                    for (Trans t = st.transList; t != null; t = t.next){
                        if (!mark[t.nextState.number]){
                            mark[i] = false;
                            changes++;
                            break;
                        }
                    }
                }
            }

            // then mark the frontier states: take each state that is not in an isle
            // and has an item that is an initial one that has a next state
            // for such item that belongs to an isle. Such isle state is a frontier
            // one unless some non-isle state reaches it with an item that is not an
            // initial one. Reductions performed in LR static mode must have all the
            // states to reduce on the LR stack (and not some in the normal GSS).
            // This means that the only one state left is the junction one, and that
            // it is the one from which the derivation begun, i.e. that has the machine
            // initial state

            boolean[] nofront = new boolean[this.lrt.stateNr];
            for (int i = 0; i < this.lrt.stateNr; i++){
                if (mark[i]) continue;                       // in an isle
                LR0State st = (LR0State)this.table[i];
                for (Item it = st.itemList; it != null; it = it.next){      // scan its items
                    LR1Item item = (LR1Item)it;
                    State[] nextStates = item.toStates(st);
                    if (nextStates == null) continue;
                    for (int j = 0; j < nextStates.length; j++){
                        State next = nextStates[j];
                        if (!mark[next.number]) continue;
                        if (item.isInitial()){           // initial
                            next.status |= LALRRNFAtables.ISFRONTIER;   // tentativaly frontier
                        } else {                     // non-initial:  n_X
                            nofront[next.number] = true;
                        }
                    }
                }
            }

            // then unmark the ones that must not be frontiers
            for (int i = 0; i < this.lrt.stateNr; i++){
                State st = this.table[i];
                if ((st.status & LALRRNFAtables.ISFRONTIER) != 0 && nofront[i]){
                    st.status &= ~LALRRNFAtables.ISFRONTIER;
                }
            }

            // then mark as isles the states that are reacheable from frontier ones
            // put on the queue the frontier ones, and then find the reacheable ones from them
            State[] queue = new State[this.lrt.stateNr];
            int dp = 0;
            int qp = 0;
            for (int i = 0; i < this.lrt.stateNr; i++){
                State st = this.table[i];
                if ((st.status & LALRRNFAtables.ISFRONTIER) != 0){
                    st.status |= LALRRNFAtables.ISLALR;
                    queue[qp++] = st;
                }
            }
            while (dp != qp){                          // while queue not empty
                State s = queue[dp++];                 // dequeue
                for (Trans t = s.transList; t != null; t = t.next){       // scan edges
                    nul: {
                        for (int i = 0; i < qp; i++){
                            if (t.nextState == queue[i]) break nul;   // already visited
                        }
                        queue[qp++] = t.nextState;         // enqueue for visiting
                        t.nextState.status |= LALRRNFAtables.ISLALR;
                    }
                }
            }

            // build tables
            LALRRNFAtables lr = (LALRRNFAtables)this.lrt;
            lr.isFrontierStates = new byte[(this.lrt.stateNr +   // allocate array
                BITSBYTE - 1) / BITSBYTE];
            for (int i = 0; i < this.lrt.stateNr; i++){
                if ((this.table[i].status & LALRRNFAtables.ISFRONTIER) != 0){
                    boolSet(lr.isFrontierStates,i);
                }
            }
        }

        /**
         * Tell if the specified act set of tokens contains tokens that belong to some
         * tokens set that has in it other tokens that belong to act. I.e. if there
         * are tokens in act that trigger several actions.
         *
         * @param    act set of tokens
         * @return   <code>true<code> if there are such tokens, <code>false<code> otherwise
         */

        // LR01FA
        protected boolean isTokenAmbiguous(BitSet act){
            return false;
        }

    }

    //--------- LR(1) ----------------

    /**
     * The LR(1).
     */

    class LR1FA extends LR01FA implements Serializable {

        /**
         * A state.
         */

        protected class LR1State extends LR01State {

            /**
             * Add an item if not already present and if the grammar has group items,
             * and the item is that of a group, add the additional group item.
             *
             * @param   item item
             * @return  reference to the added item if already present and if its lookaheads changed
             */

            @Override
            protected LR1Item addItem(Item item){
                BitSet la = ((LR1Item)item).la;
                LR1Item itm1 = (LR1Item)appendItem(item);
                BitSet laAdded = new BitSet();
                if (itm1 != item){                          // item already present
                    laAdded.or(la);
                    laAdded.andNot(itm1.la);                // newly added lookaheads
                    if (!itm1.equals(la)){
                        BitSet nla = (BitSet)itm1.la.clone();   // merge lookaheads
                        nla.or(la);
                        itm1.la = latable.add(nla);
                    }
                }
                LR1Item res = itm1;
                LR1Item itm2 = null;
                gr: if ((tab.mode & ParserGen.NOGROUPS) == 0){   // has group items
                    if (itm1 != item) break gr;                  // already added both
                    int sy = tab.grammar[item.dot];
                    int p = item.dot-1;
                    int gp = tab.grammar[p];
                    if (gp >= tab.ruleBase){                // added a predicted item
                        break gr;
                    }
                    if (gp < tab.tokBase &&                 // nt
                        tab.ntKind[gp] == ParserTables.BOR){
                        if (sy < tab.ruleBase){             // old item ... . &1 &1
                            if (tab.grammar[p+2] <          // &1 &1 . &1 ...
                                tab.ruleBase) break gr;     // add extra final item
                            p++;                            // insert a &1 &1 .
                        } else {                            // old item ... &1 . &1
                            p--;                            // insert a &1 . &1
                        }
                        LR1Item gitem = newItem(p+1,la);
                        itm2 = (LR1Item)appendItem(gitem);
                        if (itm2 != gitem){                 // already present
                            BitSet l = (BitSet)gitem.la.clone();
                            l.andNot(itm2.la);              // newly added lookaheads
                            laAdded.or(l);                  // total newly added lookaheads
                            if (!itm2.equals(gitem.la)){
                                BitSet nla = (BitSet)itm2.la.clone();   // merge lookaheads
                                nla.or(gitem.la);
                                itm2.la = latable.add(nla);
                            }
                        }
                    }
                } // gr
                if (itm2 != null && itm2.index < itm1.index){
                    res = itm2;                             // the earliest, to restart processing
                }
                if (laAdded.isEmpty()) res = null;
                return res;
            }

            /**
             * Tell if there are conflicts, and in such a case mark them in the state.
             */

            @Override
            protected void findConflicts(){
                int nsym = tab.numOfToks + 1;
                for (int s = 0; s < nsym; s++){
                    int reNr = 0;
                    int shNr = 0;
                    for (Item i = this.itemList; i != null; i = i.next){
                        int gp = tab.grammar[i.dot];
                        if (gp >= tab.ruleBase){        // reduce item
                            if (((LR1Item)i).la.get(s)){
                                reNr++;
                            }
                        } else if (gp >= tab.tokBase){  // shift item
                            if (gp-tab.tokBase == s){
                                shNr++;
                            }
                        }
                    }
                    if (shNr > 0 && reNr > 0){          // there are shifts and reductions
                        // shift-reduce conflict
                        this.status |= LR0FAtables.CONFLICT_SR;
                    }
                    if (reNr > 1){                      // there are several reductions
                        // reduce-reduce conflict
                        this.status |= LR0FAtables.CONFLICT_RR;
                    }
                }
            }
        }

        /**
         * Deliver a new state;
         *
         * @param   sym accessing symbol
         * @return  state
         */

        // LR1FA
        @Override
        protected LR1State newState(int sym){
            LR1State s = new LR1State();
            s.accessingSymbol = sym;
            return s;
        }

        /**
         * Perform the closure of the list of items of the specified state, adding the items
         * predicted by them.
         *
         * @param      state state
         */

        // LR1FA
        @Override
        protected void closure(LR0State state){
            int ruleBase = tab.ruleBase;
            int tokBase = tab.tokBase;
            char[] grammar = tab.grammar;
            for (Item i = state.itemList; i != null;){
                int redo = i.index + 1;                 // item to restart processing
                Item redoitm = null;
                // apply predictor
                process: {
                    int l = grammar[i.dot];
                    if (l >= ruleBase) break process;   // dot at end
                    l = toSingleton(l);
                    if (l >= tokBase) break process;    // dot at a token
                    BitSet first = firstOf(i.dot+1,((LR1Item)i).la);
                    if ((tab.mode & ParserGen.NOGROUPS) == 0){
                        // grammar rules of repetition groups changed: add the tokens that
                        // head the body, otherwise they are missing in the right contexts
                        // since there is no item . &1 &1
                        if (tab.ntKind[l] == ParserTables.BOR){
                            first.or(tab.firsts[l]);
                        }
                    }
                    // dot at a nonterminal
                    // add the predicted items
                    for (int rulenr = tab.ntToRule[l];  // add all its rules
                        (rulenr < tab.ruleToNt.length) &&
                        (tab.ruleToNt[rulenr] == l); rulenr++){
                        Item itm = state.addItem(newItem(tab.ruleIndex[rulenr],first));
                        if (itm != null && itm.index < redo && itm.index <= i.index){
                            redo = itm.index;
                            redoitm = itm;
                        }
                    }
                } // process
                if (redo != i.index+1){
                    i = redoitm;             // restart from previous item because its LAs changed
                    continue;
                }
                i = i.next;
            }
        }

        /**
         * Compute FIRST(alpha t), where alpha is the sequence of symbols that starts
         * at the point in the rule indicated by the specified dot.
         *
         * @param      dot index in the rule
         * @param      t set of terminals
         * @return     FIRST
         */

        // LR1FA
        private BitSet firstOf(int dot, BitSet t){
            BitSet res = new BitSet();
            for (int p = dot;;p++){
                int el = tab.grammar[p];
                if (el >= tab.ruleBase){                    // end of rule
                    res.or(t);
                    break;
                }
                if (el >= tab.tokBase){                     // terminal
                    res.set(el-tab.tokBase);
                    break;
                }
                res.or(tab.firsts[el]);
                if (!boolGet(tab.nullable,el)){  // not a nullable nt
                    break;
                }
            }
            return res;
        }
    }

    //--------- LALR ----------------

    /**
     * The LALR(0).
     */

    class LALRFA extends LR01FA implements Serializable {

        /** For each nonterminal, the index in fromState and toState. */
        private int[] gotoMap;

        /** State number which a transition leads from. */
        protected int[] fromState;

        /** State number it leads to. */
        private int[] toState;

        /** The number of transitions for nonterminals. */
        private int ngotos;

        /** The follow set for each nonterminal transition. */
        private BitSet[] follows;

        /** The includes relation. */
        private int[][] includes;

        /**
         * A state.
         */

        protected class LALRState extends LR01State {

            /** The indexes of the rules that can be reduced. */
            protected IntVector rules;

            /** The lookaheads of the reductions. */
            protected BitSet[] lookaheads;

            /** The lookbacks for each rule to reduce. */
            protected IntVector[] lookbacks;

            /**
             * Tell if there are conflicts, and in such a case mark them in the state.
             */

            @Override
            protected void findConflicts(){
                // the conflicts are determined after having computed the LALR lookaheads
            }

            /**
             * Trace the reductions of this state.
             */

            void traceReductions(){
                if (this.rules != null){
                    Trc.out.printf("  reductions\n");
                    for (int i = 0; i < this.rules.length(); i++){    // trace its nexts
                        Trc.out.printf("    r%d",this.rules.get(i));
                        if (this.lookaheads != null && this.lookaheads[i] != null){
                            for (int j = 0; j < this.lookaheads[i].length(); j++){
                                if (this.lookaheads[i].get(j)){
                                    Trc.out.printf(" %s",tab.tokLitName(j));
                                }
                            }
                        }
                        Trc.out.printf("\n");
                    }
                }
            }

            /**
             * Trace this state.
             */

            @Override
            void trace(){
                super.trace();
                traceReductions();
            }
        }

        /**
         * Deliver a new state;
         *
         * @param   sym accessing symbol
         * @return  state
         */

        // LALRFA
        @Override
        protected LALRState newState(int sym){
            LALRState s = new LALRState();
            s.accessingSymbol = sym;
            return s;
        }

        /**
         * Compute the LALR lookaheads.
         */

        /* This computes the lookaheads using the Pennello's algorithm.
         * Note that it is not possible to build the LALR FA computing it as if it were a
         * LR(1) and when finding a state that is equal to a newly built one apart from
         * lookaheads, to merge it with the other one.
         * It is not possible because when a state S is added, and from a successor T is
         * added, and then later, a state U is found to be equivalent to S and merged with
         * it, the lookaheads of T would have to be recomputed.
         * There is a so-called step-by-step algorithm that keeps cycling over states recomputing
         * the lookaheads until no more changes occur.
         */

        // LALRFA
        protected void buildLalr(){
            initializeLa();              // allocate the lookahead sets for the reductions in states
            buildGotoMap();              // build the maps of transitions
            initializeFollows();         // create the follows function
            buildIncludes();             // create the includes relation
            computeFollows();            // compute the follows relation
            computeLookaheads();         // compute the lookaheads
            // at this point we have states with reductions and each reduction has a rule
            // and lookaheads for the rule. This method computes the lalr lookaheads only.
            // Here we have also the gotoMap, the fromState and toState.
        }

        /**
         * Allocate the lookbacks tables in states.
         *
         *     state
         *         reductions   rules       lookaheads        lookback
         *                    | rule nr |   | BitSet |      | gotoList  |
         *                    |   ...   |   |  ...   |      |   ...     |
         *                                    null if none    null if none
         */

        // LALRFA
        protected void initializeLa(){
            // create the containers for the lookaheads in states
            for (int i = 0; i < this.lrt.stateNr; i++){
                // for glr parsing all reductions must have lookaheads
                LALRState s = (LALRState)this.table[i];
                // set the accessing symbols
                for (Trans t = s.transList; t != null; t = t.next){
                    ((LALRState)t.nextState).accessingSymbol = t.sym;
                }
                if (i == 0){       // initial state
                    s.accessingSymbol = tab.numOfNts-1;
                }
                // determine the rules to reduce. It is possible to do without this
                // array of rules, and instead access the final or reduction items, but
                // it is much less efficient
                s.rules = null;
                for (Item itm = s.itemList; itm != null; itm = itm.next){
                    int l = tab.grammar[itm.dot];
                    if (l >= tab.ruleBase){                    // dot at end
                        if (s.rules == null) s.rules = new IntVector();
                        s.rules.add(l - tab.ruleBase);
                    }
                }
                if (s.rules != null){
                    s.lookbacks = new IntVector[s.rules.length()];
                }
            }
        }

        /**
         * Build the gotoMap storing in the entry correspoding to the nt in index the start
         * index in fromState and toState of the buckets of the transitions of each nt:
         * each bucket contains the start and end state numbers of the transitions of a same nt.
         * This allows from a (state,nt) to find the entry of the transition (accessing first
         * the bucket for the nt and then seeking the state with a binary search).
         *
         *            gotoMap        fromState    toState
         *   ntNr    |   *---|----->| state    | | state  |  } bucket of transitions of the same
         *           |   *---|,     | state    | | state  |  } nt, fromState ordered in increasing nr
         *                     `--->| state    | | state  |
         *
         * N.B. in states, the transitions for nonterminals are all before the ones for
         * terminals.
         */

        // LALRFA
        private void buildGotoMap(){
            this.gotoMap = new int[tab.numOfNts + 1];
            int[] tempMap = new int[tab.numOfNts + 1];

            this.ngotos = 0;
            // determine how many transitions for each nt
            for (int j = 0; j < this.lrt.stateNr; j++){
                State s = this.table[j];
                for (Trans t = s.transList; t != null; t = t.next){
                    LALRState ns = (LALRState)t.nextState;
                    if (ns.accessingSymbol >= tab.tokBase) break;  // end or nt transitions
                    this.ngotos++;
                    this.gotoMap[ns.accessingSymbol]++;
                }
            }
            int k = 0;
            for (int i = 0; i < tab.numOfNts; i++){
                tempMap[i] = k;                     // set indexes to buckets in fromState and toState
                k += this.gotoMap[i];
            }
            for (int i = 0; i < tab.numOfNts; i++){
                this.gotoMap[i] = tempMap[i];
            }
            this.gotoMap[tab.numOfNts] = this.ngotos;
            tempMap[tab.numOfNts] = this.ngotos;

            this.fromState = new int[this.ngotos];
            this.toState = new int[this.ngotos];

            for (int j = 0; j < this.lrt.stateNr; j++){  // distributes transitions in buckets
                State s = this.table[j];
                for (Trans t = s.transList; t != null; t = t.next){
                    LALRState ns = (LALRState)t.nextState;
                    if (ns.accessingSymbol >= tab.tokBase) break;  // end or nt transitions
                    k = tempMap[ns.accessingSymbol]++;
                    this.fromState[k] = j;
                    this.toState[k] = ns.number;
                }
            }
        }

        /**
         * Map a state/symbol pair into the number of the transition (index in
         * fromState, etc.).
         *
         * @param   state state number
         * @param   symbol nt number
         * @return  index
         */

        // LALRFA
        protected int mapToGoto(int state, int symbol){
            int low = this.gotoMap[symbol];
            int high = this.gotoMap[symbol + 1] - 1;
            for (;;){
                int middle = (low + high) / 2;
                int s = this.fromState[middle];
                if (s == state){
                    return middle;
                } else if (s < state){
                    low = middle + 1;
                } else {
                    high = middle - 1;
                }
            }
        }

        /**
         * Taken a transition T from a state s1 labelled with a nonterminal N to a state s2,
         * follows[T] is the set of tokens that will first be recognised in s2 or by any state
         * that is reached from s2 with transitions of nullable nonterminals. In other words,
         * we can make that transition only if the next unexpended token is in follows[T].
         * N.B. follows has as domain the transitions, and codomain sets of tokens.
         * To build them, for each transition the set of the other transitions labelled
         * with nullable nonterminals outgoing from the transition next state is build
         * (the "reads" relation) and then its closure made collecting all tokens of the
         * transitions of all states reached.
         * I.e. it takes a transition, and the tokens (labelling the transitions) of its
         * next state. Then it follows all the transitions with nullable nonterminals from
         * that next state collecting the tokens, and repeating this until no more states
         * are reached.
         */

        // LALRFA
        private void initializeFollows(){
            int nrtokens = tab.numOfToks + 1;    // + 1 for eof
            int[][] reads = new int[this.ngotos][];
            int[] edges = new int[this.ngotos];
            int nedges = 0;
            this.follows = new BitSet[this.ngotos];

            for (int i = 0; i < this.ngotos; i++){             // for all transitions
                this.follows[i] = new BitSet(nrtokens);        // allocate follows bitset

                int stateno = this.toState[i];
                State tostate = this.table[stateno];
                if (tostate.transList == null) continue;

                // build the reads relation linking the current transition with
                // the ones on nullable nt outgoing from the transition state.
                // Initialize the follows function for the current transition with
                // the tokens outgoing from the transition next state

                // collect the transitions on nullable nonterminals in edges,
                // and the tokens of the ones labelled with tokens in follows

                for (Trans t = tostate.transList; t != null; t = t.next){
                    int sym = ((LALRState)t.nextState).accessingSymbol;
                    if (sym < tab.tokBase){                             // nonterminal
                        if (boolGet(tab.nullable,sym)){                 // set of transitions outgoing
                            edges[nedges++] = mapToGoto(stateno,sym);   // from fromState for nullable
                        }
                    } else {
                        this.follows[i].set(sym - tab.tokBase); // set of tokens labelling outgoing edges of fromState
                    }
                }
                if (nedges > 0){
                    reads[i] = Arrays.copyOf(edges,nedges);
                    nedges = 0;
                }
            }

            // "reads" maps each transition to the others hopping over the ones
            // for the empty string, "follows" maps each nt transition to the tokens that
            // will be matched after it. Making the transitive closure we map each transition
            // to the tokens that will be matched after having made the transition

            digraph(reads,this.follows,false);            // transitive closure
        }

        /**
         * Compute the transitive closure of the specified function on the
         * specified relation. The relation is defined over a set X and for
         * each element x tells what elements x is linked to. The function
         * is defined on X and delivers for each x a set of values (belonging
         * to another set S). The resulting function is (F' is the input one):
         *
         *    F(x) = F'(x) union {F(y) | xRy}
         *
         * i.e. F'(x) is unioned with all the F'(y) for all the y that are linked
         * to x in the relation directly or indirectly.
         *
         * @param   r relation
         * @param   function function
         * @param   tracefoll <code>true</code> true to trace the follows sets, <code>false</code> otherwise
         */

        // LALRFA
        private void digraph(int[][] r, BitSet[] function, boolean tracefoll){
            int size = r.length;
            int infinity = size + 2;
            int[] index = new int[size + 1];
            int[] stack = new int[size + 1];
            int top = 0;
            for (int i = 0; i < size; i++){     // visit all vertices
                if (index[i] == 0 && r[i] != null){
                    top = traverse(i,index,stack,top,infinity,function,r,tracefoll);
                }
            }
        }

        /**
         * For all the values linked to the specified element compute the transitive
         * closure of the function
         *
         * @param   i element
         * @param   r relation
         * @param   function function
         * @param   tracefoll <code>true</code> true to trace the follows sets, <code>false</code> otherwise
         * @return  index
         */

        // LALRFA
        private int traverse(int i, int[] index, int[] stack, int top,
            int infinity, BitSet[] f, int[][] r, boolean tracefoll){
            stack[++top] = i;
            int height = top;
            index[i] = top;
            int[] ri = r[i];
            if (ri != null){                                 // has linked elements
                for (int j = 0; j < ri.length; j++){         // visit them all
                    if (index[ri[j]] == 0){                  // not yet visited
                        top = traverse(ri[j],index,stack,top,infinity,f,r,tracefoll);
                    }
                    if (index[i] > index[ri[j]]){            // cycle, remove it because visited
                        index[i] = index[ri[j]];
                    }
                    f[i].or(f[ri[j]]);                       // unite with the function of the relation
                }
            }

            if (index[i] == height){                         // visit back the cycle just ended
                for (;;){
                    int j = stack[top--];
                    index[j] = infinity;
                    if (i == j) break;
                    f[j].or(f[i]);                           // unite with the first in cycle
                }
            }
            return top;
        }

        /**
         * Build the relation includes, and add lookback edges. The relation "includes" is
         * defined as follows:
         *
         *     (p,A) includes (q,B) iff B -> beta A gamma, gamma =*> epsilon and q -beta-> p
         *
         * The lookback edges are links from the reductions to the states that predicted them.
         * I.e. a state that has an item A -> alpha . has a reduction for it and a lookback to
         * the state that contains A -> . alpha (actually the lookback contains the index of
         * the transition of that state for A since that state contains also an item
         * B -> beta . A gamma).
         *
         * In a normal (non-split) dfa, a state that has a transition for nonterminal A has
         * also a predicted item for A.
         * In a split dfa, a state that has a transition for A has the predicted item in the
         * associated nonkernel state. This holds also for the initial state.
         * Note that also nonkernel states can have transitions for nonterminals.
         */

        // LALRFA
        private void buildIncludes(){
            int[] edge = new int[this.ngotos];
            LALRFAtables lr = (LALRFAtables)this.lrt;
            lr.longestRule = 0;
            for (int i = 0; i < tab.ruleLen.length; i++){
                if (tab.ruleLen[i] > lr.longestRule) lr.longestRule = tab.ruleLen[i];
            }
            int[] moves = new int[lr.longestRule + 1];    // +1 for the initial one
            this.includes = new int[this.ngotos][];

            for (int i = 0; i < this.ngotos; i++){
                int nedges = 0;
                // get the nt of this transition
                int symbol = ((LALRState)this.table[this.toState[i]]).accessingSymbol;
                // (q,B) is here the current transition, (fromState,sym)
                // fromState (or its nonkernel one) contains the predicted items
                // for all rules of B. Take each of them, and perform all moves till the
                // state with the corresponding final item is found.
                // Then collect all the transitions for all nullable nts and the last
                // non-nullable one in the moves and link them in the relation with (q,B).
                for (int rulenr = tab.ntToRule[symbol];      // visit the rules of the nt of the transition
                    (rulenr < tab.ruleToNt.length) &&
                    (tab.ruleToNt[rulenr] == symbol); rulenr++){
                    nedges = buildMovesLookbacks(rulenr,i,moves,edge,nedges);
                }
                // build includes[i] as the list of all transition nr's for all the nullables at
                // the end of all alternatives of the nt that labels the toState of transition i
                if (nedges != 0){
                    this.includes[i] = Arrays.copyOf(edge,nedges);
                }
            }

            // transpose it: includes becomes an array indexed with transition nr's, reporting
            // for each one the transition numbers of the nt's in which it occurs at the nullable
            // tails of its rules. E.g. if there is an A -> alpha B or A -> alpha B beta, with
            // nullable beta, then includes(B) contains A. Actually, this is not done for
            // nonterminals, but for each transition.
            this.includes = transpose(this.includes);
        }

        /**
         * Build the moves and the lookbacks.
         *
         * @param   rulenr rule number
         * @param   i state number
         * @param   moves array of transitions
         * @param   edge array of edges
         * @param   nedges number of edges in it
         * @return  updated nedges
         */

        // LALRFA
        protected int buildMovesLookbacks(int rulenr, int i, int[] moves, int[] edge, int nedges){
            boolean done = false;
            int length = 1;
            LALRState s = (LALRState)this.table[this.fromState[i]];
            moves[0] = s.number;

            // being this rule R -> X0 X1 ...
            // build moves: fromState state(X0) state(X1) .. states accessed by X0, X1 ...
            int p;
            for (p = tab.ruleIndex[rulenr];                   // visit the rule
                tab.grammar[p] < tab.ruleBase; p++){

                int sym = tab.grammar[p];
                // find the state reached with sym
                for (Trans t = s.transList; t != null; t = t.next){
                    if (t.sym == sym){
                        s = (LALRState)t.nextState;
                        break;
                    }
                }
                moves[length++] = s.number;
            }

            int redno = reductionFind(s,rulenr);
            addLookback(s,redno,i);

            // now visit the rule from the end backwards: stop when visited or at the
            // first token encountered, or at the first nt N that is not nullable, and
            // for N and all following nt's collect in edges the indexes of their
            // transitions:
            //     moves: fromState, state(X0),..., state(Xn-3), state(Xn-2), state(Xn-1) 
            //     edge:  trans(state(Xn-1),Xn-1), trans(state(Xn-2),Xn-2), ...
            // Collect in edges the similar transitions of the other rules of this nt.
            // These are the nt's that must get the follows of symbol
            length--;
            done = false;
            while (!done){
                done = true;
                // every rule in the grammar has a sentinel before it, so it is
                // safe to scan rules backwards stopping at sentinels
                p--;
                int sym = tab.grammar[p];
                if (sym < tab.tokBase){              // nonterminal
                    edge[nedges++] = mapToGoto(moves[--length],sym);
                    if (boolGet(tab.nullable,sym)){
                        done = false;
                    }
                }
            }
            return nedges;
        }

        /**
         * Deliver a string representing the transition from the fromState at
         * the specified index.
         *
         * @param   t index
         * @return  string
         */

        // LALRFA
        private String transToString(int t){
            return "(" + this.fromState[t] + "," +
                tab.ntLitName(((LALRState)this.table[this.toState[t]]).accessingSymbol) + ")";
        }

        /**
         * Find the reduction for the specified rule in the specified state.
         *
         * @param   s state
         * @param   r rule
         * @return  index, -1 if not found
         */

        // LALRFA
        private int reductionFind(LALRState s, int r){
            if (s.rules == null) return -1;
            for (int i = 0; i < s.rules.length(); i++){
                if (s.rules.get(i) == r){
                    return i;
                }
            }
            return -1;
        }

        /**
         * Add a lookback link for the specified reduction to the transition that the
         * DFA will do after having gone back the the state that originated it.
         *
         * @param   s state
         * @param   r reduction number
         * @param   gotonr transition
         */

        // LALRFA
        protected void addLookback(LALRState s, int r, int gotonr){
            if (s.lookbacks[r] == null) s.lookbacks[r] = new IntVector();
            s.lookbacks[r].add(gotonr);
        }

        /**
         * Return the transpose of the specified relations.
         *
         * @param   r relation
         * @return  transpose
         */

        // LALRFA
        private int[][] transpose(int[][] r){
            // the lengths of rows of the transposed
            int[] nedges = new int[r.length];
            // count the lengths of rows of the transposed
            for (int i = 0; i < r.length; i++){
                if (r[i] != null){
                    for (int j = 0; j < r[i].length; j++){
                        nedges[r[i][j]]++;
                    }
                }
            }

            // matrix to hold the result
            int[][] newR = new int[r.length][];
            for (int i = 0; i < r.length; i++){
                if (nedges[i] > 0){
                    newR[i] = new int[nedges[i]];
                }
            }
            // number of elements in the rows of the result
            int[] end = new int[r.length];

            // transpose
            for (int i = 0; i < r.length; i++){
                if (r[i] != null){
                    for (int j = 0; j < r[i].length; j++){
                        int idx = r[i][j];
                        newR[idx][end[idx]++] = i;
                    }
                }
            }

            return newR;
        }

        /**
         * Compute the follows relation.
         */

        // LALRFA
        private void computeFollows(){
            digraph(this.includes,this.follows,true);
            this.includes = null;
        }

        /**
         * Compute the lookaheads.
         */

        // LALRFA
        private void computeLookaheads(){
            int nrtokens = tab.numOfToks + 1;    // + 1 for eof
            for (int i = 0; i < this.lrt.stateNr; i++){
                LALRState s = (LALRState)this.table[i];
                IntVector[] lists = s.lookbacks;
                if (lists == null) continue;          // no reductions in this state
                s.lookaheads = new BitSet[lists.length];
                for (int j = 0; j < lists.length; j++){
                    s.lookaheads[j] = new BitSet(nrtokens);
                    if (lists[j] != null){
                        for (int sp = 0; sp < lists[j].length(); sp++){
                            int value = lists[j].get(sp);
                            s.lookaheads[j].or(this.follows[value]);
                        }
                    }
                }
            }
            this.follows = null;
        }

        /**
         * Scan the rules of the specified state and store in the specified row
         * of the compressed table the reductions at the indexes corresponding to their
         * lookaheads.
         *
         * @param    s state
         * @param    row row
         */

        // LALRFA
        @Override
        protected void storeReductions(LR0State s, IntVector[] row){
            LALRState st = (LALRState)s;
            if (st.rules != null){
                for (int j = 0; j < st.rules.length(); j++){
                    if (st.lookaheads[j] == null) continue;
                    int len = st.lookaheads[j].length();
                    // n.b. reductions that have no lookaheads are removed
                    for (int k = 0; k < len; k++){
                        if (!st.lookaheads[j].get(k)) continue;
                        int val = ParserLRTables.ISREDUCE | st.rules.get(j);
                        row[k+tab.tokBase].add(val);
                    }
                }
            }
        }

        /**
         * Mark the states that have conflicts.
         */

        // LALRFA
        @Override
        protected void findConflicts(){
            int nsym = tab.numOfToks + 1 + tab.numOfNts;
            LR0FAtables lr = (LR0FAtables)this.lrt;
            for (int i = 0; i < this.lrt.stateNr; i++){
                LALRState s = (LALRState)this.table[i];
                for (int j = 0; j < nsym; j++){
                    int bas = lr.LRbase[i];
                    int start = bas+j;
                    int ele = lr.LRcheck[start] == bas ? lr.LRtable[start] : 0;
                    if (ele == 0) continue;
                    if (ele < 0){            // array of actions
                        ele = -ele;
                        int len = lr.LRtable[ele++];
                        start = ele;
                        int shfnr = 0;
                        int rednr = 0;
                        for (int k = 0; k < len; k++){
                            int val = lr.LRtable[start+k];
                            if (val >= ParserLRTables.ISREDUCE){
                                rednr++;
                            } else {
                                shfnr++;
                            }
                        }
                        if (shfnr > 0 && rednr > 0){        // there are shifts
                            // shift-reduce conflict
                            s.status |= LR0FAtables.CONFLICT_SR;
                        }
                        if (rednr > 1){      // there are several reduction: reduce-reduce conflict
                            s.status |= LR0FAtables.CONFLICT_RR;
                        }
                    }
                }
            }
        }

        /**
         * Build the LALRFA.
         */

        // LALRFA
        @Override
        void build(){
            buildPilot(tab.startRule);         // build the pilot
            buildLalr();                       // build the lookaheads
            compactTables();                   // produce the compact tables
        }
    }

    //--------- LALRRN ----------------

    /**
     * The Right-nulled FA based on LALR(0).
     */

    class LALRRNFA extends LALRFA implements Serializable {

        /**
         * A state.
         */

        protected class LALRRNState extends LALRState {

            /** The number of elements before the rn tail of each rule. */
            protected IntVector beforeDots;

            /**
             * Trace the reductions of this state.
             */

            @Override
            void traceReductions(){
                if (this.rules != null){
                    Trc.out.printf("  reductions\n");
                    for (int i = 0; i < this.rules.length(); i++){    // trace its nexts
                        Trc.out.printf("    r%d,%d",
                            this.rules.get(i),this.beforeDots.get(i));
                        if (this.lookaheads != null && this.lookaheads[i] != null){
                            for (int j = 0; j < this.lookaheads[i].length(); j++){
                                if (this.lookaheads[i].get(j)){
                                    Trc.out.printf(" %s",tab.tokLitName(j));
                                }
                            }
                        }
                        Trc.out.printf("\n");
                    }
                }
            }
        }

        /**
         * Deliver a new state;
         *
         * @param   sym accessing symbol
         * @return  state
         */

        // LALRRN
        @Override
        protected LALRRNState newState(int sym){
            LALRRNState s = new LALRRNState();
            s.accessingSymbol = sym;
            return s;
        }

        /**
         * Allocate the lookbacks tables in states.
         *
         *     state
         *         reductions   rules       lookaheads        lookback
         *                    | rule nr |   | BitSet |      | gotoList  |
         *                    |   ...   |   |  ...   |      |   ...     |
         *                                    null if none    null if none
         */

        // LALRRN
        @Override
        protected void initializeLa(){
            // create the containers for the lookaheads in states
            for (int i = 0; i < this.lrt.stateNr; i++){
                // for glr parsing all reductions must have lookaheads
                LALRRNState s = (LALRRNState)this.table[i];
                // set the accessing symbols
                for (Trans t = s.transList; t != null; t = t.next){
                    ((LALRState)t.nextState).accessingSymbol = t.sym;
                }
                if (i == 0){       // initial state
                    s.accessingSymbol = tab.numOfNts-1;
                }
                // determine the rules to reduce. It is possible to do without this
                // array of rules, and instead access the final or reduction items, but
                // it is much less efficient
                s.rules = null;
                scan: for (Item itm = s.itemList; itm != null; itm = itm.next){
                    int beforeDot = 0;
                    int rno = 0;
                    // find the end of the item to compute the number of elements
                    // before the dot and at the same time if after the dot there is
                    // a rn part
                    for (int j = itm.dot;; j++){
                        int el = tab.grammar[j];
                        if (el >= tab.ruleBase){                // end of rule found
                            rno = el - tab.ruleBase;
                            int rlen = tab.ruleLen[rno];
                            beforeDot = rlen - (j - itm.dot);
                            break;
                        }
                        if (el >= tab.tokBase ||                // token, or not nullable nt
                            !boolGet(tab.nullable,el)){
                            continue scan;
                        }
                    }
                    if (s.rules == null){
                        s.rules = new IntVector();
                        s.beforeDots = new IntVector();;
                    }
                    s.rules.add(rno);
                    s.beforeDots.add(beforeDot);
                }
                if (s.rules != null){
                    s.lookbacks = new IntVector[s.rules.length()];
                }
            }
        }

        /**
         * Build the moves and the lookbacks.
         *
         * @param   rulenr rule number
         * @param   i state number
         * @param   moves array of transitions
         * @param   edge array of edges
         * @param   nedges number of edges in it
         * @return  updated nedges
         */

        // LALRRN
        @Override
        protected int buildMovesLookbacks(int rulenr, int i, int[] moves, int[] edge, int nedges){
            boolean done = false;
            int length = 1;
            LALRRNState s = (LALRRNState)this.table[this.fromState[i]];
            moves[0] = s.number;

            // being this rule R -> X0 X1 ...
            // build moves: fromState state(X0) state(X1) .. states accessed by X0, X1 ...
            int bef = 0;
            int p;
            for (p = tab.ruleIndex[rulenr];                   // visit the rule
                tab.grammar[p] < tab.ruleBase; p++){

                // to build an rn table here we need to know if each state
                // has a reduction for the dotted rule at hand.
                // If it has, it means that the rule had an rn part (after
                // a number of elements that is equal to the ones visited here).

                int redno = reductionFind(s,rulenr,bef);
                if (redno >= 0){
                    addLookback(s,redno,i);
                }

                int sym = tab.grammar[p];
                // find the state reached with sym
                for (Trans t = s.transList; t != null; t = t.next){
                    if (t.sym == sym){
                        s = (LALRRNState)t.nextState;
                        break;
                    }
                }
                moves[length++] = s.number;
                bef++;
            }

            int redno = reductionFind((LALRRNState)s,rulenr,bef);
            addLookback(s,redno,i);

            // now visit the rule from the end backwards: stop when visited or at the
            // first token encountered, or at the first nt N that is not nullable, and
            // for N and all following nt's collect in edges the indexes of their
            // transitions:
            //     moves: fromState, state(X0),..., state(Xn-3), state(Xn-2), state(Xn-1) 
            //     edge:  trans(state(Xn-1),Xn-1), trans(state(Xn-2),Xn-2), ...
            // Collect in edges the similar transitions of the other rules of this nt.
            // These are the nt's that must get the follows of symbol
            length--;
            done = false;
            while (!done){
                done = true;
                // every rule in the grammar has a sentinel before it, so it is
                // safe to scan rules backwards stopping at sentinels
                p--;
                int sym = tab.grammar[p];
                if (sym < tab.tokBase){              // nonterminal
                    edge[nedges++] = mapToGoto(moves[--length],sym);
                    if (boolGet(tab.nullable,sym)){
                        done = false;
                    }
                }
            }
            return nedges;
        }

        /**
         * Find the reduction for the specified rule in the specified state, and that has
         * the specified number of symbols before the dot if generating rn-tables.
         *
         * @param   s state
         * @param   r rule
         * @param   bef symbols before the dot
         * @return  index, -1 if not found
         */

        // LALRRN
        private int reductionFind(LALRRNState s, int r, int bef){
            if (s.rules == null) return -1;
            for (int i = 0; i < s.rules.length(); i++){
                if (s.rules.get(i) == r && s.beforeDots.get(i) == bef){
                    return i;
                }
            }
            return -1;
        }

        /**
         * Scan the rules of the specified state and store in the specified row
         * of the compressed table the reductions at the indexes corresponding to their
         * lookaheads.
         *
         * @param    s state
         * @param    row row
         */

        // LALRRN
        @Override
        protected void storeReductions(LR0State s, IntVector[] row){
            LALRState st = (LALRState)s;
            if (st.rules != null){
                LALRRNFAtables lr = (LALRRNFAtables)this.lrt;
                if (lr.lr1kind < 2){
                    for (int j = 0; j < st.rules.length(); j++){
                        if (st.lookaheads[j] == null) continue;
                        int len = st.lookaheads[j].length();
                        // n.b. reductions that have no lookaheads are removed
                        for (int k = 0; k < len; k++){
                            if (!st.lookaheads[j].get(k)) continue;
                            int val = ParserLRTables.ISREDUCE | st.rules.get(j);
                            if (st.getClass() == LALRRNState.class){   // not one of canonical
                                val |= ((LALRRNState)st).beforeDots.get(j) << ParserLRTables.BEFSHIFTS;
                            }
                            row[k+tab.tokBase].add(val);
                        }
                    }
                } else {
                    // store first the normal reductions and then the rn ones to make lr static faster
                    // i.e. on isle states the only reduction to make in lr static mode is the non-lr
                    // one, and it is the first
                    for (int p = 0; p < 2; p++){
                        for (int j = 0; j < st.rules.length(); j++){
                            if (st.lookaheads[j] == null) continue;
                            if (p == 0 &&
                                (((LALRRNState)st).beforeDots.get(j) !=
                                tab.ruleLen[st.rules.get(j)])) continue;   // rn reduction
                            if (p == 1 &&
                                (((LALRRNState)st).beforeDots.get(j) ==
                                tab.ruleLen[st.rules.get(j)])) continue;   // not rn reduction
                            int len = st.lookaheads[j].length();
                            // n.b. reductions that have no lookaheads are removed
                            for (int k = 0; k < len; k++){
                                if (!st.lookaheads[j].get(k)) continue;
                                int val = ParserLRTables.ISREDUCE | st.rules.get(j);
                                if (st.getClass() == LALRRNState.class){   // not one of canonical
                                    val |= ((LALRRNState)st).beforeDots.get(j) << ParserLRTables.BEFSHIFTS;
                                }
                                row[k+tab.tokBase].add(val);
                            }
                        }
                    }
                }
            }
        }

        /**
         * Build a dfa containing canonical isles (i.e. non-split). Then pair its states with
         * the ones of the current dfa, and add the isles to it.
         */

        // LALRRN
        protected void buildSubDfas(){
            // build the tables for a canonical DFA (but do not compress them);
            LALRFA canon = new LALRFA();
            ParserLRTables lrt = (ParserLRTables)tab.pilot;
            canon.lrt = lrt.new LALRFAtables();
            canon.buildPilot(tab.startRule);         // build the pilot
            canon.buildLalr();                      // build the lookaheads
            // the canonical one can have conflicts, so detect the deterministic isles
            ((LALRRNFA)canon).setLookaheads();
            canon.detectSubLalr();
            // then pair the states
            // build the hash tables of the canonical one using only kernel items

            int[] hdir = new int[canon.lrt.stateNr];
            int[] hlink = new int[canon.lrt.stateNr];
            for (int i = 0; i < canon.lrt.stateNr; i++){
                LALRState st = (LALRState)canon.table[i];
                int hfunct = 0;
                for (Item j = st.itemList; j != null; j = j.next){
                    hfunct += j.dot;
                }
                hfunct &= hdir.length - 1;
                int z = st.number;
                hlink[z] = hdir[hfunct];    // not found, prepend
                hdir[hfunct] = z;
            }
            State[] map = new State[this.lrt.stateNr];
            int nrfrontier = 0;
            for (int i = 0; i < this.lrt.stateNr; i++){
                LALRState st = (LALRState)this.table[i];
                int hfunct = 0;
                for (Item j = st.itemList; j != null; j = j.next){
                    hfunct += j.dot;
                }
                hfunct &= hdir.length - 1;
                LALRState found = null;
                pa: for (int z = hdir[hfunct]; z != 0; z = hlink[z]){
                    Item i1 = st.itemList;
                    Item i2 = ((LALRState)canon.table[z]).itemList;
                    boolean equal = true;
                    for (; i1 != null && i2 != null; i1 = i1.next, i2 = i2.next){
                        if (!i1.equals(i2)) equal =  false;
                    }
                    if (i1 != null || i2 != null) equal =  false;
                    if (equal){
                        LALRState cst = (LALRState)canon.table[z];
                        // check the lookaheads
                        if (st.rules != null){
                            for (int r = 0; r < st.rules.size(); r++){
                                boolean rulefound = false;
                                for (int c = 0; c < cst.rules.size(); c++){
                                    if (st.rules.get(r) == cst.rules.get(c)){      // found the rule
                                        BitSet b = new BitSet();
                                        b.or(st.lookaheads[r]);
                                        b.andNot(cst.lookaheads[c]);
                                        if (!b.isEmpty()) continue pa;
                                        rulefound = true;
                                    }
                                }
                                if (!rulefound) continue pa;
                            }
                        }
                        found = cst;
                        break;
                    }
                }
                if (found != null){
                }
                if (found != null && ((found.status & LALRRNFAtables.ISFRONTIER) != 0)){
                    map[i] = found;
                    st.status |= LALRRNFAtables.ISFRONTIER | LALRRNFAtables.ISLALR;
                    nrfrontier++;
                }
            }

            // now copy into the current tables the lalr states of the canon, relocating them,
            // compute the number of states of the isles in canon (some isle might not be
            // used, but to discover them there is a need to color the isles starting from
            // the frontier states mapped above)
            // The states in the main dfa that become unreacheable could be removed, but
            // the final, production version does not use the canonical DFA, so it has
            // no unreacheable states
            int nlalr = 0;
            for (int i = 0; i < canon.lrt.stateNr; i++){
                State st = canon.table[i];
                if ((st.status & LALRRNFAtables.ISLALR) != 0) nlalr++;
            }
            this.table = Arrays.copyOf(this.table,this.table.length+nlalr);
            nlalr = this.lrt.stateNr;
            for (int i = 0; i < canon.lrt.stateNr; i++){
                State st = canon.table[i];
                if ((st.status & LALRRNFAtables.ISLALR) == 0) continue;
                this.table[nlalr-1].suc = st;     // append to list
                st.suc = null;
                this.table[nlalr] = st;
                st.number = nlalr;
                nlalr++;
            }
            // create then the map of frontier states
            LALRRNFAtables lr = (LALRRNFAtables)this.lrt;
            lr.frontierMap = new int[lr.stateNr];
            for (int i = 0; i < map.length; i++){
                if (map[i] == null) continue;
                lr.frontierMap[i] = map[i].number;
            }
            lr.stateNr = this.table.length;
            lr.isFrontierStates = newBits(lr.stateNr);   // allocate array
            for (int i = 0; i < lr.stateNr; i++){
                if ((this.table[i].status & LALRRNFAtables.ISFRONTIER) != 0){
                    boolSet(lr.isFrontierStates,i);
                }
            }

        }

        /** 
         * Set the lookaheads of the final items taking them from the reductions.
         */

        // LALRRN
        void setLookaheads(){
            for (int i = 0; i < this.table.length; i++){
                LALRState st = (LALRState)table[i];
                if (st.rules == null) continue;
                for (Item k = st.itemList; k != null; k = k.next){
                    int dot = k.dot;
                    int sym = tab.grammar[dot];
                    if (sym < tab.ruleBase) continue;     // not final
                    int rule = sym - tab.ruleBase;
                    for (int r = 0; r < st.rules.length(); r++){    // find the index of the rule
                        if (st.rules.get(r) == rule){
                            ((LR1Item)k).la = st.lookaheads[r];
                            break;
                        }
                    }
                }
            }
        }

        /**
         * Build the LALRRNFA.
         */

        // LALRRN
        @Override
        void build(){
            LALRRNFAtables lr = (LALRRNFAtables)this.lrt;
            if (options != null && options.length() > 0){
                lr.lr1kind = options.charAt(0) - '0';
            }
            buildPilot(tab.startRule);         // build the pilot
            buildLalr();                       // build the lookaheads
            if (lr.lr1kind == 1){
                buildSubDfas();
            } else if (lr.lr1kind >= 2){       // isles without canonical DFA
                setLookaheads();               // to use detectSubLalr
                detectSubLalr();
                lr.isFrontierStates = null;
            }
            compactTables();                   // produce the compact tables

            // build table of accessing symbols
            lr.accessingSym = new int[lr.stateNr];
            for (int i = 0; i < lr.stateNr; i++){
                LALRState s = (LALRState)this.table[i];
                lr.accessingSym[s.number] = s.accessingSymbol;
            }

            if (lr.lr1kind == 3){
                firstNcycNulRule();            // determine first non-cyclic rule for nullable nts
            }

        }
    }

    //--------- ELR1 ----------------

    /*
     * This is the ELR(1) DFA.
     * ELR(1) has a LR(1) pilot, but it could have instead a LALR one.
     *
     * In items, the dot is here a machine state, but apart from that, the items are actually
     * the same as the LR1Items.
     * There is a FA for each nonterminal or rule, but here they are keep all together in a
     * same NFA and DFA, with multiple initial states.
     *
     * The ELR1 is also the base class for ELR1+, which are the tables for the elr1+ parser.
     * Actually there are several variants of them.
     * There are two configuration parameters that apply to all of them:
     *
     *       - machinesNts:   whether there is only one machine for each nonterminal, or one for
     *                        each rule
     *       - enclosingRule: whether there is a machine for the enclosing rule or not
     *
     * They are set in each kind of FA.
     * ELR(1) is the FA of Crespi's book, i.e. the one that does not have leftpointers in pilot
     * items.
     */

    /**
     * The machines NFA.
     */

    class NFA extends LR0FA {

        /** The nonterminal of the machine currently built. */
        private int nfaCurAccSym;

        /** The initial state of the machine currently built. */
        private NFAState nfaCurInit;

        /** The label on a transition that has no symbol. */
        protected int epsilonEdge;

        /** The reference to the NFA machines (initial state) for each nonterminal. */
        protected NFAState[] ntToStartStates;

        /**
         * An item.
         */

        protected class NFAItem extends Item {

            /**
             * Deliver a new item with the specified dot.
             *
             * @param   dot dot
             * @return  item
             */

            protected NFAItem(int dot){
                super(dot);
            }

            /**
             * Deliver a string representing this object.
             *
             * @return  string
             */

            @Override
            public String toString(){
                return String.format("%s [%s]",this.index,tab.ruleToString(this.dot,true));
            }
        }

        /**
         * A state.
         */

        protected class NFAState extends LR0State {

            /** The nonterminal of the machine. */
            protected int nt;

            /** The initial state of the NFA of the nonterminal of this state. */
            protected NFAState startState;

            /** The rule reduced, if accepting machine state, and one state per rule. */
            protected int redRule;

            /** The head of the temporary list. */
            protected NFAState list;

            /**
             * Deliver a string representing this object.
             *
             * @return  string
             */

            @Override
            public String toString(){
                return Integer.toString(this.number);
            }

            /**
             * Deliver a string representing this state and its items.
             *
             * @return  string
             */

            private String stateToString(){
                StringBuilder itemStr = new StringBuilder();
                String attr = (FAtables.ACCEPTING & this.status) != 0 ? "^" : "";
                boolean first = true;
                for (Item j = this.itemList; j != null; j = j.next){
                    if (j.dot == 0) continue;
                    if (!first) itemStr.append(",");
                    first = false;
                    itemStr.append(" ");
                    itemStr.append(tab.ruleToString(j.dot,true));
                }
                NFAState init = this.startState;
                return String.format("%s%s %s_%s:%s",this.number,attr,
                    this.number-init.number,tab.gramSymToString(this.nt),itemStr);
            }
        }

        /**
         * Deliver a new state.
         *
         * @return  state
         */

        // NFA
        protected NFAState newState(){
            NFAState h = new NFAState();
            h.number = this.lrt.stateNr++;
            this.lastAdded = h;
            if (this.last == null) this.head = h;   // append to list
            else this.last.suc = h;
            this.last = h;
            h.startState = this.nfaCurInit;
            if (this.nfaCurInit == null) h.startState = h;
            h.nt = this.nfaCurAccSym;
            return h;
        }

        /**
         * Deliver a new state and add an item with the specified dot.
         *
         * @param   p dot
         * @return  state
         */

        // NFA
        protected NFAState newState(int p){
            NFAState h = newState();
            h.appendItem(new NFAItem(p));
            return h;
        }

        /**
         * Add the specified transition from the specified state to the specified one.
         *
         * @param   from state
         * @param   to state
         * @return  transition
         */

        // NFA
        private Trans newTrans(NFAState from, NFAState to){
            return newTrans(from,to,0);
        }

        /**
         * Add the specified transition from the specified state to the specified one
         * for the specified dot.
         *
         * @param   from state
         * @param   to state
         * @param   p dot
         * @return  transition
         */

        // NFA
        private Trans newTrans(NFAState from, NFAState to, int p){
            int sym = 0;
            if (p == 0 || tab.grammar[p] >= tab.ruleBase){
                sym = this.epsilonEdge;
            } else {
                sym = tab.grammar[p];
            }
            Trans t = new Trans(sym,to);
            t = from.addTrans(t);
            if (p != 0){
                // add items to states to show the transitions
                from.appendItem(new NFAItem(p));
                if (sym != this.epsilonEdge){
                    to.appendItem(new NFAItem(p+1));
                } else {
                    to.appendItem(new NFAItem(p));
                }
            }
            return t;
        }

        /**
         * Build the NFA.
         *
         * @param   machinesNts <code>true</code> to have one DFA for each nonterminal, and
         *          <code>false</code> to have one for each rule
         * @param   enclosingRule <code>true</code> to have a machine for the enclosing
         *          rule, and <code>false</code> to have it not
         */

        // NFA
        void build(boolean machinesNts, boolean enclosingRule){
            this.trc = ParserLR.this.trc;
            this.epsilonEdge = tab.ruleBase;
            int num = tab.numOfNts-1;                      // enclosing one excluded
            if (enclosingRule) num = tab.numOfNts;
            this.ntToStartStates = new NFAState[num];
            this.transOrdered = false;                     // do not keep transitions ordered
            for (int i = 0; i < this.ntToStartStates.length; i++){
                if (tab.ntKind[i] != 0) continue;          // implicit nt
                this.nfaCurAccSym = i;
                this.nfaCurInit = null;
                NFAState si = newState();                  // allocate its initial state
                this.nfaCurInit = si;
                this.ntToStartStates[i] = si;
                if (machinesNts){                          // one final state for all the rules of a same nt
                    NFAState sf = newState();              // allocate its final state
                    sf.status |= FAtables.ACCEPTING;
                    vi_nt_nfa(i,si,sf);                    // build NFA for nt
                } else {                                   // one final state for each rule
                    // scan all its rules
                    for (int r = tab.ntToRule[i];
                        r < tab.ruleToNt.length &&
                        tab.ruleToNt[r] == i; r++){        // visit all its rules
                        NFAState sf = newState();          // allocate its final state
                        sf.status |= FAtables.ACCEPTING;
                        sf.redRule = r;
                        vi_alt(r,si,sf);                   // build alternative
                    }
                }
            }

            // build table of states
            this.table = new NFAState[this.lrt.stateNr];
            for (State s = this.head; s != null; s = s.suc){
                ((NFAState)s).sortItems();
                this.table[s.number] = s;
            }
        }

        /**
         * Build the machine for the specified nonterminal, using the specified initial
         * and final states.
         *
         * @param   nt nonterminal
         * @param   is initial state for the machine
         * @param   fs final state for the machine
         */

        // NFA
        private void vi_nt_nfa(int nt, NFAState is, NFAState fs){
            vi_nfa(nt,is,fs);                    // scan its definition
        }

        /**
         * Build the machine for the specified nonterminal, using the specified initial
         * and final states.
         *
         * @param   nt nonterminal
         * @param   is initial state for the machine
         * @param   fs final state for the machine
         */

        // NFA
        private void vi_nfa(int nt, NFAState is, NFAState fs){
            // scan all its rules
            for (int r = tab.ntToRule[nt];
                r < tab.ruleToNt.length &&
                tab.ruleToNt[r] == nt; r++){     // visit all its rules
                vi_alt(r,is,fs);                 // build alternative
            }
        }

        /**
         * Build the machine for the specified rule, using the specified initial
         * and final states.
         *
         * @param   rule rule
         * @param   is initial state for the machine
         * @param   fs final state for the machine
         */

        // NFA
        private void vi_alt(int rule, NFAState is, NFAState fs){
            is.appendItem(new NFAItem(tab.ruleIndex[rule]));
            vi_conc(tab.ruleIndex[rule],is,fs);
            fs.appendItem(new NFAItem(tab.ruleIndex[rule]+tab.ruleLen[rule]));
        }

        /**
         * Build the machine for the specified concatenation, using the specified initial
         * and final states.
         *
         * @param   first start dot in the grammar of the concatenation
         * @param   is initial state for the machine
         * @param   fs final state for the machine
         */

        // NFA
        private void vi_conc(int first, NFAState is, NFAState fs){
            NFAState ci = is;
            // scan the rule
            if (tab.grammar[first] >= tab.ruleBase){   // empty rule
                newTrans(is,fs,first);                 // bypass
                return;
            }
            for (int p = first; tab.grammar[p] < tab.ruleBase; p++){
                NFAState cf;
                if (tab.grammar[p+1] < tab.ruleBase){  // not the last
                    cf = newState();              // allocate intermediate state
                } else {
                    cf = fs;                      // use the given one
                }
                vi_primary(p,ci,cf);
                ci = cf;
            }
        }

        /**
         * Build the machine for the specified element, using the specified initial
         * and final states.
         *
         * @param   p dot in the grammar of the element
         * @param   is initial state for the machine
         * @param   fs final state for the machine
         */

        // NFA
        private void vi_primary(int p, NFAState is, NFAState fs){
            NFAState ci = is;
            NFAState cf = fs;
            int rn = 0;
            int gp = tab.grammar[p];
            if (gp >= tab.tokBase ||                 // terminal
                gp < tab.ntNrGroups){                // non group nt
                newTrans(ci,cf,p);
            } else {                                 // group
                vi_group(p,is,fs);
            }
        }

        /**
         * Build the machine for the specified group, using the specified initial
         * and final states.
         *
         * @param   p dot in the grammar where the group starts
         * @param   is initial state for the machine
         * @param   fs final state for the machine
         */

        // NFA
        private void vi_group(int p, NFAState is, NFAState fs){
            NFAState ci = null;
            NFAState cf = null;
            ci = is;
            cf = fs;

            int rn = 0;
            int gp = tab.grammar[p];
            int body = body(gp);

            NFAState s1;
            NFAState s2;
            switch (tab.ntKind[gp]){
            case ParserTables.GRO:                    // simple group
                vi_nfa(body,ci,cf);                   // expand its graph
                break;
            case ParserTables.OPT:                    // optional group
                int bypass = tab.ntToRule[gp];
                if (tab.ruleLen[bypass] > 0){
                    bypass++;
                }
                bypass = tab.ruleIndex[bypass];
                vi_body(body,ci,cf);                  // expand its graph
                newTrans(ci,cf,bypass);               // bypass
                break;
            case ParserTables.RES:                    // kleene group
                s1 = newState();                      // new initial state
                bypass = tab.ntToRule[gp];
                if (tab.ruleLen[bypass] > 0){
                    bypass++;
                }
                bypass = tab.ruleIndex[bypass];
                newTrans(ci,s1,bypass);               // link to old initial state
                newTrans(s1,cf,bypass);               // link to old final state
                vi_body(body,s1,s1);                  // loop onto itself
                break;
            case ParserTables.REU:                    // :u
                rn = tab.ntToRule[gp]; 
                for (p = tab.ruleIndex[rn];           // generate list of
                    tab.grammar[p] < tab.ruleBase;    // .. options
                    p++){        
                    if (tab.grammar[p+1] < tab.ruleBase){
                        cf = newState();              // allocate intermediate state
                    } else {
                        cf = fs;
                    }
                    newTrans(ci,cf);                  // bypass
                    vi_body(body,ci,cf);              // expand its graph
                    ci = cf;
                }
                break;
            case ParserTables.REL:                    // l:
            case ParserTables.REP:                    // +
                rn = tab.ntToRule[gp]; 
                p = tab.ruleIndex[rn];
                if (tab.grammar[p+1] >= tab.ruleBase){  // s1 only if one &1, i.e. REP
                    s1 = newState();                  // new initial state
                    newTrans(ci,s1);                  // link to old initial state
                    ci = s1;
                }
                s2 = newState();                      // new final state
                newTrans(s2,cf);                      // link to old final state
                for (; tab.grammar[p] < tab.ruleBase; p++){        
                    if (tab.grammar[p+1] < tab.ruleBase){
                        cf = newState();              // allocate intermediate state
                    } else {
                        cf = s2;
                        newTrans(cf,ci);              // loop edge
                    }
                    vi_body(body,ci,cf);              // expand its graph
                    ci = cf;
                }
                break;
            case ParserTables.RER:                    // l:u
            case ParserTables.REF:                    // l
                rn = tab.ntToRule[gp]; 
                p = tab.ruleIndex[rn];
                for (; tab.grammar[p] < tab.ruleBase; p++){        
                    if (tab.grammar[p+1] < tab.ruleBase){
                        cf = newState();              // allocate intermediate state
                    } else {
                        cf = fs;
                    }
                    if (tab.ntKind[tab.grammar[p]] == ParserTables.OBO){
                        newTrans(ci,cf);              // bypass
                    }
                    vi_body(body,ci,cf);              // expand its graph
                    ci = cf;
                }
                break;
            }
        }

        /**
         * Build the machine for the specified group body, using the specified initial
         * and final states.
         *
         * @param   nt nonterminal of the group body
         * @param   is initial state for the machine
         * @param   fs final state for the machine
         */

        // NFA
        private void vi_body(int nt, NFAState ci, NFAState cf){
            vi_nfa(nt,ci,cf);
        }

        /**
         * Deliver the dot in the grammar where starts the body of the specified group.
         *
         * @param   gp nonterminal of the group
         * @return  dot of the body
         */

        // NFA
        private int bodyp(int gp){
            int rn = 0;
            int p = 0;
            switch (tab.ntKind[gp]){
            case ParserTables.GRO:
                break;
            case ParserTables.OPT:
            case ParserTables.RER:
            case ParserTables.REF:
                rn = tab.ntToRule[gp];
                p = tab.ruleIndex[rn];
                break;
            case ParserTables.REU:
                rn = tab.ntToRule[gp];
                p = tab.ruleIndex[rn];
                gp = tab.grammar[p];           // &2
                rn = tab.ntToRule[gp] + 1;
                p = tab.ruleIndex[rn];
                gp = tab.grammar[p];           // &1
                if (gp >= tab.ruleBase){       // the rules have been swapped
                    p -= 2;
                }
                break;
            case ParserTables.REL:
                rn = tab.ntToRule[gp];
                p = tab.ruleIndex[rn];
                break;
            case ParserTables.RES:
                rn = tab.ntToRule[gp] + 1;
                p = tab.ruleIndex[rn];
                int g = tab.grammar[p];
                if (g == gp){                   // left-recursive
                    p++;
                }
                break;
            case ParserTables.REP:
                rn = tab.ntToRule[gp];
                p = tab.ruleIndex[rn];
                g = tab.grammar[p];
                if (g == gp){                   // left-recursive
                    p++;
                }
                break;
            }
            return p;
        }

        /**
         * Deliver the nonterminal of the body of the specified group.
         *
         * @param   gp nonterminal of the group
         * @return  nonterminal of the group
         */

        // NFA
        private int body(int gp){
            if (tab.ntKind[gp] == ParserTables.GRO){
                return gp;
            }
            if (tab.ntKind[gp] >= ParserTables.BOD || tab.ntKind[gp] == 0){
                return gp;
            }
            return tab.grammar[bodyp(gp)];
        }

        /**
         * Trace the NFA.
         */

        // NFA
        void trace(PrintWriter trc){
            trc.printf("---- machines ----\n");
            for (int i = 0; i < this.table.length; i++){
                NFAState s = (NFAState)this.table[i];
                trc.printf("%s rule %s\n",s.stateToString(),s.redRule);
                for (Trans t = s.transList; t != null; t = t.next){
                    trc.printf("  --%s--> %s\n",
                        edgeToString(t.sym),
                        ((NFAState)t.nextState).stateToString());
                }
            }
        }

        /**
         * Deliver a string representation of the specified edge label.
         *
         * @param   sym label
         * @return  state
         */

        // NFA
        private String edgeToString(int sym){
            String str = null;
            if (sym == this.epsilonEdge){             // epsilon edge
                str = "epsilon";
            } else {
                str = tab.gramSymToString(sym);
            }
            return str.toString();
        }
    }

    /**
     * The machines DFA.
     */

    class MDFA extends NFA {

        /** The reference to the DFA machine (initial state) for each nonterminal. */
        protected MDFAState[] ntToDfaStates;

        /** Temporary sets of symbols for all transitions of a DFA state. */
        private int[] symbSets;

        /** Temporary sets of NFA states for all transitions of a DFA state. */
        private IntSet[] stateSets;

        /** Reference to the NFA. */
        private NFA machines;

        /**
         * A transition (edge) from a state to another.
         */

        protected class MDFATrans extends Trans {

            /**
             * Deliver a new transition with the specified symbol and next state.
             *
             * @param   sym symbol
             * @param   next next state
             * @return  transition
             */

            protected MDFATrans(int sym, State next){
                super(sym,next);
            }

            /**
             * Deliver a string representing this object.
             *
             * @return  string
             */

            @Override
            public String toString(){
                String str = null;
                if (sym == epsilonEdge){             // epsilon edge
                    str = "epsilon";
                } else {
                    str = tab.gramSymToString(sym);
                }
                return String.format("-%s->%s",
                    str.toString(),this.nextState.name());
            }
        }

        /*
         * A state. States are unique by the set of NFA states that they represent.
         * Such set plays the role of items, but items here denote the dotted rule that
         * the state represent.
         */

        protected class MDFAState extends NFAState {

            /** The NFA states that this one represents. */
            protected NFAState[] nfaName;

            /** The rn tail status. */
            protected static final int RNTAIL = 1 << 13;

            /**
             * Deliver a string representing this object.
             *
             * @return  string
             */

            @Override
            public String toString(){
                Str st = new Str();
                st.append(Integer.toString(this.number));
                return st.toString();
            }

            /**
             * Deliver a string representing the component NFA states of this one.
             *
             * @return  string
             */

            String dfaName(){
                Str st = new Str();
                st.append("(");
                for (int i = 0; i < this.nfaName.length; i++){
                    if (i > 0){
                        st.append(",");
                    }
                    st.append(Integer.toString(this.nfaName[i].number));
                }
                st.append(")");
                return st.toString();
            }

            /**
             * Tell if this object is equal to the specified one.
             *
             * @param   other object
             * @return  <code>true</code> if equal, <code>false</code> otherwise
             */

            @Override
            public boolean equals(Object other){
                if (this == other) return true;
                if (other == null) return false;
                MDFAState s = (MDFAState)other;
                return Arrays.equals(this.nfaName,s.nfaName);
            }

            /**
             * Deliver the hash value of this object.
             *
             * @return  hash value
             */

            @Override
            public int hashCode(){
                int h = 0;
                for (int i = 0; i < this.nfaName.length; i++){
                    h = 31*h + this.nfaName[i].number;
                }
                return h;
            }

            /**
             * Sort the set of NFA items. Actually it does nothing since items are
             * added in increasing order.
             */

            @Override
            protected void sortItems(){
            }

            /**
             * Tell if there are conflicts, and here there are none.
             */

            @Override
            protected void findConflicts(){
            }

            /**
             * Deliver a string representing the name of this state.
             *
             * @return  string
             */

            @Override
            protected String name(){
                return String.format("%s_%s",this.number-this.startState.number,
                    tab.gramSymToString(this.nt));
            }

            /**
             * Deliver a string representing the header of the state in tracing.
             *
             * @return  string
             */

            @Override
            protected String header(){
                String status = lrt.statusToString(this.status);
                String nam = name();
                return String.format("%s%s%s %s rule %s",
                    tab.gramSymToString(this.nt),
                    this.number,
                    status.length()==0?"":" " + status,
                    nam.length()==0?"":" " + nam,
                    this.dfaName(),this.redRule);
            }
        }

        /**
         * Convert the specified NFAs into DFAs.
         *
         * @param   machinesNts <code>true</code> to have one DFA for each nonterminal, and
         *          <code>false</code> to have one for each rule
         * @param   ntToStartStates array of start NFA states, one for each nonterminal or rule
         * @return  array of DFAs
         */

        // MDFA
        private MDFAState[] nfaToDfa(boolean machinesNts, NFAState[] ntToStartStates){
            // allocate temporary arrays
            int sn = tab.grammar.length;
            NFAState[] stArr = new NFAState[sn];        // allocate array for building DFA state names
            int[] states = new int[sn];

            this.symbSets = new int[20];                // symbols on the edges for a state
            this.stateSets = new IntSet[20];            // nfa states reached with a symbol
            this.ntToDfaStates = new MDFAState[ntToStartStates.length];
            this.transOrdered = false;                     // do not keep transitions ordered

            for (int i = 0; i < ntToStartStates.length; i++){
                NFAState bs = ntToStartStates[i];
                if (bs == null) continue;
                // build the first state
                MDFAState state = new MDFAState();

                Arrays.fill(this.symbSets,0);
                Arrays.fill(this.stateSets,null);
                bs.list = null;                         // closure of initial NFA state
                closure(bs);                            // build a list with the nfa state and all ..
                int n = 0;                              // .. the ones reached with epsilon arcs
                IntSet itms = new IntSet();
                for (NFAState h = bs; h != null; h = h.list){  // build name
                    // add the items of component NFA states to the DFA one
                    for (Item k = h.itemList; k != null; k = k.next){
                        itms.add(k.dot);
                    }
                    stArr[n++] = h;                     // store pointers
                }
                int[] arr = itms.toArray();
                for (int z = 0; z < arr.length; z++){
                    Item ni = this.machines.new NFAItem(arr[z]);
                    state.appendItem(ni);
                }
                state.nfaName = Arrays.copyOf(stArr,n); // create name
                addUnique(state);                       // create new DFA state with the NFA states
                ntToDfaStates[i] = state;
                synthAttr(state,machinesNts);           // synthetize attributes (accepting, reduction rule)
                MDFAState startState = state;
                state.startState = state;               // pointer to the start state
                state.nt = i;                           // nt for this machine
                MDFAState sh = state;                   // head of created DFA
                for (MDFAState h = state; h != null;    // scan DFA non visited states
                    h = (MDFAState)h.suc){
                    n = dfaEdgeList(h);                       // build edges: symbols and reached nfa states
                    closeList(n);                             // closure of all states in the edges
                    for (int j = 0; j < n ; j++){             // generate DFA transitions
                        state = new MDFAState();
                        this.stateSets[j].toArray(states);
                        int m = (int)(this.stateSets[j].size());
                        itms = new IntSet();
                        for (int k = 0; k < m; k++){
                            NFAState nf = (NFAState)this.machines.table[states[k]];
                            for (Item nk = nf.itemList; nk != null; nk = nk.next){
                                itms.add(nk.dot);
                            }
                            stArr[k] = nf;
                        }
                        arr = itms.toArray();
                        for (int z = 0; z < arr.length; z++){
                            Item ni = this.machines.new NFAItem(arr[z]);
                            state.appendItem(ni);
                        }
                        state.nfaName = Arrays.copyOf(stArr,m);  // name
                        boolean added = addUnique(state);        // create new DFA state with the NFA states
                        if (added){
                            synthAttr(state,machinesNts);        // synthetize attributes
                            state.startState = startState;
                            state.nt = i;                        // nt for this machine
                        } else {
                            state = (MDFAState)this.lastAdded;
                        }
                        // add edge
                        h.addTrans(new MDFATrans(this.symbSets[j],state));
                    }
                    h.transOrder();                       // order the transitions
                }
            }
            this.symbSets = null;                         // release temporary storage
            this.stateSets = null;

            minimizeMachines(ntToDfaStates);

            // build table of states
            this.table = new MDFAState[this.lrt.stateNr];
            for (State s = this.head; s != null; s = s.suc){
                this.table[s.number] = s;
            }
            return ntToDfaStates;
        }

        /**
         * Trace the DFA.
         */

        // MDFA
        public void trace(){
            Trc.out.printf("---- mac ----\n");
            for (int i = 0; i < this.table.length; i++){
                MDFAState s = (MDFAState)this.table[i];
                s.trace();
            }
            Trc.out.printf("---- start states ----\n");
            for (int i = 0; i < ntToDfaStates.length; i++){
                Trc.out.printf("  %s",tab.gramSymToString(i));
                if (ntToDfaStates[i] == null){
                    Trc.out.printf(" null");
                } else {
                    Trc.out.printf(" %s",ntToDfaStates[i].number);
                }
                Trc.out.printf("\n");
            }
        }

        /**
         * Enlist all the NFA states reacheable with epsilon arcs from the specified state.
         * The returned states are connected in a list that is the temporary one of the
         * specified state.
         *
         * @param   s NFA state
         */

        // MDFA
        private void closure(NFAState s){
            NFAState ta = s;
            for (NFAState h = s; h != null; h = h.list){   // scan the list
                ta = h;
                t: for (Trans tr = h.transList; tr != null; tr = tr.next){
                    if (tr.sym != this.epsilonEdge) continue;
                    for (NFAState j = s; j != null; j = j.list){   // append if not alredy present
                        if (tr.nextState == j) continue t;
                    }
                    ((NFAState)tr.nextState).list = ta.list;       // put state into list after the current
                    ta.list = (NFAState)tr.nextState;
                    ta = (NFAState)tr.nextState;
                }
            }
        }

        /**
         * Scan all the nfa states represented by the specified dfa state and for each non-epsilon
         * edge store its symbol in symbSets, and in stateSets the set of reached nfa states;
         * when there are several edges with a same symbol, collect the reached states in stateSets.
         *
         * @param   s DFA state
         */

        // MDFA
        private int dfaEdgeList(MDFAState h){
            int n = 0;
            for (int i = 0; i < h.nfaName.length; i++){     // scan edges of the set of nfa states
                for (Trans ts = h.nfaName[i].transList;
                    ts != null; ts = ts.next){              // scan all edges of this state
                    if (ts.sym == this.epsilonEdge) continue;
                    boolean found = false;
                    for (int j = 0; j < n; j++){
                        if (this.symbSets[j] == ts.sym){    // same symbol
                            this.stateSets[j]
                               .add(ts.nextState.number);   // add state
                            found = true;
                            break;
                        }
                    }
                    if (!found){                            // add to list
                        if (n == this.symbSets.length){
                            int curlen = this.symbSets.length;
                            int newlen = curlen + 20;
                            this.symbSets = Arrays.copyOf(this.symbSets,newlen);
                            this.stateSets = Arrays.copyOf(this.stateSets,newlen);
                        }
                        if (this.stateSets[n] == null){      // store the new set
                            this.stateSets[n] = new IntSet();
                        } else {
                            this.stateSets[n].clear();
                        }
                        this.stateSets[n].add(ts.nextState.number);
                        this.symbSets[n] = ts.sym;
                        n++;
                    }
                }
            }
            return n;
        }
    
        /**
         * Deliver a string representing an edge in the edge list.
         *
         * @param   i index of the edge
         * @return  updated n
         */

        // MDFA
        private String edgeToString(int i){
            return this.machines.edgeToString(this.symbSets[i]) + " -> " +
                this.stateSets[i].toString(false);
        }

        /**
         * Perform the closure of all the states in the list of edges, which has the
         * specified number of significant entries.
         *
         * @param   n number of significant entries in the list (symbSets and stateSets).
         * @return  updated n
         */

        // MDFA
        private int closeList(int n){
            int[] stateNrs = new int[20];
            int l = 0;
            for (int i = 0; i < n; i++){          // make e-closure on edges
                NFAState q = null;
                IntSet s = this.stateSets[i];
                int nr = (int)s.size();
                stateNrs = s.toArray(stateNrs);
                for (int k = 0; k < nr; k++){
                    int j = stateNrs[k];
                    ((NFAState)this.machines.table[j]).list = q;
                    q = (NFAState)this.machines.table[j];
                }
                closure(q);
                for (; q != null; q = q.list){    // store the closure
                    s.add(q.number);
                }
            }
            return n;
        }

        /**
         * Synthetize the attributes of the NFA states represented by the specified DFA state
         * storing the result in its status.
         *
         * @param   s DFA state
         * @param   machinesNts <code>true</code> to have one DFA for each nonterminal, and
         *          <code>false</code> to have one for each rule
         */

        // MDFA
        private void synthAttr(MDFAState s, boolean machinesNts){
            int redRule = -1;
            for (int i = 0; i < s.nfaName.length; i++){
                NFAState h = (NFAState)s.nfaName[i];
                if ((FAtables.ACCEPTING & h.status) != 0){  // accepting state
                    s.status |= FAtables.ACCEPTING;
                    if (!machinesNts){
                        if (tab.ntKind[tab.ruleToNt[h.redRule]] == 0){
                            if (redRule < 0){
                                redRule = h.redRule;
                            } else if (redRule != h.redRule){
                                Trc.out.printf("!! more than one reduction in a machine accepting state dfa state: %s nfa state %s rule1 %s rule2 %s\n",
                                    s.number,h.number,tab.ruleToString(tab.ruleIndex[redRule],false),
                                    tab.ruleToString(tab.ruleIndex[h.redRule],false));
                            }
                        }
                    }
                }
            }
            if (redRule >= 0){          // N.B. There is only one because the grammar is not ambiguous
                s.redRule = redRule;
            }
        }

        /**
         * Minimize the specified DFAs.
         * Simplified version of the one present in ParserFA.
         *
         * @param   ntToDfaStates start states of the DFAs
         */

        // MDFA
        private void minimizeMachines(MDFAState[] ntToDfaStates){
            int curnt = -1;
            this.table = new MDFAState[this.lrt.stateNr];
            for (State s = this.head; s != null; s = s.suc){
                this.table[s.number] = s;
            }
            this.head = null;
            MDFAState prev = null;
            for (int i = 0; i < this.table.length; i++){
                MDFAState s = (MDFAState)this.table[i];
                MDFAState init = (MDFAState)s.startState;
                if (init.nt != curnt){                         // start state of a machine
                    curnt = init.nt;
                    int first = i;                             // first state of this machine
                    int last = this.table.length;              // last+1 state
                    for (; i < this.table.length; i++){
                        MDFAState st = (MDFAState)this.table[i];
                        init = (MDFAState)st.startState;
                        if (init.nt != curnt){                 // start state of the next machine
                            last = i;
                            i--;
                            break;
                        }
                    }
                    MDFAState m = minimizeMachineDfa(first,last);
                    // append to the list of states
                    if (this.head == null){
                        this.head = m;
                    } else {
                        for (MDFAState st = prev; st != null; st = (MDFAState)st.suc){
                            if (st.suc == null){
                                st.suc = m;
                                break;
                            }
                        }
                    }
                    prev = m;
                    ntToDfaStates[curnt] = m;
                }
            }
            int num = 0;
            for (State s = this.head; s != null; s = s.suc){
                s.number = num++;
            }
            this.lrt.stateNr = num;
        }

        /**
         * Minimize the specified states, starting from the specified first one and
         * ending in the specified last one.
         *
         * @param   first first state
         * @param   last last state
         * @return  head of the list of the minimized states
         */

        // MDFA
        private MDFAState minimizeMachineDfa(int first, int last){
            int sn = this.table.length;                    // number of states

            MDFAState[] curPart = new MDFAState[sn+1];     // current partition
            MDFAState[] newPart = new MDFAState[sn+1];     // new partition
            int[] groupNr = new int[sn+1];                 // group numbers of states

            int n = 0;                                     // build initial partition
            for (int k = first; k < last; k++){
                MDFAState h = (MDFAState)this.table[k];
                MDFAState s1 = h;
                for (int i = 0; i < n; i++){               // scan the collected ones
                    MDFAState s = curPart[i];
                    boolean equiv = false;
                    comp: {
                        if ((FAtables.ACCEPTING & h.status) != 0){        // final state
                            if ((FAtables.ACCEPTING & s.status) == 0){    // different
                                break comp;
                            }
                            equiv = s.redRule == h.redRule;            // compare reduced rules
                            break comp;
                        } else {
                            if ((FAtables.ACCEPTING & s.status) != 0){  // different
                                break comp;
                            }
                        }
                        equiv = true;
                    }
                    if (equiv){                            // in an existing group
                        s1.list = curPart[i];              // add to it
                        curPart[i] = s1;
                        s1 = null;
                        break;
                    }
                }
                if (s1 != null){                           // in no groups
                    curPart[n] = s1;                       // create new one
                    curPart[n].list = null;
                    n++;
                }
            }
            for (int i = 0; i < n; i++){                   // fill in group numbers
                for (MDFAState g = curPart[i];             // scan group
                    g != null; g = (MDFAState)g.list){
                    groupNr[g.number] = i;
                }
            }

            int m = 0;                                     // fragment now
            boolean change = true;                         // .. partitions
            while (change){
                change = false;
                for (int i = 0; i < n; i++){               // scan current partition
                    MDFAState group = curPart[i];          // current group
                    if (group == null) continue;
                    newPart[m] = group;                    // place first in new group
                    group = (MDFAState)group.list;
                    newPart[m].list = null;
                    int mm = m++;
                    MDFAState next;
                    for (MDFAState g = group;              // scan remaining of current group
                        g != null; g = next){
                        next = (MDFAState)g.list;
                        MDFAState s1 = g;
                        for (int j = mm; j < m; j++){      // scan the previous ones in group
                            MDFAState s2 = newPart[j];     // take first, all have
                            boolean equiv = false;         // .. the same transitions
                            comp: {
                                Trans t1 = s1.transList;
                                Trans t2 = s2.transList;
                                while ((t1 != null) && (t2 != null)){
                                    if ((t1.sym != t2.sym) ||
                                        (groupNr[t1.nextState.number] !=
                                        groupNr[t2.nextState.number])){
                                        break;
                                    }
                                    t1 = t1.next;
                                    t2 = t2.next;
                                }
                                equiv = t1 == t2;
                            } // comp
                            if (equiv){                    // in an existing group
                                s1.list = newPart[j];      // add to it
                                newPart[j] = s1;
                                s1 = null;
                                break;
                            }
                        }
                        if (s1 != null){                   // in no groups
                            newPart[m] = s1;               // create new one
                            newPart[m].list = null;
                            m++;
                            change = true;
                        }
                    }
                }
                for (int i = 0; i < m; i++){               // write group numbers
                    for (MDFAState g = newPart[i];         // scan group
                        g != null; g = (MDFAState)g.list){
                        groupNr[g.number] = i;
                    }
                }
                MDFAState[] tmp = curPart;
                curPart = newPart;
                newPart = tmp;
                n = m;
                m = 0;
            }
            // reduce now the automaton

            NFAState[] nfas = null;                   // temp for rebuilding names
            MDFAState[] stateMap = newPart;           // build map, reuse newPart
            for (int i = 0; i < n; i++){              // put state translation
                MDFAState s = curPart[i];             // .. in stateMap
                int min = s.number;                   // determine representative
                int nf = 0;
                if (s.nfaName != null){
                    nf = s.nfaName.length;
                }
                for (MDFAState g = (MDFAState)s.list;    // it is the one with the
                    g != null; g = (MDFAState)g.list){   // .. minimum state number
                    if (g.number < min){
                        min = g.number;
                        s = g;
                    }
                    if (g.nfaName != null){
                        nf += g.nfaName.length;
                    }
                }
                if ((nfas == null) || (nf > nfas.length)){
                    nfas = new NFAState[nf];
                }
                int nn = 0;
                for (MDFAState g = curPart[i];            // fill now the translation
                    g != null; g = (MDFAState)g.list){    // .. map and rebuild name
                    stateMap[g.number] = s;
                    if (nf == 0) continue;
                    ins: for (int k = 0; k < g.nfaName.length; k++){
                        for (int j = 0; j < nn; j++){
                            if (g.nfaName[k] == nfas[j]) continue ins;
                        }
                        nfas[nn++] = g.nfaName[k];
                    }
                }
                if (nf == 0) continue;
                if (s.nfaName.length != nn){             // larger name, allocate
                    s.nfaName = new NFAState[nn];        // .. a new one
                }
                System.arraycopy(nfas,0,s.nfaName,0,nn);
            }

            // check that there are no incoming transitions in the initial state
            boolean inInitial = false;
            for (int k = first; k < last; k++){           // visit all states
                MDFAState h = (MDFAState)this.table[k];
                if (stateMap[h.number] != h) continue;    // state discarded
                Trans ts = h.transList;                   // scan all transitions, translate state
                for (; ts != null; ts = ts.next){
                    if (stateMap[ts.nextState.number] == this.table[first]){
                        inInitial = true;
                        break;
                    }
                }
            }
            MDFAState tail = null;
            MDFAState head = null;
            MDFAState next = null;
            if (inInitial){
                // deliver the non-minimized one
                for (int k = first; k < last; k++){
                    MDFAState h = (MDFAState)this.table[k];
                    if (tail == null){                    // insert at beginning
                        head = h;
                    } else {                              // append
                        tail.suc = h;
                    }
                    h.suc = null;
                    tail = h;
                }
            } else {
                for (int k = first; k < last; k++){           // visit all states
                    MDFAState h = (MDFAState)this.table[k];
                    if (stateMap[h.number] == h){             // keep this state
                        if (tail == null){                    // insert at beginning
                            head = h;
                        } else {                              // append
                            tail.suc = h;
                        }
                        h.suc = null;
                        tail = h;
                    } else {
                        continue;
                    }
                    Trans ts = h.transList;                   // scan all transitions, translate state
                    for (; ts != null; ts = ts.next){
                        ts.nextState = stateMap[ts.nextState.number];
                    }
                }
            }

            // update the start state fields
            for (MDFAState s = head; s != null; s = (MDFAState)s.suc){
                s.startState = head;
            }

            return head;
        }

        /**
         * Build the MDFA.
         */

        // MDFA
        void build(boolean machinesNts){
            this.trc = ParserLR.this.trc;
            this.epsilonEdge = tab.ruleBase;
            this.ntToDfaStates = nfaToDfa(machinesNts,this.machines.ntToStartStates);
        }
    }

    /**
     * The ELR(1).
     */

    class ELR1FA extends LR1FA implements Serializable {

        /** The NFA of machines. */
        protected NFA machines;

        /** The DFA of machines. */
        protected MDFA mac;

        /** Whether there is only one machine end state for each nt, false for one for each rule. */
        protected boolean machinesNts = true;

        /** Whether the enclosing rule is used to build states in the pilot. */
        protected boolean enclosingRule;

        /** Whether there are conflicts. */
        protected boolean conflicts;

        /** The label on a transition that has no symbol. */
        protected int epsilonEdge;

        /**
         * Deliver a string representing the specified set of terminals.
         *
         * @return  s set
         * @return  string
         */

        @Override
        protected String tokSetToString(BitSet s){
            String res = "";
            if (s == null) return res;
            int len = s.length();
            for (int i = 0; i < len; i++){
                if (!s.get(i)) continue;
                if (res.length() > 0) res += " ";
                if (i == this.epsilonEdge){
                    res += "\"\"";
                } else {
                    res += tab.tokLitName(i);
                }
            }
            return "{" + res + "}";
        }

        /**
         * An item.
         */

        protected class ELR1Item extends LR1Item {

            /**
             * Deliver a new item with the specified dot and lookahead.
             *
             * @param   dot dot
             * @param   la lookahead
             * @return  item
             */

            protected ELR1Item(int dot, BitSet la){
                super(dot,la);
            }

            /**
             * Deliver a string representing this item.
             *
             * @return  string
             */

            @Override
            public String toString(){
                StringBuilder sb = new StringBuilder();
                sb.append(this.index);
                sb.append(" <");
                MDFA.MDFAState m = (MDFA.MDFAState)mac.table[this.dot];
                sb.append(m.name());
                sb.append(",");
                sb.append(tokSetToString(this.la));
                sb.append(">");
                return sb.toString();
            }

            /**
             * Tell if this object is a final one.
             *
             * @return  <code>true</code> if final, <code>false</code> otherwise
             */

            boolean isFinal(){
                MDFA.MDFAState q = (MDFA.MDFAState)mac.table[this.dot];
                return (FAtables.ACCEPTING & q.status) != 0;
            }

            /**
             * Tell if this object is an initial one.
             *
             * @return  <code>true</code> if initial, <code>false</code> otherwise
             */

            boolean isInitial(){
                MDFA.MDFAState q = (MDFA.MDFAState)mac.table[this.dot];
                return q == q.startState;     // initial: 0_X
            }

            /**
             * Tell if this object is adequate (i.e. it has a unique predecessor).
             *
             * @return  <code>true</code> if adequate, <code>false</code> otherwise
             */

            boolean isAdequate(){
                return true;
            }

            /**
             * Deliver the next states that this item leads to.
             *
             * @param   state the state of the item
             * @return  array of next states, empty if there are no next states
             */

            State[] toStates(State state){
                ArrayList<State> arr = new ArrayList<State>();
                MDFA.MDFAState q = (MDFA.MDFAState)mac.table[this.dot];
                for (Trans t = q.transList; t != null; t = t.next){     // scan its arcs
                    // determine the pilot state they lead to
                    for (Trans s = state.transList; s != null; s = s.next){
                        if (s.sym == t.sym){
                            arr.add(s.nextState);
                        }
                    }
                }
                return arr.toArray(new State[0]);
            }

            /**
             * Deliver the nonterminal of this item.
             *
             * @return  nonterminal
             */

            int lhs(){
                MDFA.MDFAState q = (MDFA.MDFAState)mac.table[this.dot];
                return ((MDFA.MDFAState)q.startState).nt;
            }
        }

        /**
         * A state.
         */

        protected class ELR1State extends LR1State {

            /** The convergence conflicts status. */
            protected static final int CONFLICT_CC = 1 << 6;

            /**
             * Tell if this object is equal to the specified one.
             *
             * @param   other object
             * @return  <code>true</code> if equal, <code>false</code> otherwise
             */

            @Override
            public boolean equals(Object other){
                if (this == other) return true;
                if (other == null) return false;
                Item i1 = this.itemList;
                Item i2 = ((ELR1State)other).itemList;
                for (; i1 != null && i2 != null; i1 = i1.next, i2 = i2.next){
                    if (!i1.equals(i2)) return false;
                }
                if (i1 != null || i2 != null) return false;
                return true;
            }

            /**
             * Add the specified item if not already present.
             *
             * @param   item item
             * @return  reference to the added item if already present and if its lookaheads changed
             */

            @Override
            protected ELR1Item addItem(Item item){
                BitSet la = ((ELR1Item)item).la;
                ELR1Item itm = (ELR1Item)appendItem(item);
                BitSet laAdded = new BitSet();
                if (item != itm){                  // already present
                    laAdded.or(la);
                    laAdded.andNot(itm.la);        // newly added lookaheads
                    // force the merging of lookaheads to obtain the same results as the
                    // Crespi's book and our paper
                    BitSet l = new BitSet();
                    l.or(itm.la);
                    l.or(la);
                    itm.la = latable.add(l);
                } else {
                }
                if (laAdded.isEmpty()) itm = null;
                return itm;
            }

            /**
             * Tell if there are conflicts, and in such a case mark them in the state.
             */

            @Override
            protected void findConflicts(){
                // the conflicts are determined after having built the pilot
            }
        }

        /**
         * Deliver a new item with the specified dot.
         *
         * @param   dot dot
         * @return  item
         */

        // ELR1FA
        @Override
        protected ELR1Item newItem(int dot){
            int EOF = tab.numOfToks;
            BitSet la = new BitSet();
            la.set(EOF);
            return new ELR1Item(dot,la);
        }

        /**
         * Deliver a new item with the specified dot and lookaheads.
         *
         * @param   dot dot
         * @param   la lookahead
         * @return  item
         */

        // ELR1FA
        protected ELR1Item newItem(int dot, BitSet la){
            return new ELR1Item(dot,la);
        }

        /**
         * Deliver a new item with the dot advanced with respect to the specified one
         * for the specified symbol (used when there are machines).
         *
         * @param   other other item
         * @param   sym symbol
         * @return  item
         */

        // ELR1FA
        @Override
        protected ELR1Item newAdvItem(Item other, int sym){
            ELR1Item item = (ELR1Item)other;
            MDFA.MDFAState q = (MDFA.MDFAState)mac.table[item.dot];
            for (Trans t = q.transList; t != null; t = t.next){  // scan edges
                if (t.sym != sym) continue;
                BitSet las = new BitSet();
                las.or(item.la);
                return new ELR1Item(t.nextState.number,las);
            }
            return null;
        }

        /**
         * Ensure that this FA contains an element that is equal to the specified one.
         * If it is not yet present, add it.
         * It appends the new element at the end of the ordered list.
         *
         * @param   state reference to the state to add
         * @return  <code>true</code> if the element has been inserted
         */

        // ELR1FA
        @Override
        protected boolean addUnique(LR0State state){
            boolean added = super.addUnique(state);
            if (added){
                ELR1State s = (ELR1State)state;
                int startnt = tab.grammar[tab.startRule];
                if (this.enclosingRule){
                    startnt = tab.ruleToNt[tab.grammar[tab.startRule+2]-tab.ruleBase];
                }
                for (Item i = s.itemList; i != null; i = i.next){  // determine if it is final
                    MDFA.MDFAState m = (MDFA.MDFAState)this.mac.table[i.dot];
                    if (m.nt == startnt){
                        if ((FAtables.ACCEPTING & m.status) != 0){
                            // it is the final pilot state when it is the accepting one
                            // of the machine for the axiom or the enclosing axiom
                            s.status |= FAtables.ACCEPTING;
                            break;
                        }
                    }
                }
            }
            return added;
        }

        /**
         * Deliver the shifts of the specified state into the specified array.
         *
         * @param   state state
         * @param   shifts array in which the shifts are delivered
         * @param   shift array used to make the shifts unique
         * @return  number of shifts
         */

        // ELR1FA
        @Override
        protected int getShifts(LR0State state, int[] shifts, boolean[] shif){
            int shiftsnr = 0;
            Arrays.fill(shif,false);
            // determine the shifts, i.e. symbols for transitions
            for (Item i = state.itemList; i != null; i = i.next){ // scan its items
                MDFA.MDFAState q = (MDFA.MDFAState)this.mac.table[i.dot];
                for (Trans t = q.transList; t != null; t = t.next){  // scan edges
                    if (!shif[t.sym]) shifts[shiftsnr++] = t.sym;
                    shif[t.sym] = true;
                }
            }
            Arrays.sort(shifts,0,shiftsnr);             // sort so as to generate states orderly
            return shiftsnr;
        }

        /**
         * Deliver a new state;
         *
         * @param   sym accessing symbol
         * @return  state
         */

        // ELR1FA
        @Override
        protected ELR1State newState(int sym){
            ELR1State s = new ELR1State();
            s.accessingSymbol = sym;
            return s;
        }

        /**
         * Perform the closure of the list of items of the specified state, adding the items
         * predicted by them.
         *
         * @param      state state
         */

        // ELR1FA
        @Override
        protected void closure(LR0State state){
            for (Item i = state.itemList; i != null;){
                int redo = i.index + 1;                   // item to restart processing
                Item redoitm = null;
                // apply predictor to all items
                MDFA.MDFAState q = (MDFA.MDFAState)this.mac.table[i.dot];
                for (Trans t = q.transList; t != null; t = t.next){      // scan edges
                    if (t.sym < tab.tokBase){                            // nonterminal
                        BitSet first = Ini((MDFA.MDFAState)t.nextState);
                        if (first.get(epsilonEdge)){      // generates the empty string
                            first.clear(epsilonEdge);
                            first.or(((ELR1Item)i).la);
                        }
                        Item itm = state.addItem(newItem(this.mac.ntToDfaStates[t.sym].number,first));
                        if (itm != null && itm.index < redo && itm.index <= i.index){
                            redo = itm.index;
                            redoitm = itm;
                        }
                    }
                }
                if (redo != i.index+1){
                    i = redoitm;             // restart from previous item because its LAs changed
                    continue;
                }
                i = i.next;
            }
        }

        /*
         * This is First() for states in machines. First(s) is the set of terminals
         * that head paths from s.
         *
         * N.B. it contains null only if only the empty string is generated.
         * The set contains the empty string (represented as epsilonEdge) if the empty
         * string is generated (possibly together with others).
         */

        // ELR1FA
        private BitSet Ini(MDFA.MDFAState q){
            BitSet la = new BitSet();
            if ((FAtables.ACCEPTING & q.status) != 0){
                la.set(epsilonEdge);
            }
            MDFA.MDFAState[] queue = new MDFA.MDFAState[this.mac.lrt.stateNr];
            int dp = 0;
            int qp = 0;
            queue[qp++] = q;
            while (dp != qp){                          // while queue not empty
                MDFA.MDFAState s = queue[dp++];                           // dequeue
                for (Trans t = s.transList; t != null; t = t.next){       // scan edges
                    if (t.sym >= tab.tokBase){                            // terminal
                        if (t.sym == tab.ruleBase) continue;
                        la.set(t.sym-tab.tokBase);
                    } else {                                              // nonterminal
                        la.or(tab.firsts[t.sym]);
                        nul: if (boolGet(tab.nullable,t.sym)){
                            if ((FAtables.ACCEPTING & t.nextState.status) != 0){  // edge terminating in final state
                                la.set(epsilonEdge);
                            }
                            for (int i = 0; i < qp; i++){
                                if (t.nextState == queue[i]) break nul;   // already visited
                            }
                            queue[qp++] = (MDFA.MDFAState)t.nextState;    // enqueue for visiting
                        }
                    }
                }
            }
            return la;
        }

        /**
         * Mark the states that have conflicts.
         */

        // ELR1FA
        @Override
        protected void findConflicts(){
            int conflicts = 0;
            for (int i = 0; i < this.table.length; i++){
                ELR1State s = (ELR1State)this.table[i];
                for (int sy = 0; sy < tab.numOfToks + 1; sy++){
                    int reNr = 0;
                    int shNr = 0;
                    for (Item j = s.itemList; j != null; j = j.next){   // scan items
                        MDFA.MDFAState m = (MDFA.MDFAState)this.mac.table[j.dot];            // machine state
                        if ((FAtables.ACCEPTING & m.status) != 0){         // a reduction
                            if (((ELR1Item)j).la.get(sy)){
                                reNr++;
                            }
                        }
                        for (Trans t = m.transList; t != null; t = t.next){      // scan edges
                            if (t.sym != sy+tab.tokBase) continue;
                            shNr++;
                            // find if there is another item with a same shift and nextstate
                            // and overlapping lookaheads
                            for (Item k = j.next; k != null; k = k.next){         // scan following items
                                MDFA.MDFAState mm = (MDFA.MDFAState)this.mac.table[k.dot];          // machine state
                                for (Trans tt = mm.transList; tt != null; tt = tt.next){  // scan edges
                                    if (tt.sym != sy+tab.tokBase) continue;
                                    if (tt.nextState == t.nextState &&
                                        ((ELR1Item)k).la.intersects(((ELR1Item)j).la)){
                                        // convergence conflict
                                        s.status |= ELR1State.CONFLICT_CC;
                                        conflicts++;
                                    }
                                    break;
                                }
                            }
                            break;
                        }
                    }
                    boolean found = false;
                    if (reNr > 0 && shNr > 0){                    // there is at least one reduction and one shift
                        // shift-reduce conflict
                        s.status |= LR0FAtables.CONFLICT_SR;
                        conflicts++;
                        found = true;
                    }
                    if (reNr > 1){                    // there are several reductions
                        // reduce-reduce conflict
                        s.status |= LR0FAtables.CONFLICT_RR;
                        conflicts++;
                        found = true;
                    }
                    if (found){
                        for (Item j = s.itemList; j != null; j = j.next){   // scan items
                            MDFA.MDFAState m = (MDFA.MDFAState)this.mac.table[j.dot]; // machine state
                            if ((FAtables.ACCEPTING & m.status) != 0){         // a reduction
                                if (((ELR1Item)j).la.get(sy)){
                                }
                            }
                            for (Trans t = m.transList; t != null; t = t.next){      // scan edges
                                if (t.sym != sy+tab.tokBase) continue;
                            }
                        }
                    }
                }
            }
            if (conflicts > 0) this.conflicts = true;
        }

        /**
         * Scan the items of the specified state and store in the specified array
         * the save bits.
         *
         * @param    s state
         * @param    save array
         */

        // ELR1FA
        @Override
        protected void storeSaveBits(LR0State s, int[] save){
            for (Item j = s.itemList; j != null; j = j.next){
                MDFA.MDFAState q = (MDFA.MDFAState)this.mac.table[j.dot];
                for (Item k = q.itemList; k != null; k = k.next){
                    int dot = k.dot;
                    int sym = tab.grammar[dot];
                    if (sym < tab.tokBase) continue;
                    if (sym >= tab.ruleBase) continue;
                    // dot in front of token
                    if (boolGet(tab.storeLex,dot)){     // string to be stored
                        save[sym] |= ParserLRTables.SAVELEX;
                    }
                    if (boolGet(tab.storePoint,dot)){   // point to be stored
                        save[sym] |= ParserLRTables.SAVEPOS;
                    }
                }
            }
        }

        /**
         * Scan the items of the specified state and store in the specified row
         * at the lookahead places the rules to reduce.
         *
         * @param    s state
         * @param    row row
         */

        // ELR1FA
        @Override
        protected void storeReductions(LR0State s, IntVector[] row){
            for (Item j = s.itemList; j != null; j = j.next){
                MDFA.MDFAState q = (MDFA.MDFAState)this.mac.table[j.dot];
                if ((FAtables.ACCEPTING & q.status) == 0) continue;   // not a final state
                BitSet la = ((ELR1Item)j).la;
                if (la == null) continue;
                int len = la.length();
                // n.b. reductions that have no lookaheads are removed
                for (int k = 0; k < len; k++){
                    if (!la.get(k)) continue;
                    int val = ParserLRTables.ISREDUCE | j.index;
                    row[k+tab.tokBase].add(val);
                }
            }
        }

        /**
         * Build the ELR1FA.
         */

        // ELR1FA
        @Override
        void build(){
            this.machines = new NFA();
            ParserLRTables lrt = (ParserLRTables)tab.pilot;
            this.machines.lrt = lrt.new LR0FAtables();
            this.machines.lrt.tab = tab;
            this.machines.trc = this.trc;
            this.machines.build(this.machinesNts,this.enclosingRule);  // build the NFA machines

            this.mac = new MDFA();
            this.mac.lrt = lrt.new LR0FAtables();
            this.mac.lrt.tab = tab;
            this.mac.trc = this.trc;
            this.mac.machines = this.machines;
            this.mac.build(this.machinesNts);       // build the DFA machines

            int dot = 0;
            if (!this.enclosingRule){
                int startsym = tab.grammar[tab.startRule];
                dot = this.mac.ntToDfaStates[startsym].number;
            } else {
                dot = this.mac.ntToDfaStates[tab.numOfNts-1].number;
            }
            buildPilot(dot);

            compactTables();                        // produce the compact tables
        }
    }

    //--------- ELR1+ ----------------

    /**
     * The ELR(1)+. An ELR(1) with items with the index to the predecessor.
     * The index is set to 0 for the rules that have no REs.
     */

    /*
     * Here we have the various kinds of elr1 tables, all with leftpointers.
     *
     * The kind of tables depends on elr1kind (default: 2)
     *
     *   elr1 left mach. rhl enclo additem normal (le = predecessor)    add    hop compact
     *   kind ptrs esNts on  sing              left        rhl          clos       redu
     *     1    y    y        y                le          0            l: -1      itmnr|fixed
     *     2    y             y                RE? 0:le    0            l: -1      itmnr|fixed
     *     3    y    y    y   y    le.rhl<MRL? le.left     le.rhl+1                itmnr|rhl|nt
     *                             else        le          1            l: -1
     *     4    y         y   y    RE?rhl<MRL? le.left     le.rhl+1                itmnr|rhl|nt
     *                                else     le          1
     *                             else        -1          le.rhl+1     l: -1
     *     5    y    y        y    left: 1?leftmark:le+1   0            l: m|n -m  itmnr|key
     *
     * When adding items, there can be two items with the same dot and different leftpointers:
     *  - they have overlapping lookaheads: the second is not added since it may lead to
     *    produce an infinite number of states (this is a convercence conflict)
     *  - they have non overlapping lookaheads: then the lookaheads are different, and
     *    the second item is added
     *
     * With elr1kind=5, LEFTMARK in the left field of items is used to know that an item is
     * the first of a chain, and then when adding a successor, if the predecessor is the first
     * of the chain, 0 is set as leftpointer, otherwise its number. This means that in a chain
     * the first is marked, the second has leftpointer 0 and the others have leftpointers.
     * The first item is never used to make reductions, and this relieves to visit it.
     * I have called this "Pilot I draft 11" because in that pilot the first item has pik _|_,
     * which here is LEFTNULL (that is used only to trace) and the second item has pik 0,
     * and the others the predecessor.
     */

    class ELR1PFA extends ELR1FA implements Serializable {

        /** The mark that flags the beginning of a left chain. */
        private static final int LEFTMARK = 1 << 30;

        /** The null value of a leftpointer. */
        private static final int LEFTNULL = 0x3fffffff;

        /** The number of elements to peel off a reduction. */
        private static final int MRL = 3;

        /** Table that tells the machine states that have REs in at least one rule they reduce. */
        protected byte[] stateRE;

        /**
         * An item.
         */

        protected class ELR1PItem extends ELR1Item {

            /** The index of the predecessor item (aka leftpointer). */
            protected int left;

            /** The reduction handle lengths of the items. */
            protected int rhl;

            /**
             * Deliver a new item with the specified dot, lookahead and leftpointer.
             *
             * @param   dot dot
             * @param   la lookahead
             * @param   left leftpointer
             * @param   rhl length of the reduction handle, if reduction item
             * @return  item
             */

            protected ELR1PItem(int dot, BitSet la, int left, int rhl){
                super(dot,la);
                this.left = left;
                this.rhl = rhl;
            }

            /**
             * Tell if this object is equal to the specified one.
             *
             * @param   other object
             * @return  <code>true</code> if equal, <code>false</code> otherwise
             */

            @Override
            boolean equals(Item other){
                ELR1PItem oth = (ELR1PItem)other;
                return this.dot == other.dot &&
                    this.la.equals(oth.la) &&
                    this.left == oth.left &&
                    this.rhl == oth.rhl;
            }

            /**
             * Tell if this object is equivalent to the specified one when building next states.
             *
             * @param   other object
             * @return  <code>true</code> if equivalent, <code>false</code> otherwise
             */

            @Override
            boolean equivalent(Item other){
                ELR1PItem oth = (ELR1PItem)other;
                return this.dot == other.dot &&
                    this.left == oth.left &&
                    (((ELR1PFAtables)lrt).rhlOn ? (this.rhl == oth.rhl) : true);
            }

            /**
             * Deliver a string representing this item.
             *
             * @return  string
             */

            @Override
            public String toString(){
                StringBuilder sb = new StringBuilder();
                sb.append(this.index);
                sb.append(" <");
                MDFA.MDFAState m = (MDFA.MDFAState)mac.table[this.dot];
                sb.append(m.name());
                sb.append(",");
                sb.append(tokSetToString(this.la));
                sb.append(",");
                int le = this.left;
                String lestr = null;
                if (((ELR1PFAtables)lrt).elr1kind == 5){
                    if ((LEFTMARK & le) != 0){
                        le &= ~LEFTMARK;
                        lestr = le + "!";
                    }
                    if (le == LEFTNULL){
                        lestr = "_|_";
                    } else {
                        lestr = le + "";
                    }
                } else {
                    lestr = le + "";
                }
                sb.append(lestr);
                sb.append(";");
                sb.append(this.rhl);
                sb.append(">");
                return sb.toString();
            }
        }

        /**
         * Deliver a new item with the specified dot.
         *
         * @param   dot dot
         * @return  item
         */

        // ELR1PFA
        @Override
        protected ELR1Item newItem(int dot){
            int EOF = tab.numOfToks;
            BitSet la = new BitSet();
            la.set(EOF);
            int le = 0;
            if (((ELR1PFAtables)lrt).elr1kind == 5){
                le = LEFTMARK|LEFTNULL;
            }
            return new ELR1PItem(dot,la,le,0);
        }

        /**
         * Deliver a new item with the specified dot and lookaheads.
         *
         * @param   dot dot
         * @param   la lookahead
         * @return  item
         */

        // ELR1PFA
        protected ELR1Item newItem(int dot, BitSet la){
            int le = 0;
            if (((ELR1PFAtables)lrt).elr1kind == 5){
                le = LEFTMARK|LEFTNULL;
            }
            return new ELR1PItem(dot,la,le,0);
        }

        /**
         * Deliver a new item with the dot advanced with respect to the specified one
         * for the specified symbol (used when there are machines).
         *
         * @param   other other item
         * @param   sym symbol
         * @return  item
         */

        // ELR1PFA
        @Override
        protected ELR1Item newAdvItem(Item other, int sym){
            ELR1PItem item = (ELR1PItem)other;
            MDFA.MDFAState q = (MDFA.MDFAState)mac.table[item.dot];
            for (Trans t = q.transList; t != null; t = t.next){  // scan edges
                if (t.sym != sym) continue;
                BitSet las = new BitSet();
                las.or(item.la);

                int le = 0;
                int rhl = 0;
                int dot = t.nextState.number;
                ELR1PItem pred = (ELR1PItem)other;
                switch (((ELR1PFAtables)lrt).elr1kind){
                case 1:
                    le = pred.index;
                    break;
                case 2:
                    if (boolGet(this.stateRE,dot)){     // the new state (dot) is one of a rule that has REs
                        le = pred.index;
                    }
                    break;
                case 3:
                    if (pred.rhl < MRL){
                        le = pred.left;
                        rhl = pred.rhl+1;
                    } else {
                        le = pred.index;
                        rhl = 1;
                    }
                    break;
                case 4:
                    if (boolGet(stateRE,dot)){     // the new state (dot) is one of a rule that has REs
                        if (pred.rhl < MRL){
                            le = pred.left;
                            rhl = pred.rhl+1;
                        } else {
                            le = pred.index;
                            rhl = 1;
                        }
                    } else {
                        le = -1;
                        rhl = pred.rhl+1;
                    }
                    break;
                case 5:
                    if ((LEFTMARK & pred.left) == 0) le = pred.index+1;
                    break;
                }

                return new ELR1PItem(dot,las,le,rhl);
            }
            return null;
        }

        /**
         * Build the table that tells if a rule has REs in its right part,
         * and mark the states.
         */

        // ELR1PFA
        protected void buildRuleRE(){
            ELR1PFAtables lr = (ELR1PFAtables)this.lrt;
            lr.ruleRE = newBits(tab.ruleToNt.length);               // allocate table
            for (int i = 0; i < tab.ruleIndex.length; i++){
                int nt = tab.ruleToNt[i];
                boolean hasRE = false;
                if (tab.ntKind[nt] != 0){                           // internal one
                    if (i == tab.ruleIndex.length-1) continue;      // enclosing rule
                    hasRE = true;
                } else {
                    for (int p = tab.ruleIndex[i]; tab.grammar[p] < tab.ruleBase; p++){
                        int gp = tab.grammar[p];
                        if (gp >= tab.tokBase) continue;            // not a nt
                        if (tab.ntKind[gp] != 0){                   // group
                            hasRE = true;
                        }
                    }
                }
                if (hasRE){
                    boolSet(lr.ruleRE,i);
                }
            }

            // reckon the states of the machines that have at least a final item
            // representing a rule that has REs
            this.stateRE = newBits(this.mac.lrt.stateNr);            // allocate table
            for (MDFA.MDFAState s = (MDFA.MDFAState)this.mac.head;
                s != null; s = (MDFA.MDFAState)s.suc){
                for (Item i = s.itemList; i != null; i = i.next){
                    int p = i.dot;
                    while (tab.grammar[p] < tab.ruleBase) p++;       // get to the sentinel
                    int rule = tab.grammar[p]-tab.ruleBase;
                    if (boolGet(lr.ruleRE,rule)){
                        boolSet(this.stateRE,s.number);
                        break;
                    }
                }
            }
        }

        /**
         * Scan the items of the specified state and store in the specified row
         * at the lookahead places the rules to reduce.
         *
         * @param    s state
         * @param    row row
         */

        // ELR1PFA
        @Override
        protected void storeReductions(LR0State s, IntVector[] row){
            ELR1PFAtables lr = (ELR1PFAtables)this.lrt;
            for (Item j = s.itemList; j != null; j = j.next){
                MDFA.MDFAState q = (MDFA.MDFAState)this.mac.table[j.dot];
                if ((FAtables.ACCEPTING & q.status) == 0) continue;   // not a final state
                BitSet la = ((ELR1Item)j).la;
                if (la == null) continue;
                int len = la.length();
                // n.b. reductions that have no lookaheads are removed
                for (int k = 0; k < len; k++){
                    if (!la.get(k)) continue;
                    int val = ParserLRTables.ISREDUCE;
                    int nt = ((MDFA.MDFAState)q.startState).nt;
                    switch (lr.elr1kind){
                    case 1:
                        val |= (j.index << ParserLRTables.BEFSHIFTS) | nt;
                        if (boolGet(lr.ruleRE,q.redRule)){
                            val |= ParserLRTables.RULEFIXED;
                        }
                        break;
                    case 2:
                        val |= (j.index << ParserLRTables.BEFSHIFTS) | q.redRule;
                        if (boolGet(lr.ruleRE,q.redRule)){
                            val |= ParserLRTables.RULEFIXED;
                        }
                        break;
                    case 3:
                    case 4:
                        val |= (j.index << ParserLRTables.BEFSHIFTS) | ((ELR1PItem)j).rhl | (nt << ParserLRTables.NTSHIFTS);
                        break;
                    case 5:
                        int key = j.index + 1;      // index of final item (+1 because 0 reserved)
                        int left = ((ELR1PItem)j).left;
                        if ((LEFTMARK & left) != 0){
                            key = 0;
                        }
                        val |= (nt << ParserLRTables.BEFSHIFTS) | key;
                        break;
                    }
                    row[k+tab.tokBase].add(val);
                }
            }
        }

        /**
         * Build the ELR1PFA.
         */

        // ELR1PFA
        @Override
        void build(){
            ELR1PFAtables lr = (ELR1PFAtables)this.lrt;
            if (options != null && options.length() > 0){
                lr.elr1kind = options.charAt(0) - '0';
            }
            switch (lr.elr1kind){
            case 1:
            case 5:
                break;
            case 2:
                this.machinesNts = false;
                break;
            case 3:
                lr.rhlOn = true;
                break;
            case 4:
                this.machinesNts = false;
                lr.rhlOn = true;
                break;
            }
            this.enclosingRule = true;
            this.trc = ParserLR.this.trc;
            this.machines = new NFA();
            ParserLRTables lrt = (ParserLRTables)tab.pilot;
            this.machines.lrt = lrt.new LR0FAtables();
            this.machines.lrt.tab = tab;
            this.machines.trc = this.trc;
            this.machines.build(this.machinesNts,this.enclosingRule);  // build the NFA machines

            this.mac = new MDFA();
            this.mac.lrt = lrt.new LR0FAtables();
            this.mac.lrt.tab = tab;
            this.mac.trc = this.trc;
            this.mac.machines = this.machines;
            this.mac.build(this.machinesNts);       // build the DFA machines
            buildRuleRE();                          // build table of rules that have REs

            int dot = 0;
            if (!this.enclosingRule){
                int startsym = tab.grammar[tab.startRule];
                dot = this.mac.ntToDfaStates[startsym].number;
            } else {
                dot = this.mac.ntToDfaStates[tab.numOfNts-1].number;
            }
            buildPilot(dot);

            // build the hop table
            lr.stateHop = new int[lr.stateNr][];
            for (int i = 0; i < this.table.length; i++){
                ELR1State s = (ELR1State)this.table[i];
                int n = 0;
                for (Item j = s.itemList; j != null; j = j.next){
                    n++;
                }
                lr.stateHop[i] = new int[n];
                n = 0;
                for (ELR1PItem j = (ELR1PItem)s.itemList; j != null; j = (ELR1PItem)j.next){
                    lr.stateHop[i][n] = j.left;
                    if (lr.elr1kind == 5){
                        lr.stateHop[i][n] &= ~LEFTMARK;
                    }
                    n++;
                }
            }

            compactTables();                        // produce the compact tables
        }
    }

    //--------- ELR1RN ----------------

    /**
     * The ELR(1) RN tables for the RNGLR parser that uses ELR1 tables.
     */

    /*
     * These are the tables for the rnglr-ebnf optimized, which has sets of leftpointers.
     * This is an optimized version with respect to the one in rnglrParser: it has leftpointers
     * as sets of indexes, not as pairs, and thus state equality requires equality of leftpointers,
     * not merging them. This can lead to some states more.
     *
     * In any pilot state there is only one item with the same dot, and the lookaheads are merged,
     * and the leftpointers too.
     *
     * If elr1kind == 1, equality of items does not consider lookaheads. This means that when
     * building the pilot, and checking if there is a state equal to the candidate state, one
     * that has the same dots is sufficient.
     * But here the step-by-step algorithm is not applied to LR1 states to merge their lookaheads,
     * but to LR0 states computing the lookaheads anew, and merging them when another state with
     * the same core is found. This means that there is no need to compute the LR1 states, the
     * LR0 ones are sufficient.
     */

    class ELR1RNFA extends ELR1PFA implements Serializable {

        /**
         * An item.
         */

        protected class ELR1RNItem extends ELR1Item {

            /** The sets of the indexes of predecessor items (aka leftpointers). */
            protected IntSet leftSet;

            /**
             * Deliver a new item with the specified dot, lookahead and leftpointer.
             *
             * @param   dot dot
             * @param   la lookahead
             * @param   left leftpointer
             * @return  item
             */

            protected ELR1RNItem(int dot, BitSet la, int left){
                super(dot,la);
                if (left >= 0){
                    this.leftSet = new IntSet(left);
                } else {
                    this.leftSet = new IntSet();
                }
            }

            /**
             * Tell if this object is equal to the specified one.
             *
             * @param   other object
             * @return  <code>true</code> if equal, <code>false</code> otherwise
             */

            @Override
            boolean equals(Item other){
                ELR1RNItem oth = (ELR1RNItem)other;
                if (this.dot != other.dot) return false;
                if (((ELR1RNFAtables)lrt).elr1kind == 2){
                    if (!this.la.equals(oth.la)) return false;
                }
                return this.leftSet.equals(oth.leftSet);
            }

            /**
             * Tell if this object is equivalent to the specified one when building next states.
             *
             * @param   other object
             * @return  <code>true</code> if equivalent, <code>false</code> otherwise
             */

            @Override
            boolean equivalent(Item other){
                ELR1RNItem oth = (ELR1RNItem)other;
                return this.dot == other.dot;
            }

            /**
             * Deliver a string representing this item.
             *
             * @return  string
             */

            @Override
            public String toString(){
                StringBuilder sb = new StringBuilder();
                sb.append(this.index);
                sb.append(" <");
                MDFA.MDFAState m = (MDFA.MDFAState)mac.table[this.dot];
                sb.append(m.name());
                sb.append(",");
                sb.append(tokSetToString(this.la));
                sb.append(",");
                sb.append(this.leftSet);
                sb.append(">");
                if ((FAtables.ACCEPTING & m.status) != 0){    // a final state
                    sb.append("f");
                }
                if ((MDFA.MDFAState.RNTAIL & m.status) != 0){       // a reduction tate
                    sb.append("r");
                }
                return sb.toString();
            }

            /**
             * Tell if this object is adequate (i.e. it has a unique predecessor).
             *
             * @return  <code>true</code> if adequate, <code>false</code> otherwise
             */

            boolean isAdequate(){
                return this.leftSet == null || (this.leftSet.size() <= 1);
            }
        }

        /**
         * A state.
         */

        protected class ELR1RNState extends ELR1State {

            /**
             * Tell if this object is equal to the specified one.
             *
             * @param   other object
             * @return  <code>true</code> if equal, <code>false</code> otherwise
             */

            @Override
            public boolean equals(Object other){
                if (this.accessingSymbol != ((ELR1RNState)other).accessingSymbol) return false;
                boolean res = super.equals(other);
                return res;
            }

            /**
             * Add an item if not already present.
             *
             * @param   item item
             * @return  reference to the added item if already present and if its lookaheads changed
             */

            @Override
            protected ELR1RNItem addItem(Item item){
                ELR1RNItem eitem = (ELR1RNItem)item;
                ELR1RNItem itm = (ELR1RNItem)appendItem(item);
                BitSet laAdded = new BitSet();
                if (item != itm){                  // already present
                    laAdded.or(eitem.la);
                    laAdded.andNot(itm.la);        // newly added lookaheads
                    BitSet l = new BitSet();       // merge lookaheads
                    l.or(itm.la);
                    l.or(eitem.la);
                    itm.la = latable.add(l);
                    itm.leftSet.add(eitem.leftSet);     // merge leftpointers
                } else {
                }
                if (laAdded.isEmpty()) itm = null;
                return itm;
            }
        }

        /**
         * Deliver a new state;
         *
         * @param   sym accessing symbol
         * @return  state
         */

        // ELR1RNFA
        @Override
        protected ELR1State newState(int sym){
            ELR1RNState s = new ELR1RNState();
            s.accessingSymbol = sym;
            return s;
        }

        /**
         * Deliver a new item with the specified dot.
         *
         * @param   dot dot
         * @return  item
         */

        // ELR1RNFA
        @Override
        protected ELR1Item newItem(int dot){
            int EOF = tab.numOfToks;
            BitSet la = new BitSet();
            la.set(EOF);
            return new ELR1RNItem(dot,la,-1);
        }

        /**
         * Deliver a new item with the specified dot and lookaheads.
         *
         * @param   dot dot
         * @param   la lookahead
         * @return  item
         */

        // ELR1RNFA
        protected ELR1Item newItem(int dot, BitSet la){
            return new ELR1RNItem(dot,la,-1);
        }

        /**
         * Deliver a new item with the dot advanced with respect to the specified one
         * for the specified symbol.
         *
         * @param   other other item
         * @param   sym symbol
         * @return  item
         */

        // ELR1RNFA
        @Override
        protected ELR1RNItem newAdvItem(Item other, int sym){
            ELR1RNItem item = (ELR1RNItem)other;
            ELR1RNItem res = null;
            MDFA.MDFAState q = (MDFA.MDFAState)this.mac.table[item.dot];
            for (Trans t = q.transList; t != null; t = t.next){  // scan edges
                if (t.sym != sym) continue;
                BitSet las = new BitSet();
                las.or(((ELR1Item)item).la);
                int le = 0;
                ELR1RNItem pred = item;
                if (pred == null){
                    le = -1;
                } else if (boolGet(this.stateRE,t.nextState.number)){     // the new state (dot) is one of a rule that has REs
                    le = pred.index;
                }
                res = new ELR1RNItem(t.nextState.number,las,le);
                break;
            }
            return res;
        }

        /**
         * Find the final states reacheable from paths of nullable nonterminals.
         *
         * @param   node state to start the paths
         * @return  reference to the array of reached states
         */

        // ELR1RNFA
        private State[] rnReacheable(State node){
            boolean[] visited = new boolean[mac.lrt.stateNr];
            State[] tovisit = new State[mac.lrt.stateNr];
            State[] reached = new State[mac.lrt.stateNr];
            int rp = 0;
            int sp = 0;
            tovisit[sp++] = node;
            for (int i = 0; i < sp; i++){
                State m = tovisit[i];
                if ((FAtables.ACCEPTING & m.status) != 0){  // accepting state
                    reached[rp++] = m;
                }
                visited[m.number] = true;
                for (Trans e = m.transList; e != null; e = e.next){
                    // test if the edge is for a nullable nonterminal
                    if (e.sym >= tab.tokBase) continue;           // terminal
                    if (!boolGet(tab.nullable,e.sym)) continue;   // nt not nullable
                    State to = e.nextState;
                    if (!visited[to.number]){
                        tovisit[sp++] = to;
                    }
                }
            }
            return Arrays.copyOf(reached,rp);
        }

        /**
         * A walk in the machines DFAs.
         */

        private class Walk {

            /** The sequence number, for tracing. */
            private int seq;

            /** The edges of the walk. */
            private Trans[] path;

            /** The last node visited. */
            private State node;

            /** The reference to the next walk. */
            private Walk next;

            /** 
             * Construct an object.
             *
             * @param   node state to start the path
             */

            Walk(State node){
                this.node = node;
                this.path = new Trans[0];
            }

            /** 
             * Deliver a string representing this object.
             *
             * @return  string
             */

            public String toString(){
                String str = this.node.toString() + " path: [";
                for (int j = 0; j < this.path.length; j++){
                    if (j > 0) str += ",";
                    str += this.path[j].toString();
                }
                str += "]";
                return str;
            }

            /** 
             * Deliver a string representing this object in a short form.
             *
             * @return  string
             */

            private String toBrief(int start){
                String str = this.seq + ": ";
                for (int j = start; j < this.path.length; j++){
                    if (j > start) str += ", ";
                    str += tab.gramSymToString(this.path[j].sym);
                }
                return str;
            }
        }

        /** 
         * Deliver a string representing this the specified path.
         *
         * @param   path the path
         * @param   start start index in path
         * @param   end end index in path
         * @return  string
         */

        // ELR1RNFA
        private String toBrief(Trans[] path, int start, int end){
            String str = "";
            for (int j = start; j < end; j++){
                if (j > start) str += ", ";
                str += tab.gramSymToString(path[j].sym);
            }
            return str;
        }

        /** 
         * Deliver the from-node of the edge at the specified index in the path of the specified
         * walk, that starts at the specified node.
         *
         * @param   wal walk
         * @param   idx index in its path
         * @param   start node from which the path starts
         * @return  from-state
         */

        // ELR1RNFA
        private State fromState(Walk wal, int idx, State start){
            if (idx == 0){
                return start;
            }
            return wal.path[idx-1].nextState;
        }

        /** 
         * Deliver all the walks that start from the specified node and that visit
         * cycles once and end in accepting states.
         *
         * @param   mnumber number of the node
         * @return  array of walks, each being an array of nonterminal numbers
         */

        // ELR1RNFA
        private int[][] allRnWalks(int mnumber){
            MDFA.MDFAState ms = (MDFA.MDFAState)this.mac.table[mnumber];
            State startNode = ms;      // node from which all paths starts

            Walk walks = null;
            int nwalks = 0;
            int seq = 0;
            int sp = 0;
            Walk[] stack = new Walk[100];
            Walk c = new Walk(ms);
            c.seq = seq++;
            stack[sp++] = c;
            while (sp > 0){                                  // while stack not empty
                c = stack[--sp];                             // pop
                if ((FAtables.ACCEPTING & c.node.status) != 0){ // end chain
                    if (walks == null){                      // store it as a new walk
                        walks = c;
                    } else {
                        c.next = walks;
                        walks = c;
                    }
                    nwalks++;
                }

                for (Trans e = c.node.transList; e != null; e = e.next){  // scan machine edges
                    // test if the edge is for a nullable nonterminal
                    if (e.sym != this.epsilonEdge){
                        if (e.sym >= tab.tokBase) continue;               // terminal
                        if (!boolGet(tab.nullable,e.sym)) continue;       // nt not nullable
                    }
                    // disallow a same edge to appear twice
                    boolean found = false;
                    for (int j = 0; j < c.path.length; j++){
                        if (c.path[j] == e){
                            found = true;
                            break;
                        }
                    }
                    /*
                    State w = e.nextState;
                    // find the main cycle
                    boolean found = false;
                    int startseq = -1;
                    cyc: if (w == c.node){
                        // autoloop
                        for (int j = 0; j < c.path.length; j++){
                            if (c.path[j] == e){
                                TRACE(E,"allRnWalks autoloop already present\n");
                                found = true;
                                break;
                            }
                        }
                        startseq = c.path.length;
                    } else {
                        Trans[] purged = new Trans[(c.path.length - startseq)*2];
                        int purgedi = 0;
                        for (int i = c.path.length-1; i >= 0; i--){
                            if (fromState(c,i,startNode) == w){
                                startseq = i;
                                break;
                            }
                        }
                        if (startseq < 0) break cyc;
                        TRACE(E,"cycle sequence at: %s: sequence %s + %s\n",
                            startseq,c.toBrief(startseq),tab.gramSymToString(e.sym));
                        // here we must find from the beginning a sequence of arcs that is
                        // the same as the current one - once the inner loops are removed.
                        // Let's purge the current sequence of the inner loops to make this simple
                        for (int j = startseq; j < c.path.length; j++){
                            purged[purgedi++] = c.path[j];
                            // find the edge that has its to-node the same as
                            // the to-node of the current one
                            for (int m = j+1; m < c.path.length; m++){
                                if (c.path[m].nextState == c.path[j].nextState){   // inner loop
                                    // skip to this
                                    j = m;
                                }
                            }
                        }
                        purged[purgedi++] = e;
                        #ifdef DEBUG
                        if ((FL_S & this.trc) != 0){
                            Trc.out.printf("cycle sequence at: %s: purged %s\n",
                                startseq,toBrief(purged,0,purgedi));
                            Trc.out.printf("cycle walk: %s\n",toBrief(c.path,0,c.path.length));
                        }
                        #endif
                        System.arraycopy(purged,0,purged,purgedi,purgedi);
                        // then find the purged sequence in the path, purging the path on the fly
                        // find in the path the edge that is equal to the first one of the sequence
                        // and then try to match the sequence
                        sea: for (int i = 0; i < startseq; i++){
                            int purgedstart = -1;
                            for (int j = 0; j < purgedi; j++){
                                if (c.path[i] == purged[j]){
                                    purgedstart = j;
                                    break;
                                }
                            }
                            if (purgedstart < 0) continue;
                            // here the path at index i has an edge that could be the
                            // start of a cycle; let's see if it starts a cycle
                            int endcycle = -1;
                            for (int j = i+1; j < startseq; j++){
                                if (c.path[j].nextState == fromState(c,i,startNode)){
                                    // cycle found;
                                    endcycle = j + 1;
                                    break;
                                 }
                            }
                            if (endcycle < 0) continue;
                            // try a match
                            TRACE(E,"try match cycle at: %s-%s purgedstart %s\n",
                                i,endcycle,purgedstart);
                            int pi = purgedstart;
                            for (int j = i; j < endcycle && pi < purgedstart+purgedi; j++){
                                TRACE(E,"try compare: %s: %s with %s: %s\n",
                                    j,tab.gramSymToString(c.path[j].sym),
                                    pi,tab.gramSymToString(c.path[pi].sym));
                                if (c.path[j] != purged[pi]) continue sea;
                                pi++;
                                // skip inner loops
                                for (int m = j+1; m < endcycle; m++){
                                    TRACE(S,"try j:%s %s m: %s %s\n",
                                        j,tab.gramSymToString(c.path[j].sym),
                                        m,tab.gramSymToString(c.path[m].sym));
                                    if (c.path[m].nextState == c.path[j].nextState){
                                        // skip to this
                                        TRACE(E,"try j %s m %s skipped to: %s\n",j,m,m);
                                        j = m;
                                    }
                                }
                            }
                            if (pi == purgedstart+purgedi){
                                found = true;
                            }
                            TRACE(E,"cycle found? %s\n",found);
                            break;
                        }
                    }
                    */
                    if (found) continue;           // not a walk, cycle walked twice
                    Walk wal = new Walk(e.nextState);
                    wal.seq = seq++;
                    wal.path = Arrays.copyOf(c.path,c.path.length+1);
                    wal.path[wal.path.length-1] = e;
                    if (sp >= stack.length){
                        stack = Arrays.copyOf(stack,sp+100);
                    }
                    stack[sp++] = wal;             // push it as a new walk to process
                }
            }
            if (walks != null){
                Walk curr = walks;
                Walk prev = null;
                while (curr != null){
                    Walk next = curr.next;         // save next to step on
                    curr.next = prev;              // reverse the link
                    prev = curr;
                    curr = next;
                }
                walks = prev;                      // store the head link
            }
            int[][] paths = new int[nwalks][];
            int k = 0;
            for (Walk i = walks; i != null; i = i.next, k++){
                int[] p = new int[i.path.length];
                for (int j = 0; j < i.path.length; j++){
                    p[j] = i.path[j].sym;
                }
                paths[k] = p;
            }
            return paths;
        }

        /**
         * Scan the items of the specified state and store in the specified row
         * at the lookahead places the rules to reduce.
         *
         * @param    s state
         * @param    row row
         */

        // ELR1RNFA
        @Override
        protected void storeReductions(LR0State s, IntVector[] row){
            // store first the normal reductions and then the rn ones to make lr static faster
            // i.e. on isle states the only reduction to make in lr static mode is the non-lr
            // one, and it is the first
            for (int p = 0; p < 2; p++){
                for (Item j = s.itemList; j != null; j = j.next){
                    MDFA.MDFAState q = (MDFA.MDFAState)this.mac.table[j.dot];
                    redu: {
                        if (p == 0 && (FAtables.ACCEPTING & q.status) != 0) break redu;   // a final state
                        if (p == 1 && (FAtables.ACCEPTING & q.status) == 0 &&
                            (MDFA.MDFAState.RNTAIL & q.status) != 0) break redu;      // a reduction state
                        continue;
                    }
                    BitSet la = ((ELR1Item)j).la;
                    if (la == null) continue;
                    int len = la.length();
                    // n.b. reductions that have no lookaheads are removed
                    for (int k = 0; k < len; k++){
                        if (!la.get(k)) continue;
                        int val = ParserLRTables.ISREDUCE;
                        int nt = ((MDFA.MDFAState)q.startState).nt;
                        int relq = q.number - ((ELR1RNFAtables)this.lrt).ntMacStart[nt];
                        if (q == q.startState) val |= ParserLRTables.RULEFIXED;
                        if (nt > ParserLRTables.NTMASK || relq > ParserLRTables.MACMASK || j.index > ParserLRTables.BEFMASK){
                            throw new Error("too large grammar");
                        }
                        val |= (j.index << ParserLRTables.BEFSHIFTS) | (nt << ParserLRTables.NTSHIFTS) | relq;
                        row[k+tab.tokBase].add(val);
                    }
                }
            }
        }

        /**
         * Deliver the length of all the walks from the specified start state to the
         * specified accepting state, if all their lengths are equal, or -1 otherwise.
         *
         * @param   startState start state
         * @param   accState accepting state
         * @return  string
         */

        // ELR1RNFA
        private int macReduPaths(State accState, State startState, Trans[] revarc){
            Walk walks = null;
            int nwalks = 0;
            int seq = 0;
            int sp = 0;
            Walk[] stack = new Walk[100];
            Walk c = new Walk(startState);
            c.seq = seq++;
            stack[sp++] = c;
            while (sp > 0){                                  // while stack not empty
                c = stack[--sp];                             // pop
                if (revarc[c.node.number] == null){          // end chain
                    if (walks == null){                      // store it as a new walk
                        walks = c;
                    } else {
                        c.next = walks;
                        walks = c;
                    }
                    nwalks++;
                }
                for (Trans e = revarc[c.node.number]; e != null; e = e.next){  // scan machine edges
                    State w = e.nextState;
                    // test if the new edge makes a cycle
                    boolean found = false;
                    for (int j = 0; j < c.path.length; j++){
                        if (c.path[j].nextState == w || c.path[j].nextState == startState){
                            if (w == accState){
                                return -1;
                            }
                            found = true;
                            break;
                        }
                    }
                    if (found){                    // a cycle present
                        return -1;
                    }
                    Walk wal = new Walk(e.nextState);
                    wal.seq = seq++;
                    wal.path = Arrays.copyOf(c.path,c.path.length+1);
                    wal.path[wal.path.length-1] = e;
                    if (sp >= stack.length){
                        stack = Arrays.copyOf(stack,sp+100);
                    }
                    stack[sp++] = wal;             // push it as a new walk to process
                }
            }
            // determine if all the lengths are equal
            int len = -1;
            for (Walk i = walks; i != null; i = i.next){
                if (i.node != accState) continue;
                if (len < 0){
                    len = i.path.length;
                } else {
                    if (len != i.path.length){
                        len = -1;
                        break;
                    }
                }
            }
            return len;
        }

        /**
         * Build the ELR1RNFA.
         */

        // ELR1RNFA
        @Override
        void build(){
            this.enclosingRule = true;
            // n.b. this.machinesNts set to true by default, one rule for each nt
            this.trc = ParserLR.this.trc;
            this.epsilonEdge = tab.ruleBase;
            // generate NFAs machines
            this.machines = new NFA();
            ParserLRTables lrt = (ParserLRTables)tab.pilot;
            this.machines.lrt = lrt.new LR0FAtables();
            this.machines.lrt.tab = tab;
            this.machines.trc = this.trc;
            this.machines.build(this.machinesNts,this.enclosingRule);  // build the NFA machines

            // transform NFAs machines into DFAs
            this.mac = new MDFA();
            this.mac.lrt = lrt.new LR0FAtables();
            this.mac.lrt.tab = tab;
            this.mac.trc = this.trc;
            this.mac.machines = this.machines;
            this.mac.build(this.machinesNts);       // build the DFA machines

            ELR1RNFAtables lr = (ELR1RNFAtables)this.lrt;
            lr.ntMacStart = new int[this.mac.ntToDfaStates.length];
            for (int i = 0; i < this.mac.ntToDfaStates.length; i++){
                if (this.mac.ntToDfaStates[i] == null) continue;
                lr.ntMacStart[i] = this.mac.ntToDfaStates[i].number;
            }

            // mark the machine states that have rn reductions
            // and compute the rn tails (i.e. sequences of nt numbers)
            lr.rnTails = new int[this.mac.table.length][][];
            lr.ntRnTails = new int[tab.numOfNts][][];
            for (int i = 0; i < this.mac.table.length; i++){
                MDFA.MDFAState s = (MDFA.MDFAState)this.mac.table[i];
                State[] rnreached = rnReacheable(s);
                if (rnreached.length > 0){
                    s.status |= MDFA.MDFAState.RNTAIL;
                    lr.rnTails[i] = allRnWalks(i);
                }
                if (s.startState == s){             // initial state
                    lr.ntRnTails[s.nt] = lr.rnTails[i];
                }
            }

            // build the table that for each machine accepting state tells
            // the length of the reduction, if all the paths to initial state
            // have the same length, and -1 otherwise

            lr.derlen = new int[this.mac.table.length];
            lr.rnDerlen = new int[this.mac.table.length];
            // build the arcs of the machines in the opposite direction
            Trans[] revarc = new Trans[this.mac.lrt.stateNr];
            for (int i = 0; i < this.mac.lrt.stateNr; i++){
                State st = this.mac.table[i];
                for (Trans t = st.transList; t != null; t = t.next){
                    Trans e = new Trans(t.sym,st);
                    e.next = revarc[t.nextState.number];   // prepend
                    revarc[t.nextState.number] = e;
                }
            }
            this.stateRE = newBits(this.mac.lrt.stateNr);           // allocate table
            for (int i = 0; i < this.mac.table.length; i++){
                MDFA.MDFAState q = (MDFA.MDFAState)this.mac.table[i];
                int length = -1;
                if ((FAtables.ACCEPTING & q.status) != 0){          // a final state
                    length = macReduPaths(q.startState,q,revarc);
                }
                lr.derlen[i] = length;
                length = -1;
                if ((FAtables.ACCEPTING & q.status) != 0 ||         // a final state
                    (MDFA.MDFAState.RNTAIL & q.status) != 0){    // a reduction state
                    length = macReduPaths(q.startState,q,revarc);
                    if (length < 0){
                        boolSet(this.stateRE,q.startState.number);
                    }
                }
                lr.rnDerlen[i] = length;
                if (length > lr.maxRnDerlen) lr.maxRnDerlen = length;
            }

            // mark all the states of the machine if there is one that
            // has variable-length reductions
            for (int i = 0; i < this.mac.table.length; i++){
                MDFA.MDFAState q = (MDFA.MDFAState)this.mac.table[i];
                if (boolGet(this.stateRE,q.startState.number)){
                    boolSet(this.stateRE,q.number);
                }
            }

            lr.macnames = new String[this.mac.table.length];
            for (int i = 0; i < this.mac.table.length; i++){
                lr.macnames[i] = this.mac.table[i].name();
            }

            lr.elr1kind = 1;                   // enable isles and LR modes
            if (options != null && options.length() > 0){
                lr.elr1kind = options.charAt(0) - '0';
            }

            int dot = this.mac.ntToDfaStates[tab.numOfNts-1].number;
            buildPilot(dot);
            if (lr.elr1kind < 2){
                buildLalrLa();
            }
            if (lr.elr1kind == 1){
                detectSubLalr();
            }

            // build the hop table, i.e. the table of leftpointers
            lr.stateHops = new int[this.lrt.stateNr][];
            int n = 0;
            for (int i = 0; i < this.table.length; i++){
                LR1State s = (LR1State)this.table[i];
                int ni = 0;
                for (ELR1RNItem j = (ELR1RNItem)s.itemList; j != null; j = (ELR1RNItem)j.next){
                    int nptr = (int)j.leftSet.size();
                    if (nptr > 0){
                        n += j.leftSet.size() + 1;
                    }
                    ni++;
                }
                lr.stateHops[i] = new int[ni];
            }
            lr.stateHopt = new int[n];
            n = 0;
            for (int i = 0; i < this.table.length; i++){
                LR1State s = (LR1State)this.table[i];
                for (ELR1RNItem j = (ELR1RNItem)s.itemList; j != null; j = (ELR1RNItem)j.next){
                    int[] lef = j.leftSet.toArray();
                    int nptr = lef.length;
                    if (nptr == 0){
                        lr.stateHops[i][j.index] = -1;
                    } else {
                        lr.stateHops[i][j.index] = n;
                        for (int k = 0; k < lef.length; k++){
                            lr.stateHopt[n++] = lef[k];
                        }
                        lr.stateHopt[n++] = -1;        // sentinel
                    }
                }
            }

            compactTables();                        // produce the compact tables

        }
    }

    //--------- LALRGRN ----------------

    /**
     * The LALRG(1) Structured RN tables for the RNGLR parser that uses LALRGRN tables.
     */

    /*
     * These are the tables for the rnglr-ebnf structured, but unlike the ELR1RN, has
     * the machines integrated into the pilots: pilots are built directy adding the items
     * of groups.
     *
     * In any pilot state there is only one item with the same dot, and the lookaheads are merged.
     *
     * Equality of items does not consider lookaheads. This means that when building the pilot,
     * and checking if there is a state equal to the candidate state, one that has the same
     * dots is sufficient.
     * Here the step-by-step LALR algorithm is not applied to LR1 states to merge their lookaheads,
     * but to LR0 states computing the lookaheads anew, and merging them when another state with
     * the same core is found. This means that there is no need to compute the LR1 states, the
     * LR0 ones are sufficient.
     *
     * Options (lr1Kind):
     *    b0:  isles
     *    b1:  isles for ambiguous tokens (states with them are not adequate)
     *    b2:  disambiguation
     */

    // DO NOT CHANGE THESE

    /* Reductions
     *
     *  - Reductions must find the gss nodes that have the predictions of the rules that are
     *    completed. A possible solution could be to keep a map from rules to gss nodes of
     *    the predictions. When a gss node is processed that has a reduction to make, the map
     *    is looked for to find the nodes that contain the prediction. Once they have been
     *    found, they are used to make the nonterminal shifts and then removed from the map.
     *    There is, though, a need to mark somehow the entries because we must be sure that
     *    they are in the same paths that depart from reductions. E.g. there can be two
     *    predictions, but only one be reacheable from a reduction to make.
     *    That mark could be a backpointer or a unique prediction number stored in states.
     *    Even better, it could be the index of the nodes that contains the predictions, in
     *    which case when a reduction has to be done, there would be no need to visit paths
     *    to make the nonterminal shifts. Carrying along such marks is not complex, but disposing
     *    the ones that are no longer needed seems not simple. Perhaps at the end of a level
     *    the marks that have been used to make reductions can be disposed.
     *    A node with a state with predictions launches the matching of rules. Some of them
     *    do not match, and some succeed. The latter produce a nonterminal shift. The issue
     *    then is to detect when they match, but the same rule could be launched by several
     *    nodes. Even thinking that I can dispose the mark when a reduction is made, the
     *    handing down of marks and the disposal do not seem any simpler than visiting the
     *    reduction paths.
     *    Moreover, a successor state could have a prediction for a rule that is being already
     *    predicted, which means that I must distinguish them so that when a reduction comes
     *    is applied only to the right one.
     *    All this seems too complex.
     *
     * -  In rnglre (and elr1p) to find the length of a variable reduction I used leftpointers
     *    to make leftchains to visit until the end is found, which is the end of the reduction.
     *    The question is if it is possible to do that with some other means, e.g. visiting the
     *    chain of nodes of the gss and the states in them and testing if a state contains the
     *    prediction of the wanted rule. The problem could be that there could be states that
     *    contain it before the wanted one is found.
     *    If that is the case, can perhaps I add some number to the prediction item that I
     *    carry along in advanced items so that I can spot the correct lookback state?
     *    This perhaps could make the spotting easier. And perhaps reduce also the number of
     *    states because either there is no such mark, or it is less varying than leftpointers.
     *    I found cases in which there is such intermediate state that can feign as the start
     *    but it is not. It was done by visiting rnglre pilots and taking the ones that have
     *    initial 0_X machine states and following all the paths to next states thru transitions
     *    made with arcs labelled with 0_X arcs, taking then the successor item in them and
     *    repeating.
     *    If such next states contain an item with the very same 0_X state, then we have found it.
     *    Cycles should not be visited. This occurs also here without machines.
     *    The examples are tg32.28, and tg36.11 without machines, but the initial items are the
     *    ones of the body of the groups. The reasoning applies to normal rules, not to the group
     *    ones that have predicted items in all their states.
     *    The thing is that if the very same group is predicted another time in a state that has
     *    the successor of that group, what would happen? perhaps that the body items have several
     *    leftpointers? This could happen with normal rules too.
     *    But then if I use the marks said above, then an item could have several.
     *    The advantage of such marks is that there is only a need to see if a state has an item
     *    with the desired mark, no need to know which. A comb table could tell it. I could try
     *    and see the statistics of the pilots.
     *    Let's say that the marks are unique for each prediction in the pilot. Then when visiting
     *    paths we have only to stop when a state is found that has the same mark as the one
     *    attached to the reduction item, or visit several paths if the reduction item has several
     *    marks (or perhaps we can associate to a reduction state a set of marks and search the
     *    paths that have them).
     *    Even if this would work, there would still be a need to visit the paths and at each step
     *    make an intersection of sets, which is not simpler than following the leftpointers.
     * 
     *  - a new way to make reduction has been discovered, which does not need leftpointers:
     *    fixed reductions are made using all the paths of fixed length down to the desired
     *    edge, while variable reductions are make using all the paths whose edges are labelled
     *    with the group body, and end in a state in which there is an arc for the nonterminal
     *    groups.
     *
     * Items for groups
     *
     *  - these are the items for groups:
     *
     *      - RES:   &0 -> . &1     added &0 -> &1 .     added extra &0 -> . &1
     *               &0 -> .
     *      - REP:   &0 -> . &1     added &0 -> &1 .     added extra &0 -> . &1
     *      - REL:   &0 -> . &1 &1  added &0 -> &1 &1 .  added extra &0 -> &1 . &1
     *
     *    {:n} with all bypasses to the end should be done by parserbnf, but it is not
     *    strictly needed since I produce anyway the proper forest.
     *    The items serve to build states, they are not for showing or for complying to recursive
     *    rules that represent groups, e.g. .{a}* {.a}* {a.}* {a}*.  and what if there were no
     *    parentheses? or . &0  .&0 &1, etc. two are sufficient: one that has the dot in front of
     *    the body and another that has the dot after the group. In such case there is a need
     *    compute the lookaheads in a dedicated way because a &1.  must have as lookaheads also
     *    the ones of . &1.
     *    {}, (n) and [] do not need leftpointers
     *
     *  - I made an attempt to mimic the items that are in states when machines are used.
     *    E.g. a*:
     *        item 0_A, succ 1_A
     *        item 1_A, succ 1_A
     *        all final
     *    could be repserented by:
     *        item &0 ::= .&1, succ &0 ::= &1.
     *        item &0 ::= &1., succ &0 ::= &1.
     *        all final
     *    This would produce states that have the same amount of items as with machines.
     *    There would be items that are final and still have successors, and also the rn ones.
     *    With ordinary items instead there are 2 items in the first state and 2 in the second,
     *    i.e. twice.
     *    However, to do it there is a need to define:
     *        - newAdvItem (2 methods),
     *        - isFinal(),
     *        - getshifts(),
     *        - closure(): must consider &1. as initial
     *    It turns out to be more complex than adding the extra items and considering them
     *    normal items: only addItem is affected.
     *
     *  - for * there is a &1. on each state of the loop because we want to have bodies
     *    delimited, unlike rnglre.
     *
     * Notes
     *
     *  - the accessingsymbol unicity on states is needed here and also in rnglre
     *
     *  - closure() adds predicted items for the rules that are in the grammar. I.e., if there
     *    is a rule &0 -> &0 &1, it adds . &0 &1, and here this is not what perhaps I want.
     *    Note that to cater for missing right contexts in &1, it adds also some lookaheads to
     *    cope with the fact that &1 can be followed by others.
     *    This should do no harm here, but if I introduce a dedicated closure() here, it
     *    could be incorporated in the new items added.
     *    Why this was not done here?
     *    Perhaps when the dot is in front of a &0 of a star, closure() should instead add . &1.
     *    For all groups that have an upper limit there is no problem (i.e. (l:u), (:u)m, [], (),
     *    (n)), the extra items are with *, +, and the second rule of (l:).
     *
     *  - closure adds the missing right contexts:
     *    Lookaheads are handed over on advanced items so as to be defined on the final ones to
     *    drive reductions. They are defined first on predicted items, which are introduced
     *    by closure(). The kind of &1 for repetition groups were changed so as to tell the ones
     *    that needed the extra contexts. I did not define their kind as BOR in ParserBnf
     *    because this is the only place in which there is a need to tell a &1 that is the one
     *    of a repetition group, while in all other places that is not needed, and it would then
     *    be necessary to test both BOD an BOR. But I could compute the right contexts without
     *    this testing the kind of the &0 that uses it: it is the one introduced before it.
     *    I set BOR also on these in ParserGen.
     *
     *  - convergence conflicts are irrelevant here because we do not bother about conflicts.
     */

    /** Whether isles should be detected. */
    static final int OPT_ISLES = 1;

    /** Whether isles should not contain ambiguous terminals. */
    static final int OPT_ISLES_AMB = 1 << 1;

    /** Whether disambiguation is done. */
    static final int OPT_DISAM = 1 << 2;

    class LALRGRNFA extends LR1FA implements Serializable {

        protected class LALRGRNItem extends LR1Item {

            /**
             * Deliver a new item with the specified dot and lookahead.
             *
             * @param   dot dot
             * @param   la lookahead
             * @return  item
             */

            protected LALRGRNItem(int dot, BitSet la){
                super(dot,la);
            }

            /**
             * Tell if this object is equal to the specified one.
             *
             * @param   other object
             * @return  <code>true</code> if equal, <code>false</code> otherwise
             */

            @Override
            boolean equals(Item other){
                LALRGRNItem oth = (LALRGRNItem)other;
                if (this.dot != other.dot) return false;
                return true;
            }

            /**
             * Tell if this object is equivalent to the specified one when building next states.
             *
             * @param   other object
             * @return  <code>true</code> if equivalent, <code>false</code> otherwise
             */

            @Override
            boolean equivalent(Item other){
                LALRGRNItem oth = (LALRGRNItem)other;
                return this.dot == other.dot;
            }

            /**
             * Deliver a string representing this item.
             *
             * @return  string
             */

            @Override
            public String toString(){
                return String.format("%s [%s,%s]",this.dot,
                    tab.ruleToString(this.dot,true),tokSetToString(this.la));
            }

            /**
             * Tell if this object is adequate (i.e. it has a unique predecessor).
             *
             * @return  <code>true</code> if adequate, <code>false</code> otherwise
             */

            boolean isAdequate(){
                return true;
            }
        }

        /**
         * A state.
         */

        protected class LALRGRNState extends LR1State {

            /**
             * Tell if this object is equal to the specified one.
             *
             * @param   other object
             * @return  <code>true</code> if equal, <code>false</code> otherwise
             */

            @Override
            public boolean equals(Object other){
                if (this.accessingSymbol != ((LALRGRNState)other).accessingSymbol) return false;
                boolean res = super.equals(other);
                return res;
            }

            /**
             * Add an item if not already present and if the grammar has group items,
             * and the item is that of a group, add the additional group item.
             *
             * @param   item item
             * @return  reference to the added item
             */

            @Override
            protected LR1Item addItem(Item item){
                LALRGRNItem litem = (LALRGRNItem)item;
                LALRGRNItem itm1 = (LALRGRNItem)appendItem(item);
                BitSet laAdded = new BitSet();
                if (itm1 != item){                          // item already present
                    laAdded.or(litem.la);
                    laAdded.andNot(itm1.la);                // newly added lookaheads
                    BitSet l = new BitSet();                // merge lookaheads
                    l.or(itm1.la);
                    l.or(litem.la);
                    itm1.la = latable.add(l);
                } else {
                }
                LR1Item res = itm1;
                LALRGRNItem itm2 = null;
                gr: {
                    if (itm1 != item) break gr;             // already added both
                    int sy = tab.grammar[item.dot];
                    int p = item.dot-1;
                    int gp = tab.grammar[p];
                    if (gp >= tab.ruleBase){                // added a predicted item
                        break gr;
                    }
                    // the item just added is x y . w z, and here p
                    // is at x . y w z   and gp = y  and  sy = w
                    if (gp < tab.tokBase &&                     // nt
                        tab.ntKind[gp] == ParserTables.BOR){    // there is a y
                        if ((ParserTables.LEFTGROUPS & tab.mode) != 0){
                            if (sy >= tab.ruleBase){            // old item x y w .
                                p--;                            // extra x y . w
                            } else {
                                break gr;
                            }
                        } else {
                            if (sy < tab.ruleBase){             // old item x y . w z
                                if (tab.grammar[p+2] <          // z present
                                    tab.ruleBase) break gr;     // do not add extra final item
                                p++;                            // old item x y . w, extra x y w .
                            } else {                            // old item x y w .
                                p--;                            // extra x y . w
                            }
                        }
                        LALRGRNItem gitem = (LALRGRNItem)newItem(p+1,itm1.la);
                        itm2 = (LALRGRNItem)appendItem(gitem);
                        if (itm2 != gitem){                 // already present
                            BitSet l = (BitSet)gitem.la.clone();
                            l.andNot(itm2.la);              // newly added lookaheads
                            laAdded.or(l);                  // total newly added lookaheads
                            l.clear();                      // merge lookaheads
                            l.or(itm2.la);
                            l.or(gitem.la);
                            itm2.la = latable.add(l);
                        }
                    }
                } // gr
                if (itm2 != null && itm2.index < itm1.index){
                    res = itm2;                             // the earliest, to restart processing
                }
                if (laAdded.isEmpty()) res = null;
                return res;
            }
        }

        /**
         * Deliver a new item with the specified dot.
         *
         * @param   dot dot
         * @return  item
         */

        // LALRGRNFA
        @Override
        protected LALRGRNItem newItem(int dot){
            int EOF = tab.numOfToks;
            BitSet la = new BitSet();
            la.set(EOF);
            return new LALRGRNItem(dot,la);
        }

        /**
         * Deliver a new item with the specified dot and lookaheads.
         *
         * @param   dot dot
         * @param   la lookaheads
         * @return  item
         */

        // LALRGRNFA
        @Override
        protected LALRGRNItem newItem(int dot, BitSet la){
            return new LALRGRNItem(dot,la);
        }

        /**
         * Deliver a new item with the dot advanced with respect to the specified one.
         *
         * @param   other other item
         * @return  item
         */

        // LALRGRNFA
        @Override
        protected LALRGRNItem newAdvItem(Item other){
            BitSet la = new BitSet();
            la.or(((LALRGRNItem)other).la);
            int nt = other.lhs();
            int dot = other.dot + 1;
            return new LALRGRNItem(dot,la);
        }

        /**
         * Deliver a new state;
         *
         * @param   sym accessing symbol
         * @return  state
         */

        // LALRGRNFA
        @Override
        protected LALRGRNState newState(int sym){
            LALRGRNState s = new LALRGRNState();
            s.accessingSymbol = sym;
            return s;
        }

        /**
         * Scan the items of the specified state and store in the specified row
         * at the lookahead places the rules to reduce.
         *
         * @param    s state
         * @param    row row
         */

        // LALRGRNFA
        @Override
        protected void storeReductions(LR0State s, IntVector[] row){
            // store first the normal reductions and then the rn ones to make lr static faster
            // i.e. on isle states the only reduction to make in lr static mode is the non-lr
            // one, and it is the first
            for (int p = 0; p < 2; p++){
                scan: for (Item j = s.itemList; j != null; j = j.next){
                    int beforeDot = 0;
                    int rno = 0;
                    boolean fixed = true;
                    int nt = 0;
                    redu: {
                        nt = j.lhs();
                        if (p == 0 && j.isFinal()){          // a final item
                            if (tab.ntKind[nt] <= ParserTables.REU){
                                fixed = false;
                                break redu;
                            }
                            int end = j.dot;
                            while (tab.grammar[end] < tab.ruleBase) end++;
                            rno = tab.grammar[end]-tab.ruleBase;
                            beforeDot = tab.ruleLen[rno];
                            break redu;
                        }
                        if (p == 1 && !j.isFinal()){
                            if (tab.ntKind[nt] <= ParserTables.REU){
                                continue scan;
                            }
                            // find the end of the item to compute the number of elements
                            // before the dot and at the same time if after the dot there is
                            // a rn part
                            for (int k = j.dot;; k++){
                                int el = tab.grammar[k];
                                if (el >= tab.ruleBase){                // end of rule found
                                    rno = el - tab.ruleBase;
                                    int rlen = tab.ruleLen[rno];
                                    beforeDot = rlen - (k - j.dot);
                                    break;
                                }
                                if (el >= tab.tokBase ||                // token, or not nullable nt
                                    !boolGet(tab.nullable,el)){
                                    continue scan;
                                }
                            }
                            break redu;
                        }
                        continue;
                    } // redu

                    BitSet la = ((LR1Item)j).la;
                    if (la == null) continue;
                    int len = la.length();
                    // n.b. reductions that have no lookaheads are removed
                    for (int k = 0; k < len; k++){
                        if (!la.get(k)) continue;
                        int val = 0;
                        if (fixed){
                            val |= rno + tab.ruleBase;
                            if (val > ParserLRTables.GPMASK || beforeDot > ParserLRTables.ELMASK){
                                throw new Error("too large grammar");
                            }
                            val |= (beforeDot << ParserLRTables.ELSHIFTS);
                            if (beforeDot == 0) val |= ParserLRTables.EMPTYMASK;
                        } else {
                            val |= nt;
                            if (j.isInitial()) val |= ParserLRTables.EMPTYMASK;
                        }
                        val |= ParserLRTables.ISREDUCE;
                        row[k+tab.tokBase].add(val);
                    }
                }
            }
        }

        /**
         * Tell if the specified act set of tokens contains tokens that belong to some
         * tokens set that has in it other tokens that belong to act. I.e. if there
         * are tokens in act that trigger several actions.
         *
         * @param    act set of tokens
         * @return   <code>true<code> if there are such tokens, <code>false<code> otherwise
         */

        // LALRGRNFA
        @Override
        protected boolean isTokenAmbiguous(BitSet act){
            LALRGRNFAtables lr = (LALRGRNFAtables)this.lrt;
            if ((lr.lr1kind & OPT_ISLES_AMB) == 0){
                return false;
            }
            boolean res = false;
            // visit all the tokens for which there is an action
            l: for (int i = act.nextSetBit(0); i >= 0; i = act.nextSetBit(i+1)){
                for (int tl = 0; tl < tab.tokLists.length; tl++){
                    char[] tset = tab.tokLists[tl];
                    if (tset == null) continue;
                    if (tset.length == 1) continue;    // a single one
                    boolean found = false;
                    for (int t = 0; t < tset.length; t++){
                        if (tset[t] == i){             // a set containing it
                            found = true;
                            break;
                        }
                    }
                    if (!found) continue;
                    for (int t = 0; t < tset.length; t++){
                        if (tset[t] == i) continue;    // skip itself
                        if (act.get(tset[t])){         // found an action
                            res = true;
                            // Trc.out.printf("isTokenAmbiguous act %s token set %s\n",
                            //    tokSetToString(act),tab.tokSetToString(tset));
                            break l;
                        }
                    }
                }
            }
            return res;
        }

        /**
         * Build the LALRGRNFA.
         */

        // LALRGRNFA
        @Override
        void build(){
            this.trc = ParserLR.this.trc;
            LALRGRNFAtables lr = (LALRGRNFAtables)this.lrt;
            lr.lr1kind = OPT_ISLES;            // enable isles and LR modes
            if (options != null && options.length() > 0){
                lr.lr1kind = options.charAt(0) - '0';
            }
            if (tab.isOption("-tokenSets")){   // do not do the token sets check in isles
                lr.lr1kind &= ~OPT_ISLES_AMB;
            }
            // build the pilot
            buildPilot(tab.startRule);         // build the pilot
            buildLalrLa();
            detectSubLalr();
            lr.isFrontierStates = null;

            compactTables();                   // produce the compact tables

            lr.longestRule = 0;
            for (int i = 0; i < tab.ruleLen.length; i++){
                if (tab.ruleLen[i] > lr.longestRule) lr.longestRule = tab.ruleLen[i];
            }

            maxReDepth();                      // compute max subexpression depth

            packStates();                      // build the tables of items in states

        }

        /** The maximum RE subexpression depth in the current rule. */
        int maxReDepth;

        /**
         * Visit the rules of the non-implicit nonterminals and determine the max nesting
         * depths of subexpressions.
         */

        private void maxReDepth(){
            tab.maxReDepth = 0;
            for (int rn = 0; rn < tab.ruleIndex.length; rn++){
                int nt = tab.ruleToNt[rn];
                if (nt >= tab.ntNrGroups) continue;
                this.maxReDepth = 0;
                vi_max(rn,0);
                if (this.maxReDepth > tab.maxReDepth){
                    tab.maxReDepth = this.maxReDepth;
                }
            }
        }

        /**
         * Visit the specified rule and determine the maximum depth of subexpression.
         *
         * @param      rn rule number
         * @param      lev current depth
         */

        private void vi_max(int rn, int lev){
            if (lev > this.maxReDepth){
                this.maxReDepth = lev;
            }
            for (int p = tab.ruleIndex[rn];
                tab.grammar[p] < tab.ruleBase; p++){     // scan rule
                int gp = tab.grammar[p];
                if (gp >= tab.tokBase) continue;         // terminal
                if (gp < tab.ntNrGroups) continue;       // nt not internal
                for (int rulenr = tab.ntToRule[gp];      // scan all its rules
                    (rulenr < tab.numOfRules + 1) &&
                    (tab.ruleToNt[rulenr] == gp); rulenr++){
                    int l = lev + 1;
                    if (tab.ntKind[gp] >= ParserTables.BOD){
                        l = lev;                         // one level more in the rules
                    }
                    vi_max(rulenr,l);
                }
            }
        }

        /**
         * Build the table of items in states.
         */

        private void packStates(){
            int[] index = new int[this.lrt.stateNr];
            int loc = this.lrt.stateNr;
            for (int i = 0; i < this.lrt.stateNr; i++){
                LALRGRNState s = (LALRGRNState)this.table[i];
                index[s.number] = loc;
                loc++;             // for the number of items
                int n = 0;
                for (LALRGRNItem j = (LALRGRNItem)s.itemList; j != null; j = (LALRGRNItem)j.next){
                    n++;
                }
                loc += n;
            }
            int[] dots = new int[loc];
            ((LALRGRNFAtables)this.lrt).stateDots = dots;
            System.arraycopy(index,0,dots,0,this.lrt.stateNr);
            loc = this.lrt.stateNr;
            for (int i = 0; i < this.lrt.stateNr; i++){
                LALRGRNState s = (LALRGRNState)this.table[i];
                int locnr = loc++;          // number of items
                int n = 0;
                for (LALRGRNItem j = (LALRGRNItem)s.itemList; j != null; j = (LALRGRNItem)j.next){
                    dots[loc++] = j.dot;
                    n++;
                }
                dots[locnr] = n;
            }

            int[][] ntdata = null;
            for (int i = 0; i < tab.numOfNts - tab.ntNrGroups - 1; i++){
                int nt = tab.ntNrGroups+i;
                if (tab.ntKind[nt] >= ParserTables.BOD) continue;
                if (ntdata == null){
                    ntdata = new int[tab.numOfNts - tab.ntNrGroups][];
                }
                int[] data = new int[4];
                int body = tab.body(nt);
                int body2 = -1;
                int l = 0;
                if (tab.ntKind[nt] == ParserTables.REL || tab.ntKind[nt] == ParserTables.REF){
                    l = tab.ruleLen[tab.ntToRule[nt]];
                } else if (tab.ntKind[nt] == ParserTables.RER){
                    int ru = tab.ntToRule[nt];
                    for (int p = tab.ruleIndex[ru];; p++){
                        int gp = tab.grammar[p];
                        if (tab.ntKind[gp] == ParserTables.OBO){
                            l = (p - tab.ruleIndex[ru]);
                            break;
                        }
                    }
                } else if (tab.ntKind[nt] == ParserTables.REP){
                    l = 1;
                }
                int u = 0;
                if (tab.ntKind[nt] == ParserTables.RER || tab.ntKind[nt] == ParserTables.REU ||
                    tab.ntKind[nt] == ParserTables.REF){
                    int rn = tab.ntToRule[nt];
                    u = tab.ruleLen[rn];
                    if (tab.ntKind[nt] == ParserTables.RER){
                        body2 = tab.grammar[tab.ruleIndex[rn]+u-1];
                    } else {
                        body = tab.grammar[tab.ruleIndex[rn]];   // &2
                    }
                } else if (tab.ntKind[nt] == ParserTables.GRO){
                    l = 1;
                    u = 1;
                } else if (tab.ntKind[nt] == ParserTables.OPT){
                    l = 0;
                    u = 1;
                }
                ntdata[i] = new int[]{l,u,body,body2};
            }
            ((LALRGRNFAtables)this.lrt).ntGroupData = ntdata;
        }
    }


    /**
     * Compute what rules are nullable and how many nullable rules each nt has.
     * Compute also which rule generate only the empty string.
     */

    private void computeNullable(){
        this.tab.nullableNtRules = new int[this.tab.numOfNts];
        this.tab.nullableRules = newBits(this.tab.ruleToNt.length); // allocate array of nullable rules
        for (int i = 0; i < this.tab.numOfNts; i++){
            if (!boolGet(this.tab.nullable,i)){
                continue;                                           // not a nullable nt
            }
            // scan all the rules of this nt
            int nullrules = 0;
            for (int j = this.tab.ntToRule[i]; j < this.tab.ruleToNt.length; j++){
                if (this.tab.ruleToNt[j] != i) break;
                // scan this rule
                boolean isnullable = true;
                for (int d = this.tab.ruleIndex[j]; this.tab.grammar[d] < this.tab.ruleBase; d++){
                    int el = this.tab.grammar[d];
                    if (el >= this.tab.tokBase ||                     // terminal
                        !boolGet(this.tab.nullable,el)){              // not a nullable nt
                        isnullable = false;
                        break;
                    }
                }
                if (isnullable){
                    boolSet(this.tab.nullableRules,j);
                    nullrules++;
                }
            }
            this.tab.nullableNtRules[i] = nullrules;
        }
        this.tab.eonlyRules = newBits(this.tab.ruleToNt.length); // allocate array of nullable rules
        for (int i = 0; i < this.tab.numOfNts; i++){
            if (!boolGet(this.tab.nullable,i)){
                continue;                                        // not a nullable nt
            }
            // scan all the rules of this nt
            int nullrules = 0;
            for (int j = this.tab.ntToRule[i]; j < this.tab.ruleToNt.length; j++){
                if (this.tab.ruleToNt[j] != i) break;
                // scan this rule
                boolean isnullable = true;
                for (int d = this.tab.ruleIndex[j]; this.tab.grammar[d] < this.tab.ruleBase; d++){
                    int el = this.tab.grammar[d];
                    if (el >= this.tab.tokBase ||                // terminal
                        !boolGet(this.tab.eonly,el)){            // not a nt that produces only the empty
                        isnullable = false;
                        break;
                    }
                }
                if (isnullable){
                    boolSet(this.tab.eonlyRules,j);
                }
            }
        }
    }

    /**
     * Build a FA in accordance with the kind and options.
     */

    void build(){
        ParserLRTables lrt = new ParserLRTables();
        this.tab.pilot = lrt;
        FA res = null;
        switch (this.kind){
        case LR0:
            res = new LR0FA();
            res.lrt = lrt.new LR0FAtables();
            break;
        case LR1:
            res = new LR1FA();
            res.lrt = lrt.new LR1FAtables();
            break;
        case LALR:
            res = new LALRFA();
            res.lrt = lrt.new LALRFAtables();
            break;
        case LALRRN:
            res = new LALRRNFA();
            res.lrt = lrt.new LALRRNFAtables();
            computeNullable();
            break;
        case ELR1:
            res = new ELR1FA();
            res.lrt = lrt.new ELR1FAtables();
            break;
        case ELR1P:
            res = new ELR1PFA();
            res.lrt = lrt.new ELR1PFAtables();
            break;
        case ELR1RN:
            res = new ELR1RNFA();
            res.lrt = lrt.new ELR1RNFAtables();
            break;
        case LALRGRN:
            res = new LALRGRNFA();
            res.lrt = lrt.new LALRGRNFAtables();
            computeNullable();
            break;
        }
        res.trc = this.trc;
        res.lrt.tab = this.tab;
        res.lrt.options = this.options;
        res.build();
        this.fa = res;
        lrt.lrTables = res.lrt;
    }
}
