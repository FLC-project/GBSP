/*
 * @(#)FormFloat.java       1.0 98/11/04
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;
import java.text.*;
import java.math.*;
import lbj.Formatter.*;

/**
 * The <code>FormFloat</code> class provides formatting for floating
 * point numbers for a <code>Formatter</code>.
 *
 * @author  Angelo Borsotti
 * @version 1.0   04 Nov 1998
 */

public class FormFloat {

    /* Trace flags. */
    private static final int FL_D = 1 << ('d'-0x60);
    private static final int FL_F = 1 << ('f'-0x60);

    /*
     * Floating points by now are converted by using the very inefficient
     * Float or Double class methods.  There would be a need for better
     * methods to format floating point numbers, which take the mantissa
     * and the exponent and format them.
     * <p>
     * Taken a DecimalFormat, to control the external representation there
     * is a need to set:
     * <ul>
     * <li>min fractional (it sets the max automatically)
     * <li>min integral
     * <li>scientific representation and min nr of exponent digits
     * <li>decimal separator always shown
     * <li>grouping used/not-used
     * <li>grouping size
     * <li>decimal separators
     * <li>minus sign symbol
     * <li>locale digits
     * <li>the position of the currency symbol: before, or after the number
     *   both for positive and negative.
     * <li>whether there is a space or not between the number and currency
     * <li>if the currency symbol separates the sign and the number
     * <li>the use of the local or the international one
     * <li>the removal of the currency
     * </ul>
     * <p>
     * An array of LocNumdata is kept. The use of DecimalFormat is too heavy
     * and too inflexible.
     * <p>
     * The minimum number of digits in the fraction is inserted if the format
     * is free (and only in this case because when the format is fixed the
     * fraction, which is unpredictably long, can occupy the whole field.
     * The same for exponent, but also in fixed format because the number of
     * digits is low.
     * The effect of printing all decimals is that this can produde a lot
     * of digits for some numbers. However, if there is a need to limit it,
     * the decimal qualifier should be used.
     * <p>
     * g|G qualifiers: the normal notation is used if it does not produce a
     * number which has too many digits, and the scientific one if the
     * fractional part is too long or the integral part greater than the one
     * specified.
     * <p>
     * Since getval with FRM_DOUBLE delivers a double out of any value which
     * can be casted to it, there is no need here to make a special case for
     * float values.
     * <p>
     * The use of parentheses for negative values is not a locale dependent
     * feature, but a general one for monetary values. In some locales it
     * is the only one allowed. The `(' qualifier selects the parentheses
     * anyway.
     * <p>
     * A currency formatter is taken, the prefix and postfix got, its data
     * extracted, new prefixes and suffixes determined, a pattern applied,
     * the affixes, grouping, etc., set and the value formatted.
     * <p>
     * A floating point binary number, strictly speaking, represents a decimal
     * number which can have a lot of digits. This results in having values
     * which are not evenly spaced in the decimal base. Since, however, a binary
     * floating point number represents also the numbers which lay in an
     * interval around it, one can also choose in it the decimal number with
     * the smallest number os significant digits in the hope to have a better
     * number repertoire, hoping also that there are no holes and that the
     * operations could be implemented in such a way as to provide values
     * which are correct in that system. E.g. if one takes the binary values
     * which represent 0.1 and 0.2 and sum them he wants to obtain a value
     * which represents 0.3, and not let the errors sum so as to lead to a
     * floating binary number which represents 0.4.  However, even if this
     * property does not hold, the best that can be done is to represent a
     * flating point number with the decimal one that lays close to it and
     * that has less digits.
     * <p>
     * A number can be converted to and from the fixed point notation and
     * the scientific one in the following way. First, since there is a need not
     * to loose digits, a floating notation should be obtained by scaling the
     * number so as to make it have one integral digit (without making it
     * overflow or underflow). Then, the desired fixed point notation can be
     * obtained by placing the decimal point in its place and rounding, and the
     * scientific notation can be obtained by placing it in the specified place
     * and adjusting the exponent accordingly. This is not simple for values
     * which are close to the borders, and perhaps it is also not simple to
     * choose always the number which is closest to the base 2 floating point
     * one and that has the minimum number of digits. Thus these operations
     * are directly done on the decimal representation.
     * <p>
     * It is not simple how to find the decimal number which falls within
     * the interval denoted by a floating point binary number that has the
     * minimum number of digits, and how to find the closest when there are
     * several. Since these conversions do not occur often, it would be better
     * to have simpler, but well understood algorithms.
     * <p>
     * Formatting of percentages: the percent formatter is a DecimalFormatter
     * with a specific pattern that, however, seems incorrect for the locales
     * that want suffix -. Therefore it is not used, and the percent sign
     * included instead.
     * <p>
     * The technique used is to determine the intrinsic characteristics
     * for a locale so a to keep them the first time that locale is used.
     * When formatting a number, they are changed on the basis of
     * the qualifiers and used to format it.
     * <p><blockquote><pre>
     *       intrinsic               qualifiers
     *
     *       GroupingSeparator;
     *       GroupingSize;
     *       DecimalSeparator;
     *       MonetaryDecimalSeparator;
     *       ZeroDigit;
     *       ExponentialSymbol
     *       position of minus sign
     *       PositivePrefix          if (qu.sign != ' ') "+"
     *       PositiveSuffix
     *       NegativePrefix
     *       NegativeSuffix
     *       Infinity;               if ((qualMap['L'] & qu.pres) != 0) "1/0"
     *       NaN;                    if ((qualMap['L'] & qu.pres) != 0) "NaN"
     * </pre></blockquote><p>
     * In order to avoid to process a long string, the Float.toString or
     * the Double.toString methods are used, which provide the scientific
     * notation when the number is big. The string obtained is then processed
     * to scale, truncate, and localise it.
     *
     * @param      frm the formatter
     */

    static void float_cbk(Formatter frm){
        Cdata   qu = frm.cptr;
        char    code;
        char    ch;
        double  v = 0;                         // value to be converted
        int     i;
        int     len;
        boolean patt;                          // true if pattern mode
        boolean expo = false;                  // true if m.nEee used
        char    kind;
        char    decSep = '.';
        char    curDecSep = '.';
        char    thou = ',';
        boolean group = false;
        int     fract = 0;                     // nr of fractional digits
        String  infinity;
        String  nan;
        char    groupSep;
        LocNumData    locData = null;
        DecimalFormat nf = null;

        code = qu.formt[qu.pfor++];
        kind = 'n';
        ch = qu.formt[qu.pfor];
        if (ch == 'm'){                              // monetary
            kind = 'c';
            qu.pfor++;
        }
        patt = false;
        if (ch == 'P'){                              // pattern
            qu.pfor++;
            patt = true;
            qu.eptr = qu.extRep;
            qu.pfor = frm.skip_format(               // get pattern
                Formatter.F_SPEC,0,0);
            frm.frmGetQuals(null);
        } else if (kind == 'n'){
            frm.frmGetQuals(FLOAT_QUALS);
        } else {
            frm.frmGetQuals(MONE_QUALS);
        }
        frm.handleLocale('n');                       // obtain locale
        locData = frm.nlArr[frm.locNum];
        if (kind == 'c'){                            // the currency one
            if (locData.space == 0){
                locData.monetary(
                    NumberFormat.getCurrencyInstance
                        (frm.locArr[frm.locNum]));
            }
        }
        curDecSep = locData.decSep;
        if (kind == 'c'){                            // the currency one
            curDecSep = locData.monDecSep;
        }
        groupSep = locData.groupSep;
        infinity = locData.infinity;
        nan = locData.nan;
        if ((Formatter.qualMap['L'] & qu.pres) != 0){   // ASCII only
            if (groupSep == '\u00a0'){
                groupSep = ' ';
            }
            infinity = "Inf";
            nan = "NaN";
        }
        locSet: {
            if (patt){
                try {
                    nf = new DecimalFormat(
                        String.valueOf(qu.extRep,0,qu.erLength),
                        new DecimalFormatSymbols(frm.locArr[frm.locNum]));
                } catch (IllegalArgumentException e) {
                    frm.error(Formatter.ERR_FORMAT);
                }
                break locSet;
            }

            if (kind == 'n'){
                group = qu.thou != '\0';
            } else {
                group = qu.thou == '\0';
            }
            fract = -1;
            if (qu.decimal >= 0){                        // fix precision
                fract = qu.decimal;
            } else if (qu.minw != 0){
                fract = 6;
            }
        }
        while (qu.repfact-- > 0){
            byte       valtype;
            BigDecimal big = null;
            boolean    negative = false;
            String     numstr = null;
            int        exp = 0;
            int        off;
            int        rem;
            int        k;
            int        ep;
            int        grCount;
            int        grSize;
            int        epFirst;                 // index of first digit
            int        integr;                  // nr of integral digits
            boolean    special = false;

            valtype = frm.getElemType();
            if ((FL_D & frm.trc) != 0){
                Trc.out.println("valtype: " + valtype);
            }
            switch (valtype){
            case Formatter.FRM_FLOAT:
                frm.getval(Formatter.FRM_FLOAT);
                float f = qu.val_float;
                numstr = infinity;
                special = true;
                if (f == Float.NEGATIVE_INFINITY){
                    negative = true;
                } else if (Float.isNaN(f)){
                    numstr = nan;
                } else if (f != Float.POSITIVE_INFINITY){
                    numstr = Float.toString(f);
                    special = false;
                }
                break;
            case Formatter.FRM_BIGDEC:
                frm.getval(Formatter.FRM_BIGDEC);
                big = (BigDecimal)(qu.val_obj);
                if (patt){
                    v = big.doubleValue();
                } else {
                    numstr = big.toString();
                }
                break;
            case Formatter.FRM_STRING:
                frm.getval(Formatter.FRM_STRING);
                numstr = (String)(qu.val_obj);
                break;
            default:
                frm.getval(Formatter.FRM_DOUBLE);
                v = qu.val_double;
                numstr = infinity;
                special = true;
                if (v == Double.NEGATIVE_INFINITY){
                    negative = true;
                } else if (Double.isNaN(v)){
                    numstr = nan;
                } else if (v != Double.POSITIVE_INFINITY){
                    numstr = Double.toString(v);
                    special = false;
                }
            }
            if (special){
                ep = qu.extRep.length;
                qu.erLength = ep;
                ep = insAffix(negative,false,qu,locData,ep,kind);
                len = numstr.length();                       // determine length
                numstr.getChars(0,len,qu.extRep,ep-len);
                ep -= len;
                epFirst = ep;
                if (kind == 'c'){                            // the currency one
                    ep = insAffix(negative,true,qu,locData,ep,kind);
                } else {
                    if (negative){                           // include sign
                        if (locData.minusPref){
                            qu.extRep[--ep] = locData.minusSign;
                        }
                    } else if (qu.sign == '+'){
                        qu.extRep[--ep] = '+';
                    }
                }
                qu.preflen = epFirst - ep;
                qu.mode = 0;
                frm.insert(qu.extRep,Formatter.FRM_CHARS,  // ins. in record
                    ep,qu.erLength-ep,1);
                continue;
            }
            if (patt){
                numstr = nf.format(v);
                qu.preflen = 0;
                qu.mode = 0;
                frm.insert(numstr,Formatter.FRM_STRING,
                    0,numstr.length(),1);              // insert in record
                continue;
            }
            len = numstr.length();                     // determine length
            off = 0;
            negative = false;
            if (numstr.charAt(0) == '-'){
                off = 1;
                negative = true;
            }
            int lastdig = off;                         // last sig digit
            int firstdig = -1;                         // first sig digit
            int scale = 0;
            int decsep = len;                          // decimal separator
            exp = 0;
            for (int j = off; j < len; j++){
                char c = numstr.charAt(j);
                if (c == '.'){
                    decsep = j;
                } else if (c == 'E'){                  // exponent
                    if (decsep == len) decsep = j;     // . at end
                    boolean expneg = false;
                    if (numstr.charAt(++j) == '-'){
                        j++;
                        expneg = true;
                    }
                    for (; j < len; j++){
                        c = numstr.charAt(j);
                        exp = exp*10 + (c - '0');
                        if (exp < 0) frm.error(IOError.ERR_OUTLIMIT);
                    }
                    if (expneg) exp = -exp;
                    break;
                } else if (c != '0'){
                    lastdig = j;
                    if (firstdig < 0) firstdig = j;
                }
            }
            if (firstdig < 0) firstdig = off;
            scale = lastdig - firstdig + 1;
            if ((decsep >= firstdig) &&                // . in between
                (decsep <= lastdig)){
                scale--;
            }
            int deca = decsep - firstdig;
            if ((exp > 0) == (deca > 0)){              // same sign
                if ((exp > 0) != (exp + deca > 0)){    // result diff. sign
                    frm.error(IOError.ERR_OUTLIMIT);
                }
            }
            exp += deca;
            if (firstdig > decsep) exp++;              // 0.00nnn

            // scale is the number of significant digits starting at
            // firstdig; exp is the decimal exponent; off is the start of
            // the first significant digit (first non-zero or 0 if the only 
            // one).

            if ((FL_D & frm.trc) != 0){
                Trc.out.println("off " + off + " |" + numstr + "|" +
                    " firstdig " + firstdig + " lastdig " + lastdig +
                    " decsep " + decsep + " scale " + scale +
                    " exp " + exp);
            }

            int natexp = exp;
            int carry = 0;
            int cc = 0;
            int lastfract = 0;

            deca = 0;
            if ((Formatter.qualMap['C'] & qu.pres) != 0){  // percent
                deca = 2;                                  // * 100
            } else if ((Formatter.qualMap['M'] & qu.pres) != 0){ // per mille
                deca = 3;                                  // * 1000
            }
            if (exp > 0){
                if (exp + deca < 0){
                    frm.error(IOError.ERR_OUTLIMIT);
                }
            }
            exp += deca;

            expo = false;
            switch (qu.kind){
            case 'e': case 'E': case 'g': case'G':
                expo = true;
            }
            int savexp = exp;
            if (expo){                                 // determine exp
                if (qu.integral >= 0){                 // specified
                    integr = qu.integral;
                } else {
                    integr = 1;
                }
                if (exp < 0){
                    if (exp - integr > 0){
                        frm.error(IOError.ERR_OUTLIMIT);
                    }
                }
                exp -= integr;
            } else {
                integr = exp;
            }
            if ((FL_D & frm.trc) != 0){
                Trc.out.println("exp " + exp + " integr " + integr +
                    " negative " + negative);
            }

            if (fract >= 0){                           // fixed precision
                if (integr > 0){
                    if (integr + fract < 0){
                        frm.error(IOError.ERR_OUTLIMIT);
                    }
                }
                int xxx = round(frm,numstr,firstdig,
                    integr + fract,scale,decsep);
                carry = xxx & 1;
                cc = (xxx >> 1) & 1;
                lastfract = xxx >>> 2;
                if (cc > 0){
                    if (exp > 0){
                        if (exp + 1 < 0){
                            frm.error(IOError.ERR_OUTLIMIT);
                        }
                    }
                    exp++;
                    if (!expo) integr = exp;
                    numstr = "1";
                    scale = 1;
                    firstdig = 0;
                    lastdig = 0;
                    decsep = 0;
                    carry = 0;
                    lastfract = 0;
                    if (!expo) integr = exp;
                }
            }
            if ((qu.kind == 'g') || (qu.kind == 'G')){ // N.B. after
                int expmin = -4;                       // .. rounding
                int expmax = qu.integral >= 0 ? qu.integral : 6;
                if ((exp >= expmin) && (savexp < expmax)){
                    expo = false;
                    exp = savexp;
                    integr = exp;
                }
            }

            if ((FL_D & frm.trc) != 0){
                Trc.out.println("integral: " + integr +
                    " exp " + exp + " cc " + cc + " " + lastfract);
            }
            int ilead0 = 1;                        // integral leading 0's
            int intnum = 0;                        // integral digits
            int itrail0 = 0;                       // integral trailing 0's
            int flead0 = 0;                        // fraction leading 0's
            int fracnum = 0;                       // fraction digits
            int ftrail0 = 0;                       // fraction trailing 0's

            boolean dsep = true;
            if (integr > 0){
                ilead0 = 0;
                if (integr > scale){               // 0's at end
                    itrail0 = integr - scale;
                    intnum = scale;
                } else {
                    intnum = integr;
                }
            }
            if (integr < 0){
                if (scale - integr < 0){
                    frm.error(IOError.ERR_OUTLIMIT);
                }
            }
            if (fract < 0){                        // free fraction
                fracnum = scale - integr;
                if (fracnum < 0){                  // . beyond last
                    fracnum = 0;
                } else if (integr < 0){            // . before first
                    flead0 = -integr;
                    if (flead0 < 0){
                        frm.error(IOError.ERR_OUTLIMIT);
                    }
                    fracnum = scale;
                }
            } else {                               // fixed fraction
                fracnum = scale - integr;
                if (fracnum <= 0){                 // . beyond last
                    fracnum = 0;
                    ftrail0 = fract;
                } else if (integr < 0){            // . before first
                    flead0 = -integr;
                    if (flead0 < 0){
                        frm.error(IOError.ERR_OUTLIMIT);
                    }
                    fracnum = scale;
                    if (fracnum > fract - flead0){
                        fracnum = fract - flead0;
                    }
                    if (flead0 > fract){           // . 0000x  00x truncated
                        flead0 = fract;
                        fracnum = 0;
                    }
                } else {                           // . in betwen
                    if (fracnum < fract){
                        ftrail0 = fract - fracnum;
                    } else {
                        fracnum = fract;
                    }
                }
            }
            int temp = ilead0 + intnum;
            if (temp < 0) frm.error(IOError.ERR_OUTLIMIT);
            temp += itrail0;
            if (temp < 0) frm.error(IOError.ERR_OUTLIMIT);
            temp += flead0;
            if (temp < 0) frm.error(IOError.ERR_OUTLIMIT);
            temp += fracnum;
            if (temp < 0) frm.error(IOError.ERR_OUTLIMIT);
            temp += ftrail0;
            if (temp < 0) frm.error(IOError.ERR_OUTLIMIT);
            dsep = flead0 + fracnum + ftrail0 > 0;

            // integr is the number of digits after which the decimal
            // separator should be written (0 at this point).
            // ilead0 intnum itrail0      flead0 fracnum ftrail0
            //   000     iii   000     .    000    fff     000

            if ((FL_D & frm.trc) != 0){
                Trc.out.println("ilead0 " + ilead0 +
                    " intnum " + intnum + " itrail0 " + itrail0 +
                    " flead0 " + flead0 + " fracnum " + fracnum +
                    " ftrail0 " + ftrail0 + " dsep " + dsep);
            }
            int ersize = 16;                       // -0.e-% and 10 exp digits
            if (group){
                grSize = locData.groupSize;
                temp = intnum + itrail0 + grSize;
                ersize += (temp - 1) / grSize;
                if (ersize < 0){
                    frm.error(IOError.ERR_OUTLIMIT);
                }
            } else {
                grSize = Integer.MAX_VALUE;             // never insert
            }
            ersize += intnum + itrail0;                 // integral digits
            ersize += flead0 + fracnum + ftrail0;
            if (ersize < 0){
                frm.error(IOError.ERR_OUTLIMIT);
            }
            if (kind == 'c'){                           // the currency one
                ersize += locData.affLength;
                if (ersize < 0){
                    frm.error(IOError.ERR_OUTLIMIT);
                }
            }
            temp = ersize + 2;                          // +2 for . and %
            if (temp < 0){
                frm.error(IOError.ERR_OUTLIMIT);
            }
            frm.ensure_extRep(temp,0);
            if ((FL_D & frm.trc) != 0){
                Trc.out.println("ersize: " + ersize +
                    " " + qu.extRep.length);
            }
            ep = qu.erLength;
            if ((Formatter.qualMap['C'] & qu.pres) != 0){         // percent
                qu.extRep[--ep] = locData.percent;
            } else if ((Formatter.qualMap['M'] & qu.pres) != 0){  // per mille
                qu.extRep[--ep] = locData.perMill;
            }
            if (expo){                                  // exponent now
                int e;
                ep = insAffix((exp < 0),false,qu,locData,ep,kind);
                e = exp;
                if (e < 0) e = -e;
                if (e < 0) frm.error(IOError.ERR_OUTLIMIT);
                do {
                    rem = (int)(e % 10);                // remainder
                    qu.extRep[--ep] = (char)(rem + locData.zeroDigit);
                    e /= 10;
                } while (e > 0);
                ep = insAffix((exp < 0),true,qu,locData,ep,kind);
                if ((qu.kind == 'e') || (qu.kind == 'g')){
                    qu.extRep[--ep] = Character.toLowerCase
                        (locData.expSym);
                } else {
                    qu.extRep[--ep] = locData.expSym;
                }
            }
            ep = insAffix(negative,false,qu,locData,ep,kind);

            grCount = grSize;
            char c;
            if (fract < 0){                        // free fraction
                k = lastdig;
            } else {                               // fixed fraction
                k = lastfract;
                if (lastfract == 0) k = lastdig;   // no fract digit cut
            }
            for (; ftrail0 > 0; ftrail0--){
                qu.extRep[--ep] = locData.zeroDigit;
            }
            for (; fracnum > 0; fracnum--){        // copy fraction digits
                c = numstr.charAt(k--);
                if (c == '.') c = numstr.charAt(k--);
                rem = c - '0' + carry;
                carry = (rem > 9) ? 1 : 0;
                if (rem > 9) rem = 0;
                qu.extRep[--ep] = (char)(rem + locData.zeroDigit);
            }
            for (; flead0 > 0; flead0--){
                rem = 0 + carry;
                carry = (rem > 9) ? 1 : 0;
                if (rem > 9) rem = 0;
                qu.extRep[--ep] = (char)(rem + locData.zeroDigit);
            }
            if (dsep | (qu.dradix == '!')){
                qu.extRep[--ep] = curDecSep;
            }
            for (; itrail0 > 0; itrail0--){
                if (grCount-- == 0){
                    qu.extRep[--ep] = groupSep;
                    grCount = grSize-1;
                }
                qu.extRep[--ep] = locData.zeroDigit;
            }
            for (; intnum > 0; intnum--){          // copy integral part
                c = numstr.charAt(k--);
                if (c == '.') c = numstr.charAt(k--);
                if (grCount-- == 0){
                    qu.extRep[--ep] = groupSep;
                    grCount = grSize-1;
                }
                rem = c - '0' + carry;
                carry = (rem > 9) ? 1 : 0;
                if (rem > 9) rem = 0;
                qu.extRep[--ep] = (char)(rem + locData.zeroDigit);
            }
            if (ilead0 > 0){
                if (grCount-- == 0){
                    qu.extRep[--ep] = groupSep;
                    grCount = grSize-1;
                }
                qu.extRep[--ep] = locData.zeroDigit;
            }

            if (qu.integral > 0){                     // minimum specified
                if (Character.isSpaceChar(qu.nfill))  // numeric filling
                    grCount = Integer.MAX_VALUE;
                for (k = 0; k < qu.integral-integr; k++){
                    if (grCount-- == 0){
                        qu.extRep[--ep] = groupSep;
                        grCount = grSize-1;
                    }
                    qu.extRep[--ep] = qu.nfill;
                }
            }
            epFirst = ep;
            if (kind == 'c'){                         // the currency one
                ep = insAffix(
                    negative,true,qu,locData,ep,kind);
            } else {
                if (negative){                        // include sign
                    if (locData.minusPref){
                        qu.extRep[--ep] = locData.minusSign;
                    }
                } else if (qu.sign == '+'){
                    qu.extRep[--ep] = '+';
                }
            }
            if (valtype == Formatter.FRM_STRING){
                if ((FL_F & frm.trc) != 0){
                    String s;
                    s = "" + firstdig + " " + scale + " " +
                        decsep + " " + natexp + " " +
                        exp + " " + integr + " ";
                    s += String.valueOf(qu.extRep,ep,qu.erLength-ep);
                    frm.insert(s,Formatter.FRM_STRING,  // ins. in record
                        0,s.length(),1);
                    continue;
                }
             }

            qu.preflen = epFirst - ep;
            qu.mode = 0;
            frm.insert(qu.extRep,Formatter.FRM_CHARS,   // ins. in record
                ep,qu.erLength-ep,1);
        }
    }

    /** The qualifiers for floating clauses. */
    static final long[] FLOAT_QUALS =
        {Formatter.qualSet("+nfpdL"),Formatter.qualSet("eEgG"),
        Formatter.qualSet("'^"),Formatter.qualSet("CM"),
        Formatter.qualSet("aA"),Formatter.qualSet("zZ"),
        Formatter.qualNum("i.!f"),Formatter.qualNum("n:m"),
        Formatter.qualNum("$")};

    /** The qualifiers for monetary clauses. */
    static final long[] MONE_QUALS =
        {Formatter.qualSet("icanfpdL"),Formatter.qualSet("+("),
        Formatter.qualSet("'^"),Formatter.qualSet("aA"),
        Formatter.qualSet("zZ"),Formatter.qualNum("i.!f"),
        Formatter.qualNum("n:m"),Formatter.qualNum("$")};

    /**
     * Determine if the rounding of a number increases the number of
     * integral digits.
     * If carry = 1 there is a need to propagate it starting from
     * len-scale+fract-1 down; if cc = 1, the number of integral digits will
     * become incremented because of propagation.
     *
     * @param      frm the formatter
     * @param      numstr string of the number
     * @param      firstdig index of the first digit
     * @param      fract number of fractional digits
     * @param      scale number of digits
     * @param      decsep index of the decimal separator (if any)
     * @return     carry
     */

    private static int round(Formatter frm, String numstr, int firstdig,
        int fract, int scale, int decsep){
        if ((FL_D & frm.trc) != 0){
            Trc.out.println("round: " + numstr + " fract " + fract +
                " scale " + scale);
        }
        int carry = 0;
        int cc = 0;
        int lastfract = 0;
        rnd: if ((0 <= fract) && (fract < scale)){     // within scale
            int r;
            char c;

            r = firstdig + fract;
            if (r < 0) frm.error(IOError.ERR_OUTLIMIT);
            if ((firstdig < decsep) && (decsep <= r))  // first to cut
                r++;
            if ((FL_D & frm.trc) != 0){
                Trc.out.println("round at: " + r);
            }
            c = numstr.charAt(r);
            if (c == '.') c = numstr.charAt(--r);
            r--;
            lastfract = r;
            if (c == '5'){
                if (scale-fract == 1){           // just 5
                    c = numstr.charAt(r);
                    if (c == '.'){
                        c = numstr.charAt(--r);
                    }
                    c -= '0';
                    if ((c & 1) == 0) break rnd;
                }
                carry = 1;
            } else if (c > '5'){
                carry = 1;
            }
            if ((FL_D & frm.trc) != 0){
                Trc.out.println("prop: at " + r + " carry " +
                    carry);
            }
            cc = carry;
            for (;r >= firstdig; r--){
                int rem;
                c = numstr.charAt(r);
                if (c == '.') continue;
                rem = (int)c - '0' + cc;
                cc = (rem > 9) ? 1 : 0;
            }
        }
        if ((FL_D & frm.trc) != 0){
            Trc.out.println("round cc " + cc + " carry " + carry +
               " lastfract " + lastfract);
        }
        return (lastfract << 2) | (cc << 1) | carry;
    }

    /**
     * Deliver an affix according to the one passed as argument and
     * the qualifiers passed. The affix is delivered in extRep.
     *
     * @param      neg <code>true</code> if negative
     * @param      prefix <code>true</code> if prefix
     * @param      qu qualifiers
     * @param      locData locale data
     * @param      ep index in extRep
     * @param      kind 'c' if monetary
     */

    /* The elements to insert in the affix are coded into a mask, with
     * the following convention:
     *
     *   b0:  currency sign
     *   b1:  space
     *   b2:  space
     *   b3:  (
     *   b4:  )
     *   b5:  -
     */

    static int insAffix(boolean neg, boolean prefix, Cdata qu,
        LocNumData locData, int ep, char kind){
        byte   msk;
        String csign;

        if ((Formatter.qualMap['i'] & qu.pres) != 0){
            csign = locData.intnCsign;
        } else {
            csign = locData.csign;
        }
        if (neg){
            if (kind != 'c'){                   // not the currency one
                if (prefix == locData.minusPref){
                    qu.extRep[--ep] = locData.minusSign;
                }
                return ep;
            }
            msk = (prefix) ? locData.cyNegPref : locData.cyNegSuff;
        } else {
            if (kind != 'c'){                   // not the currency one
                return ep;
            }
            msk = (prefix) ? locData.cyPosPref : locData.cyPosSuff;
        }
        if ((msk & 1) != 0){
            if ((Formatter.qualMap['c'] & qu.pres) != 0) msk &= ~(0x7);
        }
        if (neg){
            if ((Formatter.qualMap['('] & qu.pres) != 0){
                msk &= ~((1<<5) | (1<<6));
                msk |= 1 << ((prefix)? 3 : 4);
            }
        }
        if ((msk & 1<<4) != 0) qu.extRep[--ep] = ')';
        if ((msk & 1<<2) != 0) qu.extRep[--ep] = locData.space;
        if ((msk & 1) != 0){
            for (int j = csign.length() - 1; j >= 0; j--){
                qu.extRep[--ep] = csign.charAt(j);
            }
        }
        if ((msk & 1<<1) != 0) qu.extRep[--ep] = locData.space;
        if ((msk & 1<<5) != 0) qu.extRep[--ep] = locData.minusSign;
        if ((msk & 1<<3) != 0) qu.extRep[--ep] = '(';
        return ep;
    }   
}
