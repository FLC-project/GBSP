/*
 * @(#)IOBundle.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;

/**
 * The <code>IOBundle</code> class provides the English locale for
 * the <code>IOError</code> class.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

public class IOBundle extends ListResourceBundle {
    public Object[][] getContents() {
        return contents;
    }

    // LOCALIZE THIS

    public static final String[] MSGTAB = {
        "SUCCESS, successful operation",          //  0
        "IOERR, io error",                        //  1
        "ILLFILE, illegal file",                  //  2
        "OUTLIMIT, limits exceeded",              //  3
        "NOCORE, insufficient core",              //  4
        "NOTOPEN, file not open",                 //  5
        "MISMATCH, file changed underneath",      //  6
        "RENAME, file rename failure",            //  7
        "ISOPEN, file is open",                   //  8
        "NOLOC, file has not been located",       //  9
        "EXECERR, command exec failed",           // 10
        "CIRCDEF, circular definition",           // 11
        "INVOP, invalid operation",               // 12
        "NOFILE, no such file",                   // 13

        "NOSPACE, no space in record",            // 14
        "NOREC, no record",                       // 15
        "NOCHAR, missing character",              // 16
        "ILLCODE, unknown or missing code",       // 17
        "NOOPN, unmmatched )",                    // 18
        "NOCLO, ( not closed",                    // 19
        "NONUM, missing number",                  // 20
        "TOOLOW, number too low",                 // 21
        "OUTREC, cursor out of record",           // 22
        "NOTAB, no tab",                          // 23
        "TOOLRG, number too large",               // 24
        "MISMATCH, format and io list mismatch",  // 25
        "FORMAT, illegal format",                 // 26
        "STREAM, no file nor output callback",    // 27
        "SYSTEM, system error",                   // 28
        "LOCALE, no locale",                      // 29
        "NEGNUM, negative number",                // 30
        "NEST, endless recursion",                // 31
        "MISCMA, missing comma",                  // 32
        "IOLIST, illegal io list",                // 33
        "EXHAUSTED, io list exhausted",           // 34
        "INIT, not initialised",                  // 35
        "ILLTYPE, illegal type",                  // 36
        "INDEX, illegal index",                   // 37
        "VALUE, illegal value",                   // 38
        "RESOURCE, no resource",                  // 39
        "PRINTERR, PrintStream io error",         // 40
        "NOTMAIN, could not locate main file",    // 41
        "NOCREA, such a file may not be created", // 42
        "ILLCLASS, illegal class",                // 43
        "SECURITY, security violation",           // 44
        "SETTIME, time could not be changed",     // 45
        "LONGLINE, line too long",                // 46
        "ENDOFFILE, end of file",                 // 47
        "TOOMANY, too many errors",               // 48

        "ERRDET, errors detected: ",              // 49
        "DELFAIL, delete file failed",            // 50
    };

    private static final Object[][] contents = {
        {"MSGTAB",   MSGTAB},
        {"ONFILE",   "on file"},
        {"POSITION", "at position"},
        {"ONFORMAT", "in format"},
        {"PAGE",     "Page"},
        {"EOF",      "eof"},
        {"INFO",     "INFO"},
        {"WARNING",  "WARNING"},
        {"ERROR",    "ERROR"},
        {"FATAL",    "FATAL"},
        {"ERRDET",     "Errors detected:"},
        {"WARNINGS",   "warnings"},
        {"ERRORS",     "errors"},
        {"FATALS",     "fatals"},
    };

    // END OF MATERIAL TO LOCALIZE
}
