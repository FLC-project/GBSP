/*
 * @(#)CharStream.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import lbj.CharsRow;

/**
 * The <code>CharStream</code> interface provides the API for classes
 * that provide character transfer.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

/**
 * This class provides the definition of the methods for opening,
 * closing, reading and writing characters to a stream.
 */

public interface CharStream {

    /**
     * Open the stream for reading or writing.
     *
     * @param      name stream name
     * @param      enc encoding
     * @param      mode open mode
     */
 
    public void open(String name, String enc, int mode);

    /**
     * Deliver a java.io stream of this object.
     *
     * @param      mode kind of stream to be delivered
     */

    public Object getStream(int mode);

    /**
     * Close the stream.
     */

    public void close();

    /**
     * Flush all the data which are pending in the stream.
     */

    public void flush();

    /**
     * Read a sequence of characters. It delivers what data are available,
     * but no more than the amount specified, and it blocks if there are none.
     * It returns an eof if the file index is at the end of the file before
     * executing the read.
     *
     * @param      t1 return array of characters
     * @param      s1 offset at which the data are returned
     * @param      l1 maximum number of data to be read
     * @return     number of characters read
     */

    public int read(char[] t1, int s1, int l1);

    /**
     * Read a line, and deliver a reference to it.
     *
     * @param      row to the line
     */

    public void readln(CharsRow r);

    /**
     * Tell if the last read operation attempted to transfer data beyond the
     * last available one.
     *
     * @return     true if end of file
     */

    public boolean eof();

    /**
     * Deliver the number of lines read.
     *
     * @return     number
     */

    public long lines();

    /**
     * Write an array of characters.
     *
     * @param      t1 array
     * @param      s1 start index of slice in t1
     * @param      l1 length of slice
     */

    public void write(char[] t1, int s1, int l1);

    /**
     * Write an array of characters in a line.
     *
     * @see        #writeln(char[],int,int)
     */

    public void writeln(char[] t1, int s1, int l1);

    /**
     * Write a string of characters.
     *
     * @see        #write(char[],int,int)
     */

    public void write(String t1, int s1, int l1);

    /**
     * Write a string of characters.
     *
     * @see        #write(char[],int,int)
     */

    public void write(String t1);

    /**
     * Write a string of characters in a line.
     *
     * @see        #writeln(char[],int,int)
     */

    public void writeln(String t1, int s1, int l1);

    /**
     * Write a string of characters in a line.
     *
     * @see        #writeln(char[],int,int)
     */

    public void writeln(String t1);
}
