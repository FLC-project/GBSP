/*
 * @(#)ParserRnglrPdgr.jpp       1.0 2020/11/01
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;
import lbj.ParserLRTables.*;
import lbj.ParserGLRengine;

/**
 * The <code>ParserRnglrPdgr</code> class provides the RNGLR for EBNF structured parsing algorithm
 * that uses pedigrees.
 *
 * @author  Angelo Borsotti
 * @version 1.0   1 Nov 2020
 */


    // macros to access the pedigrees
/*
 * This parser accepts all CF EBNF grammars, parses texts and produces either forests
 * or, if told to disambiguate, one parse tree (the leftmost-longest one).
 * Forests and trees are structured, i.e. represent the structure of the right-hand sides
 * of the rules.
 * It handles also ambiguous tokens.
 *
 * This parser overcomes the weakness of rnglrd by storing groups with pedigrees instead
 * of using gss sppfs. Leftchains are visited by encodetree to store in the final forest
 * group (flat) derivations. Rnglrd delivered a garland when not disambiguating and a
 * garland plus getchildren to have a group view of the parse tree when disambiguating.
 * This instead delivers a group forest in both cases, that is a tree when disambiguating,
 * and still avoid the weakness of rnglre on some grammars.
 * Moreover, it treats the bounded groups, which rnglre does not (it produces wrong forests).
 * It treats also the sppfs with infinite ambiguity, that cannot be represented correctly
 * in flat forests: (A B)* with nullable A and B.
 * The proper forests and trees for EBNF can only be generated if a parser produces linear
 * chains of gss states for the elements of groups. When it instead has garlands gss it
 * cannot produce proper forests (or it is very difficult to produce them). This is what
 * rnglre and this parser do. The difference is that rnglre produces flat forests, while
 * this produces structured forests.
 * Moreover, to overcome the slowness of rnglre when processing some groups (groups for
 * which it cannot tell the end, and thus builds gss sppf for the group at each step),
 * then building of the forest is here delayed and done only at the end or at lr points.
 * This is done recording pedigrees (similarly to Earley) instead of building gss sppfs.
 *
 *
 * Testing and verification
 *
 * In traces there are a lot of numbers, and it is difficult to tell what they mean.
 * I use some prefix to distinguish them:
 *
 *       n     node
 *       e     edge
 *       n/s   node/state
 *       s     state
 *       r     rule
 *       p     pedigree
 *       i     item
 *       {l:h} cover
 *       #n    number of elements in reduction
 *
 * Flag 'o' for top-level trace, 'a' for levels, prios and trees.
 *
 * I added a testing part to this file to test the visit of paths.
 * I verified the disambiguating one with myEarley.
 *
 *
 * Measurements
 *
 * - to measure the pilot, set DEBUG and SHOW_MEASURES in ParserLR and compile it. Then run
 *   cd corpus
 *   glrmeaLR rnglrg   (or rnglrgd)
 *
 * - to measure the speed and footprint:
 *
 *   cd corpus
 *   glrmeaPtimeLex rnglrg   (or rnglrgd)
 *   N.B. isles and singletons can be disabled changing ParserFactory
 *
 * - to measure how many tokens have been parsed in what mode:
 *
 *   enable MEASURE here and recompile
 *   uncomment lastEng.statistics(Trc.wrt) in ParserScope
 *   cd corpus
 *   glrmeaPtimeLex rnglrg
 *
 * 	        rnglre	rnglrg	rnglrgd   rnglrg+isles  rnglrg-isles      rnglrg
 *			                  -singl   b/t  -singl    b/t     +all
 * javalalr.bnf	1414	1047.8	1063.78   1073.33  63.4   295.69  282.3   857.27
 * java.bnf	412	297.01	328.5     306.08   77.6   224.74  356.34  304.08
 * c.bnf	        91	39.99	42.58     41.82   452.2    37.35 1507.0    40.59
 * cpp.bnf	        205	106.61	144.25    107.42   63.9    77.05  592.6   105.56
 * freepascal.bnf	395	410.14	561.02    364.80   11.9   214.68  218.6   386.36
 * html2.bnf	833	494.4	511.87    470.58   20.1   281.43  216.4   505.43
 * html.bnf	0	0	18.69
 * gram1.bnf	0	0	0.02      0.00
 * json.bnf	1418	1211.01	1193.75   1241.00   0.4   390.03  112.1  1196.15
 * xml1.bnf	1523	1458.45	1377.01   1287.30   2.6   424.12   57.4  1135.06
 * go.bnf	        143	188.88	251.91    277.04   26.6   139.46  272.9   196.37
 *
 * rnglrg	javalalrLex.bnf	listlalr.cmd	2099.8	813.2	81759996	1002.78	63.4	1290147	154788	12241340	1385686	5988745
 * rnglrg	javaLex.bnf	listlalr.cmd	4985.6	775.4	100127284	306.43	77.6	1290147	188345	14930707	8086184	1310656
 * rnglrg	cLex.bnf	listch.cmd	139396.4	1353.8	2604112948	41.72	452.2	5758583	2144133	161598221	79269621	3267131
 * rnglrg	cppLex.bnf	listcpp.cmd	25709.4	629.2	169270624	105.59	63.9	2648287	1660367	64378387	36635751	1544674
 * rnglrg	freepascalLex.bnf	listp.cmd	3164.2	279.6	11994868	348.94	11.9	1006570	6508723	16372022	4856819	598389
 * rnglrg	html2Lex.bnf	listhh.cmd	1121.4	372.7	7065100	469.87	20.1	351784	178713	2309907	1062896	837268
 * rnglrg	gram1.bnf	gram1-32.txt	34188.8	0.3	3948484	0.00	119651.0	33	34198707	34198707	211	2
 * rnglrg	jsonLex.bnf	listjson1.cmd	9964.8	2503.7	3579504	1198.72	0.4	8943757	28149345	37170173	112	23320734
 * rnglrg	xml1Lex.bnf	model1.xml	129.5	44.8	285288	1289.65	2.6	109227	196628	196628	4	152926
 * rnglrg	goLex.bnf	golist.cmd	58915.8	4755.8	284717728	197.62	26.6	10702999	10272589	130775267	61007489	6822688
 * 
 *
 * Lexing
 *
 * Some grammars have a lexis with ambiguous lexemes, i.e. need contextual lexing.
 * A solution is to make the lexer have an initial state for each token, and an initial
 * state for each place in the grammar in which a number of tokens can occur.
 * We can define an initial state for each such place with empty edges to the initial
 * state of the possible tokens, and make the parser pass that state to the lexer.
 * Another solution is to pass to the tokenizer the set of tokens that are wanted. The
 * tokenizer then intersects it with that returned by the lexer and returns, e.g. the
 * first element. Note that in both cases there could be several tokens that meet the
 * requested ones.
 * The first solution makes the lexer search a token that belongs to the subset of
 * tokens that are allowed in the specific place in which it is called, and in the
 * subset there might be tokens that do not overlap, which could instead be the case
 * with the second solution.
 * However, at a specific point in parsing there could be several rules under matching,
 * each one with its own set of tokens. So, both solutions require either to call
 * the lexer with the union of the subsets of tokens of all the rules under matching,
 * or to call it for each such rule.
 * There is a third solution, which is to make the lexer return the sets of all tokens
 * matched, and make the parser use all of them.
 * The limit of this solution is that the lexer matches the longest lexeme starting at
 * the current input position. If there are lexemes "abc" and "abcd", and the input
 * at that position has "abcd", the lexer returns only the second lexeme, while perhaps
 * the only rule under matching would expect the first.
 * This means that this applies only to grammars that have lexemes that are properly
 * delimited, i.e. that it is possible to split a text in lexemes unambiguously even
 * if there are lexemes that can belong to several syntactic categories, i.e. tokens.
 * With this solution the parser performs all the shifts for all the lexemes matched
 * instead of just one.
 * A common case in that of a lexeme the belongs to two different tokens, like, e.g. a
 * predefined identifier, that is not a reserved word, and that in a specific rule can
 * have a specific meaning. E.g. <S> -> <id> <A> | open <B>, where "open" can be also
 * an identifier.
 * The lexer returns a number, which denotes a set of tokens, and serves to access the
 * tokSet table in ParserTables to get a vector that contains the codes of all the tokens
 * matched.
 * Let's build a table that tells all the tokens for which in a pilot state there are
 * arcs labelled with tokens to the next states, and match it with the set of returned
 * tokens. This is not full yet contextual lexing, for which the tokens matched should
 * only be the ones expected, but it is close to it.
 * Actually, the LR pilot should be sufficient, there is no need for an additional
 * table.
 * Now, the tokenizer is called at the beginning, where the state is the initial one, and
 * at the end of the mainloop. When there is one parse, its state is known, and it is
 * possible to check if there is at least a token delivered by the tokenizer for which
 * an action is allowed in that state, or to perform all of them.
 * However, when no LR modes can be used, a number of GSS nodes are present, and visited,
 * and each of them has a state that has actions for a set of tokens. There is a need
 * either to perform all the actions of all the tokens delivered by the lexer for each
 * such node, or to choose one for each node.
 * Let's see if it is possible to choose one of the tokens delivered by the tokenizer
 * to make the parser accept at least the common case of lexers with identifiers, reserved
 * words and predefined words.
 * Let's define the identifiers in such a way that they are not reserved words, e.g.
 * - {<keyword>}. This works as expected (well, it works also if the first token delivered
 * is a reserved word).
 * However, when a predefined one is found, the lexer returns it and also an identifier.
 * In the rules in which a predefined one is present, it is likely that no identifier is
 * present. For them, choosing the reserved among the ones delivered by the lexer would be
 * good. However, in the rules in which an identifier occurs it is likely that no predefined
 * are allowed. Perhaps then, taking a state and picking up the first delivered token that
 * has an action could solve the problem.
 * When a node is visited, match the set of tokens with its transitions, and take the first
 * token for which there are actions. When an action is a shift, record in the potter the
 * token kind. When processing the potter, create the node, edge, and possibly save the token
 * with its proper kind if not already saved (no need to keep two lexstore, one for the tokens
 * that are defined with rules, and another for the ones that are single terminals because
 * there is very little change in memory footprint). In so doing we would produce the proper
 * derivations.
 * If instead we accept all the token kinds for which there is a transition, then
 * do the same for each one of them.
 * This is also called Schrodinger tokens.
 *
 * Contextual lexing is a bit different: it should match only the expected tokens without
 * matching the longest lexeme the grammar. This means that in each state of the pilot the
 * lexer should match only the tokens that are allowed in it (i.e. for which there are
 * terminal shifts). But this would be difficult to describe to the user because s/he does
 * not know what lexemes would be allowed in each place of the grammar.
 *
 * An example of ambiguous lexemes that is solved generating several parses, one of which
 * then dies is (java):
 *        <ModuleDirective> ::=
 *            requires {<RequiresModifier>}* <ModuleName> ";"
 *        <RequiresModifier> ::=
 *            transitive | static
 *        <ModuleName> ::=
 *            <Identifier>
 * "transitive" is not reserved, so this is legal:
 *        requires transitive;
 * Here "transitive" acts as module name, but that is known only after having seen that
 * it is follwed by a semicolon, otherwise it is a <RequiresModifier>.
 * And, when none dies, if this ambiguity cannot be solved by the leftmost-longest
 * one can use priorities.
 *
 * There is a problem with the lr static mode and ambiguous lexemes: suppose a frontier
 * state is found, and some shifts have been done in lrs, and then an ambiguous lexeme
 * is found: the lr mode cannot continue because there could be two possible shifts.
 * There is a means to detect this when making isles.
 * When testing if a state is adequate, and checking if for a token there is only one
 * action, we should test if the token is ambiguous.
 * The lr modes are entered when there is only one action among all the possible tokens.
 * There are cases in which a token is ambiguous and there is only one action for only
 * one choice, and then that would still be adequate, and it would be correct to enter
 * the lrs, in which case perhaps I should enter it also in the mainloop.
 * When a state is tested for adequacy, and the set S of tokens for which there is an
 * action computed, for each token in it, test if it belongs to some token set in which
 * there are also other tokens and if so, test that such other tokens are not in S.
 * And what about the lrd? lrd performs a single action and it does it when there
 * is a nonambiguous token, so it is ok.
 * In ParserLR there is then an option to control the adequacy with ambiguous lexemes because
 * when a user lexer is provided that delivers no token sets, the normal token sets must
 * not be used when building the pilot.
 * A solution could be to pass the user parser class when building a parser.
 * The thing is that the use of a user lexer is tied to a grammar, so probably it should
 * be specified in the grammar, like, e.g. LEXER ParserGoLex (in which case ParserTest
 * could get it), but it is always a bad idea to put in a source file a reference to
 * an executable.
 * Another is to tell in the grammar that the token sets are not needed, or in general
 * to specify options, like, e.g.: OPTIONS string,... the option here is "-tokenSets"
 *
 * The idea to take the first token in a set that matches an action is not good for java15,
 * and not even if we declare an id that is not var: in var = x, "var" works only if it is
 * interpreted as an id.
 * When there are predefined identifiers, if the tokenizer delivers only the first token
 * in token sets (which is a predefined one in sets in which there is a predefined and
 * an identifier), then in the pilot there should be transitions also for the predefined,
 * while when the tokenizer delivers the sets, all tokens in the set are used by the parser,
 * then there is no need for the pilot to have such transitions.
 * This means that for grammars that have predefined identifiers, and a parser that does
 * not treat ambiguous lexemes, a non-lexis rule: <identifier> ::= <id> | <predefined>
 * must be present.
 * For pascal, there are predefined identifiers and identifiers that are ambiguous, and
 * that is the reason for fewer isles, which means that the problem of predefined identifiers
 * is solved, but at the cost of reducing the isles. Note that even passing to the lexer the
 * set of expected tokens it would not avail because there are many states in which a
 * predefined identifier and a normal one have terminal shifts, so the lexer would be unable
 * to deliver one, it has to deliver both.
 *
 * Parsing is faster when there are few ambiguous lexemes. So the user should check in the
 * listing of the grammar that there are few token sets with more than one token.
 *
 * The grammars in the benchmark that end in "Lex" are used when contextual lexis is enabled:
 * glrmeaPtimeLex.
 *
 * Note that in specific cases, like, e.g. predefined identifiers, the rule:
 *    <identifier> ::= <id> | var | open | ...
 * (where <id> is a lexis nonterminal) would solve the problem too, but require 
 * to change the grammar replacing <id> with <identifier> in all places in which an
 * identifier that could be also a predefined one can occur.
 * Contextual lexing is more expressive because it does not need this, and even more
 * important, it works also with a disambiguating parser, while the rule above works
 * only with a general parser (i.e. one that delivers forests).
 * Moreover, the rule above works only if the token returned by the tokenizer is the
 * predefined (terminal) one and not the <id>, or that the token taken by the parser
 * among the ones returned by the tokenizer is the predefines one.
 *
 *
 * Pilot
 *
 * In pilots there are states that differ only for the leftpointers, and this makes
 * examples such as {a|""}* have a gss that contains paths with two ""s and then
 * forests in which there is one alternative with one empty body and another with two.
 * Probably this would disappear if we associated the leftpointers to arcs in the pilot,
 * or (which is the same) if we had several tables of leftpointers in a state, one for
 * each predecessor, or (as it is in rnglrParser.js) if we had leftpointers as pairs
 * (left,predecessor), which makes the building of paths less efficient.
 * This, however, is a problem only for empty bodies, and thus it is better to solve
 * it without putting a penalty on all.
 * Let's see another solution: in a state, for an item, what we need is to record a key
 * that, when going back to the predecessor state, allows to get another key hopping
 * until no key is found. The key now is the index of the item, but it could be the
 * dot (in which case we should then have in a state a table indexed with the dot that
 * contains the next key). Well, we now have a table that for each state is indexed
 * with the item number and allows to get the key. The new table would be more sparse,
 * but perhaps not much bigger, and would be as fast to access as the current one.
 * In other words, we would identify items in states with their dot instead as their
 * index for what concerns leftpointers. Consequently, we would record in reductions the
 * dot instead of the index.
 * Actually, only the items of groups need to have a key to hop, but the rules of
 * groups are placed anywhere in the encoded grammar.
 *
 * With machines there is only one element, that represents both the group and the body
 * Let's represent the machine states with an integer that is a dotted rule, and treat in
 * a dedicated way these items for what concerns the advanced items, the lookaheads and
 * the fact that they can be reductions whether they have the dot at the end or not:
 *
 *   0_S              1_S               2_S
 *   S ::= . x &0 y   S ::= x . &0f y   S ::= x &0f . y
 *                    &0 ::= . &1
 *
 * For a * there is a need of two dots because the machine has two states .&1 and &1.
 * Same for +.
 *
 * The star is represented by &1 instead of &1 &1 because it is simpler. &1 &1 helps
 * the computation of lookaheads, that can be computed anyway.
 *
 * REP in the grammar is represented by one rule only: &0 ::= &1.
 *
 * If I use the Aycock's predictor (recursively) in the building of pilots, I think
 * that I can get rid of cycles in gss. Of course, I should then generate the proper
 * e-trees or cycles when encoding the forest. This would achieve the same result of Herman.
 * But this is the same as eSplit-DFA, which needed the splitting of the grammar, and
 * was not faster.
 * There is no point then in doing it also because the test of cyclicity here is
 * inexpensive.
 *
 *
 * Pedigrees
 *
 * It is possible to use pedigrees, i.e. not to create sppfs with rule nodes that collect
 * the elements of derivations, but simply to add causal pointers to edges, and leave
 * the building of the forest to encodetree. This eliminates the problem of rnglre that
 * builds a lot of sppfs that are dead.
 * When a gss node N is processed, and a reduction in it done, a new gss node is added with
 * the nonterminal shift. Instead of storing in its gss edge a sppf we could store a pointer
 * to N and the reduction action (as stored in the LR compressed table) i.e. what allows
 * to build the sppf so as to allow encodetree to build it, but on the final tree.
 * Then in edges, the pdgr field would denote either a reduction or an encoded subtree.
 * An edge could then have several reductions attached.
 * The pdgr field of edges then contains: a reduction or an encoded tree, a gss node, start
 * and end, and a next field. Start and end are common to all pedigrees of the same edge.
 * Encodetree then builds the paths (as the reducer).
 * If we do not build gss sppfs, then the idea of having pilots with group rules, that
 * allows to have linear paths instead of garlands could be used, which means that I must
 * add the pointers to the pilot items unless I am able to spot the beginning of the reduction
 * of a group from the items in the states. But remember that groups do not occur so
 * often in grammars, so the code to handle them must not put some penalty on that of the
 * normal rules.
 * Note that pilots with group rules lead to linear paths for groups, and this requires
 * the use of pedigrees because if instead gss sppfs were built we would have the same
 * problem as rnglre to build a lot of gss sppf that are useless.
 * If pilots do not have group rules, i.e. they have recursive rules for groups, then
 * gss sppfs can be used, or also pedigrees.
 *
 * Here we visit all the paths twice, which we do not do in rnglre. However, there we
 * store the sppfs, which is barely the same as storing paths, and we do it for a lot
 * of ulesess ones, while here we store only the info to make the paths.
 *
 * Since pedigrees denote reductions, when two reductions are done producing the same
 * gss node and edge, a casual pedigree is added to the pedigree of that edge.
 * Since the node N is the same, then also the nt of the reduction is the same because
 * it corresponds to an edge in the pilot from the state of the lookback node to the
 * state of N, and on that pilot arc there is only one label, the nt.
 * Thus, all the casuals of a same pedigree denote reductions for a same nt.
 *
 * When a reduction is made, i.e. the parser is processing a gss node and its state has
 * reductions, all the paths starting with the node (and possibly with a specific edge
 * of it) are visited. They have either a fixed length or a length determined by the
 * items in them (which is the case of repetition groups). Each path ends in a node
 * (called the lookback node). A nonterminal shift is then done, i.e. a new node added
 * with an edge to the lookback node with a pedigree attached that tells the reduction
 * done, i.e. the rule, start edge or node, item, cover.
 * I do not store in pedigrees the lookback node because in so doing I have fewer pedigrees:
 * a pedigree denotes all the paths.
 * When there are several paths with the same cover, ending in different lookback nodes,
 * I add a reference to the same pedigree to several edges. In order not to process a
 * pedigree in encodetree several times, I mark there the processed ones.
 *
 * A pedigree {0:3}p82(->0 r1#2 e57) tells that starting with edge e57 and making a path
 * of length 2 we have a derivation whose cover is 0:3. However, not all the paths of
 * length 2 from e57 make a derivation with that cover.
 * This is due to the adding of edges to a node that has already been created by a nonterminal
 * reduction. E.g. a reduction on node n1 makes a nonterminal shift creating node n2
 * and adding a pedigree to the created edge of n2. The pedigree tells that a reduction
 * has been made from n1 (and an edge, say, e1). However, later on, other nodes and edges
 * could be created, and the reduction path n1-e1->...->nx could no longer be the only one
 * from n1-e1->. Other paths could then exist. There is then a need to take only the ones
 * that have the same cover as nx, cover that is stored in the pedigree.
 * Recording the edge and the length of the path would not be sufficient, and neither the
 * reached node(s) because there are several paths in general between two nodes.
 * More precisely, I perform all the reductions from the given edge and length (or chain
 * of items) and take only the ones that have the desired cover.
 * This is consistent with the fact that for a same cover and nt all the alternative trees
 * are to be created as sons of a same symbol forest node.
 * I wrote that without backpointers it is difficult to use pedigrees, and this is why.
 *
 * Instead of checking the cover, it could be possible to check that the path ends in the
 * same tostate of the edge of the pedigree:
 *
 *            x <----- x1<---... ---- xn
 *              <---------A-----------Y
 *                        pdgr(xn...)
 *
 * There is a need to pass the edge to encodetree, to put edges in the queue instead of
 * pedigrees and also in gamma and to check if the hash table and the duplication check works.
 * Then, after a path is got, we must check if its end node is the same as the tonode of the
 * edge that has the pedigree.
 * However, there could be several edges sharing a same pedigree, which means that we must
 * take all the paths that end in any of the tonodes of all these edges.
 * Then the test on the cover is better.
 * Note that paths that have a different cover generate different pedigrees. This means
 * that all the paths that have the same cover (and nt) are represented by the same pedigree.
 * A casual is added to a pedigree only when the reducer finds that the node and the edge
 * are already there, but this means that the edge is leading to the very same node to
 * which the new path leads, and then it has the same cover.
 *
 * To compute the cover of a pedigree, we exploit the fact that the end of the cover is the
 * current level, and for the start, the pedigree is created when there is a lookback node.
 * If that node has edges with pedigrees (that are not tokens or e-nts), the end cover in
 * them is the level of the lookback node, which is also the start that we want.
 * Otherwise, we scan the nodes starting with the lookback until the beginning is found,
 * which is the level.
 *
 * The problem that occurs in parsers that build gss sppfs when processing some texts of
 * some grammars is that several such sppfs are built that are useless. When this occurs
 * because the grammar rule has a star, and the number of iterations is high, the speed
 * of the parser becomes slow.
 * With pedigrees this does not occur because sppfs are not built until the end, when
 * only the useful sppfs are built.
 * To do the same with gss sppfs, there would be -when building a gss sppf rule node- a need
 * to detect that a path is partly stored as another gss sppf rule node, and then record the
 * new one as an increment with respect to the old one. This seems not simple.
 *
 * Reductions
 *
 * To make reductions, all what is needed are the endpoints of the paths, not all the
 * segments of the paths. However, it is not possible to compute the endpoints since the
 * algorithm does not work when there are cycles.
 * There is a need to walk the paths discarding the cyclic ones.
 * The algorithm to find the endpoints is like this: start with a vector containing the
 * endpoint of the startedge, then put in another vector all the neighbours, swap the
 * vectors and repeat as many times as the desired length. At each stage (or at the end)
 * remove duplicates (if any).
 *
 * For the variable length reductions there is a need to follow the items. The algorithm
 * to visit paths is the same, but with the leftpointers: taken the start node N, with a
 * neighbour M, its attached items are a set, and then the attached items of its neighbours
 * are the union of the leftpointers of each item of that set. This is not much efficient,
 * unless it occurs seldom and I use a reusable pool of sets, and I store the leftpointers
 * in the parse tables.
 * It is not possible to precompute these unions. Suppose we have state S1 with successor S2,
 * and state S3 with successor S4, and S2 and S4 with successor S5.
 * Suppose S5 has an item I1{3,5} (leftpointers). This means that both its predecessors S2 and
 * S4 have I3 and I5 (3 and 5 are their indexes). However, I3 in S2 and I3 in S4 can have
 * different leftpointers. Let's precompute the sets of items that we would compute here.
 * The first problem is that we can make several reductions from S5, one for each of its
 * final items, meaning that S2 should have attached several sets, one for each reduction.
 * Then S1 should also have attached several sets, one for each reduction of S5 and also
 * one of each reduction of S2. It is quite complex.
 * The idea could be to store in a vector the union of sets followed by the neighbours
 * to which it applies, then followed by another union and other neighbours, etc.
 * This is why I thought that it could be simpler to have some marks in states: when adding
 * a neighbour we test if it contains the wanted mark(s) and if it does not we do not add
 * it. Well, this is not much different from following leftpointers.
 * In a state, two items can have the same successor in the next one with machines in
 * general: two items can have different machine states, both with an arc with the same
 * label to a common state, but with dotted rules this cannot occur since there should be two
 * items with the same dot.
 * Thus, there are never multiple leftpointers: there is only one leftchain to visit.
 * And the statehop table becomes much simpler.
 *
 * Pilots are not the best way to represent groups, but there are no other ways.
 * Pilots with counters are not an answer because they are meant to support bounded groups
 * with large bounds, which is not the case here.
 * See: Regex-Becchi.pdf and https://www.w3.org/XML/2004/05/msm-cfa.html.
 *
 * To handle empty bodies it is sufficient to discard the paths that contain more than
 * one empty body when the reduction is for a *,+. As for (l:), if the body generates
 * only the empty string, then its forest is built by encodeEtree, which generates only
 * the fixed part, otherwise only one nullable body is generated in addition to the
 * nonempty ones.
 *
 * Concerning some reductions that are not done:
 * Scott says that empty reductions do not generate nonempty reductions.
 * Pag 614, where she says that when m = 0, reductions are not applied down paths whose
 * first edge was created by a length 0 reduction.
 * This is so because the reducer when m = 0 does not enqueue reductions with m > 0.
 * I.e. the reduction A -> a B . is not needed because the A -> a . B is done first and it
 * covers the other. I say that this also holds when B is nullable, and not simply a when
 * a reduction of length 0.
 * An item B -> . or B -> alpha . with alpha nullable advances a A -> a . B to A -> a B .
 * which means that the sppf of the first edge is for a e-nt.
 * In a state with an item A -> a . B, with B nullable, there is also a B -> ., or a chain
 * leading at the end with a X -> .
 * The reduction of it causes the nonterminal shift to a state with A -> a B . (and the
 * adding of a gss node with it).
 * On page 615 she says that B -> . causes the creation of a new node that is never used.
 * I am not sure of this, but certainly the reduction A -> a B . in it is not done.
 * This applies also to rnglre.
 * Thus, testing that the first edge has sppf 0 allows to detect this.
 *
 * Encoding the forest
 *
 * For groups, encodetree can find the bodies already encoded, but not the entire groups,
 * which means that it can exhamine them and build the appropriate forests (e.g. representing
 * the empty body only once).
 * The problem is only for groups with nullable bodies because for the others there is a
 * need to collect only the bodies, and this can be done also by the LR modes.
 * As for the ones that have nullable bodies, the states contain items .&1 and &1., and
 * since they are nullable, the first has at least the same lookaheads as the second one,
 * which means that both a shift and a reduce are possible, and then the state does not
 * belong to an isle. This means that parts of groups are never already encoded, and also
 * that the encode of LR modes need not treat them.
 *
 * Can a &0 have several alternatives &1? No since it has only one rule for &1 (it has another
 * for the bypass, but that as an alternative occurs only in etrees); &1 can have alternatives,
 * in which case its index in the tree is that of a symbol node
 *
 * With pedigrees we have nodes that have edges, which are like leftpointers, each having
 * a list of subpointers. Each subpointer points to a node (or actually to an edge down
 * that node) representing a path in the gss, much the same we have with earley in which
 * a subpointer points to an item and represents all the paths of leftchains startig with it.
 * In Earley we mark that item once we have visited it. Here we mark the list of subpointers
 * because they denote a number of derivations, and once they are visited, there is no need
 * to do that again. A pedigree here represents a sppf symbol node with all its rule nodes.
 * When visiting a path we visit its edges and their pedigrees.
 *
 * When there are several pedigrees that denote the same nt and cover there is a need to put
 * them under the same packed node.
 * This is done when adding pedigrees by using a hash table to find a pedigree for the
 * same nt and cover, if any.
 * Then all the pedigrees that have the same nt and cover (in the same level) are linked
 * together. This serves in encodetree: all the derivations of a pedigree and its casuals
 * are put in a same forest symbol node.
 *
 * In earleyp there is no cover, and no keeping unique sppfs for cover, so why there
 * should be in rnglr?
 * In earley, a completion has all the pedigrees pointing to chains ended at the backpointed
 * list, so all of them have the same cover.
 * Here instead a gss node can have edges with different cover.
 * In earley there could be several pedigrees with the same left, i.e. each left had
 * (virtually) a set of subs. Not to make edges too complex, I had each pedigree (edge)
 * containing a pair (left, sub).
 *
 * In rnglr in theory, collecting all the rule nodes of a same sppf in a same level and
 * with a same cover we could collect rule nodes coming from dead paths. However, they
 * represent derivations of a same nonterminal for a same string, so they must be part
 * of the final forest.
 * Note that a reduction can lead to advance a gss node (i.e. to add a node with an edge
 * to the start node of the reduction) that is on a dead parse. However, this is not
 * relevant because a reduction means also a derivation for a nt for a cover, and if
 * such a derivation is part of the final one (because there are other alternaive ones),
 * it must be part of the forest too.
 * Here a dead path means that the reducer adds a node with an edge to the start of the
 * reduction, node that has no successors in the gss, or some that do not lead to the
 * final one, i.e. do not produce terminal shifts or reductions (e.g. because of lookaheads).
 * It would be nice to find an example that shows that a reduction coming from a dead
 * parse generates a rule node in the final forest. But this would not change the need
 * to collect the pedigrees since there are cases in which a sppf rule is added to an
 * existing symbol node originated in a reduction coming from another node.
 *
 * In earley the pedigrees of an item with the same left form a symbol node with a rule
 * node for each sub together with the ones of the items linked to it in the rope
 * (the ones that have the final dot for the same nonterminal in the same list with the
 * same backpointer). This is so because all such items represent the derivations of
 * the same nonterminal with the same cover, irrespectively on whether they are then
 * referred to from alive or dead parses.
 *
 * Simple earley puts in the same symbol node only the reductions of the pedigrees of
 * the same item. Since all the final items for a same nt and cover complete all the
 * ones with the dot in front of that nt, this makes the advanced item have one pedigree
 * for each such final item (which is the same as having only one and linking such final
 * items with a rope).
 * Then I could have in a same list two items with the dot after the same nt and with
 * the same backpointer and with two pedigrees. They do not generate two symbol nodes
 * because encodetree keeps a map of the pedigrees visited and does not duplicate them.
 * The same with ropes.
 *
 * I can link with ropes the pedigrees when I build them, or encodetree could find the
 * derivations with the same nt and cover (can it put one on the same packed node of
 * another restructuring it, and remapping the references?).
 * Suppose encodetree has built a rule node, and then finds another rule node for the
 * same nt and cover. It can build a symbol node and make a reference to them.
 * However, if a third rule is found, then it would be impossible to add it to the same
 * symbol node. Besides that, there is a need to remap the references to the first rule
 * node on the symbol node. And of course, there is a need to detect that a rule node
 * has the same nt and cover as another.
 * Let's see if it easier to do that on the pedigrees when they are built, either adding
 * one to each advanced node, or linking them with a rope.
 * In rnglr I detect this when adding sppfs to edges: the second reduction adds a rule
 * to an existing sppf. The forest then is made of the sppfs, not on the gss with the
 * pedigrees. In theory it could be possible to solve the problem of slowness by using
 * a representation of gss sppfs in which it is possible to add elements to rule nodes
 * without rebuilding them anew, but it does not seem simple.
 * So, let's see if it is possible to either add pedigrees or to link them.
 * Adding pedigrees it is possible: each time a reduction is made I could scan the
 * gss level in which lies the start node of the reduction and advance all the nodes
 * that have a transition for the same nt. This seems expensive.
 * Linking them should also be possible: it is like building a rope. Or I can put in
 * pedigrees a pointer to a sort of sppf to which all reductions are added.
 * But it is already so: edges have a pdgr field pointing to an object that contains
 * a list of reductions. It is sufficient that I do the same that I do with addgss
 * to make that object unique. I think I do not need a hash table for rules because here
 * it is easier to test duplication in the list of reductions attached to a pedigree.
 *
 * To discard duplicated derivations a hash table is used. The hash table uses reusable
 * arrays that are reused in all the calls of encodetree.
 * The directory and the links are initialized when created, and have autoaging values
 * across the processing of all pedigrees.
 * Another vector keeps the index in the tree where a derivation is stored, so as to
 * compare it with a new one being added.
 *
 * To discard the combinations in which bodies can occur in several places, let's allow
 * the empty bodies at the end, i.e. that they cannot be followed by nonempty ones.
 * Then, discard a path if it has a nonempty one and empty ones have already occurred.
 * This is done even when not cyclic.
 *
 * To disambiguate when building the forest in encodetree, I get a path, save it and
 * then get the next one and compare with the previous, and so on until all paths of a same
 * pedigree has been visited, then I encode the winner
 *
 * Encoding the forest
 *
 * Pedigrees are built also if the forest is not generated (by undefining PARSETREE and
 * FINAL_FOREST) because they have the cover, which is used for disambiguation.
 *
 * An encodetree that builds the tree has the same problem as the garland walker if done on
 * a forest to build all the combinations.
 *
 *
 * Groups
 *
 * Let's say that each group is like a nt, and see how could be the items of that nt:
 *
 *              S -> a {b}* c
 *
 *              S -> . a &0 c   S ->  a . &0 c   S ->  a . &0 c
 *                              &0 -> . b        S ->  a &0 . c
 *                              S ->  a &0 . c   &0 -> . b
 *
 *       The item  S ->  a . &0 c introduces S ->  a &0 . c in the same state.
 *       Then the state has a transition for "b". This introduces &0 -> b .
 *       What matters is that it introduces S ->  a . &0 c (and then S ->  a &0 . c),
 *       i.e. a loop.
 *       This is more or less the same as a rnglre in which we have a nonterminal
 *       for each group.
 *       Without machines there is no need for a number of tables, the ones for the
 *       rn tails, machine state numbers, etc.
 *
 * The key point is how to make reductions. The idea of having group items is the same
 * as in Earley: to build leftchains of elements instead of garlands. Then, suppose there
 * is a path in the GSS with nodes for the elements. How do we find where it ends?
 * A means could be to have leftpointers and follow the chain until a null leftpointer
 * is found.
 * A key point is to avoid the weakness of rnglre: to build derivations that do not
 * share pieces with others, like, e.g. tg32.138. 
 *
 * This parser does not have the same problem as rnglre to walk gss cycles once or at most
 * once (which occurs when there are nullable bodies) because here cycles are never
 * walked, and only one empty body is added meaning that it can be repeated at will.
 *
 * In myEarley, the adding of a body could not be done in a list that is safe because it
 * would produce the encoding of the group with the bodies collected so far, but they
 * may not be all.
 * myEarley cannot know when a group is ended in general (e.g. in {a}* a, where the group
 * is followed by an element that can also be a body. It is essential then that the lists
 * in which bodies are matched are not safe, or that they are not isles.
 * In the lists in which each body is matched, an item is added for the completion of the
 * group. Since these lists are not safe, all the bodies have not yet been put in the final
 * tree, and thus can be encoded in a group derivation.
 * Earleyp instead encodes the bodies, but not the group derivations.
 * rnglrd instead encodes also the group derivations, which means that it is not possible
 * to make encodetree store group derivations (unless we build a dirty forest).
 * Earleyp uses right-recursive groups.
 * In a pilot with group rules, if a group is followed by elements that cannot belong to
 * it, the states for the bodies could be isles because the &1. reduction items have
 * lookaheads that are different from the elements that begin the .&1 ones, which means
 * that they do not conflict. Conversely, when groups are followed by elements that do not
 * begin their bodies, the items do not conflict and the states for the bodies can be isles,
 * and only the last one performs the reduction for the group.
 * As for the lr dyn mode, it cannot be entered in the first case because there wouyld be
 * several actions.
 * With group pilots we have the same problem as with GO: if the parser builds gss sppfs,
 * at each level it must create a sppf for the group containing the bodies matched so far,
 * but only the last one is the useful one.
 * The rnglre pilot is able to handle <S> ::= b <A>, <A> ::= {a}* <B>, <B> ::= a, without
 * making any intermediate reductions. The parser shifts all the a's and at the end makes
 * the reduction for A. This is so because it has a machine for each nonterminal, and the
 * one for <A> matches without bothering to determine what elements belong to the group
 * and what not as long as they belong to the rule.
 * But with <S> ::= <A> [b] c, <A> ::= a {b a}* it makes a reduction at each iteration
 * and builds then a sppf with the bodies matched so far.
 * I could store rule nodes in sppfs with a last element pointing to a sppf in a previous
 * level, but this is the same as using recursive rules.
 * Rnglre in lr mode when matching bodies it makes shifts, not reductions; then when
 * finding the end of groups it encodes them; its problem is that it builds a sppfs
 * for the group each time it matches a body (not always, only when the group is followed
 * by terminals that could belong to its body).
 * It encodes groups in the final forest only when they are completed.
 *
 * The detection of isles with group rules is the usual one.
 *
 * The use of pedigrees leads to represent the internal forest in a rather compact way,
 * which is good in general, except when it has to be visited. Actually we visit the
 * paths twice: when making reductions and when building derivations, but this is the
 * price to pay to avoid to make derivations for dead paths.
 * Note that there is no way with pedigrees to avoid this: a pedigree represents several
 * paths unless it contained the paths themselves. In parsers in which it is possible to
 * purge the gss of the non-prior edges (like, e.g. Earley), the pedigrees denote linear
 * paths, and then a pedigree denotes only one path, making the visit simple.
 *
 * The gss with groups with the pilot group items has a linear chain for each group plus
 * twigs for the bodies.
 *
 *
 * Disambiguation
 *
 * When disambiguating I could avoid the creation of all combinations of empty and nonempty
 * bodies reductions in groups with nullable bodies by avoiding to add empty bodies, and
 * add them when encoding them. This is done when making the reductions.
 * When a group has a nullable body, which produces only the empty string, its tree is
 * produced without looking at reduction, and it is so also when the body can also produce
 * nonempty strings, but it matches nothing. When instead it matches some nonempty string,
 * the derivation has no empty body, so it is correct to skip it.
 *
 * In mainloop, after parselr a pedigree is created and also in parselrdyn to hold the
 * reference to the already encoded tree together with its cover.
 *
 * In earley, with disambiguation, only one pedigree is attached to each item.
 * In ParserRnglrPlus, only one rule is attached to a sppf symbol node. Can we also reduce
 * the GSS, having only one edge for each node? I.e. there are cases of GSS in which there
 * is no ambiguity and still there are several edges for the same node?
 * I checked this in ParserTst36: there are some. They are due to the existence of several
 * parses in parallel, some of which will be dead ends.
 * But there are also cases in which pedigrees are added to existing ones. They occur
 * when a node N1 is added because of the processing of another node N2, and later on,
 * the processing of a node N3 leads to the adding of the same node N1.
 * It is then not possible to get rid of several edges.
 * But if two parses converge in a same node, then it means that from that node onwards
 * they behave the same. Why it should then not be possible to choose one of them?
 * Well, they behave the same but from them there are several paths, some of which produce
 * reductions that thereafter lead nowhere.
 * E.g. in tg36.285 there is a node 14 and then a node 17. From it two reductions are done,
 * leading to nodes 18 and 19. However, only the latter has actions (it produces node 20).
 * The question is if at the time edge 28 is added to node 14 (or when edge 31 is added) it
 * is possible to delete edge 14. I have no idea how to do it.
 * In Earley this does not occur. It occurs here because states represent the progress
 * of several rules at once.
 * 2/0#0<-"1a"-5/2#1,2/0#0<-"4<A>"(e1)-6/1#1,5/2#1<-"13a"-9/6#2,6/1#1<-"16a"-10/5#2,2/0#0<-"19<A>"(e13)-11/1#2,10/5#2<-"28a"-14/5#3,11/1#2<-"31a"-14/5#3,14/5#3<-"34b"-17/9#4,10/5#2<-"37<N>"(e34)-18/8#4,11/1#2<-"46<N>"(e34)-19/4#4,2/0#0<-"49<S>"(e46)-20/3#4,20/3#4<-"58eof"()-23/7#5
 *
 * To compare two derivations, that are not of groups, we have the paths of both and they
 * have the same cover (they have the same nt since they are reducing the same rule), and
 * must choose the prior one.
 * I keep the currently winner path, and when a new one is visited I compare it with the
 * kept one, and then at the end I use the winner.
 *
 * In order to avoid to build useless gss sppf with n-ary derivations, which is what a parser
 * with a pilot with groups does (or one that has a normal pilot, but) visits garlands),
 * pedigrees must be used.
 * On the other hand, a parser that uses a normal pilot (and does not visit garlands to build
 * sppfs) can better use gss sppfs because it avoids to visit paths twice.
 *
 * When a reduction is made, a nonterminal shift is added (possibly) with an edge with a
 * pedigree denoting it; another reduction from another path (starting with the same edge
 * as the other) could occur, leading to the same nonterminal shift with the same pedigree.
 * E.g. tg36.280.
 * rnglrp would instead add two rule nodes to the same sppf symbol node.
 * Other reductions could occur, for the same nt and cover, and since they in rnglrp would
 * add to the same sppf symbol node, here they add casuals to the same pedigree because all
 * such reductions are valid and apply to all the nonterminal shifts of the same nt in the
 * same level with the same cover.
 * This is done in addpedigree using a hash table for nt and covers.
 * However, since a same pedigree can denote several derivation, it is not possible to
 * disambiguate when pedigrees are added; this must be done when the derivations are
 * built, i.e. in encodetree.
 *
 * Explicit priorities
 * when a group has nullable bodies, a null body is generated only when absolutely needed,
 * here and in REs. E.g. a group such as {""|a}(1:3) an empty body is generated if there
 * are no a's to match.
 * Explicit priorities serve to choose a parse tree among the ones that are in the forest,
 * and since there is no tree with an empty body in the example above, adding a priority
 * to it (i.e. {"" (prio:1)|a}(1:3)) is ineffective.
 *
 * The same means to disambiguate when there are already encoded parts of reductions as
 * rnglrd apply here, i.e. use the cover.
 *
 * To disambiguate, there is no need to wrap etrees because they have norm 0.
 * Final trees are put in the edges by lr modes, and then they can get into gss sppf
 * rule nodes as elements.
 *
 *
 * Cyclicity
 *
 * Here is the explanation why I test cyclicity on the basis of rules and not on containment
 * of subforests. Consider the following example:
 *
 *      <S> ::= <A> | b
 *      <A> ::= <B> | <C>
 *      <B> ::= <S>
 *      <C> ::= b
 *
 * myEarley builds an item for <S> -> b, then one for <A> -> <C> -> b, and then it processes
 * <A> ::= <B>, which is cyclic, but not yet at that moment because <B> -> <S> -> b, and
 * because of the longest-leftmost rule, it chooses the latter.
 * Then it processes <S> -> <A> -> <B> -> <S> -> b, and compares it with <S> -> b.
 * The latter is contained in the former, and since it performa a containment check, it
 * chooses the latter.
 * Note that also the <S> -> <A> -> <B> -> <S> -> b would be a valid derivation.
 * And also <S> -> <A> -> <C> -> b, which uses an alternative rule of <S> that is earlier
 * than the <S> ::= b.
 * The test of containment prevents cyclicicy in trees. However, there is a need to explain
 * why we choose a tree instead of another. A solution could be to state that in case of
 * cyclicity we choose any one. But here it seems that we choose the shortest tree.
 * There is a need to define it.
 * Perhaps the rule that we choose the shortest tree is simpler, but leaves still some
 * uncertainty.
 * How can we do the same in rnglrg? We start the building with <S> and have to choose
 * between <S> -> <A> and <S> -> b. If <S> were not cyclic, we should take the first.
 * But it is, so we must visit the first before deeming it the winner.
 * So, we go to <A>, and again we must choose between <B> and <C>. Same reasoning.
 * We should discard <B> because it is cyclic. Well, perhaps not since for <S> there
 * could also be another alternative, that leads to an acyclic derivation: <B> -> <S> -> b.
 * If we stick to the first rule, we take <C>, and then <S> -> <A>.
 * We would then have discovered that this is a solution. Note that, once we have built
 * the derivation for <S> -> <A> in the tree, we must build the one for <A>.
 * However, we should again choose between <B> and <C>, and do the same choice as before,
 * which seems not simple to remember.
 * It would be preferable a disambiguation that can be done at each step and delivers the
 * same result without remembering anything.
 * With myEarley, the choice seems to be done using the ordering of introduction of items.
 * It all starts with <S> -> b and then <A> -> <C> -> b, etc., as above.
 * A solution could be to state that we start from the root, <S>, and take the leftmost-longest
 * skipping the rules that are cyclic. This does not depend on the fact that there is a
 * derivation in the GSS that is not cyclic. So, we would choose <S> -> b full stop.
 * If all the rules are cyclic we could take the leftmost-longest even if cyclic, and expand
 * it knowing that there will be a nt that has a non-cyclic rule.
 * There is a need to know which rules are cyclic, and if all of them are cyclic.
 * Then, if all are cyclic, we choose without bothering about cycles, and instead skip
 * the cyclic ones.
 * We compare the derivations as paths are visited, each one with the so-far winner.
 * If all rules all cyclic: we choose the prior as if they were not cyclic.
 * Some rule cyclic: if both not cyclic, prior as before, if one only not cyclic, it wins,
 * if both cyclic: irrelevant (sooner or later an acyclic one will be visited and win).
 *
 * There could be another solution, which is to test if a candidate derivation leads to
 * a cyclic forest.
 * This solution is not completely clear.
 * We have an old derivation, i.e. a vector of pedigrees, and a new one, and want to
 * see if the new derivation, if added to the forest in place of the old one, makes the
 * forest cyclic. This means that the new derivation, if visiting the ones that it refers
 * to eventually visit itself.
 * Suppose that we have two paths for a reduction, i.e. two alternative paths for
 * a derivation and we have to choose the prior one. The first can lead to a cycle,
 * but also not. Then we can choose it, and build a derivation for it, and a number
 * of others for the nonterminals occurring in it.
 * E.g. in the example above, when we build a derivation for <A> if we choose <B>,
 * then we will not be able to have a noncyclic derivation for <C>. Ok, perhaps we can
 * mark the first rule of <A> as cyclic-only, and then test it and choose the second.
 * Encodetree visits first <S> and then <A>, etc.
 * The thing is that when we encode a derivation, it has a sequence of pedigrees, that
 * denote terminals or other derivations, potentially alternative derivations, and
 * even knowing that one of them is for a nonterminal that in the grammar has cyclic
 * and noncyclic derivations, how can we be sure that one of the paths of the pedigrees
 * will be for a noncyclic derivation? In the example above, <A> can produce "c", but
 * if there is no "c" in the string, then it will have only the cyclic derivation.
 * In other words, I should check that it has an acyclic derivation among the ones
 * that it actually has. But to do that I should take the first rule of <S>, then visit
 * <A>, take the first rule, etc, discovering that it fails, and then go back picking
 * up the second rule of <A>, which eventually succeeds. The knowledge that a rule as
 * it is in the grammar delivers only cyclic derivations can be used to reduce the
 * visits.
 * Now, if the pedigrees refer to paths that have not yet been encoded, this is
 * like the test of acyclicity of a graph in which each pedigree acts as a node
 * that has an edge for each of its paths. If in this recursive visit we encounter
 * a path that is the initial one from which the visit started, then the initial one
 * is cyclic and we must discard it. Remember that what we want is to have a tree
 * that is a tree, i.e. that a derivation candidate does not refer to itself.
 * This to be done without actually building the tree. The thing is to do it without
 * having placed the derivations in the tree, in which each one can be identified
 * with the index in the tree, while paths are a bit on the fly otherwise.
 * In encodetree we keep in pedigrees the indexes where they have gone in the tree,
 * perhaps we can still use them (but then there is then a need to clear them) imagining
 * that the derivations of the paths are virtually placed in the tree.
 * But the problem is that in the visit we simulate an encodetree and take the prior
 * path when there are alternatives, but this in turn needs to know if the chosen
 * alternative leads to a cycle, but perhaps this is the very same thing that we are
 * finding, so perhaps we should skip this test.
 * Each derivation is the only one for a given nt and cover. Perhaps we can put its
 * data in a hash table (nt, cover, marks).
 *
 * Another problem is that the containment test should be made on the forest, or partly
 * on the forest and on the pedigrees.
 * But at the point in which the cyclicity test is done in encodetree, the forest is not
 * yet remapped. When remapping, already built, e-nt, and tokens cannot refer a new
 * derivation, so the only ones that can are the others.
 * When building a derivation, and finding an element that is not a token, e-nt or already
 * built derivation, we leave it as it is until all the pedigrees have generated a fragment
 * of forest, and only then we replace that element with the index of the fragment.
 * Now, suppose that derivation D1 has an element E1 that refers to a derivation D2, that
 * contains an element E2 that refers to D1. How is it possible, when encoding D1 to
 * determine that it leads to a cyclic forest? At that time D2 has not been already encoded,
 * so we have only the pedigree. I should take the pedigree of D2 and simulate the building
 * of its forest fragment, and the same for the ones that it refers, until a reference to D1 has
 * been found, or perhaps I can visit the pedigree of D2 and then the ones referred to by
 * its paths and then test if a reference to D1 is encountered, all without building any
 * forest. But perhaps I should only visit the winner pedigrees, not all the paths.
 * Perhaps I should catch cycles in sppf only when a derivation is added that refers to
 * already encoded ones. E.g. in the case above, I would detect the cycle on D2 instead
 * of D1.
 *
 * If a rule denotes only cyclic derivations, then I can discard it, but if it denotes cyclic
 * and not cyclic, then perhaps there is a path that leads to a noncyclic derivation
 * (possibly indirectly), but how can I discover it, except by testing that it makes a cycle?
 * Could it happen that there are two derivations, and I take the first because it can
 * be noncyclic. Then I visit its elements, and at each step there could be a choice.
 * How can I be sure that each choice is the one that leads to a non cyclic derivation?
 * In earley there is no such problem because disambiguation reduces the pedigrees to 1.
 * The problem is that I must simulate what encodetree does (i.e. visit paths)
 * to discover if the forest becomes cyclic.
 *
 * When building the GSS, the reductions are done bottom-up, and when we find that one
 * leads to a cycle we do not do it. The thing is that when building the gss we do not
 * care about building pieces that are dead, so it would work also if the cycle was
 * build in another order.
 * Here instead we are building a tree, and we cannot build something that is not definitive,
 * so, to detect cycles we must either simulate the building of the tree or test some
 * conditions that guarantee not to lead to cycles.
 *
 * In encodeetree I use the same.
 * Here the derivation generates the empty string. We must consider only the rules that
 * are nullable, and the first one is winner. If all such rules are cyclic, take the first
 * one, otherwise take the first that is not cyclic, but only among the nullable ones.
 * If group, generate zero iterations only if there is no suitable rule.
 *
 * Cyclic nts can lead to gss without cycles? No, there are gss without cycles that have
 * cyclic forests.
 *
 *
 * Singletons
 *
 * When building the pilots and encountering a rule in which A occurs, and A -> X is
 * the only one rule of A, we can replace A with X. When building the forest, we detect
 * this and add the derivation according to the original grammar.
 *
 *          state x                       state y
 *            S -> .A a                   S -> A . a
 *            S -> .B b                   S -> B . b
 *            (A -> .C)     ----- C ----> 
 *            (B -> .C)
 *            C -> . b                    C -> b .
 *
 * We do not simplify the nts of groups, otherwise the bodies are not separated.
 * The &0 is never a singleton (except for simple groups); it is the &1 that can be so.
 * We should reconstruct the missing derivations in the tree, otherwise it it not possible
 * to validate with the current reference trees.
 *
 * Measuerments that there is little difference between delivering the full parse tree or
 * the simplified one. Overall it gives a 4-5% gain and in some cases 17%.
 *
 *                                   short tree	full tree
 *    clalr	javalalr.bnf         -0.58%	 7.03%
 *    rnglrgd	javalalrLex.bnf       6.48%	 4.10%
 *    rnglrgd	javaLex.bnf           4.74%	 3.98%
 *    rnglrgd	cLex.bnf              7.04%	 4.41%
 *    rnglrgd	cppLex.bnf            9.28%	11.21%
 *    rnglrgd	freepascalLex.bnf    20.00%	18.97%
 *    rnglrgd	html2Lex.bnf         16.06%	14.04%
 *    rnglrgd	gram1.bnf             0.00%	 0.00%
 *    rnglrgd	jsonLex.bnf          13.68%	13.66%
 *    rnglrgd	xml1Lex.bnf          -0.22%	0.86%
 *    rnglrgd	goLex.bnf             4.95%	5.23%
 *
 * If a simplified (short) tree is delivered, also the etrees must be.
 * Since there is little gain in delivering it, the normal (full) one is delivered.
 *
 *
 * Error reporting
 *
 * Here the parser can only report one error, while a handwritten one can do something to
 * continue parsing and report several.
 * The simplest error reporting is to print the list of tokens on the terminal shifts
 * of all the states on the last gss level: they are the ones that would make parsing
 * continue, but none has been found in the input.
 * Moreover, the parser can encounter something that is not even a token, or may end
 * successfully parsing and have yet some unexpended input.
 * A method that delivers the set of expected tokens is provided.
 *
 * Sometimes the user needs to understand how the parsing is matching the input so as
 * to see why an input that looks valid is not recognized, or an input that is wrong
 * is recognised or accepted to a point that should not be so.
 * This is obtained by showing the dotted rules that are in all the states in each GSS
 * level. There is a need to have the dots of the items for each state.
 * They are hold in an array, indexed with state numbers, that contain the indexex of
 * the slices of it that have item counts followed by item dots of each state.
 * When showing a dot that lies inside a rule of an implicit nt it is better to transform
 * it into the dot in the corresponding RE.
 * This is obtained as follows:
 *
 *    - let's take a rule whose lhs G is the one of a group
 *    - let's take the rule in which G occurs (there is only one), and if such rule is
 *      that of a group, do it again until a rule that is not the one of a group is found
 *    - the string of the such a rule is obtained by concatenating all its elements,
 *      entering in the group ones and putting them in parentheses; when the desired
 *      dot is found, show it
 *    - bounded groups have a sequence of the same bodies in their rules. However, only
 *      one body has the dot in it. In order to know which one it is, there is a need to
 *      start from the item, and go back to the predicted one, and then to its predictee,
 *      and so on walking the pilot until an item is found that is not the one of a group.
 *      All the visited items should be kept in a stack.
 *      Then, starting from it, the rule string is recursively built by entering groups:
 *      the ones that do not have the dot in front of them are simply visited taking the
 *      rule of the body, and the one that has the dot is visited taking the dotted rule
 *      of the item on the stack. Perhaps there is a need to take all the rules of its
 *      lhs and hand down the dot only when visiting the rule on the stack.
 *      Finding the predictee is not so simple, but here we deal only with groups, so we
 *      need only to find the items that have the dot in front of the nt of the predicted
 *      item.
 *    - actually, there would be a need to do this on the GSS, and not on the pilot to
 *      take only the rules that are being matched. This is not worth also because it is
 *      due only to cover bounded groups, for which there are no proper dotted rules since
 *      the expansion of repetitions is not the same as the source grammar.
 *      So, let's for them produce dotted rule with the dot inside the body and let the
 *      user figure out how many times such body is matched, much the same as for * and +.
 *
 * To show the progress of parsing, all the states in a same GSS level are taken and all the
 * items in them, which are then ordered and duplicates removed and then printed.
 */


class ParserRnglrPdgr extends ParserGLRengine {

    // Access to GSS nodes and edges

    private static final int EDGE_TO = 1;
    private static final int EDGE_PDGR = 2;

    /** The length of the header of the pedigree. */
    private static final int PDGR_FIELDS = 3;

    /** The length of the causal part of the pedigree. */
    private static final int PDGR_CFIELDS = 3;

    /** The flag that marks the elements in a pedigree that are nullable nonterminals. */
    private static final int E_NT = 0x20000000;

    /** The marks of the flag fields a pedigree. */
    private static final int PDGR_MSK = 0xe0000000;

    /** The fake pdgr, used when no forest is generated. */
    private static final int PDGR_FAKE = 1;

    /** 
     * Construct a parser for the specified grammar and lexicon.
     *
     * @param      tab reference to the general parse tables
     * @param      inp input stream
     * @param      flags trace flags
     * @param      algo kind of parser
     */

    public ParserRnglrPdgr(ParserTables tab, Object inp, String flags, String algo){
        setParserData(tab,inp,flags,algo);
    }

    /** 
     * Construct a parser.
     */

    public ParserRnglrPdgr(){
    }

    /** 
     * Set the specified parser data.
     *
     * @param      tab reference to the general parse tables
     * @param      inp input stream
     * @param      flags trace flags
     * @param      algo kind of parser
     */

    @Override
    protected void setParserData(ParserTables tab, Object inp, String flags, String algo){
        this.tab = tab;
        this.tablr = (ParserLRTables.LALRGRNFAtables)this.tab.pilot.lrTables;
        if (inp != null){
            this.lex = new ParserLex(tab,inp);
            this.lex.trc = this.trc;
        }
        this.algo = algo;
        settrc(flags);
        this.EOF = eofTokNr();
    }

    /** 
     * Deliver the token number of the EOF.
     *
     * @return     token number
     */

    @Override
    int eofTokNr(){
        return 0;
    }

    /**
     * Deliver a string representing the specified GSS node.
     *
     * @param      itm index of the node
     * @return     string
     */

    @Override
    protected String itemToString(int itm){
        int dt = gssNodeDir[(itm)>>>NSHF][((itm)&MSK)];
        StringBuilder sb = new StringBuilder();
        java.util.Formatter f = new java.util.Formatter(sb);
        f.format("%s [%s]",itm,dt);
        int tok = 0;
        for (int e = gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES] & 0x7fffffff; e != 0; e = gssEdgeDir[(e)>>>NSHF][((e)&MSK)]){
            f.format(", %d%s",e,edgeToString(e,tok));
        }
        return sb.toString();
    }

    /**
     * Deliver a string representing the specified GSS edge.
     *
     * @param      edge index of the edge
     * @param      tok number of the token, if the GSS edge is labelled with EOF
     * @return     string
     */

    @Override
    protected String edgeToString(int edge, int tok){
        if (edge == 0){
            return "";
        }
        int le = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
        String sbs = esToString(edge,tok,false);
        return String.format("(to: %d s: %s)",le,sbs);
    }

    /**
     * Deliver a string representing the pedigree of the specified GSS edge.
     *
     * @param      edge index of the edge
     * @param      tok number of the token, if the GSS edge is labelled with EOF
     * @return     string
     */

    private String esToString(int edge, int tok){
        return esToString(edge,tok,false);
    }

    /**
     * Deliver a string representing the pedigree of the specified GSS edge.
     *
     * @param      edge index of the edge
     * @param      tok number of the token, if the GSS edge is labelled with EOF
     * @param      full <code>true</code> to have a more verbose string, </code>false</code>
     *             otherwise
     * @return     string
     */

    private String esToString(int edge, int tok, boolean full){
        if (edge == 0){
            return "";
        }
        return pdgrGssElToString(gssEdgeDir[(edge+EDGE_PDGR)>>>NSHF][((edge+EDGE_PDGR)&MSK)],full);
    }

    /**
     * Deliver a string representing the specified GSS pedigree.
     *
     * @param    s index of the pedigree
     * @return   string
     */

    String pedigreeToString(int s){
        return sppfSymToString(s-PDGR_FIELDS);
    }
    private boolean nocover;

    @Override
    String sppfSymToString(int s){
        String res = "";
        int i = s + PDGR_FIELDS;
        String covertree = "";
        // determine the positions in the input
        if (!this.nocover){
            covertree = String.format("cover: %s",coverToString(i));
        }
        res += String.format("%s %s %s",
            i,covertree,pdgrCausalToString(i));
        return res;
    }

    String coverToString(int pdgr){
        if (this.nocover) return "";
        int beg = gssEdgeDir[(pdgr-2)>>>NSHF][((pdgr-2)&MSK)] & ~HEADSYM;
        beg = gssNodeDir[(beg-1)>>>NSHF][((beg-1)&MSK)];              // -levNr -1
        beg = - beg -1;
        int fin = gssEdgeDir[(pdgr-3)>>>NSHF][((pdgr-3)&MSK)] & ~HEADSYM;
        fin = gssNodeDir[(fin-1)>>>NSHF][((fin-1)&MSK)];              // -levNr -1
        fin = - fin -1;
        return String.format("{%s:%s}",beg,fin);
    }

    /*
    // Deliver the level in which lies the specified edge
    private int levelOfEdge(int edge){
        int startnodes = 2;
        int endnodes = 2;
        int startedges = 1;
        int endedges = 1;
        for (int i = 1; i < this.gssNodeNr;){
            if (i > 1){
                startedges = endedges;
                startnodes = endnodes + 2;
            }
            endedges = EDGELIST(i);
            endnodes = -STATENR(i)-2;
            if (endnodes == -1){            // last level, not yet set
                endnodes = this.gssNodeNr;
                endedges = this.gssEdgeNr;
            }
            int lev = -STATENR(i-1)-1;
            if (startedges <= edge && edge < endedges){    // found
                return lev;
            }
            TRACE(P,"--- at %s level %s nodes %s:%s edges %s:%s\n",
                i-1,lev,startnodes,endnodes,startedges,endedges);
            i = endnodes + 1;
        }
        return 0;
    }
    */

    /**
     * Deliver a string representing the specified causal of pedigree.
     *
     * @param    s index of the pedigree
     * @return   string
     */

    String pdgrCausalToString(int s){
        String res = null;
        res = "->" + gssEdgeDir[(s)>>>NSHF][((s)&MSK)];
        int redu = gssEdgeDir[(s+1)>>>NSHF][((s+1)&MSK)];
        int m = ((redu& ParserLRTables.EMPTYMASK) != 0 ? 0 : 1);
        int su = gssEdgeDir[(s+2)>>>NSHF][((s+2)&MSK)];
        if ((su & HEADF) == HEADTREE){     // tree
            res += " " + (su & ~HEADTREE) + "t";
        } else {
            res += " " + this.tablr.comprReduToString(redu);
            if (m == 0){
                res += " n" + su;
            } else {
                res += " e" + su;
            }
        }
        return res;
    }

    /**
     * Trace all the lists (i.e. the GSS levels).
     */

    void traceItemsLists(){
        for (int i = 0; i < this.gssNodeNr; i++){   // scan all lists
            if (gssNodeDir[(i)>>>NSHF][((i)&MSK)] < 0){                    // sentinel
                Trc.out.printf("list: %d\n",-gssNodeDir[(i)>>>NSHF][((i)&MSK)]-1);
                i++;
            } else {
                Trc.out.printf("%s\n",itemToString(i));
                for (int e = gssNodeDir[(i)>>>NSHF][((i)&MSK)+NODE_EDGES] & 0x7fffffff; e != 0; e = gssEdgeDir[(e)>>>NSHF][((e)&MSK)]){
                    if (e == 0) continue;
                    int pdgr = gssEdgeDir[(e+EDGE_PDGR)>>>NSHF][((e+EDGE_PDGR)&MSK)];
                    if (pdgr == 0) continue;
                    if (pdgr == PDGR_FAKE) continue;
                    if ((pdgr& PDGR_MSK) == E_NT) continue;
                    if (pdgr < 0) continue;
                    if ((pdgr & HEADF) != 0) continue;
                    int s = gssEdgeDir[(pdgr+2)>>>NSHF][((pdgr+2)&MSK)];
                    if ((s & HEADTREE) != 0) continue;
                    StringBuilder sb = new StringBuilder();
                    for (int p = pdgr; p != 0; p = gssEdgeDir[(p)>>>NSHF][((p)&MSK)]){
                        sb.append(" (");
                        sb.append("p" + p + ": ");
                        pdgrToString(p,gssEdgeDir[(pdgr-2)>>>NSHF][((pdgr-2)&MSK)],sb);
                        sb.append(")");
                    }
                    Trc.out.printf("  e%s%s\n",e,sb.toString());
                }
            }
        }
    }

    /**
     * Add a GSS node if none exist in the current level with the specified state,
     * and possibly an edge to the specified node, if none exists, with the specified pedigree.
     *
     * @param      st pilot state
     * @param      le to node, 0 if none
     * @param      pdgr pedigree of the edge
     * @param      dupl 0: do not check if another node with the same state is present
     * @return     length
     */

    /* N.b. with dupl = 0 it keeps note of the added node in the stater, i.e. it does not
     * use the hash table, and this is used in the lr dyn mode avoiding to reinitialize
     */

    @Override
    protected int addNode(int st, int le, int pdgr, int dupl){
        ;
        addNodeNr++;
        ;
        this.addedEdge = -1;
        int itm = 0;
        int hfunct = 0;
        int l = 0;
        boolean found = false;
        search: {
            if (dupl == 0){
                this.stater[st] = this.gssNodeNr + this.delta;  // remember the first one
                break search;
            }
            itm = this.stater[st];
            if (itm < this.absLevelGss){   // an item with the same dot not present
                this.stater[st] = this.gssNodeNr + this.delta;  // remember the first one
                break search;
            }
            itm -= this.delta;
            found = true;
        } // search
        boolean pedfound = false;
        boolean tohash = false;
        // #endif
        ;
        add: if (found){
            ;
            if (le == 0) break add;
            // add the new pedigree if not already there
            int prev = searchNodeEdge(itm,le);
            if (prev == -1){            // found
                pedfound = true;
                break add;
            } else if (prev == -2){     // not found, to be hashed
                tohash = true;
                prev = 0;
            }
            if (this.gssEdgeNr+EDGE_FIELDS > this.gssEdgeLength){
                enlargeGSS(1);
            }
            l = this.gssEdgeNr;
            gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = 0;
            gssEdgeDir[(l+EDGE_TO)>>>NSHF][((l+EDGE_TO)&MSK)] = le;
            gssEdgeDir[(l+EDGE_PDGR)>>>NSHF][((l+EDGE_PDGR)&MSK)] = pdgr;
            this.gssEdgeNr = l + EDGE_FIELDS;
            // prepend new edge
            if (prev == 0){
                gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES] & 0x7fffffff;
                gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES] = tohash ? (l | 0x80000000) : l;
            } else {
                gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = gssEdgeDir[(prev)>>>NSHF][((prev)&MSK)];
                gssEdgeDir[(prev)>>>NSHF][((prev)&MSK)] = l;
            }
            ;
            this.addedEdge = l;
        } else {
            l = 0;
            addedge: {
                if (le == 0) break addedge;
                // create new node and edge
                if (this.gssEdgeNr+EDGE_FIELDS > this.gssEdgeLength){
                    enlargeGSS(1);
                }
                l = this.gssEdgeNr;
                gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = 0;
                gssEdgeDir[(l+EDGE_TO)>>>NSHF][((l+EDGE_TO)&MSK)] = le;
                gssEdgeDir[(l+EDGE_PDGR)>>>NSHF][((l+EDGE_PDGR)&MSK)] = pdgr;
                this.gssEdgeNr = l + EDGE_FIELDS;
                this.addedEdge = l;
            }
            if (this.gssNodeNr >= this.gssNodeLength){
                enlargeGSS(0);
            }
            int n = this.gssNodeNr++;
            int[] block = this.gssNodeDir[n >>> NSHF];
            int off = n & MSK;
            block[off] = st;
            block[off+NODE_EDGES] = l;
            itm = n;
            ;
            this.items++;
        }
        if (!pedfound && tohash){
            hfunct = (itm*31 + le) & (this.edgeshdir.length - 1);
            int z = l - this.levelEdgeGss;      // relative to level
            if (z >= this.edgeshlink.length){
                int newlen = this.edgeshlink.length << 1;
                this.edgeshlink = Arrays.copyOf(this.edgeshlink,newlen);
                this.edgeshdata = Arrays.copyOf(this.edgeshdata,newlen);
            }
            this.edgeshlink[z] = this.edgeshdir[hfunct];  // insert at beginning
            this.edgeshdir[hfunct] = l + this.deltaEdges;
            // use edgeshdata[] to hold the start node
            this.edgeshdata[z] = itm;
        }
        if (found) itm = -itm;
        return itm;
    }

    /**
     * Search an edge from the specified GSS node to the other specified GSS node.
     *
     * @param      itm  from node
     * @param      le   to node
     * @return     index of the edge
     */

    @Override
    protected int searchNodeEdge(int itm, int le){
        int hfunct = 0;
        int prev = 0;                
        add: {
            int edg = gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES];
            if (edg >= 0){     // >= 0 when a node is created with no edges, ..
                               // and then an edge is added it must not be hashed
                ;
                int len = 0;
                for (int i = edg; i != 0;
                    i = gssEdgeDir[(i)>>>NSHF][((i)&MSK)], len++){
                    int lef = gssEdgeDir[(i+EDGE_TO)>>>NSHF][((i+EDGE_TO)&MSK)];
                    if (lef == le){
                        ;
                        prev = -1;                
                        this.addedEdge = -i;
                        break add;
                    } else if (lef > le){     // (A) keep pedigrees in ascending left ordering to speed search
                        break;
                    }
                    prev = i;
                }
                if (len > 20){
                    //nrsearchNodeEdgerehash++;
                    // put the list in the hash table
                    for (int i = edg; i != 0;
                        i = gssEdgeDir[(i)>>>NSHF][((i)&MSK)]){
                        int lef = gssEdgeDir[(i+EDGE_TO)>>>NSHF][((i+EDGE_TO)&MSK)];
                        hfunct = (itm*31 + lef) & (this.edgeshdir.length - 1);
                        int z = i - this.levelEdgeGss;      // relative to level
                        if (z >= this.edgeshlink.length){
                            int newlen = this.edgeshlink.length << 1;
                            if (z > newlen) newlen = z + 1;
                            this.edgeshlink = Arrays.copyOf(this.edgeshlink,newlen);
                            this.edgeshdata = Arrays.copyOf(this.edgeshdata,newlen);
                        }
                        this.edgeshlink[z] = this.edgeshdir[hfunct];  // insert at beginning
                        this.edgeshdir[hfunct] = i + this.deltaEdges;
                        // use edgeshdata[] to hold the start node
                        this.edgeshdata[z] = itm;
                    }

                    prev = -2;         // to hash
                    gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES] |= 0x80000000;
                }
            } else {      // < 0: it has a long list
                hfunct = (itm*31 + le) & (this.edgeshdir.length - 1);
                for (int z = this.edgeshdir[hfunct];
                    z >= this.absLevelGssEdges; z = this.edgeshlink[z-this.absLevelGssEdges]){
                    int edge = z - this.deltaEdges;
                    if (this.edgeshdata[z-this.absLevelGssEdges] == itm &&
                        gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)] == le){
                        prev = -1;                
                        this.addedEdge = -edge;
                        break add;
                    }
                }
                prev = -2;         // to hash
            }
        } // add
        ;
        return prev;
    }

    /**
     * Create a new GSS node for the specified state in the current level, and possibly an
     * edge to another node with the specified pedigree.
     *
     * @param      state pilot state for the node
     * @param      to to node, 0 if none
     * @param      tree pedigree
     * @return     index of the node
     */

    @Override
    protected int newGSSENode(int state, int to, int tree){
        ;
        int l = 0;
        if (to != 0){
            if (this.gssEdgeNr+EDGE_FIELDS > this.gssEdgeLength){
                enlargeGSS(1);
                /*
                TRACE(M,"newGSSENode enlarged %d blocks: %s\n",
                    this.gssEdgeNr,gssBlocksToString());
                */
            }
            l = this.gssEdgeNr;
            gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = 0;
            gssEdgeDir[(l+EDGE_TO)>>>NSHF][((l+EDGE_TO)&MSK)] = to;
            gssEdgeDir[(l+EDGE_PDGR)>>>NSHF][((l+EDGE_PDGR)&MSK)] = tree;
            this.gssEdgeNr = l + EDGE_FIELDS;
        }

        if (this.gssNodeNr >= this.gssNodeLength){
            enlargeGSS(0);
        }
        int n = this.gssNodeNr++;
        int[] block = this.gssNodeDir[n >>> NSHF];
        int off = n & MSK;
        block[off] = state;
        block[off+NODE_EDGES] = l;
        if (to != 0){
            int hfunct = (n*31 + to) & (this.edgeshdir.length - 1);
            int z = l - this.levelEdgeGss;      // relative to level
            if (z >= this.edgeshlink.length){
                this.edgeshlink = Arrays.copyOf(this.edgeshlink,this.edgeshlink.length << 1);
                this.edgeshdata = Arrays.copyOf(this.edgeshdata,this.edgeshdata.length << 1);
            }
            this.edgeshlink[z] = this.edgeshdir[hfunct];  // insert at beginning
            this.edgeshdir[hfunct] = l + this.deltaEdges;
            // use edgeshdata[] to hold the start node
            this.edgeshdata[z] = n;
        }

        this.stater[state] = n + this.delta;
        ;
        // nrOfNodes++;
        this.items++;
        ;
        return n;
    }

    /**
     * Deliver the rule number of the specified pedigree.
     *
     * @param      r index of the pedigree
     * @return     rule number
     */

    private int ruleNodeRule(int r){
        if (r < 0){
            return -1;
        }
        int gp = (r& ParserLRTables.GPMASK);
        if (gp >= this.tab.ruleBase){
            return gp - this.tab.ruleBase;
        }
        return -1;
    }

    /**
     * Print the statistics.
     *
     * @param   print stream
     */

    @Override
    public void statistics(PrintWriter trc){
        trc.printf("lrsmode %s lrsmode1 %s lrdmode %s ndetmode %s mloopnr %s\n",
            lrsmode,lrsmode1,lrdmode,ndetmode,mloopnr);
        trc.printf("mode tokens: %s mode reductions %s percent in ndet mode %.1f\n",
            Arrays.toString(modetoks),Arrays.toString(modereds),
            modetoks[0]*100.0/(modetoks[0]+modetoks[1]+modetoks[2]));
        trc.printf("fixed reductions: %s variable: %s (%.1f%%)\n",
            kindreds[0],kindreds[1],kindreds[1]*100.0/(kindreds[0]+kindreds[1]));
        trc.printf("edges size: %s pdgr size %s nrPaths %s\n",edgesize,pdgrsize,nrPaths);
    }

    /** The kinds of reductions: 0: fixes, 1: variable. */
    private static int[] kindreds = new int[2];

    /** The size of the pedigrees. */
    private int pdgrsize;

    /** The number of paths. */
    private int nrPaths;

    /** The reference to the LR parse tables. */
    ParserLRTables.LALRGRNFAtables tablr;

    /** Whether it disambiguates. */
    private boolean disambiguate;
    /** The number of the current token. */
    private int currentTokNr;
    /**
     * Parse the input from the lexer that was specified at object construction
     * time.  Return whether the parsing ended successfully.
     *
     * @return <code>true</code> if the parsing succeeds, and <code>false</code> otherwise.
     */

    @Override
    public boolean parse(){
        if (this.trc != 0){
            Trc.out.printf("ParserRnglrPlus debug not enabled\n");
        }
        ;
        this.disambiguate = (this.tablr.lr1kind & ParserLR.OPT_DISAM) != 0;
        ;
        enlargeGSS(0);                        // create first gss blocks
        enlargeGSS(1);
        this.levelGss = 2;                    // this serves to make makeSentinel below work
        this.gssNodeNr = 0;
        this.gssEdgeNr = 1;                   // for edges hash: 0 = null
        makeSentinel();                       // create a sentinel
        this.loc = 1;
        this.treeKind = TREE_FGROUPS;
        if (this.disambiguate){
            this.treeKind = TREE_NORMAL;
        }
        this.stater = new int[this.tablr.stateNr]; // what states are already in the current level
        boolean res = false;
        this.lastState = 0;
        int lastLevs = 0;
        int lastLeve = 0;
        this.lastLevStart = 0;
        this.lastLevEnd = 0;

        this.levelGss = this.gssNodeNr;
        this.absLevelGss = this.levelGss;
        this.delta = 0;
        this.levelEdgeGss = this.gssEdgeNr;
        this.deltaEdges = 0;
        this.absLevelGssEdges = this.levelEdgeGss;
        this.levelEdgeGss = this.gssEdgeNr;
        this.etrees = new int[this.tab.numOfNts];
        this.reduceWl = new int[400];
        this.reduceWli = 0;

        // create an initial ParseTop with grammar-initial-state,
        // set active-parsers to contain just this
        int first = newGSSENode(0,0,0);         // create a node for the start state
        ;
        this.level = 1;

        this.potter = new int[60];

        this.tab.tokLists[0] = new char[]{(char)this.tab.numOfToks};
        this.currentToken = tokenizer();
        int potlen = 0;

        ;
        // for each input symbol
        mainloop: for (;;){
            ;
            ;
            if (this.currentToken < 0) break;

            int topmostParsers = this.gssNodeNr - this.levelGss;
            int newNode = 0;
            int parser = 0;
            int oldparser = 0;

            if ((this.tablr.lr1kind & ParserLR.OPT_ISLES) != 0){    // lr modes on
                ;
                tryDeterministic: while (topmostParsers == 1){      // same as if ()for(;;)
                    if (this.tab.tokLists[this.currentToken].length != 1) break tryDeterministic;
                    // see if static lr mode applicable
                    parser = this.gssNodeNr - 1;
                    int spar = gssNodeDir[(parser)>>>NSHF][((parser)&MSK)];
                    boolean isfront = (this.tablr.stateStatus[spar] &
                        LALRRNFAtables.ISFRONTIER) != 0;
                    ;
                    lrs: if (isfront){
                        // there is only one gss node = one parser, and it has a frontier state
                        ;
                        int edge = gssNodeDir[(parser)>>>NSHF][((parser)&MSK)+NODE_EDGES] & 0x7fffffff;
                        if (gssEdgeDir[(edge)>>>NSHF][((edge)&MSK)] == 0){
                            int lev = this.level;
                            int prevedge = this.gssEdgeNr;
                            int fromnode = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
                            int fromstate = gssNodeDir[(fromnode)>>>NSHF][((fromnode)&MSK)];
                            if ((this.tablr.stateStatus[fromstate] & LALRRNFAtables.ISLALR) != 0){
                                 break lrs; // not from outsise isle
                            }
                            ;
                            int lrstate = parseLR();
                            if (lrstate < 0){
                                this.gssNodeNr = this.levelGss;  // make it fail
                                break mainloop;
                            }
                            ;
                            if (this.level > lev && this.gssNodeNr > this.levelGss){ // new level needed
                                this.level--;
                                makeSentinel();
                                this.level++;
                                this.levelGss = this.gssNodeNr;
                                this.absLevelGss = this.levelGss + this.delta;
                                this.levelEdgeGss = this.gssEdgeNr;
                                this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;
                                ;
                            } else {
                                // replace the node
                                this.stater[gssNodeDir[(this.gssNodeNr-1)>>>NSHF][((this.gssNodeNr-1)&MSK)]] = 0;   // remove the pointer to the node
                                this.gssNodeNr--;
                                int curEdgeNr = this.gssEdgeNr;
                                this.gssEdgeNr = prevedge;
                                this.delta += 1;       // roll up total delta
                                this.absLevelGss = this.levelGss + this.delta;
                                this.deltaEdges += curEdgeNr - this.gssEdgeNr;
                                this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;
                                // adjust the sentinel
                                gssNodeDir[(this.levelGss-2)>>>NSHF][((this.levelGss-2)&MSK)] = -this.level;
                            }
                            int nrf = PDGR_FIELDS + PDGR_CFIELDS;
                            if (this.gssEdgeNr+nrf > this.gssEdgeLength){
                                enlargeEdges(this.gssEdgeNr+nrf);
                            }

                            // compute the cover
                            int tonode = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
                            int tonodeLev = 0;
                            sent: {
                                if (gssNodeDir[(tonode)>>>NSHF][((tonode)&MSK)+NODE_EDGES] != 0){
                                    int edu = gssNodeDir[(tonode)>>>NSHF][((tonode)&MSK)+NODE_EDGES] & 0x7fffffff;
                                    int pdu = gssEdgeDir[(edu+EDGE_PDGR)>>>NSHF][((edu+EDGE_PDGR)&MSK)];
                                    if (pdu > 1 && (pdu & PDGR_MSK) == 0){  // not token nor e-nt
                                        tonodeLev = gssEdgeDir[(pdu-3)>>>NSHF][((pdu-3)&MSK)];
                                        break sent;
                                    }
                                }
                                tonodeLev = tonode--;
                                while (gssNodeDir[(tonodeLev)>>>NSHF][((tonodeLev)&MSK)] >= 0) tonodeLev--; 
                            }

                            this.LRtree = addPedigree(tonodeLev,this.levelGss - 1,this.LRtree);
                            ;

                            // no need to check for duplicates
                            newNode = addNode(lrstate,gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)],this.LRtree,0);
                            parser = newNode;
                            // it seems that most of the times when the lr static ends, the new
                            // state is not a frontier one
                            // continue;
                        } else {
                            // if there are several edges the lr dyn is not applicable
                            break tryDeterministic;
                        }
                    }

                    if (this.tab.tokLists[this.currentToken].length != 1) break tryDeterministic;
                    ;
                    // lr dynamic mode
                    ;
                    int lrres = parseLRdyn();
                    ;
                    if (lrres == -2) return false;
                    newNode = this.gssNodeNr-1;
                    oldparser = 0;
                    if (lrres == -1) break tryDeterministic;
                    if (lrres == -3) break mainloop;
                    if (lrres == 0){
                        parser = newNode;
                        this.currentToken = tokenizer();
                        continue mainloop;
                    }
                    ;
                } // tryDeterministic
                ;
            }

            // repeatedly run the reducer, and the scanner to save tokens
            int lexstore = 0;
            potlen = 0;                            // initialise pot for next list
            int start = newNode;
            if (start == 0) start = this.levelGss;
            int i = start;
            this.reduceWldp = 0;
            ;
            clo: for (;;){
                boolean advanceList = false;
                cloloop: if (i < this.gssNodeNr){
                    advanceList = true;
                    // process shifts and reductions
                    int state = gssNodeDir[(i)>>>NSHF][((i)&MSK)];

                    int flen = 0;
                    int fstart = 0;
                    for (int t = 0; t < this.tab.tokLists[this.currentToken].length; t++){
                        this.currentTokNr = this.tab.tokLists[this.currentToken][t];
                        int tk = this.currentTokNr+this.tab.tokBase;
                        flen = this.tablr.LRbase[state];fstart = flen + tk;flen = this.tablr.LRcheck[fstart] == flen ? this.tablr.LRtable[fstart] : 0;if (flen> 0){flen= 1;} else if (flen < 0){fstart= -flen;flen = this.tablr.LRtable[fstart++];};
                        ;
                        boolean nonZeroReduction = false;
                        // process the empty reductions and save the shifts, if any
                        for (int j = 0; j < flen; j++){
                            int act = this.tablr.LRtable[fstart+j];
                            ;
                            if (act >= ParserLRTables.ISREDUCE){      // reduction
                                int m = ((act& ParserLRTables.EMPTYMASK) != 0 ? 0 : 1);
                                if (m == 0){                // empty reduction
                                    int nt = (act& ParserLRTables.GPMASK);
                                    ;
                                    reducer(i,act,0,false);
                                } else {
                                    nonZeroReduction = true;
                                }
                            } else {                  // shift
                                // put it in potter
                                if (potlen >= this.potter.length){
                                    this.potter = Arrays.copyOf(this.potter,this.potter.length << 1);
                                }
                                // there is no need here to check if there is already such a shift
                                // in potter: at the worst we will try twice the same shift
                                this.potter[potlen++] = act;   // new state
                                this.potter[potlen++] = i;     // item to be advanced
                                this.potter[potlen++] = this.currentTokNr;   // token number
                                lexstore |= act;
                                ;
                            }
                        }
                        // process the nonempty reductions (if any): do them down to
                        // all the edges
                        if (nonZeroReduction){
                            ;
                            for (int edge = gssNodeDir[(i)>>>NSHF][((i)&MSK)+NODE_EDGES] & 0x7fffffff; edge != 0; edge = gssEdgeDir[(edge)>>>NSHF][((edge)&MSK)]){
                                ;
                                if (gssEdgeDir[(edge+EDGE_PDGR)>>>NSHF][((edge+EDGE_PDGR)&MSK)] == 0) continue;      // rn reduction useless
                                for (int j = 0; j < flen; j++){
                                    int act = this.tablr.LRtable[fstart+j];
                                    if (act < ParserLRTables.ISREDUCE) continue; // not a reduction
                                    int m = ((act& ParserLRTables.EMPTYMASK) != 0 ? 0 : 1);
                                    if (m == 0) continue;                        // empty reduction
                                    ;
                                    reducer(i,act,edge,false);
                                }
                            }
                        }
                    }

                } else if (this.reduceWldp != this.reduceWli){
                    ;
                    ;
                    int itm = this.reduceWl[this.reduceWldp++];
                    int ru = this.reduceWl[this.reduceWldp++];
                    int mm = this.reduceWl[this.reduceWldp++];
                    int ed = this.reduceWl[this.reduceWldp++];
                    for (int j = 0; j < mm; j++){
                        // the entry in the compressed table
                        int act = this.tablr.LRtable[ru+j];
                        if (act >= ParserLRTables.ISREDUCE){      // reduction
                            int m = ((act& ParserLRTables.EMPTYMASK) != 0 ? 0 : 1);
                            if (m == 0) continue;                 // empty reduction
                            ;
                            reducer(itm,act,ed,true);
                        }
                    }
                    this.currentRed = this.reduceWldp;
                } else {
                    break;
                } // cloloop
                if (advanceList){
                    i++;
                }
            } // clo
            ;

            this.absReduceWli += this.reduceWli;
            this.reduceWli = 0;
            ;

            ;
            //Trc.out.printf("lev: %d levelGss %d absLevelGss %d\n",
            //    this.level,this.levelGss,this.absLevelGss);
            //tracerItemsList(this.levelGss-2);
            lastLevs = this.levelGss;
            lastLeve = this.gssNodeNr;
            if ((FL_C & this.trc) != 0){
                Trc.out.printf("--- %s --- %s\n",tokenToString(this.currentToken),this.lex.toString());
                traceEbnfLev();
            }
            makeSentinel();
            this.level++;
            ;
            ;

            this.levelGss = this.gssNodeNr;
            this.absLevelGss = this.levelGss + this.delta;
            this.levelEdgeGss = this.gssEdgeNr;
            this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;

            ;
            for (int k = 0; k < potlen; k += 3){         // scan the potter
                int newState = potter[k] & 0xfffffff;
                int toadvance = potter[k+1];
                int toknr = potter[k+2];
                int z = 0;
                st: if (this.currentToken != EOF){
                    for (int kk = 0; kk < k; kk +=3){    // test if the first of this token kind
                        if (toknr == potter[kk+2]){      // already encountered
                            z = potter[kk+1];
                            break st;
                        }
                    }
                    z = saveToken(lexstore,toknr);      // eof cannot be encoded
                    potter[k+2] = z;                    // save it
                }
                int w = addNode(newState,toadvance,z,1);
                if (w < 0) w = -w;
                ;
            }
            ;
            if (this.gssNodeNr == this.levelGss){    // kernel empty
                this.lastLevStart = lastLevs;
                this.lastLevEnd = lastLeve;
                break;
            }
            if (this.currentToken == EOF){
                break;                               // eof
            }
            int nexttoken = tokenizer();
            if (nexttoken < 0) break;

            this.currentToken = nexttoken;
            ;
        } // mainloop
        ;
        // we come here either with a token that has not been recognized. i.e.
        // no parsers could shift it, or with an EOF shifted, i.e. a node for the
        // state that has S'-> S EOF .
        ;
        rec: if (this.gssNodeNr - this.levelGss != 1){
            res = false;
            // reposition at beginning of erroneous token
            this.lex.stream.cursor = this.lex.stream.markPos;
        } else {
            if (this.currentToken != EOF){
                res = false;
                break rec;
            }
            res = true;
            ;
            int e = gssNodeDir[(this.levelGss)>>>NSHF][((this.levelGss)&MSK)+NODE_EDGES] & 0x7fffffff;
            int to = gssEdgeDir[(e+EDGE_TO)>>>NSHF][((e+EDGE_TO)&MSK)];
            ;

            e = gssNodeDir[(to)>>>NSHF][((to)&MSK)+NODE_EDGES] & 0x7fffffff;
            ;
            int pd = gssEdgeDir[(e+EDGE_PDGR)>>>NSHF][((e+EDGE_PDGR)&MSK)];
            if ((pd& PDGR_MSK) == E_NT){
                int startnt = this.tab.grammar[this.tab.startRule];
                encodeEtree(startnt);    // return tree in treeStart and treeLen
            } else {
                encodetree(pd);     // return tree in treeStart and treeLen
            }
        }
        makeSentinel();     // close the gss
        // only if singletons
        if ((ParserGen.SINGLETONS & this.tab.mode) != 0){
            if (res){
                encodeChains();        // add the missing chains
            }
        }
        ;
        //statistics(Trc.wrt);
        /*
        if (!res) expectedTokens();
        */
        return res;
    }

    /**
     * Trace the items that belong to the specified state showing their EBNF dotted rule.
     *
     * @param     state number of the state
     */

    private void traceEbnfState(int state){
        /*
        Trc.out.printf(".... state %s\n",state);
        */
        TreeSet<String> items = new TreeSet<String>();
        int loc = this.tablr.stateDots[state];
        int n = this.tablr.stateDots[loc++];
        for (int j = 0; j < n; j++){
            items.add(this.tab.ruleEbnfToString(this.tablr.stateDots[loc],true));
            loc++;
        }
        for (String s : items){
            Trc.out.printf("%s\n",s);
        }
    }

    /**
     * Trace the items that belong to the current GSS level showing their EBNF dotted rule.
     *
     * @param     state number of the state
     */

    private void traceEbnfLev(){
        /*
        Trc.out.printf(".... states");
        for (int i = this.levelGss; i < this.gssNodeNr; i++){
            int state = STATENR(i);
            Trc.out.printf(" %s",state);
        }
        Trc.out.printf("\n");
        */
        TreeSet<String> items = new TreeSet<String>();
        for (int i = this.levelGss; i < this.gssNodeNr; i++){
            int state = gssNodeDir[(i)>>>NSHF][((i)&MSK)];
            int loc = this.tablr.stateDots[state];
            int n = this.tablr.stateDots[loc++];
            for (int j = 0; j < n; j++){
                items.add(this.tab.ruleEbnfToString(this.tablr.stateDots[loc],true));
                loc++;
            }
        }
        for (String s : items){
            Trc.out.printf("%s\n",s);
        }
    }

    /** The number of the last state encountered in LR mode parsing. */
    private int lastState;

    /** The index in the GSS nodes of the last level built. */
    private int lastLevStart;

    /** The end index in the GSS nodes of the last level built. */
    private int lastLevEnd;

    /**
     * Deliver an array of the names of the tokens that are expected at the current parsing
     * position.
     *
     * @return     array
     */

    @Override
    public String[] expectedTokens(){
        if (this.currentToken != EOF){
            ;
            return new String[]{"EOF"};
        }
        if (this.lastState != 0){
            return expTokensState(this.lastState);
        } else if (this.lastLevStart != 0){
            return expTokensLev();
        }
        return null;
    }

    /**
     * Deliver an array of the names of the tokens that are expected in the specified state
     * position.
     *
     * @param      state number of the state
     * @return     array
     */

    private String[] expTokensState(int state){
        TreeSet<Integer> items = new TreeSet<Integer>();
        ;
        int loc = this.tablr.stateDots[state];
        int n = this.tablr.stateDots[loc++];
        for (int j = 0; j < n; j++){
            int gp = this.tab.grammar[this.tablr.stateDots[loc]];
            if (this.tab.tokBase <= gp && gp < this.tab.ruleBase){
                items.add(gp);
            }
            loc++;
        }
        String[] res = new String[items.size()];
        int i = 0;
        for (int s : items){
            res[i++] = this.tab.gramSymToString(s);
            ;
        }
        return res;
    }

    /**
     * Deliver an array of the names of the tokens that are expected in the last GSS
     * level.
     *
     * @return     array
     */

    private String[] expTokensLev(){
        ;
        TreeSet<Integer> items = new TreeSet<Integer>();
        for (int i = this.lastLevStart; i < this.lastLevEnd; i++){
            int state = gssNodeDir[(i)>>>NSHF][((i)&MSK)];
            ;
            int loc = this.tablr.stateDots[state];
            int n = this.tablr.stateDots[loc++];
            for (int j = 0; j < n; j++){
                int gp = this.tab.grammar[this.tablr.stateDots[loc]];
                if (this.tab.tokBase <= gp && gp < this.tab.ruleBase){
                    items.add(gp);
                }
                loc++;
            }
        }
        String[] res = new String[items.size()];
        int i = 0;
        for (int s : items){
            res[i++] = this.tab.gramSymToString(s);
            ;
        }
        return res;
    }


    /** The chain of items in a reduction path. */
    int[] pathItems;

    /**
     * Deliver a string representing the specified parser action.
     *
     * @param      act action
     * @return     string
     */

    private String actToString(int act){
        if (act >= ParserLRTables.ISREDUCE){          // reduction
            int gp = (act& ParserLRTables.GPMASK);
            int m = ((act& ParserLRTables.EMPTYMASK) != 0 ? 0 : 1);
            int reditem = ((act>> ParserLRTables.ELSHIFTS) & ParserLRTables.ELMASK);
            String str = "reduction " + this.tab.gramSymToString(gp) + " ";
            if (m == 0) str += "empty";
            if (gp >= this.tab.ruleBase){
                str += " elements " + reditem;
            } else {
                str += " item " + reditem;
            }
            return str;
        }
        return "shift to state " + (act & ~(ParserLRTables.SAVELEX | ParserLRTables.SAVEPOS));
    }

    /**
     * Deliver the next set of tokens. It matches in the input the longest possible
     * string that correspond to some tokens in the lexis, and retuns a set of the
     * token numbers that can derive that string.
     *
     * @return     number of the set of tokens, -1 if none matched, tokLists.length if EOF
     */

    @Override
    int tokenizer(){
        ParserTables tab = this.tab;
        int res = -1;
        int set = 0;
        doit: do {
            set = this.lex.lex();
            if (this.lex.eof()){
                ;
                res = EOF;
                break doit;
            } else {
                if (set == 0){
                    ;
                    break doit;
                }
                res = set;   // set of tokens
            }
            ;
        } while (this.tab.tokLists[set][0] == tab.ignore);
        ;
        this.numOfTokens++;
        return res;
    }

    /** The number of the current line. */
    private int line;

    /**
     * Take the specified token and save it in the token pool saving its string and/or
     * point as requested by its shift action.
     *
     * @param      act shift action
     * @param      tokNr token kind
     * @return     encoding of the token for the parse tree
     */

    int saveToken(int act, int tokNr){
        int res = 0;
        boolean lexstore = (act & ParserLRTables.SAVELEX) != 0;
        boolean pointstore = (act & ParserLRTables.SAVEPOS) != 0;
        ;
        tl: {
            BufReader stream = this.lex.stream;
            int lexNr = 0;
            if (lexstore){
                if (this.pool == null){
                    this.pool = new ParserPool();  // allocate string pool
                }
                lexNr = this.pool.addUnique(stream.buffer,
                    stream.markPos,
                    stream.cursor - stream.markPos);
                this.pooled++;
                ;
            }
            long point = stream.index - stream.end + stream.markPos;
            if (!pointstore){                         // do not store point
                long tk = lexNr * this.tab.numOfToks + tokNr + 1;
                if ((tk & 0xe0000000) == 0){          // packing possible
                    res = (int)tk | TOK_ELEM;
                    break tl;
                }
                point = -1L;
            }
            if (!lexstore) lexNr = -1;
            int lastTok = addToken(lexNr,tokNr,point);
            res = lastTok | TOK_ELEM;
        } // tl
        ;
        ;
        return res;
    }

    /**
     * Deliver a string representing the specified tokens.
     *
     * @param      number of the set of tokens
     * @return     string
     */

    private String tokenToString(int set){
        if (set < 0) return "unknown";
        if (set == this.EOF) return "EOF";
        return this.tab.tokSetToString(set);
    }

    /** Whether the GSS is cyclic. */
    private boolean gssCyclic;

    /**
     * Perform all reductions from the specified firstitm GSS node and down
     * the specifed edge, or no edge if the reduction has length zero.
     *
     * @param   firstitm GSS node from which the reduction starts
     * @param   act reduction action, from the compressed table
     * @param   start edge of firstitm down which the reduction is made, if
     *          the length of the reduction is not zero, and 0 otherwise.
     * @param   rwl <code>true</code> if the reduction is done from the rwl
     */

    private void reducer(int firstitm, int act, int startedge, boolean rwl){
        ;
        int startred = gssNodeDir[(firstitm)>>>NSHF][((firstitm)&MSK)];
        int gp = (act& ParserLRTables.GPMASK);
        int nt = gp;
        boolean fixed = false;
        int derlen = 0;
        int reditem = ((act>> ParserLRTables.ELSHIFTS) & ParserLRTables.ELMASK);
        if (gp >= this.tab.ruleBase){
            gp -= this.tab.ruleBase;
            nt = this.tab.ruleToNt[gp];
            fixed = true;
            derlen = reditem;
        }
        int m = ((act& ParserLRTables.EMPTYMASK) != 0 ? 0 : 1);                   // if empty
        ;
        ;
        // getting the paths from start makes parse times much longer because a lot more paths
        // are found: all the ones that passes for all neighbours of start, and not only from v,
        // so, we get instead the paths starting at v

        boolean repgroup = this.tab.ntKind[nt] <= ParserTables.REF;
        boolean nullbody = false;
        if (repgroup){
            int body = this.tab.body(nt);
            nullbody = ((this.tab.nullable[(body)>>>ParserTables.NSHIFTB] & (1 << (body& ParserTables.MASKB))) != 0);
        }
        boolean nullrule = false;
        ;
        int second = 0;
        if (m > 0){                       // not an empty reduction
            second = gssEdgeDir[(startedge+EDGE_TO)>>>NSHF][((startedge+EDGE_TO)&MSK)];
            if (gssNodeDir[(second)>>>NSHF][((second)&MSK)+NODE_EDGES] == 0){      // no path beyond startedge
                nullrule = true;
            } else if (derlen == 1){
                nullrule = true;
            }
        } else {
            nullrule = true;
        }
        // nullrule here means that there are no edges to find
        int lev = 0;
        boolean first = true;
        int ed = 0;
        ;
        if (fixed){
            // allocate pathIterator to the max derlen
            if (this.pathIterator == null || this.pathIterator.length < this.tablr.longestRule){
                this.pathIterator = new int[this.tablr.longestRule];
            }
        }
        if (this.pathIterator == null || this.pathIterator.length < 100){
            this.pathIterator = new int[100];
            this.pathItems = new int[100];
        }
        int[] pathedg = this.pathIterator;           // progress points in states to deliver next path
        int[] pathitm = this.pathItems;
        if (m > 0){
            // this is needed in order to have something to start with to make paths
            if (!fixed){
                // if variable length compute the item of the second state of the path
                act &= ~(ParserLRTables.ELMASK << ParserLRTables.ELSHIFTS);
                int bas = this.tablr.hopBase[startred];
                int start = bas+reditem;
                int itemnr = this.tablr.hopCheck[start] == bas ? this.tablr.hopTable[start] : -1;
                act |= (itemnr << ParserLRTables.ELSHIFTS);
                ;
                reditem = itemnr;
            }
            pathedg[lev] = startedge;                // actually, the first edge
            pathitm[lev] = reditem;                  // the items in tonode of the first edge
            lev++;
        }
        allph: for (;;){                             // visit all paths
            this.lev = lev;
            // take all paths, do not discard any of repetition groups otherwise
            // empty {""}* will have only a path for an empty body
            int res = getpath(nullrule,first,second,derlen,
                fixed,startedge,nullbody);
            this.nrPaths++;
            first = false;
            lev = this.lev;
            if (res == 1){
                continue allph;
            } else if (res == 2){
                break allph;
            }
            int u = 0;                   // to node
            if (m == 0){
                u = firstitm;
            } else {
                u = gssEdgeDir[(this.pathIterator[this.lev-1]+EDGE_TO)>>>NSHF][((this.pathIterator[this.lev-1]+EDGE_TO)&MSK)];
            }
            // if u is in the current level, and the reduction is for a BOD, skip
            if (this.disambiguate){
                if (nt < this.tab.ruleBase && this.tab.ntKind[nt] == ParserTables.BOR){
                    if (u >= this.levelGss){
                        ;
                        break allph;
                    }
                }
            }
            int k = gssNodeDir[(u)>>>NSHF][((u)&MSK)];
            int lrbase0= this.tablr.LRbase[k];int pl = this.tablr.LRcheck[lrbase0+nt] == lrbase0 ? this.tablr.LRtable[lrbase0+nt] : 0;;
            ;

            int w = addNode(pl,u,0,1);
            int wa = Math.abs(w);
            if (u > this.levelGss && wa <= u){     // backlink, GSS contains a cycle
                this.gssCyclic = true;
            }
            // TRACE(O,"nonterminal shift %s/%s<-%s-%s/%s\n",u,STATENR(u),
            //    this.tab.gramSymToString(nt),wa,STATENR(wa));

            addtree: if (m > 0){
                if (this.addedEdge < 0){                       // edge already there
                    int pdgr = gssEdgeDir[(-this.addedEdge+EDGE_PDGR)>>>NSHF][((-this.addedEdge+EDGE_PDGR)&MSK)];
                    if ((pdgr& PDGR_MSK) == E_NT || (pdgr & HEADF) == HEAD){  // empty etree: all its derivations ..
                        break addtree;                         // .. already there
                    }
                }
                int newsym =  this.addedEdge >= 0 ? 0 : gssEdgeDir[(-this.addedEdge+EDGE_PDGR)>>>NSHF][((-this.addedEdge+EDGE_PDGR)&MSK)];
                int tonode = u;

                // compute the cover
                int tonodeLev = 0;
                sent: {
                    if (gssNodeDir[(u)>>>NSHF][((u)&MSK)+NODE_EDGES] != 0){
                        int edu = gssNodeDir[(u)>>>NSHF][((u)&MSK)+NODE_EDGES] & 0x7fffffff;
                        int pdu = gssEdgeDir[(edu+EDGE_PDGR)>>>NSHF][((edu+EDGE_PDGR)&MSK)];
                        if (pdu > 1 && (pdu & PDGR_MSK) == 0){
                            tonodeLev = gssEdgeDir[(pdu-3)>>>NSHF][((pdu-3)&MSK)];
                            break sent;
                        }
                    }
                    tonodeLev = tonode--;
                    while (gssNodeDir[(tonodeLev)>>>NSHF][((tonodeLev)&MSK)] >= 0) tonodeLev--; 
                }

                // if non-null reduction pass the edge down which the reduction is made
                int rednode = startedge;
                int pdgr = addPedigree(newsym,rednode,act,tonodeLev,this.levelGss - 1);
                if (this.addedEdge >= 0){            // edge added
                    gssEdgeDir[(this.addedEdge+EDGE_PDGR)>>>NSHF][((this.addedEdge+EDGE_PDGR)&MSK)] = pdgr;
                }
            } else {
                if (this.addedEdge >= 0){     // edge added (with node added or present)
                    gssEdgeDir[(this.addedEdge+EDGE_PDGR)>>>NSHF][((this.addedEdge+EDGE_PDGR)&MSK)] = nt | E_NT;
                }
            }
            int aedge = Math.abs(this.addedEdge);
            ;
            red: if (this.addedEdge >= 0){         // edge added
                if (w < 0){                        // new node not added, only edge added
                    if (m != 0){
                        w = -w;
                        addred: if (!rwl && w == firstitm){
                            ;
                            if (gssNodeDir[(firstitm)>>>NSHF][((firstitm)&MSK)+NODE_EDGES] >= 0){         // short list
                                if (gssEdgeDir[(this.addedEdge+EDGE_TO)>>>NSHF][((this.addedEdge+EDGE_TO)&MSK)] > gssEdgeDir[(startedge+EDGE_TO)>>>NSHF][((startedge+EDGE_TO)&MSK)]) break addred;
                            }                          // long list: new edge prepended
                            int flen = 0;
                            int fstart = 0;
                            for (int t = 0; t < this.tab.tokLists[this.currentToken].length; t++){
                                this.currentTokNr = this.tab.tokLists[this.currentToken][t];
                                int tk = this.currentTokNr+this.tab.tokBase;
                                flen = this.tablr.LRbase[gssNodeDir[(firstitm)>>>NSHF][((firstitm)&MSK)]];fstart = flen + tk;flen = this.tablr.LRcheck[fstart] == flen ? this.tablr.LRtable[fstart] : 0;if (flen> 0){flen= 1;} else if (flen < 0){fstart= -flen;flen = this.tablr.LRtable[fstart++];};
                                if (flen > 0 && this.tablr.LRtable[fstart+flen-1] >=
                                    ParserLRTables.ISREDUCE){
                                    // enqueue only if there are reductions (but there could be only empty ones)
                                    addAllReductions(firstitm,fstart,flen,this.addedEdge);
                                }
                            }
                        }
                        int curItem = rwl ? this.gssNodeNr : firstitm;
                        if (w >= curItem) break red;  // node not yet processed
                        ;
                        // enqueue only nonempty reductions, i.e., the ones that have the added edge
                        int flen = 0;
                        int fstart = 0;
                        for (int t = 0; t < this.tab.tokLists[this.currentToken].length; t++){
                            this.currentTokNr = this.tab.tokLists[this.currentToken][t];
                            int tk = this.currentTokNr+this.tab.tokBase;
                            flen = this.tablr.LRbase[pl];fstart = flen + tk;flen = this.tablr.LRcheck[fstart] == flen ? this.tablr.LRtable[fstart] : 0;if (flen> 0){flen= 1;} else if (flen < 0){fstart= -flen;flen = this.tablr.LRtable[fstart++];};
                            if (flen > 0 && this.tablr.LRtable[fstart+flen-1] >=
                                ParserLRTables.ISREDUCE){
                                // enqueue only if there are reductions (but there could be only empty ones)
                                addAllReductions(w,fstart,flen,this.addedEdge);
                            }
                        }
                    }
                }
            }
            if (nullrule) break;
        } // allph
        ;
    }

    /**
     * Deliver the next path in the GSS starting from the specified node or edge.
     *
     * @param      nullrule whether the reduction is for an empty rule
     * @param      first whether it is the first path
     * @param      second second node in the path
     * @param      derlen length of the path if fixed
     * @param      fixed whether the paths has a fixed length
     * @param      startedge the starting edge of the path
     * @param      nullbody whether the body is nullable
     * @return     0: path delivered, 1: path to be discarded, 2: no more paths
     */

    /* getpath for variable length paths keeps two vectors: each pair of elements
     * represents a segment in the path: edge,item in tonode of edge.
     * The path starts from a node N, and it is represented in the vectors with the
     * first edge of the path (originating from N) and the item in the tonode of that edge.
     * The path ends with a last edge and a -1 item meaning that there is no item in
     * the tonode.
     * E.g.:
     *           n5/2<--e1----n6/3<--e2---n7/4
     * pathedg          e1           e2           state 4:              state 3:
     * pathitm          -1           i10             item 11 left 10       item 10 left -1
     */

    int getpath(boolean nullrule, boolean first, int second,
        int derlen, boolean fixed, int startedge, boolean nullbody){
        ;
        int res = 0;
        int lev = this.lev;
        int[] pathedg = this.pathIterator;       // progress points in states to deliver next path
        int[] pathitm = this.pathItems;
        int ed = 0;
        ;
        makepath: {
            boolean goleft = false;
            if (fixed){                          // find next fixed-length path
                up: if (first){
                    if (nullrule){
                        ;
                        break makepath;
                    }
                    ed = gssNodeDir[(second)>>>NSHF][((second)&MSK)+NODE_EDGES] & 0x7fffffff;
                    pathedg[lev++] = ed;
                } else {
                    ;
                    // build next path
                    // go up until it is possible to go sideways
                    while (lev > 1){
                        ed = pathedg[--lev];
                        ;
                        ed = gssEdgeDir[(ed)>>>NSHF][((ed)&MSK)];
                        if (ed != 0){
                            pathedg[lev++] = ed;
                            break up;
                        }
                    }
                    res = 2;
                    break makepath;
                }
                // go down to bottom
                while (lev < derlen){
                    int le = gssEdgeDir[(ed+EDGE_TO)>>>NSHF][((ed+EDGE_TO)&MSK)];
                    ;
                    ed = gssNodeDir[(le)>>>NSHF][((le)&MSK)+NODE_EDGES] & 0x7fffffff;
                    pathedg[lev++] = ed;
                }
            } else {                            // find nex variable-length path
                up: if (first){
                    if (nullrule){
                        ;
                        break makepath;
                    }
                    int node = gssEdgeDir[(pathedg[lev-1]+EDGE_TO)>>>NSHF][((pathedg[lev-1]+EDGE_TO)&MSK)];
                    int state = gssNodeDir[(node)>>>NSHF][((node)&MSK)];
                    int bas = this.tablr.hopBase[state];
                    int starth = bas+pathitm[lev-1];
                    int itemnr = this.tablr.hopCheck[starth] == bas ? this.tablr.hopTable[starth] : -1;
                    ;
                    if (itemnr < 0){             // no more chains
                        break makepath;
                    }
                    ed = gssNodeDir[(second)>>>NSHF][((second)&MSK)+NODE_EDGES] & 0x7fffffff;
                    if (this.gssCyclic){
                        int to = gssEdgeDir[(ed+EDGE_TO)>>>NSHF][((ed+EDGE_TO)&MSK)];
                        int pd = gssEdgeDir[(ed+EDGE_PDGR)>>>NSHF][((ed+EDGE_PDGR)&MSK)];
                        for (int c = 0; c < lev; c++){
                            if (gssEdgeDir[(pathedg[c]+EDGE_TO)>>>NSHF][((pathedg[c]+EDGE_TO)&MSK)] == to){
                                res = 1;
                                break makepath;
                            }
                        }
                    }
                    pathedg[lev] = ed;
                    pathitm[lev++] = itemnr;
                    ;
                } else {
                    ;
                    // build next path
                    // go up until it is possible to go sideways
                    while (lev >= 1){
                        ed = pathedg[--lev];
                        ;
                        if (lev == 0){
                            res = 2;
                            break makepath;   // do not visit the siblings of the first edge
                        }
                        ed = gssEdgeDir[(ed)>>>NSHF][((ed)&MSK)];
                        if (ed != 0){
                            goleft = true;
                            break up;
                        }
                    }
                    res = 2;
                    break makepath;
                }
                // go down to bottom
                for (;;){
                    if (goleft){
                        goleft = false;
                    } else {
                        int le = gssEdgeDir[(ed+EDGE_TO)>>>NSHF][((ed+EDGE_TO)&MSK)];
                        ;
                        ed = gssNodeDir[(le)>>>NSHF][((le)&MSK)+NODE_EDGES] & 0x7fffffff;
                    }
                    int node = gssEdgeDir[(pathedg[lev-1]+EDGE_TO)>>>NSHF][((pathedg[lev-1]+EDGE_TO)&MSK)];
                    int state = gssNodeDir[(node)>>>NSHF][((node)&MSK)];
                    int bas = this.tablr.hopBase[state];
                    int starth = bas+pathitm[lev-1];
                    int itemnr = this.tablr.hopCheck[starth] == bas ? this.tablr.hopTable[starth] : -1;
                    ;
                    if (itemnr < 0){             // no more chains
                        break makepath;
                    }
                    if (ed == 0){
                        res = 1;
                        break makepath;
                    }
                    if (this.gssCyclic){
                        int to = gssEdgeDir[(ed+EDGE_TO)>>>NSHF][((ed+EDGE_TO)&MSK)];
                        int pd = gssEdgeDir[(ed+EDGE_PDGR)>>>NSHF][((ed+EDGE_PDGR)&MSK)];
                        for (int c = 0; c < lev; c++){
                            if (gssEdgeDir[(pathedg[c]+EDGE_TO)>>>NSHF][((pathedg[c]+EDGE_TO)&MSK)] == to){
                                res = 1;
                                break makepath;
                            }
                        }
                    }
                    if (lev >= this.pathIterator.length){
                        this.pathIterator = Arrays.copyOf(this.pathIterator,lev+100);
                        pathedg = this.pathIterator;
                        this.pathItems = Arrays.copyOf(this.pathItems,lev+100);
                        pathitm = this.pathItems;
                    }
                    pathedg[lev] = ed;
                    pathitm[lev++] = itemnr;
                    ;
                }
            }
        } // makepath
        this.lev = lev;
        if (res == 0){
            ;
        } else {
            ;
        }
        return res;
    }

    /** The length of the path. */
    private int lev;


    /* Edges
     *
     *    +0  nextedge   index of the next edge of the same node, HEADSYM if hashed
     *    +1  tonode     index of the reached node
     *    +2  pedigree   E_NT | nt:   etree (cannot occur with groups)
     *                   < 0:         token
     *                   > 0:         index of pedigree in the edges array
     *
     * There are no proper pedigrees for e-nt since pedigrees are needed for the cover,
     * which is zero.
     * Pedigrees (in the edges array), which will later be used to encode the final forest by
     * encodetree.
     *
     *    -3  end:     end cover
     *    -2  start:   HEADSYM | index of nodes sentinel+1 (start)
     *    -1  remap:   index in the final forest
     *  ->+0  next:    index of next pedigree           --------.
     *    +1  redu:    reduction                                |
     *    +2  sub:     index of gss node/edge or HEAD|tree      |
     *                                                          |
     *   causal:                                                |
     *    +0  next:    index of next pedigree            <------'
     *    +1  redu:    reduction
     *    +2  sub:     index of gss node/edge or HEAD|tree
     *
     * Edges refer to pedigrees at the index marked ->  above. In so doing, the next,
     * redu and gss fields of all the pedigrees of the same edge are accessed with the
     * same offsets. They are linked by the next field. When a new one is added, it is
     * prepended to the list.
     * The redu field denotes a nonempty reduction (if the reduction is empty, a 
     * e-nt pedigree is stored in the edge).
     * The sub field contains either an index in the final tree (if HEAD) or that
     * of an edge down which the reduction is made.
     *
     * The start field and the redu field have a flag that allows to distinguish them
     * and them from the edges. The edges have no flag. The pedigrees have HEADSYM
     * in the second field, and the causal parts have HEAD in the second field (i.e.
     * the reduction flag).
     * This allows to scan the edges array telling what object is encountered.
     *
     * When reductions are not empty, i.e. have some symbol to reduce, they are done
     * down a specific edge of their starting node. The edge is stored in the sub
     * field. If they are not fixed, then the item to start with is the one reached
     * from the item stored in the origin reduction. It is stored in the item part of the
     * redu field.
     *
     * In the LR stack, the pedigree denotes:
     *
     *    < 0          token
     *    0            nullable nt
     *    HEAD | tree  already built, tree: index in the final forest
     *    pdgr         index of the pedigree in the edges array, with a final tree in it
     *
     * The format in the final forest is:
     *
     *    symbol node:
     *
     *    +0  head:    HEADSYM | number of alternatives
     *    +1           index of first alternative
     *    +.           .....
     *    +n           index of last alternative
     *
     *    rule node:
     *
     *    +0  head:    HEAD | (rule number if not variable repetition group, otherwise numOfRules + nr. of elements)
     *    +1           elements
     *
     *    elements:
     *
     *    < 0          token
     *    tree         index of a sppf node
     */

    /** 
     * Add a pedigree with the specified data. If a pedigree with the same cover already
     * exists, then add an additional element to it.
     *
     * @param   pdgr index of a pedigree to search, 0 to create one
     * @param   rednode reduction gss node if empty reduction, otherwise the edge down
     *          which the reduction must be done
     * @param   start index of the sentinel of the start level
     * @param   end index of the sentinel of the end level
     * @return  index of the pedigree
     */

    /* The cover of the derivation to be added is represented with the index of the
     * level at which its first element starts.
     * A hash table links all the pedigrees and allows to find quicly one that has the
     * desired nt and cover.
     * Another hash table links all the rule nodes that have the desired nt and elements
     * and allows to find quickly if the desired rule node is already present.
     */

    int addPedigree(int pdgr, int rednode, int redu, int start, int end){
        int nt = (redu& ParserLRTables.GPMASK);
        if (nt >= this.tab.ruleBase){
            nt = this.tab.ruleToNt[nt-this.tab.ruleBase];
        }
        int m = ((redu& ParserLRTables.EMPTYMASK) != 0 ? 0 : 1);
        // there are cases in which we know already the pedigree, so skip search
        int hfunct = (nt + start) & (this.sppfsymhdir.length - 1);
        ;
        sy: if (pdgr == 0){
            for (int z = this.sppfsymhdir[hfunct];
                z >= this.absLevelGssEdges; z = this.edgeshlink[z-this.absLevelGssEdges]){
                int s = z - this.deltaEdges + PDGR_FIELDS;
                int red = gssEdgeDir[(s+1)>>>NSHF][((s+1)&MSK)];
                int lhs = (red& ParserLRTables.GPMASK);
                if (lhs >= this.tab.ruleBase){
                    lhs = this.tab.ruleToNt[lhs-this.tab.ruleBase];
                }
                if ((lhs == nt) &&
                    ((gssEdgeDir[(s-2)>>>NSHF][((s-2)&MSK)] & ~HEADSYM) == start)){    // found
                    pdgr = s;
                    ;
                    break;
                }
            }
        } else {
            ;
        }
        boolean createRedu = false;
        boolean embeddedRedu = false;
        boolean pdgradded = false;
        doit: if (pdgr == 0){          // create it
            int nrf = PDGR_FIELDS + PDGR_CFIELDS;
            if (this.gssEdgeNr+nrf > this.gssEdgeLength){
                enlargeEdges(this.gssEdgeNr+nrf);
            }
            int next = 0;
            int z = this.gssEdgeNr - this.levelEdgeGss;      // relative to level
            if (z >= this.edgeshlink.length){
                int newlen = z << 1;
                if (z < this.edgeshlink.length << 1){        // extend at least twice
                    newlen = this.edgeshlink.length << 1;
                }
                // this perhaps also in other places in which an unknown amount is needed
                this.edgeshlink = Arrays.copyOf(this.edgeshlink,newlen);
                this.edgeshdata = Arrays.copyOf(this.edgeshdata,newlen);
            }
            this.edgeshlink[z] = this.sppfsymhdir[hfunct];   // insert at beginning
            this.sppfsymhdir[hfunct] = this.gssEdgeNr + this.deltaEdges;
            // use edgeshdata[] to hold the tail of the list of rules
            this.edgeshdata[z] = this.gssEdgeNr + PDGR_FIELDS;
            ;

            this.gssEdgeNr += PDGR_FIELDS;
            pdgr = this.gssEdgeNr;
            gssEdgeDir[(this.gssEdgeNr-2)>>>NSHF][((this.gssEdgeNr-2)&MSK)] = HEADSYM | start;
            gssEdgeDir[(this.gssEdgeNr-3)>>>NSHF][((this.gssEdgeNr-3)&MSK)] = end;
            gssEdgeDir[(this.gssEdgeNr-1)>>>NSHF][((this.gssEdgeNr-1)&MSK)] = 0;
            gssEdgeDir[(this.gssEdgeNr)>>>NSHF][((this.gssEdgeNr)&MSK)] = 0;
        } else {
            for (int i = pdgr; i != 0; i = gssEdgeDir[(i)>>>NSHF][((i)&MSK)]){
                if (gssEdgeDir[(i+1)>>>NSHF][((i+1)&MSK)] == redu && gssEdgeDir[(i+2)>>>NSHF][((i+2)&MSK)] == rednode){
                    if (gssEdgeDir[(i+2)>>>NSHF][((i+2)&MSK)] != rednode) continue;
                    ;
                    return pdgr;
                }
            }
            if (this.gssEdgeNr+PDGR_CFIELDS > this.gssEdgeLength){
                enlargeEdges(this.gssEdgeNr+PDGR_CFIELDS);
            }
            gssEdgeDir[(this.gssEdgeNr)>>>NSHF][((this.gssEdgeNr)&MSK)] = gssEdgeDir[(pdgr)>>>NSHF][((pdgr)&MSK)];
            gssEdgeDir[(pdgr)>>>NSHF][((pdgr)&MSK)] = this.gssEdgeNr;
            ;
        }
        gssEdgeDir[(this.gssEdgeNr+1)>>>NSHF][((this.gssEdgeNr+1)&MSK)] = redu;
        gssEdgeDir[(this.gssEdgeNr+2)>>>NSHF][((this.gssEdgeNr+2)&MSK)] = rednode;
        this.gssEdgeNr += PDGR_CFIELDS;
        ;
        return pdgr;
    }
    
    /** 
     * Add a pedigree with the specified data.
     *
     * @param   start index of the sentinel of the start level
     * @param   end index of the sentinel of the end level
     * @param   tree index of the encoded tree
     * @return  index of the pedigree
     */

    int addPedigree(int start, int end, int tree){
        int nrf = PDGR_FIELDS + PDGR_CFIELDS;
        if (this.gssEdgeNr+nrf > this.gssEdgeLength){
            enlargeEdges(this.gssEdgeNr+nrf);
        }
        this.gssEdgeNr += PDGR_FIELDS;
        int res = this.gssEdgeNr;
        gssEdgeDir[(this.gssEdgeNr-2)>>>NSHF][((this.gssEdgeNr-2)&MSK)] = HEADSYM | start;
        gssEdgeDir[(this.gssEdgeNr-3)>>>NSHF][((this.gssEdgeNr-3)&MSK)] = end;
        gssEdgeDir[(this.gssEdgeNr-1)>>>NSHF][((this.gssEdgeNr-1)&MSK)] = 0;
        gssEdgeDir[(this.gssEdgeNr)>>>NSHF][((this.gssEdgeNr)&MSK)] = 0;
        gssEdgeDir[(this.gssEdgeNr+1)>>>NSHF][((this.gssEdgeNr+1)&MSK)] = HEAD;
        gssEdgeDir[(this.gssEdgeNr+2)>>>NSHF][((this.gssEdgeNr+2)&MSK)] = tree | HEADTREE;
        this.gssEdgeNr += PDGR_CFIELDS;
        ;
        return res;
    }

    /**
     * Deliver a string representing the specified reduction path.
     *
     * @param      firstitm first node in path
     * @param      reditem reduction item in first node, -1 is none
     * @param      pathedg sequence of edges
     * @param      pathitm sequence of items
     * @param      len end index in path
     * @param      nt nonterminal
     * @return     string
     */

    private String rnpToString(int firstitm, int reditem, int[] pathedg,
        int[] pathitm, int len, int nt){
        int startred = gssNodeDir[(firstitm)>>>NSHF][((firstitm)&MSK)];
        String str = "";
        str += this.tab.gramSymToString(nt) + " ::= " +
            firstitm + "/" + startred;
            if (reditem >= 0) str += "." + reditem;
        String strr = "";
        for (int k = 0; k < len; k++){
            int to = gssEdgeDir[(pathedg[k]+EDGE_TO)>>>NSHF][((pathedg[k]+EDGE_TO)&MSK)];
            strr += "---e" + pathedg[k] + ":" + edgeToSym(pathedg[k]) + "--->" +
                to + "/" + gssNodeDir[(to)>>>NSHF][((to)&MSK)];
            if (reditem >= 0) strr += "." + pathitm[k];
        }
        str += strr;
        return str;
    }

    /**
     * Deliver a string representing the grammar symbol associated to an edge.
     *
     * @param      e edge
     * @return     string
     */

    private String edgeToSym(int e){
        String res = null;
        int pdg = gssEdgeDir[(e+EDGE_PDGR)>>>NSHF][((e+EDGE_PDGR)&MSK)];
        if (pdg == 0) return "eof";
        doit: if ((pdg& PDGR_MSK) == E_NT){       // nullable nt
            res = this.tab.gramSymToString(pdg & ~PDGR_MSK) + "&";   // & for epsilon
        } else if (pdg == -1){          // invalid
            res = "?";
        } else if (pdg < 0){            // token
            res = getLexeme(getLexNr(pdg));
        } else if ((pdg & HEADF) != 0){ // already built
            pdg &= ~HEADF;
            res = getDerLit(pdg);
        } else {
            int s = gssEdgeDir[(pdg+2)>>>NSHF][((pdg+2)&MSK)];
            if ((s & HEADTREE) != 0){       // already encoded
                s &= ~HEADF;
                res = getDerLit(s);
            } else {
                int redu = gssEdgeDir[(pdg+1)>>>NSHF][((pdg+1)&MSK)];
                int lhs = (redu& ParserLRTables.GPMASK);
                if (lhs >= this.tab.ruleBase){
                    lhs -= this.tab.ruleBase;
                    lhs = this.tab.ruleToNt[lhs];
                }
                res = this.tab.gramSymToString(lhs);
            }
        }
        return res;
    }

    /**
     * Check that the specified index is that of an object of the specified kind,
     * print a stack trace and terminate the program if it is not.
     *
     * @param      idx index
     * @param      kind 0: edge, 1: pedigree, 2: causal pedigree
     */

    private void isObject(int idx, int kind){
        boolean res = false;
        for (int i = 1; i < this.gssEdgeNr;){
            int p = i + PDGR_FIELDS;
            int el = gssEdgeDir[(p-2)>>>NSHF][((p-2)&MSK)];
            if (el < 0){                    // pedigree
                if (p == idx && kind == 1){
                    res = true;
                    break;
                }
                i += PDGR_FIELDS + PDGR_CFIELDS;
            } else if ((el & HEADF) != 0){  // causal pedigree
                if (i == idx && kind == 2){
                    res = true;
                    break;
                }
                i += PDGR_CFIELDS;
            } else {
                if (i == idx && kind == 0){
                    res = true;
                    break;
                }
                i += EDGE_FIELDS;
            }
        }
        if (idx == PDGR_FAKE && kind == 1) return;
        if (!res){
            Trc.out.printf("%s not %s\n",idx,new String[]{"edge","pdgr","pdgr-c"}[kind]);
            new Throwable().printStackTrace(Trc.out);
            System.exit(1);
        }
    }

    /**
     * Deliver a string representing the specified array of pedigrees which are the elements
     * of the specified rule.
     *
     * @param      gamma array
     * @param      len length of the dignificant part of the array
     * @return     string
     */

    private String gammaToString(int[] gamma, int len){
        String str = "";
        for (int i = 0; i < len; i++){
            if (i > 0) str += " ";
            str += pdgrGssElToString(gamma[i],false);
        }
        return str;
    }

    /**
     * Deliver a string representing the specified casual pedigree.
     *
     * @param    r index of the pedigree
     * @param    full <code>true</code> to include the index and rule
     * @return   string
     */

    // redefined sppfRuleToString to support wrapper pedigrees
    @Override
    String sppfRuleToString(int r, boolean full){
        StringBuilder str = new StringBuilder();
        int link = gssEdgeDir[(r)>>>NSHF][((r)&MSK)];
        str.append(String.format("%s %s",r,pdgrCausalToString(r)));
        return str.toString();
    }

    /**
     * Deliver a string representing the specified element of casual pedigree.
     *
     * @param    el element
     * @return   string
     */

    String pdgrGssElToString(int el){
        if (el == PDGR_FAKE) return "";
        StringBuilder sb = new StringBuilder();
        pdgrGssElToString(el,sb,false);
        return sb.toString();
    }
    String pdgrGssElToString(int el, boolean full){
        if (el == PDGR_FAKE) return "";
        StringBuilder sb = new StringBuilder();
        pdgrGssElToString(el,sb,full);
        return sb.toString();
    }

    /**
     * Append a string representing the specified sub field of casual pedigree to
     * the specified string builder optionally showing the frontier of the subtree
     * when the elements denotes one.
     *
     * @param    el element
     * @param    sb string builder
     * @param    <code>true</code> to show the frontier, and <code>false</code> otherwise
     */

    void pdgrGssElToString(int el, StringBuilder sb, boolean frontier){
        pdgrGssElToString(el,sb,frontier,false);
    }
    void pdgrGssElToString(int el, StringBuilder sb, boolean frontier, boolean inside){
        if (el == 0) return;            // just in case
        doit: if ((el& PDGR_MSK) == E_NT){        // nullable nt
            sb.append(this.tab.gramSymToString(el & ~PDGR_MSK) + "&");   // & for epsilon
        } else if (el == -1){           // invalid
            sb.append("?");
        } else if (el < 0){             // token
            sb.append(getLexeme(getLexNr(el)));
        } else if ((el & HEADF) != 0){  // already encoded
            el &= ~HEADF;
            if (frontier){
                sb.append("(");
                encTreeToString(el,sb);
                sb.append(")");
            } else {
                sb.append(el + "t");
            }
        } else {
            int s = gssEdgeDir[(el+2)>>>NSHF][((el+2)&MSK)];
            if ((s & HEADTREE) != 0){       // already encoded
                s &= ~HEADF;
                if (frontier){
                    sb.append("(");
                    encTreeToString(s,sb);
                    sb.append(")");
                } else {
                    sb.append(s + "t");
                }
                break doit;
            }
            if (frontier && inside){
                // visit the pedigree
                // pdgrToString(el,sb);
                sb.append(el);
            } else {
                sb.append(coverToString(el));
                sb.append("p");
                boolean first = true;
                for (; el != 0; el = gssEdgeDir[(el)>>>NSHF][((el)&MSK)]){
                    if (!first){
                        sb.append(" p");
                    }
                    first = false;
                    sb.append(Integer.toString(el));
                    sb.append("(");
                    sb.append(pdgrCausalToString(el));
                    sb.append(")");
                }
            }
        }
    }

    private void pdgrToString(int pdgr, int pdgrstart, StringBuilder sb){
        int redu = gssEdgeDir[(pdgr+1)>>>NSHF][((pdgr+1)&MSK)];
        ;
        int lhs = (redu& ParserLRTables.GPMASK);
        boolean fixed = false;
        int derlen = 0;
        int rule = 0;
        int reditem = ((redu>> ParserLRTables.ELSHIFTS) & ParserLRTables.ELMASK);
        if (lhs >= this.tab.ruleBase){
            lhs -= this.tab.ruleBase;
            rule = lhs;
            lhs = this.tab.ruleToNt[lhs];
            fixed = true;
            derlen = reditem;
        }
        int m = ((redu& ParserLRTables.EMPTYMASK) != 0 ? 0 : 1);
        boolean repgroup = this.tab.ntKind[lhs] <= ParserTables.REF;
        boolean nullbody = false;
        if (repgroup){
            int body = this.tab.body(lhs);
            nullbody = ((this.tab.nullable[(body)>>>ParserTables.NSHIFTB] & (1 << (body& ParserTables.MASKB))) != 0);
        }
        // compute the paths
        // n.b. when the reductions are made down the first edge,
        // the edge is recorded in the pedigrees, and if it is variable,
        // the item of the second node

        boolean nullrule = false;
        int startedge = gssEdgeDir[(pdgr+2)>>>NSHF][((pdgr+2)&MSK)];
        int second = 0;
        if (m > 0){                       // not an empty reduction
            second = gssEdgeDir[(startedge+EDGE_TO)>>>NSHF][((startedge+EDGE_TO)&MSK)];
            if (gssNodeDir[(second)>>>NSHF][((second)&MSK)+NODE_EDGES] == 0){      // no path beyond startedge
                nullrule = true;
            } else if (derlen == 1){
                nullrule = true;
            }
            ;
        } else {
            nullrule = true;
            ;
        }
        // nullrule here means that there are no edges to find, and that
        // the path is made at most of one edge (the starting one)
        int lev = 0;
        boolean first = true;
        int ed = 0;

        ;

        // save the fields that getpath changes
        int[] savePiter = this.pathIterator;
        int[] savePitem = this.pathItems;
        int[] saveReus = this.reusablePath;
        int saveLev = this.lev;
        this.pathIterator = new int[100];
        this.pathItems = new int[100];
        this.reusablePath = new int[100];

        if (fixed){
            // allocate pathIterator to the max derlen
            if (this.pathIterator == null || this.pathIterator.length < this.tablr.longestRule){
                this.pathIterator = new int[this.tablr.longestRule];
            }
        }
        if (this.pathIterator == null || this.pathIterator.length < 100){
            this.pathIterator = new int[100];
            this.pathItems = new int[100];
        }
        int[] pathedg = this.pathIterator;           // progress points in states to deliver next path
        int[] pathitm = this.pathItems;
        if (m > 0){
            pathedg[lev] = startedge;                // actually, the first edge
            pathitm[lev] = reditem;                  // the items in tonode of the first edge
            lev++;
            // this is needed in order to have something to start with to make paths
        }
        allph: for (;;){                             // visit all paths
            this.lev = lev;
            // take all paths, do not discard any of repetition groups otherwise
            // empty {""}* will have only a path for an empty body
            int res = getpath(nullrule,first,second,derlen,
                fixed,startedge,nullbody);
            first = false;
            lev = this.lev;
            if (res == 1){
                continue allph;
            } else if (res == 2){                    // end of paths
                break allph;
            }
            // check that the path denotes a derivation with the same cover
            // as the pedigree
            int lastedge = pathedg[lev-1];
            int lastnode = gssEdgeDir[(lastedge+EDGE_TO)>>>NSHF][((lastedge+EDGE_TO)&MSK)];
            ;

            // check the cover
            int toLev = 0;
            sent: {
                if (gssNodeDir[(lastnode)>>>NSHF][((lastnode)&MSK)+NODE_EDGES] != 0){
                    int edu = gssNodeDir[(lastnode)>>>NSHF][((lastnode)&MSK)+NODE_EDGES] & 0x7fffffff;
                    int pdu = gssEdgeDir[(edu+EDGE_PDGR)>>>NSHF][((edu+EDGE_PDGR)&MSK)];
                    if (pdu > 1 && (pdu & PDGR_MSK) == 0){
                        toLev = gssEdgeDir[(pdu-3)>>>NSHF][((pdu-3)&MSK)];
                        break sent;
                    }
                }
                toLev = lastnode--;
                while (gssNodeDir[(toLev)>>>NSHF][((toLev)&MSK)] >= 0) toLev--; 
            }
            int startcover = pdgrstart & ~HEADSYM;
            ;
            if (toLev != startcover){
                if (nullrule) break;
                continue;
            }
            // build the derivation
            int len = lev;
            if (fixed){
                len = this.tab.ruleLen[rule];
            }
            if (this.reusablePath == null){
                this.reusablePath = new int[len];
            } else if (this.reusablePath.length < len){
                this.reusablePath = new int[len];
            }

            int[] gamma1 = this.reusablePath;
            int gj1 = 0;
            for (int g = lev-1; g >= 0; g--){
                gamma1[gj1++] = gssEdgeDir[(pathedg[g]+EDGE_PDGR)>>>NSHF][((pathedg[g]+EDGE_PDGR)&MSK)];
            }
            String str = "";
            for (int g = 0; g < gj1; g++){
                if (g > 0) str += "-";
                str += "e" + pathedg[g];
            }
            sb.append(str);

            /*
            int firstitm = 0;
            sea: for (int k = 0; k < this.gssNodeNr; k++){  // search from-node of startedge
                if (STATENR(k) < 0){    // sentinel
                    k++;
                } else {                // node
                    for (int e = EDGELIST(k); e != 0; e = NEXTEDGE(e)){
                        if (e == startedge){
                            firstitm = k;
                            break sea;
                        }
                    }
                }
            }
            String str = rnpToString(firstitm,fixed?-1:reditem,pathedg,pathitm,lev,lhs);
            String strr = "";
            String strrn = "";
            if (m > 0 && fixed){
                int gp = this.tab.ruleIndex[rule];
                for (int p = gp+derlen; this.tab.grammar[p] < this.tab.ruleBase; p++){
                    strr = this.tab.gramSymToString(this.tab.grammar[p]);
                    if (strr == "") strr = "\"\"";
                    strrn += strr;
                }
                if (strrn != ""){
                    str += " +rn-tail: " + strrn;
                }
            }
            sb.append("reduction: " + str);
            */

            int[] gamma = this.reusablePath;
            int gj = 0;
            // this works for groups because they have a path that encompasses all bodies,
            if (fixed){
                for (int g = lev-1; g >= 0; g--){
                    gamma[gj++] = gssEdgeDir[(pathedg[g]+EDGE_PDGR)>>>NSHF][((pathedg[g]+EDGE_PDGR)&MSK)];
                }
            } else {
                gj = filterPath(pathedg,lev,gamma,repgroup,nullbody,lhs);
                if (gj < 0){
                    if (nullrule) break allph;
                    continue allph;
                }
                len = gj;
            }
            /*
            for (int k = 0; k < len; k++){
                int el = gamma[k];
                if (sb.length() > 0){
                    if (sb.charAt(sb.length()-1) != ' '){
                       sb.append(' ');
                    }
                }
                pdgrGssElToString(el,sb,true,true);
            }
            */
            break;
        } // allPh
        // restore the fields that getpath changes
        this.pathIterator = savePiter;
        this.pathItems = savePitem;
        this.reusablePath = saveReus;
        this.lev = saveLev;
    }

    /**
     * Store a string representing the specified encoded tree in the specified string builder.
     *
     * @param    root root of the tree
     * @param    sb string builder
     */

    void encTreeToString(int root, StringBuilder sb){
        if (isAlt(root)){
            root = this.tree[(root+1)>>>NSHF][((root+1)&MSK)];                  // take the first one
        }
        int t = getLength(root);                  // length of phrase of derivation
        for (int i = root+1; i < root+1+t; i++){  // scan the derivation
            int s = this.tree[(i)>>>NSHF][((i)&MSK)];                      // take symbol
            if (s < 0){                           // token
                sb.append(getLexeme(getLexNr(s)));
            } else {
                encTreeToString(s,sb);
            }
        }
    }

    /**
     * Generate the final parse subforest for the specified nullable nonterminal.
     *
     * @param    root nonterminal
     * @return   index of the subforest in the forest
     */

    /*
     * Considering also the problematic ones:
     *      *     can have no iterations or 1 if the body is nullable
     *      +     one (body is nullable because otherwise group would not be nullable)
     *      n     n, same
     *      (:u)  0 ... u, same
     *      (l:)  l, same
     *      (l:u) l ... u, same
     *      []    0 or 1 if body nullable
     *
     * The case of body with an empty rule is special: {}* must have only one alternative
     * with zero iterations, and not two, and yet it has a body with an empty rule.
     */

    @Override
    protected int encodeEtree(int root){
        ;
        if (this.etrees[root] != 0){         // already done
            return this.etrees[root];
        }

        int loc = this.loc;
        int start = loc;
        int visitedNr = 0;                   // nr of nodes visited

        int dp = 0;
        int qp = 0;
        this.encodequeue[qp++] = root;       // enqueue root
        this.etrees[root] = -1;
        while (dp != qp){                        // while queue not empty
            int i = this.encodequeue[dp++];      // dequeue
            visitedNr++;
            ;

            this.etrees[i] = this.loc;           // remapping
            ;

            // get the number of rules
            int nrrules = 0;

            boolean zeroit = false;
            boolean group = false;
            int lower = 0;
            int zerohdr =  HEAD | this.tab.numOfRules;
            boolean nobody = false;
            if (this.tab.ntKind[i] <= ParserTables.REF || this.tab.ntKind[i] == ParserTables.OPT){
                group = true;
                int body = this.tab.body(i);
                boolean nulbody = ((this.tab.nullable[(body)>>>ParserTables.NSHIFTB] & (1 << (body& ParserTables.MASKB))) != 0);
                int rbody = this.tab.ntToRule[body];
                if (rbody < this.tab.ruleToNt.length-1 &&
                    this.tab.ruleToNt[rbody+1] != body){   // only one rule
                    if (this.tab.ruleLen[rbody] == 0){     // empty rule
                        nobody = true;
                    }
                }
                ;
                switch (this.tab.ntKind[i]){
                case ParserTables.REP:
                    if (nulbody) nrrules = 1;
                    lower = 1;
                    break;
                case ParserTables.RES:
                    if (nulbody && !nobody) nrrules = 1;
                    zeroit = true;
                    lower = 1;
                    if (this.disambiguate){
                        if (nulbody && !nobody){
                            boolean cyc = (ParserTables.CYC & this.tab.attr) != 0;
                            if (!cyc || !((this.tablr.ruleCyc[(rbody)>>>ParserTables.NSHIFTB] & (1 << (rbody& ParserTables.MASKB))) != 0)){
                                zeroit = false;
                            } else {
                                nrrules = 0;
                            }
                        }
                    }
                    break;
                case ParserTables.OPT:
                    if (nulbody && !nobody){
                        group = false;
                        nrrules = 1;
                    }
                    zeroit = true;
                    if (nulbody && nobody){
                        zeroit = false;
                        group = false;
                        nrrules = 1;
                    }
                    lower = 1;
                    if (this.disambiguate){
                        if (nulbody && !nobody){
                            boolean cyc = (ParserTables.CYC & this.tab.attr) != 0;
                            if (!cyc || !((this.tablr.ruleCyc[(rbody)>>>ParserTables.NSHIFTB] & (1 << (rbody& ParserTables.MASKB))) != 0)){
                                zeroit = false;
                                nrrules = 1;
                                i = body;
                            } else {
                                nrrules = 0;
                                group = true;
                            }
                        }
                    }
                    break;
                case ParserTables.REL:
                case ParserTables.REF:
                    if (nulbody) nrrules = 1;   // and the first rule has l elements
                    lower = this.tab.ruleLen[this.tab.ntToRule[i]];
                    break;
                case ParserTables.RER:
                    if (nulbody){               // u + 1 alternatives
                        int ru = this.tab.ntToRule[i];
                        for (int p = this.tab.ruleIndex[ru];; p++){
                            int gp = this.tab.grammar[p];
                            if (this.tab.ntKind[gp] == ParserTables.OBO){
                                lower = 
                                    (p - this.tab.ruleIndex[ru]);
                                nrrules = this.tab.ruleLen[this.tab.ntToRule[i]] - lower + 1;
                                break;
                            }
                        }
                        if (this.disambiguate) nrrules = 1;
                    }
                    break;
                case ParserTables.REU:
                    if (nulbody){               // u alternatives
                        int ru = this.tab.ntToRule[i];
                        nrrules = this.tab.ruleLen[ru];
                    }
                    zeroit = true;
                    if (this.disambiguate){
                        nrrules = 0;
                        if (nulbody && !nobody){
                            boolean cyc = (ParserTables.CYC & this.tab.attr) != 0;
                            if (!cyc || !((this.tablr.ruleCyc[(rbody)>>>ParserTables.NSHIFTB] & (1 << (rbody& ParserTables.MASKB))) != 0)){
                                zeroit = false;
                                nrrules = 1;
                            } else {
                                nrrules = 0;
                            }
                        }
                        if (nobody){
                            nrrules = 0;
                        }
                    }
                    break;
                }
            } else {
                nrrules = this.tab.nullableNtRules[i];
                if (this.disambiguate) nrrules = 1;
            }
            ;
            int totalt = nrrules;
            if (zeroit) totalt++;

            int firstnotnull = -1;
            dis: if (this.disambiguate){
                if (nobody) break dis;
                for (int j = this.tab.ntToRule[i]; j < this.tab.ruleToNt.length; j++){
                    if (this.tab.ruleToNt[j] != i) break;
                    if (!((this.tab.nullableRules[(j)>>>ParserTables.NSHIFTB] & (1 << (j& ParserTables.MASKB))) != 0)) continue;  // not a nullable rule
                    if (firstnotnull < 0){
                        firstnotnull = j;
                    }
                }
            }
            // store then the symbol node if needed
            int ruleInSym = 0;
            if (totalt > 1){
                ;
                loc = this.loc;
                this.loc += totalt + 1;
                if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                    enlargeTree(this.loc);
                }
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = totalt | HEADSYM;
                ruleInSym = loc + 1;             // first loc of symbol node
            }
            // build the zero iteration if any
            if (zeroit){
                loc = this.loc;
                if (ruleInSym > 0){              // store ref in symbol node to rule node
                    this.tree[(ruleInSym)>>>NSHF][((ruleInSym)&MSK)] = loc;
                    ruleInSym++;
                }
                ;
                this.loc++;
                if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                    enlargeTree(this.loc);
                }
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = zerohdr;
                loc++;
            }
            // for groups generate as many rule nodes as nrrules, each being a
            // repetition group derivation with as many elements as the rule node
            // number plus the fixed part;
            ;
            if (group){
                for (int j = 0; j < nrrules; j++){
                    loc = this.loc;
                    if (ruleInSym > 0){               // store ref in symbol node to rule node
                        this.tree[(ruleInSym)>>>NSHF][((ruleInSym)&MSK)] = loc;
                        ruleInSym++;
                    }
                    // reserve space in tree for rule
                    int len = j + lower;
                    if (this.tab.ntKind[i] == ParserTables.REU){
                        len++;
                    }
                    this.loc += len + 1;
                    if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                        enlargeTree(this.loc);
                    }
                    // copy header
                    this.tree[(loc)>>>NSHF][((loc)&MSK)] = HEAD | len+this.tab.numOfRules;
                    ;
                    loc++;
                    for (int k = 0; k < len; k++){
                        int el = this.tab.body(i);
                        ;
                        ;
                        if (this.etrees[el] > 0){              // e-nt already encoded
                            el = this.etrees[el] | HEAD;
                        } else if (this.etrees[el] == 0){
                            // add it to queue to visit
                            ;
                            this.etrees[el] = -1;
                            if (qp >= this.encodequeue.length){
                                if (dp > 10){                   // shift down, if worth
                                    System.arraycopy(this.encodequeue,dp,this.encodequeue,0,qp-dp);
                                    qp -= dp;
                                    dp = 0;
                                } else {                        // enlarge
                                    this.encodequeue = Arrays.copyOf(this.encodequeue,this.encodequeue.length+100);
                                }
                            }
                            this.encodequeue[qp++] = el;        // enqueue it
                        }
                        this.tree[(loc)>>>NSHF][((loc)&MSK)] = el;
                        loc++;
                    }
                }
                continue;
            }

            // visit the rules now
            for (int j = this.tab.ntToRule[i]; j < this.tab.ruleToNt.length; j++){
                if (this.tab.ruleToNt[j] != i) break;
                if (!((this.tab.nullableRules[(j)>>>ParserTables.NSHIFTB] & (1 << (j& ParserTables.MASKB))) != 0)) continue;  // not a nullable rule
                int rule = j;
                if (this.disambiguate){
                    rule = this.tablr.ncycNulRule[i];
                    if (rule < 0){
                        rule = firstnotnull;
                    }
                    ;
                }
                int p = this.tab.ruleIndex[rule];
                loc = this.loc;
                if (ruleInSym > 0){               // store ref in symbol node to rule node
                    this.tree[(ruleInSym)>>>NSHF][((ruleInSym)&MSK)] = loc;
                    ruleInSym++;
                }
                // reserve space in tree for rule
                int len = this.tab.ruleLen[rule];
                this.loc += len + 1;
                if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                    enlargeTree(this.loc);
                }
                // copy header
                ;
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = rule | HEAD;
                loc++;
                for (int k = 0; k < len; k++){
                    int el = this.tab.grammar[p++];
                    ;
                    if (this.etrees[el] > 0){              // e-nt already encoded
                        el = this.etrees[el] | HEAD;
                    } else if (this.etrees[el] == 0){
                        // add it to queue to visit
                        ;
                        this.etrees[el] = -1;
                        if (qp >= this.encodequeue.length){
                            if (dp > 10){                   // shift down, if worth
                                System.arraycopy(this.encodequeue,dp,this.encodequeue,0,qp-dp);
                                qp -= dp;
                                dp = 0;
                            } else {                        // enlarge
                                this.encodequeue = Arrays.copyOf(this.encodequeue,this.encodequeue.length+100);
                            }
                        }
                        this.encodequeue[qp++] = el;        // enqueue it
                    }
                    this.tree[(loc)>>>NSHF][((loc)&MSK)] = el;
                    loc++;
                }
                if (this.disambiguate) break;
                if (--nrrules <= 0) break;                  // for opt
            }
        }

        // scan the rules stored above in the final parse tree and remap the references to
        // grammar nts to the ones in the parse tree
        ;

        for (int i = start; i < this.loc;){            // scan the tree
            ;
            int h = this.tree[(i)>>>NSHF][((i)&MSK)];
            if ((h & HEADF) == HEADSYM){               // symbol node
                int len = h & ~HEADSYM;
                this.altNum += len;
                i += len + 1;
            } else {
                int len = h & ~HEADF;                  // length of phrase of derivation
                if (len >= this.tab.numOfRules){
                    len -= this.tab.numOfRules;
                } else {
                    len = this.tab.ruleLen[len];       // fixed length
                }
                i++;
                int end = i + len;
                for (; i < end; i++){
                    int el = this.tree[(i)>>>NSHF][((i)&MSK)];
                    if ((el & HEADF) == HEAD){     // already built
                        el &= ~HEAD;
                    } else if (el >= 0){
                        ;
                        el = this.etrees[el];
                    }
                    this.tree[(i)>>>NSHF][((i)&MSK)] = el;
                }
                this.derNum++;
                this.eleNum += len;
            }
        }

        this.treeLen = this.loc;
        this.treeStart = start;

        return start;
    }

    /**
     * Do LR parsing.
     *
     * @return   state at the end of parsing, negated if the input is not recognized
     */

    /* In the stack each frame contains the state, the level and the tree.
     * When a reduction is done it removes the frames correspondig to its derivation,
     * builds a fragment of forest, and adds a frame for it. The tree can be denoted
     * by a pedigree, or also directly by a value with the already encoded flag on.
     */

    private int parseLR(){
        int res = 0;
        int node = this.gssNodeNr - 1;       // the one with the frontier state
        ;
        int edge = gssNodeDir[(node)>>>NSHF][((node)&MSK)+NODE_EDGES] & 0x7fffffff;
        int state = gssNodeDir[(node)>>>NSHF][((node)&MSK)];           // its state
        node = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
        int startstate = gssNodeDir[(node)>>>NSHF][((node)&MSK)];      // the junction one
        ;
        this.LRstackBottom = this.gssEdgeNr;
        // initialize the stack with the node that starts the LR parsing
        int spf = gssEdgeDir[(edge+EDGE_PDGR)>>>NSHF][((edge+EDGE_PDGR)&MSK)];
        ;
        pushLRstack(state,spf);
        for (;;){
            int action = 0;
            int nracts = 0;
            int acts = 0;
            for (int t = 0; t < this.tab.tokLists[this.currentToken].length; t++){
                this.currentTokNr = this.tab.tokLists[this.currentToken][t];
                int tk = this.currentTokNr+this.tab.tokBase;
                nracts = this.tablr.LRbase[state];acts = nracts + tk;nracts = this.tablr.LRcheck[acts] == nracts ? this.tablr.LRtable[acts] : 0;if (nracts> 0){nracts= 1;} else if (nracts < 0){acts= -nracts;nracts = this.tablr.LRtable[acts++];};
                if (nracts == 0) continue;
                ;
                break;
            }
            if (nracts == 0){                 // no action
                this.lastState = state;
                res = -1;
                break;
            }
            // of course, there is only one, otherwise the state would not be an isle one
            // n.b. rn reductions are irrelevant here
            action = this.tablr.LRtable[acts];
            if (action >= ParserLRTables.ISREDUCE){  // reduce
                int gp = (action& ParserLRTables.GPMASK);
                int nt = gp;
                boolean fixed = false;
                int derlen = 0;
                if (gp >= this.tab.ruleBase){
                    gp -= this.tab.ruleBase;
                    nt = this.tab.ruleToNt[gp];
                    fixed = true;
                    derlen = this.tab.ruleLen[gp];
                }
                int reditem = ((action>> ParserLRTables.ELSHIFTS) & ParserLRTables.ELMASK);
                int rule = gp;
                int startSpReduct = this.gssEdgeNr - 3;
                if (fixed){
                    // the reduction has fixed length, take fixed chunk
                    startSpReduct -= (derlen << 1) + derlen;
                } else {
                    // the length is not known, hop to find it
                    derlen = 0;
                    int bas = this.tablr.hopBase[state];
                    int start = bas+reditem;
                    int le = this.tablr.hopCheck[start] == bas ? this.tablr.hopTable[start] : -1;
                    if (le >= 0){
                        for (; le >= 0;){
                            derlen++;
                            ;
                            startSpReduct -= 3;                       // previous stack frame
                            if (startSpReduct < this.LRstackBottom) break;
                            state = gssEdgeDir[(startSpReduct)>>>NSHF][((startSpReduct)&MSK)];
                            bas = this.tablr.hopBase[state];
                            start = bas+le;
                            le = this.tablr.hopCheck[start] == bas ? this.tablr.hopTable[start] : -1;
                            if (le < 0) break;
                        }
                    }
                }
                ;
                int z = 0;
                // for rnglr no need to treat the case of rule with empty tail: it has a conflict
                if (this.tab.ntKind[nt] == ParserTables.OBO){
                    z = gssEdgeDir[(this.gssEdgeNr-1)>>>NSHF][((this.gssEdgeNr-1)&MSK)];
                    ;
                } else {
                    z = encodeLRtree(nt,derlen,startSpReduct,fixed,rule);
                }
                this.gssEdgeNr -= derlen * 3;   // pop the stack
                // now move from the exposed state with the reduced nonterminal
                int topstack = this.gssEdgeNr - 3;
                ;
                int lookback = gssEdgeDir[(topstack)>>>NSHF][((topstack)&MSK)] & LRS_STATE_MASK;
                if (topstack < this.LRstackBottom){      // end of LR piece
                    int lrbase1= this.tablr.LRbase[startstate];int newState1 = this.tablr.LRcheck[lrbase1+nt] == lrbase1 ? this.tablr.LRtable[lrbase1+nt] : 0;;
                    boolean isfront = (this.tablr.stateStatus[newState1] & LALRRNFAtables.ISFRONTIER) != 0;
                    ;
                    ;
                    this.gssEdgeNr = this.LRstackBottom;
                    aga: {
                        int st = newState1;
                        if (!isfront){
                            st = 0;
                        }
                        ;
                        if (st == 0) break aga;
                        pushLRstack(st,z | HEADTREE);
                        state = st;
                        ;
                        if ((FL_C & this.trc) != 0){
                            Trc.out.printf("--- %s --- %s\n",tokenToString(this.currentToken),this.lex.toString());
                            traceEbnfState(state);
                        }
                        continue;
                    }
                    this.LRtree = z;
                    res = newState1;
                    break;
                }
                int lrbase2= this.tablr.LRbase[gssEdgeDir[(topstack)>>>NSHF][((topstack)&MSK)]];int newState = this.tablr.LRcheck[lrbase2+nt] == lrbase2 ? this.tablr.LRtable[lrbase2+nt] : 0;;
                ;
                pushLRstack(newState,z | HEADTREE);
                state = newState;
                if ((FL_C & this.trc) != 0){
                    Trc.out.printf("--- %s --- %s\n",tokenToString(this.currentToken),this.lex.toString());
                    traceEbnfState(newState);
                }
            } else {                            // shift
                this.level++;
                ;
                int z = 0;
                if (this.currentToken == EOF){  // shifting the EOF: end of parse
                    ;
                    this.lastState = state;
                    res = -1;
                    break;
                }
                z = saveToken(action,this.currentTokNr);          // eof cannot be encoded
                int newState = action & ParserLRTables.STATEMASK;
                pushLRstack(newState,z);
                ;
                state = newState;
                if ((FL_C & this.trc) != 0){
                    Trc.out.printf("--- %s --- %s\n",tokenToString(this.currentToken),this.lex.toString());
                    traceEbnfState(newState);
                }
                this.currentToken = tokenizer();
                if (this.currentToken < 0){
                    this.lastState = state;
                    res = -1;
                    break;
                }
            }
        }
        ;
        return res;
    }

    /**
     * Trace the lr stack starting from the specified bottom.
     *
     * @param      stackBottom index of the start element to trace
     */

    @Override
    protected void traceLRstack(int stackBottom){
        Trc.out.printf("stack");
        for (int i = stackBottom; i < this.gssEdgeNr; i += 3){
            Trc.out.printf(" %d:(%d,%d",i,gssEdgeDir[(i)>>>NSHF][((i)&MSK)],gssEdgeDir[(i+1)>>>NSHF][((i+1)&MSK)]);
            int t = gssEdgeDir[(i+2)>>>NSHF][((i+2)&MSK)];
            String s = pdgrGssElToString(t,false);
            Trc.out.printf(",%s)",s);
        }
        Trc.out.printf("\n");
    }

    /**
     * Encode the specified piece of the lr stack into the final forest.
     *
     * @param      nt nonterminal that is the root of the generated forest fragment
     * @param      derlen length of the derivation on the lr stack
     * @param      startSpReduct start index on the lr stack
     * @param      fixed <code>true</code> if fixed reduction, <code>false</code> otherwise
     * @param      rule rule, if fixed
     * @return     index in the final forest for the fragment generated
     */

    private int encodeLRtree(int nt, int derlen, int startSpReduct, boolean fixed, int rule){
        ;
        // on the stack there are derlen values, each being a token or a derivation
 
        int befsp = startSpReduct+1;
        if (befsp > this.LRstackBottom &&
            gssEdgeDir[(befsp)>>>NSHF][((befsp)&MSK)] == this.level){           // empty yield
            ;
            // n.b. this generates an etree with all the possible derivations (rules)
            // for the nt
            if (this.etrees[nt] == 0){
                this.etrees[nt] = this.loc;
            } else {
                return this.etrees[nt];              // return already encoded e-tree
            }
        }

        int newloc = this.loc;
        int start = newloc;
        doit: {
            int hdr = HEAD;
            if (fixed){
                int ntr = this.tab.ruleToNt[rule];
                if (this.tab.ntKind[ntr] == ParserTables.OPT &&
                    this.tab.ruleLen[rule] == 0){
                    hdr |= this.tab.numOfRules;
                } else if (this.tab.ntKind[ntr] == ParserTables.OPT &&
                    this.tab.ruleLen[rule] != 0){
                    // return directly the body
                    int val = gssEdgeDir[(this.gssEdgeNr-1)>>>NSHF][((this.gssEdgeNr-1)&MSK)];
                    if ((val & HEADF) == HEAD){
                        val &= ~HEAD;
                    } else if (val > 0){
                        int s = gssEdgeDir[(val+2)>>>NSHF][((val+2)&MSK)];
                        if ((s & HEADTREE) != 0){              // already encoded
                            val = s & ~HEADTREE;
                        }
                    }
                    return val;
                } else if (this.tab.ntKind[ntr] == ParserTables.RER ||
                    this.tab.ntKind[ntr] == ParserTables.REF){
                    hdr |= (derlen + this.tab.numOfRules);
                } else {
                    hdr |= rule;
                }
            } else {
                hdr |= (derlen + this.tab.numOfRules);
                ;
            }
            newloc += derlen + 1;

            if (((newloc-1) >>> NSHF) >= this.treeBlocks){
                enlargeTree(newloc);
            }
            int loc = this.loc;

            // store header
            ;
            this.tree[(loc)>>>NSHF][((loc)&MSK)] = hdr;
            loc = newloc - 1;

            // visit the stack for this rule
            for (int i = this.gssEdgeNr - 3; i > startSpReduct; i -= 3){
                int val = gssEdgeDir[(i+2)>>>NSHF][((i+2)&MSK)];
                ;
                // store value
                if ((val & HEADF) == HEAD){    // newly encoded value in lrs mode
                    val &= ~HEAD;
                } else if (val > 0){
                    int s = gssEdgeDir[(val+2)>>>NSHF][((val+2)&MSK)];
                    val = s & ~HEADTREE;
                    // n.b. it is already encoded because we are in lr mode
                }
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = val;               // store value
                ;
                loc--;
            }
            this.eleNum += newloc - start - 1;
            this.derNum++;
            this.treeLen = newloc;
            this.treeStart = start;
            this.loc = newloc;
        } // doit
        return this.treeStart;
    }


    /**
     * Visit the parse forest and add the singleton chains that are not present.
     */

    /* N.B. Option groups are always shortened, so here they are skipped.
     */

    private void encodeChains(){
        int end = this.loc;
        for (int i = 1; i < end;){
            int el = this.tree[(i)>>>NSHF][((i)&MSK)];
            ;
            if ((el & HEADSYM) != 0){            // symbol node
                el &= ~HEADSYM;
                i += el + 1;
            } else {                             // rule node
                int start = i + 1;
                el &= ~HEAD;
                int p = 0;
                if (el < this.tab.numOfRules){   // not a repetition group
                    ;
                    p = this.tab.ruleIndex[el];
                    el = this.tab.ruleLen[el];   // fixed length
                    i += el + 1;
                } else {                         // repetition group
                    el -= this.tab.numOfRules;   // decode the length;
                    i += el + 1;
                    continue;
                }
                
                for (int j = start; j < i; j++, p++){
                    el = this.tab.grammar[p];
                    ;
                    if (el >= this.tab.tokBase) continue;  // token
                    if (this.tab.ntKind[el] == ParserTables.OPT) continue;
                    int s = this.tree[(j)>>>NSHF][((j)&MSK)];
                    ;
                    int nt = -1;
                    if (s >= 0){
                        // get the nt
                        nt = getNt(s);
                        if (this.tab.ntKind[el] < 0 && nt < 0) continue;  // group
                    } else {
                        ;
                        nt = this.tab.tokBase + getTokNr(s);
                    }
                    if (el == nt) continue;
                    ;
                    // generate the missing links
                    // there is a sequence of unitary rules
                    int cur = j;
                    do {
                        this.tree[(cur)>>>NSHF][((cur)&MSK)] = this.loc;
                        ;
                        int loc = this.loc;
                        this.loc += 2;
                        if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                            enlargeTree(this.loc);
                        }
                        // store header
                        this.tree[(loc)>>>NSHF][((loc)&MSK)] = HEAD | this.tab.ntToRule[el];
                        ;
                        loc++;
                        this.tree[(loc)>>>NSHF][((loc)&MSK)] = s;               // store value
                        ;
                        cur = loc;
                        loc++;
                        ;
                        el = this.tab.ntToRule[el];
                        el = this.tab.grammar[this.tab.ruleIndex[el]];
                        ;
                        if (nt < 0) break;
                        if (el < this.tab.tokBase && this.tab.ntKind[el] == ParserTables.OPT) break;
                    } while (el != nt);
                }
                ;
            }
        }
        this.treeLen = this.loc;
        if ((FL_Y & this.trc) != 0){
            Trc.out.printf("encodeChains start %s\n",this.treeStart);
            traceTree(Trc.wrt,0);
        }
    }

    /**
     * Do LR dynamic mode parsing.
     *
     * @return     >= 0: parsing successful, -1: LR parsing cannot be done,
     *             -2: internal error because of malformed GSS, -3: EOF detected
     */

    private int parseLRdyn(){
        int res = 0;
        int parser = this.gssNodeNr - 1;
        ;
        determin: {
            int state = gssNodeDir[(parser)>>>NSHF][((parser)&MSK)];
            // here there should be only one action
            int nracts = 0;
            int acts = 0;
            this.currentTokNr = this.tab.tokLists[this.currentToken][0];
            int tk = this.currentTokNr+this.tab.tokBase;
            nracts = this.tablr.LRbase[state];acts = nracts + tk;nracts = this.tablr.LRcheck[acts] == nracts ? this.tablr.LRtable[acts] : 0;if (nracts> 0){nracts= 1;} else if (nracts < 0){acts= -nracts;nracts = this.tablr.LRtable[acts++];};
            ;
            if (nracts != 1){
                ;
                res = -1;
                break determin;
            }
            int act = this.tablr.LRtable[acts];
            if (act >= ParserLRTables.ISREDUCE){             // reduce
                int gp = (act& ParserLRTables.GPMASK);
                int nt = gp;
                boolean fixed = false;
                int derlen = 0;
                if (gp >= this.tab.ruleBase){
                    gp -= this.tab.ruleBase;
                    nt = this.tab.ruleToNt[gp];
                    fixed = true;
                    derlen = this.tab.ruleLen[gp];
                }
                int reditem = ((act>> ParserLRTables.ELSHIFTS) & ParserLRTables.ELMASK);
                int rule = gp;
                if (!fixed){
                    rule = -1;
                }
                if (((this.tab.cyclic[(nt)>>>ParserTables.NSHIFTB] & (1 << (nt& ParserTables.MASKB))) != 0)){
                    res = -1;
                    break determin;
                }
                ;
                int z = 0;
                int lookback = this.gssNodeNr - 1;

                if (fixed){
                    // here it would be better to avoid to scan the path twice:
                    // here and in encode
                    int node = parser;
                    for (int i = 0; i < derlen; i++){
                        int edge = gssNodeDir[(lookback)>>>NSHF][((lookback)&MSK)+NODE_EDGES] & 0x7fffffff;
                        if (gssEdgeDir[(edge)>>>NSHF][((edge)&MSK)] != 0){
                            res = -1;
                            break determin;
                        }
                        lookback = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
                    }
                } else {
                    derlen = 0;
                    state = gssNodeDir[(parser)>>>NSHF][((parser)&MSK)];
                    int bas = this.tablr.hopBase[state];
                    int start = bas+reditem;
                    int le = this.tablr.hopCheck[start] == bas ? this.tablr.hopTable[start] : -1;
                    if (le >= 0){
                        for (; le >= 0;){
                            derlen++;
                            int edge = gssNodeDir[(lookback)>>>NSHF][((lookback)&MSK)+NODE_EDGES] & 0x7fffffff;
                            if (gssEdgeDir[(edge)>>>NSHF][((edge)&MSK)] != 0){
                                res = -1;
                                break determin;
                            }
                            lookback = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
                            state = gssNodeDir[(lookback)>>>NSHF][((lookback)&MSK)];
                            bas = this.tablr.hopBase[state];
                            start = bas+le;
                            le = this.tablr.hopCheck[start] == bas ? this.tablr.hopTable[start] : -1;
                            if (le < 0) break;
                        }
                    }
                }
                ;

                // for rnglr no need to treat the case of rule with empty tail: it has a conflict
                ;
                z = encodeLRdyntree(nt,derlen,this.gssNodeNr - 1,rule);
                ;
                if (z < 0){
                    res = -1;
                    break determin;
                }
                ;
                int sentLookback = -1;
                if (gssNodeDir[(lookback)>>>NSHF][((lookback)&MSK)+NODE_EDGES] != 0){
                    int edu = gssNodeDir[(lookback)>>>NSHF][((lookback)&MSK)+NODE_EDGES] & 0x7fffffff;
                    int pdu = gssEdgeDir[(edu+EDGE_PDGR)>>>NSHF][((edu+EDGE_PDGR)&MSK)];
                    if (pdu > 1 && (pdu & PDGR_MSK) == 0){
                        sentLookback = gssEdgeDir[(pdu-3)>>>NSHF][((pdu-3)&MSK)];
                    }
                }

                // pop the levels
                if (lookback < this.levelGss){           // in a level before the current one
                    // find the end of the level
                    // compute the cover
                    int startNodelev = 0;
                    if (sentLookback > 0){
                        startNodelev = sentLookback;
                    } else {
                        startNodelev = lookback;
                        startNodelev--;
                        while (gssNodeDir[(startNodelev)>>>NSHF][((startNodelev)&MSK)] >= 0) startNodelev--; 
                        sentLookback = startNodelev;
                    }

                    ;
                    int curNodeNr = this.gssNodeNr;
                    int curEdgeNr = this.gssEdgeNr;
                    int oldNodes = this.gssNodeNr;
                    int oldEdges = this.gssEdgeNr;
                    this.gssNodeNr = -gssNodeDir[(startNodelev)>>>NSHF][((startNodelev)&MSK)];        // deallocate nodes
                    this.gssEdgeNr = gssNodeDir[(startNodelev)>>>NSHF][((startNodelev)&MSK)+NODE_EDGES] & 0x7fffffff;        // and edges
                    this.levelGss = this.gssNodeNr;
                    this.delta += curNodeNr - this.gssNodeNr;       // roll up total delta
                    this.absLevelGss = this.levelGss + this.delta;
                    this.levelEdgeGss = this.gssEdgeNr;
                    this.deltaEdges += curEdgeNr - this.gssEdgeNr;
                    this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;

                    // adjust the sentinel
                    gssNodeDir[(this.gssNodeNr-1)>>>NSHF][((this.gssNodeNr-1)&MSK)] = -1;
                    ;
                } else {
                    // do not pop the current level: empty reduction
                    sentLookback = this.levelGss - 1;
                }
                // create the new node
                int lrbase3= this.tablr.LRbase[gssNodeDir[(lookback)>>>NSHF][((lookback)&MSK)]];int newState = this.tablr.LRcheck[lrbase3+nt] == lrbase3 ? this.tablr.LRtable[lrbase3+nt] : 0;;
                ;

                int tonodeLev = sentLookback;
                int pdgr = addPedigree(tonodeLev,this.levelGss - 1,z);

                int newNode = addNode(newState,lookback,pdgr,0);
                if (newNode < 0) newNode = -newNode;
                if ((FL_C & this.trc) != 0){
                    Trc.out.printf("--- %s --- %s\n",tokenToString(this.currentToken),this.lex.toString());
                    traceEbnfState(newState);
                }
                res = newNode;
            } else if (act > 0) {
                // actually, this code is not much different from what is done in
                // the main loop (well, a bit more optimized)
                // can shift unambiguously
                makeSentinel();
                this.level++;
                ;
                ;
                this.levelGss = this.gssNodeNr;
                this.absLevelGss = this.levelGss + this.delta;
                this.levelEdgeGss = this.gssEdgeNr;
                this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;
                int z = PDGR_FAKE;
                if (this.currentToken != EOF){
                    z = saveToken(act,currentTokNr);  // eof cannot be encoded
                }
                int newState = act & ParserLRTables.STATEMASK;
                int newNode = addNode(newState,parser,z,0);
                if (newNode < 0) newNode = -newNode;
                ;
                ;
                if ((FL_C & this.trc) != 0){
                    Trc.out.printf("--- %s --- %s\n",tokenToString(this.currentToken),this.lex.toString());
                    traceEbnfState(newState);
                }
                if (this.currentToken == EOF){  // shifting the EOF: end of parse
                    ;
                    res = -3;
                    break determin;
                }
                // return to mainloop
                res = 0;
            }
        } // determin
        ;
        return res;
    }

    /**
     * Encode the derivation starting from the specified node collecting the trees of
     * each element and encoding the ones that are not yet so (instead of creating a node
     * with its pedigree), which happens when the previous levels are not lr.
     *
     * @param     nt nonterminal of the derivation
     * @param     derlen length of the derivation
     * @param     rootnode index of the pedigree to encode
     * @param     rule rule of the derivation, -1 if group
     * @return    index in the final forest of the fragment generated
     */

    private int encodeLRdyntree(int nt, int derlen, int rootnode, int rule){
        ;
        // on the gss there is a linear path with n values, where n is the length of the derivation,
        // each being a token or a derivation

        // detect if it is an etree
        if (derlen == 0){
            ;
            if (this.etrees[nt] == 0){
                this.etrees[nt] = this.loc;
            } else {
                return this.etrees[nt];              // return already encoded e-tree
            }
        }

        int node = rootnode;

        int newloc = this.loc;
        int start = newloc;
        doit: {
            int hdr = HEAD;
            if (rule >= 0){
                int ntr = this.tab.ruleToNt[rule];
                if (this.tab.ntKind[ntr] == ParserTables.OPT &&
                    this.tab.ruleLen[rule] == 0){
                    hdr |= this.tab.numOfRules;
                } else if (this.tab.ntKind[ntr] == ParserTables.OPT &&
                    this.tab.ruleLen[rule] != 0){
                    int edge = gssNodeDir[(node)>>>NSHF][((node)&MSK)+NODE_EDGES] & 0x7fffffff;
                    int val = gssEdgeDir[(edge+EDGE_PDGR)>>>NSHF][((edge+EDGE_PDGR)&MSK)];
                    if ((val & HEADF) == HEAD) val &= ~HEAD;
                    if ((val& PDGR_MSK) == E_NT){                     // nullable nt
                    } else if ((val & HEADF) == 0){         // not yet encoded
                        ;
                        val = encodetree(val);
                    }
                    return val;
                } else if (this.tab.ntKind[ntr] == ParserTables.REF){
                    hdr |= derlen + this.tab.numOfRules;
                } else {
                    hdr |= rule;
                }
            } else {
                hdr |= derlen + this.tab.numOfRules;
            }
            newloc += derlen + 1;
            if (((newloc-1) >>> NSHF) >= this.treeBlocks){
                enlargeTree(newloc);
            }
            int loc = this.loc;
            this.loc = newloc;              // make this derivation allocated
            this.treeLen = newloc;
            // store header
            ;
            this.tree[(loc)>>>NSHF][((loc)&MSK)] = hdr;
            loc++;

            // visit the gss for this rule
            node = rootnode;
            for (int i = derlen-1; i >= 0; i--){
                int edge = gssNodeDir[(node)>>>NSHF][((node)&MSK)+NODE_EDGES] & 0x7fffffff;
                int val = gssEdgeDir[(edge+EDGE_PDGR)>>>NSHF][((edge+EDGE_PDGR)&MSK)];
                if ((val & HEADF) == HEAD) val &= ~HEAD;

                if ((val& PDGR_MSK) == E_NT){                      // nullable nt
                    int lhs = 0;
                    if (rule >= 0){                      // fixed
                        lhs = val & ~PDGR_MSK;
                    } else {                             // variable
                        // nt is that of the group
                        // nt+1 is that of the body
                    }
                    if (this.etrees[lhs] == 0){          // not already encountered
                        this.etrees[lhs] = encodeEtree(lhs);
                    }
                    val = this.etrees[lhs];
                } else if ((val & HEADF) == 0){         // not yet encoded
                    ;
                    val = encodetree(val);
                }

                // store value            
                int l = loc + i;
                this.tree[(l)>>>NSHF][((l)&MSK)] = val;                  // store element
                ;
                node = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
            }
            this.LRstackBottom = node;
            this.eleNum += newloc - start - 1;
            this.derNum++;
            this.treeStart = start;
        } // doit
        ;
        return this.treeStart;
    }

    /**
     * Generate the forest from the pedigree at the specified index.
     *
     * @param      root index of the pedigree.
     * @return     index in the forest
     */

    /* encodetree visites the pedigrees (a graph, mostly a dag) creating the nodes in the final
     * forest along with the visit while remembering the positions, and resolving references
     * in the second pass done on the final forest.
     * The algorithm with the queue is not slower than the one with the two passes.
     */

    /** The hash table for rules to find duplicates. */
    private int[] rulehashdir;
    private int[] rulehashlink;
    private int[] rulehashdata;
    /** The base for autoaging indexes in the hash table. */
    private int rulehashbase = 1;
    private int[] winnerpath;
    @Override
    protected int encodetree(int root){
        ;
        if (this.ruleptrs == null){
            this.ruleptrs = new int[20];
        }
        this.treeLen = this.loc;
        int ps = gssEdgeDir[(root+2)>>>NSHF][((root+2)&MSK)];
        if ((ps & HEADTREE) != 0){              // already encoded
            ps &= ~HEADTREE;
            ;
            this.treeStart = ps;
            return ps;
        }
        // here we know that the rule derives the empty string because the cover is 0
        if (gssEdgeDir[(root-2)>>>NSHF][((root-2)&MSK)] == HEADSYM){       // empty rule
            int redu = gssEdgeDir[(root+1)>>>NSHF][((root+1)&MSK)];
            int lhs = (redu& ParserLRTables.GPMASK);
            if (lhs >= this.tab.ruleBase){
                lhs -= this.tab.ruleBase;
                lhs = this.tab.ruleToNt[lhs];
            }
            if (this.etrees[lhs] != 0){
                ;
                this.treeStart = this.etrees[lhs];
                return this.etrees[lhs];
            }
        }

        this.nocover = true;         // because below we call pedigreeToString on casuals
        int rulehashnr = 0;                    // number of new rules in hash table
        inithash: {
            if (this.disambiguate) break inithash;
            if (this.rulehashdir == null){
                this.rulehashdir = new int[256];
                this.rulehashlink = new int[256];
                this.rulehashdata = new int[256];
            }
        }
        int loc = this.loc;
        int start = loc;

        int dp = 0;
        int qp = 0;
        this.encodequeue[qp++] = root;   // enqueue root
        int[] ogamma = null;
        int ogj = 0;
        int orule = 0;
        while (dp != qp){                        // while queue not empty
            int rnode = this.encodequeue[dp++];      // dequeue
            // visitedNr++;

            int redu = gssEdgeDir[(rnode+1)>>>NSHF][((rnode+1)&MSK)];
            int lhs = (redu& ParserLRTables.GPMASK);
            if (lhs >= this.tab.ruleBase){
                lhs -= this.tab.ruleBase;
                lhs = this.tab.ruleToNt[lhs];
            }
            ;

            // make sure that derivations for a same empty rule has one single instance in the
            // final parse tree
            // int lhs = -1;
            if (gssEdgeDir[(rnode-2)>>>NSHF][((rnode-2)&MSK)] == HEADSYM){        // empty rule
                if (this.etrees[lhs] != 0){           // already encountered
                    ;
                    continue;
                } else {
                    ;
                }
            }

            // visit all the pedigrees headed by rnode and for each one build the
            // paths and then for each path the reduction and make sure that it is
            // unique
            int nrrules = 0;

            gssEdgeDir[(rnode-1)>>>NSHF][((rnode-1)&MSK)] = this.loc;        // set it to consider allocated
            ;

            // I must allocate/copy the symbol node only if it has > 1 rules,
            // but I do not know it, and neither I know how many they are so as to allocate
            // the table of its rules. I first allocate/copy the rules and then the symbol
            // node, but I must remember somewhere the locations of the symbol nodes ... it
            // would had been better to link the rules in a list instead of having a table
            // of symbol nodes in the final parse tree.
            // But then all rules would have a field in them for the link, also the ones that
            // belong to symbol nodes that have only one rule.

            boolean firstpath = true;
            boolean fixed = false;
            for (int j = rnode; j != 0; j = gssEdgeDir[(j)>>>NSHF][((j)&MSK)]){
                ;
                ;

                redu = gssEdgeDir[(j+1)>>>NSHF][((j+1)&MSK)];
                ;
                lhs = (redu& ParserLRTables.GPMASK);
                fixed = false;
                int derlen = 0;
                int rule = 0;
                int reditem = ((redu>> ParserLRTables.ELSHIFTS) & ParserLRTables.ELMASK);
                if (lhs >= this.tab.ruleBase){
                    lhs -= this.tab.ruleBase;
                    rule = lhs;
                    lhs = this.tab.ruleToNt[lhs];
                    fixed = true;
                    derlen = reditem;
                }
                int m = ((redu& ParserLRTables.EMPTYMASK) != 0 ? 0 : 1);
                boolean repgroup = this.tab.ntKind[lhs] <= ParserTables.REF;
                boolean nullbody = false;
                if (repgroup){
                    int body = this.tab.body(lhs);
                    nullbody = ((this.tab.nullable[(body)>>>ParserTables.NSHIFTB] & (1 << (body& ParserTables.MASKB))) != 0);
                }
                // compute the paths
                // n.b. when the reductions are made down the first edge,
                // the edge is recorded in the pedigrees, and if it is variable,
                // the item of the second node

                boolean nullrule = false;
                int startedge = gssEdgeDir[(j+2)>>>NSHF][((j+2)&MSK)];
                int second = 0;
                if (m > 0){                       // not an empty reduction
                    second = gssEdgeDir[(startedge+EDGE_TO)>>>NSHF][((startedge+EDGE_TO)&MSK)];
                    if (gssNodeDir[(second)>>>NSHF][((second)&MSK)+NODE_EDGES] == 0){      // no path beyond startedge
                        nullrule = true;
                    } else if (derlen == 1){
                        nullrule = true;
                    }
                    ;
                } else {
                    nullrule = true;
                    ;
                }
                // nullrule here means that there are no edges to find, and that
                // the path is made at most of one edge (the starting one)
                int lev = 0;
                boolean first = true;
                int ed = 0;

                ;
                if (fixed){
                    // allocate pathIterator to the max derlen
                    if (this.pathIterator == null || this.pathIterator.length < this.tablr.longestRule){
                        this.pathIterator = new int[this.tablr.longestRule];
                    }
                }
                if (this.pathIterator == null || this.pathIterator.length < 100){
                    this.pathIterator = new int[100];
                    this.pathItems = new int[100];
                }
                int[] pathedg = this.pathIterator;           // progress points in states to deliver next path
                int[] pathitm = this.pathItems;
                if (m > 0){
                    pathedg[lev] = startedge;                // actually, the first edge
                    pathitm[lev] = reditem;                  // the items in tonode of the first edge
                    lev++;
                    // this is needed in order to have something to start with to make paths
                }
                allph: for (;;){                             // visit all paths
                    this.lev = lev;
                    // take all paths, do not discard any of repetition groups otherwise
                    // empty {""}* will have only a path for an empty body
                    int res = getpath(nullrule,first,second,derlen,
                        fixed,startedge,nullbody);

                    first = false;
                    lev = this.lev;
                    if (res == 1){
                        continue allph;
                    } else if (res == 2){                    // end of paths
                        break allph;
                    }
                    // TRACE(Y,"encodetree gss node %d\n",this.gssNodeNr);
                    // TRACE(Y,"encodetree gss %s\n",GSStoString());
                    // TRACE(Y,"encodetree path m %s %s: %s\n",m,firstitm,pToString(pathedg,lev));
                    // check that the path denotes a derivation with the same cover
                    // as the pedigree
                    int lastedge = pathedg[lev-1];
                    int lastnode = gssEdgeDir[(lastedge+EDGE_TO)>>>NSHF][((lastedge+EDGE_TO)&MSK)];

                    // check the cover
                    int toLev = 0;
                    sent: {
                        if (gssNodeDir[(lastnode)>>>NSHF][((lastnode)&MSK)+NODE_EDGES] != 0){
                            int edu = gssNodeDir[(lastnode)>>>NSHF][((lastnode)&MSK)+NODE_EDGES] & 0x7fffffff;
                            int pdu = gssEdgeDir[(edu+EDGE_PDGR)>>>NSHF][((edu+EDGE_PDGR)&MSK)];
                            if (pdu > 1 && (pdu & PDGR_MSK) == 0){
                                toLev = gssEdgeDir[(pdu-3)>>>NSHF][((pdu-3)&MSK)];
                                break sent;
                            }
                        }
                        toLev = lastnode--;
                        while (gssNodeDir[(toLev)>>>NSHF][((toLev)&MSK)] >= 0) toLev--; 
                    }
                    int startcover = gssEdgeDir[(rnode-2)>>>NSHF][((rnode-2)&MSK)] & ~HEADSYM;
                    if (toLev != startcover){
                        ;
                        if (nullrule) break;
                        continue;
                    }

                    // build the derivation
                    ;
                    int len = lev;
                    if (fixed){
                        len = this.tab.ruleLen[rule];
                    }
                    if (this.reusablePath == null){
                        this.reusablePath = new int[len];
                    } else if (this.reusablePath.length < len){
                        this.reusablePath = new int[len];
                    }
                    int[] gamma = this.reusablePath;
                    int gj = 0;

                    // this works for groups because they have a path that encompasses all bodies,
                    fp: if (fixed){
                        // for REU, and perhaps for others it can happen that the lr dyn encodes
                        // each single body, which means that we come here with obo reductions,
                        // and they are fixed.
                        // The problem is how to get rid of the extra obo level
                        for (int g = lev-1; g >= 0; g--){
                            gamma[gj++] = gssEdgeDir[(pathedg[g]+EDGE_PDGR)>>>NSHF][((pathedg[g]+EDGE_PDGR)&MSK)];
                        }
                    } else {
                        gj = filterPath(pathedg,lev,gamma,repgroup,nullbody,lhs);
                        if (gj < 0){
                            ;
                            if (nullrule) break allph;
                            continue allph;
                        }
                        len = gj;
                    }

                    if (fixed){
                        for (int p = this.tab.ruleIndex[rule]+derlen; this.tab.grammar[p] < this.tab.ruleBase; p++){
                            gamma[gj++] = this.tab.grammar[p] | E_NT;
                        }
                    }
                    dupcheck: {
                        if (this.disambiguate) break dupcheck;
                        ;
                        ;
                        if (rulehashnr/this.rulehashdir.length > 5){
                            this.rulehashdir = new int[this.rulehashdir.length*2];
                            Arrays.fill(this.rulehashlink,0);
                            rulehashbase = 1;
                            ;
                        }
                        int hfunct = 0;
                        for (int n = 0; n < gj; n++){
                            hfunct = 31*hfunct + gamma[n];
                        }
                        hfunct &= this.rulehashdir.length - 1;
                        boolean found = false;
                        hloop: for (int z = this.rulehashdir[hfunct];
                            z >= this.rulehashbase; z = this.rulehashlink[z-this.rulehashbase]){
                            int ri = this.rulehashdata[z-this.rulehashbase];
                            int r = this.tree[(ri)>>>NSHF][((ri)&MSK)] & ~HEAD;
                            int ln = 0;
                            if (r < this.tab.numOfRules){
                                ln = this.tab.ruleLen[r];
                                if (r != rule) continue hloop;
                            } else {
                                ln = r - this.tab.numOfRules;
                            }
                            if (ln != gj) continue hloop;
                            int rd = ri + 1;
                            for (int rg = 0; rg < ln; rg++, rd++){
                                int el = gamma[rg];
                                conv: {
                                    if ((el& PDGR_MSK) == E_NT){                        // nullable nt
                                        if (!fixed){                          // the body of a group
                                            el = this.tab.body(lhs) | E_NT;   // record it for remapping
                                        }
                                        break conv;
                                    }
                                    if (el < 0) break conv;                // token
                                    if ((el & HEADF) == HEAD) break conv;  // already built
                                    int s = gssEdgeDir[(el+2)>>>NSHF][((el+2)&MSK)];
                                    if ((s & HEADTREE) != 0){              // already encoded
                                        el = s;
                                        break conv;
                                    }
                                }
                                if (el != this.tree[(rd)>>>NSHF][((rd)&MSK)]) continue hloop;
                            }
                            // found
                            found = true;
                            ;
                            break;
                        }
                        if (found){
                            if (nullrule) break allph;
                            continue allph;
                        }
                        // new rule, add it to the hash table
                        int z = nrrules;
                        if (z >= this.rulehashlink.length){
                            int newlen = z << 1;
                            if (z < this.rulehashlink.length << 1){        // extend at least twice
                                newlen = this.rulehashlink.length << 1;
                            }
                            this.rulehashlink = Arrays.copyOf(this.rulehashlink,newlen);
                            this.rulehashdata = Arrays.copyOf(this.rulehashdata,newlen);
                            ;
                        }
                        this.rulehashlink[z] = this.rulehashdir[hfunct];  // insert at beginning
                        this.rulehashdir[hfunct] = z + this.rulehashbase;
                        this.rulehashdata[z] = this.loc;

                    } // dupcheck

                    if (this.disambiguate){
                        ;
                        dis: if (firstpath){
                            // the first time record the path
                            firstpath = false;
                            if (this.winnerpath == null ||
                                this.winnerpath.length < gj){
                                this.winnerpath = Arrays.copyOf(gamma,gj);
                            } else {
                                System.arraycopy(gamma,0,this.winnerpath,0,gj);
                            }
                            ogamma = this.winnerpath;
                            ogj = gj;
                            orule = rule;
                        } else {
                            boolean newwins = false;
                            boolean cyc = (ParserTables.CYC & this.tab.attr) != 0;
                            if (cyc && fixed){
                                ;
                                if (!((this.tablr.allCyc[(lhs)>>>ParserTables.NSHIFTB] & (1 << (lhs& ParserTables.MASKB))) != 0)){
                                    if (((this.tablr.ruleCyc[(rule)>>>ParserTables.NSHIFTB] & (1 << (rule& ParserTables.MASKB))) != 0)){
                                        // wins the old
                                        break dis;
                                    } else if (((this.tablr.ruleCyc[(orule)>>>ParserTables.NSHIFTB] & (1 << (orule& ParserTables.MASKB))) != 0)){
                                        // wins the new
                                        newwins = true;
                                    }
                                }
                            }
                            // subsequent times: compare the path with the winner one
                            if (!newwins){
                                newwins = prior(gamma,gj,rule,ogamma,ogj,orule,lhs);
                            }
                            if (newwins){
                                if (this.winnerpath == null ||
                                    this.winnerpath.length < gj){
                                    this.winnerpath = Arrays.copyOf(gamma,gj);
                                } else {
                                    System.arraycopy(gamma,0,ogamma,0,gj);
                                }
                                ogamma = this.winnerpath;
                                ogj = gj;
                                orule = rule;
                                ;
                            }
                        }
                        if (nullrule) break;
                        continue allph;
                    }
                    ;

                    if (this.tab.ntKind[lhs] == ParserTables.OBO){
                        ;
                        int el = gamma[0];
                        obo: {
                            if ((el& PDGR_MSK) == E_NT) break obo;                    // nullable nt
                            if (el < 0) break obo;                          // token
                            if ((el & HEADF) == HEAD) break obo;            // already built
                            int s = gssEdgeDir[(el+2)>>>NSHF][((el+2)&MSK)];
                            if ((s & HEADTREE) != 0) break obo;              // already encoded
                            if (gssEdgeDir[(el-1)>>>NSHF][((el-1)&MSK)] != 0) break obo;              // remapped
                            ;
                            return encodetree(el);
                        }
                    }

                    // reserve space in tree for rule
                    loc = this.loc;
                    // save the start address of this rule
                    if (nrrules >= this.ruleptrs.length){
                        this.ruleptrs =  Arrays.copyOf(this.ruleptrs,nrrules << 1);
                    }
                    this.ruleptrs[nrrules++] = loc;
                    this.loc += len + 1;
                    if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                        enlargeTree(this.loc);
                    }
                    // copy header
                    int hdr = rule;
                    if (!fixed) hdr = len + this.tab.numOfRules;
                    if (this.tab.ntKind[lhs] == ParserTables.REF){
                        hdr = len + this.tab.numOfRules;
                    }
                    this.tree[(loc)>>>NSHF][((loc)&MSK)] = hdr | HEAD;
                    ;
                    ;
                    loc++;
                    int startrule = loc;
                    ;
                    for (int k = 0; k < len; k++){
                        int el = gamma[k];
                        ;
                        this.tree[(loc)>>>NSHF][((loc)&MSK)] = el;
                        loc++;
                        if (el == -1){
                            Trc.out.printf("invalid at: %d lev %d j %d rnode %d\n",k,this.level,j,rnode);
                        }
                        if ((el& PDGR_MSK) == E_NT){                     // nullable nt
                            ;
                            if (this.tab.ntKind[lhs] == ParserTables.RER ||
                                this.tab.ntKind[lhs] == ParserTables.REU) continue;
                            if (!fixed){                       // the body of a group
                                this.tree[(loc-1)>>>NSHF][((loc-1)&MSK)] = this.tab.body(lhs) | E_NT;   // record it for remapping
                            }
                            continue;
                        }
                        if (el < 0) continue;                  // token
                        if ((el & HEADF) == HEAD) continue;    // already built
                        int s = gssEdgeDir[(el+2)>>>NSHF][((el+2)&MSK)];
                        if ((s & HEADTREE) != 0){              // already encoded
                            this.tree[(loc-1)>>>NSHF][((loc-1)&MSK)] = s;
                            ;
                            continue;
                        }
                        // remove one level for OPT
                        int re = gssEdgeDir[(el+1)>>>NSHF][((el+1)&MSK)];
                        int ntel = (re& ParserLRTables.GPMASK);
                        if (ntel >= this.tab.ruleBase){
                            ntel -= this.tab.ruleBase;
                            ntel = this.tab.ruleToNt[ntel];
                        }
                        ;
                        if (this.tab.ntKind[ntel] == ParserTables.OPT){
                            el = gssEdgeDir[(s+EDGE_PDGR)>>>NSHF][((s+EDGE_PDGR)&MSK)];                      // the pedigree of the edge
                            this.tree[(loc-1)>>>NSHF][((loc-1)&MSK)] = el;
                            ;
                        }

                        if (gssEdgeDir[(el-1)>>>NSHF][((el-1)&MSK)] != 0){              // remapped
                            ;
                            continue;
                        }
                        ;
                        gssEdgeDir[(el-1)>>>NSHF][((el-1)&MSK)] = -1;                   // mark
                        if (qp >= this.encodequeue.length){
                            if (dp > this.encodequeue.length/QUEUE_THRES_1){  // shift down, if worth
                                System.arraycopy(this.encodequeue,dp,this.encodequeue,0,qp-dp);
                                qp -= dp;
                                dp = 0;
                            } else {                           // enlarge
                                this.encodequeue = Arrays.copyOf(this.encodequeue,
                                    this.encodequeue.length+this.encodequeue.length/QUEUE_THRES_2);
                            }
                        }
                        this.encodequeue[qp++] = el;  // enqueue it
                    }
                    ;
                    startrule = loc - startrule;               // nr of elements copied
                    ;
                    if (nullrule) break;
                } // allph
            } // visit of all pedigrees of the edge

            if (!this.disambiguate){
                this.rulehashbase += nrrules+1;        // highest pointer of previous use of hash table
                rulehashnr = nrrules;
            }
            if (this.disambiguate){
                // remove one level for obo
                if (this.tab.ntKind[lhs] == ParserTables.OBO){
                    ;
                    int el = ogamma[0];
                    obo: {
                        if ((el& PDGR_MSK) == E_NT) break obo;                     // nullable nt
                        if (el < 0) break obo;                  // token
                        if ((el & HEADF) == HEAD) break obo;    // already built
                        int s = gssEdgeDir[(el+2)>>>NSHF][((el+2)&MSK)];
                        if ((s & HEADTREE) != 0) break obo;     // already encoded
                        if (gssEdgeDir[(el-1)>>>NSHF][((el-1)&MSK)] != 0) break obo;              // remapped
                        ;
                        return encodetree(el);
                    }
                }

                // build derivation of winner
                int len = ogj;
                int rule = orule;
                int[] gamma = ogamma;
                // reserve space in tree for rule
                loc = this.loc;
                this.loc += len + 1;
                if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                    enlargeTree(this.loc);
                }
                // copy header
                int hdr = rule;
                if (!fixed) hdr = len + this.tab.numOfRules;
                if (this.tab.ntKind[lhs] == ParserTables.REF){
                    hdr = len + this.tab.numOfRules;
                }
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = hdr | HEAD;
                ;
                ;
                loc++;

                int startrule = loc;
                ;
                for (int k = 0; k < len; k++){
                    int el = gamma[k];
                    ;
                    this.tree[(loc)>>>NSHF][((loc)&MSK)] = el;
                    loc++;
                    if (el == -1){
                        Trc.out.printf("invalid at: %d lev %d rnode %d\n",k,this.level,rnode);
                    }
                    if ((el& PDGR_MSK) == E_NT){                     // nullable nt
                        ;
                        if (this.tab.ntKind[lhs] == ParserTables.RER ||
                            this.tab.ntKind[lhs] == ParserTables.REU) continue;
                        if (!fixed){                       // the body of a group
                            this.tree[(loc-1)>>>NSHF][((loc-1)&MSK)] = this.tab.body(lhs) | E_NT;   // record it for remapping
                        }
                        continue;
                    }
                    if (el < 0) continue;                  // token
                    if ((el & HEADF) == HEAD) continue;    // already built
                    int s = gssEdgeDir[(el+2)>>>NSHF][((el+2)&MSK)];
                    if ((s & HEADTREE) != 0){              // already encoded
                        this.tree[(loc-1)>>>NSHF][((loc-1)&MSK)] = s;
                        ;
                        continue;
                    }
                    // remove one level for OPT
                    int re = gssEdgeDir[(el+1)>>>NSHF][((el+1)&MSK)];
                    int ntel = (re& ParserLRTables.GPMASK);
                    if (ntel >= this.tab.ruleBase){
                        ntel -= this.tab.ruleBase;
                        ntel = this.tab.ruleToNt[ntel];
                    }
                    ;
                    if (this.tab.ntKind[ntel] == ParserTables.OPT){
                        el = gssEdgeDir[(s+EDGE_PDGR)>>>NSHF][((s+EDGE_PDGR)&MSK)];    // the pedigree of the edge
                        this.tree[(loc-1)>>>NSHF][((loc-1)&MSK)] = el;
                        ;
                    }
                    if (gssEdgeDir[(el-1)>>>NSHF][((el-1)&MSK)] != 0){              // remapped
                        ;
                        continue;
                    }
                    ;
                    gssEdgeDir[(el-1)>>>NSHF][((el-1)&MSK)] = -1;                   // mark
                    if (qp >= this.encodequeue.length){
                        if (dp > this.encodequeue.length/QUEUE_THRES_1){  // shift down, if worth
                            System.arraycopy(this.encodequeue,dp,this.encodequeue,0,qp-dp);
                            qp -= dp;
                            dp = 0;
                        } else {                           // enlarge
                            this.encodequeue = Arrays.copyOf(this.encodequeue,
                                this.encodequeue.length+this.encodequeue.length/QUEUE_THRES_2);
                        }
                    }
                    this.encodequeue[qp++] = el;  // enqueue it
                }
                ;
                startrule = loc - startrule;               // nr of elements copied
                ;
            }
            // store then the symbol node
            if (nrrules > 1){
                ;
                gssEdgeDir[(rnode-1)>>>NSHF][((rnode-1)&MSK)] = this.loc;              // remap it to symbol node
                loc = this.loc;
                this.loc += nrrules + 1;
                if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                    enlargeTree(this.loc);
                }
                ;
                ;
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = nrrules | HEADSYM;          // number of rules
                for (int j = 0; j < nrrules; j++){      // copy the rules
                    loc++;
                    this.tree[(loc)>>>NSHF][((loc)&MSK)] = this.ruleptrs[j];
                }
            }
        } // top while loop

        // scan the rules stored above in the final parse tree and remap the references to symbol
        // nodes in the edges blocks to the ones in the parse tree
        ;

        loc = this.loc;
        for (int i = start; i < loc;){                 // scan the tree
            int h = this.tree[(i)>>>NSHF][((i)&MSK)];
            if ((h & HEADF) == HEADSYM){               // symbol node
                int len = h & ~HEADSYM;
                this.altNum += len;
                i += len + 1;
            } else {
                int startder = i;
                int len = h & ~HEADF;                  // length of phrase of derivation
                int rule = len;
                boolean fixed = true;
                if (len < this.tab.numOfRules){
                    len = this.tab.ruleLen[len];       // fixed length
                } else {
                    len -= this.tab.numOfRules;        // variable length
                    fixed = false;
                }
                ;
                i++;
                int end = i + len;
                int elstart = i;
                for (; i < end; i++){
                    int el = this.tree[(i)>>>NSHF][((i)&MSK)];
                    ;
                    if ((el & HEADF) == HEAD){          // already built
                        el &= ~HEAD;
                    } else if ((el& PDGR_MSK) == E_NT){           // e-tree
                        int nt = el & ~E_NT;
                        ;
                        if (this.etrees[nt] == 0){      // not already encountered
                            this.etrees[nt] = encodeEtree(nt);
                        }
                        el = this.etrees[nt];
                    } else if (el > 0){
                        ;
                        el = gssEdgeDir[(el-1)>>>NSHF][((el-1)&MSK)];
                    }
                    this.tree[(i)>>>NSHF][((i)&MSK)] = el;
                }
                ;
                this.derNum++;
                this.eleNum += len;
            }
        }

        this.treeLen = this.loc;
        this.treeStart = gssEdgeDir[(root-1)>>>NSHF][((root-1)&MSK)];               // not "start" when it has several rules
        ;

        int redu = gssEdgeDir[(root+1)>>>NSHF][((root+1)&MSK)];
        int nt = (redu& ParserLRTables.GPMASK);
        if (nt >= this.tab.ruleBase){
            nt -= this.tab.ruleBase;
            nt = this.tab.ruleToNt[nt];
        }

        this.nocover = false;
        // return start;
        return this.treeStart;
    }

    /**
     * Tell if the path passed as argument is the valid one for the kind of group
     * specified, or if it must be discarded.
     *
     * @param      pathedg path, represented as an array of edges
     * @param      lev length of the path
     * @param      gamma array in which the pedigrees of the edges are returned
     * @param      repgroup whether the gorup is a repetition one
     * @param      nullbody whether the body is nullable
     * @param      lhs nt of the derivation
     * @return     length of the significant part of gamma, -1 if the path has to be discasrded
     */

    /* This code is based on the fact that the parser gets all the derivations, limited to
     * a few empty bodies, and then we have only to filter them taking a representative one.
     * If the body is not nullable, then empty bodies in paths are only the OBO ones, and they
     * are discarded.
     * If the body is absent, then the forest fragment is build by encodeetree.
     * Otherwise the body is nullable.
     * For groups that have a lower and/or a limit, i.e. a number of bodies that are present in
     * their rule, the good path could have up to l-1 empty bodies, of which we take only one.
     * For the other groups the good path is the one that has only one empty body (there could be
     * other paths that have more, but we take only the good one).
     * No good path has a nonempty body after an empty one.
     * And also the ones that have some nonempty body and no empty ones. The only groups that
     * can have nonempty bodies and no nullable ones are the (n) ones, that have fixed length
     * derivations while here we deal only with the variable ones.
     */

    private int filterPath(int[] pathedg, int lev, int[] gamma, boolean repgroup,
        boolean nullbody, int lhs){
        int gj = 0;
        boolean replower = this.tab.ntKind[lhs] == ParserTables.RER ||
            this.tab.ntKind[lhs] == ParserTables.REL ||
            this.tab.ntKind[lhs] == ParserTables.REU;
        int lower = 0;
        if (this.disambiguate){
            if (nullbody){
                if (this.tab.ntKind[lhs] == ParserTables.REL){
                    lower = this.tab.ruleLen[this.tab.ntToRule[lhs]];
                } else if (this.tab.ntKind[lhs] == ParserTables.RER){
                    int ru = this.tab.ntToRule[lhs];
                    for (int p = this.tab.ruleIndex[ru];; p++){
                        int gp = this.tab.grammar[p];
                        if (this.tab.ntKind[gp] == ParserTables.OBO){
                            lower = (p - this.tab.ruleIndex[ru]);
                            break;
                        }
                    }
                }
            }
            ;
        }
        doit: {
            int totempty = 0;
            int totnotempty = 0;
            int prev = -1;
            pth: for (int g = lev-1; g >= 0; g--){
                int pdgr = gssEdgeDir[(pathedg[g]+EDGE_PDGR)>>>NSHF][((pathedg[g]+EDGE_PDGR)&MSK)];
                ;
                // reduce one level for OBO bodies
                bod: if (((pdgr& PDGR_MSK) == E_NT)){
                    totempty++;
                    int nt = pdgr & ~E_NT;
                    if (repgroup){
                        if (replower){
                            pdgr = this.tab.body(nt) | E_NT;
                            if (nullbody){
                                if (this.disambiguate){
                                    ;
                                    if (gj >= lower) continue pth;   // skip extra empty bodies
                                }
                                if (pdgr == prev) continue pth;
                                // change the pedigree to the body
                                break bod;
                            } else {
                                continue pth;
                            }
                        } else {
                            if (this.disambiguate) continue pth;   // skip empty bodies
                            if (pdgr == prev){
                                ;
                                gj = -1;
                                break doit;
                            }
                        }
                    }
                } else {
                    totnotempty++;
                    if (totempty > 0){
                        // nonempty after empty
                        if (repgroup){
                            ;
                            gj = -1;
                            break doit;
                        }
                    }
                    int sub = gssEdgeDir[(pdgr+2)>>>NSHF][((pdgr+2)&MSK)];
                    if ((sub & HEADF) == 0){
                        // TRACE(W,"%s\n",pedigreeToString(pdgr));
                        int red = gssEdgeDir[(pdgr+1)>>>NSHF][((pdgr+1)&MSK)];
                        int gp = (red& ParserLRTables.GPMASK) - this.tab.ruleBase;
                        int nt = this.tab.ruleToNt[gp];
                        if (this.tab.ntKind[nt] == ParserTables.OBO){
                            // skip to the body
                            pdgr = gssEdgeDir[(sub+EDGE_PDGR)>>>NSHF][((sub+EDGE_PDGR)&MSK)];
                        }
                    }
                }
                gamma[gj++] = pdgr;
                prev = pdgr;
            }
            checkpath: {
                if (this.disambiguate) break checkpath;
                ;
                // if RER or REU and totnotempty < upper, then check that there is an empty one
                if (this.tab.ntKind[lhs] == ParserTables.RER ||
                    this.tab.ntKind[lhs] == ParserTables.REU){
                    if (nullbody && totempty == 0 && totnotempty > 0
                        && totnotempty < this.tab.ruleLen[lhs]){
                        ;
                        gj = -1;
                    }
                    break doit;
                }
                if (repgroup && nullbody && totempty == 0 && totnotempty > 0){
                    ;
                    gj = -1;
                    break doit;
                }
            }
        } // doit
        return gj;
    }

    /**
     * Tell if the specified derivation represents a tree that is prior in the 
     * leftmost-earliest ordering of the derivation present in the specified
     * other derivation.
     *
     * @param      newder derivation
     * @param      len its length
     * @param      rule rule of the derivation (-1 if group)
     * @param      older other derivation
     * @param      olen its length
     * @param      orule rule of the other derivation (-1 if group)
     * @return     <code>true</code> if it is, <code>false</code> otherwise
     */

    /* For normal derivations, the rule numbers are compared, and the earlier wins,
     * or the one with the highest explicit priority, if any.
     * If the rules are the same, then the norms of the  corresponding elements are compared,
     * until one pair is found for which the norms are not equal. Then the higer wins.
     * This applies also to groups. Additionally, for groups, the rule numbers of the corresponding
     * elements are compared before comparing the norms, as above.
     *
     * The prios placed on cyclic rules are ineffective.
     */

    private boolean prior(int[] newder, int len, int rule, int[] oldder, int olen,
        int orule, int lhs){
        ;
        boolean res = false;
        pr: if (rule != orule){
            if (rule < orule){
                ;
                res = true;
            }
            ;
            if (this.tab.priLocs.length > 0){
                res = false;
                int idx = this.tab.ruleIndex[rule] + this.tab.ruleLen[rule];
                int pri = 0;
                int p = Arrays.binarySearch(       // index of prio in priVals
                    this.tab.priLocs,idx);
                if (p >= 0) pri = tab.priVals[p];  // priority of first rule
                idx = this.tab.ruleIndex[orule] + this.tab.ruleLen[rule];
                int opri = 0;
                p = Arrays.binarySearch(           // index of prio in priVals
                    this.tab.priLocs,idx);
                if (p >= 0) opri = tab.priVals[p]; // priority of first rule
                if (pri > opri){
                    res = true;
                } else if (pri == opri){
                    if (rule < orule) res = true;
                }
                ;
            }
        } else {
            // priVals contains prios for the elemente (dots) of the rules, and
            // for the first dot of each rule (which is the rule prio), the indexe
            // in priMap. priMap contains the maps that order the elements of each
            // rule in priority descending ordering
            int map = -1;
            if (tab.priLocs.length > 0){            // priorities present
                int idx = Arrays.binarySearch(tab.priLocs,tab.ruleIndex[rule]);
                if (idx >= 0){
                    map = tab.priVals[idx];
                }
            }
            boolean repgroup = this.tab.ntKind[lhs] <= ParserTables.REF;
            if (tab.priLocs.length == 0) repgroup = false;
            for (int i = 0; ; i++){
                // do something when all corresponding bodies have been compared
                // and one derivation has some more than the other
                if (i == olen){
                    if (len > olen){
                        ;
                        res = true;          // second has more elements
                    }
                    ;
                    break;
                } else {
                    if (i >= len){
                        ;
                        break;
                    }
                }
                int r = i;
                if (map >= 0){
                    r = tab.priMaps[map + i];
                }

                int el1 = newder[r];
                int el2 = oldder[r];
                ;
                if (el1 == el2) continue;

                if (repgroup){
                    // when the elements are the bodies of a group, take also into
                    // account the priorities of their rules
                    // The elements of newder and oldder are the pdgr fields of the
                    // edges of a path in the gss. They either denote tokens, e-nts,
                    // or reductions of a same nonterminal.
                    int redu = gssEdgeDir[(el1+1)>>>NSHF][((el1+1)&MSK)];
                    int r1 = (redu& ParserLRTables.GPMASK) - this.tab.ruleBase;
                    redu = gssEdgeDir[(el2+1)>>>NSHF][((el2+1)&MSK)];
                    int r2 = (redu& ParserLRTables.GPMASK) - this.tab.ruleBase;
                    ;
                    ;
                    res = false;
                    int idx = this.tab.ruleIndex[r1] + this.tab.ruleLen[r1];
                    int pri = 0;
                    int p = Arrays.binarySearch(       // index of prio in priVals
                        this.tab.priLocs,idx);
                    if (p >= 0) pri = tab.priVals[p];  // priority of first rule
                    idx = this.tab.ruleIndex[r2] + this.tab.ruleLen[r2];
                    int opri = 0;
                    p = Arrays.binarySearch(           // index of prio in priVals
                        this.tab.priLocs,idx);
                    if (p >= 0) opri = tab.priVals[p]; // priority of first rule
                    if (pri > opri){
                        res = true;
                    } else if (pri == opri){
                        if (r1 < r2) res = true;
                    }
                    ;
                    break pr;
                }

                int norm1 = norm(el1);
                int norm2 = norm(el2);
                ;
                if (norm1 > norm2){
                    res = true;
                    ;
                    break pr;
                }
                if (norm2 > norm1){
                    ;
                    break pr;
                }
            }
        }
        ;
        return res;
    }

    /**
     * Deliver the norm (the length of the frontier) of the subtree denoted by the specified
     * pedigree.
     *
     * @param      pdgr pedigree
     * @return     norm
     */

    private int norm(int pdgr){
        ;
        int norm = 0;
        if (pdgr < 0){                           // token
            norm = 1;
        } else if ((pdgr& PDGR_MSK) == E_NT){
            norm = 0;
        } else if (pdgr > 0){
            int start = gssEdgeDir[(pdgr-2)>>>NSHF][((pdgr-2)&MSK)] & ~HEADSYM;
            start = gssNodeDir[(start-1)>>>NSHF][((start-1)&MSK)];            // -levNr -1
            start = - start -1;
            int end = gssEdgeDir[(pdgr-3)>>>NSHF][((pdgr-3)&MSK)];
            end = gssNodeDir[(end-1)>>>NSHF][((end-1)&MSK)];                // -levNr -1
            end = - end -1;
            norm = end - start;
            ;
        }
        return norm;
    }
    /**
     * Deliver the size of the stack used.
     *
     * @return     size in bytes
     */

    @Override
    protected int stackLength(){
        int[] data = new int[50];
        int n = 0;
        data[n++] = arraySize(this.gssNodeDir);
        data[n++] = arraySize(this.gssEdgeDir);
        data[n++] = arraySize(this.edgeshlink);
        data[n++] = arraySize(this.edgeshdata);
        data[n++] = arraySize(this.edgeshdir);
        data[n++] = arraySize(this.nodeshdir);
        data[n++] = arraySize(this.nodeshlink);
        data[n++] = arraySize(this.stater);
        data[n++] = arraySize(this.potter);
        data[n++] = arraySize(this.sppfsymhdir);
        data[n++] = arraySize(this.sppfrulehdir);
        data[n++] = arraySize(this.reduceWl);
        data[n++] = arraySize(this.pathIterator);
        data[n++] = arraySize(this.pathItems);
        data[n++] = arraySize(this.encodequeue);
        data[n++] = arraySize(this.etrees);
        data[n++] = arraySize(this.ruleptrs);
        data[n++] = arraySize(this.reusablePath);
        data[n++] = arraySize(this.rulehashdir);
        data[n++] = arraySize(this.rulehashlink);
        data[n++] = arraySize(this.rulehashdata);
        int res = 0;
        for (int i = 0; i < data.length; i++){
            res += data[i];
        }
        ;
        return res;
    }

    // ------------- Testing -----------------------

}
