/*
 * @(#)ListBundle.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;

/**
 * The <code>ListBundle</code> class provides the English locale for
 * the testing of the <code>Listing</code> class.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

public class ListBundle extends ListResourceBundle {
    public Object[][] getContents() {
        return contents;
    }

    // LOCALIZE THIS

    public static final String[] MSGTAB = {
        "TOOMANY, too many errors",               // 0
        "BADLIN, too long line, truncated",       // 1
        "BADTKN, bad token",                      // 2
        "PREEND, premature end of input",         // 3
        "EXCCHAR, exceeding character(s)",        // 4
        "ILLSTMT, illegal statement",             // 5
        "MULDEF, multiple definition",            // 6
        "NOCORE, insufficient core",              // 7
        "UNEXLIN, unexpected line(s)",            // 8
    };

    private static final Object[][] contents = {
        {"MSGTAB",   MSGTAB},
        {"SECT",     "Section"},
        {"TITLE",    "Title"},
        {"MYERR",    "MYERR, bad token"},
        {"SOURCE",   "Source text"},
    };

    // END OF MATERIAL TO LOCALIZE
}
