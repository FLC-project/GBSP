/*
 * @(#)ParserBnf.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;
import java.util.*;
import lbj.ParserLexer.*;
import lbj.ParserNode.*;

/**
 * The <code>ParserBnf</code> class provides a representation
 * for a grammar supplied in BNF form.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

/* The parser generator reads a grammar, verifies the conditions and then
 * emits all the necessary tables.
 * To do it, it keeps an internal representation of the grammar which is not
 * necessarily similar to the tables needed by the generated parser.
 */

class ParserBnf extends ParserGrammar {

    /** The string to hold the current token. */
    Str symb = new Str(80);

    /** The reference to the lexer generator. */
    ParserLexGen lexer;

    /** The reference to the parser generator. */
    ParserGen gen;

    /** The mode of the lexer generator. */
    int mode;

    /** Whether the input contains data after the grammar. */
    public static final int EXTRA_DATA = 1 << 24;

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
//        ParserEngine eng = (ParserEngine) this;
//        eng.trc = this.trc;
//        if (eng.lex != null) eng.lex.trc = this.trc;
    }

    /** 
     * Construct a parser analyser.
     */

    ParserBnf(){
    }

    /** 
     * Construct a parser for the specified grammar and lexicon.
     *
     * @param      gram grammar
     */

    ParserBnf(Object gram){
        analyse(gram);
    }

    /** 
     * Parse the specified text on the specified grammar and lexicon.
     *
     * @param      gram grammar
     * @param      text text
     */

/*
    ParserBnf(Object gram, Object text){
        if (analyse(gram)){
            parse(text);
        }
    }
*/

    /**
     * Analyse an EBNF grammar and build the parsing tables.
     *
     * @param      gr object containing the grammar
     * @return     <code>true</code> when no errors are present,
     *             <code>false</code> otherwise
     */

    public boolean analyse(Object gr){
        this.lex = new ParserLexer(gr);
        return analyse();
    }

    /** The node which has just been created. */
    private ParserNode curNode;

    /**
     * Analyse a EBNF grammar and build the parsing tables.
     *
     * @return     <code>true</code> when no errors are present,
     *             <code>false</code> otherwise
     */

    /* An attempt is made to carry out the analysis of the text as much
     * as possible so as to report errors. When an error occurs which can
     * be immediately recovered, a message is filed and processing continues.
     * When processing may not continue, the input is skipped up to the
     * next rule and an exception is thrown. This allows to avoid to file
     * extra, meaningless errors. Lexical methods can all encounter errors.
     * In order not to test it after each call, they throw exceptions.
     * This is the case of fatal errors such as comments not close.
     * Therefore, an overall try block is used to catch it. When there is
     * a need to proceed with the analysis (like e.g. when parsing rules),
     * dedicated try blocks are used.
     * To overcome the well known impossibility of java to return an exception
     * and a value from a method (when an exception causes the call to abort,
     * no value is returned), the methods which build rules store a reference
     * to the nodes they create in the <code>curNode</code> field, which is
     * then accessed in a <code>finally</code> block to move its contents
     * to the final place. This allows to keep the part of rules which has
     * been correctly built so far, so as to proceed with the analysis with
     * an internal form which is as faithful as possible, and then to avoid
     * to report errors which do not exist.
     * These methods save and restore <code>curNode</code> when they call
     * internally other methods which can change it (except when such calls
     * are made when the value has not yet been assigned).
     *
     * An i/o error is due to the corruption of a file or a device error.
     * To fix it, the user must do something different than correcting what
     * s/he wrote. It is also useless to try to analyse the part of the text
     * which has been read because it is likely to produce a lot of
     * meaningless errors. Also when a comment has not been closed, a lot
     * of errors occur. The same applies to memory overflow errors.
     * All these are fatal errors.
     * ParserLexer detects an error when it strikes a non-closed comment.
     * In this case there is little to do to continue: no recovery is possible
     * in an easy way (there would be a need to go back and see if inside
     * the comment there is a sequence of tokens that might be interpreted
     * as non-comment text).
     * Without throwing an exception there would be a need to test it after
     * each call so as to jump to the end of analysis methods, or to report
     * failure, which eventually makes the flow of control go to the end,
     * but possibly with the reporting of other additional errors which could
     * be confusing.
     * Note that the detection of an eof is not an error: it would be if the
     * text had to be terminated by a specific "end" token.
     *
     * The empty string notation is put in the nonterminal or terminal
     * dictionary depending on what it is. This is done because all the
     * symbols should be in some dictionary, even if in this case it is
     * not strictly necessary.
     * It is marked as TR, EM, EO, and also ST (so as not to have an error)
     * because this reflects what it is.
     *
     * The evaluation of the usage count is done when parsing the input
     * so as to reflect the occurrences in the input (see sequence() and
     * anLexis()).
     */

    public boolean analyse(){
        ParserDic h;
        if ((FL_I & this.trc) != 0){
            this.lex.settrc("i");
        }
        if ((FL_V & this.trc) != 0){
            this.lex.settrc("vi");
        }
        if ((FL_W & this.trc) != 0){
            this.lex.trc |= FL_W;
        }
        boolean muldef = false;              // dupl. A ::= disabled by default
        ana: try {
            ParserNode usrEmp = null;
            gra: {
                if (!this.lex.gkey("GRAMMAR")) break gra;
                boolean grerr = false;
                if (!this.lex.gmet("{")) break gra;
                if (!this.lex.gntr(this.symb)){        // start nt not found
                    this.lex.message(
                        ParserLexer.ERR_NOTSTART);
                    grerr = true;
                } else {
                    this.start_sy =
                        addDic(this.ntDic,this.symb);  // insert it
                }
                muldef = this.lex.gkey("EBNF");        // allow same LHS
                if (this.lex.gmet("}")) break gra;
                emp: if (this.lex.gntr(this.symb)){    // empty string symbol
                    this.dic_usrEmp =
                        addDic(this.ntDic,this.symb);  // insert it
                } else {
                    int k = lex_gter(this.symb);
                    if (k == 0) break emp;
                    if (k != 1){
                        this.lex.message(ParserLexer.ERR_MISTER);
                        grerr = true;
                    }
                    if (this.symb.length == 0) break emp;
                    this.dic_usrEmp =
                        addDic(this.terDic,this.symb,  // insert it
                            ParserDic.TER); 
                }
                if (this.dic_usrEmp != null){
                    if (this.dic_usrEmp == this.start_sy){
                        this.lex.message(ParserLexer.ERR_MULDEF);
                        this.dic_usrEmp = null;
                    } else {
                        this.dic_usrEmp.status |= ParserNode.TR |
                            ParserNode.EO | ParserNode.EM | ParserNode.ST;
                        usrEmp = newNode(ParserNode.S_TER);
                        usrEmp.status |= ParserNode.TR;
                        this.dic_usrEmp.def = usrEmp;
                        usrEmp.def = this.dic_emp;
                    }
                }
                if (!this.lex.gmet("}")){
                    this.lex.message(ParserLexer.ERR_MISTOK,"}");
                    grerr = true;
                }
                if (grerr) resynch(false);
            }
            boolean lexis = false;
            l: for(;;){
                if ((FL_A & this.trc) != 0){
                    this.lex.trcBuffer("anEbnf");
                }
                if (this.lex.eof()) break l;         // eof
                if (this.lex.gkey("END")) break l;   // end syntax
                if (this.lex.gkey("LEXIS")){         // lexicon
                    lexis = true;
                    break l;
                }
                if (this.lex.gkey("OPTIONS")){
                    this.lex.backup(1);              // go back one lexeme
                    break l;
                }
                if (this.lex.gkey("PRECEDENCE")){    // precedence and associativity
                    this.lex.backup(1);              // go back one lexeme
                    break l;
                }
                pd: {
                    if (!this.lex.gntr(this.symb)){  // non-terminal not found
                        this.lex.message(
                            ParserLexer.ERR_MISNT);
                        resynch(true);
                        break pd;
                    }
                    long point = this.lex.getPoint();
                    long line = this.lex.getLineNr();
                    if (!this.lex.gmet("::=")){      // ::= not found
                        this.lex.message(
                            ParserLexer.ERR_MISTOK,"::=");
                        resynch(false);
                        break pd;
                    }
                    h = addDic(this.ntDic,this.symb,     // find definition
                        point,line);
                    if (h.def != null){                  // duplicated definition
                        if (!muldef){
                            if (h.def != usrEmp){
                                this.lex.message(
                                    ParserLexer.ERR_MULNTR,null,point);
                            }
                        }
                    } else {
                        h.point = point;                 // set its def. point
                        h.line = line;
                    }
                    if (this.start_sy == null){          // take first defined
                        this.start_sy = h;
                    }
                    if ((FL_A & this.trc) != 0){
                        this.lex.trcBuffer("anEbnf def");
                    }
                    this.defnt = h;                      // for <>
                    try {
                        expression(h.def);
                    } catch (ParserError exc){
                        resynch(false);                  // n.b. comment not closed, fatal
                        break pd;                        // done after finally body
                    } finally {
                        ParserNode altdef = h.def;
                        if (h == this.dic_usrEmp){       // check that it is empty
                            ParserNode n = this.curNode;
                            if (n.def != this.dic_emp){
                            } else if (n.suc != null){
                                n = n.suc;
                            } else if (n.alt != null){
                                n = n.alt;
                            } else if (n.constr != null){
                                n = n.constr;
                            } else {
                                n = null;
                            }
                            if (n != null){
                                this.lex.message(
                                    ParserLexer.ERR_ILLDEF,null,n.point);
                            }
                            altdef = null;
                        }
                        if (altdef == null){
                            h.def = this.curNode;
                        } else {
                            while (altdef.alt != null){  // find last
                                altdef = altdef.alt;
                            }
                            altdef.alt = this.curNode;
                        }
                    }
                    this.lex.gmet(".");                  // optional end production
                    if ((FL_A & this.trc) != 0){
                        this.lex.trcBuffer("anEbnf end def");
                        Trc.out.print(h + " ::= ");
                        h.def.trace_exp();
                        Trc.out.println();
                    }
                } // pd;
                if (this.lex.fatcnt > 0) break ana;
            } // l;

            if (lexis){                              // LEXIS present
                anLexis();                           // analyse it
            }

//            lex_tname = null;
//            if ((FL_B & this.trc) != 0){
//                this.lex.trcBuffer("anEbnf LEXER");
//            }
//            if (this.lex.gkey("LEXER")){             // lexer tables name
//                if (!this.lex.gidj(this.symb)){
//                    this.lex.message(ParserLexer.ERR_MISNAM);
//                } else {
//                  lex_tname = addDic(this.cbkDic,this.symb);  // find string
//                }
//            }

/** The name of the lexer tables. */
//private ParserDic lex_tname;
//???? no more useful

            if (this.lex.gkey("OPTIONS")){        // options
                anOptions();
            }
            if (this.lex.gkey("PRECEDENCE")){        // precedence and associativity
                anPrecedence();
            }

            this.lex.gkey("END");

            if ((EXTRA_DATA & this.mode) == 0){      // input complete
                if (!this.lex.eof()){
                    this.lex.message(ParserLexer.ERR_UNEXLIN);
                }
            }

            if ((FL_A & this.trc) != 0){
                this.lex.trcBuffer("anEbnf end");
            }
            if (this.ntDic.head == null){
                this.lex.message(ParserLexer.ERR_EMPTYG);  // empty grammar
                break ana;
            }
            if (this.start_sy == null){
                this.lex.message(ParserLexer.ERR_UNDEFS,
                    "",this.start_sy.point);
                break ana;
            } else {
                if (this.start_sy.def == null){      // undefined
                    this.lex.message(
                        ParserLexer.ERR_UNDEFS,"",this.start_sy.point);
                    break ana;
                }
            }
            process_lexis();                         // check and process lexis
            report_undef();                          // report undefined nts

            // this check is done here and not at the end of each
            // rule because rules introduce nonterminals.

            ck_duplProd();                           // report duplicated rules

            if ((FL_F & this.trc) != 0){
                dic_trace();
                trace_dic(this.ntDic,0,0,Trc.wrt);
            }
            if (this.lex.fatcnt == 0){               // no fatals
                this.lexer = new ParserLexGen();
                this.lexer.trc = this.trc;
                this.lexer.mode = this.mode;
                this.lexer.aut = new ParserTables();
                this.lexer.aut.trc = this.trc;
this.lexer.aut.gramFileName = this.lex.stream.path;
                // store options
                this.lexer.aut.options = this.options;
                this.lexer.genLexer(this);
                // N.B. it is not possible to free the lexer tables
                // when a user lexer is specified that does not
                // need them because they are used to check the grammar
            }
            find_irr();                              // find irrelevant nt's
            find_empty();                            // find empty producers
            find_eonly();                            // find empty only producers
            eval_ctype();                            // determine Chomsky types

            show_irr();                              // report irrelevant
            if ((ParserNode.TR & this.start_sy.status) == 0){
                this.lex.message(
                    ParserLexer.ERR_NOUSEST,"",this.start_sy.point);
            }

            ParserError m = this.lex.excLast;        // detect empty lexemes
            for (ParserNode a = this.lex_list;       // scan lexemes
                a != null; a = a.alt){
                if ((ParserNode.TY2 & a.def.status) != 0){
                    this.lex.message(ParserLexer.ERR_NREG,
                        null,a.point);               // non regular
                }
                if (a.def.def == null) continue;     // undefined
                if (((ParserNode.EM & a.def.status) != 0) ||
                    ((ParserNode.TR & a.def.status) == 0)){
                    this.lex.messageNoDup(
                        ParserLexer.ERR_EMPLEX,"",a.def.point,m);
                }
            }

            // get the number of ignore token
            if (this.lexer != null && this.lexer.aut != null){
                this.lexer.aut.ignore = -1;
                ig: if (this.ignore != null){
                    ParserNode a = null;
                    for (a = this.lex_list;              // scan lexemes
                        a != null; a = a.alt){
                        if (a.def == this.ignore){
                            this.lexer.aut.ignore = a.def.tokNum;
                            break;
                        }
                    }
                    // check unicity of ignore tokens
                    if (this.lexer.aut.isOption("-tokenSets")) break ig;
                    if (this.lexer.aut.tokLists == null) break ig;
                    for (int i = 0; i < this.lexer.aut.tokLists.length; i++){
                        char[] tl = this.lexer.aut.tokLists[i];
                        if (tl == null || tl.length <= 1) continue;
                        for (int j = 0; j < tl.length; j++){
                            if (tl[j] == this.lexer.aut.ignore){
                                this.lex.message(ParserLexer.ERR_LEXUSE,
                                    null,a.def.point);      // ambiguous
                                break ig;
                            }
                        }
                    }
                }
            }

            if ((FL_F & this.trc) != 0){
                Trc.out.printf("analyze fatals %s errors %s\n",
                    this.lex.fatcnt,this.lex.errcnt);
            }
            if ((this.lex.fatcnt == 0) &&            // no fatals
                (this.lex.errcnt == 0)){             // no errors
                this.gen = new ParserGen(this,this.lexer.aut);
                this.gen.trc = this.trc;
                this.gen.mode = this.mode;
                this.gen.genParser();
//this.gen.traceGenMode();
            }
        } catch (ParserError exc){
// exc.printStackTrace(System.err);
        } catch (OutOfMemoryError exc){
            this.lex.message(ParserLexer.ERR_NOCORE,"",this.lex.index(),exc);
        } catch (StackOverflowError exc){
            this.lex.message(ParserLexer.ERR_NOCORE,"",this.lex.index(),exc);
        } catch (Failure exc){
            this.lex.message(ParserLexer.ERR_IOERR,"",this.lex.index(),exc);
        } // ana;
        return (this.lex.fatcnt == 0) && (this.lex.errcnt == 0) &&
            (this.lex.warcnt == 0);
    }

    /**
     * Parse an expression and build its definition. Return it in the
     * <code>curNode</code> field.
     *
     * @param      head reference to an already built part of the expression
... unused!
     * @return     <code>true</code> if found
     */

    private boolean expression(ParserNode head){
        ParserNode q;
        boolean err;

        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("start expression");
        }
        this.curNode = null;
        boolean empty = false;
        boolean range = false;
        doit: {
            ParserNode r = null;
            try {
                subexpression(true);                  // allow also nothing
            } finally {
                if (this.curNode == null){
                    this.curNode = newNode(ParserNode.S_TER);
                    this.curNode.def = this.dic_emp;  // return an empty
                    empty = true;                     // .. one to spare
                }                                     // .. callers to do it
            }
            if (empty) break doit;
            r = this.curNode;
            l: while (this.lex.gmet("|")){
                if (!range && this.lex.gmet("..")){
                    if (!this.lex.gmet("|")){
                        this.lex.message(
                            ParserLexer.ERR_MISTOK,"|");
                        throw this.lex.excObj;
                    }
                    ParserNode k = this.curNode;      // save
                    try {
                        subexpression(false);         // second one, require a term
                    } finally {
                        r.alt = this.curNode;         // store anyway
                        this.curNode = k;             // restore
                        k = r.alt;
                    }
                    r.oper |= ParserNode.S_RNG;
                    r = k;                            // make it previous
                    range = true;
                } else {
                    q = this.curNode;                 // save
                    try {
                        subexpression(false);         // alternative, require a term
                    } finally {
                        r.alt = this.curNode;         // store anyway
                        this.curNode = q;             // rstore
                        q = r.alt;
                        r = q;
                    }
                    range = false;
                }
            } // l;
        } // doit
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("end expression");
            if (this.curNode != null) this.curNode.trcNode();
        }
        return !empty;
    }

    /**
     * Parse a subexpression and build its definition. Return it in the
     * <code>curNode</code> field.
     *
     * @param      emp <code>true</code> to accept empty expressions
     */

    private void subexpression(boolean emp){
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("start subexpression");
        }
        int pri = 0;
        this.curNode = null;
        sequence(!emp);
        ParserNode first = this.curNode;
        if (this.curNode != null){
            ParserNode q = this.curNode;
            l: for (;;){
                pri = priority();
                int oper = 0;
                if (this.lex.gmet("-")){          // difference
                    oper = ParserNode.S_DIFF;
                } else if (this.lex.gmet("&")){   // intersection
                    oper = ParserNode.S_AND;
                }
                ParserNode p = this.curNode;
                try {
                    sequence(false);
                } finally {
                    q.suc = this.curNode;
                    q.oper |= oper;
                    this.curNode = p;
                }
                if (q.suc == null){
                    if (oper != 0){               // second operand missing
                        this.lex.message(
                            ParserLexer.ERR_MISFAC);
                        throw this.lex.excObj;
                    }
                    break l;
                }
                if ((oper == 0) &&
                    (q.suc.def == this.dic_emp) &&
                    (q.suc.oper == 0)){           // intermediate empty string
                    q.suc = null;                 // discard it
                } else if ((oper == 0) &&
                    (q == first) &&
                    (first.def == this.dic_emp) &&
                    (first.oper == 0)){           // initial empty string followed by a factor
                    this.curNode = q.suc;         // discard it
                } else {
                    q = q.suc;
                }
                q.prio = (char)pri;
                pri = 0;
            } // l;
        }
        if (this.curNode != null){
            this.curNode.prio = (char)pri;
        }
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("end subexpression");
            if (this.curNode != null) this.curNode.trcNode();
        }
    }

    /**
     * Parse a priority directive, and return the value of the priority.
     *
     * @return     priority
     */

    private int priority(){
        int prio = 0;
        doit: {
            if (!this.lex.gmet("(")){
                break doit;
            }
            if (!this.lex.gkey("prio")){        // missing prio
                this.lex.message(ParserLexer.ERR_MISKEY);
                throw this.lex.excObj;
            }
            if (this.lex.gdel(':')){            // : specified
                if (this.lex.gdec(this.symb)){  // priority
                    if (this.lex.integral >     // too big
                        Character.MAX_VALUE){
                        this.lex.message(ParserLexer.ERR_ILLNUM);
                    } else {
                        prio = (int)this.lex.integral;
                    }
                } else {
                    this.lex.message(ParserLexer.ERR_MISNUM);
                    throw this.lex.excObj;
                }
            } else {
                prio = 1;
            }
            if (!this.lex.gmet(")")){
                this.lex.message(ParserLexer.ERR_MISTOK,")");
                throw this.lex.excObj;
            }
        } // doit
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("priority " + prio);
        }
        return prio;
    }

    /** Whether the grammar is being parsed (instead of the lexicon). */
    private boolean in_grammar = true;

    /**
     * Parse a sequence and build its definition. Return it in the
     * <code>curNode</code> field.
     *
     * @param      mand <code>true</code> to return an error if not found
     */

    /* When the term is preceded by several unary operators, a group
     * is created to represent all of them exept the last one.
     */

    private void sequence(boolean mand){
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("start sequence");
        }
        int unary = 0;
        if (this.lex.gmet("^")){                     // complement
            unary = ParserNode.S_COMPL;
        } else if (this.lex.gmet("!")){              // language complement
            unary = ParserNode.S_COMCL;
        } else if (this.lex.gmet("~")){              // upto
            unary = ParserNode.S_UPTO;
        }
        ParserNode first = null;
        ParserNode prev = null;
        do {
            int una = 0;
            if (this.lex.gmet("^")){                 // complement
                una = ParserNode.S_COMPL;
            } else if (this.lex.gmet("!")){          // language complement
                una = ParserNode.S_COMCL;
            } else if (this.lex.gmet("~")){          // upto
                una = ParserNode.S_UPTO;
            } else {
                break;
            }
            long point = this.lex.getPoint();        // create a group
            long line = this.lex.getLineNr();
            ParserDic nt0 = addDic(this.ntDic,null,point,line);
            nt0.status |= ParserNode.G_GRO;
            ParserNode p = new ParserNode(ParserNode.S_NT,point,nt0);
            if (first == null){
                first = p;
                this.curNode = p;
            } else {
                prev.def.def = p;
            }
            prev = p;
            p.oper = (byte)unary;                    // store the previous one
            unary = una;                             // make this the current
        } while (true);
        ParserNode sav = this.curNode;
        try {
            if (unary != 0) mand = true;
            factor(mand);
        } finally {
            if (this.curNode != null){
                this.curNode.oper = (byte)unary;
            }
            if (prev != null){
                if (this.curNode == null){
                    this.curNode = newNode(ParserNode.S_TER);
                    this.curNode.def = this.dic_emp;     // create an empty
                }
                prev.def.def = this.curNode;
                this.curNode = sav;
            }
        }
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("end sequence");
            if (this.curNode != null) this.curNode.trcNode();
        }
    }

    /**
     * Parse a factor and build its definition. Return it in the
     * <code>curNode</code> field.
     *
     * @param      mand <code>true</code> to return an error if not found
     */

    /* Groups are represented by expanding them into equivalent rules:
     *
     *  group        low upp attrib. kind repl. equivalent rule              
     *
     *  {alpha}(l:u)  l   u   G_RE1  RER  &0    &0 ::= &1 ... &1 &2 ... &2
     *                               BOD        &1 ::= alpha
     *                               OBO        &2 ::= "" | &1
     *
     *  {alpha}(:u)   0   u   G_RE0  REU  &0    &0 ::= &2 .. &2
     *                               BOD        &1 ::= alpha
     *                               OBO        &2 ::= "" | &1
     *
     *  {alpha}(:1)   0   1   G_OPT  OPT  &0    &0 ::= &1 | ""
     *  [alpha]                      BOO        &1 ::= alpha
     *
     *  {alpha}(l:)   l  inf  G_RE1  REL  &0    &0 ::= &1 ... &1 | &1 &0
     *                               BOD¹       &1 ::= alpha
     *  {alpha}+      1  inf  G_RE1  REP  &0    &0 ::= &1 | &1 &0
     *                               BOD¹       &1 ::= alpha
     *
     *  {alpha}(0:)   0  inf  G_RE0  RES  &0    &0 ::= "" | &1 &0
     *  {alpha}*                     BOD¹       &1 ::= alpha
     *
     *  {alpha}(1)    1   1   G_GRO  GRO  &0    &0 ::= alpha
     *  {alpha}
     *
     *  {alpha}(l)    l   l   G_RE1  REF  &0    &0 ::= &1 ... &1
     *                               BOD        &1 ::= alpha
     *
     * ¹: it becomes BOR when the encoded grammar is changed to support
     *    natively groups in engines
     *
     * The LEFTGROUPS mode option allows to use left recursive rules
     * (instead of the right recursive ones in G_RE0 and G_RE1).
     * When the expression in an optional group contains an empty alternative,
     * the group is stored as a simple group. This, besides being shorter,
     * avoids a "duplicated alternative" error.
     *
     * A more compact equivalent rule could be used for groups whith one
     * alternative only. E.g. {alpha}* could become &0 = "" | alpha &0.
     * However, there would then be a need to make the parser engine detect it.
     * Moreover, to do it in {...}+, the expression must be cloned.
     * Since singleton reduction (see the engine) makes the same optimization
     * anyway, it is not done.
     * Note that repetition groups are defined with right recursion.
     * This is to enforce the earliest-longest-acyclic default ambiguity
     * resolution. This leads also to generate less items when parsing. It is
     * due to the fact that rules such as &1 | &1 &0 have two alternatives
     * applicable since both start with &1, and when &1 gets completed, both
     * need be advanced. A rule &1 | &0 &1 instead, advances only one alternative
     * since the other is advanced only later.
     *
     * Option groups are represented as &0 ::= &1 | "" to maintain the
     * ordering of the alternatives in the body and also to behave properly
     * when the body produces the empty string. I.e., the body takes priority
     * over the empty one so as to match it when its definition contains
     * the empty string instead of matching no body. The matching is such
     * that when no occurrence of the body is present, the group is considered
     * not to be applied (and the parse tree reports it), while when an
     * occurrence, albeit empty, is present, the groups is considered to be
     * applied, and the parse tree reports one derivation for one body.
     * This, however, produces one nonterminal more. A shorter representation
     * is: &0 ::= alpha | "" adds an extra rule to alpha, and thus does not
     * maintain the origin definition, visible at the API.
     * They are also not represented as (0:1) because the latter needs an
     * additional nonterminal.
     *
     * Groups with an optional part are represented as a sequence of identical
     * options instead of nested options. E.g. {a}(0:3) is represented as
     * [a][a][a] instead of [a[a[a]]]. This is so because the nested ones
     * require the introduction of many rules.
     *
     * Groups are expanded into equivalent rules, but an attribute is kept to
     * allow to reconstruct the original construct.
     * There is a need to know it in some places, like e.g. when comparing
     * alternatives, or printing, or reporting errors (errors might be
     * reported also on group occurrences).
     * In general, there can be a (possibly missing) fixed part, followed
     * by a (possibly missing) optional part, or Kleene part.
     * The groups (1) and (0:1) have a simplified equivalent rule, which
     * cannot be distinguished from the others, and thus are flagged as
     * G_GRO and G_OPT respectively.
     * Groups whose lower bound is zero are flagged as G_RE0:
     *
     *    - the ones which have two alternatives, are (0:),
     *    - otherwise, are (0:u).
     *
     * Groups whose lower bound is greater than zero are flagged as G_RE1:
     *
     *    - the ones which have two alternatives, have a number of
     *      repeated nodes, followed by a positive group,
     *    - otherwise, they have a number of repeated nodes, followed by
     *      optional nodes. The first element which is different marks
     *      the start of the optional ones.
     *
     * Expanding groups into equivalent rules is the simplest and most general
     * solution.  Visits of the grammar are kept simple since the internal
     * representation is also kept simple. Moreover, since bounds are not
     * expected to be large, this is also a reasonably efficient solution.
     * Thus, they are expanded, and then they are allowsed in the grammar also.
     * It would also be possible to have a dedicated internal representation,
     * but then it must be treated in many algorithms.
     * TR, etc., algorithms would work also by representing repetition groups
     * by means of appropriate groups, like, e.g. a G_GRO when the lower bound
     * is greater than zero and a G_RE0 otherwise, but without the expanded
     * rules. However, such group would not convey the necessary information
     * for all contexts. E.g. it would not be appropriate to detemine if an
     * expression generates one string only.
     *
     * Repeated groups are represented in parser and lexer automa as states and
     * edges. This is consistent with the fact that upper bounds are expected
     * to be low in practice. Moreover, supporting them as dedicated actions in
     * engines slows down execution and makes the engines more complex.
     *
     * The TR algorithm makes special cases for groups so as to avoid to
     * report useless errors.
     *
     * The equalAlt() methods compares groups, not their transformed
     * equivalents. This is obtained by requiring also the equality of
     * the attributes of nodes as well as the contents.

...  Spaces should be allowed, e.g. {...}( 3 : 5 ), but then, why not allow
  ( i )? This is not done so as to make (i) and (f) lexical elements, which
  are recognised by the lexer. Otherwise there would be a need to backup
  when looking for a repertition and not finding a number or colon after
  the open parenthesis.
  Well, backup of the parens only.
  (i) is not bad: it is a marker, not a parenthetised construct.
  But have a look with the notation for other clauses: if there are others
  which are parenthetised ...
  ... then update ParserLexer, and the doc

     * For {alpha}(l:u) and {alpha}(:u) groups the definition of &2 has
     * the empty alternative to simplify the construction of derivations
     * when the body is empty (otherwise a &1 ::= "" would appear because
     * of the default resolution of ambiguity, which would need to be
     * detected and descarted).
     * For {alpha}(l:), {alpha}+ and {alpha}* the recursion is at the
     * right and is the second alternative so as to make the default resolution
     * of the ambiguity be the leftmost-earliest without a need to make a
     * special case for it. If the equivalent rule were the opposite, special
     * code would be needed.
     *
     * Groups occur in:
     *
     *  - ParserBnf: here
     *  - ParserBnf: show_irr()
     *  - ParserGrammar: description of TR
     *  - ParserGrammar: cloneRule()
     *  - ParserFA: vi_primary()
     *  - ParserNode: toString(), equalAlt(), body()
     *  - ParserEngine: nestAmbiguity(), placeDer(), encodeDer()
     *  - ParserTables: ruleNr()
     */

    private void factor(boolean mand){
        int k;
        ParserNode p = null;

        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("start factor");
        }
        this.curNode = null;
        l: if (this.lex.gntr(this.symb)){            // non terminal
            long point = this.lex.getPoint();
            long line = this.lex.getLineNr();
            boolean del = false;
            try {
                if (this.in_grammar){
                    del = this.lex.gmet("::=");      // ::= present
                } else {
                    del = this.lex.gmet("==") ||     // == present
                        this.lex.gmet("=>");         // => present
                }
            } catch (ParserError exc){               // store anyway
            }
            if (del){                                // delimiter
                this.lex.backup(2);                  // go back two lexemes
                if (!mand){                          // factor not found
                    break l;
                }
                this.lex.message(ParserLexer.ERR_MISFAC);
                throw this.lex.excObj;
            }
            p = newNode(ParserNode.S_NT,point);
            if (isTheEmpty(this.symb,ParserDic.NTER)){  // empty string
                p.kind = ParserNode.S_TER;
                p.def = this.dic_emp;
            } else {
                p.def = addDic(this.ntDic,this.symb, // find it
                    point,line);
                p.def.use++;
            }
            this.curNode = p;
            p.attr |= storage(false,false);          // get storage directive
            if (this.lex.fatcnt > 0) throw this.lex.excObj;
        } else if (this.lex.gmet("<>")){             // same
            p = newNode(ParserNode.S_NT);
            p.def = this.defnt;                      // current nt being defined
            this.defnt.status |= ParserNode.SAME;
            p.status |= ParserNode.SAME;
            this.curNode = p;
        } else if ((k = lex_gter(this.symb)) > 0){   // terminal
            long point = this.lex.getPoint();
            long line = this.lex.getLineNr();
            if (!this.in_grammar){
                boolean del = false;
                try {
                    del = this.lex.gmet("=>");       // => present
                } catch (ParserError exc){           // store anyway
                }
                if (del){                            // => present
                    if (!mand){                      // factor not found
                        this.lex.backup(2);          // go back two lexemes
                        break l;
                    }
                    this.lex.message(ParserLexer.ERR_MISFAC);
                    throw this.lex.excObj;
                }
            }
            if (k == 1) k = ParserDic.TER;
            else if (k == 2) k = ParserDic.TER_SPE;
            p = newNode(ParserNode.S_TER,point);
            if (isTheEmpty(this.symb,ParserDic.TER)){  // empty string
                p.def = this.dic_emp;
            } else {
                p.def = addDic(this.terDic,            // add it
                    this.symb,k,point,line);
                p.def.use++;
            }
            this.curNode = p;
            p.attr |= storage(false,false);            // get storage directive
            if (this.lex.fatcnt > 0) throw this.lex.excObj;
        } else if (this.lex.gmet("[")){                // [
            long point = this.lex.getPoint();
            long line = this.lex.getLineNr();

            ParserDic nt0 = addDic(this.ntDic,null,point,line);
            nt0.status |= ParserNode.G_OPT;
            p = new ParserNode(ParserNode.S_NT,point,nt0);
            p.status |= ParserNode.G_OPT;
            this.curNode = p;
            ParserNode sav = this.curNode;
            ParserNode g = null;
            ParserError err = null;
            try {
                expression(null);
            } catch (ParserError exc){               // create G_OPT
                err = exc;                           // .. unless ""
            } finally {
                g = this.curNode;
                nt0.def = g;
                this.curNode = sav;
            }
            createGroup(nt0,0,1,point);              // create now the group
            if (err != null) throw err;
            if (!this.lex.gmet("]")){
                this.lex.message(ParserLexer.ERR_MISTOK,"]");
                throw this.lex.excObj;
            }
        } else if (this.lex.gmet("{")){              // {

            // a simple group is buil, which holds the expression
            // so as not to loose it in case of error. When the kind
            // of group is known, the structure is changed.

            long point = this.lex.getPoint();
            long line = this.lex.getLineNr();

            ParserDic nt0 = addDic(this.ntDic,null,point,line);
            nt0.status |= ParserNode.G_GRO;
            p = new ParserNode(ParserNode.S_NT,point,nt0);
            p.status |= ParserNode.G_GRO;
            this.curNode = p;

            int kind = ParserNode.G_GRO;
            ParserNode sav = this.curNode;
            ParserNode g = null;
            try {
                expression(null);
            } finally {
                g = this.curNode;
                nt0.def = g;
                this.curNode = sav;
            }
            if (this.lex.gmet("}*")){
                kind = ParserNode.G_RE0;
            } else if (this.lex.gmet("}+")){
                kind = ParserNode.G_RE1;
            } else if (!this.lex.gmet("}")){
                this.lex.message(ParserLexer.ERR_MISTOK,"}");
                throw this.lex.excObj;
            }

            ParserNode c;
            ParserDic nt1;
            int lo = -1;
            int hi = -1;
            switch (kind){
            case ParserNode.G_GRO:
                if (!this.lex.gmet("(")){              // simple group
                    lo = 1;
                    hi = 1;
                    break;
                }
                if (this.lex.gdec(this.symb)){         // lower bound
                    if (this.lex.integral >            // too big
                        Character.MAX_VALUE){
                        this.lex.message(ParserLexer.ERR_ILLNUM);
                    } else {
                        lo = (int)this.lex.integral;
                    }
                }
                if (this.lex.gdel(':')){               // : specified
                    if (this.lex.gdec(this.symb)){     // higher bound
                        if (this.lex.integral >        // too big
                            Character.MAX_VALUE){
                            this.lex.message(ParserLexer.ERR_ILLNUM);
                        } else {
                            hi = (int)this.lex.integral;
                        }
                        if (lo < 0) lo = 0;
                    } else if (lo < 0){                // : present, but
                        this.lex.message(              // .. both bounds missing
                             ParserLexer.ERR_MISNUM);
                        throw this.lex.excObj;
                    }
                } else if (lo < 0){                    // no bounds, no :
//                    this.lex.message(ParserLexer.ERR_MISNUM);
//                    throw this.lex.excObj;
                    this.lex.backup(1);             // go back one lexeme
                    lo = 1;
                    hi = 1;
                    break;
                } else {
                    hi = lo;
                }
                if (!this.lex.gmet(")")){
                    this.lex.message(ParserLexer.ERR_MISTOK,")");
                    throw this.lex.excObj;
                }
                if (hi >= 0){
                    if ((hi < lo) || (hi == 0)){
                        this.lex.message(ParserLexer.ERR_EMPRNG);
                    }
                }
                break;
            case ParserNode.G_RE0:
                lo = 0;
                hi = -1;
                break;
            case ParserNode.G_RE1:
                lo = 1;
                hi = -1;
                break;
            }
            createGroup(nt0,lo,hi,point);
            p.status &= ~ParserNode.G_GRP;
            p.status |= nt0.status & ParserNode.G_GRP;
        } else {
            if (mand){
                this.lex.message(ParserLexer.ERR_MISFAC);
                throw this.lex.excObj;
            }
        }
        if (p != null){
            p.status |= caseinsens();
        }
        cons: for (;;){
            if (p == null) break;
            int cn = 0;
            excon: {
                if (this.lex.gmet("~{")){      // constr-not
                    cn = ParserNode.C_NOT;
                    break excon;
                }
                if (this.lex.gmet("={")){      // constr-equ
                    cn = ParserNode.C_EQU;
                    break excon;
                }
                if (this.lex.gmet("-{")){      // constr-diff
                    cn = ParserNode.C_DIFF;
                    break excon;
                }
                if (this.lex.gmet(":{")){      // constr-succ
                    cn = ParserNode.C_SUCC;
                    break excon;
                }
                if (this.lex.gmet("#{")){      // constr-term
                    cn = ParserNode.C_TERM;
                    break excon;
                }
                break cons;
            } // excon;
            long point = this.lex.getPoint();
            ParserNode q, r;
            ParserNode sav = this.curNode;
            try {
                expression(null);
            } finally {
                q = this.curNode;
                this.curNode = sav;
            }
            if (this.lex.gmet("}*")){
                r = newNode(ParserNode.G_RE0);
                r.gnode = q;
                q = r;
            } else if (this.lex.gmet("}+")){
                r = newNode(ParserNode.G_RE1);
                r.gnode = q;
                q = r;
            } else if (!this.lex.gmet("}")){
                this.lex.message(ParserLexer.ERR_MISTOK,"}");
                throw this.lex.excObj;
            }
            p.add_constr(cn,q,point);          // add to constraints list
        } // cons;
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("end factor");
            if (this.curNode != null) this.curNode.trcNode();
        }
    }

    /**
     * Create the equivalent rule for a group.
     *
     * @param      nt0 reference to the dictionary entry of the group
     * @param      lo lower bound, -1 if undefined
     * @param      hi upper bound, -1 if undefined
     * @param      point point in the source grammar
     */

    private void createGroup(ParserDic nt0, int lo, int hi, long point){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("lo: " + lo + " hi: " + hi);
        }
        doit: {
            ParserNode c;
            ParserDic nt1;
            if (hi == 1){
                if (lo == 1){
                    nt0.grKind = ParserTables.GRO;
                    break doit;                     // {alpha}(1): simple group
                }
                if (lo == 0){                       // {alpha}(0:1): optional group
                    nt1 = addDic(this.ntDic,null,point,0);  // create &1 ::= alpha
                    nt1.def = nt0.def;
                    nt1.grKind = ParserTables.BOO;
                    c = new ParserNode(
                        ParserNode.S_NT,point,nt1); // &1 | e
                    c.alt = new ParserNode(
                        ParserNode.S_TER,point,this.dic_emp);
                    nt0.def = c;                    // &0 = &1 | e
                    nt0.status &= ~ParserNode.G_GRP;
                    nt0.status |= ParserNode.G_OPT;
                    nt0.grKind = ParserTables.OPT;
                    break doit;
                }
            }
            nt0.status &= ~ParserNode.G_GRP;
            ParserNode cur = null;
            nt1 = addDic(this.ntDic,null,point,0);  // create &1 ::= alpha
            nt1.def = nt0.def;
            nt1.grKind = ParserTables.BOD;
            nt0.def = null;
            for (int i = 0; i < lo; i++){           // &1 ... &1 lo times
                ParserNode n =
                    new ParserNode(ParserNode.S_NT,point,nt1);
                if (nt0.def == null){
                    nt0.def = n;
                } else {
                    cur.suc = n;
                }
                cur = n;
            }
            if ((lo == 0) && (hi < 1)){                // {alpha}(0:)
                c = new ParserNode(ParserNode.S_TER,   // e | &1 &0
                    point,this.dic_emp);
                if ((ParserTables.LEFTGROUPS & mode) == 0){    // right-recursive
                    c.alt = new ParserNode(
                        ParserNode.S_NT,point,nt1);
                    c.alt.suc = new ParserNode(
                        ParserNode.S_NT,point,nt0);
                } else {                               // left-recursive
                    c.alt = new ParserNode(
                        ParserNode.S_NT,point,nt0);
                    c.alt.suc = new ParserNode(
                        ParserNode.S_NT,point,nt1);
                    nt0.status |= ParserNode.LEFT_RECUR;
                }
                nt0.def = c;
                nt0.status |= ParserNode.G_RE0;
                nt0.grKind = ParserTables.RES;
            } else if (hi < 0){                                // {alpha}(l:)
                if ((ParserTables.LEFTGROUPS & mode) == 0){    // right-recursive
                    c = new ParserNode(ParserNode.S_NT, // &1 &0
                        point,nt1);                     // first alt created above
                    c.suc = new ParserNode(ParserNode.S_NT,
                        point,nt0);
                } else {                                // left-recursive
                    c = new ParserNode(ParserNode.S_NT, // &0 &1
                        point,nt0);                     // first alt created above
                    c.suc = new ParserNode(ParserNode.S_NT,
                        point,nt1);
                    nt0.status |= ParserNode.LEFT_RECUR;
                }
                nt0.def.alt = c;
                nt0.status |= ParserNode.G_RE1;
                if (lo == 1){
                    nt0.grKind = ParserTables.REP;      // {alpha}+
                } else {
                    nt0.grKind = ParserTables.REL;      // {alpha}(l:)
                }
            } else if (hi > lo){                        // (l:u), (:u)
                ParserDic nt2 = addDic(                 // create &2
                    this.ntDic,null,point,0);
                    nt2.grKind = ParserTables.OBO;
                    c = new ParserNode(
                        ParserNode.S_TER,point,this.dic_emp);
                    c.alt = new ParserNode(
                        ParserNode.S_NT,point,nt1);     // &2 ::= e | &1
                nt2.def = c;
                for (int i = lo; i < hi; i++){          // &2 ... &2
                    c = new ParserNode(ParserNode.S_NT,point,nt2);
                    if (nt0.def == null){
                        nt0.def = c;
                    } else {
                        cur.suc = c;
                    }
                    cur = c;
                }
                if (lo == 0){
                    nt0.status |= ParserNode.G_RE0; // {alpha}(:u)
                    nt0.grKind = ParserTables.REU;
                } else {
                    nt0.status |= ParserNode.G_RE1; // {alpha}(l:u)
                    nt0.grKind = ParserTables.RER;
                }
            } else {
                nt0.status |= ParserNode.G_RE1;     // {alpha}(l)
                nt0.grKind = ParserTables.REF;
            }
        } // doit
        if ((FL_A & this.trc) != 0){
            String s = "";
            switch (ParserNode.G_GRP & nt0.status){
            case ParserNode.G_GRO: s = "gro"; break;
            case ParserNode.G_OPT: s = "opt"; break;
            case ParserNode.G_RE0: s = "re0"; break;
            case ParserNode.G_RE1: s = "re1"; break;
            }
            Trc.out.println(s);
        }
    }
    /**
     * Get a case-insensitive directive.
     *
     * @return     attribute which indicates the case-insensitive kind
     */

    private int caseinsens(){
        int att = 0;
        doit: {
            if (!this.lex.gmet("(")){
                break doit;
            }
            if (this.lex.gkey("i")){
                att = ParserNode.CASEINSENS;       // case insensitive
            } else if (this.lex.gkey("f")){
                att = ParserNode.CASEINSENS_FULL;  // full case insensitive
            } else {
                this.lex.backup(1);             // go back one lexeme
                break doit;
            }
            if (!this.lex.gmet(")")){
                this.lex.message(ParserLexer.ERR_MISTOK,")");
                throw this.lex.excObj;
            }
        } // doit
        return att;
    }

    /**
     * Test if an element is equal to the empty string notation.
     *
     * @param      str string of the element
     * @param      k kind of the element
     * @return     <code>true</code> if found
     */

    /* When processing the grammar, it would be efficient to store
     * that notation into a dictionary so as not to compare the strings
     * each time a terminal and nonterminal had to be tested.
     * However, that does not work when processing shorthands or
     * replacements, and thus each terminal or nonterminal is checked
     * againts the string of the empty string notation.
     */

    private boolean isTheEmpty(Str s, int k){
        if ((k == ParserDic.TER) && (s.length == 0)) return true;
        if (this.dic_usrEmp == null) return false;
        if (this.dic_usrEmp.kind != k) return false;
        if (this.dic_usrEmp.code.length != s.length) return false;
        for (int i = 0; i < s.length; i++){
            if (this.dic_usrEmp.code[i] != s.buffer[i]) return false;
        }
        return true;
    }

    /**
     * Get a terminal element, which can be a symbol other than a metasymbol, or a string.
     *
     * @param      s string in which the token is returned
     * @return     0 if not found, 1 if an ordinary one found, 2 if a special
     *             non terminal found.
     */

    private int lex_gter(Str s){
        if (this.lex.gjstr(s)){         // string
            return 1;
        }
        return this.lex.gnme(s);        // non meta
    }

    /**
     * Skip input past an end of production. Note that it recognizes
     * a "." not inside a string and a "::=", "==" and "=>".
     * Resynch detects always the three rule separators independently
     * on whether it is called in the grammar or in the lexis because
     * such separators may not occur in rules anyway.
     *
     * @param      kind <code>true</code> to advance one token anyway
     *             <code>false</code> to position to the start of the
     *             next rule (possibly skipping no token)
     */

    /* When it is called at the start of a malformed rule like e.g. a ::= b,
     * it must advance (otherwise an endless loop occurs), while when called
     * after it it advances if it is not yet at the beginning of a rule.
     * LEXIS is detected as stopper only in the grammar, not in the lexis,
     * otherwise it would make anLexis enter an endless loop if LEXIS
     * appears in the lexicon.
     */

    private void resynch(boolean adv){
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("resynch start " + adv);
        }
        if (this.lex.eof()) return;               // do not register a message
        int n = 0;
        do {
            if ((FL_A & this.trc) != 0){
                Trc.out.println("resynch loop " +
                    this.lex.index() + " " + n);
            }
            if (this.lex.gkey("END")){
                this.lex.backup(1);
                break;
            } else if (this.in_grammar &&         // in grammar
                this.lex.gkey("LEXIS")){
                this.lex.backup(1);
                break;
            } else if (this.lex.gntr(this.symb)){
                n++;
            } else if (this.lex.gjstr(this.symb)){
                n++;
            } else if ((this.lex.gmet("::=")) ||  // ::= present
                (this.lex.gmet("=>")) ||          // => present
                (this.lex.gmet("=="))){           // == present
                n++;
                if (n > (adv ? 2 : 1)){
                    this.lex.backup(2);
                    n -= 2;
                    break;
                }
            } else if (this.lex.gnme(this.symb) > 0){
                n++;
            } else if (this.lex.gidj(this.symb)){
                n++;
            } else {                              // none, advance
                if (!this.lex.skipch()) break;
                n++;
            }
        } while (!this.lex.eof());
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("resynch end " + n + " " +
                this.lex.index());
        }
        if (n > 0){
            this.lex.message(ParserLexer.ERR_SKIP,null,this.lex.index());
        }
        return;
    }

    /**
     * Report all nonterminals that have no binding.
     */

    private void report_undef(){
        ParserDic h = this.ntDic.head;           // check all nt be defined
        while (h != null){
            if (h.def == null){                  // not defined
                this.lex.message(
                    ParserLexer.ERR_UNDEF,"",h.point);
            }
            h = h.suc;
        }
    }

    /**
     * Report duplicated productions.
     */

    private void ck_duplProd(){
        ParserError m = this.lex.excLast;
        for (ParserDic h = this.ntDic.head; h != null; h = h.suc){
            if (h.def != null){
                ck_duplAlt(h.def,m);
            }
        }
    }

    /**
     * Report duplicated alternatives. Do not report twice the same
     * error.
     *
     * @param      p reference to the rule
     * @param      m reference to the list of messages
     */

    /* A rule <A> ::= b | {b} is accepted because the check is that no two
     * alternatives must be identical. It would be impossible to detect
     * that they may not produce the same strings.
     */

    private void ck_duplAlt(ParserNode p, ParserError m){
        if ((FL_T & this.trc) != 0){
            Trc.out.println("ck_duplAlt " + p + " " + p.point);
        }
        for (ParserNode a = p; a != null; a = a.alt){  // scan all alternatives
            for (ParserNode b = p; b != a; b = b.alt){
                if ((FL_T & this.trc) != 0){
                    Trc.out.println(a + " " + a.point + " =? "
                        + b + " " + b.point);
                }
                if (a.equalAlt(b)){
                    if ((FL_T & this.trc) != 0){
                        Trc.out.println("==");
                    }
                    this.lex.messageNoDup(
                        ParserLexer.ERR_DUPPROD,null,a.point,m);
                }
                if ((ParserNode.S_RNG & b.oper) != 0){   // range
                    b = b.alt;
                }
            }
            for (ParserNode s = a; s != null; s = s.suc){   // scan all successors
                for (ParserNode csp = s.constr; csp != null; csp = csp.suc){
                    ck_duplAlt(csp.gnode,m);
                }
            }
            if ((ParserNode.S_RNG & a.oper) != 0){       // range
                a = a.alt;
                if (a == null) break;
            }
        }
    }

    /**
     * Construct a new node and stores the position in the input in it.
     *
     * @param      k kind of node
     */

    private ParserNode newNode(int k){
        ParserNode p = newNode(k,this.lex.getPoint());
        return p;
    }

    /**
     * Add a new dictionary entry if not present and store the position
     * in the input in it.
     *
     * @see        #addDic(ParserGrammar.HashDic,Str,int,long,long)
     */

    private ParserDic addDic(HashDic d, Str s, int k){
        return addDic(d,s,k,this.lex.getPoint(),
            this.lex.getLineNr());
    }

    /**
     * Add a new dictionary nonterminal entry if not present and store
     * the position in the input in it.
     *
     * @see        #addDic(ParserGrammar.HashDic,Str,int,long,long)
     */

    private ParserDic addDic(HashDic d, Str s){
        if ((FL_D & this.trc) != 0){
            Trc.out.println("adding: " + s);
        }
        return addDic(d,s,ParserDic.NTER);
    }

    /* The analysis of the grammar. */

    /** 
     * Report the irrelevant nonterminals. See the description of the
     * algorithm which determines them.
     * The message ERR_NOGEN is not reported on internal nonterminals
     * because they denote groups, and such a message is meaningful only
     * on nonterminals which appear explicitly in grammars.
     */

    private void show_irr(){
        ParserError m = this.lex.excLast;
        ParserDic h = this.ntDic.head;                    // scan them again
        for (; h != null; h = h.suc){
            if ((ParserNode.ST & h.status) == 0){
                if ((ParserNode.INTER & h.status) == 0){  // not in a group
if ((FL_X & this.trc) != 0){
Trc.out.printf("??? --- %s %s\n",h,System.identityHashCode(h));
}
                    this.lex.messageNoDup(                // underivable
                        ParserLexer.ERR_NOGEN,"",h.point,m);
                }
            }
            if ((ParserNode.INTER & h.status) != 0){      // internal
                if ((ParserNode.G_GRP & h.status) == 0){  // second of group
                    continue;
                }
            }
            if ((ParserNode.LXS &                             // non-regular
                h.status) != 0){                              // .. in lexis:
                if ((ParserNode.TY2 & h.status) != 0){        // .. TR not set
                    continue;
                }
            }
            ParserNode a = h.def;
            if ((ParserNode.TR & h.status) == 0){
                if ((ParserNode.LEXEME & h.status) != 0){     // EMPLEX instead
                    continue;
                }
                if (h.def != null){                           // not undefined
                    if ((ParserNode.G_GRP & h.status) ==      // group
                        ParserNode.G_GRO){
                        if (h.body().alt == null) continue;   // single alt
                    }
                    if ((ParserNode.G_GRP & h.status) ==      // re1 group
                        ParserNode.G_RE1){
                        if (h.body().alt == null) continue;   // single alt
                    }
                    this.lex.messageNoDup(                    // dead end
                        ParserLexer.ERR_DEADEND,null,h.point,m);
                }
            } else {
                op: if ((ParserNode.G_GRP & h.status) ==      // opt group
                    ParserNode.G_OPT){
                    a = h.body();
                    int n = 0;
                    for (ParserNode l = h.body(); l != null;
                        l = l.alt){
                        if ((l.def != null) &&
                            (l.def.code.length != 0)) n++;
                        if (n > 1) break op;
                    }
                    continue;
                }
                if ((ParserNode.G_GRP & h.status) ==          // re0 group
                    ParserNode.G_RE0){
                    a = h.body();
                    if (a.alt == null) continue;              // single alt
                }
                if ((ParserNode.G_GRP & h.status) ==          // re1 group
                    ParserNode.G_RE1){
                    a = h.body();
                }
                for (; a != null; a = a.alt){                 // scan all alternatives
                    if ((ParserNode.TR & a.status) == 0){
                        this.lex.messageNoDup(                // dead end
                            ParserLexer.ERR_DEADALT,null,a.point,m);
                    }
                }
            }
        }
    }

    /** 
     * Analyze the lexicon and build the lists of shorthands
     * and replacements.
     */

    /* Multiple definitions of shorthands or replacements are rejected
     * because they are likely to be errors.  This is different from
     * productions in which that is supported to accept grammars which
     * appears in books on languages.
     *
     * It checks that the LHS of shorthands and replacements is not
     * the empty string notation.
     */

    private void anLexis(){
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("start anLexis");
        }
        try {
            ntr_list(true);                          // list of lexemes
        } finally {
            this.lxi_list = this.curNode;
        }
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("anLexis after list");
        }
        if ((FL_X & this.trc) != 0){
            Trc.out.println("lexemes list");
            if (this.lxi_list != null){
                this.lxi_list.trace_exp();
            }
            Trc.out.println();
        }
        // check ignore elements
        int nigno = 0;
        for (ParserNode a = this.lxi_list; a != null; a = a.alt){
            if ((ParserNode.LEX_IGNORE & a.attr) != 0){
                ParserDic nt = this.ntDic.search(a.def);
                if (nigno == 0){
                    this.ignore = nt;
                } else {
                    this.lex.message(ParserLexer.ERR_MULDEF);
                    throw this.lex.excObj;
                }
                nigno++;
            }
        }

        ParserDic h;
        this.in_grammar = false;                     // rules terminated by next
                                                     // == or => now
        l: for (;;){
            if ((FL_A & this.trc) != 0){
                this.lex.trcBuffer("anLexis loop");
            }
            if (this.lex.eof()) break l;
            if (this.lex.gkey("END")){               // end lexis
                this.lex.backup(1);                  // go back one lexeme
                break l;
            }
            if (this.lex.gkey("PRECEDENCE")){        // precedence and associativity
                this.lex.backup(1);                  // go back one lexeme
                break l;
            }
            if (this.lex.gkey("OPTIONS")){           // options
                this.lex.backup(1);                  // go back one lexeme
                break l;
            }
            if (this.lex.gkey("ALPHABET")){          // alphabet declaration
                boolean found = false;
                try {
                    found = expression(null);        // get expression
                } catch (ParserError exc){
                    resynch(false);
                    break l;
                } finally {
                    if (found){
                        this.alphaRule = this.curNode;   // store it
                    }
                }
                this.lex.gmet(".");                  // optional end production
                if (!found){
                    this.lex.message(ParserLexer.ERR_MISFAC);
                    break l;
                }
                if ((FL_A & this.trc) != 0){
                    Trc.out.print("alphabet: ");
                    if (this.alphaRule != null){
                        this.alphaRule.trace_exp();
                        Trc.out.println();
                    }
                }
                if (this.lex.gkey("END")) break l;   // end lexis
                break l;
            }
            pd: {
                int k;
                k = lex_nt();                        // get lexeme
                if (isTheEmpty(this.symb,k)){        // empty string
                    this.lex.message(ParserLexer.ERR_NOTALL);
                    k = -2;
                    resynch(true);
                    break pd;
                }
                if (k < -1){                         // error
                    this.lex.message(ParserLexer.ERR_MISEL);
                    resynch(true);
                    break pd;
                }
                long point = this.lex.getPoint();
                long line = this.lex.getLineNr();
                if ((k == ParserDic.NTER) &&
                    (this.lex.gmet("=="))){          // shorthand
                    h = addDic(this.shoDic,
                        this.symb,point,line);       // find definition
                    if (h.def != null){              // duplicated definition
                        this.lex.message(
                            ParserLexer.ERR_MULDEF,"",point);
                    } else {
                        h.point = point;
                        h.line = line;
                    }

                    try {
                        ntr_list(false);             // definition
                    } finally {
                        ParserNode p = this.curNode;
                        if (p != null){
                            h.def = p;
                        } else {                     // create an empty one
                            h.def = newNode(ParserNode.S_TER);
                            h.def.def = this.dic_emp;
                        }
                        if ((FL_X & this.trc) != 0){
                            Trc.out.print(h + " == ");
                            if (h.def != null) h.def.trace_exp();
                            Trc.out.println();
                        }
                    }
                    break pd;
                }
                if (!this.lex.gmet("=>")){           // => not found
                    this.lex.message(
                        ParserLexer.ERR_MISTOK,"=>");
                    resynch(false);
                    break pd;
                }
                h = addDic(this.repDic,this.symb,k,  // find definition
                    point,line);
                h.status &= ~(ParserNode.MRK | ParserNode.TR |
                    ParserNode.ST | ParserNode.EO | ParserNode.EM);
                if (h.def != null){                  // duplicated definition
                    this.lex.message(
                        ParserLexer.ERR_MULDEF,"",point);
                } else {
                    h.point = point;                 // set its def. point
                    h.line = line;
                    if (k != ParserDic.NTER){
                        if (k == ParserDic.TER){     // terminal LHS
                            h.org = addDic(this.terDic,
                                this.symb,ParserDic.TER,
                                point,line);
                        } else {                     // TERMINALS
                            h.org = this.dic_ter;    // bind it
                        }
                    }
                }
                this.defnt = h;
                HashDic save = this.ntDic;           // put replacements in repDic
                this.ntDic = this.repDic;            // .. including groups
                try {
                    expression(null);
                } catch (ParserError exc){
                    resynch(false);
                    break pd;                        // done after finally body
                } finally {
                    h.def = this.curNode;
                    this.ntDic = save;               // restore it
                }
                this.lex.gmet(".");                  // optional end production
                if ((FL_A & this.trc) != 0){
                    Trc.out.print(h + " => ");
                    h.def.trace_exp();
                    Trc.out.println();
                }
            }// pd;
            if (this.lex.fatcnt > 0) break l;
        } // l;
        if ((FL_B & this.trc) != 0){
            this.lex.trcBuffer("end anLexis");
        }
    }

    /** 
     * Get a list of lexemes. Nonterminals are all inserted in shoDic.
     * Return the head of the list in <code>curNode</code> so as to
     * allow callers to catch exceptions and store the list which has
     * been built so far.
     *
     * @param      ter <code>true</code> to accept TERMINALS
     */

    private void ntr_list(boolean ter){
        ParserNode q, r;
        ParserDic  h;

        this.curNode = null;
        boolean none = true;
        r = null;
        boolean nobar = false;
        l: for (;;){
            elem: {
                int k = lex_nt();                       // get lexeme
                long point = this.lex.getPoint();
                long line = this.lex.getLineNr();
                doit: if (k >= 0){
                    boolean del = false;
                    try {
                        del = this.lex.gmet("=>");      // => present
                        if (!del && (k == ParserDic.NTER)){
                            del = this.lex.gmet("==");  // == present
                        }
                    } catch (ParserError exc){          // store anyway
                    }
                    if (del){                           // delimiter
                        this.lex.backup(2);             // go back two lexemes
                        break l;
                    }
                    if (isTheEmpty(this.symb,k)){       // empty string
                        this.lex.message(
                            ParserLexer.ERR_NOTALL,"",point);
                        if (this.lex.fatcnt > 0){
                            throw this.lex.excObj;
                        }
                        none = false;
                        break elem;
                    }
                }
                if (k == ParserDic.NTER){               // non terminal
                    h = addDic(this.shoDic,this.symb,
                        point,line);
                    h.use++;
                    q = newNode(ParserNode.S_NT,point);
                    q.def = h;
                } else if (k > 0){                      // terminal or TERMINALS
                    q = newNode(ParserNode.S_TER,point);
                    if (k == ParserDic.TER){
                        h = addDic(this.terDic,         // add it
                            this.symb,ParserDic.TER,
                            point,line);
                        h.use++;
                    } else {                            // TERMINALS
                        if (!ter){
                            this.lex.message(
                                ParserLexer.ERR_TRMERR,"",point);
                            if (this.lex.fatcnt > 0){
                                throw this.lex.excObj;
                            }
                            none = false;
                            break elem;
                        }
                        h = this.dic_ter;
                    }
                    q.def = h;
                } else {
                    break l;
                }
                for (ParserNode a = this.curNode;
                    a != null; a = a.alt){
                    if ((a.kind == q.kind) &&
                        (a.def == q.def)){
                        this.lex.message(               // already in the list
                            ParserLexer.ERR_MULOCC,"",point);
                        break elem;
                    }
                }
                if ((FL_A & this.trc) != 0){
                    Trc.out.println("ntr_list " + q + " " + r);
                }
                if (this.curNode == null){
                    this.curNode = q;
                }
                q.attr |= storage(true,ter);            // get storage directive
                if (r != null) r.alt = q;               // link previous
                r = q;
                if (this.lex.fatcnt > 0) throw this.lex.excObj;
            } // elem
            if (this.lex.gmet(".")){
                nobar = true;
                break l;
            }
            if (!this.lex.gmet("|")){
                nobar = true;
                break l;
            }
        } // l
        if (!nobar && (this.curNode != null)){          // | not followed by element
            this.lex.message(ParserLexer.ERR_MISEL);
            resynch(false);
        }
        if (!ter && (this.curNode == null) && none){
            this.lex.message(ParserLexer.ERR_MISNT);    // empty definition
        }
    }

    /** 
     * Get a nonterminal, a terminal or TERMINALS.
     *
     * @return     kind of element, -1 if not found
     */

    private int lex_nt(){
        int k = -1;
        if (this.lex.gntr(this.symb)){           // non terminal
            k = ParserDic.NTER;
        } else if (this.lex.gjstr(this.symb)){   // string
            k = ParserDic.TER;
        } else if (this.lex.gkey("TERMINALS")){  // special
            k = ParserDic.TER_SPE;
            this.symb.assign(dic_ter.code);
        } else {
            int t = this.lex.gnme(this.symb);
            if (t > 0){                          // non meta
                if (t == 1) k = ParserDic.TER;
                else k = ParserDic.TER_SPE;
            } else {
                k = -1;
            }
        }
        if ((FL_A & this.trc) != 0){
            Trc.out.println("lex_nt ret " + k + " " + this.symb);
        }
        return k;
    }

    /**
     * Parse a storage directive, and return the settings in it.
     *
     * @param      mand <code>TRUE</code> to return an error if an open
     *             parenthesis is specified, but not followed by the rest
     *             of the directive
     * @param      igno <code>TRUE</code> to parse an ignore attribute
     * @return     node attributes of the directive
     */

    private int storage(boolean mand, boolean igno){
        int lexm = 0;
        int pnt = 0;
        doit: {
            if (!this.lex.gmet("(")){
                break doit;
            }
            if (igno){
                if (this.lex.gkey("ignore")){       // ignore specified
                    if (!this.lex.gmet(")")){
                        this.lex.message(ParserLexer.ERR_MISTOK,")");
                        throw this.lex.excObj;
                    }
                    lexm = ParserNode.LEX_IGNORE;
                    break doit;
                }
            }
            boolean minus = this.lex.gdel('-');
            if (this.lex.gkey("lex")){          // lex specified
                lexm = minus ?
                    ParserNode.LEX_STR_NOSTORE :
                    ParserNode.LEX_STR_STORE;
            } else if (this.lex.gkey("point")){ // point specified
                pnt = minus ?
                    ParserNode.LEX_POINT_NOSTORE :
                    ParserNode.LEX_POINT_STORE;
            } else if (minus || mand){
                this.lex.message(ParserLexer.ERR_MISKEY);
                throw this.lex.excObj;
            } else {
                this.lex.backup(1);             // go back one lexeme
                break doit;
            }
            sec: if (this.lex.gdel(',')){       // , specified
                minus = this.lex.gdel('-');
                if (lexm != 0){
                    if (this.lex.gkey("point")){
                        pnt = minus ?
                            ParserNode.LEX_POINT_NOSTORE :
                            ParserNode.LEX_POINT_STORE;
                        break sec;
                    }
                } else {
                    if (this.lex.gkey("lex")){
                        lexm = minus ?
                            ParserNode.LEX_STR_NOSTORE :
                            ParserNode.LEX_STR_STORE;
                        break sec;
                    }
                }
                this.lex.message(ParserLexer.ERR_MISKEY);
                throw this.lex.excObj;
            }
            if (!this.lex.gmet(")")){
                this.lex.message(ParserLexer.ERR_MISTOK,")");
                throw this.lex.excObj;
            }
        } // doit
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("storage " + lexm + " " + pnt);
        }
        return lexm | pnt;
    }

    /**
     * Analyze the options declaration.
     */

    private void anOptions(){
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("start anOptions");
        }
        for (;;){
            if ((FL_A & this.trc) != 0){
                this.lex.trcBuffer("anOptions loop");
            }
            if (this.lex.eof()) break;
            if (!this.lex.gjstr(this.symb)){
                this.lex.message(ParserLexer.ERR_MISEL);
                throw this.lex.excObj;
            }
            // check the option
            String opt = this.symb.toString();
            if (Lexer.searchKey(OPTTABLE,0,
                OPTTABLE.length,this.symb,false) < 0){
                this.lex.message(ParserLexer.ERR_ILLDEF);
                throw this.lex.excObj;
            }
            // store the option
            if (this.options == null){
                this.options = new String[1];
            } else {
                for (int i = 0; i < this.options.length; i++){
                    if (opt.equals(this.options[i])){
                        this.lex.message(ParserLexer.ERR_MULDEF);
                        throw this.lex.excObj;
                    }
                }
                this.options = Arrays.copyOf(this.options,this.options.length+1);
            }
            this.options[this.options.length-1] = opt;
            if (!this.lex.gdel(',')){
                break;
            }
        }
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("end anOptions");
        }
    }

    /** The table of options. */
    String[] options;

    /** The table of the allowed options. */
    static final String[] OPTTABLE = {
        "-tokenSets",
    };
    static {
        Arrays.sort(OPTTABLE);
    }

    /**
     * Analyze the precedence declarations.
     */

    private void anPrecedence(){
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("start anPrecedence");
        }
        Str term = new Str();
        Precedence tail = null;
        l: for (;;){
            if ((FL_A & this.trc) != 0){
                this.lex.trcBuffer("anPrecedence loop");
            }
            if (this.lex.eof()) break l;
            if (this.lex.gkey("SHIFT")){             // default in favour of shift
                this.precAssocDefault = 1;
            } else if (this.lex.gkey("REDUCE")){     // default in favour of reduce
                this.precAssocDefault = 2;
            }
            if (this.lex.gkey("END")){               // end precedences
                this.lex.backup(1);                  // go back one lexeme
                break l;
            }
            long point = this.lex.getPoint();
            if (lex_gter(term) != 1){
                this.lex.message(ParserLexer.ERR_MISTER);
                break l;
            }
            int kind = 0;
            if (this.lex.gkey("LEFT")){
                kind = 1;
            } else if (this.lex.gkey("RIGHT")){
                kind = 2;
            } else if (this.lex.gkey("NONASSOC")){
                kind = 3;
            }
            int prio = 0;
            if (this.lex.gdec(this.symb)){           // priority number
                prio = (int)this.lex.integral;
            }
            Precedence elem = new Precedence();
            elem.term = term.toString();
            elem.kind = kind;
            elem.prio = prio;
            elem.pos = point;
            if (this.precAssoc == null){
                this.precAssoc = elem;
            } else {
                tail.next = elem;
            } 
            tail = elem;
        } // l           
        if ((FL_B & this.trc) != 0){
            Trc.out.printf("precedences\n");
            for (Precedence i = this.precAssoc; i != null; i = i.next){
                Trc.out.printf("term %s kind %d prio %d\n",i.term,i.kind,i.prio);
            }
        }
        if ((FL_A & this.trc) != 0){
            this.lex.trcBuffer("end anPrecedence");
        }
    }

    /** The elements of the table of precedences. */
    static class Precedence{
        Precedence next;
        String term;
        int kind;        // 0: none, 1: left, 2: right, 3: nonassoc
        int prio;
        long pos;
    }

    /** The table of precedences. */
    Precedence precAssoc;

    /** The default resolution (0: none, 1: shift, 2: reduce). */
    int precAssocDefault;

    /**
     * Deliver a reference to the parsing tables.
     *
     * @return     reference to the parsing tables
     */

    public ParserTables getTables(){
        if (this.lexer == null) return null;
        return this.lexer.aut;
    }

    /**
     * Tell if the analysis of the grammar ended successfully.
     *
     * @return     <code>true</code> if successful, <code>false</code>
     *             otherwise
     */

    public boolean error(){
        return (this.lex.fatcnt != 0) ||            // fatals
            (this.lex.errcnt != 0);                 // errors
    }

    /**
     * Parse the specified text.
     *
     * @param      text text to parse
     * @return     <code>true</code> if successful, <code>false</code>
     *             otherwise
     */

/*
    public boolean parse(Object text){
        if ((this.lex.fatcnt != 0) ||                // fatals
            (this.lex.errcnt != 0)){                 // errors
            return false;
        }
        ParserEngine eng = (ParserEngine)this;
        eng.tab = this.lexer.aut;
        eng.lex = new ParserLex(tab,text);
        eng.trc = this.trc;
        if (eng.parse()) return true;
        this.lex.errcnt++;
        return false;
    }
*/
}
