/*
 * @(#)Failure.java       1.0 99/02/19
 *
 * Copyright (c) 1998-1999 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;

/**
 * The <code>Failure</code> class provides a means for representing
 * exceptional conditions.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

/**
 * An error. It indicates the violation of a checked condition which has been
 * encountered during the execution due either to some external cause or to a
 * programming error which can cause the violation of some checked condition.
 * The user must be told what went wrong and where.
 * There are operations (performed by methods) that are quite long, and that
 * can detect the violation of many conditions. In this case it could be more
 * useful for the caller to know all the violations. E.g. a compiler should report
 * as many errors as possible, and not just quit at the first one.
 * In this case a list of errors should be returned to the user.
 * <p>
 * Error returning:
 * <p>
 * Several methods in several classes need to return errors due to the
 * violation of some conditions on arguments or on the object status.
 * There are a number of means of doing it:
 * <ul>
 * <li>returning a value: represent the error condition as some special
 *   value that is returned (e.g. a null pointer). This is the easiest
 *   and cheapest solution, and the one to be used for methods that return
 *   only one error, of one kind only and that needs no extra data to
 *   detail it. It is not possible to forget to return a value on methods
 *   that declare a return value. Moreover, callers can store the returned
 *   value, test it, etc.: maximum flexibility is provided.
 *   Reserving a value to denote an error condition is not difficult.
 * <li>returning an exception: methods declare the returned exception.
 *   Exceptions have pros and cons:
 *   <ul>
 *   <li>exceptions force normally a transfer of control to a handler.
 *     Many times there is a need to perform some action after a call,
 *     be it successful or otherwise, and then to do something if an
 *     an error occurred. This should be done by enclosing it in a try
 *     block:
 *     <pre>
 *         try {
 *              try { call();} finally {
 *                  after-call-action
 *              }
 *              handle normal case
 *         } catch (exception){
 *              handle exception
 *         }
 *     </pre>
 *     This executes the after-call-action and throws an exception if one
 *     occurs in the called method.
 *   <li>unfortunately there is no language construct that allows to
 *     return an error condition that can be tested and need not be cleared.
 *   <li>there is no need to clear anything upon entry
 *   <li>there is no way to forget to treat errors
 *   </ul>
 *   If it is too cumbersome to force callers to pass exceptions all the
 *   way up the callers, exceptions can be declared as inheriting Failure.
 * <li>return an exception object. Since several methods would need to
 *   return some value too, the reference to the exception object must be
 *   returned in some global field. However, this is tedious and prone
 *   to errors:
 *   <ul>
 *   <li>there is a need in all methods that can return an error to clear
 *     it at the beginning
 *   <li>the methods that may not go wrong should clear it all the same,
 *     or leave it unchanged (except for some that play with errors)
 *   <li>when a higher method calls inner methods that clear it, the last
 *     one called would determine what the higher methods returns, unless
 *     the higher one remembers that an error occurred (note that the
 *     higher one might decide to proceed when it encounters and error
 *     so as to detect others, and at the end report the last one, or one
 *     anyway).
 *   </ul>
 * </ul>
 * The technique to use to report errors to callers depend on the data that
 * must be returned. Clearly, if a simple boolean presence of an error is
 * needed, a return value is sufficient. If there is a need to return more
 * data, an error object can be used (possibly an exception object).
 * If there is a need to return several errors as violations of several
 * conditions, a list of objects is needed.
 * In conclusion, use the minimal error reporting that is needed. If you
 * can do it by returning an error value, do it. Otherwise throw exceptions,
 * or as a last resort return an error object in a global field.
 * Failures are used in the second and third solutions.
 * <p>
 * Failures are exceptions, i.e. means for a subsystem to report faults to
 * callers.
 * <p>
 * Various subsystems make subclasses of this one, in which they redefine
 * the <code>getMessage()</code> method to deliver a specialized error
 * message containing all the additional information which is appropriate
 * to make messages revealing. This allows to print errors without knowing
 * their internal structure. The message should be localised.
 * A subsystem can return failures of different subclasses. This is to say
 * that it can return several exceptions. Each of them has its own error
 * code in it. This relives from a system-wide numbering of errors.
 * Callers that need to test for specific errors should catch the appropriate
 * exception first (or test for it), and then test the error code.
 * This relieves also subsystems for wrapping always inner failures into
 * one of theirs so as to return only one subclass of failures.
 * <p>
 * Failures could be linked: when a subsystem detects a failure in an
 * operation which it requested to another subsystem, it can create a
 * new Failure in which it provides its own data and explanation of the
 * failure, and link the inner one. When failures are printed, the list
 * is traversed. Each failure indicates the subsystem which originated it.
 * Note that an application, upon detecting a failure, should print a
 * meaningful message in which the application name is shown, telling
 * the reason of the failure as close as possible to what the user requested,
 * and then print the list of inner failures.
 * <p>
 * It is usually a good structuring technique to let each subsystem (large
 * class or set of tightly coupled classes) have its own errors.
 * In so doing, they are not mixed with the ones of other subsystems, which
 * makes clear what errors may occur in it.
 * Moreover, having a dedicated bundles avoid mixing messages which have
 * nothing to do each other.
 * <p>
 * Failues should indicate 1. what went wrong, and 2. in doing what, and
 * 3. on what (object, value, etc.).
 * A method can call several others, and each of them several times.
 * To make clear a failure, there is a need for a method to catch
 * exceptions and to add some data tellig what it was doing at that time.
 * I.e. it is useless to re-state exceptions.
 * The rule of thumb is that if a subsystem does something simple, for
 * which an error coming from an inner subsystem is revealing enough,
 * there is no need to stack an obvious error on top of the other,
 * while there is a need for it when it conveys information which is necessary
 * for the understanding of the overall failure.
 * E.g. when only one subclass is returned by the methods called in it (i.e.
 * the called method wraps errors), and that is sufficient to circumstantiate
 * the error, the caller should not wrap it, otherwise it should.
 * For a subsystem there is a need to design failures by deciding what
 * data are needed to circumstantiate them. E.g. when parsing, the position
 * in the text could be sufficient. The data which are common to all the
 * failures of a subsystem should be recorded into a Failure object by
 * a registerError method by default, leaving to each call the passing of
 * additional data which are specific for that call. Failure classes can also
 * be inner classes, in which case the data which can be taken from the object
 * need not be stored in failures.
 * It is good programming practice, when a failure is detected, to handle
 * it before doing anything on the object since new actions could destroy
 * the data that allows to understand what went wrong. To protect against
 * this, at least the error code is copied into failures.
 * If a Java exception is caught, an applicative one should always be stacked
 * on top of it because the Java one is not localized.
 * E.g., when an OutOfMemory is caught, a failure is stacked on it which
 * contains an error code that corresponds to a localized message that
 * tells it.
 * The Failures with the application verb on them are the ones which are issued
 * directly by applications. The ones which come from subsystems have the
 * subsystem name in them.
 * <p>
 * In order to allow applications catching Failures to know the object on
 * which they occurred, a field is provided to keep a reference to the
 * object. E.g. An application which has several files and catches an error
 * in one of them can test such a reference and determine what file it is.
 * <p>
 * To manage exceptions, upon entry in methods, any reference to an exception
 * object should be cleared. During the execution, when an abnormal condition
 * is detected, a failure object should be created. Then, if the method is
 * simple, a transfer of control is made at the end, and if it is complex (and
 * calls several internal methods), the exception is thrown, and catched at the
 * end. There, the exception can be thrown or a status returned, or an abort
 * done. Note that for complex methods, it is possible to throw from the body
 * an exception, catch it and throw at the end a different one.
 * In such a case there is a need to test if the failure data are the same so
 * as to avoid building a new failure object.
 * <p>
 * When documenting an API, it is important to describe all the exceptions
 * (including Failures) that methods throw, not only the ones which are
 * declared in method definitions. This is so as to allow callers to catch
 * them, otherwise it would be impossible to tell what went wrong.
 * <p>
 * Applications must catch all <code>Throwable</code>s at least in the main,
 * and not to use bundles there to report them.
 * <p>
 * When the functionalities of Failures are sufficient, Failures can also be
 * used to record and report top-level application messages (i.e. the ones
 * which are not returned to some caller, but are reported), without a need
 * to subclass them.
 * To allow it, Failures have the bundle name, the error kind, and also the
 * subsystem name in them. The method <code>getMessages()</code> in Failure
 * delivers the message on the base of the bundle and the code.
 * Failure has also a print method which allows to avoid to generate a
 * wrapper failure: it is equivalent to create a wrapper failure and print
 * it and the ones linked to it.
 * <p>
 * To make subclasses independent on the position in the filesystem of the
 * bundles they use, <i>class-name</i><code>.class.getName()</code> can be
 * used to get the fully qualified name of the bundle.
 * <p>
 * OutOfMemoryError
 * <p>
 * The creation of a <code>Failure</code> when a <code>OutOfMemoryError</code>
 * occurs could fail: if there is no memory, then there is also none for that
 * Failure, unless such a <code>Failure</code> be preallocated at the
 * beginning to be used for that, or if the methods which catch it free some
 * memory before creating a <code>Failure</code>. There is a need there to
 * make a tradeoff between freeing as much memory as possible and keeping
 * as many objects as needed to circumstantiate the cause of the memory
 * consumption. Freeing only few objects makes the garbage collector run two
 * times in a row: one for the <code>new()</code> which just failed, and
 * another as the objects are freed and the <code>Failure</code> is created.
 * The catching of <code>OutOfMemoryError</code> should be done by the methods
 * which allocate memory in an amount which increases as that of the data they
 * process increase. It would be practically impossible to run out of memory
 * for objects whose number does not depend on the data processed, i.e.
 * buffers, static data, etc. These are the methods which either allocate
 * recursively memory or allocate arrays of dynamic size.
 * <p>
 * StackOverflowError
 * <p>
 * The catching of <code>StackOverflowError</code> should be done only by the
 * methods which are recursive. It would be practically impossible for the
 * others to cause that exception.
 */

/* Applications which exit upon detection of failures should print them
 * before aborting.
 *
 * To see the source lines where Failures have been created, turn the
 * <code>trc</code> flag on.
 *
 * It is possible to access the data in a bundle directly by naming the
 * name of the bundle contained in the class.
 * Resource bundles are read from a jar, if a program is run from it.
 *
 * The reason to identify errors by means of error codes is to allow callers to
 * test them easily, which could be more difficult if references to strings
 * would be used instead. Having error codes, it is straightforward to use
 * then message tables indexed by message codes instead of keywords to access
 * resource bundles to localize messages.
 *
 * The public method to print Failure messages is an instance one because
 * it is simpler to call.
 *
 * When an exception occurs during the reporting of an error, an attempt
 * is made to report on System.err the first one because it is always closer
 * to what originally happened.
 * Then most applications would like to exit, because there is little to
 * do to recover it. This is what <code>print()</code> does.
 * For the ones which want to take control over it, <code>write()</code>
 * is provided.
 *
 * There is a need to have a common "report" stream which is used by all the
 * classes to report errors. There are two needs here:
 *
 *   1. to be able to redirect the data to another stream.
 *   2. not to overwite or leave blank lines on it. Since System.out shares
 *      the console together with System.err, there is a need for a common
 *      convention so as not to leave blank lines or to overwite on previous
 *      output. Moreover, there is a need to have data in the same order
 *      as that of the write operations (which might not be the case when
 *      several buffered, unflushed writers were used).
 *
 * The need for a common report is to allow applications which have several
 * threads, or even simply several tasks to do, and that call methods which
 * produce a report, to redirect that report to distinct streams so as not to
 * mix the one of one task with that of another.
 * There is a problem only with classes which print on the report, because
 * all the other ones produce at most text which is meant to be eventually
 * printed on the report, and that is done by the applications.
 * This is solved by passing a report to all classes which can produce
 * output on it, like Cli or Listing.
 * Applications which do not care to use System.err can pass it, the
 * other that do care can pass something else, like e.g. a different one
 * for each thread.
 * In some classes, when the user chooses the ERR_ABORT policy, System.err is
 * used to print the error messages. This modality is for simple programs, though.
 * A common report also would relieve all classes which have something to print
 * to create their own Formatter or IoStream or java.io to print.
 * However, it is not convenient to force to use the Cli one since
 * there are applications which do not have commands, and there are classes
 * (like e.g. Listing) which have their own one anyway.
 * Moreover, in most cases printing can be done directly on the report
 * passed without a need to build any other io object on top of it.
 * Additionally, the error report has better not to be a Formatter or another
 * high-level object so as to avail also when a programming error prevents
 * such an object to to work.
 *
 * If a Formatter has been used to write text on the report other than error
 * messages, there is a need to pay attention to the positioning of the
 * carriage. A formatter either has printed the last message with a [cr] lf
 * at the end, or a cr only. The convention is that on the report the cursor
 * is at the beginning of a fresh line. This is the initial state for all
 * subsystems. This means that when some text is being printed and an error
 * is detected, before printing it a newline must be printed if the cursor
 * has been left on the previous line. That could occur mainly when a
 * Formatter with a listing file has been used.
 * The problem which can occur with classes that allows callbacks is that
 * callbacks could print on the report. Thus, such classes must make sure
 * that the report is positioned correctly and flushed also across callback
 * calls.
 *
 * In registererror() in this package, a new Failure is not created if
 * one already exists, i.e. if a Failure has already been created within
 * the execution of the current method. This is so because when an error
 * occurs, that error can be catched and some recovery done, but then it
 * is thrown again. I.e. it is not destroyed or changed into another one.
 * Should that case occur, the Failure would be terminated and another one
 * created.
 *
 * Serialization
 *
 * Failure is a subclass of Throwable, which is serializable. Although
 * it is not clear why exceptions should be serializable, Failure declares
 * its fields which can be serialized as @serial.
 */

public class Failure extends RuntimeException {

    /**
     * The error code.
     *
     * @serial
     */
    public int code;

    /**
     * The additional exception object.
     *
     * @serial
     */
    public Throwable exc;

    /**
     * The bundle name.
     *
     * @serial
     */
    public String bundle;

    /**
     * The kind of message.
     *
     * @serial
     */
    public char kind;

    /**
     * The subsystem name.
     *
     * @serial
     */
    public String subSystem;

    /** The object on which the failure occurred. */
    public transient Object instance;

    /**
     * Create a Failure. It associates a message string for completeness
     * and for debugging. That string is not used to report the failure,
     * but a possibly localised string.
     *
     * @param      c error code
     * @param      k message kind: 'W', 'E' or 'F'
     * @param      n subsystem name
     * @param      t exception
     * @param      s message string
     * @param      b name of the bundle
     * @param      o object on which it occurs
     */

    public Failure(int c, char k, String n, Throwable t, String s, String b,
        Object o){
        super(s);          // message describing result
        this.code = c & 0x0fffffff;
        this.kind = k;
        this.exc = t;
        this.subSystem = n;
        this.bundle = b;
        this.instance = o;
    }

    /**
     * Deliver the standard heading of an error message.
     *
     * @param      n name of the subsystem.
     * @param      k kind of message: (I)nformational, (W)arning, (E)rror,
     *             (F)atal
     * @return     string
     */

    public static String header(String n, char k){
        switch (k){
        case 'I': case 'W': case 'E': break;
        default: k = 'F';
        }
        return "%" + n + "-" + k + "-";
    }

    /**
     * Deliver the strings representing the failure. This method is meant
     * to be redefined by subclasses. To deliver a localized string,
     * a bundle can be accessed to take strings from it. This is acceptable
     * because messages are usually printed not too often and because
     * bundles are cached.
     *
     * @param      loc locale, null if no locale
     * @return     strings
     */

    public String[] getMessages(Locale loc){
        Locale l = loc;
        if (loc == null) l = Locale.getDefault();
        if (this.bundle != null){            // bundle present
            ResourceBundle bun =
                ResourceBundle.getBundle(this.bundle,l);
            String ms = this.getMessage();
            return new String[] {header(this.subSystem,this.kind) +
                ((String[])(bun.getObject("MSGTAB")))[this.code] +
                (ms == null ? "" : " " + ms)};
        } else {
            return new String[] {header(this.subSystem,this.kind) +
                this.getMessage()};
        }
    }

    /** The trace flag. */
    public static boolean trc = false;

    /**
     * Print a failure and all the ones referred to by it.
     *
     * @param      stream Writer or PrintStream for printing
     * @param      loc locale, null if no locale
     * @param      exc exception object
     * @param      stack true to print the stack trace also
     * @exception  IOException
     */

    private static void printMessage(Object stream, Locale loc,
        Throwable exc, boolean stack) throws IOException {
        Writer wr = null;
        PrintStream ps = null;
        CharStream cs = null;
        if (stream instanceof Writer){
            wr = (Writer)stream;
        } else if (stream instanceof PrintStream){
            ps = (PrintStream)stream;
        } else if (stream instanceof CharStream){
            cs = (CharStream)stream;
        } else {
            ps = System.err;
        }
        String lineSep = System.getProperty("line.separator");
        do {
            Throwable e = exc;
            String[] msgs;
            if (exc instanceof Failure){
                Failure ex = (Failure)exc;
                msgs = ex.getMessages(loc);
                exc = ex.exc;
            } else {
                msgs = new String[] {
                    header("JRE",'F') + exc.toString()};
                exc = null;
            }
            for (int i = 0; i < msgs.length; i++){
                if (wr != null){
                    if (i > 0) wr.write("  ");
                    wr.write(msgs[i]);
                    wr.write(lineSep);
                } else if (ps != null){
                    if (i > 0) ps.print("  ");
                    ps.println(msgs[i]);
                } else {
                    if (i > 0) cs.write("  ");
                    cs.writeln(msgs[i]);
                }
            }
            String strace = null;
            if (stack){
                CharArrayWriter cw = new CharArrayWriter();
                PrintWriter pw = new PrintWriter(cw);
                e.printStackTrace(pw);
                strace = cw.toString();
            }
            if (wr != null){
                if (strace != null) wr.write(strace);
                wr.flush();
            } else if (ps != null){
                if (strace != null) ps.print(strace);
                ps.flush();
            } else {
                if (strace != null) cs.write(strace);
                cs.flush();
            }
        } while (exc != null);
    }

    /**
     * Print this failure and all the ones referred to by it.
     * If an error occurs during the operation, an internal error is
     * printed on System.err and the program is terminated.
     * This is the case of a grave system failure, which does impair even
     * the printing of error messages.
     *
     * @param      stream Writer or PrintStream for printing
     * @param      loc locale, null if no locale
     * @param      stack true to print the stack trace also
     */

    public void print(Object stream, Locale loc, boolean stack){
        try {
            printMessage(stream,loc,this,stack);
        } catch (Throwable exc){
            System.err.println(header("Failure",'F') +
                "INTERNAL, Internal error");
            System.err.println("  " + exc);
            System.err.println("  " + this);
            if (stack) exc.printStackTrace(System.err);
            System.exit(1);
        }
    }

    /**
     * Print this failure and all the ones referred to by it.
     * The language is determined by the default locale.
     *
     * @see        #print(Object,Locale,boolean)
     */

    public void print(Object stream){
        print(stream,null,false);
    }

    /**
     * Print this failure and all the ones referred to by it.
     * If an error occurs during the operation, that error is returned.
     * The user program should then terminate or perform some deep recovery
     * action.
     *
     * @param      stream Writer or PrintStream for printing
     * @param      loc locale, null if no locale
     * @param      stack true to print the stack trace also
     * @exception  Throwable
     */

    public void write(Object stream, Locale loc, boolean stack)
        throws Throwable {
        printMessage(stream,loc,this,stack);
    }

    /**
     * Print this failure and all the ones referred to by it.
     * The language is determined by the default locale.
     *
     * @see        #write(Object,Locale,boolean)
     */

    public void write(Object stream) throws Throwable {
        write(stream,null,false);
    }

    /**
     * Print an error message, possibly taken from a bundle, and
     * then a Failure and all the ones referred to by it.
     * If an error occurs during the operation, an internal error is
     * printed on System.err and the program is terminated.
     * This is the case of a grave system failure, which does impair even
     * the printing of error messages.
     *
     * @see        #writeMessage(Object,Locale,String,char,String,String,
     *             Throwable,boolean)
     */

    public static void printMessage(Object stream, Locale loc, String n,
        char k, String m, String bn, Throwable exc, boolean stack){
        try {
            writeMessage(stream,loc,n,k,m,bn,exc,stack);
        } catch (Throwable e){
            System.err.println(header("Failure",'F') +
                "INTERNAL, Internal error");
            System.err.println("  " + e);
            System.err.println("  " + exc);
            if (stack) exc.printStackTrace(System.err);
            System.exit(1);
        }
    }

    /**
     * Print an error message, possibly taken from a bundle, and
     * then a Failure and all the ones referred to by it.
     * If an error occurs during the operation, that error is returned.
     * The user program should then terminate or perform some deep recovery
     * action.
     *
     * @param      stream Writer or PrintStream for printing
     * @param      loc locale, null if no locale
     * @param      n name of the subsystem.
     * @param      k kind of message: (I)nformational, (W)arning, (E)rror,
     *             (F)atal
     * @param      m message, or key in the bundle (if present)
     * @param      bn name of the bundle
     * @param      exc exception object
     * @param      stack true to print the stack trace also
     * @exception  Throwable
     */

    /* This method serves to relieve the user from skipping a print()
     * when a previous printing of a message produced an exception.
     */

    public static void writeMessage(Object stream, Locale loc, String n,
        char k, String m, String bn, Throwable exc, boolean stack)
        throws Throwable {
        Writer wr = null;
        PrintStream ps = null;
        CharStream cs = null;
        if (stream instanceof Writer){
            wr = (Writer)stream;
        } else if (stream instanceof PrintStream){
            ps = (PrintStream)stream;
        } else if (stream instanceof CharStream){
            cs = (CharStream)stream;
        } else {
            ps = System.err;
        }
        String lineSep = System.getProperty("line.separator");
        String msg = header(n,k);
        if (bn != null){
            Locale l = loc;
            if (loc == null) l = Locale.getDefault();
            ResourceBundle bun =
                ResourceBundle.getBundle(bn,l);
            msg += bun.getString(m);
        } else {
            msg += m;
        }
        if (wr != null){
            wr.write(msg);
            wr.write(lineSep);
            wr.flush();
        } else if (ps != null){
            ps.println(msg);
            ps.flush();
        } else {
            cs.writeln(msg);
            cs.flush();
        }
        if (exc != null){
            printMessage(stream,loc,exc,stack);
        }
    }
}
