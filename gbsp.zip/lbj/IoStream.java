/*
 * @(#)IoStream.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.net.*;
import java.util.*;
import lbj.Failure;
import lbj.IOError;
import lbj.Str;
import lbj.CharsRow;
import lbj.BytesRow;

/**
 * The <code>IoStream</code> class provides a means for performing input
 * output.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

/**
 * This class provides:
 * <ul>
 * <li>uniform handling of i/o: a unique object serves to perform io
 *   on any kind and in both directions, buffered or otherwise.
 *   IoStream is not a subclass of some Java io class because Java io has
 *   several classes which do not have a common superclass.
 * <li>uniform naming of files, be them devices, standard streams,
 *   web resources.
 * <li>handling of relative names which contain partial filespecs, that
 *   are resolved against another filespec.
 * <li>uniform transfer of data to and from arrays of characters and bytes,
 *   with or without line separation.
 * <li>transfer of bytes and characters on all streams.
 * <li>uniform handling of exceptions.
 * <li>error detection with delivery of the information that allows to
 *   identify the external object on which errors occurred.
 * <li>non-synchronised methods, which can be synchronised when need occurs.
 * <li>a speed in performing io which is from two to three times that of
 *   java.io.
 * </ul>
 * <b>Kinds of files</b>
 * <p>
 * This class handles streams of characters and bytes as a sequence of
 * values, with no record structuring. Only separation in lines is
 * supported.
 * The distinction between text files and byte files is that the text ones
 * are made of characters, while the byte ones are made of bytes.
 * Streams are eventually made of bytes, except for the ones which are
 * built around a java.io character object (like e.g. a CharArrayReader).
 * Files of java values are object data files. There is no notion of, e.g.,
 * files of e.g. integers or booleans.
 * When there is no need to interoperate with other applications, Data files
 * can be used to hold Java values. Otherwise, byte files must be used.
 * <p>
 * It could be useful to let a text file be represented as it is best for
 * the filesystem. I.e., there are filesystems in which text files are
 * record oriented.
 * Note that it is not possible to provide text files as sequences of
 * characters and line terminators if the underlying file is record oriented.
 * The model of lines as sequences of characters separated by line
 * separators is more powerful since it allows to write lines whose
 * length is not known in advance. With files in which lines are records,
 * there is either a need to buffer entire lines or to re-write the
 * record lengths when lines are completed. Since most blocks have a
 * line that is placed across a block boundary, this means writing most
 * blocks twice. This means that either there is a need for long buffers
 * or more i/o. Consider also that lines are mainly used with text files,
 * which are either edited, or printed, or accessed by humans, and the
 * breaking into lines is made for having a more convenient way to see
 * text. It is thus pointless to allow line separators in the middle of
 * lines, the main feature that record files have over stream files.
 * Record files are really needed when there is a need to treat data which
 * might not be text. In such a case it is better to have Data files of Java
 * char[] or Strings.
 * <p>
 * Notably, files of records, present in several systems, provide a useful
 * mechanism for structuring data which relieves the programmer from inventing
 * an in-band way to do it. They are provided as Data files of arrays (the
 * length of Java arrays is variable), or objects.
 * <p>
 * Files are unstructured sequences of bytes which are interpreted as
 * applications likes, even when they are characters.
 * It is up to applications to convert bytes back and forth into Java values.
 * When files are known to contain characters only, the appropriate conversion
 * can be performed automatically, as well as when reading bytes which must
 * be interpreted as characters.
 * <p>
 * Character files are encoded in a way which by default depends on the
 * platform, or which is specified when they are created.
 * The format of the stream is that defined for the encoding used. Note,
 * however, that there are some encodings which map a sequence of charaters
 * into several possible byte sequences.
 * IoStream allows to use all encodings independently on the access method,
 * i.e. to use sequential and random access on any file present in a device
 * which allows both.
 * There is a need, however, to pay some attention with files which are
 * accessed randomly or have a mixture of characters and bytes.
 * <p>
 * In files in which there are sequences of bytes and characters, a
 * character sequence can be followed by a byte sequence or by the end of
 * the file.
 * For any file which is meant to be read until the eof is found, there
 * must not be an incomplete sequence at the end of the file.
 * This is also the case of streams which give access to files whose data
 * are not available at once and which do not block a read() operation when
 * no data is available: since it is not possible to know for sure that there
 * are data after a missed arrival, when that happens, the text must be well
 * formed and complete at that point.
 * This means also that in multifile reading, each file should be well-formed,
 * e.g. sequences must not span file boundaries.
 * To make <code>read()</code> and <code>readln()</code> interpret the
 * lack of data as a suspension instead as an eof, the <code>ENDLESS</code>
 * mode is provided.
 * <p>
 * For files accessed sequentially, the number of <code>write()</code>
 * operations, the amount of characters written by each one, and the use of
 * buffering or autoflushing are irrelevant for what concerns the subsequent
 * reading of those characters, which can be done by using any number of
 * <code>read()</code> operations.
 * Note that the usage of buffering changes the contents of the file written
 * with respect to what it would be without buffering when lock-shift
 * encodings are used. Without buffering, lock-shift byte sequences are
 * written at each <code>write()</code> to set and reset the charset of the
 * characters written. With buffering that is done only for the entire character
 * sequence. Note that the characters which are represented in the file
 * are the same.
 * <p>
 * When a file is accessed randomly, it is considered a byte file (e.g.
 * the current index in it denotes byte positions).
 * It is possible to seek the index at any position at which bytes are present,
 * and at any position at which a <code>write()</code> of characters has been
 * done. For fixed-length and non lock-shift encodings it is also possible to
 * seek at any position at which a character is present, even in the middle of
 * characters written by a <code>write()</code>.
 * Examples of such encodings are: ASCII, ISO8859 and Unicode.
 * Note that in general, a file which is meant to be read randomly, is
 * also created by an <code>open()</code> in random mode because that is the
 * only way to know the indexes of the data which are needed thereafter to read
 * them, which would be impossible should the file be opened in sequential
 * access.
 * Moreover, after having positioned the file at a point at which the first
 * character of a write was written, and having read some characters,
 * there is also a need to read all the characters that have been written
 * by it before positioning at a different place. This works with all
 * encodings. It is also possible to position the file at a place in which
 * characters are present which belong to the same shifted status as the
 * last that was read.
 * These restictions are not present for non-shift encodings.
 * Autodetect encodings, like e.g. "Unicode" (with autodetect byte order)
 * should be used carefully in random access because they require to
 * process some bytes after opening to detect the actual encoding.
 * Use instead, e.g. a UnicodeLittle. Otherwise make a <code>read()</code> at
 * a point in the file (e.g. the beginning) which contains the first
 * characters which have been written.
 * <p>
 * Changing the encoding is a lengthy operation, which should be used
 * sparingly.
 * <p>
 * Lines are terminated by a line terminator, or by the end of file.
 * They are not terminated by byte sequences which are not characters.
 * In Windows the line terminator is CR LF, in Unix LF and in MacOS CR.
 * IoStream uses the same policy as java.io to delimit lines when reading:
 * a line is terminated by CR or LF, or by CR LF. This means that a java
 * program reading a file written by an Unix application would break a
 * line at a CR. I.e. lines are not exactly what they are normally in Unix,
 * in which they can contain a CR.
 * <p>
 * Standard input, output and error allow mixing of characters and bytes.
 * <p>
 * <b>Filespecs</b>
 * <p>
 * The methods <code>open()</code> and <code>find()</code> build a filespec
 * from the one passed as argument and the one which is present in the
 * object, from which all parts that are not present in the one passed
 * as argument are propagated. To leave a filespec in an object, close it
 * with the <code>LOCATE</code> mode. Opening with an iterator implicitly
 * enables propagation. Propagation of filetype is done only when a default
 * filetype is provided, possibly an empty string. To disable propagation,
 * create another object, or close it in the standard way.
 * <p>
 * It is possible to open in read or in write web resources. Propagation on
 * them is that defined for URI resolution. Note that while between files
 * there is no notion of relative directory for spec and the previous one,
 * there is bethween URIs.
 * Due to a bug in JDK 1.2, URI reserved characters may not occur in URIs,
 * except with theyr reserved meaning.
 * URIs may not be opened in read and write at the same time.
 * <p>
 * A special type of URI allows to denote jar elements in jar files,
 * which can only be opened in read.
 * <p>
 * It is possible to open sockets by providing a URI in which "tcp" is
 * specified as protocol, followed by "//", the host name or IP address,
 * ":" and the port number. E.g. <code>tcp://host.x.y:450</code> or
 * <code>tcp://151.98.56.12:7</code>.
 * Sockets provide streams of bytes.
 * <p>
 * Filespecs could contain logical names, which are translated before
 * performing propagation, that is done on the filespec which results
 * from replacing the logical names by the strings they denote.
 * <p>
 * Standard files are given a name because that allows to mention them
 * in commands, e.g. in the middle of lists of files. This allows to use
 * propagation and reporting of errors in a uniform way.
 * The name is platform dependent because <code>find()</code> and
 * <code>open()</code> must interoperate with other classes, like e.g.
 * command parsing, which provide native notations.
 * When open() is used to open files whose spec is contained in command
 * arguments, the spec contains the name, which (possibly after logical name
 * translation) can eventually contain a name of a standard file which is
 * platform dependent. In such a case <code>open()</code> detects that
 * it is opening a standard file after having derived the canonical path.
 * Additionally, a platform independent notation for standard file is
 * provided to be used when <code>open()</code> is called to open explicitly
 * a standard file. For this, constant strings are provided to denote
 * standard files. Although the contents of such strings is platform
 * dependent, the references are not, and thus serve as platform independent
 * denotations.
 * When applying propagation to filespecs containing standard files,
 * the usual rules are applied to propagate the directory, filename and
 * filetype. This serves, e.g., to propagate a "/dev/" present in a filespec
 * on a following one which is "stdin", which would otherwise not be
 * recognised as the standard file "/dev/stdin". This is partly done by the
 * when a path its transformed into a canonical path by substituting links,
 * removing irrelevant parts etc.
 * <p>
 * IoStream objects provide a path which is the filespec string independently
 * on whether it is a file, a URI, or a standard file.
 * <p>
 * In Java there is no way to identify uniquely files (e.g., there are no
 * inodes). This means that they are identified by their (canonical) names,
 * relying on the underlying filesystem for their uniqueness (i.e. for
 * not having two names for a same file).
 * <p>
 * It is possible to take an already built java.io object, like e.g. a
 * Reader or a Writer and open an IoStream to perform io on it.
 * This kind of open is called: "open by object".
 * The data transfer which is allowed depends on the kind of object.
 * E.g. when a Writer is passed, only character writes are allowed,
 * and when an OutputStream is passed, byte and character writes are
 * allowed.
 * <p>
 * On filesystems mounted in NFS from a Windows machine to a Unix machine
 * the files, as seen from the Windows machine, have names which suffer
 * from the differences in case sensitivity between the two systems.
 * When locating a file which is unique not considering the case of letters,
 * that file is taken. If it is not unique, i.e. there are other files
 * with the same name apart from the case, one among them is taken, often
 * the one which is first in the lexicographical ordering.
 * <p>
 * <b>File handling</b>
 * <p>
 * An IoStream object, after being associated by <code>find()</code> to an
 * object in the external world, is in the "file handling" state (it is
 * "located").
 * In such a state, the file can be manipulated as a whole, i.e. opened,
 * renamed, deleted, inquired.
 * <p>
 * The method <code>find()</code> does not open a file, i.e. it does not
 * construct the reader or writer which are needed to transfer the data,
 * which are heavy operations that are avoided when there is only a need
 * to know the attributes of a file.
 * This table shows which attributes are provided and when they become
 * known:
 * <p>
 * <table>
 * <tr><td>      </td><td><i>file </td><td><i>find</td><td><i>open/read</td></tr>
 * <tr><td>length      </td><td>ordinary</td><td>    y</td><td>  y</td></tr>
 * <tr><td>            </td><td>special </td><td>    -</td><td>  -</td></tr>
 * <tr><td>            </td><td>uri     </td><td>     </td><td>  y</td></tr>
 * <tr><td>lastmodified</td><td>ordinary</td><td>    y</td><td>  y</td></tr>
 * <tr><td>            </td><td>special </td><td>    -</td><td>  -</td></tr>
 * <tr><td>            </td><td>uri     </td><td>     </td><td>  y</td></tr>
 * <tr><td>path        </td><td>all     </td><td>    y</td><td>  y</td></tr>
 * <tr><td>kind(*)     </td><td>        </td><td>    y</td><td>  y</td></tr>
 * </table>
 * (*) whether the file is an ordinary, special, or URI one.
 * <p>
 * After a <code>find()</code>, an <code>open()</code>, a <code>rename</code>,
 * and a <code>delete()</code> without a filespec argument operate on the
 * file which has been associated. Versions of these methods are provided
 * which accept a filespec argument and that combine the find with the basic
 * action they perform.
 * The object returns to the free state by executing a <code>close()</code>.
 * Note that there are methods, such as <code>length()</code>, which are
 * better be called after a file has been closed, and returned to the file
 * handling state.
 * <p>
 * Files are created by opening them in <code>WRITE</code> or
 * <code>APPEND</code>. When a file is opened in <code>WRITE</code> and
 * a file with the same name exists in the same directory, the file is
 * rewritten, unless <code>NOREWRITE</code> is specified, in which case
 * the operation is rejected. This mode is effective only when
 * <code>NAME_CLOSE</code> (see below) is not specified.
 * If <code>TEMP</code> is specified, the file is created as a temporaty
 * one in the specified directory with a name that has the specified
 * filename as prefix.
 * <p>
 * In filesystems which are not versioned, like e.g. the Unix or NT ones,
 * if a program opens an output and an input files, it should pay attention
 * to open the output after the input because if they have the same name,
 * the input would be lost. To avoid it, there is a need to open the output
 * with a temporary name and change it on close.
 * In java, when a file is opened in output, and then in input, the read
 * gets the data which are in the file even if the file has not yet been
 * closed.
 * A technique is to create a temporary file, and to rename it upon closing.
 * The creation of a temporary file works also in versioned filesystems
 * because on rename a new version would be created.
 * Unfortunately, if the program is aborted, a temporary file is there,
 * and the user does not even know that he has to delete it. This results
 * in cluttering disks with files nobody knows what they are.
 * There is a basic condition to guarantee: an application upon normal or
 * abnormal exit must not leave unretrievable garbage files. If an application
 * which is writing a file is killed, but the file is known (e.g. it is
 * specified in the command), it is still possible for the user to delete
 * it or to rerun the application, which will overwrite it.
 * It would be better to delete the non-closed file upon termination, but
 * the above behaviour is still acceptable.
 * Such temporary files should not be created in a system-wide temporary
 * directory such as "/tmp" because then they have to be moved into the
 * destination directory, which could be on a different disk.
 * Moreover, when an application takes an input and an output files which
 * have the same name, it should pay attention to preserve the input one:
 * either it terminates normally with the output superseding the input
 * correctly, or it must leave the input unchanged (and no unknown output).
 * To do it, it creates the output with a temporary name, and it replaces
 * it only when it has completed it. Finalization and shutdown hooks are
 * used by IoStream to delete the file upon abnormal termination or when the
 * file has not been closed.
 * This is made independently on whether the output file existed before
 * or not. I.e. the output file is not created with its file name if it
 * did not exist before because if it was named in the input list, that
 * should be detected as an error.
 * This modality is obtained with the <code>NAME_CLOSE</code> or the
 * interlocked mode.
 * <p>
 * There is also a problem when a sequence of files should be appended to
 * an existing file. The semantics is that of making a temporary copy of
 * the file to be appended, to transfer data into it, and eventually to
 * rename it.
 * Read operations must not read the new data, or in other words, they must
 * read only the data which were present at the moment the whole operation
 * began.
 * Since read operations read all the data written and flushed into the
 * file and not only the ones present before the write operations, there is
 * a need to detect that the file is opened in write also and to restrict
 * reads to get only the old data. This is possible because append is
 * only effective on regular files, for which the length is known.
 * When a file is opened in append, its length is stored, and then when a
 * file is opened in read, a check is made that the file is not open in
 * write, in which case the length is taken from the open object.
 * A reference is kept in IoStream objects to a set of other IoStream
 * ("interlocked") objects that hold files opened in write or append.
 * When an open in read is done, the interlocked objects are examined to
 * get the origin length, which is stored in them at the time the files were
 * opened.
 * Interlocked mode is allowed only for files opened in sequential read.
 * It is not allowed for files opened in read/write, nor it is for files
 * opened in random access.
 * <p>
 * Another technique is to create a new file and then to append it to the
 * origin one before closing it.
 * The issue is on how much effort to do to make an application safe
 * with respect to problems in append. The best would be that either an
 * application succeeds, or that it leaves the origin file as it was
 * before. To guarantee this under all circumstances, including a computer
 * halt, a new file should be created with the old contents, and then
 * appended, and renamed to the old one upon closing. To guarantee this
 * against errors which can be catched by the application there is a need
 * to truncate the file to the original size on error. Note that this is
 * a general technique, to be used for all kind of errors, not only on
 * those related to the copying of input files into the output one.
 * This, however, defeats the whole concept of append.
 * To restore the filesystem (i.e. to restore a file to its initial state
 * it had at the beginning of the current write or append operation),
 * the <code>RECOVER()</code> close mode is provided.
 * <p>
 * Some applications need to read a sequence of files more than one time.
 * However, between the fist pass and a subsequent one, such files could
 * have been changed underneath.
 * This is obtained by opening the files in "check" mode. An IoStream object
 * which is used in such a mode remembers the files that it opened and
 * their last modification time. When the first pass is completed, the
 * object is told to check that all the files subsequently opened by it,
 * if their name matches one of the names of the files opened previously,
 * also their time must match. Note that this is done internally by IoStream
 * to support reading of sequence of files, which implies the automatic
 * opening of files (which is out of user control).
 * <p>
 * To restore the initial defaults and to set the "check" mode on an IoStream
 * object, <code>restart()</code> is provided. Then the restarted object
 * can read (and check) again a (list of) files.
 * <p>
 * There are sources for files other than devices:
 * <p>
 * <table>
 * <tr><td>memory   </td><td>character and byte sequences</td></tr>
 * <tr><td>pipes    </td><td>byte sequences</td></tr>
 * </table>
 * <p>
 * Memory streams allow to read/write data from memory. Pipes are streams
 * of messages between Java threads. A Java program can create pipes
 * to communicate with other processes created by means of <code>exec()</code>.
 * These, however, are seen as standard files.
 * To access these objects, an IoStream can be used. It is done by passing
 * them to <code>open()</code>. A path is passed also, which is used for
 * error reporting.
 * For memory and pipes there may not be a concept of propagation. for sockets
 * It is difficult to provide a standard way for IoStream to open or create
 * objects of these classes because they have specialized parameters,
 * and also because there are cases in which they exist already (like e.g.
 * <code>System.in</code>).
 * The attributes which are managed by IoStream, such as the date, length,
 * path, etc. can be set by applications. They are not really needed by
 * IoStream, except for the length which is only used in interlocked
 * append, which is disabled here. Interlock and multipass checking is not
 * provided for IoStream objects opened by providing an object ("open by
 * object").
 * It is possible to open System.in, System.out and System.err. It is
 * equivalent to use the predefined names, except that there is a need here
 * to provide also a path.
 * IoStream sets automatically PERMANENT so as not to close a standard file
 * because when it is closed there is no way to open it again.
 * <p>
 * Java provides filters to manipulate what is contained in files, like
 * e.g.:
 * <table>
 * <tr><td>object streams  </td><td>sequences of Java objects</td></tr>
 * <tr><td>data streams    </td><td>sequences of Java primitive objects</td></tr>
 * <tr><td>pushback streams</td><td>streams with backtraking</td></tr>
 * </table>
 * These are some, but others are provided which filter byte streams into
 * byte or character streams, and character streams into character streams.
 * To use them there is a need to plug them to the stream contained in
 * an IoStream object after it has been opened so as to allow then to use their
 * read/write and their specialized methods.
 * This can also be used to get the stream which is inside an Ios object
 * and call directly its methods. E.g. for binary files a write(byte), which
 * is provided by OutpuStream can thus be called.
 * The <code>takeStream()</code> and <code>takeCharStream()</code> methods
 * return the respective streams to be used in these cases, and when unsafe,
 * disable also the use of the IoStream data transfer operations.
 * <p>
 * <b>Data transfer</b>
 * <p>
 * An IoStream object which is in the file handling state transits into the
 * "data transfer" state by means of an <code>open()</code> (it is "open"),
 * and returns back into it by a <code>close(LOCATE)</code>.
 * It returns to the free state by executing a <code>close()</code>.
 * In the data transfer state, data can be transferred to and from the
 * program and the outside world.
 * To transfer data, various forms of <code>read()</code> and <code>write</code>
 * methods are provided.
 * <p>
 * When an <code>Iterator</code> is set into an IoStream object, read operations
 * step through the files delivered by it. They report an eof when they read
 * past the end of the last file.
 * This allows applications to read a sequence of file as if they were a
 * single stream. To register an Iterator, a dedicated <code>open()</code>
 * is provided. An Iterator is provided in Cli.
 * The files in the sequence are opened in sequential read access.
 * <p>
 * Data transfer is automatically buffered when useful to maximize efficiency
 * and keep data transfer between user memory, buffers and the external
 * world at a mimumum.
 * <p>
 * FLUSH is done automatically after every write operations on special files.
 * This can be forced on any file by selecting <code>AUTO_FLUSH</code>.
 * Moreover, <code>flush()</code> can be used to flush operations when no
 * auto-flush is in effect.
 * <p>
 * Methods for reading and writing lines and line separators are provided.
 * They use the platform specific line delimitation. Write methods do not
 * scan the characters which are printed to detect embedded newlines.
 * To have this, a Formatter should be used.
 * To obtain portability, the line terminator could be set in an IoStream
 * object.
 * However, in most cases that is not really needed because files are portable
 * if their lines are terminated by LFs or by CR LFs.
 * <p>
 * By default, files are opened for byte transfer, as it is when
 * <code>BYTES</code> is specified. If <code>CHARS</code> is specified,
 * it overrides <code>BYTES</code>, and character transfer only is enabled
 * in the default encoding. If an encoding is specified, <code>CHARS</code>
 * is enabled with that encoding.
 * Note that there are streams which can transfer characters only.
 * The default encoding is the platform dependent one, which is specified
 * by the "file.encoding" system property. The list of supported encodings is
 * reported in:
 * http://java.sun.com/products/jdk/1.2/docs/guide/internat/encoding.doc.html.
 * In addition, "UCS2" is supported. It allows 16 bits codepoints without
 * any byte mark and with the most significant byte first.
 * When opening by name (or after a <code>find()</code>), if neither
 * <code>BYTES</code> nor <code>CHARS</code> are specified in an
 * <code>open()</code> call, <code>BYTES</code> is selected unless the open mode
 * is <code>RANDOM</code>, in which case also <code>CHAR</code> is selected.
 * If <code>BYTES</code> is specified, it has no effect, if <code>CHARS</code>
 * or an encoding is specified, a converter is created immediately and
 * <code>BYTES</code> is delesected (i.e. only character transfers are allowed).
 * <p>
 * In output, although the behaviour of the converters when called on
 * characters which have no equivalent is not specified, a "?" is 
 * written.
 * In input, when an invalid sequence is read (i.e. a sequence of bytes
 * which is not allowed by the encoding), a <code>CharConversionException</code>
 * (<code>sun.io.MalformedInputException</code>) is thrown.
 * <p>
 * Each datum in a file is uniquely identified by an <i>index</i>.
 * Data transfer operations move values to/from memory and a file at a
 * position in the file which is indentified by the current value of the
 * index, which is then advanced past those data.
 * When the value of the index at which the data ought to be read by
 * the last read operation denoted data that lay outside the file, an
 * eof is returned (unless <code>ENDLESS</code> is specified) either as
 * a return status, which can be tested by <code>eof()</code>, or as
 * an exception (if <code>EOF_EXCEPTION</code> is specified).
 * <p>
 * The index may not be accessed for files which are opened in sequential
 * mode. However, it is possible to know if the last read operation attempted
 * to transfer data while the current index was beyond that of the last
 * value in the file. The index can be accessed for files opened in random
 * access.
 * <p>
 * <b>Random access</b>
 * <p>
 * <p>Files residing on random access devices can be opened in random
 * access mode, in read and/or write. All write operations are implicitly
 * autoflushed. Read operations read at once as many data from the file as
 * needed to deliver the requires data to the caller. Note that if another
 * application or thread is writing ad the same time data at positions in
 * the file which overlap the ones which are being written, the data which
 * are read can be partly the old ones and partly the new ones in an
 * unpredictable amount.
 * <p>
 * <b>Read/write access</b>
 * <p>
 * Disk files, special files (like e.g. the standard input and output), URIs,
 * sockets, etc. are able to perform input and output, and thus can be opened
 * in read and write at the same time. The standard input may not be opened
 * in write only, and the standard output in read only.
 * On IoStream objects opened in read and write, <code>read()</code> and
 * <code>write()</code> can be called. In sequential access, each operation
 * keeps its own sequence in transferring data as if two streams had been
 * used. What data are transferred depends on the device: on block devices,
 * the data which are present at the time the operation is done, which
 * means that it is possible to read data which had been written by a
 * write operation previosuly done on the same stream, on sequential devices,
 * only data which lay ahead at each operation.
 * When a same disk file is opened both in read and in write, and there is
 * a need to read the data which the very same application wrote before,
 * that stream must be autoflushed, or the write operations whose data must be
 * read must be followed by a <code>flush()</code><br>
 * The length of files opened in read and write is the same as for files
 * opened in write, which is the real, actual one.
 * <p>
 * <b>Interworking</b>
 * <p>
 * Interworking (i.e. mixing operations on a same file by calling methods
 * of different classes) between IoStream objects and java.io objects
 * is possible if before performing output with other methods on an IoStream
 * object, it is flushed. Likewise, after having transferred data with
 * other methods and before calling an IoStraam, flushing is needed.
 * With java.io classes in general, the intermixing of data when a same file
 * is opened by several streams is correct only when they are flushed each time.
 * Interworking in input, however, is possible only for byte io, and not
 * for character io, not even between java.io classes themselves because not
 * all classes provide the equivalent of flushing for input, i.e. the unreading
 * (pushback) of data.
 * E.g. suppose an InputStreamReader is created on top of an InputStream.
 * When reading from the first, its internal buffer is automatically filled.
 * To read then form the second data which have not been taken from the
 * first there is a need to force it to pushbach those data from its
 * buffer into the other one. This, however, is not supported by Java.
 * Interworking is enabled by taking the handle to the java.io object(s)
 * which are created inside an IoStream object.
 * <p>
 * <b>Lifetime/b>
 * <p>
 * A file can be deleted while a java application is running. The application
 * keep on using it as long as it runs. When the file is closed by all
 * the applications which accessed it, it is actually removed.
 * <p>
 * <b>Errors</b>
 * <p>
 * When an error occurs, is it possible to use again the same IoStream
 * object to perform other io operations providing that a <code>close()</code>
 * has been done on it.
 * <p>
 * When an error occurs, a <code>close(RECOVER)</code> is done by default, unless
 * <code>NOCLOSE</code> is on. The default is appropriate for all the applications
 * which terminate when there is an io error. When an application needs to perform
 * specific recovery actions, it can set <code>NOCLOSE</code>.
 *
 * IoStream does its best to indicate the index in streams at which an error
 * occurred. For character streams that is the number of the character.
 * Unfortunately, when IoStream relies entirely on JDK classes to perform
 * decoding, such an index is not precise. In order not to keep two indexes,
 * the position is reported only when reading. Streams accessed in write
 * can also be inspected directly so as to see the extent to which they
 * have been written.
 */

/*
 * To do
 *
 * Shutdown hook for kill: delete or rename unnamed files, and possibly
 * close the opened ones. This has to be done with JDK 1.3.
 * Support for sockets.
 * Support for a memory-based stream which can be written and reread.
 *
 */

/*
 * Handling of errors
 *
 * There is intrinsically a mutual relation between IoStream and Failure:
 * IoStream makes use of Failure to create errors, and Failure can print
 * error messages by calling IoStream methods.
 * However, IoStream calls Failure.print only when aborting, and in such
 * a case it uses System.err. There are these alternative solutions:
 *
 *   1. to have a Failure private to this package to be used in IoStream, and
 *      one which then adds a print method which can use also an IoStream to
 *      print. This requires to have two print() methods in the two Failure
 *      classes.
 *   2. to have a utility class which contains a class method to print
 *      Failures, and exceptions in general.
 *      This requires to have two print() methods in the two classes.
 *      The latter method could use the application name contained in
 *      the command as subsystem name. However, in so doing it could not
 *      be used in all other classes of this package.
 *      This solution is not much different from 1, except that it introduces
 *      a class which is not a subclass of Failure.
 *   3. to define an interface which exports a write method so as to let
 *      IoStream implement it and Failure use it.
 *      This requres one print() method only.
 *
 * Note also that it is always possible for an application to have a method
 * which calls the Failure.print passing to it its own data (like e.g. the
 * name of the bundle, or the command name as subsystem name).
 * This is likely to be the most common case since it simplifies the operations
 * needed when errors are detected, which can happen to be in a number of
 * places in the code.
 *
 * Endless loops in printing error messages do not occur between IoStream
 * and Failure. The case is when an IoStream is used to print an error which
 * occurred on a method of another IoStream object, and the former produces
 * an error when called from Failure. Suppose a method of some class calls
 * a method of IoStream, and the latter causes a memory overflow, and the
 * caller then uses a IoStream to print the error. This is apparently an
 * endless recursion, because:
 *
 *  -  if this produces again an error, then the message is not printed
 *     (which is unlikely because if the overflow was due to the former
 *     IoStream because of a large allocation, then that memory has been
 *     released, otherwise the program is close to the limit, and does
 *     not even have the memory to make a print which is rare),
 *  -  otherwise the message is printed.
 *
 * Note that the Failure.print() can be called with System.err, which
 * prints even when there are problems in IoStream. Thus, it can be used
 * as a last resort in extreme cases.
 *
 * This solution allows applications to print messages on an IoStream that
 * they define.
 *
 * PrintStream intercepts the interrupted io exception and interrupts
 * the current thread. It is not clear what could be the meaning of this
 * because an io interrupted exception is thrown when the thread
 * that performed the io was terminated, and thus it seems pointless
 * to interrupt it.
 *
 * Where possible, the specialized IOExceptions are catched before the
 * generic one so as to give localized messages.
 *
 * There is no permanent error status in IoStream objects because it seems
 * not useful. Moreover, that requires a method to clear it, applications
 * to call it, and the semantics of the other methods to depend on it.
 *
 * When a public method which can return errors as exceptions or status
 * is called from within another method, a check on the result is done
 * so as to terminate when an error has occurred. This is needed because
 * if the error policy is RET_STATUS, the method returns to the caller.
 *
 * OutOfMemoryError
 *
 * IoStream catches memory overflow because it can allocate long lines.
 * It then closes the file so as to free some memory and create the Failure.
 *
 *
 * Notes on the encodings
 *
 * Some encodings use multibytes to encode some characters and single bites to encode
 * some others, and lock-shift encodings use some sequences of bytes to switch from
 * single bytes to multibytes.
 * In all these cases it is difficult to have in a same file encoded strings of characters
 * and plain bytes, not to mention the random access to them.
 * The semantics here is that a mixed mode file must be read in the same way as it has
 * been written, at least for the encoded parts. I.e. to read the same amount of characters
 * that has been written. This ensures that we read the lock-shift bytes properly and
 * then we can read what follows properly.
 * The architecture implemented here for mixed mode files and for the random accessed ones
 * containing encoded characters is to use the InputStreamReader and OutputStreamWiter,
 * which are decoders and encoders that wrap adapters that call the readers and writers.
 * They have an internal state that controls the process, and that is changed when processing
 * lock-shift sequences, or when closing, detecting unavailable data, etc.
 * The only safe way to use them is to make them write entire strings, which they encode
 * wrapping them with the proper lock-shift sequences, and to read such strings in the
 * same way.
 * When reading there is an additional problem. The reading of a string is done by telling
 * read() the number of characters to read, and the reading of a line of characters is done
 * by readln() not knowing its length. In order to read the appropriate number of bytes that
 * make up the number of characters to be read or the line, decoders are provided here, that
 * do not decode, but tell the number of such characters.
 * I implemented a decoder class for that, but it needs to be maintained, and this to
 * support a feature that is seldom used, which is the mixings of encodings in a same file.
 * These are the Java encoders and decoders that do not work JIS0208, JIS0212, CP930, CP933,
 * CP935, CP937, CP939, EUC_YW. My decoders are instead correct.
 * E.g. "\u6ffd".getBytes("CP930") produces only one byte, 6f, while it should produce a
 * shift-in plus two bytes. This probably occurs only when dealing with characters that do
 * not belong to the set of the ones that such encodings are supposed to have.
 * Knowing the proper number of bytes for a string or a line, the input adapter can read
 * them, thus making its wrapping InputStreamReader deliver the proper amount of characters.
 * As for the encoding, I could use a CharserEncoder instead of an OutputStreamWriter, but
 * that would not change things much.
 * In some future version, probably the mixed mode and the random access to encoded files
 * could be removed, at least for the encodings that have multibyte and lock-shift sequences.
 * The complexity of the implementation is hardly worth the support of these features, that
 * are seldom used.
 */

public class IoStream implements CharStream {

    /** The mode. */
    private int mode;

    /** Character transfer mode. */
    public static final int CHARS = 1<<0;

    /** Binary transfer mode. */
    public static final int BYTES = 1<<1;

    /** Do not close on error mode. */
    public static final int NOCLOSE = 1<<2;

    /** Do not overwite files mode. */
    public static final int NOREWRITE = 1<<3;

    /** Flush after any write mode. */
    public static final int AUTOFLUSH = 1<<4;

    /** Reopen check mode. */
    public static final int CHECKED = 1<<5;

    /** Give name on close mode. */
    public static final int NAME_CLOSE = 1<<6;

    /** File open in write mode. */
    public static final int WRITE = 1<<7;

    /** File open in append mode. */
    public static final int APPEND = 1<<8;

    /** File open in random access mode. */
    public static final int RANDOM = 1<<9;

    /** File open in read mode. */
    public static final int READ = 1<<10;

    /** Endless file mode. */
    public static final int ENDLESS = 1<<11;

    /** Eof exception mode. */
    public static final int EOF_EXCEPTION = 1<<12;

    /** Recover close mode. */
    public static final int RECOVER = 1<<13;

    /** Temporary file creation mode. */
    public static final int TEMP = 1<<14;

    /** To file handling state close mode. */
    public static final int LOCATE = 1<<15;

    /** Deliver a newline at end of files if not present mode. */
    public static final int ENDING_NL = 1<<16;

    /** The status. */
    private int status;

    /** File open status. */
    public static final int IS_OPEN = 1<<0;

    /** File ended status. */
    public static final int AT_EOF = 1<<1;

    /** Special file status. */
    public static final int SPECIAL = 1<<2;

    /** Permanent file status. */
    public static final int PERMANENT = 1<<3;

    /** Directory file status. */
    public static final int DIRECTORY = 1<<4;

    /** Uri file status. */
    public static final int URI = 1<<5;

    /** Readable file status. */
    public static final int READABLE = 1<<6;

    /** Writeable file status. */
    public static final int WRITEABLE = 1<<7;

    /** Existent file status. */
    public static final int EXISTENT = 1<<8;

    /** Check in force status. */
    private static final int CHECK = 1<<9;

    /** File has not been named yet status. */
    private static final int UNNAMED = 1<<10;

    /** File located status. */
    private static final int LOCATED = 1<<12;

    /** File length is final status. */
    private static final int LENGTH_FINAL = 1<<13;

    /** Eof detected and kept pending status. */
    private static final int PENDING_EOF = 1<<14;

    /** Encoding changed status. */
    private static final int NEW_ENCODING = 1<<15;

    /** ISO8859_1 encoding status. */
    private static final int ISO8859_1 = 1<<16;

    /** UCS2 encoding status. */
    private static final int UCS2 = 1<<17;

    /** Whether the output stream is a PrintStream status. */
    private static final int ISPRINT = 1<<18;

    /** Whether the output stream is a BufferedWriter status. */
    private static final int ISBUFWRITER = 1<<19;

    /** Whether the output stream is a BufferedOutputStream status. */
    private static final int ISBUFSTREAM = 1<<20;

    /** Whether a read delivered data at the beginning of a file in a sequence. */
    public static final int DATA_BREAK = 1<<21;

    /** Whether a newline is present at the end of the last data read. */
    private static final int NL_PRESENT = 1<<22;

    /** Whether data have been read from a file. */
    private static final int NONEMPTY = 1<<23;

    /** The defaults for the filespec. */
    private String defaults;

    /** The filespec. */
    private FileSpec fileSpec;

    /** The filespec as string. */
    private String path;

    /** The file handle. */
    private File file;

    /** The origin file handle. */
    private File originFile;

    /** The character encoding. */
    private String encoding;

    /** The character reader. */
    private Reader readerStream;

    /** The character writer. */
    private Writer writerStream;

    /** The byte reader. */
    private InputStream inStream;

    /** The byte writer. */
    private OutputStream outStream;

    /** The random access stream. */
    private RandomAccessFile randStream;

    /** The URL connection. */
    private URLConnection urlcon;

    /** The socket. */
    private Socket socket;

    /** The list of accessed files. */
    private FileRef openList;

    /** The trace flags. */
    private int trc;

    /** The number of the current line. */
    private long lineNum;

    /** The original length. */
    private long oldLength;

    /** The last modification time. */
    private long lastModified;

    /** The array of interlocked IoStream objects. */
    private IoStream[] intLock;

    /** The buffer size. */
    private int bufferSize;

    /** The index in the file. */
    private long index;

    /** The number of io operations done. */
    int nrIoDone;

    /** The line separator. */
    private char[] lineSep;

    /** The line separator for byte files. */
    private byte[] byteLineSep;

    /** The multifile name producer callback. */
    private Iterator iter;

    /** The open encoding in a sequence of files. */
    private String openEncoding;

    /** The synchronization lock. */
    private Object mutex;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    a   basic operations
     *    b   user trace
     *    c   actions
     *    d   decoder
     *    f   errors
     *    m   allocation
     * </pre></blockquote><p>
     */

    private static final int FL_A = 1 << ('a'-0x60);
    private static final int FL_B = 1 << ('b'-0x60);
    private static final int FL_C = 1 << ('c'-0x60);
    private static final int FL_D = 1 << ('d'-0x60);
    private static final int FL_F = 1 << ('f'-0x60);
    private static final int FL_M = 1 << ('m'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Deliver a string describing the mode and status.
     *
     * @return     string
     */

    public String trcmode(){
        Str st = new Str();
        int m = this.mode;
        if ((m & CHARS) != 0) st.append("CHARS ");
        if ((m & BYTES) != 0) st.append("BYTES ");
        if ((m & NOCLOSE) != 0) st.append("NOCLOSE ");
        if ((m & NOREWRITE) != 0) st.append("NOREWRITE ");
        if ((m & AUTOFLUSH) != 0) st.append("AUTOFLUSH ");
        if ((m & CHECKED) != 0) st.append("CHECKED ");
        if ((m & NAME_CLOSE) != 0) st.append("NAME_CLOSE ");
        if ((m & WRITE) != 0) st.append("WRITE ");
        if ((m & APPEND) != 0) st.append("APPEND ");
        if ((m & RANDOM) != 0) st.append("RANDOM ");
        if ((m & READ) != 0) st.append("READ ");
        if ((m & ENDLESS) != 0) st.append("ENDLESS ");
        if ((m & EOF_EXCEPTION) != 0) st.append("EOF_EXCEPTION ");
        if ((m & RECOVER) != 0) st.append("RECOVER ");
        if ((m & TEMP) != 0) st.append("TEMP ");
        if ((m & LOCATE) != 0) st.append("LOCATE ");
        if ((m & ENDING_NL) != 0) st.append("ENDING_NL ");
        int s = this.status;
        if ((s & IS_OPEN) != 0) st.append("IS_OPEN ");
        if ((s & AT_EOF) != 0) st.append("AT_EOF ");
        if ((s & SPECIAL) != 0) st.append("SPECIAL ");
        if ((s & PERMANENT) != 0) st.append("PERMANENT ");
        if ((s & DIRECTORY) != 0) st.append("DIRECTORY ");
        if ((s & URI) != 0) st.append("URI ");
        if ((s & READABLE) != 0) st.append("READABLE ");
        if ((s & WRITEABLE) != 0) st.append("WRITEABLE ");
        if ((s & EXISTENT) != 0) st.append("EXISTENT ");
        if ((s & CHECK) != 0) st.append("CHECK ");
        if ((s & UNNAMED) != 0) st.append("UNNAMED ");
        if ((s & LOCATED) != 0) st.append("LOCATED ");
        if ((s & LENGTH_FINAL) != 0) st.append("LENGTH_FINAL ");
        if ((s & PENDING_EOF) != 0) st.append("PENDING_EOF ");
        if ((s & NEW_ENCODING) != 0) st.append("NEW_ENCODING ");
        if ((s & ISO8859_1) != 0) st.append("ISO8859_1 ");
        if ((s & UCS2) != 0) st.append("UCS2 ");
        if ((s & DATA_BREAK) != 0) st.append("DATA_BREAK ");
        if ((s & NL_PRESENT) != 0) st.append("NL_PRESENT ");
        if ((s & NONEMPTY) != 0) st.append("NONEMPTY ");
        return st.toString();
    }

    /* Result values and messages */

    /** The result of the last operation. */
    public int res;

    /** The exception object. */
    public IOError excObj;

    /** The error handling. On error 0: ret 1: throw 2: abort. */
    private int errthrow;

    /** On error return a status code. */
    public static final int RET_STATUS = 0;

    /** On error return an exception. */
    public static final int ERR_THROW  = 1;

    /** On error abort. */
    public static final int ERR_ABORT  = 2;

    /**
     * Create an IOError for this stream.
     *
     * @param      c error code
     * @param      e associated exception (if any);
     * @return     reference to the created object
     */

    public IOError newError(int c, Throwable e){
        long idx = -1;
        if ((IS_OPEN & this.status) != 0){
            if ((RANDOM & this.mode) != 0){
                try {
                    idx = this.randStream.getFilePointer();
                } catch (Throwable t){
                }
            } else {
                idx = this.index;
            }
        }
        return new IOError(c,e,this.path,idx,this);
    }

    /**
     * Set the error handling policy.
     *
     * @param  et kind of handling
     */

    public void setOnErr(int et){
        this.errthrow = et;
    }

    /**
     * Deliver the locale neutral message which corresponds to a given
     * error code.
     *
     * @param      c error code
     */

    private static String message(int c){
        String[] msgtab = IOBundle.MSGTAB;
        if (msgtab == null) return Integer.toString(c);
        else if (c >= 0) return msgtab[c];
        else return Integer.toString(c);
    }

    /**
     * Initialize the exception and return status.
     */

    private void excInit(){
        this.res = 0;
        this.excObj = null;
    }

    /**
     * Terminate the exception and return status.
     */

    private void excTerm(){
        if (this.res > 0){
            if (this.res != IOError.ENDOFFILE){   // a real error
                if ((NOCLOSE & this.mode) == 0){
                    try {
                        forceClose(true);         // close and recover
                    } catch (Throwable exc){
                    } finally {
                        free();
                    }
                }
            }
            signalError();
        } else {
            this.excObj = null;
        }
    }

    /**
     * Create an exception object if one is not present.
     *
     * @param      code error code
     * @param      value additional value
     * @param      pres argument indexes present
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     * @param      exc additional exception
     */

    private void registerError(int code, Throwable exc){
        if (exc instanceof OutOfMemoryError){
            try {
                forceClose(true);              // close and recover
            } catch (IOException ex){          // keep the first error
            }
        } else if (exc instanceof FileNotFoundException){
            code = IOError.ERR_NOFILE;
        } else if (exc instanceof IOException){
            String m = exc.getMessage();
            if (m != null){
                if (m.startsWith("E:0")){
                    code = IOError.ERR_NOTMAIN;
                    exc = null;
                } else if (m.startsWith("E:")){
                    code = IOError.ERR_EXECERR;
                    exc = null;
                } else if (m.equals("C")){
                    code = IOError.ERR_CIRCDEF;
                    exc = null;
                } else {
                    code = IOError.ERR_IOERR;
                }
            } else {
                code = IOError.ERR_IOERR;
            }
        }
        this.res = code;
        this.excObj = newError(code,exc);
        if ((FL_B & this.trc) != 0){
            Trc.out.println("registerError: " + message(code) +
                " " + this.errthrow);
            if (exc != null){
                Trc.out.println(exc);
            }
        }
        if ((FL_F & this.trc) != 0){
            Trc.out.println("registerError: " + code);
            if (exc != null) Trc.out.println(exc.toString());
            Throwable t = new Throwable();
            t.printStackTrace();
            System.exit(0);
        }
    }

    /**
     * Handle an error: it aborts the program or it throws an exception.
     */

    private void signalError(){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("error signal " + this.res +
                " " + this.errthrow);
        }
        if (this.errthrow == ERR_ABORT){
            if ((FL_A & this.trc) != 0){
                Trc.out.println("error abort");
            }
            this.excObj.print(System.err,Locale.getDefault(),false);
            System.exit(1);
        } else if (this.errthrow == ERR_THROW){
            if ((FL_A & this.trc) != 0){
                Trc.out.println("error throw");
            }
            this.excObj.fillInStackTrace();
            throw this.excObj;
        }
    }

    /**
     * Construct a new <code>IoStream</code>.
     */

    public IoStream(){
        this.errthrow = ERR_THROW;
        this.bufferSize = BUFFER_SIZE;
        this.lineSep = LINE_SEP.toCharArray();
        int len = this.lineSep.length;
        this.byteLineSep = new byte[len];
        for (int i = 0; i < len; i++){
            this.byteLineSep[i] = (byte)this.lineSep[i];
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("constructed " + this);
        }
    }

    /**
     * Construct a new <code>IoStream</code> with a given error handling
     * policy.
     *
     * @param      et kind of handling
     */

    public IoStream(int et){
        this();
        this.errthrow = et;
    }

    /**
     * Construct a new <code>IoStream</code> with a given default.
     *
     * @param      def default for filespec
     */

    public IoStream(String def){
        this();
        this.defaults = def;
    }

    /**
     * Construct a new <code>IoStream</code> with a given error handling
     * policy and defaults.
     *
     * @param      et kind of handling
     * @param      def defaults for filespec
     */

    public IoStream(int et, String def){
        this();
        this.errthrow = et;
        this.defaults = def;
    }

    /**
     * Construct a new <code>IoStream</code> with a given error handling
     * policy, mode and defaults.
     *
     * @param      et kind of handling
     * @param      mode mode
     * @param      def default for filespec
     */

    public IoStream(int et, int mode, String def){
        this();
        this.errthrow = et;
        this.mode = mode;
        this.defaults = def;
    }

    /**
     * Construct a new, synchronised <code>IoStream</code> with a given error
     * handling policy, mode and defaults.
     *
     * @param      et kind of handling
     * @param      mode mode
     * @param      def default for filespec
     * @param      lock null if the lock is the object itself, otherwise
     *             reference to the lock object
     */

    public IoStream(int et, int mode, String def, Object lock){
        this(et,mode,def);
        this.mutex = (lock == null) ? this : lock;
    }

    /**
     * Terminate this object. It releases all system resources and
     * deletes the file, if opened in write and not closed, or restores
     * it to its original length if opened in append and not closed.
     * Files need be closed by applications.
     */

    protected void finalize() throws Throwable {
        super.finalize();
        if ((FL_C & this.trc) != 0){
            Trc.out.println("finalize " + this);
        }
        forceClose(true);
        free();
    }

    /**
     * Deliver the path of the stream present in this object.
     *
     * @return     string of the path
     */

    public String getPath(){
        return this.path;
    }

    /**
     * Deliver the filespec of the stream present in this object.
     *
     * @return     filespec
     */

    public FileSpec getFileSpec(){
        return this.fileSpec;
    }

    /**
     * Deliver a string representataion of this object.
     *
     * @return     string
     */

    public String toString(){
        return this.path;
    }

    /**
     * Deliver the number of lines read.
     *
     * @return     number
     */

    public long lines(){
        return this.lineNum;
    }

    /**
     * Deliver the index in the file. For files which eventually have a
     * byte storage, the index is the byte index. For Readers or Writers,
     * opened in with an open by object, it is the character index.
     * The stream must be open.
     *
     * @return     index
     */

    public long index(){
        if (this.mutex != null){
            synchronized (this.mutex) {
                return getIndex();
            }
        } else {
            return getIndex();
        }
    }

    /**
     * Deliver the index in the file. For internal use.
     *
     * @return     index
     */

    private long getIndex(){
        long idx = -1;
        excInit();
        doit: try {
            if ((IS_OPEN & this.status) == 0){
                registerError(IOError.ERR_NOTOPEN,null);
                break doit;
            }
            if ((RANDOM & this.mode) == 0){   // sequential mode
                registerError(IOError.ERR_INVOP,null);
                break doit;
            }
            idx = this.randStream.getFilePointer();
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } finally {
            excTerm();
        }
        return idx;
    }

    /**
     * Deliver the mode.
     *
     * @return     mode
     */

    public int getMode(){
        return this.mode;
    }

    /**
     * Deliver the status.
     *
     * @return     status
     */

    public int getStatus(){
        return this.status;
    }

    /**
     * Deliver the encoding.
     *
     * @return     canonical name of the encoding
     */

    public String getEncoding(){
        return this.encoding;
    }

    /**
     * Deliver the length of the file. The length returned is the
     * current one, which might have been changed as a result of some
     * operation done by this or another application, except when the
     * file has been opened in interlocked mode. Note that when buffering
     * is done, the length represents the number of data actually
     * present in the file, which is the same as the data written after
     * a flush() is done. The object must at least be located.
     *
     * @return     length
     */

    public long length(){
        if (this.mutex != null){
            synchronized (this.mutex) {
                return getLength();
            }
        } else {
            return getLength();
        }
    }

    /**
     * Deliver the length of the file. For internal use.
     *
     * @return     length
     */

    private long getLength(){
        excInit();
        long len = 0;
        doit: try {
            if ((LOCATED & this.status) == 0){
                registerError(IOError.ERR_NOLOC,null);
                break doit;
            }
            if ((LENGTH_FINAL & this.status) == 0){
                if (this.file != null){       // e.g. regular files
                    if ((DIRECTORY & this.status) != 0){
                       len = 0;
                    } else {
                       len = this.file.length();
                    }
                } else if (this.urlcon != null){
                    len = this.urlcon.getContentLength();
                }
            } else {
                len = this.oldLength;
            }
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } finally {
            excTerm();
        }
        return len;
    }

    /**
     * Deliver the time of the last modification.
     *
     * @return     time
     */

    public long lastModified(){
        return this.lastModified;
    }

    /**
     * Set the time of the last modification. The file must not be
     * open (otherwise the method fails in NT).
     *
     * @param      time time to be set
     */

    public void setLastModified(long time){
        if (this.mutex != null){
            synchronized (this.mutex) {
                setLastModif(time);
            }
        } else {
            setLastModif(time);
        }
    }

    /**
     * Set the time of the last modification. For internal use.
     *
     * @param      time time to be set
     */

    private void setLastModif(long time){
        excInit();
        doit: try {
            if ((IS_OPEN & this.status) != 0){
                registerError(IOError.ERR_ISOPEN,null);
                break doit;
            }
            this.lastModified = time;
            if (this.file == null) break doit;
            boolean res = this.file.setLastModified(time);
            if (!res){
                registerError(IOError.ERR_SETTIME,null);
                break doit;
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("time: " + time);
            }
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } finally {
            excTerm();
        }
    }

    /**
     * Set the line separator. By default it is the one of the current
     * platform. It must be "\n", "\r", or "\r\n" or "" (for the last line).
     *
     * @param      s line separator
     */

    public void setLineSep(String s){
        if (this.mutex != null){
            synchronized (this.mutex) {
                setLnSep(s);
            }
        } else {
            setLnSep(s);
        }
    }

    /**
     * Set the line separator. For internal use.
     *
     * @param      s line separator
     */

    private void setLnSep(String s){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("setLnSep " + Str.strQuoted(s));
        }
        excInit();
        if (!s.equals("\n") && !s.equals("\r") &&
            !s.equals("\r\n") && !s.equals("")){
            registerError(IOError.ERR_VALUE,null);
        } else {
            this.lineSep = s.toCharArray();
            int len = this.lineSep.length;
            this.byteLineSep = new byte[len];
            for (int i = 0; i < len; i++){
                this.byteLineSep[i] = (byte)this.lineSep[i];
            }
        }
        excTerm();
    }

    /**
     * Get the line separator.
     *
     * @return     line separator
     */

    public String getLineSep(){
        return String.valueOf(this.lineSep);
    }

    /**
     * Set the filetype default. To enable filetype propagation, supply
     * a non-null (but possibly empty) default.
     *
     * @param      s defaults
     */

    public void setFileType(String s){
        if (this.mutex != null){
            synchronized (this.mutex) {
                setFty(s);
            }
        } else {
            setFty(s);
        }
    }

    /**
     * Set the filetype default. For internal use.
     *
     * @param      s defaults
     */

    private void setFty(String s){
        this.defaults = s;
        this.fileSpec = null;     // force reconstruction
    }

    /* File association methods. */

    /**
     * Determine the resultant filestring and then locates the file.
     *
     * @param      name file path
     * @exception  IOException 
     */

    /* There is a need to obtain the actual resolved full names for files
     * for reporting errors and also for propagation. This is obtained
     * with File, which translates links. There is a need to reparse the
     * result then to have the spec parsed into its components to support
     * propagation.
     * File delivers as absolute path one which contains a non-reduced
     * directory, and as canonical path one in which directories are reduced
     * and links resolved.
     * Note that the reduction of paths is not essential, and besides that,
     * it is done automatically when File derives the canonical path.
     *
     * It is not so simple to tell if a file is ordinary and not. E.g. in
     * NT "con" is seen as a regular file. This is why SPECIAL is set on
     * standard files. "/dev/tty" and "/dev/null" are not files in Unix,
     * while "con" and "nul" are files in NT.
     *
     * When the method is called with one of the predefined names for
     * standard files, it does not allocate a File because there is no
     * need for it, not even to obtain the canonical name, because it
     * is already inserted in the FileSpec by resultant().
     *
     * When an attempt is made to open a file whose name is the empty string,
     * the canonical path is a bit strange since it simply ends with the
     * directory name, which looks as a correct path, but an error is returned.
     * To have a more revealing one, a directory separator is added at the end.
     */

    private void findFile(String name) throws IOException {
        doit: {
            if ((IS_OPEN & this.status) != 0){
                registerError(IOError.ERR_ISOPEN,null);
                break doit;
            }
            this.status &= CHECK;
            if (this.fileSpec == null){          // first time
                this.fileSpec = new FileSpec(this.defaults);
            }
            this.fileSpec.resultant(name);       // remember it to propagate
            this.path = this.fileSpec.toString();
            this.file = null;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("find: " + this.path + " " + this.defaults);
            }
            this.oldLength = 0;
            this.lastModified = 0;
            this.index = 0;
            this.nrIoDone = 0;
            find: {
                normal: {
                    boolean standard = false;
                    if (this.fileSpec.isStandard()){         // cut filetype
                        standard = true;
                    }                    
                    if (name == FileSpec.STDIN){             // skip creation
                        this.status |= SPECIAL | READABLE;   // .. of a File
                        break normal;                        // when name predefined
                    } else if (name == FileSpec.STDOUT){
                        this.status |= SPECIAL | WRITEABLE;
                        break normal;
                    } else if (name == FileSpec.STDERR){
                        this.status |= SPECIAL | WRITEABLE;
                        break normal;
                    }
                    if (this.fileSpec.isURI()){         // URI specified
                        this.status |= URI;
                        break find;
                    }
                    this.file = new File(this.path);    // seek the file
                    String cano = this.path;
                    if (!standard){                     // on standard it fails
                        cano = this.file.getCanonicalPath();
                    } else if (Prg.os == Prg.WIN){
                        if (this.fileSpec.isStandard(FileSpec.STDIN)){
                            cano = "\\\\.\\con";
                        } else if (this.fileSpec.isStandard(FileSpec.STDNULL)){
                            cano = "\\\\.\\nul";
                        }
                    }
                    if (this.path.length() == 0){
                        this.path = cano +
                            System.getProperty("file.separator");
                    } else {
                        this.path = cano;
                    }
                    this.fileSpec.parseFile(this.path);
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("find: " + this.path);
                    }
                    if (isStdFile()) break normal;      // standard file
                    if (this.file.exists()){
                        this.status |= EXISTENT;
                    }
                    if (this.file.isDirectory()){
                        this.status |= DIRECTORY;
                    } else if (!this.file.isFile()){    // special file
                        if ((EXISTENT & this.status) != 0){
                            this.status |= SPECIAL;
                        }
                    }
                    if (this.file.canRead()){
                        this.status |= READABLE;
                    }
                    if (this.file.canWrite()){
                        this.status |= WRITEABLE;
                    }
                    this.oldLength = this.file.length();
                    if ((FL_C & this.trc) != 0){
                        Trc.out.println("find length: " + this.file.length());
                    }
                    this.lastModified = this.file.lastModified();
                    break find;
                }
                this.status |= EXISTENT | PERMANENT;
            }
            this.status |= LOCATED;
        }//doit
        if ((FL_B & this.trc) != 0){
            Trc.out.println("find res: " + this.res + " " +
                trcmode());
        }
    }

    /**
     * Determine if the current filespec denotes a standard file and
     * if must be treated as a normal file or not.
     *
     * @return     <code>true</code> if it is a special file
     */

    private boolean isStdFile(){
        boolean res = false;
        if (this.fileSpec.isStandard(FileSpec.STDIN)){
            this.status |= SPECIAL | READABLE;
            res = true;
        }
        if (this.fileSpec.isStandard(FileSpec.STDOUT)){
            this.status |= SPECIAL | WRITEABLE;
            res = true;
        }
        if (this.fileSpec.isStandard(FileSpec.STDERR)){
            this.status |= SPECIAL | WRITEABLE;
            res = true;
        }
        if (this.fileSpec.isStandard(FileSpec.STDTTY)){
            this.status |= SPECIAL | READABLE | WRITEABLE |
                PERMANENT | EXISTENT;               // EXISTENT for NT
        }
        if (this.fileSpec.isStandard(FileSpec.STDNULL)){
            this.status |= SPECIAL | READABLE | WRITEABLE |
                PERMANENT | EXISTENT;               // EXISTENT for NT
        }
        return res;
    }

    /**
     * Determine the resultant filestring and then locate the file.
     *
     * @param      name file path
     */

    public void find(String name){
        if (this.mutex != null){
            synchronized (this.mutex) {
                findLocate(name);
            }
        } else {
            findLocate(name);
        }
    }

    /**
     * Locates the file. For internal use.
     *
     * @param      name file path
     */

    private void findLocate(String name){
        excInit();
        doit: try {
            findFile(name);
            if (this.res != 0) break doit;       // error
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (IOError exc){
        } finally {
            excTerm();
        }
    }

    /* File handling methods. */

    /* Status of the IoStream object
     *
     * This is the object model:
     *
     *     ,-------------------------------open----v         ,---. read, write
     *  (free)---find--->(file handling)---open-->(data trasfer) | skip, seek,
     *    ^ ^--close-----' ^-length-'  ^---close------' |    ^---' flush, etc.
     *    |              delete, rename                 |
     *    `----------------close------------------------'
     *
     * Open(), delete(), etc. require that the object does not denote an
     * open file. This is so because they all imply a find(), which
     * change the contents of the object, that then may no longer be used to
     * close the previous file.
     * This is consistent with the correct usage of a file, which needs be
     * closed at the end.
     * A status flag signals that the find has been done to let the other
     * methods, when called with a null filespec, operate on the file which
     * is associated there.
     * 
     * Since standard files have no File, it is not possible to use the
     * file field to determine if the file is open. A status flag is used.
     * All mode and status flags last between find()/open() and close(), except
     * for CHECKED and CHECK, which are not cleared by close().
     *
     * Attributes of files in filesystems
     *
     * Files in Unix and NT filesystems have no attributes telling their
     * format, i.e. if they are character files or not, the encoding, etc.
     * In open there is a need to pass a set of file attributes that tell what
     * kind of file is to be opened.
     * Unfortunately that means that a filespec string is not sufficient to
     * open correctly a file. This implies that all classes which can open
     * files should receive also some extra data.
     * It would be wonderful to add this to the filespec, but there is no
     * way to do it without reducing the set of characters that can be part
     * of filespecs.
     *
     * Protections
     *
     * The actual protection of the files which are created in Unix is
     * determined by the umask and the permissions of an existing file
     * with that name (if any).
     * There is little support to change it in Java. FilePermissions is of
     * no use since it has no external effect. The only one method which
     * works is File.setReadOnly(). There woud be a need to use an exec()
     * of a chmod in Unix and an attrib for NT.
     *
     * Open by object
     *
     * The stream from which a program is run (directory, jar file) can
     * not be denoted by a constant as it is for the standard files.
     * That is so because it is a logical name that denotes the directory
     * or jar file to which the name of the file to be opened must be
     * appended, and for this a constant is of little use.
     * STDIN, etc. are FileSpec constants, which is somehow more internal
     * than IoStream, but that is not important.
     * When an input is given and an output as well, they should be related
     * somehow. However, since there is no simple rule to test this, no
     * check is done.
     * Interlocked mode is not allowed for open by object since the lenght
     * is not known.
     *
     * Filters
     *
     * It is conceivable to provide an open with a Class parameter that tells
     * the filter to create. This is another way to tell the kind of the file.
     * However, since there are many classes, which can also be subclassed by
     * the caller, and since the creation of such wrappers can have also
     * specialised parameters, that is left to applications.
     *
     * Handles
     *
     * Since there are files that allow to be opened in read and write
     * at the same time, fields for readers and writers, both for character
     * and byte transfer, and for random access are provided.
     *
     * Kind of files / streams
     *
     * Mail is not yet supported because it requires Java.mail, which is
     * not yet integrated in JDK.
     * Jar files: it is not yet possible to write them, but that is less
     * important. The construction of a java archive is something which
     * is rarely done by an application. It is more commonly done by using
     * the jar utility.
     *
     * Sockets
     *
     * From the client side, they act as devices on which it is possible
     * to read and write. From the server side they act as drivers, and the
     * implementation of them need not be done with IoStream.
     * Sockets are recognised as distinguished streams because there is a
     * need to close them when the stream is closed.
     *
     * URIs
     *
     * In output, there is a need to encode some data with the URLEncoder.
     * In input, there is a need to decode them, but that is a problem for a
     * HTTP server. This applies only to some specific parts, like e.g. query
     * strings and fields in forms.
     * According to the RFC, escapes should also be used in URIs (specs).
     * Note that there is no workaround for the JDK bug on treating HTTP
     * escapes: simply the reserver characters may not be used.
     * The handling of the HTTP in java.net is rather peculiar: it is not
     * allowed to do anything in input before having completed output because
     * any input action causes the completion of the output, likely the
     * sending of an empty message. Moerover, it is not allowed to perform
     * output after input. The only way to perform input after output is to
     * use the same connection. For these reasons, IoStream does not allow
     * to open them in r/w.
     *
     * Protections
     *
     * File handling state methods can be provided to get and set permissions,
     * as well as parameters in open to set them at creation time.
     * Since there are no java methods to do it, there is a need to exec
     * commands.  Protection objects can be used to specify them if they do
     * not prove to be to bulky. Alternatively, strings similar to the Unix
     * chmode command can be used.
     * This is how protection works in Unix:
     *
     *   - file creation: if the file does not exist, protections is:
     *     a=rw & umask, otherwise the existing protections. I.e. having a
     *     file with no write permissions prevents its rewriting.
     *     Thus, a create is indeed a (re)write when the file exists.
     *     When a file has write permission, it can be written, i.e. new data
     *     witten in it, possibly on top of the existing ones or at the end.
     *     In other words it can be updated.
     *     When a new file need be created, which does not yet exist, there
     *     is a need for write permissions on the directory.
     *   - file delete: to delete a file, it must have write permissions on it
     *     and also on the directory.
     *   - write permission on normal files allows write and delete, on
     *     directories allows insertion and removal of entries.
     *   - execute permisions on directories allows directory search.
     *   - read permissions allow to read files and list directories.
     *   - system accounts have no restrictions.
     *
     *   This is how they work in NT:
     *
     *   - file creation: the protection is "A" = archive, regardless on
     *     whether the file existed.
     *   - file deletion: allowed if the file is not read only.
     *   - no permission other than readonly is supported.
     *
     * Note that there are systems which support more powerful and flexible
     * permission schemes such as: read/write/execute/delete on sytem/group/
     * owner/world users, and Access Control Lists.
     * IoStream does not provide operations on file security in general.
     *
     * Locking
     *
     * Some filesystems provide record locking. This is a rather primitive
     * technique to guarantee exclusive access to records. It is not provided
     * by java.io, and it would be quite difficult for IoStream to provide
     * it on top of java.io.
     * Moreover, some filesystems support allocation of sequential devices.
     * This requires the availability of a lock manager, which in a networked
     * environment must become a network lock manager.
     * This is beyond the scope of IoStream.
     *
     * Synchronization
     *
     * When there is a need to have IoStream's which are used by several
     * threads at the same time, those objects must be thread-safe, i.e.
     * theis methods synchronised. This is obtained by a dedicated constructor.
     */

    /**
     * Delete the file currently referred to by this object.
     */

    public void delete(){
        delete(null);
    }

    /**
     * Delete this file. Deletion is not performed if the file is a
     * permanent one, a URI or a special file. If the file does not exits
     * it does not return an error.
     *
     * @param      name filespec of the file to be deleted
     */

    public void delete(String name){
        if (this.mutex != null){
            synchronized (this.mutex) {
                deleteFile(name);
            }
        } else {
            deleteFile(name);
        }
    }

    /**
     * Delete this file. For internal use.
     *
     * @param      name filespec of the file to be deleted
     */

    private void deleteFile(String name){
        excInit();
        doit: try {
            if (name != null){
                findFile(name);
                if (this.res != 0) break doit;       // error
            }
            if ((LOCATED & this.status) == 0){
                registerError(IOError.ERR_NOLOC,null);
                break doit;
            }
            if ((PERMANENT & this.status) != 0) break doit;
            if ((SPECIAL & this.status) != 0) break doit;
            if ((URI & this.status) != 0) break doit;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("delete: " + this.file);
            }
            this.file.delete();
            this.lastModified = 0;
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (IOError exc){
        } finally {
            excTerm();
        }
    }

    /**
     * Rename the file currently referred to by this object.
     *
     * @param      newname new name
     */

    public void rename(String newname){
        rename(null,newname);
    }

    /**
     * Rename this file. Renaming is rejected if the file does not exist,
     * or it is a permanent one, a URI, or a special file. It propagates
     * the filespec onto the new one.
     * If a file whose name is equal to <code>newname</code> exists,
     * it is deleted.
     *
     * @param      oldname filespec of the file to be renamed
     * @param      newname new name
     */

    public void rename(String oldname, String newname){
        if (this.mutex != null){
            synchronized (this.mutex) {
                renameFile(oldname,newname);
            }
        } else {
            renameFile(oldname,newname);
        }
    }

    /**
     * Rename this file. For internal use.
     *
     * @param      oldname filespec of the file to be renamed
     * @param      newname new name
     */

    private void renameFile(String oldname, String newname){
        excInit();
        doit: try {
            if (oldname != null){
                findFile(oldname);
                if (this.res != 0) break doit;       // error
            }
            if ((LOCATED & this.status) == 0){
                registerError(IOError.ERR_NOLOC,null);
                break doit;
            }
            if ((EXISTENT & this.status) == 0){
                registerError(IOError.ERR_NOFILE,null);
                break doit;
            }
            if (((PERMANENT & this.status) != 0) ||
                ((SPECIAL & this.status) != 0) ||
                ((URI & this.status) != 0)){
                registerError(IOError.ERR_INVOP,null);
                break doit;
            }
            this.originFile = this.file;
            long lastModified = this.lastModified;
            int status = this.status;
            findFile(newname);
            if (this.res != 0) break doit;           // error
            if ((FL_B & this.trc) != 0){
                Trc.out.println("rename: " + this.file +
                    " " + this.originFile);
            }
            boolean rena = this.originFile.renameTo(this.file);
            if (!rena){                              // in NT rename fails
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("rename, try delete");
                }
                this.file.delete();                  // when the file exists
                rena = this.originFile.renameTo(this.file);
                if (!rena){
                    registerError(IOError.ERR_RENAME,null);
                    break doit;
                }
            }
            this.lastModified = lastModified;
            this.status = status;
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (IOError exc){
        } finally {
            excTerm();
        }
    }

    /**
     * Create the directories currently referred to by this object.
     */

    public void mkdir(){
        mkdir(null);
    }

    /**
     * Create the directories currently referred to by this object.
     * Creation is not performed if the name denotes a permanent file,
     * a URI or a special file.
     * Creation of directories that exist is rejected if NOREWRITE is
     * in effect.
     *
     * @param      name filespec of the directory to be created
     */

    public void mkdir(String name){
        if (this.mutex != null){
            synchronized (this.mutex) {
                createDir(name);
            }
        } else {
            createDir(name);
        }
    }

    /**
     * Create this directory. For internal use.
     *
     * @param      name filespec of the directory to be created
     */

    private void createDir(String name){
        excInit();
        doit: try {
            if (name != null){
                findFile(name);
                if (this.res != 0) break doit;       // error
            }
            if ((LOCATED & this.status) == 0){
                registerError(IOError.ERR_NOLOC,null);
                break doit;
            }
            if ((DIRECTORY & this.status) != 0) break doit;
            if ((PERMANENT & this.status) != 0) break doit;
            if ((SPECIAL & this.status) != 0) break doit;
            if ((URI & this.status) != 0) break doit;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("mkdir: " + this.file);
            }
            boolean created = this.file.mkdirs();
            if (((NOREWRITE & this.mode) != 0) && !created){
                registerError(IOError.ERR_INVOP,null);
            }
            this.fileSpec.parseFile(this.path);    // make it a directory
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (IOError exc){
        } finally {
            excTerm();
        }
    }

    /**
     * Deliver the list of files of the directory of this object.
     */

    public String[] dirList(){
        return dirList(null);
    }

    /**
     * Deliver the list of files of the directory of this object.
     * If the object is a directory, its list is delivered, if it is
     * a file, the list of the directory in which it is contained.
     *
     * @param      name filespec
     */

    public String[] dirList(String name){
        String[] res = null;
        if (this.mutex != null){
            synchronized (this.mutex) {
                res = directoryList(name);
            }
        } else {
            res = directoryList(name);
        }
        return res;
    }

    /**
     * Deliver the list of files of the directory of this object.
     * For internal use.
     *
     * @param      name filespec of the directory to be created
     */

    private String[] directoryList(String name){
        excInit();
        String[] res = null;
        doit: try {
            if (name != null){
                findFile(name);
                if (this.res != 0) break doit;       // error
            }
            if ((LOCATED & this.status) == 0){
                registerError(IOError.ERR_NOLOC,null);
                break doit;
            }
            if ((PERMANENT & this.status) != 0) break doit;
            if ((SPECIAL & this.status) != 0) break doit;
            if ((URI & this.status) != 0) break doit;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("list: " + this.file);
            }
            File d = this.file;
            if ((this.status & DIRECTORY) == 0){
                d = d.getParentFile();
            }
            if (d == null){
                registerError(IOError.ERR_NOLOC,null);
            }
            res = d.list();
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (IOError exc){
        } finally {
            excTerm();
        }
        return res;
    }

    /**
     * Register the interlocked streams. The array of IoStream objects is
     * registered into this one as the ones which are interlocked with it
     * for simultaneous opening.
     *
     * @param      arr array of IoStream objects
     */

    /* The interlocked mode, allows to handle the cases in which an input
     * IoStream is used to open files which are also opened at the same
     * time in write or append. In the input object a list to such other
     * IoStream objects is kept. When an object is opened in append, the
     * origin length at the time it was opened is saved. This is done always
     * even when there is no interlock. When a file is opened in read, a check
     * is made to see if that file in opened also in append by one of the
     * IoStream objects in the array. In such a case, the length of the file
     * is taken to be the saved one, i.e. the data which have been written in
     * the meantime are not considered.
     * When a file is opened in write, its contents is lost. To keep it,
     * it is created with a temporary name and renamed at the time it is
     * closed. This cannot be done always because when an application wants
     * to use a file to write data which are read by another application as
     * they are produced, the name must be given at open time, and not at
     * close time. However, when an array of interlocked object is registered,
     * the objects in the array are marked as NAME_CLOSE. If there is an array
     * already present, the objects in it are unmarked before replacing the
     * array.
     * The basic idea is to allow to open in write/append a file and at the
     * same time make a snapshot of the file before open, so as to allow an
     * input IoStream access them.
     * The typical use is to interlock the object, then to open the output
     * first and then the input, which could be a sequence of files.
     */

    public void interLock(IoStream[] arr){
        if (this.mutex != null){
            synchronized (this.mutex) {
                setInterLock(arr);
            }
        } else {
            setInterLock(arr);
        }
    }

    /**
     * Register the interlocked streams. For internal use.
     *
     * @param      arr array of IoStream objects
     */

    private void setInterLock(IoStream[] arr){
        excInit();
        doit: try {
            if (this.intLock != null){
                for (int i = 0; i < this.intLock.length; i++){
                    this.intLock[i].mode &= ~NAME_CLOSE;
                }
            }
            this.intLock = arr;
            if (this.intLock != null){
                for (int i = 0; i < this.intLock.length; i++){
                    if ((IS_OPEN & this.intLock[i].status) != 0){
                        registerError(IOError.ERR_ISOPEN,
                            new IOException(this.intLock[i].path));
                        break doit;
                    }
                    this.intLock[i].mode |= NAME_CLOSE;
                }
            }
        } finally {
            excTerm();
        }
    }

    /**
     * Open a file for reading, writing or both.
     * If this object refers to an open file, it returns an error.
     * The filespec of the file is obtained by taking the one contained
     * in this object as a base for the one passed as argument.
     * When <code>name</code> is null, the file whose filespec is contained
     * in the current object is open.
     *
     * @param      name file path
     * @param      enc encoding
     * @param      mode open mode
     */
 
    /* Temporary NAME_CLOSE files have a filetype which may not be
     * accidentally replicated.
     */
 
    private void openrw(String name, String enc, int mode){
        if (this.mutex != null){
            synchronized (this.mutex) {
                openStream(name,enc,mode);
            }
        } else {
            openStream(name,enc,mode);
        }
    }

    /**
     * Open a file for reading, writing or both. For internal use.
     *
     * @param      name file path
     * @param      enc encoding
     * @param      mode open mode
     */

    private void openStream(String name, String enc, int mode){
        excInit();
        doit: try {
            this.mode |= mode;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("open: " + enc + " " + trcmode());
            }
            if (((READ | WRITE | APPEND) & mode) == 0){
                registerError(IOError.ERR_INVOP,null);
                break doit;
            }
            if (name != null){
                findFile(name);
                if (this.res != 0) break doit;       // error
            }
            if ((LOCATED & this.status) == 0){
                registerError(IOError.ERR_NOLOC,null);
                break doit;
            }

            this.readerStream = null;
            this.writerStream = null;
            this.inStream = null;
            this.outStream = null;
            this.randStream = null;
            this.decoder = null;
            this.inAdapt = null;
            this.ouAdapt = null;
            long len = 0;

            boolean rand = false;
            opn: {
                if ((RANDOM & this.mode) != 0){
                    if ((((SPECIAL | DIRECTORY | URI) & this.status) != 0) ||
                        (this.iter != null)){
                        registerError(IOError.ERR_ILLFILE,null);
                        break doit;
                    }
                    String rmode = "r";
                    if (((WRITE | APPEND) & this.mode) != 0){
                        rmode = "rw";
                        create();
                        if (this.res != 0) break doit;
                    }
                    RandomAccessFile r =
                        new RandomAccessFile(this.file,rmode);
                    this.randStream = r;
                    this.mode |= BYTES | CHARS | AUTOFLUSH;
                    len = r.length();
                    if ((APPEND & this.mode) != 0){
                        r.seek(len);
                        this.index = len;
                    }
                    this.oldLength = len;                 // remember length
                    rand = true;
                    break opn;
                }
                if ((this.fileSpec.isStandard(FileSpec.STDIN)) ||
                    (this.fileSpec.isStandard(FileSpec.STDOUT))){
                    if ((READ & this.mode) != 0){
                        this.inStream = System.in;        // standard input
                        this.status |= READABLE;
                    } else {
                        if (this.fileSpec.isStandard(FileSpec.STDIN) &&
                            !this.fileSpec.isStandard(FileSpec.STDTTY)){
                            registerError(IOError.ERR_ILLFILE,null);
                            break doit;
                        }
                    }
                    if (((WRITE | APPEND) & this.mode) != 0){
                        this.outStream = System.out;      // standard output
                        this.status |= WRITEABLE | ISPRINT;
                    } else {
                        if (this.fileSpec.isStandard(FileSpec.STDOUT) &&
                            !this.fileSpec.isStandard(FileSpec.STDTTY)){
                            registerError(IOError.ERR_ILLFILE,null);
                            break doit;
                        }
                    }
                    this.mode |= BYTES;
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("open standard input/output");
                    }
                    break opn;
                }
                if (this.fileSpec.isStandard(FileSpec.STDERR)){
                    if ((READ & this.mode) != 0){
                        if (!this.fileSpec.isStandard(FileSpec.STDTTY)){
                            registerError(IOError.ERR_ILLFILE,null);
                            break doit;
                        }
                    }
                    if (((WRITE | APPEND) & this.mode) != 0){
                        this.outStream = System.err;      // standard error
                        this.status |= WRITEABLE | ISPRINT;
                    }
                    this.mode |= BYTES;
                    break opn;
                }
                if (this.fileSpec.isURI()){               // URI specified
                    if (!this.fileSpec.getScheme()
                        .equalsIgnoreCase("tcp")){
                        if ((((WRITE | APPEND) & this.mode) != 0) ==
                            ((READ & this.mode) != 0)){       // r/w
                            registerError(IOError.ERR_ILLFILE,null);
                            break doit;
                        }
                        URL u = new URL(this.path);
                        this.urlcon = u.openConnection();
                        if (((WRITE | APPEND) & this.mode) != 0){
                            this.urlcon.setDoOutput(true);    // output first
                            this.status |= WRITEABLE;
                            this.outStream = this.urlcon.getOutputStream();
                        }
                        if ((READ & this.mode) != 0){         // then input
                            this.status |= READABLE;
                            this.urlcon.setDoInput(true);
                            this.inStream = this.urlcon.getInputStream();
                            this.oldLength = this.urlcon.getContentLength();
                            this.lastModified = this.urlcon.getLastModified();
                        }
                    } else {                              // socket specified
                        String auth = this.fileSpec.getAuthority();
                        int h = auth.lastIndexOf(':');
                        String host = auth;
                        int port = 0;
                        if (h >= 0){
                            host = auth.substring(0,h);
                            String p = auth.substring(h+1,auth.length());
                            try {
                                port = Integer.parseInt(p);
                            } catch (NumberFormatException ex){
                                registerError(IOError.ERR_ILLFILE,ex);
                                break doit;
                            }
                        }
                        if ((FL_C & this.trc) != 0){
                            Trc.out.println("open socket: " +
                                host + ":" + port);
                        }
                        this.socket = new Socket(host,port);
                        if (((WRITE | APPEND) & this.mode) != 0){
                            this.status |= WRITEABLE;
                            this.outStream = this.socket.getOutputStream();
                        }
                        if ((READ & this.mode) != 0){
                            this.status |= READABLE;
                            this.inStream = this.socket.getInputStream();
                        }
                    }
                    this.mode |= BYTES;
                    this.status |= EXISTENT;
                    break opn;
                }
                if (this.file.isDirectory()){
                    registerError(IOError.ERR_ILLFILE,null);
                    break doit;
                }
                if (((PERMANENT & this.status) != 0) ||   // no name close on
                    ((SPECIAL & this.status) != 0)){      // .. these
                    this.mode &= ~NAME_CLOSE;
                }
                if ((WRITE & this.mode) != 0){            // create a new one
                    if ((NAME_CLOSE & this.mode) != 0){   // created with a tmp name
                        this.originFile = this.file;
                        File dir = this.file.getParentFile();
                        if (dir == null){
                            dir = new File(System.getProperty("user.dir"));
                        }
                        String fn = this.fileSpec.getFilename();
                        if (fn == null) fn = "";
                        // in XP control characters not allowed
                        // if (fn.length() < 3) fn += "\2\2\2";
                        if (fn.length() < 3) fn += "---";
                        this.file = File.createTempFile
                            // (fn,".\1\1\1",dir);
                            (fn,".---",dir);
                        this.status |= UNNAMED;
                        if ((FL_B & this.trc) != 0){
                            Trc.out.println("create: as temporary " +
                                this.file.getPath());
                        }
                    } else {
                        create();
                        if (this.res != 0) break doit;
                    }
                    this.outStream = new FileOutputStream(this.file);
                } else if ((APPEND & this.mode) != 0){     // append
                    this.outStream = new FileOutputStream(this.path,true);
                }
                if ((READ & this.mode) != 0){              // n.b. after write to ..
                    this.inStream = new FileInputStream(this.file);  // create first
                }                                          // .. the file when r/w
                this.mode |= BYTES;
            } // opn
            if (this.intLock != null){
                if (((WRITE | APPEND | RANDOM) & this.mode) != 0){
                    registerError(IOError.ERR_INVOP,null);
                    break doit;
                }
                if ((READ & this.mode) != 0){
                    for (int i = 0; i < this.intLock.length; i++){
                        if (this.path.equals(this.intLock[i].path)){
                            this.oldLength = this.intLock[i].oldLength;
                            this.status |= LENGTH_FINAL;
                        }
                    }
                }
            }
            setDefaultEncoding();
            if ((enc != null) ||                     // implied
                ((CHARS & mode) != 0)){              // CHARS in argument
                this.mode &= ~BYTES;
                this.mode |= CHARS;
                boolean wrap = true;
                if ((enc == null) || (enc.equals(this.encoding))){
                    if ((this.fileSpec.isStandard(FileSpec.STDOUT)) ||
                        (this.fileSpec.isStandard(FileSpec.STDERR))){
                        wrap = false;
                    }
                }
                if (enc != null){
                    setEncod(enc);
                }
                ctb: if ((READ & this.mode) != 0){
                    if (((ISO8859_1 | UCS2) & this.status) != 0){   // direct handling
                        break ctb;
                    }
                    InputStream ist = this.inStream;
                    if ((LENGTH_FINAL & this.status) != 0){
                        this.inAdapt = new InAdapter();
                        ist = this.inAdapt;
                    } else if ((RANDOM & this.mode) != 0){
                        createInAdapter();
                        break ctb;
                    }
                    InputStreamReader isr =
                        new InputStreamReader(ist,this.encoding);
                    this.readerStream = isr;
                    this.encoding = isr.getEncoding();
                }
                btc: if ((((WRITE | APPEND) & this.mode) != 0) && wrap){
                    if (((ISO8859_1 | UCS2) & this.status) != 0){   // direct handling
                        break btc;
                    }
                    OutputStream ost = this.outStream;
                    if ((RANDOM & this.mode) != 0){
                        ost = new OutAdapter();
                    }
                    OutputStreamWriter osw =
                        new OutputStreamWriter(ost,this.encoding);
                    this.writerStream = osw;
                    this.encoding = osw.getEncoding();
                }
            } else {
                this.status &= ~(ISO8859_1 | UCS2);
            }
            this.status |= IS_OPEN;
            if ((READ & this.mode) != 0){
                if ((CHECKED & this.mode) != 0){     // access check
                    if (!makeCheck()){
                        registerError(IOError.ERR_MISMATCH,null);
                        break doit;
                    }
                }
            }
            this.lineNum = 0;
            ensureBuffers();
            if ((FL_C & this.trc) != 0){
                Trc.out.println("oldLength: " + this.oldLength + " " +
                    " length: " + len + " " + this.inAdapt +
                    " " + this.decoder + " " + this.ouAdapt);
            }
            if ((SPECIAL & this.status) != 0){
                this.mode |= AUTOFLUSH;
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("opened: " + this.path);
            }
        } catch (MalformedURLException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (FileNotFoundException exc){
            registerError(IOError.ERR_NOFILE,exc);
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (UnknownHostException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (IllegalArgumentException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (IOError exc){
        } finally {
            if ((FL_B & this.trc) != 0){
                Trc.out.println("open exit: " + this.res + " " + trcmode());
            }
            excTerm();
        }
    }

    /**
     * Create a file. The file is a temporary one if TEMP is in effect,
     * otherwise it is a normal one, and then the rewriting of an existing
     * file is rejected if NOREWRITE is in effect.
     *
     * @exception  IOException, IllegalArgumentException
     */

    private void create() throws IOException, IllegalArgumentException {
        if ((TEMP & this.mode) != 0){
            File dir = this.file.getParentFile();
            if (dir == null){
                dir = new File(System.getProperty("user.dir"));
            }
            this.file = this.file.createTempFile(
                this.fileSpec.getFilename(),null,dir);
            this.path = this.file.getCanonicalPath();
            if ((FL_C & this.trc) != 0){
                Trc.out.println("create: temporary " +
                    dir + " " +
                    this.fileSpec.getFilename() + " " +
                    this.file);
            }
        } else {
            boolean created = this.file.createNewFile();
            if ((FL_C & this.trc) != 0){
                Trc.out.println("create: " + created);
            }
            if (((NOREWRITE & this.mode) != 0) && !created){
                registerError(IOError.ERR_INVOP,null);
            }
        }
    }

    /**
     * Set the default encoding.
     */

    private void setDefaultEncoding(){
        setEncod(System.getProperty("file.encoding"));
    }

    /**
     * Set an encoding. It recognizes the ones which have a special
     * handling.
     *
     * @param      enc encoding
     */
 
    private void setEncod(String enc){
        this.encoding = enc;
        this.status &= ~(ISO8859_1 | UCS2);
        if (enc.startsWith("8859")){
            this.encoding = "ISO" + enc;
            this.status |= ISO8859_1;
        } else if (enc.equals("ISO8859_1")){
            this.status |= ISO8859_1;
        } else if (enc.equals("UCS2")){
            this.status |= UCS2;
        }
        if ((FL_D & this.trc) != 0){
            Trc.out.println("setEncod " + this.encoding);
        }
    }

    /**
     * Open the file located in this object for reading.
     *
     * @see        #open(String,String,int)
     */
 
    public void open(){
        openrw(null,null,READ);
    }

    /**
     * Open the file located in this object for reading or writing.
     *
     * @see        #open(String,String,int)
     */
 
    public void open(int mode){
        if (((WRITE | APPEND) & mode) == 0){
            openrw(null,null,mode | READ);
        } else {
            openrw(null,null,mode);
        }
    }

    /**
     * Open a file for reading.
     *
     * @see        #open(String,String,int)
     */
 
    public void open(String name){
        openrw(name,null,READ);
    }

    /**
     * Open a file for reading or writing.
     *
     * @see        #open(String,String,int)
     */
 
    public void open(String name, int mode){
        if (((WRITE | APPEND) & mode) == 0){
            openrw(name,null,mode | READ);
        } else {
            openrw(name,null,mode);
        }
    }

    /**
     * Open a file for reading or writing.
     *
     * @param      name file path
     * @param      enc encoding
     * @param      mode open mode
     */
 
    public void open(String name, String enc, int mode){
        if (((WRITE | APPEND) & mode) == 0){
            openrw(name,enc,mode | READ);
        } else {
            openrw(name,enc,mode);
        }
    }

    /**
     * Open an object for reading, writing or both.
     *
     * @see        #open(String,Object,Object,int)
     */
 
    public void open(String name, Object io, int mode){
        open(name,io,io,mode);
    }

    /**
     * Open an object for reading, writing or both. The parameter
     * <code>mode</code> allows to specify the properties of the
     * object such as <code>SPECIAL</code>, etc. This objct is opened
     * in read or write according to the class of <code>io</code>,
     * and the <code>mode</code> argument, which must either specify
     * a mode which is allowed by the file or specify no mode.
     * The object must not be in interlocked mode. When the file is
     * the standard input, output or error, its attributes are set
     * implicitly.
     *
     * @param      name name of the object
     * @param      inp input object
     * @param      out output object
     * @param      mode properties of the object
     */
 
    public void open(String name, Object inp, Object out, int mode){
        if (this.mutex != null){
            synchronized (this.mutex) {
                openStream(name,inp,out,mode);
            }
        } else {
            openStream(name,inp,out,mode);
        }
    }

    /**
     * Open an object for reading, writing or both. For internal use.
     *
     * @param      name name of the object
     * @param      inp input object
     * @param      out output object
     * @param      mode properties of the object
     */

    private void openStream(String name, Object inp, Object out, int mode){
        excInit();
        if ((FL_B & this.trc) != 0){
            Trc.out.println("open: " + trcmode());
        }
        doit: try {
            if ((IS_OPEN & this.status) != 0){
                registerError(IOError.ERR_ISOPEN,null);
                break doit;
            }
            if (this.intLock != null){
                registerError(IOError.ERR_INVOP,null);
                break doit;
            }
            this.encoding = null;

            this.readerStream = null;
            this.writerStream = null;
            this.inStream = null;
            this.outStream = null;
            this.randStream = null;
            this.decoder = null;
            this.inAdapt = null;
            this.ouAdapt = null;

            this.mode |= mode & ~(BYTES | CHARS);
            this.status = 0;
            if ((inp instanceof Reader) ||           // input object
                (inp instanceof InputStream)){
                if (((WRITE | APPEND) & this.mode) != 0){
                    registerError(IOError.ERR_ILLFILE,null);
                    break doit;
                }
                this.mode |= READ;
            }
            if ((out instanceof Writer) ||           // output object
                (out instanceof OutputStream)){
                if (((NAME_CLOSE | READ | APPEND) &
                    this.mode) != 0){
                    registerError(IOError.ERR_ILLFILE,null);
                    break doit;
                }
                this.mode |= WRITE;
            }
            this.status |= EXISTENT | READABLE | LOCATED;
            this.path = name;                        // set attributes
            long len = 0;
            this.oldLength = 0;
            this.lastModified = 0;
            this.index = 0;
            this.nrIoDone = 0;
            setDefaultEncoding();
            this.status &= ~(ISO8859_1 | UCS2);      // no direct handling
            if (out instanceof PrintStream){         // Printstream
                this.outStream = (PrintStream)out;
                this.mode |= BYTES | CHARS;
                this.status |= ISPRINT;
            } else if (out instanceof OutputStream){ // byte output stream
                this.outStream = (OutputStream)out;
                this.mode |= BYTES;
                if (out instanceof BufferedOutputStream){
                    this.status |= ISBUFSTREAM;
                }
            } else if (out instanceof Writer){       // character output stream
                this.writerStream = (Writer)out;
                this.mode |= CHARS;
                if (out instanceof OutputStreamWriter){
                    this.encoding = ((OutputStreamWriter)out)
                        .getEncoding();
                }
                if (out instanceof BufferedWriter){
                    this.status |= ISBUFWRITER;
                }
            } else if (inp != out){
                registerError(IOError.ERR_ILLFILE,null);
                break doit;
            }
            if (inp instanceof InputStream){         // byte input stream
                this.inStream = (InputStream)inp;
                this.mode |= BYTES;
            } else if (inp instanceof Reader){       // character input stream
                this.readerStream = (Reader)inp;
                this.mode |= CHARS;
                if (out instanceof InputStreamReader){
                    this.encoding = ((InputStreamReader)inp)
                        .getEncoding();
                }
            } else if (inp instanceof RandomAccessFile){
                this.randStream = (RandomAccessFile)out;
                this.mode |= BYTES | CHARS | RANDOM | AUTOFLUSH;
                RandomAccessFile r = (RandomAccessFile)out;
                len = r.length();
                if ((APPEND & this.mode) != 0){
                    r.seek(len);
                    this.index = len;
                }
                this.oldLength = len;                 // remember length
            } else if (inp != out){
                registerError(IOError.ERR_ILLFILE,null);
                break doit;
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("open stream: " + this.inStream +
                    " " + this.outStream + " " + this.readerStream +
                    " " + this.writerStream + " " + this.randStream);
            }
            this.status |= IS_OPEN | PERMANENT;    // prevent close()
            this.lineNum = 0;
            ensureBuffers();
            if ((SPECIAL & this.status) != 0){
                this.mode |= AUTOFLUSH;
            }
            this.file = null;
            this.fileSpec = null;
            boolean nulpath = (this.path == null) ||
                (this.path.length() == 0);
            if (inp == System.in){
                if (nulpath) this.path = FileSpec.STDIN;
            } else if (out == System.out){
                this.status |= ISPRINT;
                this.mode |= AUTOFLUSH;
                if (nulpath) this.path = FileSpec.STDOUT;
            } else if (out == System.err){
                this.status |= ISPRINT;
                this.mode |= AUTOFLUSH;
                if (nulpath) this.path = FileSpec.STDERR;
            }
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } finally {
            if ((FL_B & this.trc) != 0){
                Trc.out.println("open exit: " + trcmode());
            }
            excTerm();
        }
    }

    /**
     * Deliver a reference to the File of this object. The object must at
     * least be located.
     *
     * @return     File
     */

    public File getFile(){
        if (this.mutex != null){
            synchronized (this.mutex) {
                return getFileRef();
            }
        } else {
            return getFileRef();
        }
    }

    /**
     * Deliver a reference to the File of this object. For internal use.
     *
     * @return     File
     */

    private File getFileRef(){
        excInit();
        if ((LOCATED & this.status) == 0){  // the file is not located
            registerError(IOError.ERR_INVOP,null);
        }
        excTerm();
        return this.file;
    }

    /**
     * Deliver a reference to the URL connection of this object.
     *
     * @return     URL connection
     */

    public URLConnection getURLcon(){
        if (this.mutex != null){
            synchronized (this.mutex) {
                return getURLconnect();
            }
        } else {
            return getURLconnect();
        }
    }

    /**
     * Deliver a reference to the URL connection of this object.
     * For internal use.
     *
     * @return     URL connection
     */

    private URLConnection getURLconnect(){
        excInit();
        if ((IS_OPEN & this.status) == 0){  // the file is not open
            registerError(IOError.ERR_NOTOPEN,null);
        }
        excTerm();
        return this.urlcon;
    }

    /**
     * Deliver a stream of this object. If the object is open in write,
     * the write stream is delivered, otherwise the read one.
     *
     * @see        #getStream(int)
     */

    public Object getStream(){
        return getStream(this.mode);
    }

    /**
     * Deliver a stream of this object. The file must not be opened in
     * sequential interlocked mode. The method could return a different
     * stream object each time it is called. Thus, it is meant to be called
     * only once for an IoStream object.
     *
     * @param      mode READ/WRITE
     * @return     stream
     */
 
    /* No check is done that the requested stream is null. By testing
     * it the caller can then decide.
     */

    public Object getStream(int mode){
        if (this.mutex != null){
            synchronized (this.mutex) {
                return getStreamHandle(mode);
            }
        } else {
            return getStreamHandle(mode);
        }
    }

    /**
     * Deliver a stream of this object. For internal use.
     *
     * @param      mode READ/WRITE
     * @return     stream
     */

    private Object getStreamHandle(int mode){
        Object stream = null;
        excInit();
        if ((FL_B & this.trc) != 0){
            Trc.out.println("getStream: " + trcmode());
        }
        doit: try {
            if ((IS_OPEN & this.status) == 0){   // the file is not open
                registerError(IOError.ERR_NOTOPEN,null);
                break doit;
            }
            if (this.intLock != null){
                registerError(IOError.ERR_INVOP,null);
                break doit;
            }
            if ((RANDOM & this.mode) != 0){
                stream = this.randStream;
                break doit;
            }
            if ((CHARS & this.mode) != 0){
                if ((WRITE & mode) != 0){
                    stream = this.writerStream;
                    if (stream == null){
                        stream = new OutputStreamWriter
                            (this.outStream,this.encoding);
                    }
                } else {
                    stream = this.readerStream;
                    if (stream == null){
                        stream = new InputStreamReader
                            (this.inStream,this.encoding);
                    }
                }
            } else {
                if ((WRITE & mode) != 0){
                    stream = this.outStream;
                } else {
                    stream = this.inStream;
                }
            }
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } finally {
            excTerm();
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("getStream: " + stream);
        }
        return stream;
    }

    /**
     * Open a sequence of files for reading.
     *
     * @see        #open(Iterator,int)
     */
 
    public void open(Iterator iter){
        open(iter,null,READ);
    }

    /**
     * Open a sequence of files for reading.
     *
     * @param      iter <code>Iterator</code> which delivers the filespec
     *             strings either as Strings or String[2] of the filespec
     *             and the encoding
     * @param      mode open mode
     */
 
    public void open(Iterator iter, int mode){
        open(iter,null,mode | READ);
    }

    /**
     * Open a sequence of files for reading. The <code>mode</code> must
     * not specify open in write or append.
     *
     * @param      iter Iterator which delivers the filespec strings
     * @param      enc encoding
     * @param      mode open mode
     */
 
    public void open(Iterator iter, String enc, int mode){
        if (this.mutex != null){
            synchronized (this.mutex) {
                openStream(iter,enc,mode);
            }
        } else {
            openStream(iter,enc,mode);
        }
    }

    /**
     * Open a sequence of files for reading. For internal use.
     *
     * @param      iter Iterator which delivers the filespec strings
     * @param      enc encoding
     * @param      mode open mode
     */
 
    private void openStream(Iterator iter, String enc, int mode){
        excInit();
        doit: try {
            if (((WRITE | APPEND) & mode) != 0){
                registerError(IOError.ERR_INVOP,null);
                break doit;
            }
            if ((IS_OPEN & this.status) != 0){
                registerError(IOError.ERR_ISOPEN,null);
                break doit;
            }
            this.iter = iter;
            this.nrIoDone = 0;
            this.mode |= mode | READ;
            this.openEncoding = enc;
            ensureBuffers();
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } finally {
            excTerm();
        }
    }

    /**
     * The descriptor for files which have been accessed.
     */

    private static class FileRef {

        /** The next element. */
        private FileRef next;

        /** The file path. */
        private String path;

        /** The file path. */
        private long time;
    }

    /**
     * When check is in the initial phase, record the data of the
     * files which are opened. When check is turned on, check that
     * the file which is being opened it has already been accessed in
     * the first phase.
     *
     * @return     <code>false</code> if error
     */
 
    /* The time of last modification is kept to determine if a file has
     * changed. This is better, e.g. than the inode number in Unix
     * because the contents of a file might have been changed, while
     * keeping its position in the file system (inode) unchanged.
     *
     * If applications will need to use seveal IoStream objects to read
     * a set of files, and want to make the modification check on the
     * set, all such objects could be set to refer to a same list of
     * checked files. This is not implemented now.
     *
     * The openList is not cleared by close() once a IoStream has become
     * checked. If the object is no longer used, there is no problem.
     * If it is used again and it is opened in non-checked mode, the list
     * is cleared.
     */

    private boolean makeCheck(){
        if ((CHECKED & this.mode) == 0){     // no check
            return true;
        }
        FileRef fr = this.openList;
        search: while (fr != null){
            if ((fr.time == lastModified()) &&
                ((fr.path == this.path) ||
                (fr.path.equals(this.path)))){
                break search;
            }
            fr = fr.next;
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("check: " + (fr == null) +
                " " + ((CHECK & this.status) == 0) +
                " " + this.openList);
        }
        if ((CHECK & this.status) == 0){     // first phase
            if (fr == null){                 // not yet in list
                fr = new FileRef();          // prepend
                fr.next = this.openList;
                this.openList = fr;
                fr.path = this.path;
                fr.time = lastModified();
            }
        } else {
            if (fr == null) return false;
        }
        return true;
    }

    /**
     * Unconditionally close the file.
     *
     * @param      reco <code>true</code> to recover the status of the
     *             file prior to the open
     * @exception  IOException
     */

    /* Files are closed only when they have been opened by IoStream.
     * The files which are not opened by IoStream are the ones like e.g.
     * System.out, which are permanent, or the ones that have been created
     * outside and passed to it.
     * Opened files are flushed so as to transfer all the data which
     * is still waiting for it.
     * When recovery is selected, is tries to restore the origial status
     * of the filesystem prior to the open: if the file was opened in
     * write, it deletes it; if it was opened in append, it restores it
     * to its original length.
     * Recovery is not done for files which are objects that are created
     * outside IoStream.
     * When recovery is requested it does not try to flush the buffer
     * or the stream, and instead it deletes or truncated immediately
     * the file. Writing and flushing does not work in HP Java because
     * at the time finalizers are executed, file descriptors may have
     * become invalid due to an HP bug.
     * Since it is not possible to flush the buffer, it turns out that
     * deleting or truncating the file is the only safe operation which
     * can be done in finalization.
     * This method can call registerError because it clears IS_OPEN, which
     * makes it ineffective the next time it is called, and thus does not
     * recur forever.
     */

    private void forceClose(boolean reco) throws IOException {
        if ((FL_C & this.trc) != 0){
            Trc.out.println("forceClose: " + trcmode());
        }
        doit: try {                              // close the file
            if ((IS_OPEN & this.status) == 0)    // the file is not open
                break doit;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("closing: " + this.path);
            }
            this.status &= ~IS_OPEN;
            if (!reco && ((WRITE | APPEND) & this.mode) != 0){
                flushAllStreams();
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("close: flushed");
                }
            }
            if ((this.urlcon != null) &&
                (((WRITE | APPEND) & this.mode) != 0)){
                this.urlcon.getLastModified();    // hack to force output
            }
            if ((PERMANENT & this.status) != 0)  // the file is a permanent
                break doit;                      // .. one
            if (reco && (this.file != null)){
                if ((APPEND & this.mode) != 0){
                    RandomAccessFile r = new
                        RandomAccessFile(this.file,"rw");
                    r.setLength(this.oldLength);
                    r.close();
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("close: restored " +
                            this.oldLength);
                    }
                }
                this.status &= ~UNNAMED;
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("close: " + this.path);
            }
            if ((UNNAMED & this.status) != 0){   // give it its name
                boolean rena = this.file.renameTo(this.originFile);
                if (!rena){                      // in NT rename fails
                    boolean del = this.originFile.delete();    // when the file exists
                    // in XP no rename if file still open
                    if (this.writerStream != null){
                        this.writerStream.close();
                    }
                    if (this.outStream != null){
                        this.outStream.close();
                    }
                    rena = this.file.renameTo(this.originFile);
                    if (!rena){
                        registerError(IOError.ERR_RENAME,null);
                        throw this.excObj;
                    }
                }
                this.status &= ~UNNAMED;
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("renamed");
                }
            }
            if (this.writerStream != null) this.writerStream.close();
            if (this.outStream != null){
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("close: outStream " + this.file);
                }
                this.outStream.close();
                if ((ISPRINT & this.status) != 0){
                    printStreamCheck();
                }
            }
            if (this.readerStream != null) this.readerStream.close();
            if (this.inStream != null) this.inStream.close();
            if (this.randStream != null) this.randStream.close();
            if (this.socket != null) this.socket.close();
            if (reco && (this.file != null)){
                if ((WRITE & this.mode) != 0){
                    boolean del = this.file.delete();
                    if (!del){                      // failed
                        registerError(IOError.ERR_DELFAIL,null);
                        throw this.excObj;
                    }
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("close: deleted " +
                            this.file + " " + del);
                    }
                }
            }
        /*
        } catch (Throwable t){
            if ((FL_B & this.trc) != 0){
                Trc.out.println("forceclose: " + t);
            }
        */
        } finally {
            this.mode &= CHECKED;
            this.status &= CHECK | DATA_BREAK;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("closed " + trcmode());
            }
        }
    }

    /**
     * Throw an IOError if an error has been found on the last operation
     * on a PrintStream.
     *
     * @exception  IOError, IOException
     */

    private void printStreamCheck() throws IOException {
        if (((PrintStream)(this.outStream)).checkError()){
            registerError(IOError.ERR_PRINTERR,null);
            throw this.excObj;
        }
        if (Thread.currentThread().isInterrupted()){
            throw new InterruptedIOException();
        }
    }

    /**
     * Close the stream. It releases all the resources.
     */

    public void close(){
        close(0);
    }

    /**
     * Release all the resources.
     */

    private void free(){
        this.charInBuf = null;
        this.byteInBuf = null;
        this.charOutBuf = null;
        this.byteOutBuf = null;
        this.path = null;
        this.fileSpec = null;
        if ((CHECKED & mode) == 0){
            this.openList = null;
        }
        this.iter = null;
        this.encoding = null;
        this.readerStream = null;
        this.writerStream = null;
        this.inStream = null;
        this.outStream = null;
        this.randStream = null;
        this.urlcon = null;
        this.file = null;
        this.originFile = null;
        this.decoder = null;
        this.inAdapt = null;
        this.ouAdapt = null;
        if ((FL_B & this.trc) != 0){
            Trc.out.println("memory freed");
        }
    }

    /**
     * Close the stream. It recovers the filesystem if <code>RECOVER</code>
     * is specified. It puts this object into the file handling state if
     * <code>LOCATE</code> is specified.
     *
     * @param      mode kind of close: 0: normal, RECOVER: recover the file,
     *             LOCATE: go to the file handling state
     */

    /* When LOCATE is specified, the readers, writers, decoders, etc.,
     * are destroyed because it is difficult to determine how and when they
     * can be reused. E.g. an InputStreamReader could contain data into its
     * internal buffer when the file has not been read entirely.
     */

    public void close(int mode){
        if (this.mutex != null){
            synchronized (this.mutex) {
                closeStream(mode);
            }
        } else {
            closeStream(mode);
        }
    }

    /**
     * Close the stream. For internal use.
     *
     * @param      mode kind of close: 0: normal, RECOVER: recover the file,
     *             LOCATE: go to the file handling state
     */

    private void closeStream(int mode){
        excInit();
        if ((FL_B & this.trc) != 0){
            Trc.out.println("closeStream " + trcmode());
        }
        int mod = this.mode;                // save file handling
        int stat = this.status;             // .. fields
        FileSpec fspec = this.fileSpec;
        String pat = this.path;
        File fil = this.file;
        doit: try {
            forceClose((RECOVER & mode) != 0);
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (IOError exc){
        } finally {
            free();                             // clear all pointers
            if ((LOCATE & mode) != 0){
                this.mode = mod;
                this.status = stat & (CHECK | SPECIAL | READABLE |
                    WRITEABLE | URI | EXISTENT | DIRECTORY |
                    PERMANENT | LOCATED);
                this.fileSpec = fspec;          // restore
                this.path = pat;
                this.file = fil;
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("end close " + trcmode());
            }
            excTerm();
        }
    }

    /**
     * Restart this object. Then, it can be used again for opening
     * files with the initial defaults. It can instruct the subsequent
     * <code>open()</code> calls to check that the opened files have
     * already been opened by this object, i.e. that in the meantime
     * they have not been replaced by new files with the same name, but
     * possibly different contents. This is intended to be used by
     * applications which need to read the same files more than once.
     * The file must not be open.
     *
     * @param      check <code>true</code> to enable the check
     */
 
    public void restart(boolean check){
        if (this.mutex != null){
            synchronized (this.mutex) {
                restartStream(check);
            }
        } else {
            restartStream(check);
        }
    }

    /**
     * Restart this object. For internal use.
     *
     * @param      check <code>true</code> to enable the check
     */

    private void restartStream(boolean check){
        excInit();
        boolean res = false;
        doit: try {
            if ((IS_OPEN & this.status) != 0){    // file open
                registerError(IOError.ERR_ISOPEN,null);
                break doit;
            }
            if (this.fileSpec != null){
                this.fileSpec.init();
            }
            this.status = 0;
            this.nrIoDone = 0;
            if (!check) return;
            if ((CHECKED & this.mode) != 0){
                this.status |= CHECK;
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("restart: " + trcmode());
            }
        } finally {
            excTerm();
        }
    }

    /* Data transfer operations. */

    /* A set of methods which implement a stream reader (interlocked, random,
     * etc.) over the fields of IoStream, which is used both directly and from
     * within the input adapter, and to implement load().
     *
     * Interruption of io
     *
     * Java.io methods are not interupted when the thread calling them is
     * interrupted. E.g. a read which is blocked does not unblock because of
     * an interrupt on the thread waiting on it, be it done by another thread
     * by using interrupt() or by some means on the device.
     * The only way to make a thread interrupt what is doing is to break long
     * operations into ones so short that it can be tolerable to wait for their
     * completion, and to test periodically if it has been interrupted.
     * PrintStream methods, however, catch the io interruption exception
     * (even if it never occurs in JD 1.2) and interrupt the current thread.
     * Thus, after after a PrintStream io method call if the thread is
     * interrupted, IoStream throws an exception.
     * There are two alternatives: when an io operation completes and delivers
     * an InterruptedIOException, that exception can be returned, or an
     * InterruptedException can be returned. Moreover, when a IoStream method
     * is interrupted because another thread performs an interrupt() on
     * the thread executing that method, the method can return one exception or
     * the other one. PrintStream performs an interrupt(), which means that
     * it simply marks that the thread is interrupted. It is simpler to return
     * the InterruptedIOException: since it is a subclass of IOException,
     * it is already caught, and an isInterrupted() in io loops and after
     * PrintStrem io can throw an InterruptedIOException. These exceptions are
     * then returned as an IOError.
     * All primitive read operations are enclosed into two methods, which
     * breaks the long ones. This includes the character ones because
     * InputStreamReader.read() performs several read() operations, but does
     * not check interruption.
     * A similar approach is used for write(). Note that it is not convenient
     * to break long write()s into buffered ones (i.e. not to use dynamic
     * buffering) becasuse that is slower than performing the large ones
     * directly. Therefore, to support interruptions, the large writes are
     * split into blocks which are larger than the buffer size, and are written
     * directly (i.e. without moving the data into a buffer).
     * OutputStremWriter.write() and PrintStream.print() operations on
     * characters are split too because they do not test interruption.
     * Moreover, write() operations on strings are implemented by moving
     * the characters directly into the buffer because the java.io ones
     * allocate instead an array (which is large if the string is large).
     *
     * Measurements
     *
     * For testing purposes, the number of java.io read/write calls is
     * tracked in nrIoDone.  Since java.io eventually performs some native
     * operations on which there is no knowledge on the actual io they make,
     * even the rekoning of them does not reveal the number of physical io
     * operations done. However, knowing the number of java.io operations done
     * is useful for testing purposes to check that the number of them is
     * equal to what is expected.
     * Note that also when the streams are disclosed to the caller, is still
     * represents the io done by IoStream since it does not aim to represent
     * the total one.
     *
     * It could also be useful to have a way to know the amount of data
     * transferred to implement meters. That would apply to read().
     * For write(), the application must know the total amount of data that
     * it will write if it wants to determine the percentage. This seems
     * quite a bit application dependent, and thus it is not provided.
     *
     * Interoperation
     *
     * Interoperation, i.e. the use of java.io and IoStream serves to:
     *
     *     1. use methods not provided by IoStream, but provided by the
     *        java.io stream which is in it, like e.g. PrintStream or
     *        RandomAccessFile.
     *     2. to add functionality to an IoStream object (takestream/setstream),
     *        which are provided by some io wrapper class either as behaviour of
     *        the standard methods, of as some additional ones.
     *     3. to pass an IoStream to some API which requires a java io one.
     *
     * In input it is possible to attach a BufferedReader, LineNumberReader
     * or PushBackReader, or a user-defined FilterReader.
     * In output it is possible to attach a BufferedWriter, a PrintWriter or
     * a user-defined FilterWriter. Likewise, for streams there are several
     * classes which can be attached.
     * In InputStreamReader, there is are several methods (e.g. mark()), and
     * in RandomAccessFile there are plenty.
     * To perform the operations on File which are not provided by IoStream,
     * a reference to the File in is can be obtained.
     * Note that in java.io mixing of bytes and chars is not available.
     * To use the java.io methods, a reference to a stream can be obtained,
     * and the java,io methods called on it. If the object is opened in
     * CHARS, the reader or writer is handed. If there is none (which is
     * the case, e.g. for encodings handled directly such as ISO8859_1),
     * a reader or writer is created when getStream() is called. That will
     * also be the case when an InputStreamReader or OutputStreamWriter
     * will no longer be used.
     * If the object is opened in BYTES, the InputStream or OutputStream are
     * handed, even when a reader or writer has been created to support
     * character io. This is so because it is quite unlikely that, having
     * obtained an InputStream and also a Reader for a same IoStream, the
     * caller will be able to use them correctly, i.e. mixing bytes and
     * characters (IoStream had to struggle a lot to do it). Thus, only the
     * stream is delivered. A file with bytes and characters is effectively
     * a byte file, in which IoStream is able to encode characters.
     *
     * - In input:
     *
     * It is possible when each read is independent from the others.
     * It is not possible to mix buffered and direct input because once
     * the data have been read in a buffer, it is not possible to push them
     * back and then make a direct read. This applies in general to io, and
     * in particular to byte io.
     * In byte input this is obtained by AUTOFLUSH, which must be set from
     * the very beginning, otherwise bytes are buffered.
     * In character input it is not possibile, except for random access.
     *
     * - In ouput:
     *
     * It is possible if a flush is done between java.io and IoStream
     * calls. In general, it is possible to mix buffered and direct output
     * providing that when making a direct output after a buffered one, a
     * flush is done first.
     * IoStream does not set the autoflush implicitly because the caller may
     * want to make a sequence of IoStream operations and sometimes call the
     * native ones. It lets the caller have control on autoflush: it can set it
     * when needed.
     *
     * - Extra functionality
     *
     * Extra functionality can be obtained either by wrapping an IoStream
     * with a class which provides an improved behaviour, or by replacing
     * the java.io object contained in it with another one.
     * With replacing, IoStream.read/write call the replaced one, and thus
     * the caller can use the IoStream methods. I.e., once replaced, the code
     * is the same and maybe faster. It is more integrated, it interworks
     * better. E.g. suppose there is a need to have pushback. If the reader
     * is replaced with a pushback one, then the IoStream.read can still be
     * used and the extra methods also. If it is only wrapped, then all the
     * new methods must be used. It looks like a nice idea, but it is
     * dangerous because the implementation of IoStream methods relies on
     * the presence of a non-buffered stream object, and currently on a
     * character object. If those objects are replaced with something else,
     * they might not work. E.g. if the InputStreamReader is replaced with a
     * pushback one, it is not possible to guarantee that mixing calls to its
     * methods and IoStream ones works.
     * Besides this, the replacement is difficult for other reasons.
     * Replacement would require to get a stream, wrap or change it and
     * reinstall it when there are no data in buffers. The caller must also
     * pay attention not to forget files open: if a stream should be replaced
     * by another one, the old one must be closed first.
     * Thus, no replacement it allowed.
     *
     * - Interconnection
     *
     * To pass an IoStream to some object which requires a java.io object,
     * wrapper classes can be defined, or an internal handle can be delivered.
     * The latter is more efficient, and thus it is provided.
     *
     * Read+write
     *
     * Two (couples) of streams are created. They are kept in separate handles.
     * There are streams which allow full-duplex i/o, which can be buffered.
     * This means that there are conflicts in the use of the buffers because
     * read() and write() use them.
     * Random access does not make use of separate input and output buffers.
     * For non-random access, only input or only output buffers are allocated
     * when a file is opened only in read or only in write.
     * There is only one autoflush mode for input and output: this means that
     * it makes both write() and read() be immediate and without use of
     * buffering.
     */

    /**
     * Read bytes from the stream of a IoStream object. It uses the proper
     * stream and it checks interlock. In the case of a big request
     * it breaks it in smaller, interruptible ones.
     *
     * @param      bb bytes buffer
     * @param      off start offset in buffer at which bytes are returned
     * @param      number of bytes to be read
     * @return     number of bytes read
     * @exception  IOException 
     */

    private int get(byte[] bb, int off, int len) throws IOException {
        if ((FL_C & this.trc) != 0){
            Trc.out.println("get: " + this.oldLength +
                " " + this.index + " " + off + " " + len);
        }
        boolean eof = false;
        int n = 0;
        get: {
            if ((PENDING_EOF & this.status) != 0){   // eof pending
                n = -1;
                break get;
            }
            int piece = len;
            if ((LENGTH_FINAL & this.status) != 0){  // length known
                long avail = this.index + piece;     // .. to catch eof
                if ((avail > this.oldLength) ||
                    (avail < 0)){
                    piece = (int)(this.oldLength - this.index);
                    if ((FL_C & this.trc) != 0){
                        Trc.out.println("request: " + len +
                            " reduced to " + piece);
                    }
                    eof = true;
                    if (piece == 0){
                        n = -1;
                        break get;
                    }
                }
            }
            if ((RANDOM & this.mode) != 0){
                this.index = this.randStream.getFilePointer();
                this.index -= off;                    // index of buffer start
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("get index of buffer: " +
                        this.index);
                } 
                if (piece == 0){
                    n = 0;
                    if (this.randStream.getFilePointer() ==
                        this.randStream.length()){
                        n = -1;
                        eof = true;
                    }
                    break get;
                }
                if (this.index + piece < 0){          // reduce to file index
                    long rem = Long.MAX_VALUE - this.index;
                    if (piece > rem) piece = (int)rem;
                }
            } else {
                if (piece == 0){
                    n = 0;
                    if (this.inStream.available() <= 0){
                        n = -1;
                        eof = true;
                    }
                    break get;
                }
            }
            int end = bb.length;                 // reduce to buffer
            if (off > end) off = end;            // .. area
            if ((off + piece < 0) || (off + piece > end))
                piece = end - off;
            n = 0;
            int start = off;
            int r = 0;
            do {
                int l = piece - n;
                if (l > MAX_TRANSFER) l = MAX_TRANSFER;
                this.nrIoDone++;
                if ((RANDOM & this.mode) == 0){
                    r = this.inStream.read(bb,start,l);
                    if (r > 0) this.status |= NONEMPTY;
                } else {
                    r = this.randStream.read(bb,start,l);
                }
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("get: r: " + r);
                }
                if (r < 0){
                    eof = true;
                    if (n == 0) n = -1;        // no data read: eof
                    break;
                }
                start += r;
                n += r;
                if (n >= piece) break;
                if (r < l) break;
                if (Thread.currentThread().isInterrupted()){
                    throw new InterruptedIOException();
                }
            } while (available() > 0);
            if ((RANDOM & this.mode) == 0){
                if (n > 0) this.index += n;
            }

            if ((FL_C & this.trc) != 0){
                Trc.out.println("get: " + n + " " +
                    this.index + " " + off + " data: " +
                    byteToString(bb,0,off + ((n < 0) ? 0 : n)));
            }
        } // get
        if ((ENDLESS & this.mode) == 0){
            if ((RANDOM & this.mode) == 0){
                if (eof) this.status |= PENDING_EOF;    // end of file
            }
        }
        return n;
    }

    /** The maximum number of data read by a single operation. */
    private static int MAX_TRANSFER = 8192;

    /**
     * Deliver the number of bytes which can be read without blocking.
     * In takes interlock into account. It should be used in conjunction
     * with get(). It can also be used in conjuction with read(), but only
     * when it has delivered less data than requested because in such a
     * case there are no data pending in buffers.
     *
     * @return     number of bytes available
     * @exception  IOException 
     */

    private int available() throws IOException {
        int n = 0;
        done: {
            if ((PENDING_EOF & this.status) != 0){   // eof pending
                break done;
            }
            if ((LENGTH_FINAL & this.status) != 0){  // length known
                if (this.index >= this.oldLength){   // no more data
                    break done;
                }
            }
            if ((RANDOM & this.mode) == 0){
                n = this.inStream.available();
            } else {                                 // random always ready
                n = 1;
            }
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("available: " + n);
        }
        return n;
    }

    /**
     * An input adapter. It allows to control the data which flow
     * between an InputStreamReader and the underlying InputStream,
     * and also to plug it on top of a RandomAccessFile.
     * Since is is an inner class, it performs i/o with the streams
     * of the enclosing IoStream.
     */

    private class InAdapter extends InputStream {

        /** Whether read() should deliver only a bounded number of bytes. */
        private boolean bounded;

        /** Whether available() should deliver the real number of bytes. */
        private boolean ready;

        /**
         * Deliver one byte. It is implemented only to make the class not
         * abstract.
         *
         * @return     -1
         */

        public int read() throws IOException {
            return -1;
        }

        /**
         * Deliver bytes. In bounded mode it delivers at most the bytes
         * which have been decoded by the last call to the decoder.
         * In non-bounded mode it delivers the bytes read from the input
         * stream and no past the origin length in interlocked mode.
         * Note that character files opened in random mode always have an
         * adapter and a decoder, and thus always work in bounded mode.
         * It does not make an attempt to read further data when the ones
         * read are less than the requested ones because it is called by an
         * IoStream.read() which does it and because it would be very unikely
         * that any would become available in the meantime.
         *
         * @paramn     bb return buffer
         * @paramn     off start offset in it
         * @paramn     len maximum number of bytes to read
         * @return     actual number of bytes delivered
         * @exception  IOException 
         */

        public int read(byte bb[], int off, int len) throws IOException {
            IoStream ios = IoStream.this;
            if ((FL_D & ios.trc) != 0){
                Trc.out.println("adapter read request: " + len +
                    " " + ios.index + " " + ios.oldLength + " bounded " + this.bounded);
            }
            int n = 0;
            get: if (!this.bounded){
                n = ios.get(bb,off,len);
            } else {                                     // bounded mode
                n = ios.decoder.byteIndex - ios.byteInBuf.offset;
                if (n > 0){
                    if (n > len) n = len;                // deliver bytes
                    int end = bb.length;
                    if (off > end) off = end;
                    if ((off + n < 0) || (off + n > end))
                        n = end - off;
                    System.arraycopy(ios.byteInBuf.buffer,
                        ios.byteInBuf.offset,bb,off,n);
                    ios.byteInBuf.offset = ios.decoder.byteIndex;
                } else {
                    n = -1;               // prevent InputStreamReader loop
                }
                if ((FL_D & ios.trc) != 0){
                    Trc.out.println("adapter delivers:");
                    if (n < 0) break get;
                    for (int i = off; i < off+n; i++){
                        Trc.out.print(" 0x" +
                            Integer.toHexString(bb[i] & 0xff));
                    }
                    Trc.out.println();
                }
            }
            if ((FL_D & ios.trc) != 0){
                Trc.out.println("adapter read: " + n +
                    " data delivered");
            }
            return n;
        }

        /**
         * Close the stream. In bounded mode it is empty because the
         * stream is closed by other means.
         *
         * @exception  IOException 
         */

        public void close() throws IOException {
            if (!this.bounded){                    // non-bounded mode
                IoStream.this.inStream.close();    // interlocked mode, never
            }                                      // .. open in random
        }

        /**
         * Deliver the number of data available to be read without blocking.
         * In bounded mode, if <code>ready()</code> is false, it delivers 0,
         * which is what is needed when the InputStreamReader is requested
         * to decode the bytes provided by the adapter read() and no more.
         *
         * @return     number of available bytes
         * @exception  IOException 
         */

        public int available() throws IOException {
            IoStream ios = IoStream.this;
            int n = 0;
            if (!this.bounded){                     // no buffering
                n = ios.available();
            } else {
                if (!this.ready){                   // not ready
                    n = 0;
                } else {
                    n = ios.byteInBuf.length - ios.byteInBuf.offset;
                    if (n == 0){
                        if ((RANDOM & ios.mode) == 0){
                            n = ios.available();
                        }
                    }
                }
            }
            if ((FL_D & ios.trc) != 0){
                Trc.out.println("adapter available: " + n +
                    " " + this.ready + " " + this.bounded);
            }
            return n;
        }
    }


    /** The number of decoded characters. */
    private int decoded;

    /**
     * Decode the bytes buffer. As many bytes as needed to make up the
     * requested number of characters or a line are delivered.
     *
     * @param      toRead number of characters, -1 to seek a line,
     *             -2 to seet a shift-in
     * @return     number of bytes decoded
     * @exception  IOException 
     */

    /*
     * When it is called to deliver more characters than the ones present
     * in the buffer, an incomplete sequence can be present at the end
     * of it. The decoder remembers this, and then loadDecode() next time
     * before refilling the buffer shifts the incomplete sequence at the
     * beginning of it.
     * If load() delivers no bytes, then an eof is returned. Otherwise
     * there are bytes to decode.
     * It then calls the decoder to seek the requested characters. If a
     * malformed sequence is found, an exception is thrown. If no characters
     * are decoded it is because the buffer is full of lock-shift sequences.
     * To process them, it calls the InputStreamReader.read() and then
     * it refills the buffer until characters are got, or an eof or exception
     * is found.
     * Likewise, when it is called to seek the lock-shift sequence that
     * make the unshifted charset become the current one, it loops until
     * it finds it.
     * Upon return, either an eof or exception has been found, or the
     * requested characters are located, including the case of 0 characters,
     * which make loadDecode either return an eof when it is at the end,
     * or no bytes, which make the adapter.read() return -1.
     * When it is requested to process shift-in sequences, if any, it
     * does not throw a malformed exception because a malformed sequence
     * is just not a shift-in.
     */

    private int loadDecode(int toRead) throws IOException {
        if ((FL_D & this.trc) != 0){
            Trc.out.printf("loadDecode start: %s shift %s\n",toRead,this.decoder.shiftState);
        }
        BytesRow bytebuf = this.byteInBuf;
        int loadSize = this.bufferSize;
        int n;
        this.decoded = 0;
        int toDecode = toRead;
        if (toRead == -2) toDecode = 0;         // lock-shift shift-in
        do {
            if ((FL_D & this.trc) != 0){
                Trc.out.println("loadDecode: " + this.decoder.incomplete +
                    " " + bytebuf.offset + " " +
                    bytebuf.length);
            }
            n = bytebuf.length - bytebuf.offset;
            if ((n == 0) || (this.decoder.incomplete)){
                if (toRead == -2){              // lock-shift shift-in
                    if (available() <= 0){      // if any bytes, decode
                        n = 0;                  // .. else do not deliver
                        break;                  // .. an extra eof
                    }
                }
            }
            if (this.decoder.incomplete){
                if ((FL_D & this.trc) != 0){
                    Trc.out.println("loadDecode: incomplete");
                }
                System.arraycopy(bytebuf.buffer,   // shift to
                    bytebuf.offset,                // .. beginning
                    bytebuf.buffer,0,n);
                bytebuf.offset = n;
                bytebuf.length = bytebuf.offset;
                n = load(bytebuf.offset);          // refill
                bytebuf.offset = 0;
            } else if (n == 0){
                n = load(0);
            }
            if ((FL_D & this.trc) != 0){
                Trc.out.println("loadDecode loaded: " +
                    bytebuf.offset + " " +
                    bytebuf.length + " " +
                    toRead + " " + n);
            }
            if (n == 0) n = -1;                    // make sure to terminate
            if (n < 0) break;
            if (n > 0){
                if ((FL_D & this.trc) != 0){
                    Trc.out.println("loadDecode buffer: " +
                        bytebuf.offset + " " + bytebuf.length);
                    for (int i = 0; i < bytebuf.length; i++){
                        Trc.out.print(" 0x" +
                            Integer.toHexString(
                            bytebuf.buffer[i] & 0xff));
                    }
                    Trc.out.println();
                }
                this.decoded = 0;
                if (toRead != 0){                  // shift-in, or non-empty read
                    this.decoded =
                        this.decoder.decode(bytebuf.buffer,
                            bytebuf.offset,
                            bytebuf.length-bytebuf.offset,
                            toDecode);
                } else {
                    this.decoder.byteIndex = bytebuf.offset;
                    this.decoded = 0;
                }
                if ((FL_D & this.trc) != 0){
                    Trc.out.println("loadDecode decoded: " +
                        bytebuf.offset + " " + this.decoder.byteIndex +
                           " " + this.decoded + " " + toRead + " " +
                        this.decoder.shiftState + " " +
                        this.decoder.malformed + " " +
                        this.decoder.incomplete);
                }
                if (toRead != -2){             // a real decode
                    if (this.decoder.malformed){
                        throw new CharConversionException();
                    }
                } else {
                    this.decoder.malformed = false;
                }
            }
            if (toRead != -2){                      // normal process
                if (this.decoded > 0) break;
            } else {                                // shift-in process
                if ((this.decoder.shiftState == 0) ||
                    ((this.decoder.byteIndex <      // no shift-in: extra
                    bytebuf.length) &&              // .. bytes in buffer,
                    !this.decoder.incomplete)){     // .. not incomplete and
                                                    // .. shiftstate != 0
                    this.readerStream.read();       // n.b. 1 byte
                    break;
                }
                // a shift-out at the end of the buffer
            }
            // no characters decoded: none requested,
            // .. control sequences, or no shift-in
            if (this.decoder.byteIndex -            // some sequences scanned
                bytebuf.offset > 0){
                this.readerStream.read();           // n.b. 1 byte
            } else if (!this.decoder.incomplete){   // 0 chars scanned
                break;
            } else {                                // incomplete
                if (bytebuf.length < loadSize){     // less than read
                    n = 0;
                    break;                          // no more available
                }
            }
            if (available() <= 0){                  // here only when
                n = 0;                              // .. all buffer scanned
                break;                              // .. or incomplete seq.
            }
        } while (true);
        if ((FL_D & this.trc) != 0){
            Trc.out.println("loadDecode returns: " + n);
        }
        return n;
    }

    /**
     * An output adapter. It allows to control the data which flow
     * bethween an OutputStreamReader and the underlying OuputStream.
     * and also to plug it on top of a RandomAccessFile.
     * Since is is an inner class, it performs i/o with the streams
     * of the enclosing IoStream. It uses dynamic buffering
     */

    private class OutAdapter extends OutputStream {

        /**
         * Write one byte. It is implemented only to make the class not
         * abstract.
         *
         * @param      b byte to be written
         */

        public void write(int b) throws IOException {
        }

        /**
         * Write bytes. It supports dynamic buffering.
         *
         * @param      b array of bytes to be written
         * @param      off start offset
         * @param      len number of bytes to be written
         * @exception  IOException 
         */

        public void write(byte b[], int off, int len) throws IOException {
            IoStream ios = IoStream.this;
            BytesRow bytebuf = ios.byteOutBuf;
            int piece = 0;
            fill: {
                if ((IS_OPEN & ios.mode) == 0) break fill;  // in close
                if (((AUTOFLUSH & ios.mode) != 0) &&     // autoflush and no
                    (bytebuf.offset == 0)){              // .. pending data
                    break fill;
                }
                if ((bytebuf.offset == 0) &&             // buffer empty and big
                    (len >= ios.bufferSize)) break fill; // .. transfer
                ios.bytesBufferEnsure(bytebuf);
                piece = ios.bufferSize - bytebuf.offset;
                if (piece == 0) break fill;              // buffer full
                if (piece > len) piece = len;
                System.arraycopy(b,off,bytebuf.buffer,
                    bytebuf.offset,piece);
                bytebuf.offset += piece;
            }
            if (bytebuf.offset >= ios.bufferSize){       // buffer full
                if ((FL_D & ios.trc) != 0){
                    Trc.out.println("write-ad-1: " +
                        byteToString(bytebuf.buffer,0,
                        bytebuf.offset));
                }
                ios.put(bytebuf.buffer,0,bytebuf.offset);
                bytebuf.offset = 0;
            }
            int rem = len - piece;
            if (rem > 0){                                 // not yet completed
                int off1 = off + piece;
                if ((rem >= ios.bufferSize) ||            // direct transfer
                    ((AUTOFLUSH & ios.mode) != 0)){
                    if ((FL_D & ios.trc) != 0){
                        Trc.out.println("write-ad-2: " +
                            byteToString(b,off1,rem));
                    }
                    ios.put(b,off1,rem);
                } else {
                    piece = ios.bufferSize - bytebuf.offset;
                    if (piece > rem) piece = rem;
                    System.arraycopy(b,off1,bytebuf.buffer,
                        bytebuf.offset,piece); 
                    bytebuf.offset += piece;
                    if (bytebuf.offset >= ios.bufferSize){   // buffer full
                        if ((FL_D & ios.trc) != 0){
                            Trc.out.println("write-ad-3: " +
                                byteToString(bytebuf.buffer,
                                0,bytebuf.offset));
                        }
                        ios.put(bytebuf.buffer,0,bytebuf.offset);
                        bytebuf.offset = 0;
                    }
                }
            }
        }

        /**
         * Flush the buffer. It performs no action because it is called
         * by the OutputStreamWriter flush(), which must only move the
         * bytes of its internal buffer into the bytes buffer.
         */

        public void flush() throws IOException {
            IoStream ios = IoStream.this;
            if ((FL_C & ios.trc) != 0){
                Trc.out.println("adapter flush");
            }
        }

        /**
         * Close the buffer. It performs no action because the output
         * stream is closed explicitly with other means.
         */

        public void close() throws IOException {
            IoStream ios = IoStream.this;
            if ((FL_C & ios.trc) != 0){
                Trc.out.println("adapter close");
            }
        }
    }

    /**
     * An output adapter. It allows to control the encoding of characters
     * passing the corresponding bytes to the underlying stream writer.
     * An OutputStremWriter is still used instead of a Writer to exploit its
     * flushing and closing.
     */

    private class OutputEncoder extends OutputStreamWriter {
        public OutputEncoder(OutputStream out){
            super(out);
        }
        public OutputEncoder(OutputStream out, String charsetName)
            throws UnsupportedEncodingException {
            super(out,charsetName);
        }
        public void write(char[] cbuf, int off, int len)
            throws UnsupportedEncodingException, IOException {
            IoStream ios = IoStream.this;
            if ((FL_C & ios.trc) != 0){
                Trc.out.printf("OutputEncoder write\n");
            }
            byte[] bb = String.valueOf(cbuf,off,len).getBytes(getEncoding());
            ouAdapt.write(bb,0,bb.length);
        }
        public void write(String str, int off, int len)
            throws UnsupportedEncodingException, IOException {
            IoStream ios = IoStream.this;
            if ((FL_C & ios.trc) != 0){
                Trc.out.printf("OutputEncoder write\n");
            }
            byte[] bb = str.substring(off,off+len).getBytes(getEncoding());
            ouAdapt.write(bb,0,bb.length);
        }
    }

    /** The reference to the decoder. */
    private IoDecoder decoder;

    /** The reference to the input adapter. */
    private InAdapter inAdapt;

    /**
     * Create the input converter, decoder and the input adapter.
     *
     * @exception  IOException 
     */

    private void createInAdapter() throws IOException {
        this.inAdapt = new InAdapter();               // create decoder
        this.mode |= CHARS;
        this.inAdapt.ready = false;
        this.inAdapt.bounded = true;
        InputStreamReader isw =                       // create converter
            new InputStreamReader(this.inAdapt,this.encoding);
        this.readerStream = isw;
        this.encoding = isw.getEncoding();
        this.status &= ~NEW_ENCODING;
        this.decoder = new IoDecoder(this.encoding);  // create decoder
        if ((FL_B & this.trc) != 0){
            Trc.out.println("decoder: " + this.encoding);
        }
    }

    /** The reference to the ouput adapter. */
    private OutAdapter ouAdapt;

    /**
     * Create the output converter and the output adapter.
     *
     * @exception  IOException 
     */

    private void createOutAdapter() throws IOException {
        this.ouAdapt = new OutAdapter();              // create adapter
        this.mode |= CHARS;
        OutputStreamWriter osw =                      // create converter
            new OutputEncoder(this.ouAdapt,this.encoding);
        this.writerStream = osw;
        this.encoding = osw.getEncoding();
        this.status &= ~NEW_ENCODING;
        if ((FL_B & this.trc) != 0){
            Trc.out.println("encoder: " + this.encoding + " "
                + osw.getEncoding());
        }
    }

    /**
     * Set the encoding to be used at the next character data transfer
     * operation. The file must be opened for <code>BYTES</code> transfer.
     * If the encoding is the same as the current one, no operation is
     * done. Otherwise if there are characters pending in the characters
     * buffer, they are flushed. To avoid useless creation of converters,
     * use always the canonical names of encodings.
     *
     * @param      enc encoding
     */

    /*
     * It does not recreate the converter, but it only redefines the
     * encoding. This allows to defer the creation of the input and/or
     * output converters only for files which are opened in read and/or write.
     * If the encoding is the same as the current one, nothing is done.
     * Otherwise it destructs the converter, which forces write() and read()
     * to recreate the converter and the adapter.
     * It flushes also the OutputStreamWriter if there are characters pending
     * in the characters buffer. Note that the characters buffer can only
     * contain output characters and no input ones because in input there is
     * no buffering of characters when files are opened in BYTES.
     *
     * The setting of an encoding is done by having the application call
     * a method. At the moment it does not seem that there is a need
     * to make an IoStrem object capable to follow the changes in encoding
     * which the application can make, like e.g. the changes in the language.
     * If that were the case there would be a need for something similal to
     * Lang and to test if it has changed before making a data transfer
     * operation.
     */

    public void setEncoding(String enc){
        if (this.mutex != null){
            synchronized (this.mutex) {
                setCharEncoding(enc);
            }
        } else {
            setCharEncoding(enc);
        }
    }

    /**
     * Set the encoding. For internal use.
     *
     * @param      enc encoding
     */

    private void setCharEncoding(String enc){
        excInit();
        doit: try {
            if ((IS_OPEN & this.status) == 0){       // file not open
                registerError(IOError.ERR_NOTOPEN,null);
                break doit;
            }
            if ((BYTES & this.mode) == 0){               // only BYTES streams
                registerError(IOError.ERR_INVOP,null);   // .. can have encoders
                break doit;
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("setEncoding old: " + this.encoding);
            }
            if ((this.encoding == null) ? (enc == null) :
                this.encoding.equals(enc)) break doit;
            if (((WRITE | APPEND) & mode) != 0){      // in read cb always empty
                if (this.writerStream != null){
                    if (this.charOutBuf.offset > 0){  // characters pending
                        flushBuffer(false);           // encode buffer
                    }
                    this.writerStream.flush();
                }
            }
            this.writerStream = null;          // mark as absent
            this.readerStream = null;          // mark as absent
            this.inAdapt = null;
            this.ouAdapt = null;
            this.decoder = null;
            this.status |= NEW_ENCODING;
            setEncod(enc);
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } finally {
            excTerm();
        }
    }

    /**
     * Tell whether the object is ready to deliver bytes.
     *
     * @return     <code>true</code> if the next read() will not block
     */

    public boolean ready(){
        if (this.mutex != null){
            synchronized (this.mutex) {
                return ready(true);
            }
        } else {
            return ready(true);
        }
    }

    /**
     * Tell whether the object is ready to deliver characters.
     *
     * @return     <code>true</code> if the next read() will not block
     */

    public boolean readyChars(){
        if (this.mutex != null){
            synchronized (this.mutex) {
                return ready(false);
            }
        } else {
            return ready(false);
        }
    }

    /**
     * Tell whether the object is ready to deliver characters.
     * When the last data of a file in a sequence has been read, the
     * stream is not deemed to be ready to deliver data until another
     * read operation is executed.
     *
     * @param      <code>true</code> to denote bytes
     * @return     <code>true</code> if the next <code>read()</code> will
     *             not block
     */

    /* If there are bytes in a mixed file, a read() will interpret them
     * as characters, and thus, also the bytes must be checked.
     * In a sequence of files, making the stream not ready between files
     * allows to implement buffered readers which do not concatenate
     * data across files.
     */

    private boolean ready(boolean bytes){
        if ((FL_B & this.trc) != 0){
            Trc.out.println("ready: " + trcmode() + " " + bytes);
        }
        excInit();
        boolean res = false;
        doit: try {
            if ((IS_OPEN & this.status) == 0){       // file not open
                if (this.iter == null){
                    registerError(IOError.ERR_NOTOPEN,null);
                }
                break doit;
            }
            if ((READ & this.mode) == 0){            // not in read
                registerError(IOError.ERR_INVOP,null);
                break doit;
            }
            if (bytes){                              // check data transfer
                if ((BYTES & this.mode) == 0){
                    registerError(IOError.ERR_INVOP,null);
                    break doit;
                }
            }
            if ((AT_EOF & this.status) != 0){
                res = true;
                break doit;
            }
            if ((RANDOM & this.mode) != 0){          // random always ready
                res = true;
                break doit;
            }
            chr: if (!bytes){
                if (((ISO8859_1 | UCS2) & this.status) != 0){
                    bytes = true;                    // special encodings
                    break chr;
                }
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("ready: " + this.charInBuf +
                        " " + this.charInBuf.offset +
                        " " + this.charInBuf.length);
                }
                if ((this.charInBuf != null) &&      // some data left
                    (this.charInBuf.offset <
                    this.charInBuf.length)){
                    res = true;
                    break doit;
                }
                if (this.decoder == null){
                    if (this.readerStream != null){
                        res = this.readerStream.ready();
                    } else {                         // not yet created
                        bytes = true;
                    }
                } else {
                    bytes = true;                    // check bytes
                }
            }
            if (bytes){
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("ready: " + this.byteInBuf.buffer +
                        " " + this.byteInBuf.offset + " " +
                        this.byteInBuf.length);
                }
                if ((this.byteInBuf.buffer != null) &&   // some data left
                    (this.byteInBuf.offset < this.byteInBuf.length)){
                    res = true;
                    break doit;
                }
                res = available() > 0;
            }
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } finally {
            excTerm();
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("ready returns: " + res);
        }
        return res;
    }

    /*
     * Buffering
     *
     * Data transfer is automatically buffered. Buffering reduces the number
     * of io operations done on the underlying runtime support at the cost of
     * memory and transfer between user locations and buffers.
     * In some cases buffering is necessary, like e.g. for
     * <code>readln()</code>, otherwise there would be a need to read one
     * datum at a time.
     * In all other cases buffering is dynamic. I.e. IoStream buffers when it
     * is convenient, and transfers the data directly otherwise. Note that
     * there are some devices which transfer only blocks of data, like e.g.
     * block devices, for which the underlying system transfers also blocks of
     * data, and sequential devices for which data can be read in (variable
     * size) amounts from drivers, and also individually.
     * When a transfer is made with a size which is greater or equal to the
     * buffer, the data are transferred directly to or from the user area.
     * Otherwise, a block is read, and the data obtained from it.
     * This eliminates the inefficiency of performing several small io
     * operations, and allows also to mix long and small transfers.
     *
     * The buffers are allocated when needed instead of at open time so as
     * to allocate memory only when it is used (note that if large transfers
     * are done only, no buffer is needed).
     *
     * An io operation takes approximately the same time as the copying in
     * memory of 10 Kbytes.
     * Buffering is meaningful when the buffer size is larger than the mean
     * size of transfers.
     * Simulation shows that the algorithm used in IoStream is more stable and
     * provides results not worse than those of an algorithm in which large
     * transfers are done immediately without moving first into the buffer what
     * is possible. The time spent by the second is occasionally shorter,
     * but on average not much different from the first.
     * These are the results of a test made with increasing buffer sizes.
     * These are the average transfers at which the gain is 70% with
     * respect to no buffering (src is the average number of bytes of
     * the data to transfer):
     *                           PC           HP-UX
     *
     *        buffer size        %    src     %     src
     *
     *             512           12    64     12     64
     *            1024           12   128     50    512  
     *            2048            6   128     50   1024
     *            4096            6   256     75   3072   
     *            8192            3   256     75   6144
     *
     * Beyond these values the gain is unstable. Buffer sizes which are
     * not a power of 2 produce little gains.
     *
     * When files are accessed in random mode, buffering could be efficient
     * or not depending on the locality of transfers done. I.e. if when a
     * transfer is done, other transfers close to it are likely to occur,
     * then buffering decreases the number of io done, otherwise it increases
     * the size of them. However, the underlying system would anyway transfer
     * blocks to the disk and thus it performs already a buffering. For this
     * reason and also to keep the data transferred as updated as possible,
     * buffering is not done, except when reading characters and lines in
     * general, in which case it is kept for the execution of the single
     * data transfer operation.
     *
     * The bytes buffer is kept a bit larger so as to allow to read blocks
     * of 512, 1024, etc. bytes, and at the same time to have space for
     * an incomplete bytes sequence which makes up a character.
     *
     * The cases in which input buffering is done are:
     *
     *  file       operation        sequential           random
     *
     *  bytes-only read          bb dynamic buffering
     *  bytes-only readln        bb buffering           bb buffering
     *  chars-only read          cb dynamic buffering   bb buffering/adapter (1)
     *  chars-only readln        cb buffering           bb buffering/adapter (1)
     *  mixed      byte read     bb dynamic buffering
     *  mixed      byte readln   bb buffering           bb buffering
     *  mixed      char read     bb buffering/adapter   bb buffering/adapter
     *  mixed      char readln   bb buffering/adapter   bb buffering/adapter
     *
     *  N.B. bb = bytes buffering, cb = characters buffering
     *
     *  (1): to support all encodings an InputStreamReader is used, and thus
     *       an adapter and decoder also.
     *
     *
     * Read and the end of file
     *
     * Let's consider first how read() works with buffering.
     * When keying a line, requested by a read on a terminal, and a file
     * terminator (e.g. control-D in Unix) is keyed, the line is sent without
     * a CR LF at the end (and without any other terminator). The line is read
     * by the terminal driver and then delivered to the underlying runtime
     * support. Since lines can have an arbitrary length, the readln() method
     * reads a fixed amount of data, buffers them, searches the line
     * terminator, and when it does not find it it makes futher reads until it
     * finds it or it finds the eof.
     * When read() requests exactly as many data as the free space in the buffer
     * and it gets them and they are not ended by the line terminator, it does
     * not know if there are other characters to be read. E.g. if it requested
     * 10 data and read gives 10 data and these are the ones which are needed
     * to make the buffer full, it is not sure if the read has read a line,
     * has delivered 10 characters but there are others, or if it has ended
     * the line (remember that a line may or not be terminated by CR LF).
     * By using the ready() or available() methods it could detect it. This,
     * however, would not allow to detect that the file has ended. In fact,
     * in Unix terminating a line by control-D does not mean that the file is
     * ended, and indeed further lines can be introduced.
     * In conclusion, there is always a need to make a read that delivers no
     * data to detect the eof. This means that when buffering to search a line
     * terminator, when some data have been obtained and the line terminator
     * not found, another read is made, which can return an eof. The data are
     * then returned to the calling application which will then issue another
     * readln(). This must not make another read() because it has already
     * found the eof. Another read would result in a further request for data
     * to the terminal driver, which would block the program, that receives
     * again control only when a terminator is introduced. I.e. the user would
     * be requested to introduce another contol-D.  To avoid this, there is a
     * need to introduce into the "buffer" also the eof which has been read
     * and to keep it pending.
     * When reading a sequence of files, if a file is ended while loading
     * the buffer, the pending eof is set, but if the file is not the last,
     * another one is opened, and the pending eof reset. What is important
     * is that the flag allows to avoid to make useless, disturbing read()
     * after the ones which detected an eof.
     *
     * The best model for a sequential file is a sequence of data in which
     * there is a terminator that marks the end of the sequence. Note that
     * with a normal string it is possible to know how many data are present,
     * while with a sequential file that is not known.
     * Read() returns what data is told to be (even 0) and what it can, and
     * detects eof only when there are no more data, i.e. when it strikes on
     * it. When at least one datum has been read, there is no guarantee that
     * the file is ended. To be sure that the file has ended, a read() which
     * returns nothing must have been done.
     * The best is to model this by using the notion of index. Each datum in
     * a file has an index. The index is defined also on sequential files, but
     * its maximum value is not known until it is found.
     * When a transfer operation takes place, a transfer index is calcutated,
     * i.e. the index of the place in the file at which the transfer would
     * occur. After each transfer operation the index is advanced.
     *
     * With buffering, when an eof is found while filling the buffer, the index
     * is moved to the eof.
     * This means that, after having done a read, and having obtained data, it
     * is also possible to test if the eof has been reached.
     * This can be done by setting a flag, or by using the index. Since for
     * sequential devices the length is normally not known, to test that the
     * index is at the last value, a flag should be used to tell that the
     * length is known, and thus that a test can be made on it. When the eof
     * is found, the number of data read is stored in the length and the flag
     * raised to tell that such length is faithful. This works also for empty
     * files.
     * Length could be initialised to -1 indicating that when is < 0 is
     * undefined, and when >= 0 is known.
     * However the reaching of the end be known while data are also obtained,
     * this does not make applications simpler because in so doing they should
     * use a skeme like this:
     * Skeme 1:
     *
     *       do {
     *           read()
     *           if (some data obtained)
     *               process data;
     *       } while (!index at eof);
     *      
     * First, a read() is done because without reading it is not possible to
     * know if the file is at eof.
     * This skeme does not work for sequential files, or better, it works only
     * if there is buffering which makes it be a bit ahead in reading, that
     * allows to know if the eof has been found after having read some
     * characters. It resembles the lazy read of Pascal. Note, however, that
     * buffering is quite common, or even necessary when lines are read (i.e.
     * when reading up to a terminator).
     * It is strange a skeme which reads, it gets something, processes it and
     * then it tests what follows without reading.
     *
     * This skeme could also be used:
     * Skeme 2:
     *
     *       while (!eof()){
     *           read()
     *           if (some data obtained)
     *               process data;
     *       }
     *
     * This, however, is cheating because only a read() operation can tell what
     * has been found, and thus testing what has been found before reading is
     * meaningless.
     * Since for sequential files the eof is not known until one has struck on
     * it, then it does not make sense to use eof() that tells if the file
     * is at the end because the end is not known. Also this seems to be similar
     * to the lazy read of Pascal, in which eof() actually made a read to
     * determine if it was at eof.
     * Note that to make this skeme work for sequential devices there is a need
     * to test if some data has beed read because even if the first eof()
     * returns false (which makes the loop be entered and at least one read
     * done), the read() could deliver no data (and indeed the last read() in
     * the file does it).
     *
     * The correct skeme is this:
     * Skeme 3:
     *
     *       do {
     *           read()
     *           if (eof()) break;
     *           process data;
     *       } while (true);
     *
     * The problem here is to define eof():
     *
     *   1. eof() tells if the current index is at eof, and in the case of
     *      sequential devices, whose length is unknown, the method tells that
     *      it does not know it. When it returns true it means that the index
     *      is at eof, but when it returns false it means that it does not
     *      know if the index is at eof. It is similar to the definition of a
     *      partial function. It becomes a total one, i.e. it retuns false
     *      only when it know that the file is not ended, only after a read()
     *      has been done. This reflects how things are really going on, and
     *      it allows to base the definition on the value of the index at the
     *      moment eof() is called.
     *      In effect, read(), when buffering, even if it has found an eof it
     *      feigns not to know it. This only for eof() because read()
     *      remembers it for itself so as not to make another io operation the
     *      next time. This works also when the length is known, or can be
     *      inquired (e.g. for disk files). Read() keep on delaying the eof,
     *      and it does not make a useless io operation when it knows it has
     *      read all data. This definition is difficult to understand because
     *      there is a need for tricks to state that eof() does not know it
     *      even when it is known, and that a false return value means
     *      undefined.
     *   2. read() returns what it has read, and it returns that it read
     *      nothing when it is finished. eof() returns true if the last read
     *      struck on the eof, i.e. if the index before reading was at eof
     *      (as opposite to testing the value present after reading) and false
     *      otherwise. But then read() can tell what it has found: data or eof.
     *      Or better, eof() returns true if the last read operation attempted
     *      to transfer data whose position was out of the file.
     *      This holds irrespectively on whether the current index attribute in
     *      the file denotes the position of the last record transferred or the
     *      position of the next. I.e. both conventions can be used. This does
     *      not change the fact that each datum has a position in the file and
     *      that read() attempts to get the data whose position is after that
     *      of the previous read(). Keeping the current index on the next
     *      position is better when variable amounts of data are transferred
     *      because that amount is known at the time the transfer operation
     *      is done, and not when the next is done.
     *      This makes it work in the same way for random and sequential files.
     *
     * The skeme works also when the file is open in random mode, and also
     * whether there is buffering or otherwise.
     *
     * It is useless to try to avoid a last read() because the length can be
     * known only by making a File.length(), which implies an io operation,
     * much the same as a read(). The only one case in which that is avoided
     * is when the length is known (LENGTH_FINAL).
     *
     * For random access, reading out of the file is similar to reading out
     * an array, and therefore, and exception for eof can make code more
     * simple and terse. It can be useful for sequential access too when
     * parsing files which must have a defined contents from which the end
     * can be told. This behaviour is provided by EOF_EXCEPTION. Note that
     * a IOError is returned and not, e.g. a EOFException, so as not
     * to force callers to catch it even when it is disabled.
     * Note also that RandomAccessFile.read() does not throw a EOFException,
     * but returns -1, and thus IoStream never has to catch it.
     *
     * Arrival of data
     *
     * When a read() is made and it delivers less data then requested to the
     * caller, the caller can processes at least what it has got. This is
     * better than waiting for data that might never arrive. E.g. it decodes
     * the contents. If that operation is long, further data could have become
     * available. This is likely to occur only when that processing time is
     * comparable with that of reading.
     * In InputStreamReader that is the case because the internal buffer is
     * 8 Kbytes long, and the moving in memory of that many bytes requires a
     * time which is comparable with that of an io operation.
     * This loop is made also when reading bytes to keep a unique skeme
     * because it makes no harm.
     *
     * Suspension of data availability
     *
     * When a read() on a disk file detects that no characters are available,
     * an eof is returned. Note, however, that if the file is also opened in
     * write, and data are then written on it, a subsequent read would get
     * them. I.e. data which lay "beyond the eof". Effectively, the native
     * read() returns -1, which has the meaning of "no data available", which
     * can then be interpreted as eof or as a temporary lack of data. If one
     * wants to use a file as a pipe, then it would be better to make read()
     * block when there are no data. However, there is no way in java to do
     * it. This would be the behaviour of named pipes in Unix. In Unix there
     * are also programs like e.g. "tail" which monitor files, i.e. read them
     * until killed. They are implemented by polling files: they read a file
     * until they get -1; then they sleep, wake up and try to read again the
     * file. This is the only way to monitor files since the programs which
     * create them open files and not pipes. It is up to the applications to
     * tell that a file is ended. I.e. usually when -1 is detected, files are
     * considered as ended, except for special applications that monitor files,
     * which read files forever.
     * A model in which files can deliver data after eof is not more powerful
     * than the classic one, on the contrary, it leaves to the user to make
     * understand when to finish.
     * Consider the reading of data from the terminal: if 10 characters are
     * requested, but only 5 are delivered, then another read() to complete
     * the missing 5 would block. I.e. -1 is returned if ^D is entered, and the
     * program is blocked otherwise. This is an example of file for which data
     * are not available all at once. a disk file behaves differently
     * because nothing would synchronize a program with the arrival of data in
     * the file. Notice, however, that it is the underlying read() that returns
     * -1 or 0, and thus that when a program opens a file which is already
     * opened by another program, the filesystem could return an eof when the
     * file is closed, and otherwise returns 0 characters when reading and
     * nothing is available. Unfortunately filesystems do not do it.
     * In general, when a read() is done, a request is made to the underlying
     * system, which either it delivers some data (possibly less), or it blocks
     * until some data become available, or it returns an indication that no
     * data are available. To implement a character read(), when less bytes
     * than required are obtained, an attempt is made to read more after having
     * decoded the ones obtained after having tested that some have become
     * available in the meantime. This is the best that can be done.
     * This copes with streams such as the console in NT (but not on Unix,
     * because data which are keyed before a program has issued a read request
     * are taken by the shell), and with growing disk files.
     *
     * A readFully() can be provided which tries harder to deliver the
     * requested data by reading until they are obtained or the eof is
     * encountered. On blocking streams, such as the console, it keeps the
     * caller blocked until that many characters are entered, or an eof is
     * entered. On disk files, it makes no difference because when data are
     * not available, an eof is returned, and thus it behaves as the normal
     * read(). Since its usefulness seems quite debatable, it is not provided.
     *
     * By default, when no data are available, read() returns an eof, and
     * when already at eof, it returns immediately it again because for
     * IoStream eof means really the end of data. If ENDLESS is specified,
     * when no data are available, zero data are returned, and no eof.
     * Note that in the latter case there is no triple ^D problem because ^D
     * is not interpreted as eof, and thus it does not terminate the file.
     *
     * Some notes on the behaviour of the InputStream.read(buf): on the
     * console a read() either returns -1, whic is when a ^D/^Z alone has
     * been entered, or it returns characters taken from the last introduced
     * line, if any, otherwise it blocks. If no data are left to be returned
     * from the last introduced line, read() blocks.
     *
     * The index
     *
     * The index should be faithful: if it is stated that the index after
     * a transfer operation is advanced to the next available index position,
     * then there is a need to define what happens when a same file is
     * concurrently written. E.g. suppose a same file is opened twice by a
     * same application or by two different ones.
     * Then the first writes 3 data, and then the index becomes 3, then the
     * second writes 4 data, and then the first writes again. Does this last
     * write at index 3 or 7? It does not depend on the underlying buffering
     * made by the filesystem or not, but it does on the kind of device:
     * for disk files, it occurs at the index of the handle, while for
     * sequential devices it occurs at that of the file (i.e. it can only
     * be sequential).
     * For files which are opened in random mode it occurs at the index of
     * the handle; sequential devices may not be opened that way, and thus
     * such an open is rejected (n.b. in Unix RandomAccessFile("/dev/tty","rw")
     * is accepted, in NT RandomAccessFile("con","rw")) not, and IoStream
     * rejects both).
     * For sequential access IoStream states that the index is not kwown.
     * However, it is possible to know after a read() that the index is at
     * the eof, and it could be possible to know how many data have been
     * transferred by an IoStream (which could be different from the data
     * present in the file).
     * The index in sequential access woud not be very useful anyway.
     * If the user needs to know the index it should open a file in random
     * mode.
     * It could be possible to keep an internal index telling the amount
     * of data transferred by a same (read or write) kind of operations.
     * However, in sequential mode that index could overflow. Moreover,
     * there would be a need for mixed byte/char files to determine the
     * length in bytes of the character text transferred. This is too
     * complex for the uses it can have. It would require to keep also
     * two extra fields for the read and the write indexes (the current
     * one is used to limit the get operations on interlocked files).
     *
     * The need to calculate the index also in sequential mode, at least
     * for internal use, is for supporting interlock, for which the index is the
     * value which is used to determine if the file is ended.
     * It is much more efficient to determine the overall amount of data
     * transferred sequentially than to calculate it for each transfer
     * because an adapter object sums the lengths of all the buffers that
     * transit through it (which can be different from the size of the file).
     * To support interlock there is no need to compute the index after each
     * IoStream read(): the adapter between the InputStreamReader and the
     * FileInputStream stops reading and delivering data when it reaches
     * the known length.
     * Note that when there is no need to know the amount of data transferred,
     * this adapter is not needed.
     * The index field for sequential files is used solely to count the bytes
     * read so as to be able to stop when reading in interlocked mode.
     * 
     * Files opened in interlocked mode may not be opened in read+write.
     * Write() on files on sequential devices would append to the end of the
     * file, and not to the position it was when it was opened. Therefore, it
     * is disallowed. Write in random mode would be possible. However, it is
     * better to limit interlock to read in sequential mode. Supporting it in
     * random mode requires to limit all read() to the origin size, including
     * the ones which are not buffered.
     *
     * Sequences of files (multifiles) are opened only in sequential access.
     * Random access is not allowed because there would be a need to translate
     * the indexes of the files after the first one, or to have the index
     * represent the position in the current file, which would be of little
     * use since it would refer to a file which changes dynamically as the
     * sequence is read.
     *
     * Implicit data buffer allocation
     *
     * It is possible to make read() allocate the area where data are read, and
     * return it. This saves most of the times the transfer of data in an user
     * area. It applies to read() and readln().
     * Moreover, for lines of characters, readln() can return the data in a Str,
     * which allows to be record lines of a varying length, and at the same time
     * return its length (which would not be possible with primitive
     * parameters). To hold the data, for read() it is either possible to
     * extend the buffer, or to allocate a dedicated one. The latter results
     * in extra memory, and thus the former is more efficient. To extend it
     * there is a need to copy the current contents anyway, and thus it is
     * shifted at the beginning. Then, the buffer is extended when there is
     * really no room for a block. This functionality may not be obtained
     * with a read() and readln() without parameters because it would not be
     * possible to tell whether bytes or characters are requested. A solution
     * is to have two separate methods, or to have a row parameter.
     * The latter makes the API simpler. Data can then be read and written
     * without moving them:
     *
     *        CharsRow row = new CharsRow();
     *        ...
     *        do {
     *            pkt.readln(row);
     *            if (pkt.eof()) break;
     *            opkt.write(row.buffer,row.offset,row.length);
     *        } while (true);
     *    }
     *
     * Encoding
     *
     * A restriction in java.io is that when a file is accessed in random
     * mode it may not contain characters whose encoding is one of those
     * supported when using sequential access. It ought to be independent on
     * the way a file is accessed. I.e. UCS2 should also be available on
     * sequential and all the other encodings in random access.
     * IoStream allows to use all encodings independently on the access method.
     * IoStream allows to use sequential and random access on any files that
     * allows both. I.e. the access mode and the format of the file are not
     * related, while in java.io character files may be accessed randomly
     * if and only if characters are in UCS2 or UTF8, or else they can only
     * be accessed sequentially. The only encoding which is supported by
     * both accesses is UTF8. IoStream allows to have indexable text files.
     *   
     * Unicode: when reading a file with UnicodeLittle and UnicodeBig encodings,
     * if the file does not have a byte mark, the intrinsic one is used; when
     * reading with the Unicode encoding, the byte mark is required.
     * In output it is always written.
     * When reading and writing by using the UCS2 encoding, byte marks are not
     * detected, nor they are written: they are just normal characters.
     * Characters are encoded with the most significant byte first.
     * This is consistent with java.io random access files and with java
     * strings (which do not give significance to byte marks).
     * In NT Unicode is UnicodeLittle with the byte mark.
     * Unicode SUN encoders are definitely wrong: the first String.getBytes()
     * of a thread would deliver the byte mark while the subsequent ones would
     * not.
     *
     * Mixing of characters and bytes
     *
     * Mixing of characters and bytes in a same file is important to support
     * creation and reading of files for general usage. Note that a file with
     * bytes and encoded characters can e.g. be a PDF one.
     * This means that there is no characterization of a file when it is
     * opened. It can be opened as a byte one, and when characters are
     * transferred, a converter is used.
     * Note that a file could contain several parts of text in differing
     * encodings. In such a case there would be a need to re-create the object.
     * This means also that such files are byte files and that there is no
     * encoding associated to the file, which is instead the case when a file
     * contains characters only (which is by far a very common case).
     * If an encoding has been set, then character transfers are done in that
     * encoding.
     * There are two cases: 1. when a file is made entirely of characters
     * (and then the encoding is known from the very beginning), and 2.
     * when a file is a mixture of characters possibly encoded in several
     * ways, and bytes. The first is obtained by passing the encoding name to
     * open(), or the CHARS mode (which implies the default encoding) and
     * creating the converter immediately, and the second by creating it on
     * demand for the specified encoding.
     * Note that the encoding must be told because there is no way to determine
     * it in general for files. Even on existing files it is only possible to
     * guess it. URL connections do not know it either because even when the
     * encoding is present in HTML files meta tags, they are not sent as part
     * of the HTTP header.
     * To open, if encoding is specified, then character transfer only is
     * enabled. CHARS with no encoding specified is the same as the default
     * encoding. It overrides BYTES.
     *
     * When the default encoding is chosen, and the file is a standard one
     * opened in output, it is not wrapped in an OutputStreamWriter.
     * A PrintStream, even if it is a byte stream, uses the default encoding
     * when printing characters.
     * It is quite common to have programs which produce output to the standard
     * output, that is piped by shells into other programs.
     * However, when a different encoding is selected, it is wrapped.
     * N.B. a FileOutputStream(FileDescriptor.out/err) is not used (even if
     * it would be the most efficient solution) because it would not make the
     * redirection of System.out and System.err work.
     * PrintStream requires also to check io error after each operations
     * because it does not return io exceptions. It is something special for
     * System.out and err.
     * PrintStream also flushes when a "\n" is transferred. This seems,
     * however, of little use in it and also as a general feature.
     *
     * The default encoding for PrintStream, for InputStreamReader and for
     * OutputStreamWriter is not the file.encoding, but the platform one,
     * which may not be changed.
     * Even if the java.io classes would use the default encoding, inquiring
     * it at a later time could deliver an encoding which is different from the
     * one effectively used when an io object was created.
     * Thus, InputStreamReaders and OutputStreamWriters are always created
     * with an explicit encoding. The name of the encoding as passed to
     * open() is taken to be the one that identifies that encoding and it
     * is replaced by the one provided by the reader/writer getEncoding()
     * when the converter is created. This allows to have its canonical
     * name, which is the unique one that identifies the encoding. Note that
     * a same encoding can be indentified by several alias names, but by
     * only one canonical name.
     * It is tested to determine when it changes as a result of a
     * setEncoding().
     * For PrintStreams the current file.encoding is taken to be the encoding
     * used. It could be wrong if the System property file.encoding has
     * changed in the meantime, which would be wrong anyway because it would
     * be useless.  A way to determine the encoding for PrintStreams is to
     * create an OutputStreamWriter and inquiry it, but that is too much
     * inefficient.
     *
     * - Output:
     *
     * To mix bytes and characters there is a need to keep two buffers and
     * an encoder between them. In output, characters are put in the
     * characters buffer, and that in sequential mode continues as long as
     * characters are written. When the character buffer is full, its contents
     * is encoded and moved to the byte buffer by an OutputStreamWriter.
     * When bytes are written, and the characters buffer is not empty, the
     * OutputStreamWriter is flushed into the bytes buffer first. The final
     * flush() flushes both.
     * To implement it, an OutputStreamWriter can be built on top of an
     * OutputStream. Buffering should be done to encode blocks and to write
     * blocks on both of them, and flushing must be done on the former before
     * writing on the latter. A flag could be used to remember the kind of
     * last transfer so as to avoid unnecessary flushes when two consecutive
     * writes of the same kind are done. When a byte operation has to be done,
     * first the character writer is flushed (or alternatively, when a character
     * operation is done, the Writer is also flushed afterwards).
     * A FileWriter is of little use because it creates only a
     * FileOutputStream and wraps it into a OutputStreamWriter with the
     * default encoding. A PrintWriter is of little use also since it
     * adds only the handling of newlines.
     * Currently, an OutputStreamWriter is used when there are character
     * transfers, but that is not the best because it has its own internal
     * buffering of bytes, which is large. Moreover, it is not optimal for
     * mixed character and byte transfer because to do that there is a need
     * to have a byte buffer accessible, which means that there will be two
     * (this one and the one inside the OutputStreamWriter).
     * Buffering on top of OutputStreamWriter is done because it avoids too
     * many calls to the converter.
     * Note that the flushing of the characters buffer implies no output.
     * The OutputStreamWriter writes its bytes by means of an adapter into the
     * bytes buffer, which is then flushed only when it is full (or explicitly
     * flushed). This means that flush() flushes the OutputStreamWriter
     * and also the bytes buffer.
     * Even if FileOutputStream has an empty flush(), that might not be the
     * case with other OutputStream's.
     * Note that OutputStreamWriter has a method which writes any bytes still
     * pending inside it without performing a flush(), but it is not public.
     * The adapter allows to have this behaviour.
     * Without a possibility to call such a flush, the mixing of characters
     * and bytes implies some unnecessary flush if done by a user class.
     * In sequential access, with autoflush enabled, a byte write moves the
     * data in the bytes buffer if it is not empty, and then it writes
     * immediately any remaining data. This means that if autoflush is always
     * on, all writes are immediate. This allows also to support enabling and
     * disabling of autoflush. When a character write is done, the
     * OutputStreamWriter is called to convert the data, and then a flush is
     * done.
     * The output adapter buffers by default into the bytes buffer, unless
     * AUTOFLUSH is on, in which case it writes immediately.
     * When the stream is a PrintStream (e.g. when the file is a standard file),
     * the double buffer pipe is already there: there is a BufferedWriter on top
     * of an OutputStreamWriter (which means two buffers) and thus data are
     * transferred directly by calling its methods.
     * The byte buffer in it is not used for direct byte transfer because it
     * is impossible to access it. However useful, a PrintStream may not be
     * used here as a general tool because it does not allow to specify the
     * encoding.
     *
     * Wrapping with an OutputStreamWriter is needed for PrintStreams only to
     * support encodings. A PrintStream is capable to write characters in the
     * default encoding only. If the requested encoding is different, there is
     * a need to wrap it with a converter. Flushing not needed for unwrapped
     * PrintStreams when bytes are written after characters because it
     * mixing is supported by PrintStream.
     *
     * - Input:
     *
     * To mix characters and bytes in imput it is not possible to use the
     * dual technique of that used in output.
     *
     * -- Problems
     *
     * It is possible to decode a requested number of characters; it is
     * not possible to do the opposite, i.e. given a number of characters, to
     * tell the number of bytes which generated those characters.
     * Most encodings are fixed one byte (ASCII, ISO, CP, ...), others are
     * two bytes (e.g. UCS-2), others need to scan the byte sequence,
     * some in a simple way and some others in a way which is rather specific
     * (e.g. for Cp1381, which is a DBCS, two bytes characters are the
     * ones whose first byte belongs to a set of values, rather sparse),
     * but for shift-lock encodings several byte sequences map onto a same
     * character sequence (e.g. there can be redundant lock-shift sequences).
     * Moreover, when a byte sequence has been decoded, and it is followed
     * by a shift-out sequence, and the number of the requested characters
     * has been reached, the shift-out sequence can be decoded as well, or
     * be left for the next turn.
     * This means that it is impossible to guess the number of bytes converted
     * by e.g. an InputStreamReader read() call.
     *
     * Being this the situation, let's even suppose that the sun.io converters
     * were available, and let's see what need be done to read sequentially
     * a stream in which characters and bytes are mixed.
     * Let's first consider the case of read() and then that of readln().
     *
     * For read(), the converter can be called telling it the number of
     * characters to convert. It retuns the numbers the converted bytes.
     * A subsequent read() of bytes would read starting at that index.
     * In converters, the ConversionBufferFull exception is provided to obtain
     * a given number of characters: the converter is called to convert bytes
     * into an array that hold the delivered characters.
     *
     * For readln() the situation is much worse because the number of characters
     * to convert is not known in advance. A solution could be to call the
     * converter telling to fill a character buffer. The converter may try to
     * convert bytes which are after those that make up the line, and then
     * encounter a malformed byte sequence. Even if there would be a means to
     * position the byte index to the last well formed byte sequence, and force
     * the status of the converter to be consistent with that positioning (i.e.
     * throw away bytes buffered into the converter, or reset an internal
     * state), it could happen that the converter decoded some well formed
     * byte sequence after the line which made it lock-shift. That sequence
     * can belong to a subsequent line or even belong to a part of the stream
     * which does not represent characters. There are two problems: the first
     * is to determine the byte index corresponding to the end of the line
     * (which is needed because the line could be followed by bytes, in which
     * case they need be taken from the bytes buffer starting at that index),
     * and the second is to make the status of the converter consistent with
     * that index. To determine the byte index, the character buffer ought to be
     * scanned to seek the end of the line, and then, knowing the number of
     * characters in the line, after having restored the byte buffer, the
     * converter should be called a second time to convert that many
     * characters so as to know now the byte position where it stops. However,
     * the lock-shift status of the converter could have changed, and since
     * there is no way to get or set it, it is not possible to restart the
     * former conversion.
     * There is no way to make an InputStreamReader throw away the unused
     * characters and reset so as to be ready to convert fresh characters.
     * Firstly, there is no way to clear its internal buffer, and secondly,
     * when a MalformedInputException occurs, the InputStreamReader
     * does not discard the offending bytes, and thus when called again throws
     * the same exception. Note that such an exception can occur because the
     * bytes in its byte buffer which are not part of characters are likely to
     * form illegal sequences. The only way is to throw it away and construct a
     * new one. Thus, it is viable only when the shifts between characters and
     * bytes are few in a file. This is needed for multibyte encodings.
     * Moreover this solution is inefficient because it implies actually to
     * decode the character twice.
     *
     * Another solution could be to convert one character at a time, which is
     * very inefficient.
     * A better solution would be to have the converters able to stop when
     * the end of the line has been reached.
     *
     * A more viable solution is to use an adapter class which detects the
     * end-of-line and does not deliver bytes past it. The converter is then
     * called to fill a character buffer, and upon return, if the converted
     * characters end with and end-of-line, conversion stops, otherwise it
     * is called again until that happens (or the end of the file is detected).
     * That is needed only whe mixing characters and bytes and when reading
     * lines. It is not used for files which are made solely of characters.
     * This solution works also if the sun.io converters are not available.
     * Moreover, the current sun.io converters are designed to convert as many
     * btyes as possible, and in the event an incomplete sequence is found at
     * the end of the byte buffer they eat it and keep it inside, waiting to
     * be fed with the remaining part. This means that they keep an internal
     * state, and bytes as well. This is not the best when accessing files in
     * random mode. It is unlikely that they will be changed so extensively as
     * to support stopping at end-of-line.
     * Thus, decoders are used to supply legal sequences only to sun.io
     * converters.
     *
     * -- Architecture
     *
     * This is how the solution adopted works:
     *
     *                         adp            isr
     *              bb     ,---------.   .-----------.   .-----------.cb |
     *  ,-----.  ,------.  | adapter |-->|buf| conv  |-->| character |---> app
     *  | str |->| byte |->|---------|   |fer| erter |<--|  buffer   |<--+ lic
     *  | eam |  |      |<-| adapter |<-'`-----------'   `-----------'   | ati
     *  |     |<-|buffer|  `---------'        osr                        | on
     *  `-----'  `------'<----------------------------------------------->
     *                                                                   |
     * There are a couple of adapters, an OutptStreamWriter and an
     * InputStreamReader converters. The character buffer is the IoStream
     * one. These converters can also be directly the character converters
     * (however that is feasible only when they become available).
     *
     * In interlocked character mode, an adapter is created, and then
     * everything proceeds as for non-interlocked mode. In interlocked byte
     * mode the adapter is not created because it is more efficient to test
     * completion in read and because there would be a need to avoid the
     * creation of two adapters when characters would be read.
     *
     * When a file is opened in CHAR mode, one or two converters are created.
     * For a random access which is used only to read, only an input converter
     * is created.
     *
     * In sequential mode, when the stream is made of characters only, the
     * InputStreamReader makes the byte buffering and IoStream the character
     * buffering. An adapter is created only when the file is opened in
     * interlocked mode. When the stream is made of bytes only it is as if it
     * were made of bytes and characters. If a file is made of bytes only and
     * not in interlocked mode, buffering is done in IoStream and the adapter
     * avoided. As a matter of fact, the InputStreamReader and the adapter are
     * created on demand.
     * When bytes and characters are mixed, an IoStream read() is done, which
     * makes a read() on an InputStreamReader (isr), which makes a read() on
     * an adapter (adp). IoStream, before making the isr.read() determines
     * the number of bytes to be handed to it by decoding the contents of the
     * byte buffer, and then tells adp.read() to deliver them.
     * Since prior to executing an isr.read() for characters, one for bytes
     * could have occurred, there could be bytes in the byte buffer. Thus, the
     * adapter gets always data from the bytes buffer.
     *
     * In random mode, since only read(byte[]) in RandomAccessFile is efficient,
     * and the same for write() (character operations are implemented there
     * with a loop of elementary operations), character read() and write() are
     * implemented by using an InputStreamReader and an OutputStreamReader
     * (and an adapter) which operate on the bytes buffer, and flush it at the
     * end of the operation.
     * Character operations are implemented with an InputStreamReader and an
     * OutputStreamReader also to support all encodings.
     *
     * When the converter (InputStreamReader) is run, it moves bytes from the
     * byte buffer into the character one. The former is empty on average when
     * IoStream uses buffering of characters (providing that the characters
     * buffer is larger than the bytes buffer), which is the default for
     * sequential access, but not for the direct access. When there is a need
     * to read bytes, in a random access file, they are read directly.
     * I.e. there is no need to store the bytes read (and then converted)
     * somewhere, which is instead necessary for sequential files so as not to
     * loose them.
     *
     * For ISO8859_1 and UCS2, a fast read(ln) and write(ln) which move and
     * encodes directly from bb into user area is provided because it saves
     * 20% of time. The creation of the adapter, decoder, and InputStreamReader
     * is avoided. These two encodings are handled because the former is
     * the first 256 Unicode characters, for which decoding is extension
     * and the latter requires concatenation of bytes only (and is also not
     * supported by java.io).
     * In the case of random, the number of bytes read could be reduced
     * to 256 for readln() and to toChar*N for read(), where N is the
     * average number of bytes for the encoding used. This is to avoid to
     * read more bytes than needed since the unused ones will be thrown away.
     * However, N is difficult to determine, except for fixed length
     * encodings, like e.g. ISO8859_1 and UCS2.
     *
     * -- Trailing lock-shifts
     *
     * When reading characters in random access, there is a need to make the
     * InputStreamReader read also the lock-shift sequences which could be
     * present after the byte sequences for the characters and that were
     * written by write() methods to restore the initial charset. If that is
     * not done, the reader does not go back to the unshifted state, needed to
     * read other characters in a subsequent read (possibly in another position
     * in the file).
     * This is also done when a file is accessed in sequential mode.
     * OutputStreamWriter.write() writes also the bytes needed to go to the
     * initial state (n.b. to avoid redundant lock-shift sequences there is a
     * need to plug a BufferedWriter on top of it).
     * IoStream autoflushes all random writes, ensuring thus that each sequence
     * of characters which has been written by a single write() can be read
     * by a single read().
     * Infact, after a read, if a lock-shift encoding has been used and its
     * status is shifted, all lock-shift sequences (if any) present after the
     * characters are read and converted until the status becomes unshifted
     * (this is done inside loadDecode()). The InputStreamReader is called to
     * read one character, but it actually converts only the bytes which are
     * handed to it by the adapter, and thus no characters are skipped.
     * It is called repeatedly so as to read all such sequences and take the
     * converter to the appropriate shift state.
     * As a matter of fact, this is also done when reading in general because
     * characters can be preceded by any number of lock-shift sequences.
     * Note that a shift-in sequence at the end of characters read by a
     * read() are eaten. If the file has been generated by a write(char[])
     * followed by a write(byte[]) and the latter by chance contains such
     * a sequence, it is not a problem because the former writes it.
     * When reading a sequence of files, trailing lock-shifts are read
     * at the end of the read() operation, not at the end of the inner read()
     * on the current file because when a file is ended, a close() is done,
     * which flushes the InputStreamReader forcing it to read such sequences
     * and thus to go back to the unshifted state.
     *
     * -- Input flushing
     *
     * When accessing in random mode, before loading the bytes buffer the index
     * is obtained. After decoding, the number of bytes decoded in the buffer is
     * known, and thus it is possible to calculate the index. For random access
     * it is then easy to reposition the file. Note that if a subsequent
     * character read is done, the buffer will be loaded again. This, however,
     * is needed to deliver to the caller the most updated values present in
     * the file (n.b. another application could have written new data at those
     * positions, and the buffer contain the old ones).
     * To keep the new positioning and the bytes buffer consistent, the latter
     * is emptied.
     *
     * -- Interworking between converter, decoder and adapter
     *
     * Concerning the interworking of the converter, the decoder and the
     * adapter, a solution is to use the InputStreamReader as a wrapper, and
     * let multifiles, etc. be handled by the adapter. But this is what IoStream
     * does. However, it is not efficient to build an adapter on top of an
     * IoStream: there would be two IoStreams.
     *
     * There are two alternatives concerning the placement of the decoder.
     * The first is to call the decoder from within the adapter. The adapter
     * read() would delivers no more bytes than the ones needed to derive
     * the requested number of characters, or no more than a line.
     * After delivering characters, the adapter would decrement the requested
     * number.
     * When called again, and the bytes buffer is empty or an incomplete
     * sequence has been detected previously, it would try to refill the buffer.
     * It would run then the decoder. If it catches a malformed sequence, it
     * would throw an exception. The bytes sequences are there available, or
     * there are none. Only in the case of byte sequences across files an
     * adapter could deliver 0 character and collect bytes.
     * If the decoder delivers fewer than the requested characters, but some,
     * the corresponding bytes are delivered. The problem is when the decoder
     * delivers zero characters: there are two causes: 1. there are too few
     * bytes, or 2. there is no valid sequence. In the former case, the
     * remaining bytes must be shifted and the buffer refilled, in the latter,
     * read() must stop and return 0 bytes. This is the case when characters are
     * requested, none are available, and the file is not at eof. In this case
     * an exception is thrown. This is why decoders deliver the reason for
     * stopping.
     * When the requested number of characters have been reached, or the
     * end-of-line detected, or the byteIndex is at the end of the byte buffer,
     * there could be valid byte sequences after the ones decoded.
     * The problem exists also when there are fewer characters than requested:
     * they can be followed by an incomplete byte sequence which continues
     * on the next buffer. However, there is a need to process these bytes
     * before refilling the buffer.
     *
     * The second alternative is to call the decoder before calling the
     * InputStreamReader. This is not much different from the previous one,
     * but it is better because it allows to know in advance the number of
     * characters which will be read. E.g. is allows to allocate the array
     * in which the data can be stored, or to chech that an existing array is
     * large enough.
     * This solution is feasible because to support asynchronous arrival of
     * data, IoStream read() makes an attempt to get as much data as possible
     * and then to get more if in the meantime some have become available.
     * Thus, the read() of the underlying stream could be called several times,
     * including the adapter read().
     * The latter could also deliver 0 characters, but collect bytes.
     * In effect, it is possible to avoid to call an IoStream.read() in it
     * because in readln() and read() there is a loop which is iterated as
     * many times as needed to have the requested line or characters
     * (providing that data are available, otherwise the loop will stop, but
     * also an io operation here will stop anyway).
     * Note, however, that if the adapter read() returns 0 bytes, it is
     * calld again.
     * To support this solution, the adapter available() returns 0 when
     * the adapter is in bounded delivery mode. InputStreamReader
     * then does not attempt another adapter read, and returns. When the
     * requested characters are not yet obtained, the byte buffer is refilled,
     * the decoder run, and another InputStreamReader.read() call made.
     * To make another iteration, the adapter available() is called. In this
     * context, it returns the number of data which are really available.
     *
     * -- The bytes buffer
     *
     * Concerning the placement of the bytes buffer, there are these
     * alternatives: 1. when IoStream asks IoDecode to buffer, it passes the
     * buffer. This is not viable because there is a need to pass also the
     * indexes in it. 2. the opposite, which is also difficult because
     * IoStream could have a buffer already in place to serve a previous
     * read() of bytes in sequential mode.
     * To overcome this, the byte buffer could be an instance of a class which
     * contains also its indexes, and that can be accessed by both.
     * 3. to implement the adapter as an inner class, which allows both IoStream
     * and the adapter to access the buffer.
     * The byte buffer is needed in IoStream also for output, and this is
     * another reason to place it there.
     *
     * In input, either the file is made of characters only, and then the byte
     * buffer is not used (it is hidden in the InputStreamReader), or the
     * character buffer is not used because the characters are converted
     * directly into the user area. This means that there would be no need to
     * have two sets of indexes. However, that is needed to determine if there
     * are characters to flush into the byte buffer before making a byte
     * write.
     *
     * -- End-of-line
     *
     * Concerning the the end-of-line detection, decoders detect CR or LF, and
     * when found, check the following byte if present in the buffer so as to
     * return it as well when a CR is found and the next is a LF.
     * This means that when a CR is found, and no more bytes are available in
     * the buffer, or it is not immediately followed by a LF (e.g. it can
     * be followed by escape sequences), character detection stops at CR.
     * The caller calls then again the decoder to obtain another character,
     * possibly refilling the buffer first. The number of times CR LF is
     * immediately detected is much higher than the number of times there is
     * a need for a second call.
     * If after a CR, LF is not found, there are the following causes:
     *
     *   - there are no more bytes
     *   - the next byte is not an LF
     *   - there are not enough bytes (this for Unicode only)
     *
     * There would be no need to detect the last one: suppose the LF is across
     * block boundary. The decoder returns only the bytes up to CR. Then the
     * InputStreamReader is called again to read one character, an incomplete
     * sequence is found, and the adapter called again to complete it.
     * Detecting it in the decoder makes it faster.
     * The rule that lines are not terminated by byte sequences which are
     * not characters simplifies things, and also makes the file somehow
     * independent from the encoding, which would not be the case if a line were
     * terminated also by non-character sequences because which sequences
     * are characters is higly dependent on encodings (e.g. in sigle  byte
     * encodings any byte is also a character).
     *
     * -- End-of-file
     *
     * There is a need to define what to do when a read() of 0 character is done,
     * and the file is positioned at a point in which a lock-shift is present:
     *
     *    1. the lock shift is read. This does not seem good because it can
     *       be the beginning of another character. In sequential mode it
     *       would not be much of a problem, but it could be in random mode
     *       because that sequence could be a shift-out, not followed by a
     *       shift-in, and that would leave the converter in the wrong state.
     *    2. it is not read. In this case, if the sequence is the only one thing
     *       present up to the end of the file, no eof would be returned.
     *
     * A write() of 0 characters does not produce a shift-in sequence; it produces
     * no bytes altogether. Thus, a character file written by a Java program
     * would never contain such a sequence at the end. Only a mixed file, in which
     * a bytes write has been done at the end could contain it, or a character
     * file written by some other application which has inserted an extra shift-out
     * sequence. Since it must be possible to read back bytes which have been
     * written after characters, and since the state of the converter must be
     * kept aligned with what characters have been read, the second alternative
     * is the only one solution. When that sequence it the only one up to the
     * end the caller would not receive an eof, and if the file is a character
     * only file it would infer that some characters be present, which would not
     * be be the case. However, that would also be a non-standard character file.
     * Thus, when reading 0 characters, loadDecode() does not call the decoder.
     * However, it calls load() to refill the buffer, which allows it to detect
     * the eof. Note that the InputStreamReader is never called to deliver 0
     * characters because that does not detect the eof; load() is called instead
     * to refill the buffer.  
     *
     * Read() tries to decode as many bytes as possible to deliver the
     * requested number of characters. This means that when less characters are
     * present and they are followed by lock-shift sequences, those sequences
     * are considered part of the characters. This can occur only at the end
     * of the file, which would be a non-standard one.
     * Note that decoders can not associate shift-in sequences to the following
     * character because, when called, they do not know if there is a character
     * sequence or not after a sequence of shift-in.
     *
     * -- Incomplete sequences
     *
     * There is no requirement in java.io to end text files in unshifted state
     * when they are closed.
     * When reading, and less bytes than needed to deliver the requested
     * characters are found in the file, the bytes which make up complete
     * sequences are decoded, and the characters returned. It could occur
     * that an incomplete sequence is present at the end. If the file is
     * then closed, the incomplete sequence is discarded.
     * If instead another read is done, and if more bytes have become
     * available in the meantime, the sequence could have become complete,
     * and thus it is decoded, or an error is then returned because in such
     * a case it is likely that no more data will really come.
     * Since to detect eof, files are read until eof is returned (and not
     * until less characters than requested are returned), that means that
     * when no more data are present, there must not be an incomplete sequence.
     * This is also the way to allow input to arrive in the meantime: if
     * the incomplete sequence were rejected as an error, there would be no
     * way to read a file which grows over time and whose bytes become
     * available in chuncks which can break sequences.
     *   
     * To provide this behaviour, in read() and readln() loops when loadDecode()
     * is called, it returns characters until some are found, and it returns
     * zero when an incomplete sequence only has been found and the number of
     * characters is less than the buffer capacity, or there are no more bytes
     * available. The read loop in such a case is left. Note that this allows
     * not to set the pending eof, which must not because otherwise the next
     * read would return eof without trying to read more bytes, which might have
     * become available. Moreover, the reading and decoding of a shift-in
     * sequence is done only if bytes are available so as not to block read()
     * waiting for it and not to set a pending eof.
     * 
     * When reading 0 characters in CHARS, an attempt is made to refill the
     * characters buffer to detect the eof. If in the file an incomplete
     * sequence is present, this results in an error. The issue is that the
     * loading of the buffer is done by IoStream when it needs, and if in the
     * file an encoding error is present, the user should not rely on the
     * precise instant in which it is detected.
     *
     * Sequences of files and encoding
     *
     * When a sequence of files is read, it is not possible to have files with
     * different encodings. To support it there would be a need for a way to
     * specify the encoding in the filespec (which might also be useful in
     * commands in general). This, however, would be quite uncommon. It is
     * also uncommon the case in which there is a need for an application to
     * read several files in different encodings. When an application has to
     * deal with files which are all in an encoding which is different from
     * the default one, a qualifier can be given to specify it, or an
     * environment parameter set.
     */

    /**
     * Tell if the AT_EOF attribute is true. It delivers true if
     * the last read operation attempted to transfer data beyond the
     * last available one.
     *
     * @return     <code>true</code> if end of file
     */

    public boolean eof(){
        return (AT_EOF & this.status) != 0;
    }

    /**
     * Read a line. The line is made by all the characters up to and
     * excluding a CR or LF or CR LF or the end of the file. After the last
     * line each call returns eof. The last line of the file can be
     * optionally terminated by the line terminator.
     * When reading a sequence of files, the last line in a file which
     * is not terminated by a line terminator is not concatenated with
     * the first of the following file. I.e. lines do not cross files.
     * The line is returned in a Str object which is extended so as
     * to hold the line. Note that there are no limits on the length of
     * the line. The first datum which is read is the one whose index is
     * the transfer index. The transfer index is the value of the (current)
     * index. If the transfer index is beyond that of the last datum in
     * the file, the AT_EOF attribute is set and no data trasfer takes
     * place, otherwise the data are transferred and the current index
     * advanced to the next index after the one of the last datum read.
     *
     * @see        #readln(CharsRow)
     * @param      s return string
     */

    public void readln(Str s){
        if (this.mutex != null){
            synchronized (this.mutex) {
                readlnStream(s,null,false);
            }
        } else {
            readlnStream(s,null,false);
        }
    }

    /**
     * Read a line, and deliver a reference to it. The row refers to
     * an array which holds the data and which is implicitly allocated.
     * The array is guaranteed to contain the whole line plus an additional
     * terminator character (which is not counted in the line length).
     * If the line is longer than <code>maxLine</code>, an error is
     * returned. This method must not be used when the object is accessed
     * concurrently by several threads.
     *
     * @param      row to the line
     */

    public void readln(CharsRow r){
        readlnStream(null,null,false);
        r.length = this.nrRead;
        if (this.res == 0){
            r.buffer = this.charInBuf.buffer;
            r.offset = this.offset;
        }
    }

    /**
     * Read a line of bytes, and deliver a reference to it. The row refers to
     * an array which holds the data and which is implicitly allocated.
     * This method must not be used when the object is accessed concurrently
     * by several threads.
     *
     * @see        #readln(CharsRow)
     * @param      row to the line
     */

    public void readln(BytesRow r){
        readlnStream(null,null,true);
        r.length = this.nrRead;
        if (this.res == 0){
            r.buffer = this.byteInBuf.buffer;
            r.offset = this.offset;
        }
    }

    /* The line separator of the line read by readln(). */
    public String lineSeparator;

    /* The \r line separator. */
    private static final String CRLineSep = "\r";

    /* The \n line separator. */
    private static final String LFLineSep = "\n";

    /* The \r\n line separator. */
    private static final String CRLFLineSep = "\r\n";

    /* The empty line separator. */
    private static final String NOLineSep = "";

    /**
     * Read a line of characters or bytes. If an iterator is present, it
     * steps over the files it delivers.
     *
     * @param      s return string of characters
     * @param      rb return row of bytes
     * @param      bytes <code>true</code> to deliver bytes
     */

    /*
     * When a line of a device file is not empty and is terminated by
     * an eof (^D in Unix), the line is read, the eof is not returned
     * by the FileReader.read(), and thus there is a need for a eof
     * on a line alone to make readline() aware of it. However, readline()
     * has accumulated some characters, and thus returns them and does
     * not return an eof because it is still delivering characters.
     * It remembers this by setting PENDING_EOF so that the next time it
     * delivers an eof. Note that the equivalent BufferedReader.readLine()
     * instead requests a third eof to be entered.
     *
     * In single file mode (i.e. when there is no iterator), if the file
     * is not open, an error is returned immediately. In multifile mode,
     * a loop is entered and files opened in sequence. Since open() and
     * close() change the mode, the mode is restored across them. This is
     * done in order to allow reads after the eof to return an eof again
     * and not an error, which would instead be the case if the READ open
     * mode, cleared by close() were not restored. The mode is cleared
     * by a close() called by the application.
     *
     * When a decoder is used in readln, and the line is completely
     * contained in the bytes buffer, its length is known, and thus it
     * could be possible to extend the user area to that size and convert
     * the bytes directly into it. This is not done because it provides
     * little benefit for the case of mixed files, which is not common, and
     * complicates the code.
     *
     * A means to limit readln() to read at most a given number of data could
     * be provided. When a line has not be read completely a status or a
     * value can be returned. To provide it, there is a need to have decoders
     * which can stop when the line terminator is found while also checking
     * that the bound has been reached. The problem is that if a file which
     * is not a text file is passed to an application which reads lines,
     * that application might terminate because of a memory overflow. On the
     * other hand, also having a limit on the lenght of lines is not nice.
     * This feature is not provided for the time being. Instead, a check is
     * provided to reject lines longer than the configured limit, which does
     * not require decoders to stop, but only to quit the loop of incremental
     * line creation. This relieves applications to make the memory overflow
     * check.
     *
     * When a file is accessed in random mode no record is kept on the
     * reading of an eof because each read can be done in a different place,
     * and therefore there is a need to check it each time.
     *
     * Readln() does not make use of available() because it needs to block when
     * the data are not available. Note that when a line is terminated by ^D,
     * since the line terminator is not present, another read is done.
     * The real difference between available() and read() is that the former
     * does not block, and is 30% slower.
     */

    private void readlnStream(Str s, BytesRow rb, boolean bytes){
        excInit();
        this.nrRead = 0;
        if (s != null) s.length = 0;
        doit: try {
            if ((FL_B & this.trc) != 0){
                Trc.out.println("readln: " + trcmode());
                if ((RANDOM & this.mode) != 0){
                    Trc.out.println("readln: " + index());
                }
            }
            this.status &= ~DATA_BREAK;
            if ((IS_OPEN & this.status) == 0){            // file not open
                if (this.iter == null){
                    registerError(IOError.ERR_NOTOPEN,null);
                    break doit;
                } else if ((AT_EOF & this.status) != 0){  // return again eof
                    break doit;
                }
            }
            if ((READ & this.mode) == 0){
                registerError(IOError.ERR_INVOP,null);
                break doit;
            }
            this.lineSeparator = NOLineSep;
            this.offset = (bytes) ?
                this.byteInBuf.offset : this.charInBuf.offset;
            step: do {
                if ((IS_OPEN & this.status) == 0){        // file not open
                    if (this.iter.hasNext()){
                        int iod = this.nrIoDone;
                        Object fs = this.iter.next();
                        String fn;
                        String enc = this.openEncoding;
                        if (fs.getClass().isArray()){
                            fn = ((String[])fs)[0];
                            enc = ((String[])fs)[1];
                        } else {
                            fn = (String)fs;
                        }
                        openStream(fn,enc,this.mode);
                        this.offset = 0;                  // open resets buffers
                        this.nrIoDone = iod;
                        if (this.res != 0) break doit;
                        this.status |= DATA_BREAK;
                    } else {
                        this.status |= AT_EOF;
                        break doit;
                    }
                }
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("readln: " +
                        (bytes ? this.byteInBuf.offset :
                        this.charInBuf.offset) +
                        " " +
                        (bytes ? this.byteInBuf.length :
                        this.charInBuf.length) +
                        " " + this.offset);
                }
                if (bytes){                               // N.B. done here after
                    if ((BYTES & this.mode) == 0){        // .. the end iter check
                        registerError(IOError.ERR_INVOP,null);
                        break doit;
                    }
                }
                if (!bytes){                              // chars in byte stream
                    if ((this.readerStream == null) &&
                        (((ISO8859_1 | UCS2) & this.status) == 0)){
                        createInAdapter();
                    }
                }
                if (!bytes &&
                    ((ISO8859_1 & this.status) != 0)){    // faster handling
                    if (isoReadln(s)) break step;
                } else if (!bytes &&
                    ((UCS2 & this.status) != 0)){
                    if (ucs2Readln(s)) break step;
                } else if (bytes){
                    if (byteReadln()) break step;
                } else {
                    CharsRow charbuf = this.charInBuf;
                    loop: while (true){
                        if (charbuf.offset >=
                            charbuf.length){              // refill buffer
                            if (this.decoder != null){
                                int n = loadDecode(-1);
                                if (n < 0) break loop;
                                if (n == 0) break step;
                            }
                            if (s != null){
                                if (loadChars(0) < 0) break loop;
                            } else {
                                if (appendLoadChars(0) < 0) break loop;
                            }
                        }
                        if ((FL_C & this.trc) != 0){
                            Trc.out.println("read loop: " +
                                charbuf.offset + " "
                                + charbuf.length);
                        }
                        int i;                            // seek eol
                        char c = '\0';
                        if (this.decoder == null){
                            for (i = charbuf.offset;
                                i < charbuf.length; i++){
                                c = charbuf.buffer[i];
                                if ((c == '\n') || (c == '\r')) break;
                            }
                        } else {
                            i = charbuf.length;
                            c = charbuf.buffer[i-1];
                            if (c == '\r'){               // CR
                                i--;
                            } else if (c == '\n'){        // LF
                                i--;
                                if ((i > 0) &&            // CR LF
                                   (charbuf.buffer[i-1] == '\r')){
                                   c = '\r';
                                   i--;
                                } 
                            }
                            if ((FL_C & this.trc) != 0){
                                Trc.out.println("readln decode-end: " +
                                    i + " " + charbuf.length);
                            }
                        }
                        int piece = i - charbuf.offset;
                        if (this.nrRead + piece < 0){     // overflow
                            this.nrRead = Integer.MAX_VALUE;
                            break step;
                        }
                        if (s != null){
                            s.cutInsert(s.length,0,charbuf.buffer,
                                charbuf.length,
                                charbuf.offset,piece);
                        }
                        this.nrRead += piece;
                        charbuf.offset = i;
                        if (i < charbuf.length){          // \r or \n found,
                            if ((FL_C & this.trc) != 0){  // .. line complete
                                Trc.out.println("read eol: " +
                                    charbuf.offset + " "
                                    + charbuf.length);
                            }
                            charbuf.offset++;
                            if (c == '\r'){
                                this.lineSeparator = CRLineSep;
                                if (charbuf.offset >=
                                    charbuf.length){      // refill buffer
                                    if (this.decoder != null){
                                        int n = loadDecode(-1);
                                        if (n < 0) break loop;
                                        if (n == 0) break step;
                                    }
                                    if (s != null){
                                        if (loadChars(0) < 0) break loop;
                                    } else {
                                        if (appendLoadChars(0) < 0) break loop;
                                    }
                                }
                                if ((charbuf.offset < charbuf.length) &&
                                    (charbuf.buffer
                                        [charbuf.offset] == '\n')){
                                    charbuf.offset++;     // skip it
                                    this.lineSeparator = CRLFLineSep;
                                }
                            } else {
                                this.lineSeparator = LFLineSep;
                            }
                            this.lineNum++;
                            break step;
                        }
                        if (this.nrRead > this.maxLine){
                            this.nrRead = this.maxLine;
                            if (s != null) s.length = this.nrRead;
                            registerError(IOError.ERR_LONGLINE,null);
                            break doit;
                        }
                    } // loop
                }
                if (s != null) this.nrRead = s.length;
                if (this.nrRead == 0){
                    if ((FL_C & this.trc) != 0){
                        Trc.out.println("readln: end loop");
                    }
                    if ((this.decoder != null) &&
                        this.decoder.incomplete){
                        throw new CharConversionException();
                    } else if ((UCS2 & this.status) != 0){
                        if (this.byteInBuf.length -
                            this.byteInBuf.offset == 1){
                            throw new CharConversionException();
                        }
                    }
                    if ((ENDLESS & this.mode) == 0){
                        this.status |= AT_EOF;
                    }
                    if (this.iter != null){
                        int curmode = this.mode;
                        forceClose(false);
                        this.mode |= curmode;          // restore it
                        continue step;
                    }
                    break doit;
                } else {
                    this.lineNum++;                    // last line
                    if (this.nrRead > this.maxLine){   // when max < bufferSize
                        this.nrRead = this.maxLine;
                        if (s != null) s.length = this.nrRead;
                        registerError(IOError.ERR_LONGLINE,null);
                        break doit;
                    }
                    if (s == null){                    // row, last line
                        int len = (bytes) ?
                            this.byteInBuf.buffer.length :
                            this.charInBuf.buffer.length;
                        if (this.offset + this.nrRead >= len){
                            len++;
                            if (len < 0){
                                registerError(IOError.ERR_LONGLINE,null);
                                break doit;
                            }
                            if (bytes){
                                bytesBufferEnlarge(1,true);
                            } else {
                                charsBufferEnlarge(1,true);
                            }
                        }
                    }
                    break step;
                }
            } while (this.iter != null);
            if ((RANDOM & this.mode) != 0){
                completeRead();                        // invalidate buffer
            } else {
                if ((this.decoder != null) &&
                    (this.decoder.shiftState != 0)){
                    int n = loadDecode(-2);            // locate lock-shifts
                }
            }
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (IOError exc){
        } finally {
            if ((FL_C & this.trc) != 0){
                Trc.out.print("readln: ");
                if (!bytes){
                    if (s != null){
                        Trc.literalize(s.toString().toCharArray());
                    } else if (this.charInBuf.buffer != null){
                        Trc.out.print(" " + offset + " " + nrRead + " ");
                        char[] temp = new char[this.nrRead];
                        System.arraycopy(this.charInBuf.buffer,this.offset,
                            temp,0,this.nrRead);
                        Trc.literalize(temp);
                    }
                    Trc.out.println();
                } else {
                    if (this.byteInBuf.buffer != null){
                        Trc.out.println(byteToString(this.byteInBuf.buffer,
                            this.offset,this.nrRead));
                    }
                }
            }
            if (((EOF_EXCEPTION & this.mode) != 0) &&
                ((AT_EOF & this.status) != 0)){
                registerError(IOError.ENDOFFILE,null);
            }
            this.status |= NL_PRESENT;
            excTerm();
        }
    }

    /** The maximum length of input lines, by default 65536. */
    public int maxLine = 1 << 16;

    /** The offset in the buffer at which the line starts. */
    private int offset;

    /** The number of chararcters delivered. */
    private int nrRead;

    /**
     * Read a line for an ISO8859_1 encoding.
     *
     * @param      s string in which the characters are returned
     * @return     <code>true</code> if a line has been found
     * @exception  IOException 
     */

    private boolean isoReadln(Str s) throws IOException {
        BytesRow bytebuf = this.byteInBuf;
        this.offset = 0;
        if (this.charInBuf != null){
            this.charInBuf.offset = 0;
            this.charInBuf.length = 0;
        }
        boolean found = false;
        loop: while (true){
            if (bytebuf.offset >=
                bytebuf.length){                      // refill buffer
                if (load(0) < 0) break loop;
            }
            if ((FL_C & this.trc) != 0){
                bytesBufferTrace("isoReadln");
            }
            int bytes = bytebuf.length - bytebuf.offset;
            int j = 0;
            char c = '\0';
            int i = bytebuf.offset;                   // seek eol
            int max = i;
            if (s != null){
                int space = s.buffer.length - s.length;
                max += (bytes > space) ? space : bytes;
                j = s.length;
                for (; i < max; i++){                 // part which fits in s
                    c = (char)(bytebuf.buffer[i] & 0xff);
                    if ((c == '\n') || (c == '\r')) break;
                    s.buffer[j++] = c;
                }
                s.length = j;
                this.nrRead = j;
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("readln in str: " + j);
                }
            }
            if ((i == max) && (i < bytebuf.length)){  // not (yet) found, and
                j = 0;                                // .. more to scan
                int siz = bytebuf.length - i;
                if (s != null){
                    charsBufferExtend(this.charInBuf,siz,false);
                } else {
                    if (this.nrRead + siz < 0){       // overflow: reduce
                        siz = Integer.MAX_VALUE - this.nrRead;
                        bytebuf.length = i + siz;
                        found = true;                 // force loop exit
                    }
                    charsBufferExtend(this.charInBuf,this.nrRead + siz,true);
                    j = this.nrRead;
                }
                for (; i < bytebuf.length; i++){
                    c = (char)(bytebuf.buffer[i] & 0xff);
                    if ((c == '\n') || (c == '\r')) break;
                    this.charInBuf.buffer[j++] = c;
                }
                if (s != null){
                    s.cutInsert(s.length,0,this.charInBuf.buffer,
                        this.charInBuf.buffer.length,0,j);
                }
                this.nrRead = j;
            }
            bytebuf.offset = i;
            if (i < bytebuf.length){                  // \r or \n found,
                if ((FL_C & this.trc) != 0){          // .. line complete
                    Trc.out.println("read eol: " +
                        bytebuf.offset + " " +
                        bytebuf.length);
                }
                bytebuf.offset++;
                if (c == '\r'){
                    this.lineSeparator = CRLineSep;
                    if (bytebuf.offset >=
                        bytebuf.length){              // refill buffer
                        if (load(0) < 0) break loop;
                    }
                    if ((bytebuf.offset <
                        bytebuf.length) &&
                        (bytebuf.buffer
                        [bytebuf.offset] == '\n')){
                        bytebuf.offset++;             // skip it
                        this.lineSeparator = CRLFLineSep;
                    }
                } else {
                    this.lineSeparator = LFLineSep;
                }
                this.lineNum++;
                found = true;
                break loop;
            }
            if (this.nrRead > this.maxLine){
                this.nrRead = this.maxLine;
                if (s != null) s.length = this.nrRead;
                registerError(IOError.ERR_LONGLINE,null);
                throw this.excObj;
            }
            if (found) break loop;                    // overflow
        } // loop
        if ((FL_C & this.trc) != 0){                  // .. line complete
            Trc.out.println("isoReadln: " + found);
        }
        return found;
    }

    /**
     * Read a line for a UCS2 encoding.
     *
     * @param      s string in which the characters are returned
     * @return     <code>true</code> if a line has been found
     * @exception  IOException 
     */

    private boolean ucs2Readln(Str s) throws IOException {
        BytesRow bytebuf = this.byteInBuf;
        this.offset = 0;
        if (this.charInBuf != null){
            this.charInBuf.offset = 0;
            this.charInBuf.length = 0;
        }
        boolean found = false;
        loop: while (true){
            int rem = bytebuf.length - bytebuf.offset;
            if (rem <= 1){                              // refill buffer
                if (rem == 1){                          // shift on top
                    bytebuf.buffer[0] =
                        bytebuf.buffer[bytebuf.offset];
                }
                bytebuf.offset = rem;
                bytebuf.length = bytebuf.offset;
                int n = load(rem);
                bytebuf.offset = 0;
                if (n < 0) break loop;
            }
            int chars = (bytebuf.length - bytebuf.offset) >> 1;
            int j = 0;
            char c = '\0';
            int i = bytebuf.offset;                     // seek eol
            int max = i;
            if (s != null){
                int space = s.buffer.length - s.length;
                max += ((chars > space) ? space : chars) << 1;
                j = s.length;
                for (; i < max; i++){                   // part wchich fits in s
                    c = (char)((bytebuf.buffer[i++] << 8) |
                        (bytebuf.buffer[i] & 0xff));
                    if ((c == '\n') || (c == '\r')) break;
                    s.buffer[j++] = c;
                }
                s.length = j;
                this.nrRead = j;
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("readln in str: " + j);
                }
            }
            int level = bytebuf.length & ~1;            // even part, entire chars
            if ((i == max) && (i < level)){             // not found, and
                j = 0;
                int siz = level - i;
                if (s != null){
                    charsBufferExtend(this.charInBuf,siz,false);
                } else {
                    if (this.nrRead + siz < 0){       // overflow: reduce
                        siz = Integer.MAX_VALUE - this.nrRead;
                        bytebuf.length = i + siz;
                        found = true;                 // force loop exit
                    }
                    charsBufferExtend(this.charInBuf,this.nrRead + siz,true);
                    j = this.nrRead;
                }
                for (; i < level; i++){
                    c = (char)((bytebuf.buffer[i++] << 8) |
                        (bytebuf.buffer[i] & 0xff));
                    if ((c == '\n') || (c == '\r')) break;
                    this.charInBuf.buffer[j++] = c;
                }
                if (s != null){
                    s.cutInsert(s.length,0,this.charInBuf.buffer,
                        this.charInBuf.buffer.length,0,j);
                }
                this.nrRead = j;
            }
            bytebuf.offset = i;
            if (i < level){                             // \r or \n found,
                if ((FL_C & this.trc) != 0){            // .. line complete
                    Trc.out.println("read eol: " +
                        bytebuf.offset + " " + level);
                }
                bytebuf.offset++;
                if (c == '\r'){
                    this.lineSeparator = CRLineSep;
                    rem = bytebuf.length - bytebuf.offset;
                    if (rem <= 1){                      // refill buffer
                        if (rem == 1){                  // shift on top
                            bytebuf.buffer[0] =
                                bytebuf.buffer[bytebuf.offset];
                        }
                        bytebuf.offset = rem;
                        bytebuf.length = bytebuf.offset;
                        if (load(rem) < 0) break loop;
                        bytebuf.offset = 0;
                    }
                    rem = bytebuf.length - bytebuf.offset;
                    if (rem >= 2){
                        i = bytebuf.offset;
                        c = (char)((bytebuf.buffer[i++] << 8) |
                            (bytebuf.buffer[i] & 0xff));
                        if (c == '\n'){
                            bytebuf.offset += 2;        // skip it
                            this.lineSeparator = CRLFLineSep;
                        }
                    }
                } else {
                    this.lineSeparator = LFLineSep;
                }
                this.lineNum++;
                found = true;
                break loop;
            }
            if (this.nrRead > this.maxLine){
                this.nrRead = this.maxLine;
                if (s != null) s.length = this.nrRead;
                registerError(IOError.ERR_LONGLINE,null);
                throw this.excObj;
            }
            if (found) break loop;                    // overflow
        } // loop
        if ((FL_C & this.trc) != 0){
            Trc.out.println("ucs2Readln: " +
                bytebuf.offset + " " + bytebuf.length + " " +
                found + " " + this.nrRead);
        }
        return found;
    }

    /**
     * Read a line of bytes.
     *
     * @return     <code>true</code> if a line has been found
     * @exception  IOException 
     */

    private boolean byteReadln() throws IOException {
        BytesRow bytebuf = this.byteInBuf;
        boolean found = false;
        loop: while (true){
            if (bytebuf.offset >=
                bytebuf.length){                     // refill buffer
                if (bytebuf.offset == Integer.MAX_VALUE){
                    break loop;
                }
                if (appendLoad(-1) < 0) break loop;  // append a block
            }
            if ((FL_C & this.trc) != 0){
                bytesBufferTrace("byteReadln");
            }
            int bytes = bytebuf.length - bytebuf.offset;
            byte c = 0x0;
            int i = bytebuf.offset;                  // seek eol
            for (; i < bytebuf.length; i++){
                c = bytebuf.buffer[i];
                if ((c == '\n') || (c == '\r')) break;
            }
            bytebuf.offset = i;
            this.nrRead = bytebuf.offset - this.offset;
            if (i < bytebuf.length){                 // \r or \n found,
                if ((FL_C & this.trc) != 0){         // .. line complete
                    Trc.out.println("read eol: " +
                        bytebuf.offset + " " +
                        bytebuf.length);
                }
                bytebuf.offset++;
                if (c == '\r'){
                    this.lineSeparator = CRLineSep;
                    if (bytebuf.offset >=
                        bytebuf.length){             // refill buffer
                        if (appendLoad(-1) < 0)      // append a block
                            break loop;
                    }
                    if ((bytebuf.offset < bytebuf.length) &&
                        (bytebuf.buffer[bytebuf.offset] == '\n')){
                        bytebuf.offset++;            // skip it
                        this.lineSeparator = CRLFLineSep;
                    }
                } else {
                    this.lineSeparator = LFLineSep;
                }
                this.lineNum++;
                found = true;
                break loop;
            }
            if (this.nrRead > this.maxLine){
                this.nrRead = this.maxLine;
                registerError(IOError.ERR_LONGLINE,null);
                throw this.excObj;
            }
        } // loop
        return found;
    }

    /**
     * Refill the bytes buffer. The amount of data read is always the
     * bufferSize so as to optimize i/o.
     *
     * @param      off start offset in buffer at which bytes are returned
     * @return     number of bytes read
     * @exception  IOException 
     */

    private int load(int off) throws IOException {
        BytesRow bytebuf = this.byteInBuf;
        bytesBufferEnsure(bytebuf);
        int n = get(bytebuf.buffer,off,this.bufferSize);
        bytebuf.length = off + ((n < 0) ? 0 : n);
        bytebuf.offset = off;
        return n;
    }

    /**
     * Refill the bytes buffer. The amount of data read is always the
     * bufferSize so as to optimize i/o.
     *
     * @param      off start offset in buffer at which bytes are returned
     * @param      block number of bytes to be loaded into the buffer,
     *             reduced to the buffer size if greater
     * @return     number of bytes read
     * @exception  IOException 
     */

    private int load(int off, int block) throws IOException {
        BytesRow bytebuf = this.byteInBuf;
        bytesBufferEnsure(bytebuf);
        if (block > this.bufferSize) block = this.bufferSize;
        int n = get(bytebuf.buffer,off,block);
        bytebuf.length = off + ((n < 0) ? 0 : n);
        bytebuf.offset = off;
        return n;
    }

    /**
     * Extend the bytes buffer and displace in it the available part of
     * the current block. If the space is lower than zero or lower than
     * the buffer size and not in autoflush mode, it is set equal to it.
     *
     * @param      siz space which must be made available
     * @return     number of bytes read
     * @exception  IOException 
     */

    private int appendLoad(int siz) throws IOException {
        BytesRow bytebuf = this.byteInBuf;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("append: " + this.offset);
        }
        if ((siz < 0) || ((AUTOFLUSH & this.mode) == 0)){
            if (siz < this.bufferSize) siz = this.bufferSize;
        }
        if (this.offset == 0){
            int len = bytebuf.offset;                    // already collected
            byte[] bb = bytebuf.buffer;
            if (len + siz < 0) siz = Integer.MAX_VALUE - len;
            bytesBufferExtend(bytebuf,len + siz,false);
            if (bb != null){
                System.arraycopy(bb,0,bytebuf.buffer,0,len);
            }
        } else {                                         // shift
            int len = bytebuf.offset - this.offset;      // already collected
            byte[] bb = bytebuf.buffer;
            if (len + siz < 0) siz = Integer.MAX_VALUE - len;
            bytesBufferExtend(bytebuf,len + siz,false);  // plus requested
            System.arraycopy(bb,this.offset,
                bytebuf.buffer,0,len);
            bytebuf.offset = len;
            bytebuf.length = len;
            this.offset = 0;
            if ((FL_C & this.trc) != 0){
                Trc.out.println("append: shifted " +
                    bytebuf.offset + " " + bytebuf.length);
            }
        }
        int off = bytebuf.offset;
        int n = get(bytebuf.buffer,off,siz);
        bytebuf.length = off + ((n < 0) ? 0 : n);
        bytebuf.offset = off;
        return n;
    }

    /**
     * Refill the characters buffer.
     *
     * @param      off start offset in buffer at which characters are returned
     * @return     number of characters read
     * @exception  IOException 
     */

    /* Note that the part which is refilled is the unused one, which can
     * be smaller than the block size if off > 0, and that the load is
     * reduced to the block size when it is larger (which can occur when
     * the buffer has been enlarged because of a previous read with a
     * character row parameter).
     */

    private int loadChars(int off) throws IOException {
        CharsRow charbuf = this.charInBuf;
        int n = 0;
        if (charbuf.buffer == null){
            charsBufferExtend(charbuf,this.bufferSize,false);
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("loadChars: " + this.oldLength +
                " " + this.bufferSize + " " + this.index + " " + off);
        }
        int piece = charbuf.buffer.length - off;
        if (piece > this.bufferSize) piece = this.bufferSize;
        n = getChars(charbuf.buffer,off,piece);
        charbuf.length = off + ((n < 0) ? 0 : n);
        charbuf.offset = off;
        if ((FL_C & this.trc) != 0){
            Trc.out.print("loadChars: " + n + " " + this.index + " "
                + off + " data: ");
            for (int i = 0; i < charbuf.length; i++){
                Trc.out.print(" 0x" +
                    Integer.toHexString(charbuf.buffer[i] & 0xffff));
            }
            Trc.out.println();
        }
        return n;
    }

    /**
     * Extend the characters buffer and displace in it the available
     * part of the current block. If the space is lower than the
     * buffer size, it is set equal to it.
     *
     * @param      siz space which must be made available
     * @return     number of characters read
     * @exception  IOException 
     */

    private int appendLoadChars(int siz) throws IOException {
        CharsRow charbuf = this.charInBuf;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("append: " + this.offset + " " + siz);
        }
        if (siz < this.bufferSize) siz = this.bufferSize;
        if (this.offset == 0){
            int len = charbuf.offset;                  // already collected
            char[] cb = charbuf.buffer;
            if (len + siz < 0) siz = Integer.MAX_VALUE - len;
            charsBufferExtend(charbuf,len + siz,false);
            if (cb != null){
                System.arraycopy(cb,0,charbuf.buffer,0,len);
            }
        } else {                                       // shift
            int len = charbuf.offset - this.offset;    // already collected
            char[] cb = charbuf.buffer;
            if (len + siz < 0) siz = Integer.MAX_VALUE - len;
            charsBufferExtend(charbuf,len + siz,false);   // plus requested
            System.arraycopy(cb,this.offset,
                charbuf.buffer,0,len);
            charbuf.offset = len;
            charbuf.length = len;
            this.offset = 0;
            if ((FL_C & this.trc) != 0){
                Trc.out.println("append: shifted " +
                    charbuf.offset + " " + charbuf.length);
            }
        }
        int off = charbuf.offset;
        int n = getChars(charbuf.buffer,off,siz);
        charbuf.length = off + ((n < 0) ? 0 : n);
        charbuf.offset = off;
        return n;
    }

    /**
     * Read characters from the reader stream.
     *
     * @param      cb return buffer
     * @param      off start offset in buffer at which chareacters are returned
     * @return     number of characters to read
     * @return     number of characters read
     * @exception  IOException 
     */

    private int getChars(char[] cb, int off, int len) throws IOException {
        int n;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("getChars: " + len);
        }
        boolean eof = false;
        int end = cb.length;                         // reduce to buffer
        if (off > end) off = end;                    // .. area
        if ((off + len < 0) || (off + len > end))
            len = end - off;
        get: if (this.inAdapt != null){
            if ((FL_C & this.trc) != 0){
                Trc.out.println("getChars readerStream");
            }
            n = this.readerStream.read(cb,off,len);
            if (n < 0) eof = true;
        } else {
            if ((PENDING_EOF & this.status) != 0){   // eof pending
                n = -1;
                break get;
            }
            n = 0;
            int start = off;
            do {
                int l = len - n;
                if (l > MAX_TRANSFER) l = MAX_TRANSFER;
                this.nrIoDone++;
                int r = this.readerStream.read(cb,start,l);
                if (r > 0) this.status |= NONEMPTY;
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("getChars: r: " + r + " start " + start + " l " + l);
                }
                if (r < 0){
                    if (n == 0) n = -1;        // no data read: eof
                    eof = true;
                    break;
                }
                start += r;
                n += r;
                if (r < l) break;
                if (n >= len) break;
                if (Thread.currentThread().isInterrupted()){
                    throw new InterruptedIOException();
                }
            } while (this.readerStream.ready());
            if (n > 0) this.index += n;        // for error reporting
            if ((ENDLESS & this.mode) == 0){
                if (eof) this.status |= PENDING_EOF; // end of file
            }
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("getChars return " + n);
            if (n >= 0){
                 Trc.out.print("data read: ");
                 Trc.literalize(cb,off,n);
                 Trc.out.println();
            }
        }
        return n;
    }

    /*
     * Read is blocking, i.e. it returns control only when at least some
     * data have been read (it is not blocking when a read of 0 data is
     * executed). In other words, it delivers what data are available, and
     * blocks if there are none.
     * Furthermore, read() may return less data than the amount which was
     * requested. I.e. the semantics is to get the data which are available,
     * but no more than the amount specified.
     * To implement this with buffering, first the data are taken from the
     * buffer, or they are read if the buffer is empty.
     * If less data than requested are got, an attempt is made to get further
     * data if they have become available in the meantime. Note that the latter
     * is not blocking because otherwise read() would return exactly the
     * amount requested (unless eof is reached), which is not the specified
     * bahaviour.
     * Read is always blocking, otherwise is is not possible to open a file
     * in read, and also in write and read what it is written.
     * Moreover, if it were not blocking there would be no meand to make a
     * program wait for input, unless by busy waiting.
     *
     * This needs not be used in readln() because in it data are read until
     * an end-of-line or eof is read. Thus, readln is blocking until the
     * requested data are obtained, which is not the case with read().
     *
     * When reading a sequence of files, and there are not enough data on the
     * current file, the data present in the next file are not concatenated,
     * but are delivered at the next operation. Empty files are skipped.
     * This allows callers to interpret such a file break as they like.
     * After a read() or readln() operation, DATA_BREAK is set if the
     * data delivered are the first of a file.
     * Note that this is the only possible condition to return since it
     * is possible to know that data are at the beginning of a file, but not
     * that they are at the end unless a read operation is done to detect
     * that there are no more data after them.
     *
     * When reading a sequence of files, and on the last file there are not
     * enough data, the file is closed and eof set only if no data at all
     * have been read. A subsequent read finds no file open and the iterator
     * telling that the sequence is empty. This means that the eof which was
     * pending from the last operation becomes effective then without performing
     * any read() to detect it.
     *
     * Read of sequential files is done by calling the underlying read, which
     * either delivers (part of) the data requested, or it tells that the eof
     * has been reached. The underlying read of 0 data never return an eof.
     * There is a need to read at least one datum to detect the eof.
     * This is not a problem because reading of small amounts of data is
     * always buffered. This allows to return eof when reading at most zero
     * data and the index is at the end of the file.
     *
     * For sequential devices and files, the length is not known in advance,
     * and therefore, there is a need to make a sequence of reads of amounts
     * of data greater than zero to arrive at the eof.
     * When a file before reading is opened in append, its length becomes
     * known except when it is a sequential device. However, that length in
     * such a case is correct because it represents the amount of data which
     * are present before the open in append started. This would not cover
     * the case in which some data are pending in internal buffers and not
     * yet flushed so as to make them rekoned by File.length().
     * That occurs, e.g. in Unix when a program is run and, before it comes
     * to make an io operation on stdin, some characters are introduced.
     * This could be covered by opening the file in read before opening in
     * append, testing if it is ready() and then read and buffer the data before
     * opening it in append. This seems, however, a rather uncommon case which
     * can be accepted as a limitation since it is also rather strange to open
     * a sequential device in append.
     * Note that the case could only occur with sequential devices and not
     * with disk files for which the length is known.
     * For sequential devices, the length is 0, which means that the index
     * when the file is opened is already at the end of the file, and the
     * first read should return an eof.
     * Even if there were a way to detect that a file were a sequential device,
     * open in append would not be rejected because the possibility to open
     * in append any file may not be renounced to cater for a special case
     * that in practice occurs very seldom.
     * The restriction is that interlocked open works only when there is no
     * concurrent io undergoing.
     *
     * Reading of lines is often used by applications which then parse the
     * lines. Parsing is faster if the string to be parsed terminates with
     * a known, unfrequent character such as NUL. Moreover, to speed up
     * applications, readln() can be told to deliver a reference to the
     * buffer where the line is kept. Since lines are normally terminated by
     * at least a line terminator character, there is almost always such
     * a buffer element available, except when the line is the last and
     * it is not terminated by a line terminator. In such a case the
     * buffer is extended if there is no element available after the last.
     *
     * InputStreamBuffer is buffered. Alas, there is nothing that can be
     * done because it keeps hidden in it the encoder, which is not public.
     *
     * In JRE for HP there is a bug that prevents reading from /dev/tty: read
     * never returns. This can not be mended redirecting it to standard input
     * because there is no guarantee that it is the console.
     *
     * Byte reads take bytes from the buffer in sequential mode, otherwise
     * from the file. Since the byte buffer can be accessed directly by IoStream
     * read(), these reads are never done through the adapter: they are done
     * directly.
     *
     * Returning an error when a read operation makes the index become negative
     * is difficult when buffering is done. When refilling the buffer, no errors
     * can be generated because a partial refill could suffice to deliver the
     * requested data. When the data may not be delivered entirely, there would
     * then be a need to tell that it occurred because the buffer was not
     * refilled entirely due to an index overflow. This seems too difficult for
     * a case which would occur very rarely.
     */

    /**
     * Read a sequence of characters. It delivers what data are available,
     * but no more than the amount specified, and it blocks if there are none.
     * It returns an eof if the file index is at the end of the file before
     * executing the read. This holds also when the maximum amount of data
     * to read is zero. For a more formal definition of the eof condition,
     * see readln(). Note that when the eof is encountered, the number
     * of data returned is zero.
     * When an attempt is made to read in random access at a file position
     * which is greater than 2**63-1, the operation is reduced so as not to
     * exceed that limit.
     *
     * @param      t1 return array of characters
     * @param      s1 offset at which the data are returned
     * @param      l1 maximum number of data to be read
     * @return     number of characters read
     */

    public int read(char[] t1, int s1, int l1){
        if (this.mutex != null){
            synchronized (this.mutex) {
                return read(t1,null,t1.length,s1,l1,false);
            }
        } else {
            return read(t1,null,t1.length,s1,l1,false);
        }
    }

    /**
     * Read a sequence of characters. It delivers a reference to an array
     * holding the data.
     * This method must not be used when the object is accessed concurrently
     * by several threads.
     *
     * @see        #read(char[],int,int)
     * @param      r return row to the array
     * @param      l1 maximum number of data to be read
     * @return     number of data read
     */

    public int read(CharsRow r, int l1){
        int n = read(null,null,l1,0,l1,false);
        r.buffer = this.charInBuf.buffer;
        r.offset = this.offset;
        r.length = n;
        return n;
    }

    /**
     * Read a sequence of bytes.
     *
     * @see        #read(char[],int,int)
     */

    public int read(byte[] t1, int s1, int l1){
        if (this.mutex != null){
            synchronized (this.mutex) {
                return read(null,t1,t1.length,s1,l1,true);
            }
        } else {
            return read(null,t1,t1.length,s1,l1,true);
        }
    }

    /**
     * Read a sequence of bytes. It delivers a reference to an array
     * holding the data. See read();
     * This method must not be used when the object is accessed concurrently
     * by several threads.
     *
     * @param      r return row to the array
     * @param      l1 maximum number of data to be read
     * @return     number of data read
     */

    public int read(BytesRow r, int l1){
        int n = read(null,null,l1,0,l1,true);
        r.buffer = this.byteInBuf.buffer;
        r.offset = this.offset;
        r.length = n;
        return n;
    }

    /**
     * Read a sequence of characters or bytes. If an iterator is
     * present, it steps over the files it delivers.
     *
     * @param      t1 return array of characters
     * @param      bt1 return array of bytes
     * @param      e1 length of the array
     * @param      off offset at which the data are returned
     * @param      l1 maximum number of data to be read
     * @param      bytes <code>true</code> to deliver bytes
     * @return     actual number of data read
     */

    /* When reading characters, there is always a need to use an internal
     * buffer to decode them, and thus no direct read without deblocking
     * is possible.
     * When reading bytes and delivering a row to an internal buffer
     * and reading a sequence of files, when a file is ended, the following
     * one is opened, and the operation terminated delivering the buffer
     * as it is (possibly containing less data than requested). This is
     * so in order to avoid deblocking, which would require to read the
     * data of the following file no longer in blocks, but in what amount
     * is available in the buffer. This introduces complexity and decreases
     * performance.
     * When reading bytes in a user buffer that is also done so as to
     * allow callers which make requests to read amounts of data which
     * are multiple of blocks to result in lower-level read operation of
     * blocks. That would not be the case when making direct read operation
     * since after the end of a file, a read with what remains to complete
     * the requested data would be done, thus making all the following
     * ones become odd.
     * In order to allow callers to interpret the file end as they like
     * (e.g. like readln() which interprets is as an implicit line break),
     * the data are not concatenated across files.
     *
     * When reading a file, and expecially a sequence of files, there could
     * be a need to assign to the end of a file the meaning of line break
     * when no newline is present at the end of it and the file is not empty.
     * To do that, the ENDING_NL mode is provided.
     * A NONEMPTY status flag is kept which tells if some data have been
     * got from a file.  It allows to refrain from delivering a newline
     * when a file is empty.
     * When it detects an eof it is because it could not deliver the requested,
     * characters (or there are none and none are requested), and in such
     * a case there is space in the user or IoStream buffer, to store a newline.
     */

    private int read(char[] t1, byte[] bt1, int e1, int s1, int l1,
        boolean bytes){
        if (s1 < 0) s1 = 0;
        if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;

        if ((FL_B & this.trc) != 0){
            Trc.out.println("read: " + trcmode() + " " + l1 +
                (bytes ? " bytes" : " chars") + " " + this.encoding);
        }
        excInit();
        int len = 0;
        int off = s1;
        int toRead = l1;
        this.nrRead = 0;
        this.status &= ~DATA_BREAK;
        if (!bytes){               // special encoding
            if (((ISO8859_1 & this.status) != 0) ||
                ((UCS2 & this.status) != 0)){
                if (this.charInBuf != null){
                    this.charInBuf.offset = 0;
                    this.charInBuf.length = 0;
                }
            }
        }
        doit: try {
            if ((IS_OPEN & this.status) == 0){            // file not open
                if (this.iter == null){
                    registerError(IOError.ERR_NOTOPEN,null);
                    break doit;
                } else if ((AT_EOF & this.status) != 0){  // return again eof
                    break doit;
                }
            }
            if ((READ & this.mode) == 0){
                registerError(IOError.ERR_INVOP,null);
                break doit;
            }
            this.offset = (bytes) ?
                this.byteInBuf.offset : this.charInBuf.offset;
            if ((bt1 == null) && (t1 == null)) off = this.offset;
            step: do {
                if ((IS_OPEN & this.status) == 0){        // file not open
                    if (this.iter.hasNext()){
                        int iod = this.nrIoDone;
                        Object fs = this.iter.next();
                        String fn;
                        String enc = this.openEncoding;
                        if (fs.getClass().isArray()){
                            fn = ((String[])fs)[0];
                            enc = ((String[])fs)[1];
                        } else {
                            fn = (String)fs;
                        }
                        openStream(fn,enc,this.mode);
                        this.offset = 0;                  // open resets buffers
                        this.nrIoDone = iod;
                        if (this.res != 0) break doit;
                        this.status |= DATA_BREAK;
                    } else {
                        if ((FL_C & this.trc) != 0){
                            Trc.out.println("read: end sequence");
                        }
                        this.status |= AT_EOF;
                        break doit;
                    }
                }
                if (bytes){                               // N.B. done here after
                    if ((BYTES & this.mode) == 0){        // .. the end iter check
                        registerError(IOError.ERR_INVOP,null);
                        break doit;
                    }
                }
                if (!bytes){                              // chars in byte stream
                    if ((this.readerStream == null) &&
                        (((ISO8859_1 | UCS2) & this.status) == 0)){
                        createInAdapter();
                    }
                }
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("read: " +
                        (bytes ? this.byteInBuf.offset :
                        this.charInBuf.offset) +
                        " " +
                        (bytes ? this.byteInBuf.length :
                        this.charInBuf.length) +
                        " " + l1);
                }
                int piece =
                    readData(t1,bt1,off,toRead,bytes);        // get data
                if ((AT_EOF & this.status) != 0){             // eof found
                    if ((ENDING_NL & this.mode) != 0){        // add a newline
                        if ((NL_PRESENT & this.status) == 0){ // .. if missing
                            this.status &= ~AT_EOF;           // not ended now
                            if (l1 == 0) break doit;          // empty request
                            if ((NONEMPTY & this.status) != 0){
                                int last = off + piece;
                                if (!bytes){
                                    char[] buf = t1;
                                    if (t1 == null){
                                        buf = this.charInBuf.buffer;
                                        last = this.offset + len;
                                    }
                                    buf[last] = '\n';
                                } else {
                                    byte[] buf = bt1;
                                    if (bt1 == null){
                                        buf = this.byteInBuf.buffer;
                                        last = this.offset + len;
                                    }
                                    buf[last] = (byte)'\n';
                                }
                                len++;
                                this.nrRead++;
                                this.status |= NL_PRESENT;     // present now
                                if ((FL_C & this.trc) != 0){
                                    Trc.out.println("read add newline " +
                                        last);
                                }
                            }
                        }
                    }
                    if (this.iter != null){
                        int curmode = this.mode;
                        forceClose(false);
                        this.mode |= curmode;             // restore it
                        if (len > 0){                     // a true eof
                            this.status |= AT_EOF;        // do not cross files 
                            break doit;
                        }
                        continue step;
                    }
                    break doit;
                }
                if (piece == 0) break doit;               // no data read
                len += piece;
                off += piece;
                toRead -= piece;

                if (len > 0){                             // determine if
                    if ((ENDING_NL & this.mode) != 0){    // .. ended in
                        this.status &= ~NL_PRESENT;       // .. newline
                        int last = off - 1;
                        if (!bytes){
                            char[] buf = t1;
                            if (t1 == null){
                                buf = this.charInBuf.buffer;
                                last = this.offset + len - 1;
                            }
                            if ((buf[last] == '\r') || (buf[last] == '\n')){
                                this.status |= NL_PRESENT;
                            }
                        } else {
                            byte[] buf = bt1;
                            if (bt1 == null){
                                buf = this.byteInBuf.buffer;
                                last = this.offset + len - 1;
                            }
                            if ((buf[last] == '\r') || (buf[last] == '\n')){
                                this.status |= NL_PRESENT;
                            }
                        }
                        if ((FL_C & this.trc) != 0){
                            Trc.out.println("read ending newline " +
                                ((NL_PRESENT & this.status) != 0));
                        }
                    }
                }
                if (toRead == 0) break step;              // enough
            } while (this.iter != null);
            if ((RANDOM & this.mode) != 0){
                if (!bytes && (this.decoder != null)){    // invalidate buffer
                    completeRead();                       // not for iso and ucs:
                }                                         // no extra bytes read
            } else {
                if ((this.decoder != null) &&
                    (this.decoder.shiftState != 0)){
                    int n = loadDecode(-2);               // locate lock-shifts
                }
            }
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (IOError exc){
        } finally {
            boolean eof = (AT_EOF & this.status) != 0;
            this.status &= ~AT_EOF;
            if ((ENDLESS & this.mode) == 0){
                if (len == 0){
                    if (eof){
                        if (this.iter == null){
                            this.status |= AT_EOF;
                        } else if (!this.iter.hasNext()){
                            this.status |= AT_EOF;
                        }
                    }
                }
            }
            if ((FL_C & this.trc) != 0){
                Trc.out.print("read done: ");
                if (!bytes){
                    if (t1 != null){
                        Trc.literalize(t1,s1,len);
                    } else if ((this.charInBuf != null) &&
                        (this.charInBuf.buffer != null)){
                        Trc.literalize(this.charInBuf.buffer,
                            this.offset,this.nrRead);
                    }
                } else {
                    if (bt1 != null){
                        Trc.out.print(byteToString(bt1,s1,len));
                    } else if ((this.byteInBuf != null) &&
                        (this.byteInBuf.buffer != null)){
                        Trc.out.print(byteToString(this.byteInBuf.buffer,
                            this.offset,this.nrRead));
                    }
                }
                Trc.out.println(" " + len +
                    " eof: " + ((AT_EOF & this.status) != 0));
            }
            if (((EOF_EXCEPTION & this.mode) != 0) &&
                ((AT_EOF & this.status) != 0)){
                registerError(IOError.ENDOFFILE,null);
            }
            excTerm();
        }
        return len;
    }

    /**
     * Read the data available in the file.
     *
     * @param      t1 return array of characters
     * @param      bt1 return array of bytes
     * @param      off offset at which the data are returned
     * @param      len maximum number of data to be read
     * @param      bytes <code>true</code> to deliver bytes
     * @return     actual number of data read
     * @exception  IOException
     */

    private int readData(char[] t1, byte[] bt1, int off, int len,
        boolean bytes) throws IOException {
        int piece = 0;
        int toRead = len;
        int start = off;
        int n = 0;
        boolean eof = false;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("readData requested: " + len + " data at: " +
                off);
        }
        done: {
            do {
                cat: {
                    special: if (!bytes){               // special encoding
                        if ((ISO8859_1 & this.status) != 0){
                            n = isoRead(t1,off,toRead);
                        } else if ((UCS2 & this.status) != 0){
                            n = ucs2Read(t1,off,toRead);
                        } else {
                            break special;
                        }
                        if (n < 0){
                            eof = true;
                            break done;
                        } else {
                            piece = n;
                        }
                        break cat;
                    } // special
                    if (bytes){
                        piece = this.byteInBuf.length - this.byteInBuf.offset;
                    } else {
                        piece = this.charInBuf.length - this.charInBuf.offset;
                    }
                    if ((FL_C & this.trc) != 0){
                        Trc.out.println("in buffer: " + piece +
                            " toRead: " + toRead);
                    }
                    if (piece <= 0){                       // buffer empty
                        boolean direct =
                            (toRead > 0) &&                // do not read 0 data
                            (toRead >= this.bufferSize);   // large transfer
                        if (((RANDOM & this.mode) != 0) &&
                            bytes){                        // direct for
                            direct = true;                 // .. random bytes
                        }
                        if (!bytes){                       // mixed mode
                            if (this.decoder != null){
                                direct = true;
                            }
                        }
                        if (bytes && (AUTOFLUSH & this.mode) != 0){
                            direct = true;
                        }
                        if ((bt1 == null) && (t1 == null)){
                            direct = false;
                        }
                        get: if (direct){                  // direct io
                            piece = toRead;
                            if ((FL_C & this.trc) != 0){
                                Trc.out.printf("direct read %s\n",piece);
                            }
                            if (bytes){
                                n = get(bt1,off,piece);
                            } else {
                                if (this.decoder != null){
                                    n = loadDecode(piece);
                                    if (n < 0) break get;
                                    if (n == 0) break done;
                                }
                                n = getChars(t1,off,piece);
                            }
                            if (n >= 0){
                                piece = n;
                                break cat;
                            }
                        } else {
                            if ((FL_C & this.trc) != 0){
                                Trc.out.println("load " + bytes);
                            }
                            if (bytes){
                                if (bt1 != null){
                                    n = load(0);
                                } else {
                                    n = appendLoad(toRead);
                                }
                            } else {
                                if (t1 != null){
                                    n = loadChars(0);
                                } else {
                                    if (this.decoder != null){
                                        n = loadDecode(toRead);
                                        if (n < 0) break get;
                                        if (n == 0) break done;
                                    }
                                    n = appendLoadChars(toRead);
                                }
                            }
                        }
                        if (n < 0){
                            if ((FL_C & this.trc) != 0){
                               Trc.out.println("no more data");
                            }
                            eof = true;
                            break done;
                        } else {
                            piece = n;
                        }
                    }
                    if (toRead < piece){   // take from buffer
                        piece = toRead;
                    }
                    if (bytes){
                        if (bt1 != null){
                            System.arraycopy(this.byteInBuf.buffer,
                                this.byteInBuf.offset,bt1,off,piece);
                            if ((FL_C & this.trc) != 0){
                                Trc.out.println("taken from buffer: " +
                                   byteToString(bt1,off,piece));
                            }
                        }
                        this.byteInBuf.offset += piece;
                    } else {
                        if (t1 != null){
                            System.arraycopy(this.charInBuf.buffer,
                                this.charInBuf.offset,t1,off,piece);
                            if ((FL_C & this.trc) != 0){
                                Trc.out.println("taken from buffer: " +
                                    String.valueOf(t1,off,piece));
                            }
                        }
                        this.charInBuf.offset += piece;
                    }
                } // cat
                off += piece;
                toRead -= piece;
                if (toRead == 0) break done;
                if (bytes ||
                    (((ISO8859_1 | UCS2) & this.status) != 0)){
                    if (available() <= 0) break done;
                } else {
                    if ((RANDOM & this.mode) == 0){        // random always ready
                        if (this.decoder != null)
                            this.inAdapt.ready = true;
                        if (!this.readerStream.ready()) break done;
                        if (this.decoder != null)
                            this.inAdapt.ready = false;
                   }
                }
            } while (true);
        }//done
        int dataread = off - start;
        if (dataread == 0){                     // no (real) data read
            if ((this.decoder != null) &&
                this.decoder.incomplete){
                throw new CharConversionException();
            } else if ((UCS2 & this.status) != 0){
                if ((this.byteInBuf.length - this.byteInBuf.offset == 1) &&
                    (len > 0)){
                    throw new CharConversionException();
                }
            }
            if ((ENDLESS & this.mode) == 0){
                if (eof) this.status |= AT_EOF; // then consider eof
            }
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("readData returns: " +
                dataread + " data " + trcmode() + " " + this.offset);
        }
        this.nrRead = dataread;
        return dataread;
    }

    /**
     * Read characters for a ISO8859_1 encoding.
     *
     * @param      t1 string in which the characters are returned
     * @param      off start offset in return buffer
     * @param      toRead number of characters to be read
     * @return     number of characters read
     * @exception  IOException 
     */

    private int isoRead(char[] t1, int off, int toRead)
        throws IOException {
        BytesRow bytebuf = this.byteInBuf;
        if (t1 == null){
            if (this.nrRead + toRead < 0){
                toRead = Integer.MAX_VALUE - this.nrRead;
            }
            charsBufferExtend(this.charInBuf,this.nrRead + toRead,true);
            t1 = this.charInBuf.buffer;
        }
        int n = 0;
        int rem = bytebuf.length - bytebuf.offset;
        if (rem == 0){                             // refill buffer
            bytebuf.offset = rem;
            bytebuf.length = bytebuf.offset;
            if ((RANDOM & this.mode) != 0){        // random
                int l = toRead;                    // load only the
                n = load(rem,l);                   // .. needed bytes
            } else {
                n = load(rem);
            }
            bytebuf.offset = 0;
            if (n < 0) return n;
        }
        int chars = bytebuf.length - bytebuf.offset;
        int max = (chars > toRead) ? toRead : chars;
        max += bytebuf.offset;
        char c;
        int j = off;
        int i;
        for (i = bytebuf.offset; i < max; i++){
            c = (char)(bytebuf.buffer[i] & 0xff);
            t1[j++] = c;
        }
        n = j - off;
        bytebuf.offset = i;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("isoRead: " +
                bytebuf.offset + " " + bytebuf.length + " " + n);
        }
        return n;
    }

    /**
     * Read characters for a UCS2 encoding.
     *
     * @param      t1 string in which the characters are returned
     * @param      off start offset in return buffer
     * @param      toRead number of characters to be read
     * @return     number of characters read
     * @exception  IOException 
     */

    private int ucs2Read(char[] t1, int off, int toRead)
        throws IOException {
        BytesRow bytebuf = this.byteInBuf;
        if (t1 == null){
            if (this.nrRead + toRead < 0){
                toRead = Integer.MAX_VALUE - this.nrRead;
            }
            charsBufferExtend(this.charInBuf,this.nrRead + toRead,true);
            t1 = this.charInBuf.buffer;
        }
        int n = 0;
        int rem = bytebuf.length - bytebuf.offset;
        if (rem <= 1){                             // refill buffer
            if (rem == 1){                         // shift on top
                bytebuf.buffer[0] =
                    bytebuf.buffer[bytebuf.offset];
            }
            bytebuf.offset = rem;
            bytebuf.length = bytebuf.offset;
            if ((RANDOM & this.mode) != 0){        // random
                int l = toRead;                    // load only the
                n = load(rem,l << 1);              // .. needed bytes
            } else {
                n = load(rem);
            }
            bytebuf.offset = 0;
            if (n < 0) return n;
        }
        int chars = (bytebuf.length - bytebuf.offset) >> 1;
        int max = (chars > toRead) ? toRead : chars;
        max = (max << 1) + bytebuf.offset;
        char c;
        int j = off;
        int i;
        for (i = bytebuf.offset; i < max; i++){
            c = (char)((bytebuf.buffer[i++] << 8) |
                (bytebuf.buffer[i] & 0xff));
            t1[j++] = c;
        }
        n = j - off;
        bytebuf.offset = i;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("ucs2Read: " +
                bytebuf.offset + " " + bytebuf.length + " " + n);
        }
        return n;
    }

    /**
     * Complete a random read of characters. If the decoder is in shifted
     * status, all lock-shift sequences are read up to the first which
     * brings it into the unshifted status. It clears the bytes buffer.
     * It seeks the file at the end of the bytes read.
     *
     * @exception  IOException
     */

    private void completeRead() throws IOException {
        long newindex = this.index;
        if ((this.decoder != null) &&
            (this.decoder.shiftState != 0)){
             if ((FL_D & this.trc) != 0){
                 Trc.out.println("lock-shift completion");
             }
             int n = loadDecode(-2);          // locate lock-shifts
             if ((FL_D & this.trc) != 0){
                 Trc.out.println("lock-shift completion-end");
             }
             newindex += this.decoder.byteIndex;
        } else {
             newindex += this.byteInBuf.offset;
        }
        this.byteInBuf.length = 0;            // invalidate buffer
        this.byteInBuf.offset = 0;
        if (newindex >= 0){                   // otherwise leave as it is
            this.randStream.seek(newindex);
        }
        if ((FL_C & this.trc) != 0){
           Trc.out.println("seek: " + newindex);
        }
    }

    /**
     * Convert a slice of an array of bytes into a String in which the
     * elements are represented as hexadecimal numbers.
     *
     * @param      data array of bytes
     * @param      off start offset of the slice
     * @param      len slice length
     * @return     string
     */

    private static String byteToString(byte[] data, int off, int len){
        if ((off < 0) || (len < 0) || (off + len < 0) ||
           (off + len > data.length)) return "";
        Str s = new Str();
        for (int i = off; i < off+len; i++){
            s.append(" 0x" + Integer.toHexString(data[i] & 0xff));
        }
        return s.toString();
    }

    /**
     * Convert a slice of an array of chars into a String in which the
     * elements are represented as hexadecimal numbers.
     *
     * @param      data array of chars
     * @param      off start offset of the slice
     * @param      len slice length
     * @return     string
     */

    private static String byteToString(char[] data, int off, int len){
        if ((off < 0) || (len < 0) || (off + len < 0) ||
           (off + len > data.length)) return "";
        Str s = new Str();
        for (int i = off; i < off+len; i++){
            s.append(" 0x" + Integer.toHexString(data[i] & 0xff));
        }
        return s.toString();
    }

    /**
     * Convert a slice of a String into a String in which the elements are
     * represented as hexadecimal numbers.
     *
     * @param      data slice
     * @param      off start offset of the slice
     * @param      len slice length
     * @return     string
     */

    private static String byteToString(String data, int off, int len){
        if ((off < 0) || (len < 0) || (off + len < 0) ||
           (off + len > data.length())) return "";
        Str s = new Str();
        for (int i = off; i < off+len; i++){
            s.append(" 0x" + Integer.toHexString(data.charAt(i) & 0xffff));
        }
        return s.toString();
    }

    /**
     * Skip the specified amount of bytes in the file. If <code>n</code>
     * is lower or equal than zero, no skip is done.
     *
     * @param      n number of data to skip
     * @return     number of data actually skipped
     */

    /* To skip characters, there is a need to read them because it is not
     * possible to know the number of bytes to be skipped. For bytes, the
     * ones in the buffer could be skipped, and then the underlying skip()
     * could be called. When a decoder is present, it could be used to skip
     * characters. However, since skip() is not much used, there is no need
     * to optimize it.
     * It is implemented by using read(), with the row and with chunks whose
     * size does not make the buffers be reallocated. For random it could
     * be implemented as seek for fixed length encodings and otherwise as
     * read(). However, also for random there is no need to optimize it.
     * To skip characters, skipChars() is provided because the caller may
     * not know the number of bytes that correspond to the characters.
     * Skip in multifile is supported too.
     */

    public long skip(long n){
        if (this.mutex != null){
            synchronized (this.mutex) {
                return skipStream(n);
            }
        } else {
            return skipStream(n);
        }
    }

    /**
     * Skip the specified amount of bytes in the file. For internal use.
     *
     * @param      n number of data to skip
     * @return     number of data actually skipped
     */

    private long skipStream(long n){
        excInit();
        if ((FL_B & this.trc) != 0){
            Trc.out.println("skip: " + trcmode() + " " + n);
        }
        long rem = n;
        doit: try {
            while (true){
                int len = this.bufferSize;
                if (rem < len) len = (int)rem;
                if (this.byteInBuf.buffer != null){
                    int data = this.byteInBuf.length - this.byteInBuf.offset;
                    if ((data > 0) && (data < len)) len = data;
                }
                int s = read(null,null,len,0,len,true);
                if (this.res != 0) break;
                if ((AT_EOF & this.status) != 0) break;
                rem -= s;
                if (rem == 0) break;
                if (!ready(true)) break;
                if (this.res != 0) break;
            }
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (IOError exc){
        } finally {
            excTerm();
        }
        return n - rem;
    }

    /**
     * Skip the specified amount of characters in the file. If <code>n</code>
     * is lower or equal than zero, no skip is done.
     *
     * @param      n number of data to skip
     * @return     number of data actually skipped
     */

    public long skipChars(long n){
        if (this.mutex != null){
            synchronized (this.mutex) {
                return skipCharsStream(n);
            }
        } else {
            return skipCharsStream(n);
        }
    }

    /**
     * Skip the specified amount of characters in the file. For internal use.
     *
     * @param      n number of data to skip
     * @return     number of data actually skipped
     */

    private long skipCharsStream(long n){
        excInit();
        if ((FL_B & this.trc) != 0){
            Trc.out.println("skip: " + trcmode());
        }
        long rem = n;
        doit: try {
            while (true){
                int len = this.bufferSize;
                if (rem < len) len = (int)rem;
                int data = 0;
                if (((ISO8859_1 | UCS2) & this.status) != 0){
                    if (this.byteInBuf.buffer != null){
                        data = this.byteInBuf.length - this.byteInBuf.offset;
                    }
                } else {
                    if (this.charInBuf.buffer != null){
                        data = this.charInBuf.length - this.charInBuf.offset;
                    }
                }
                if ((data > 0) && (data < len)) len = data;
                int s = read(null,null,len,0,len,false);
                if (this.res != 0) break;
                if ((AT_EOF & this.status) != 0) break;
                rem -= s;
                if (rem == 0) break;
                if (!ready(false)) break;
                if (this.res != 0) break;
            }
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (IOError exc){
        } finally {
            excTerm();
        }
        return n - rem;
    }


    /**
     * Set the current index in the file. The file must be open in
     * random access mode. If the index is set beyond the last position
     * at which a datum exists, the file is not extended.
     *
     * @param      ind index
     */

    public void seek(long ind){
        if (this.mutex != null){
            synchronized (this.mutex) {
                seekStream(ind);
            }
        } else {
            seekStream(ind);
        }
    }

    /**
     * Set the current index in the file. For internal use.
     *
     * @param      ind index
     */

    private void seekStream(long ind){
        excInit();
        if ((FL_B & this.trc) != 0){
            Trc.out.println("seek: " + trcmode());
        }
        doit: try {
            if ((IS_OPEN & this.status) == 0){       // file not open
                registerError(IOError.ERR_NOTOPEN,null);
                break doit;
            }
            if ((RANDOM & this.mode) == 0){          // not in random mode
                registerError(IOError.ERR_INVOP,null);
                break doit;
            }
            this.randStream.seek(ind);
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } finally {
            excTerm();
        }
    }

    /**
     * Set the length of the file to the index. The file must be open in
     * random access mode.
     */

    public void setLength(){
        setLength(index());
    }

    /**
     * Set the length of the file. The file must be open in random access
     * mode. If the index is set beyond the last position at which a datum
     * exists, the file is extended.
     *
     * @param      len length
     */

    public void setLength(long len){
        if (this.mutex != null){
            synchronized (this.mutex) {
                setLengthStream(len);
            }
        } else {
            setLengthStream(len);
        }
    }

    /**
     * Set the length of the file. For internal use.
     *
     * @param      len length
     */

    private void setLengthStream(long len){
        excInit();
        if ((FL_B & this.trc) != 0){
            Trc.out.println("setLength: " + trcmode());
        }
        doit: try {
            if ((IS_OPEN & this.status) == 0){       // file not open
                registerError(IOError.ERR_NOTOPEN,null);
                break doit;
            }
            if ((RANDOM & this.mode) == 0){          // not in random mode
                registerError(IOError.ERR_INVOP,null);
                break doit;
            }
            this.randStream.setLength(len);
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } finally {
            excTerm();
        }
    }

    /**
     * Write bytes into the current byte stream.
     *
     * @param      bb reference to the array containing the bytes
     * @param      off start offset in it
     * @param      len number of bytes to be written
     * @exception  IOException 
     */

    private void put(byte[] bb, int off, int len) throws IOException {
        int end = bb.length;                         // reduce to buffer
        if (off > end) off = end;                    // .. area
        if ((off + len < 0) || (off + len > end))
            len = end - off;
        int n = 0;
        int start = off;
        do {
            int l = len - n;
            if (l > MAX_TRANSFER) l = MAX_TRANSFER;
            if ((RANDOM & this.mode) != 0){
                this.randStream.write(bb,start,l);
            } else {
                this.outStream.write(bb,start,l);
            }
            this.nrIoDone++;
            start += l;
            n += l;
            if (n >= len) break;
            if (Thread.currentThread().isInterrupted()){
                throw new InterruptedIOException();
            }
        } while (true);
        if ((FL_C & this.trc) != 0){
            Trc.out.println("written: " + byteToString(bb,off,len));
        }
    }

    /**
     * Write characters into the current character stream.
     *
     * @param      cb reference to the array containing the characters
     * @param      off start offset in it
     * @param      len number of characters to be written
     * @exception  IOException 
     */

    private void putChars(char[] cb, int off, int len) throws IOException {
        if ((FL_B & this.trc) != 0){
            Trc.out.println("putChars");
        }
        int end = cb.length;                         // reduce to buffer
        if (off > end) off = end;                    // .. area
        if ((off + len < 0) || (off + len > end))
            len = end - off;
        PrintStream printer = null;
        if (this.writerStream == null){
            printer = (PrintStream)(this.outStream);
        }
        int n = 0;
        int start = off;
        do {
            int l = len - n;
            if (l > MAX_TRANSFER) l = MAX_TRANSFER;
            if (this.writerStream != null){
                this.writerStream.write(cb,start,l);
            } else {
                if (l > this.bufferSize) l = this.bufferSize;
                char[] tmp = new char[l];
                System.arraycopy(cb,start,tmp,0,l);
                printer.print(tmp);
                printStreamCheck();
            }
            if (this.ouAdapt == null) this.nrIoDone++;
            start += l;
            n += l;
            if (n >= len) break;
            if (Thread.currentThread().isInterrupted()){
                throw new InterruptedIOException();
            }
        } while (true);
        if ((FL_C & this.trc) != 0){
            Trc.out.println("written: " + String.valueOf(cb,off,len));
        }
    }

    /**
     * Write slice of a String into the current character stream.
     *
     * @param      str reference to the String
     * @param      off start offset in it
     * @param      len number of characters to be written
     * @exception  IOException 
     */

    private void putString(String str, int off, int len) throws IOException {
        int end = str.length();                      // reduce to string
        if (off > end) off = end;                    // .. area
        if ((off + len < 0) || (off + len > end))
            len = end - off;
        CharsRow charbuf = this.charOutBuf;
        PrintStream printer = null;
        if (this.writerStream != null){
            charsBufferExtend(charbuf,charbuf.offset + this.bufferSize,true);
        } else {
            printer = (PrintStream)(this.outStream);
        }
        int n = 0;
        int start = off;
        do {
            int l = len - n;
            if (l > this.bufferSize) l = this.bufferSize;
            if (this.writerStream != null){
                str.getChars(start,start+l,charbuf.buffer,
                    charbuf.offset);
                this.writerStream.write(charbuf.buffer,
                    charbuf.offset,l);
            } else {
                char[] tmp = new char[l];
                str.getChars(start,start+l,tmp,0);
                printer.print(tmp);
                printStreamCheck();
            }
            if (this.ouAdapt == null) this.nrIoDone++;
            start += l;
            n += l;
            if (n >= len) break;
            if (Thread.currentThread().isInterrupted()){
                throw new InterruptedIOException();
            }
        } while (true);
        if ((FL_C & this.trc) != 0){
            Trc.out.println("written: " + str.substring(off,off+len));
        }
    }

    /**
     * Flush the buffer.
     *
     * @param      bytes <code>true</code> to denote the bytes buffer,
     *             <code>false</code> to denote the character buffer
     * @exception  IOException 
     */

    private void flushBuffer(boolean bytes) throws IOException {
        if ((FL_C & this.trc) != 0){
            Trc.out.println("flushBuffer: " + bytes);
        }
        if (bytes){
            BytesRow bytebuf = this.byteOutBuf;
            if (bytebuf.buffer == null) return;
            if (bytebuf.offset <= 0) return;       // buffer empty
            put(bytebuf.buffer,0,bytebuf.offset);
            bytebuf.offset = 0;
            bytebuf.length = 0;
        } else {
            CharsRow charbuf = this.charOutBuf;
            if (charbuf.buffer == null) return;
            if (charbuf.offset <= 0) return;       // buffer empty
            putChars(charbuf.buffer,0,charbuf.offset);
            charbuf.offset = 0;
            charbuf.length = 0;
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("flushBuffer done");
        }
    }

    /**
     * Flush the data which are buffered.
     */

    public void flush(){
        if ((FL_B & this.trc) != 0){
            Trc.out.println("flush: " + trcmode());
        }
        if (this.mutex != null){
            synchronized (this.mutex) {
                flushStream();
            }
        } else {
            flushStream();
        }
    }

    /**
     * Flush the data which are buffered. For internal use.
     */

    private void flushStream(){
        excInit();
        doit: try {
            flushAllStreams();
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (IOError exc){
        } finally {
            excTerm();
        }
    }

    /**
     * Flush the data which are buffered. For internal use.
     *
     * @exception  IOException 
     */

    private void flushAllStreams() throws IOException {
        flushBuffer(false);                  // flush chars first
        if (this.writerStream != null){
            if ((FL_C & this.trc) != 0){
                Trc.out.println("flush: writer");
            }
            this.writerStream.flush();
        }
        flushBuffer(true);                   // then bytes
        if (this.outStream != null){
            if ((FL_C & this.trc) != 0){
                Trc.out.println("flush: output");
            }
            this.outStream.flush();
            if ((ISPRINT & this.status) != 0){
                printStreamCheck();
            }
        }
    }

    /** The system-dependent line separator. */
    private static String LINE_SEP =
        System.getProperty("line.separator");

    /**
     * Write an array of characters, or a String, or an array of bytes.
     *
     * @see        #writeStream(char[],String,byte[],
     *              int,int,int,boolean,boolean)
     */

    /* Write tries to exploit the buffer: first fill it if there is room,
     * then flush it if it has become full. Then, the remaining data are
     * fed into the (emptied) buffer if there is room, otherwise they are
     * printed directly.
     *
     * Since a PrinStream is internally buffered, there is no need for
     * buffering, and thus when the stream is of that class, write is done
     * directly.
     * Moreover, PrintStreams control by themselves autoflushing, and thus
     * IoStream writes directly on them.
     *
     * The current implementation of write for UCS2 loads into the buffer an
     * even number of bytes, and thus it is efficient for buffer sizes which
     * are a multiple of 2.
     *
     * There is a writeln() without arguments for characters. There is
     * no immediate equivalent for bytes because there would either be
     * a need for an argument or for another method name.
     *
     * The dual of the read() which delivers a row would be something like
     * having a method which delivers a row to an array as large as requested,
     * which would be a slice of the buffer, and a write() which uses it
     * directly. This could be useful in conjunction with Formatter since
     * it knows the lenght of the text record, and it can deposit the data
     * in it managing the text record without telling the caller where it it.
     * There would be a need for two methods to return a row to a buffer as
     * large at least as requested, which flush the buffer if there is a block
     * of data in it so as to spare to enlarge it.
     * The caller would fill the slice. Then it would call a write(), which
     * flushed it if in it there were at least bufferSize data, and shifted
     * the rest (or writes it all). After each write there would be a need to
     * get the new offset, or row, to fill it. This can imply the flushing of
     * the buffer so as not to enlarge it if possible. The obtainment of the
     * row could also flush the buffer to avoid to enlarge it when two
     * requests are made without a write() in between.
     * Note, however, that there is eventually always a need to move data
     * from some place in an application into a write buffer (or, to transfer
     * them directly to the undelying native io layer). The purpose of write()
     * is exactly the same, and thus letting the user access the buffer adds
     * little efficiency. Moreover, the interface is quite complex. For these
     * reasons this is not provided.
     */

    private void write(char[] t1, String st1, byte[] bt1,
        int e1, int s1, int l1, boolean bytes, boolean nln){
        if (this.mutex != null){
            synchronized (this.mutex) {
                writeStream(t1,st1,bt1,e1,s1,l1,bytes,nln);
            }
        } else {
            writeStream(t1,st1,bt1,e1,s1,l1,bytes,nln);
        }
    }

    /**
     * Write an array of characters, or a String, or an array of bytes.
     * For internal use.
     *
     * @param      t1 character array
     * @param      st1 String
     * @param      bt1 String
     * @param      e1 end of it
     * @param      s1 start index of slice in t1
     * @param      l1 length of slice
     * @param      bytes <code>true</code> to denote bytes
     * @param      nln <code>true</code> to write a line separator
     */

    private void writeStream(char[] t1, String st1, byte[] bt1,
        int e1, int s1, int l1, boolean bytes, boolean nln){
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0;
        if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;

        if ((FL_B & this.trc) != 0){
            Trc.out.println("write: " + trcmode());
        }
        excInit();
        doit: try {
            if ((IS_OPEN & this.status) == 0){           // file not open
                registerError(IOError.ERR_NOTOPEN,null);
                break doit;
            }
            if (((WRITE | APPEND) & this.mode) == 0){
                registerError(IOError.ERR_INVOP,null);
                break doit;
            }
            if (bytes){
                if ((BYTES & this.mode) == 0){
                    registerError(IOError.ERR_INVOP,null);
                    break doit;
                }
            }
            if ((l1 == 0) && !nln) return;
            int nl = nln ? this.lineSep.length : 0;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("write: " + (l1 + nl) + " data nln " + nln + " nl " + nl);
            }
            if (!bytes){                              // chars
                creaAd: if (this.writerStream == null){   // in byte stream
                    if ((ISPRINT & this.status) != 0){
                        if ((NEW_ENCODING & this.status) == 0){
                            break creaAd;
                        }
                    }
                    this.status &= ~NEW_ENCODING;
                    if (((ISO8859_1 | UCS2) & this.status) != 0){
                        break creaAd;
                    }
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("write create adapter");
                    }
                    createOutAdapter();
                }
            } else {                                 // bytes
                if (this.writerStream != null){      // after chars
                    if (this.charOutBuf.offset > 0){ 
                        flushBuffer(false);          // in random always empty
                    }
                    this.writerStream.flush();       // do it, there is no way
                }                                    // .. to know if there are
                                                     // .. bytes pending or not
            }

            imm: {
                if (this.writerStream == null){      // no higher one
                    if (((ISPRINT & this.status) == 0) &&
                        ((ISBUFSTREAM & this.status) == 0)){
                        break imm;
                    }
                } else {
                    if ((ISBUFWRITER & this.status) == 0){
                        break imm;
                    }
                }
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("write: immediate");
                }
                if (t1 != null){
                    putChars(t1,s1,l1);
                } else if (st1 != null){
                    putString(st1,s1,l1);
                } else if (bt1 != null){
                    put(bt1,s1,l1);
                }
                if (nln){
                    if (!bytes){
                        putChars(this.lineSep,0,this.lineSep.length);
                    } else {
                        put(this.byteLineSep,0,this.byteLineSep.length);
                    }
                }
                if ((AUTOFLUSH & this.mode) != 0){
                    flushAllStreams();
                }
                break doit;
            }
            if (bytes && ((RANDOM & this.mode) != 0)){   // bytes and random
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("write: random immediate");
                }
                if (bt1 != null){
                    put(bt1,s1,l1);
                }
                if (nln){
                    put(this.byteLineSep,0,this.byteLineSep.length);
                }
                if ((AUTOFLUSH & this.mode) != 0){
                    flushAllStreams();
                }
                break doit;
            }

            int toWrite = l1;
            int curr = this.byteOutBuf.offset;
            if (!bytes &&
                (((ISO8859_1 | UCS2) & this.status) == 0)){
                curr = this.charOutBuf.offset;
            }
            int rem = l1;
            int off = s1;
            if (((AUTOFLUSH & this.mode) == 0) ||   // no autoflush or
                (curr != 0) ||                      // .. pending data
                nln ||                              // .. avoid two write's
                (!bytes &&
                    (((ISO8859_1 | UCS2) & this.status) != 0))){
                int n = 0;
                do {                                // loop for special enc.
                    n = deposit(t1,st1,bt1,off,rem);
                    off += n;
                    rem -= n;
                    toWrite -= n;
                    if ((FL_C & this.trc) != 0){
                        Trc.out.println("write loop: " + rem);
                    }
                } while ((rem > 0) &&
                    (((ISO8859_1 | UCS2) & this.status) != 0));
            }
            rem = toWrite;
            if (rem > 0){                           // not yet completed
                off = s1 + l1 - rem;
                boolean direct =
                    (rem >= this.bufferSize) ||
                    ((AUTOFLUSH & this.mode) != 0);
                if (direct){                        // direct transfer
                    if (t1 != null){
                        putChars(t1,off,rem);
                    } else if (st1 != null){
                        putString(st1,off,rem);
                    } else if (bt1 != null){
                        put(bt1,off,rem);
                    }
                } else {
                    deposit(t1,st1,bt1,off,rem);
                }
                toWrite -= rem;
            }
            if (nln){
                toWrite += nl;
                if (!bytes){
                    toWrite -= deposit(this.lineSep,null,null,0,nl);
                } else {
                    toWrite -= deposit(null,null,this.byteLineSep,0,nl);
                }
                if (toWrite > 0){                          // not yet completed
                    rem = toWrite;
                    boolean direct =
                        (rem >= this.bufferSize) ||
                        ((AUTOFLUSH & this.mode) != 0);
                    if (!bytes &&
                        (((ISO8859_1 | UCS2) & this.status) != 0)){
                        direct = false;
                    }
                    if (direct){                           // direct transfer
                        if (!bytes){
                            putChars(this.lineSep,nl-rem,rem);
                        } else {
                            put(this.byteLineSep,nl-rem,rem);
                        }
                    } else {
                        if (!bytes){
                            deposit(this.lineSep,null,null,nl - rem,rem);
                        } else {
                            deposit(null,null,this.byteLineSep,nl - rem,rem);
                        }
                    }
                    toWrite -= rem;
                }
            }
            if ((AUTOFLUSH & this.mode) != 0){
                flushAllStreams();
            }
        } catch (SecurityException exc){
            registerError(IOError.ERR_SECURITY,exc);
        } catch (IOException exc){
            registerError(IOError.ERR_IOERR,exc);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (IOError exc){
        } finally {
            if ((FL_B & this.trc) != 0){
                Trc.out.println("write done");
            }
            excTerm();
        }
    }

    /**
     * Deposit data in the buffer. A slice of a character array, String,
     * or byte array is accepted.
     *
     * @param      buf character array
     * @param      str String
     * @param      bbuf byte array
     * @param      off start index of slice in array
     * @param      len length of slice
     * @return     number of characters deposited
     * @exception  IOException 
     */

    private int deposit(char[] buf, String str, byte[] bbuf, int off, int len)
        throws IOException {
        CharsRow charbuf = this.charOutBuf;
        BytesRow bytebuf = this.byteOutBuf;
        int piece;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("deposit: " + (buf == null) +
               " " + (str == null) + " " + (bbuf == null)  + " off " + off + " len " + len);
        }
        if ((buf == null) && (str == null) &&
            (bbuf == null)){
            return 0;
        }
        if (bbuf != null){
            if ((bytebuf.offset == 0) &&              // buffer empty and big
                (len >= this.bufferSize)) return 0;   // .. transfer
            bytesBufferEnsure(bytebuf);
            piece = this.bufferSize - bytebuf.offset;
        } else if ((ISO8859_1 & this.status) != 0){
            bytesBufferEnsure(bytebuf);
            piece = this.bufferSize - bytebuf.offset;
            if (str != null){
                if (charbuf.buffer == null){
                    charsBufferExtend(charbuf,this.bufferSize,false);
                }
                int p = this.bufferSize - charbuf.offset;
                if (piece > p) piece = p;
            }
        } else if ((UCS2 & this.status) != 0){
            bytesBufferEnsure(bytebuf);
            piece = (this.bufferSize - bytebuf.offset) >> 1;
            if (str != null){
                if (charbuf.buffer == null){
                    charsBufferExtend(charbuf,this.bufferSize,false);
                }
                int p = this.bufferSize - charbuf.offset;
                if (piece > p) piece = p;
            }
        } else {
            if ((charbuf.offset == 0) &&            // buffer empty and big
                (len >= this.bufferSize)) return 0; // .. transfer
            if (charbuf.buffer == null){
                charsBufferExtend(charbuf,this.bufferSize,false);
            }
            piece = this.bufferSize - charbuf.offset;
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("piece " + piece + " " + len);
        }
        if (piece > 0){                               // buffer not full
            if (piece > len) piece = len;
            if (buf != null){
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("to buffer: " +
                        byteToString(buf,off,piece));
                }
                if ((ISO8859_1 & this.status) != 0){  // copy and convert
                    int j = bytebuf.offset;
                    for (int i = off; i < off + piece; i++){
                        char c = buf[i];
                        byte b = (c > 0xff) ? (byte)'?' : (byte)(c);
                        bytebuf.buffer[j++] = b;
                    }
                    bytebuf.offset = j;
                } else if ((UCS2 & this.status) != 0){
                    int j = bytebuf.offset;
                    for (int i = off; i < off + piece; i++){
                        char c = buf[i];
                        bytebuf.buffer[j++] = (byte)((c >>> 8) & 0xff);
                        bytebuf.buffer[j++] = (byte)(c & 0xff);
                    }
                    bytebuf.offset = j;
                } else {
                    System.arraycopy(buf,off,charbuf.buffer,
                        charbuf.offset,piece);
                    charbuf.offset += piece;
                }
            } else if (str != null){
                str.getChars(off,off+piece,charbuf.buffer,
                    charbuf.offset);
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("to buffer: " +
                        byteToString(str,off,piece));
                }
                charbuf.offset += piece;
                if ((ISO8859_1 & this.status) != 0){
                    int j = bytebuf.offset;
                    for (int i = charbuf.offset-piece;
                        i < charbuf.offset; i++){
                        char c = charbuf.buffer[i];
                        byte b = (c > 0xff) ? (byte)'?' : (byte)(c);
                        bytebuf.buffer[j++] = b;
                    }
                    charbuf.offset -= piece;
                    bytebuf.offset = j;
                } else if ((UCS2 & this.status) != 0){
                    int j = bytebuf.offset;
                    for (int i = charbuf.offset-piece;
                        i < charbuf.offset; i++){
                        char c = charbuf.buffer[i];
                        bytebuf.buffer[j++] = (byte)((c >>> 8) & 0xff);
                        bytebuf.buffer[j++] = (byte)(c & 0xff);
                    }
                    charbuf.offset -= piece;
                    bytebuf.offset = j;
                }
            } else {
                System.arraycopy(bbuf,off,bytebuf.buffer,
                    bytebuf.offset,piece);
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("to buffer: " +
                        byteToString(bbuf,off,piece));
                }
                bytebuf.offset += piece;
            }
        }
        int bufferLimit = this.bufferSize;
        if ((UCS2 & this.status) != 0) bufferLimit &= ~1;   // make it even
        if ((bbuf != null) ||
            (((ISO8859_1 | UCS2) & this.status) != 0)){
            if (bytebuf.offset >= bufferLimit){             // buffer full
                flushBuffer(true);
            }
            if ((FL_C & this.trc) != 0){
                Trc.out.println(bytebuf.offset + " in buffer");
            }
        } else {
            if (charbuf.offset >= this.bufferSize){         // buffer full
                flushBuffer(false);
            }
            if ((FL_C & this.trc) != 0){
                Trc.out.println(charbuf.offset + " in buffer");
            }
        }
        return piece;
    }

    /**
     * Write an array of characters. A reference to an array which is
     * null is equivalent to a reference to an empty one.
     *
     * @param      t1 array
     * @param      s1 start index of slice in t1
     * @param      l1 length of slice
     */

    public void write(char[] t1, int s1, int l1){
        int len = (t1 == null) ? 0 : t1.length;
        write(t1,null,null,len,s1,l1,false,false);
    }

    /**
     * Write an array of characters.
     *
     * @see        #write(char[],int,int)
     */

    public void write(char[] t1){
        int len = (t1 == null) ? 0 : t1.length;
        write(t1,null,null,len,0,len,false,false);
    }

    /**
     * Write an array of characters in a line.
     *
     * @see        #writeln(char[],int,int)
     */

    public void writeln(char[] t1, int s1, int l1){
        int len = (t1 == null) ? 0 : t1.length;
        write(t1,null,null,len,s1,l1,false,true);
    }

    /**
     * Write an array of characters in a line.
     *
     * @see        #writeln(char[],int,int)
     */

    public void writeln(char[] t1){
        int len = (t1 == null) ? 0 : t1.length;
        write(t1,null,null,len,0,len,false,true);
    }

    /**
     * Write the slice of an array of characters denoted by a row.
     *
     * @param      r row to the slice
     */

    public void write(CharsRow r){
        if ((r == null) || (r.buffer == null)) r = CharsRow.EMPTY;
        int len = (r.buffer == null) ? 0 : r.buffer.length;
        write(r.buffer,null,null,len,r.offset,r.length,
            false,false);
    }

    /**
     * Write the slice of an array of characters denoted by a row in a line.
     *
     * @param      r row to the slice
     */

    public void writeln(CharsRow r){
        if ((r == null) || (r.buffer == null)) r = CharsRow.EMPTY;
        int len = (r.buffer == null) ? 0 : r.buffer.length;
        write(r.buffer,null,null,len,r.offset,r.length,
            false,true);
    }

    /**
     * Write a string of characters.
     *
     * @see        #write(char[],int,int)
     */

    public void write(Str t1, int s1, int l1){
        if (t1 == null) t1 = Str.EMPTY;
        write(t1.buffer,null,null,t1.length,s1,l1,false,false);
    }

    /**
     * Write a string of characters.
     *
     * @see        #write(char[],int,int)
     */

    public void write(Str t1){
        if (t1 == null) t1 = Str.EMPTY;
        write(t1.buffer,null,null,t1.length,0,t1.length,false,false);
    }

    /**
     * Write a string of characters in a line.
     *
     * @see        #writeln(char[],int,int)
     */

    public void writeln(Str t1, int s1, int l1){
        if (t1 == null) t1 = Str.EMPTY;
        write(t1.buffer,null,null,t1.length,s1,l1,false,true);
    }

    /**
     * Write a string of characters in a line.
     *
     * @see        #writeln(char[],int,int)
     */

    public void writeln(Str t1){
        if (t1 == null) t1 = Str.EMPTY;
        write(t1.buffer,null,null,t1.length,0,t1.length,false,true);
    }

    /**
     * Write a string of characters.
     *
     * @see        #write(char[],int,int)
     */

    public void write(String t1, int s1, int l1){
        int len = (t1 == null) ? 0 : t1.length();
        write(null,t1,null,len,s1,l1,false,false);
    }

    /**
     * Write a string of characters.
     *
     * @see        #write(char[],int,int)
     */

    public void write(String t1){
        int len = (t1 == null) ? 0 : t1.length();
        write(null,t1,null,len,0,len,false,false);
    }

    /**
     * Write a string of characters in a line.
     *
     * @see        #writeln(char[],int,int)
     */

    public void writeln(String t1, int s1, int l1){
        int len = (t1 == null) ? 0 : t1.length();
        write(null,t1,null,len,s1,l1,false,true);
    }

    /**
     * Write a string of characters in a line.
     *
     * @see        #writeln(char[],int,int)
     */

    public void writeln(String t1){
        int len = (t1 == null) ? 0 : t1.length();
        write(null,t1,null,len,0,len,false,true);
    }

    /**
     * Write a line termination.
     *
     * @see        #writeln(char[],int,int)
     */

    public void writeln(){
        write(null,null,null,0,0,0,false,true);
    }

    /**
     * Write an array of bytes.
     *
     * @see        #write(char[],int,int)
     */

    public void write(byte[] t1, int s1, int l1){
        int len = (t1 == null) ? 0 : t1.length;
        write(null,null,t1,len,s1,l1,true,false);
    }

    /**
     * Write an array of bytes.
     *
     * @see        #write(char[],int,int)
     */

    public void write(byte[] t1){
        int len = (t1 == null) ? 0 : t1.length;
        write(null,null,t1,len,0,len,true,false);
    }

    /**
     * Write an array of bytes in a line.
     *
     * @see        #writeln(char[],int,int)
     */

    public void writeln(byte[] t1, int s1, int l1){
        int len = (t1 == null) ? 0 : t1.length;
        write(null,null,t1,len,s1,l1,true,true);
    }

    /**
     * Write an array of bytes in a line.
     *
     * @see        #writeln(char[],int,int)
     */

    public void writeln(byte[] t1){
        int len = (t1 == null) ? 0 : t1.length;
        write(null,null,t1,len,0,len,true,true);
    }

    /**
     * Write the slice of an array of bytes denoted by a row.
     *
     * @param      r row to the slice
     */

    public void write(BytesRow r){
        if ((r == null) || (r.buffer == null)) r = BytesRow.EMPTY;
        int len = (r.buffer == null) ? 0 : r.buffer.length;
        write(null,null,r.buffer,len,r.offset,r.length,
            true,false);
    }

    /**
     * Write the slice of an array of bytes denoted by a row in a line.
     *
     * @param      r row to the slice
     */

    public void writeln(BytesRow r){
        if ((r == null) || (r.buffer == null)) r = BytesRow.EMPTY;
        int len = (r.buffer == null) ? 0 : r.buffer.length;
        write(null,null,r.buffer,len,r.offset,r.length,
            true,true);
    }


    /**
     * Change the size of the buffer for internal buffering. The file must
     * not be open. It is useless to reduce the size to zero because in
     * such a case it is not reduced since it would make impossible to
     * perform some operations like, e.g. reading of lines.
     *
     * @param      size new size
     */

    /* The method sets the size of the bytes buffer and that of the
     * characters buffer. This is so as not to bother the user to know
     * the internal details of buffering. For all buffers present, their
     * size is enlarged if not sufficient.
     */

    public void setBufferSize(int size){
        if (this.mutex != null){
            synchronized (this.mutex) {
                setBufSize(size);
            }
        } else {
            setBufSize(size);
        }
    }

    /**
     * Change the size of the buffer for internal buffering. For internal use.
     *
     * @param      size new size
     */

    private void setBufSize(int size){
        excInit();
        doit: try {
            if ((IS_OPEN & this.status) != 0){
                registerError(IOError.ERR_ISOPEN,null);
                break doit;
            }
            if ((size <= 0) || (size + BYTES_EXTRA < 0)){
                registerError(IOError.ERR_VALUE,null);
                break doit;
            }
            this.bufferSize = size;
            if (this.charInBuf != null){
                charsBufferExtend(this.charInBuf,size,false);
            }
            if (this.byteInBuf != null){
                bytesBufferExtend(this.byteInBuf,size,false);
            }
            if (this.charOutBuf != null){
                charsBufferExtend(this.charOutBuf,size,false);
            }
            if (this.byteOutBuf != null){
                bytesBufferExtend(this.byteOutBuf,size,false);
            }
        } finally {
            excTerm();
        }
    }

    /** The default buffer size for buffered operations. */
    private static final int BUFFER_SIZE = 1024;

    /** The characters input buffer. */
    private CharsRow charInBuf;

    /** The bytes input buffer. */
    private BytesRow byteInBuf;

    /** The characters output buffer. */
    private CharsRow charOutBuf;

    /** The bytes output buffer. */
    private BytesRow byteOutBuf;

    /** The extra space in the bytes buffer for incomplete bytes sequences. */
    private static int BYTES_EXTRA = 10;

    /* When buffer are requested to be extended by an amount which exceeds
     * the integer limit, a StringIndexOutOfBoundException exception is
     * thrown. This is done only for completeness. Such methods are never
     * called with illegal values.
     */

    /**
     * Deliver a string representing a buffer.
     *
     * @param      buf buffer
     * @returnb    string
     */

    private String theBuf(Object buf){
        String str = null;
        if (buf == charInBuf) str = "input char";
        if (buf == byteInBuf) str = "input byte";
        if (buf == charOutBuf) str = "output char";
        if (buf == byteOutBuf) str = "output byte";
        return str + " buffer ";
    }

    /**
     * Ensure that a bytes buffer be present.
     *
     * @param      buf buffer
     */

    private void bytesBufferEnsure(BytesRow buf){
        if (buf.buffer == null){
            buf.buffer =
                new byte[this.bufferSize + BYTES_EXTRA];
            if ((FL_M & this.trc) != 0){
                Trc.out.println(theBuf(buf) + " allocated " +
                    buf.buffer.length);
            }
        }
        if ((RANDOM & this.mode) != 0){
            if (this.byteInBuf != null){
                this.byteInBuf.buffer = buf.buffer;
            }
            if (this.byteOutBuf != null){
                this.byteOutBuf.buffer = buf.buffer;
            }
        }
    }

    /**
     * Extend a bytes buffer reaching the given capacity.
     *
     * @param      buf buffer
     * @param      cap capacity
     * @param      keep <code>true</code> to copy the old contents in the
     *             extended buffer
     */

    private void bytesBufferExtend(BytesRow buf, int cap, boolean keep){
        if ((cap < 0) || (cap + BYTES_EXTRA < 0)){
            throw new StringIndexOutOfBoundsException(cap);
        }
        byte[] cur = null;
        int curLen = 0;
        if (buf != null){
            cur = buf.buffer;
            if (cur != null) curLen = cur.length;
        }
        if (curLen < cap){
            byte[] p = new byte[cap + BYTES_EXTRA];
            if ((FL_M & this.trc) != 0){
                Trc.out.println(theBuf(buf) + " extended: " +
                    curLen + " " + p.length);
            }
            if ((cur != null) && keep){
                System.arraycopy(cur,0,p,0,curLen);
            }
            buf.buffer = p;
            if ((RANDOM & this.mode) != 0){
                if (this.byteInBuf != null){
                    this.byteInBuf.buffer = buf.buffer;
                }
                if (this.byteOutBuf != null){
                    this.byteOutBuf.buffer = buf.buffer;
                }
            }
        }
    }

    /**
     * Enlarge the bytes buffer by the given capacity.
     *
     * @param      cap capacity
     * @param      keep <code>true</code> to copy the old contents in the
     *             extended buffer
     */

    private void bytesBufferEnlarge(int cap, boolean keep){
        if (cap < 0) return;
        byte[] cur = null;
        int curLen = 0;
        if (this.byteInBuf != null){
            cur = this.byteInBuf.buffer;
            if (cur != null) curLen = cur.length;
        } else {
            this.byteInBuf = new BytesRow();
        }
        cap += curLen;
        if (cap < 0)
            throw new StringIndexOutOfBoundsException(cap);
        if (cap == 0){
            cap = this.bufferSize;
        } else if (cap < this.bufferSize){
            cap = this.bufferSize;
        }
        byte[] p = new byte[cap];
        if ((cur != null) && keep){
            System.arraycopy(cur,0,p,0,curLen);
        }
        this.byteInBuf.buffer = p;
        if ((FL_M & this.trc) != 0){
            Trc.out.println(theBuf(this.byteInBuf) + curLen +
                " enlarged " + cap);
        }
    }

    /**
     * Trace the bytes buffer.
     *
     * @param      comm comment string
     */

    private void bytesBufferTrace(String comm){
        Trc.out.print(comm + ": " + " " + this.byteInBuf.offset + " " +
            this.byteInBuf.length);
        for (int i = 0; i < this.byteInBuf.length; i++){
            Trc.out.print(" 0x" +
                Integer.toHexString(this.byteInBuf.buffer[i] & 0xff));
        }
        Trc.out.println();
    }

    /**
     * Extend a character buffer reaching the given capacity.
     *
     * @param      buf buffer
     * @param      cap capacity
     * @param      keep <code>true</code> to copy the old contents in the
     *             extended buffer
     */

    private void charsBufferExtend(CharsRow buf, int cap, boolean keep){
        if (cap < 0)
            throw new StringIndexOutOfBoundsException(cap);
        char[] cur = null;
        int curLen = 0;
        if (buf != null){
            cur = buf.buffer;
            if (cur != null) curLen = cur.length;
        }
        if (curLen < cap){
            char[] p = new char[cap];
            if ((cur != null) && keep){
                System.arraycopy(cur,0,p,0,curLen);
            }
            buf.buffer = p;
            if ((FL_M & this.trc) != 0){
                Trc.out.println(theBuf(buf) + curLen + " extended " + cap);
            }
            if ((RANDOM & this.mode) != 0){
                if (this.charInBuf != null){
                    this.charInBuf.buffer = buf.buffer;
                }
                if (this.charOutBuf != null){
                    this.charOutBuf.buffer = buf.buffer;
                }
            }
        }
    }

    /**
     * Enlarge the character buffer by the given capacity.
     *
     * @param      cap capacity
     * @param      keep <code>true</code> to copy the old contents in the
     *             extended buffer
     */

    private void charsBufferEnlarge(int cap, boolean keep){
        if (cap < 0) return;
        char[] cur = null;
        int curLen = 0;
        if (this.charInBuf != null){
            cur = this.charInBuf.buffer;
            if (cur != null) curLen = cur.length;
        } else {
            this.charInBuf = new CharsRow();
        }
        cap += curLen;
        if (cap < 0)
            throw new StringIndexOutOfBoundsException(cap);
        if (cap == 0){
            cap = this.bufferSize;
        } else if (cap < this.bufferSize){
            cap = this.bufferSize;
        }
        char[] p = new char[cap];
        if ((cur != null) && keep){
            System.arraycopy(cur,0,p,0,curLen);
        }
        this.charInBuf.buffer = p;
        if ((FL_M & this.trc) != 0){
            Trc.out.println(theBuf(this.charInBuf) + curLen +
                " enlarged " + cap);
        }
    }

    /**
     * Ensure that the rows to the buffers are present.
     */

    private void ensureBuffers(){
        if ((READ & this.mode) != 0){
            if (this.byteInBuf == null){
                this.byteInBuf = new BytesRow();
            } else {
                this.byteInBuf.offset = 0;
                this.byteInBuf.length = 0;
            }
            if (this.charInBuf == null){
                this.charInBuf = new CharsRow();
            } else {
                this.charInBuf.offset = 0;
                this.charInBuf.length = 0;
            }
        }
        if (((WRITE | APPEND) & this.mode) != 0){
            if (this.byteOutBuf == null){
                this.byteOutBuf = new BytesRow();
            } else {
                this.byteOutBuf.offset = 0;
                this.byteOutBuf.length = 0;
            }
            if (this.charOutBuf == null){
                this.charOutBuf = new CharsRow();
            } else {
                this.charOutBuf.offset = 0;
                this.charOutBuf.length = 0;
            }
        }
    }
}
