/*
 * @(#)CliBundle_en.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

/**
 * The <code>CliBundle_en</code> class provides the English locale for
 * the <code>Cli</code> class.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */


public class CliBundle_en extends CliBundle {
}
