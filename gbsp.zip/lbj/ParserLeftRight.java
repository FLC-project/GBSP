/*
 * @(#)ParserLeftRight.jpp       1.0 2020/07/16
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;
import lbj.ParserLRTables.*;
import lbj.ParserGLRengine;

/**
 * The <code>ParserLeftRight</code> class provides the LR parsing algorithm.
 *
 * @author  Angelo Borsotti
 * @version 1.0   16 Jul 2020
 */


class ParserLeftRight extends ParserGLRengine {

    /** 
     * Construct a parser for the specified grammar and lexicon.
     *
     * @param      tab reference to the general parse tables
     * @param      inp input stream
     * @param      flags trace flags
     * @param      algo kind of parser
     */

    public ParserLeftRight(ParserTables tab, Object inp, String flags, String algo){
        setParserData(tab,inp,flags,algo);
    }

    /** 
     * Construct a parser for the specified grammar and lexicon.
     */

    public ParserLeftRight(){
    }

    /** 
     * Set the specified parser data.
     *
     * @param      tab reference to the general parse tables
     * @param      inp input stream
     * @param      flags trace flags
     * @param      algo kind of parser
     */

    @Override
    protected void setParserData(ParserTables tab, Object inp, String flags, String algo){
        this.tab = tab;
        ParserLRTables lrt = (ParserLRTables)this.tab.pilot;
        this.tablr = (ParserLRTables.LR0FAtables)lrt.lrTables;
        if (inp != null){
            this.lex = new ParserLex(tab,inp);
        }
        this.algo = algo;
        settrc(flags);
        EOF = this.tab.numOfToks;
    }

    /** The reference to the LR parse tables. */
    ParserLRTables.LR0FAtables tablr;

    /**
     * Parse the input from the lexer that was specified at object construction
     * time.  Return whether the parsing ended successfully.
     *
     * @return <code>true</code> if the parsing succeeds, and <code>false</code> otherwise.
     */

    public boolean parse(){
        ;
        if ((FL_P & this.trc) != 0){
            this.tab.traceGrammar();
            tracePilot(Trc.wrt);
        }
        boolean res = false;
        enlargeGSS(1);
        this.loc = 1;
        this.etrees = new int[this.tab.numOfNts];
        // initialize the stack with the node that starts the LR parsing

        this.currentToken = tokenizer();
        if (this.currentToken < 0){
            return false;
        }

        int stackBottom = this.gssEdgeNr;
        pushLRstack(0,0);
        int state = 0;
        for (;;){
            int actlen = this.tablr.LRbase[state];int actstart = actlen + this.currentToken+this.tab.tokBase;actlen = this.tablr.LRcheck[actstart] == actlen ? this.tablr.LRtable[actstart] : 0;if (actlen> 0){actlen= 1;} else if (actlen < 0){actstart= -actlen;actlen = this.tablr.LRtable[actstart++];};
            if (actlen == 0){                 // no action
                res = false;
                break;
            }
            int action = this.tablr.LRtable[actstart];      // first action
            // shift come first, so it wins the s/r conflict
            // reductions are instead not ordered
            if (action >= ParserLRTables.ISREDUCE){               // reduce
                int rule = action & ParserLRTables.RULEMASK;
                int rhsLen = this.tab.ruleLen[rule];        // length of rule
                ;
                int z = 0;
                z = encodeLRtree(rule);
                this.gssEdgeNr -= this.tab.ruleLen[rule] * 3;   // pop the stack
                // now move from the exposed state with the reduced nonterminal
                int nt = this.tab.ruleToNt[rule];
                int topstack = this.gssEdgeNr - 3;
                ;
                if (topstack < stackBottom){          // end of LR piece
                    this.LRtree = z | HEAD;
                    res = true;
                    break;
                }
                int lrbase0= this.tablr.LRbase[gssEdgeDir[(topstack)>>>NSHF][((topstack)&MSK)]];int newState = this.tablr.LRcheck[lrbase0+nt] == lrbase0 ? this.tablr.LRtable[lrbase0+nt] : 0;;
                ;
                pushLRstack(newState,z);
                state = newState;
            } else {                            // shift
                this.level++;
                ;
                int z = 0;
                if (this.currentToken == EOF){  // shifting the EOF: end of parse
                    ;
                    res = true;
                    break;
                }
                z = saveToken(action);          // eof cannot be encoded
                int newState = action & ParserLRTables.STATEMASK;
                pushLRstack(newState,z);
                state = newState;
                this.currentToken = tokenizer();
                if (this.currentToken < 0){
                    res = false;
                    break;
                }
            }
        }
        if ((FL_P & this.trc) != 0){
            Trc.out.printf("tree\n");
            traceTree(Trc.wrt,0);
        }
        if (!res){                            // not recognised
            if (this.currentToken <= EOF){    // a known token has been lexed
                this.lex.stream.cursor =      // point at the beginning of it
                    this.lex.stream.markPos;
            }
        }
        ;
        return res;
    }

    /**
     * Deliver the size of the stack used.
     *
     * @return     size in bytes
     */

    @Override
    protected int stackLength(){
        int[] data = new int[50];
        int n = 0;
        data[n++] = arraySize(this.gssNodeDir);
        data[n++] = arraySize(this.gssEdgeDir);
        data[n++] = arraySize(this.edgeshlink);
        data[n++] = arraySize(this.edgeshdata);
        data[n++] = arraySize(this.edgeshdir);
        data[n++] = arraySize(this.nodeshdir);
        data[n++] = arraySize(this.nodeshlink);
        data[n++] = arraySize(this.etrees);

        int res = 0;
        for (int i = 0; i < data.length; i++){
            res += data[i];
        }
        ;
        return res;
    }
}