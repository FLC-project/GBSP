/*
 * @(#)ParserLexGen.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;
import lbj.ParserLexer.*;
import lbj.ParserNode.*;
import lbj.ParserFA.*;

/**
 * The <code>ParserLexGen</code> class performs the generation of
 * the lexer tables.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

/*
 * Table compression
 *
 * Elements and holes (no-state values) are not uniformily distributed
 * in transition tables. Tables have a personality which can slim, fat,
 * sparse, dense, uniform or clotty.
 * There can even be 30% of the subtables which are identical. This is so
 * when the lexicon has keywords because at the end of all of them the
 * subtable of the last state is identical to that of identifiers since
 * from then on only an identifier can occur.
 * This occurs on states which have no transitions and on states which have
 * equal transitions, but have not been merged on minimization because,
 * e.g. one was final and the other not.
 * Subtables are on average sparse, and only a few of them are dense.
 * However, they are not very sparse: the number of values can be comparable
 * to that of holes.
 * Many subtables can contain one element only, which refers to another
 * subtatble which contains also one element.
 *
 * A lot of space in transition tables is taken by literal tokens, e.g.
 * keywords. E.g. the tables for the lexis of Pascal without literal tokens
 * are 3 times smaller than the ones which have them.
 * When a suitable optimizing lexer is not available, people tend not to
 * define keywords in the lexis, but recognise them when hashing identifiers.
 * The need to use less space to memorize transition tables arises mainly
 * when lexis have literal tokens. However, the techniques used apply to
 * all lexers in general.
 * It is undecidable if a GFG genarates a regular language. However, a CFG
 * which does not contain autoinclusions generates a regular language.
 * This is the way used here to validate the rules of the lexicon.
 * Moreover, if the grammar does not contain nonterminals like
 * <A> =*=> alfa <A> beta, with alfa beta not both empty, it generates a
 * finite language. However, it is difficult to figure out its cardinality.
 * Therefore we can restrict to consider nonterminals which have alternatives
 * which are all made of concatenations of terminals.
 * Such lexemes are here referred to as literal tokens.
 * When a lexicon has keywords and identifiers, i.e. tokens which overlap,
 * it has many final states since all the intermediate ones of the trie
 * of each keyword become final states at which an indentifier is recognised.
 * This means that there are many final states for identifiers.
 *
 * There are not many ways to reduce the tables sizes. The key point is in
 * in reducing the edges and/or the states and/or the character categories.
 *
 * Literal tokens table
 *
 * A solution is to keep an array which contains the literal tokens, and
 * match the text against it. The hub of this solution is in making the
 * matching fast, i.e. to find which, if any, string is present in the input.
 * There is a need to take into account that there are usually not many
 * strings, not very long, and with few common prefixes.
 * From one hand, matching the input against a set of strings is slower because
 * several tests have to be done in sequence. However, from another hand,
 * such tests are fast since they can be done in a short loop.
 * When matching, it is convenient to know if a keyword contains characters
 * which need a caseless matching or not. E.g. tokens which are punctuation
 * does not. For them a more efficient match can be done.
 * The lexemes which are specified to be case-insensitive are marked as such,
 * but the ones which do not contain case-variant characters have that mark
 * cleared. The marked ones are the lexemes which have a character that
 * belongs to a casefolding equivalence class which contains more than one
 * character. In the casefolding map there are also characters which are
 * mapped onto strings. However, those strings do contain at least one
 * character which belongs to an equivalence class with more than one element
 * (at least in Unicode 3.1), and thus the marking can be done in the same
 * way for all strings. In the literal tokens table, the literals are recorded
 * as mark, length, characters, token number and continuation state.
 * The handling of case-insensitivity leads to a little inefficiency: when
 * a lexicon does not have case-insensitive lexemes the test on the
 * case-insensitive mark is done for all literal lexems and the extraction
 * of the length (which is likely to be packed with the mark) as well.
 *
 * Some means exist to avoid to match sequentially all literals to find
 * a match. It is possible to jump from the initial state to one which
 * recognizes the keywords which begin with a same character. However, this
 * is better done with a dedicated transition table (which can be a vector
 * of indexes) so as not to enlarge the transition tables of all states.
 * E.g. if they are ordered according to the first character, and then
 * to the length, a table can point to the section containing the ones
 * with a same first character.
 * A vector can be kept which tells where the keys with a given start character
 * begin, but this needs something more to support case-insensitive matching.
 * If there are no case-insensitive lexemes, the trable can simply be ordered
 * by groups of lexemes with the same starting character, the longest first
 * in each group. If there are case-insentitive lexemes, the ordering is
 * more complex. See the section on case-insensive matching.
 *
 * To build the tables that drive the engine, first the automaton must be built
 * without the literal lexemes. Then it is run on each literal lexeme, and
 * and states at which it stops are recorded.
 * The (final) engine does not backup to the beginning of the text when it
 * matches literal tokens. Since we know that the engine would stop at a
 * given state when scanning a literal lexeme, that state is entered and
 * the normal processing resumed.
 * The literal lexemes which are prefixes of other lexemes have associated
 * the state to jump to. Note that there can also be literal lexemes which
 * have no state to jump to in that automaton, but have instead a final
 * state with no outgoing edges.
 * There is a need, when the state is defined, to remember that the set
 * of returned lexemes contains the literal one, and possibly other ones
 * which are the ones that the automaton would recognise at that state.
 * Note also that there is one of such sets for each literal lexeme, and
 * another one for each literal+identifier, i.e. another one when the
 * nextstate is defined, which is the union of the one of that state and the
 * literal lexeme(s).
 * To return the sets of recognised lexemes, we can remember the literal
 * one recognised and then make the union of the set containing it and
 * the set associated to that state in the automatom. However, the union
 * is not fast.
 * A solution can be to have two arrays of lexemes sets, and to keep
 * in the literals table the index of the lexeme. If it has been
 * reconised alone, the set in the first array is taken, otherwise
 * that from the second one.
 * There is also a need to know when such a state is no-state so as to
 * return immediately. This can be done by looking at the sets of lexemes,
 * or at the state.
 * Then there is a need to handle the case when a literal has been
 * recognized, and then a longer one also by running the automaton.
 * When the automaton recognizes a longer one, the literal should be
 * discarded, when it recognises a shorter one, only the literal must be
 * returned, and both only when they have the same length.
 * There is also a need for error reporting to remember the max advance
 * done in the input to set the cursor to it when nothing is recognised. 
 *
 * This solution requires an efficient caseless comparison because with
 * keywords represented in automa there is no penalty in supporting full
 * casefolding, while there can be with keywords represented as a lexemes
 * table.
 *
 * It could also be beneficial to put the lexical tokens table into the
 * transition tables so as to make easy to have one for each start state,
 * and be fast as well since it would avoid to have another reference to
 * keep in variables.
 * A test on the range of the first character can allow to reduce the
 * index table without decreasing speed since there is a test there anyway.
 *
 * The gain which is introduced by the literal tokens table is to spare
 * categories by making keywords not enter the game.
 *
 * These are the drawbacks of this technique:
 *
 *   - a lexer which has several starting states must have several lexemes
 *     tables, one for each state.
 *   - the performance might decrease when there are more than 100 keywords.
 *     With less than that, the speed decreases 14% with respect to the
 *     basic engine.
 *   - the engine becomes more complex, and it size increases (this,
 *     however is a fixed amount which does not depend on the size of
 *     the lexicon, and it is not a large piece of code anyway)
 *   - there is a need to carry on with the engine the casefolding map,
 *     which is 3..4 Kbytes long, which is not needed with other compression
 *     techniques that require to transform caseinsensitive literal tokens
 *     into rules which contain all case forms.
 *
 *
 * Necklaces
 *
 * The usual automata, in which edges are labelled with characters can be
 * enhanced by allowing strings on the edges. This may lead to a more efficient
 * lexer because it can process sequences of characters without performing
 * state transitions. The time the lexer spends to recognize two characters
 * individually is greater than that needed for a string of two characters,
 * and the space lower. However, measurements show that this is not the case
 * in general, except for the lexicons in which there are long terminal strings
 * with few common prefixes.
 * Strings on the edges can be dealt with directly when building NFAs.
 * However, transforming them into DFAs requires to break string edges at
 * least as much as needed to make deterministic transitions. Splitting
 * strings into normal, character edges, and compacting the resulting DFAs
 * is simpler because it allows to use the normal NFA to DFA transformation
 * and minimization.
 *
 * It is possible then to optimize automa which have single entry subtables.
 * The optimization is to represent the transition tables of states which
 * have only one outgoing edge in a special way and to collapse it with that
 * of the following states as long as they have one edge only (necklaces).
 * This allows to simplify the ones which recognise literal lexemes.
 * With a set of keywords the result is an initial state with its transition
 * table, a number of "string" (necklace) states, and the remaining part
 * of the automaton, in which states have transition tables which are
 * large as that of the initial state.
 * Since most states have 1..2 transitions only (after pruning), the
 * technique to record edges as sequences of symbols (with no holes)
 * obtains more or less the same compression as necklaces.
 * Instead of category values, it it possible to store also directly
 * characters, but then caseless keywords would not become necklaces.
 * Moreover, keeping two kinds of necklaces would complicate the engine
 * too much.
 * The pruning and building of necklaces could be done on automa which
 * have the characters on the edges, having then the categories computed
 * afterwards. However, there would be much less necklaces in
 * case-insensitive lexicons. Since categories should be used anyway to
 * handle ranges, then it is appropriate to use them here as well.
 * With categories computed before, most of the case-insensitiveness is
 * already handled by them.
 * Necklacing does not lead to have less categories since the ones which
 * are present before are also present in the necklaces. Necklacing is
 * only a more compact storage layout.
 *
 * To build necklaces, first the subtables which have one element only
 * are marked. Then the cyclic ones are marked also. Then each on each
 * subtable which one edge only the longest possible necklace is built,
 * and finally the subtables which have become unreacheable are removed.
 * When analyzing the graph (counting incoming arcs, cycles, etc.), fallback
 * tables are not taken into account since they are checked to be the same
 * on all states of a necklace, and make the matching of the symbols on a
 * necklace exit its dedicated loop and enter the general one.
 * Moreover, all subtables are visited, not skipping the shared ones because
 * each necklace is computed taking into account cycles, lexemes, which could
 * be different even when subtables are the same.
 * Adding states to a necklace stops when either there are no more or
 * a cyclic one is found. Consider the case of a necklace which would
 * close a loop not at the beginning of it, but at an intermediate state.
 * When the last transition would be made, there would be no state to
 * enter that could continue to match symbols as expected since that state
 * would have been gone in the middle of the necklace and then removed.
 * Therefore, necklaces stop at cycles. To do it, the cyclic necklaces
 * are marked first: each one is walked and the visited states marked;
 * when a marked state is found, walking stops and the necklace is marked
 * as cyclic if the state reached is the same as the first one. Marking
 * allows not to enter an endless loop when the cycle ends in the middle.
 * No attempt is done to collect partial necklaces, which would then be
 * difficult to check when joined to existing ones.
 * In so doing, cases like e.g. {a|b}c are expanded, but not the ones
 * like e.g. when there are lexemes with a common prefix such as "ab" and
 * "ac".
 * Note that necklaces break at junctions only, i.e. the grains which
 * have more than one incoming edge. If they would break at cyclic nodes,
 * then all nodes in a cycle would become distinct necklaces.
 * Strictly speaking, start states should have an incoming edge from the
 * outside. However, hardly influences the result of the algorithm because
 * another state cannot have an edge to a start state without either
 * being in a cycle with it (in which case necklacing would stop anyway),
 * or having the start state a loop onto itself, but also an edge to
 * that other state, which would make the input order of that start state
 * greater than one anyway.
 *
 * In a necklace the fallback states and the recognised lexemes must be
 * equal among all grains but the last.
 * The engine needs to know if it hast to save or not the position when
 * matching a necklace. In lexers with keywords and identifiers, the
 * majority of necklaces have all states final. Without identifiers they
 * have all states but the last non-final.
 * What is important is that the engine must know if it has to save or
 * not the position and the state, both when completing the necklace and
 * when falling back.
 * A simple rule is thus to make necklaces when all states but the last
 * one either final or non-final, i.e. have the same sets of recognised
 * lexemes. Final states remain final in necklaces.
 * Note that even if the engine handles the first state of necklaces
 * correctly independently on this rule since it tests its attributes
 * before entering necklaces, and for the same reason it handles properly
 * also the last one, it needs to know how to handle the intermediate
 * ones. This simple rule states that they must be equal to the first
 * one. As a consequence, "ab|abcd" generates 3 necklaces.
 * To allow to have necklaces with intermediate states with a final-ness
 * different from that of the first and last, there is a need to store
 * somewhere an attribute and also the lexemes set code. Note that in a
 * common lexicon in which there are keywords and identifiers, the initial
 * character of keywords is the one that from the initial state transits
 * to the (necklace) one that matches the remaining characters. There is
 * no chance to have all the characters of a keyword on a same necklace.
 * Therefore this further optimization would not help much anyway.
 * This condition allows to build necklaces by adding a grain at a time
 * or also by adding all of them at once.
 * When the engine scans completely a necklace, the following can occur:
 *
 *        all but last     last
 *
 *           non-final     non-final
 *           non-final     final         save last
 *           final         non-final     save first
 *           final         final         save last
 *
 * At the end sharing is computed again, in case of there were shared
 * necklaces.
 *
 * There is no benefit in having states which are at the same time looping
 * and necklaced states. On the contrary, it is a bit slower. A necklace of
 * one single grain which is also looping does not speed up (i.e. does not
 * exploit the fast access of categories wbich is provided by longer
 * necklaces). It saves memory, though, and thus it is convenient when
 * combing is not done.
 *
 * When a fallback subtable is accessed in the engine, that subtable
 * can be a necklace in turn, and thus its matching cycle would need be
 * excuted. This, however, is too complex.
 * Thus, on subtables which are fallback targes necklaces are build
 * with one element at most.
 * The origin subtable when fallsback on a table which has one element
 * only, and matches it, it then continues to the state present in it
 * exactly as that fallback table does by itself.
 * If autofallback is done, i.e. states which have no fallback are fallbacked
 * onto themselves, it is better to disable it on necklaces because that
 * requires to save the state before assigning it the fallback value so as
 * not to access it when they are the same. It is faster to test the presence
 * of a valid fallback in the necklaces loop.
 *
 * When transition tables are represented as char[][] arrays, necklaces
 * are stored as elements in them (i.e. as chars[]). A state attribute,
 * NECKLACE tells which subtable is a necklace. This requires extra 4+4
 * bytes for each necklace. Necklaces probably are not very long, which
 * means that they could occupy twice the number of symbols.
 * When a comb-vector is used, they can be stored in it. There is a need
 * to store the length also. This placement can be convenient if there are
 * holes in the merge table for necklaces, but if there are few, it could
 * require more memory. In the comb they need 4 bytes for each symbol and
 * 4 for the length (breaking necklaces longer than 64K symbols).
 * This placement leads to 5% memory saving, while placing them in a
 * dedicated table the saving increases to 10%.
 * In the latter case the stateBase would contain the offsets in the other
 * table (which must be filled it after merging, not during).
 * Necklaces in comb-vectors with relocated transitions dig well, but the
 * saving is not much: 4..6%. Using a dedicated table, the saving increases
 * to 10%. It would be even better for speed. The offset in it goes into
 * the comb-vector after the attributes and the fallback.
 * It is not convenient to speed up necklaces by using non-relocated
 * transitions because it would slow down the normal loop: necklaces
 * should improve speed by themselves, not by reducing that of others.
 * Even with lexicons with long lexemes, there is no much saving with
 * respect to the comb-vector: from 5% to 10%. Sometimes the higher savings
 * is obtained with necklaces in comb-vectors, sometimes out of them.
 * The reason why it does not lead to much saving in memory with respect
 * comb-vectors is that necklacing removes subtables which have only one
 * entry, that can fit well into comb-vectors.
 *
 * Necklaces do not speed up the engine, which turns up to have the same
 * speed as the basic one. This is because necklaces are not long: 2..3
 * symbols, which does not compensate the overhead to read the length,
 * and setup the index to scan them, and all the more, the overhead which
 * is introduced in all transitions. The result is that the engine does not
 * run faster when there are no necklaces.
 * The comb-vector is faster even if it requires an extra test and array
 * access to get the check values, and comparable in size (10% larger).
 *
 * To test the algorithm that builds necklaces, selfcheck is provided:
 * the transitions of the origin table are compared with the ones of the
 * transformed table. This is easily done for the subtables which have
 * not been necklaced since there is a need only to check that the values
 * are translated correctly.  For the states whose subtable have been
 * replaced by a necklaced one, the check is that the origin table contained
 * only one element, and that such element is the first of the necklace.
 * For the states which have been removed, the check is that the origin
 * table contained only one element, and in the places in all necklaces
 * in which that edge has gone, there is the same symbol.
 * Since is not simple to build an example with a loop on an intermediate
 * state of a necklace (because one of the states of the loop is normally
 * final, e.g. "a {bcd}+ e" would have "{bcd}+" ending in two edges),
 * dedicated tests with explicitly declared automa are provided.
 *
 *
 * Fallback subtables
 *
 * Compression, as described in the Dragon Book, provides the same saving
 * as other methods such as tunnelling (Rex), but in a simpler and more general
 * way since it transforms transition tables by looking at them alone.
 * Pruning is only meaningful if followed by compression, otherwise it slows
 * down the engine at not benefit.
 *
 * Pruning can lead to have states which are reached only by fallbacking.
 * E.g. let's have a state S0 which has a subtable with two entries S1 and S2,
 * and a state S2 whose subtable with an entry S2, not referred to from
 * any other state. S0 is fallbacked onto S2.
 *
 * Single characters in tokens rules break the ranges of characters in many
 * small intervals, which cannot be reduced by storing subtables in any
 * way. They can be reduced by using meta-categories.
 *
 * There is no need when falling back onto another state to carry on its
 * semantics (like e.g. to make the union of the sets of the lexemes
 * recognised in both states): instead of reading the values from the
 * subtable of one state we read them from that of another one, and the
 * nextstate is then identical to the one present in the original table.
 * This means that it is confined to the contents of subtables.
 *
 * Moreover, some dedicated tests ensure that a subsequent compression does not
 * decrease when any changes are introduced in the algorithm. This is useful
 * because the algorithm is rather sensitive.
 *
 * Fallback states in char[][] tables can be represented as dedicated tables.
 * If a unique, flat transition table is used, they can be placed at the
 * beginning of it. If a comb-vector is used, they be put at the beginning
 * (if non-relocated transitions are used), otherwise they can be attached
 * to subtables. This requires that stateBase maps subtables by taking this
 * into account.
 *
 *
 * Fallback behaviour
 *
 * The number of categories is determined by the number of symbols which
 * are on the edges. Ranges are single categories. Lexicons which have many
 * literal lexemes have many categories because all the characters of keywords
 * become categories. As a result, ranges of characters like, e.g. "letters",
 * or "all-but" are no longer represented by one category, but by a set made
 * of many categories (fragmentation).
 * This seems to defeat the whole purpose of categories: they have been
 * introduced to represent ranges. However, rules which mention individual
 * characters of such ranges fragment them. To reconstruct them there is
 * a need to have meta-categories, which are effectively sets of categories.
 * Note that it is not viable to avoid to fragment them in the first
 * place. We can represent sutables of states that have one edge for a
 * specific character and another for the remaining characters of a range
 * as a couple (character, nextstate) and one entry for the range, keeping
 * the range intact. However, this does not work with case-insensitive
 * lexemes, and also with the states of keywords which proceed after common
 * prefixes since they have more than two edges.
 *
 * Rules such as "all-but X to S0", with no catch-all rule, are not
 * pruned because none of them can act as fallback target.
 * Rules such as "all-but X to S0, X to S1", with no catch-all rule,
 * are pruned, but with two differences instead of 1.
 * They occur e.g. in strings and comments. Fallback subtables allow to
 * prune most tables in automa, but not all.
 * This is so because fallbacking mainly reduces the subtables of lexemes
 * which define text that it is either equal to them or it can match some
 * other rule, as keywords do with identifiers.
 * It prunes anyway subtables which are close one another. But, apart from
 * keywords and identifiers and complement languages, there are not many
 * other cases in which this occurs.
 * Fallbacking does not help to reduce subtables which came from edges
 * that contained ranges that need many categories because of fragmentation.
 * Tables in automa for complement languages are pruned with fallbacking
 * because the newly introduced catch-all state acts as fallback.
 * What remains after pruning are the fallback targets, which are rather
 * dense, and the other subtables which are dense and have not been
 * fallbacked because no viable targed existed. These could be reduced
 * by using meta-categories (see below), but that is not convenient.
 * Fallbacking is still one of the best (if not the best) techniques
 * for compression.
 * 
 * No technique is both fast and perfect: since it is too time consuming
 * to try all possible fallback combinations, some heuristic must be
 * used.
 * There are cases which cannot be pruned even with prior ordering.
 * E.g. the catch-all rule of identifiers is not always taken as fallback
 * target. When there are keywords and identifiers, the initial state
 * has edges for the starting letters of keywords to the states of
 * keywords, and for all other letters to the state of identifier.
 * However, the state of identifiers has also edges for digits, which are
 * not present in the initial state if the lexicon does not have numbers.
 * This means that the initial state has less entries than that of indentifiers,
 * and thus it will be used as target fallback instead of the other one.
 * However, some rules of keywords would not fallback on that of the initial
 * state since they are too much different from it (they have all entries
 * which are not no-state to the state of identifiers but one).
 * Another case is when there is no catch-all rule.
 * To help these cases, When there is a subtable which has all the values
 * equal but one, a subtable cab be built which has all the values equal
 * and used it as a fallback. 
 * However, this is not aways the best solution: it depends on the number of
 * subtables which can fallback on them and on the number of entries
 * which will then be removed. If only one or two tables will fallback
 * on such a table, it is likely that there is no gain.
 * This means that either a more extensive analysis is done on the tables,
 * or there will be cases in which this does not provide more compression.
 *
 * To compress the fallback targets, the columns which are equal in
 * in them can be compressed.
 * The tables which are target fallback of some others are likely to have
 * many repeated values. A meta-categories table maps categories into
 * meta-categories which are then used to access fallback tables.
 * Since fallback states are also normal states, whose tables are
 * accessed in the main loop of the engine. There is a need then to
 * flag them so as to know when the meta-categories table must be used.
 * In general, all states could use it: a map is convenient when there
 * are a number of states which have a number of equal columns.
 * The elements folded (number of equal columns - 1 times the number of
 * rows) must be more than the size of the map.
 * In the Pascal example, on 4 target fallback subtables, there are
 * 42 colums which are equal to some others. The saving would be
 * 168 - 46 = 122 entries = 244 bytes. It is not much. Same results
 * with and without necklaces and with or without sharing subtables.
 * With the Pascal lexicon, Flex generates 3776 bytes without meta
 * and 3368 with. I.e. 10% reduction. The engine slows down by 7%.
 * It does not pay off.
 * In order not to slow down the engine, it is possible to use
 * meta-categories only on fallback targets which are used as second-try:
 * they are not used on the subtables which are tried as the first choice.
 *
 * The usefulness of meta-categories is to compress the tables of
 * states which have many edges. This is the case of edges like:
 * all character but one, or all letters (when there are also other
 * edges with specific letter somewhere, which fragments categories).
 * The problem is how to implement them efficiently. It is possible to
 * make use of them only in fallback subtables since pruned subtables
 * are already light. All the more, they should be used only on the
 * subset of fallback subtables which are dense. However, to avoid to
 * translate categories always (under condition), fallback subtables
 * must never be referred to from other subtables, except as fallback.
 *
 * An alternative is to use default transitions: on the subtables which
 * have no fallback and have many entries equal, those entries are stored
 * as default transitions. However, they are less powerful than
 * meta-categories since they apply only to the subtables which are full
 * because there is non way to tell holes from defaulted entries.
 * Note that part of the information attached to subtables is their
 * pattern of holes/elements, and part is the actual values of elements.
 * When finding fallbacks we search subtables which are good matches
 * both as pattern and as values. Any compression mechanism must be able
 * to reconstruct both patterns and values.
 * A subtable which has no-state values and also many equal values cannot
 * be defaulted simply by storing the default value and replacing entries
 * equal to it with no-state because there would be no means to distinguish
 * holes which were originally holes from the ones which have been defaulted.
 * When digging, it could be possible to reserve a value as denotation
 * for "default", meaning that such slot belongs to all tables which
 * overlay it, digging then tables in places where the values fit into
 * holes or default values overlay slots containing the default denotation.
 * This would mean in the engine:
 *
 *       if ((char)(elem = tabMerged[state+cat]) != state){
 *           if (elem != DEFAULT) break;
 *           elem = tabMerged[state-1];
 *
 * This is not convenient in practice because subtables do not dig well:
 * in the Pascal lexicon, the result is a merged table larger than the
 * original by 5%.
 * To save space they can be stored as fallback value, and an attribute
 * mark states which have them:
 *
 *      if (check != expected){
 *          if (attrs > DEFAULT) state = ... ; break;
 *          state = fallback;
 *          if (check != expected){
 *              if (attrs > DEFAULT) state = ... ; break;
 *
 * Default transitions are simple when applied to subtables whose pattern
 * is known to be full. Automa have subtables which are full when
 * recognizing complement languages.
 * Default transitions alone do not perform better than fallback.
 *
 *
 * Comb-vectors
 *
 * They have been introduced by S.C. Johnson.
 * They allow to compress sparse tables. If the ratio between elements
 * and holes is greater than 1/2 there is no compression.
 * Comb-vectors are mainly used after pruning. After pruning, the subtables
 * have holes, more holes than before.
 * When a subtable is accessed at an index, and a hole found, the fallback
 * one must be examined. What is important is that all holes (entries in
 * subtables which contain the no-state value) in subtables are layed over
 * elements in the comb-vector which have check values different from the
 * expected ones of subtables. Since when digging a subtable, only the
 * entries which are different from no-state are copied, the ones which
 * correspond to holes are left unchanged in the comb-vector, and if never
 * written (because no subtable place an entry on them), their contents
 * remain zero. Since zero is different from the check value of any subtable,
 * they are effectively holes. This means that it is sufficient in the engine
 * to test: "if (check != expected) fallback" because when "check == expected",
 * the value is never no-state.
 * Note that if this did not hold, then there would be a need for a second
 * test to fallback when the check value is the expected one and the value
 * is no-state.
 *
 * Comb-vectors represented as char[] need either a dedicated table for the
 * check values or need to shift the category used to index them if each
 * check+nextstate pairs are stored in pairs of positions.
 * With two parallel char[] arrays for the nextstate and check values there
 * is a loss of speed from 2% to 10% with respect of using a unique int[] array.
 * This is due to the fact that two array accesses are done instead of one.
 * Testing the check value is faster if it is in the least significant byte
 * of int elements because a cast can be used to mask the remaining bits,
 * which is faster than an AND. However, there is then a need to make a
 * shift to get the state, and also one to get the attributes. The latter can
 * be avoided.
 *
 *
 * Compressed transition tables
 *
 * Non-compressed transition tables are stored as char[][]. This contains the
 * references to the subtables and also a class pointer for each subtable.
 * To spare the class pointers, all subtables can be stored in a same array
 * and theis offsets into another table (which allows to have large tables)
 * or in the same (which allows smaller tables). In the former case there
 * is a need to keep the reference to the offset table into another variable
 * in lex(). The measurements tell that this is slower.
 *
 * There are several means to store transitions when a unique table is used:
 *
 *    - state numbers: to get the index, a base table is needed
 *    - state bases (relocated transitions)
 *    - state bases displacements (relative transitions).
 *
 * If the table is a comb-vector, then bases can be indexes into an int[]
 * or pair of char[] arrays (or in C, arrays of struct (check, next), and
 * displacements can be the numbers of such structs to offset from the
 * address of the current state (the machine multiplies that number by the
 * struct size and then adds it to the address of the current state), which
 * allows to displace 256 Kbytes up or down, and avoid to use a base table
 * or assigning to the state variable the sum of two values since it adds a
 * value to it).
 * In languages which allow to get pointers to elements of arrays, it is
 * possible to store the addresses instead of bases, which achieves the
 * fastest transitions. The next in speed is to store offsets in a flat
 * table. In java it is not possible to store pointers to elements of arrays,
 * and therefore offsets are stored.
 * Displacements have the same restrictions as bases since from the initial
 * state there is a need to transit to a number of states which can be quite
 * further down.
 *
 *
 * Relocated transitions
 *
 * All layouts which represent next states as indexes, bases, offsets, etc.
 * into other subtables prevents subtable sharing.
 * Sharing saves memory: there are many final states for which all edges
 * are no-state that provide little saving, but there are many others which
 * have many elements. However, with pruning such subtables becomes full of
 * no-state values, and thus the capability to share subtables is not
 * important.
 * With relocated transitions there is a need to duplicate the subtables
 * which are shared among states some of which are special and some not. 
 *
 * In comb-vectors, there is then a need to store the attributes, the
 * fallback, and the lexemes set code attached to subtables.
 * Any values in the merge table need be stored in the same way, i.e. as a
 * check+value entry. This means that there are the check values for the
 * attributes, etc., which were not present before, but the stateBase is no
 * longer needed. In the subtables the state offsets are stored.
 * Measurements show that these subtables (even without sharing) dig well:
 * the result is a comb-vector whose size is very close to the one for
 * non-relocated transitions (in the Pascal case, there is even a 1% saving).
 *
 * When building comb-vectors, there is also a need not to overwrite the
 * slots which contain the attributes and fallback, which can happen if
 * they are dig as they are since they can be also zero. A solution is to
 * store a non-zero value and then eventually put the actual one. Zero values
 * in merged tables are either stored as holes, in which case there is a need
 * to test the check values to know that they originally were zero values,
 * of they must be replaced by some non-zero value and eventually restored as
 * zero.
 * Since state values are state offsets, no table can have a state offset
 * of 0, which is always the case since they point to the beginning of the
 * transitions in subtables and each subtable is preceded by its attributes
 * and fallback.
 * There is also a need not to place two subtables at the same offset because
 * otherwise ambiguities would occur. This is always the case since all
 * subtables are preceded by two values (i.e. non-holes).
 *
 * With relocated transitions it is not possible to reorder states so as to
 * make the special ones have a number (or offset) greater than a given value.
 * This is possible with non-relocated transitions. However, speed does not
 * improve because most states are special. Because of this, the result is
 * slower engines. Enclosing the handling of special states in a conditional
 * statement so as to skip it when states are not special provides 5% speedup.
 *
 * Relocated transitions in comb-vector provide a speed which is a little bit
 * better than the the basic one, and 5% better than non-relocated transitions.
 * Relocated transitions in a unique table (not a comb-vector) provide 10%
 * speed more than non-relocated transitions.
 *
 * Automata with relocated transitions can be traced by indicating states
 * as state numbers or state offsets. In the former case, if the STATE_NUMBERS
 * mode is enabled, the stateBase is retained and the state numbers are
 * printed, otherwise the state offsets are printed (which is the default).
 * State offsets allow to interpret the tracing produced by lex(). 
 * To trace automa which do not have a stateBase, stateBase is rebuilt by
 * traversing the tables so as to visit them more easily.
 *
 * Relocated transitions in comb-vector tables are stored by representing
 * the subtable of each state as follows, having state values as the offset
 * of the beginning of the next states part:
 *
 *          -2 attributes (3 bits), tokens set code
 *             (13 bits = 8K tokens sets), check value
 *          -1 relocated fallback (16 bits), check value
 *  state--->0 relocated next states (16 bits), check value
 *
 * The maximum size of the transition tables is 256 Kbytes, which is not small
 * in practice.
 * The engine detects special states by testing their value to be lower than
 * zero: looping and final states have the higher bit set (SPECIAL).
 * This allows to skip the treatment of special states in a fast way on all
 * states which are not special. The engine shifts the tokens set code only
 * at the end.
 * Since a non-zero tokens set code is present only in final states,
 * final states are denoted by a non-zero value in that field.
 *
 *
 * Balance
 *
 * In the majority of cases comb-vector is much smaller than basic tables,
 * and in few it is comparable.
 * It is not possible to have a unique engine which treats optionally
 * pruning and merging at the same time and be efficient.
 * After pruning, if the density is not lower than, e.g. 0.3 comb-vector
 * compression should not be attempted, and when it is, the compressed
 * tables ought to be discarded if not smaller.
 * However, there would be a need to keep two engines, with different names.
 * Thus, only one engine is kept. A basic one is also kept for testing
 * because it is fast and it accepts the tables which serve then to compress.
 * The engine for comb-vector tables is only 3% slower.
 * This is acceptable since the cases in which there is no gain are
 * small lexicons, and the loss of speed is small.
 * Necklaces are not used because they do not pay off.
 * Comparison is done with respect to the basic engine (which supports
 * looping states also) which is both simple and fast. It is not the
 * fastest, which is the one that has also relocated transitions (but it
 * is not much faster).
 * Comparison:
 *                              memory saving   speed reduction
 *     string table:                70%              14%
 *     necklaces+fallback+comb:     69%              12%
 *     fallback+comb:               66%               3%
 *     handwritten:                 --               42%
 *
 * This means that the memory saving of all methods are similar, but
 * the fallback+comb is the fastest, and thus it is better than the others.
 * The fastest is the basic automa with unique tables with relocated
 * transitions, but they are only 1.3% faster than the fallback+comb.
 * With respect to Flex -Ce: fallback+comb: 7.7% less memory, 37% slower.
 * The handwritten one is considerably slower because it may not implement
 * all the optimizations since it needs to be readable. E.g. it scans
 * keywords as identifiers and then searches them in a table.
 *
 * Fallback+comb is simple, at the cost of requiring some generation time,
 * which is negligible in normal cases, in comparing subtables against
 * subtables.
 * It keeps linear the scanning time however large be the number of literal
 * tokens, which is not true with the string table method.
 *
 *
 * Cell sharing
 *
 * Another compression algorithm is to slice the transition table in cells
 * and to record them only once. The subtables for the states would become
 * arrays of references to pieces. There is a need to find out what is the
 * appropriate granularity so as to maximize the cells which are identical.
 * One alternative is to build a hash table and store in it halves of transition
 * subtables and then check how many are identical. Then the same can be done
 * with quarters and then with eights. Of course, a limit will be found when
 * it no longer pays off. A reference takes 4 bytes, and thus, if the size of
 * those tables is S, when the pieces are S/2 we would have references occupy
 * as much as S. When pieces are S/4, the references occupy S/2 and there at
 * least half of the pieces should be duplicated not to loose.
 * At best we will save half the space, which is not much. I would think that
 * we should stop at S/8 looking for gain.
 * Note that this technique alone does not allow to reduce states since that
 * is possible only once the keywords have been simplified reducing them to
 * necklaces (which requires fallback since then they will be made by
 * sequences of states all with the same fallback).
 * Measurements show that cell sharing at most it halves the size, and thus
 * this technique is not attractive.
 *
 *
 * Final states merging
 *
 * The minimization algorithm does not factor out the tails of the subgraphs
 * that recognizes the lexemes. This is because final states for differing
 * lexemes are put in distinct partitions. The resulting graphs spreads
 * like a tree from the initial state. This is done to make the engine stop
 * at a different state for each lexeme (more precisely, to traverse a
 * different final state for each lexeme and remember it).
 * An automaton which does not return the kind of lexeme, and thus is a
 * simple recognizer, factors out the tails. In the case of Pascal, it
 * occupies 30% less.
 * It is not sufficient to attach to states the lexemes under recognizion
 * so as to allow this factoring out. Consider e.g. the example of two
 * lexemes which have a different initial character and a common tail,
 * like e.g. "acd" and "bcd". The automaton would have two branches from
 * the initial state to a state that recognizes "cd". To tell at the end
 * which lexeme has been recognised there is a need to remember which
 * initial transition had been done. I.e. some data must be attached to
 * edges. The same happens e.g. if the last character is the one different.
 * Data attached to transitions takes memory, to the point that it would
 * hardly pay off. The final result very likely is not a big saving (if a
 * saving at all) and slows down the engine.
 *
 *
 * Multiple category tables
 *
 * A special category table could be used for the start state. It could
 * allow to compress better since in general there are many symbols in the
 * initial state, but not many in the other ones. This could be the case
 * when necklaces are used and contain characters instead of categories.
 * However, without this, the other states taken all together have many edges
 * and on them there are many symbols. This means that the size of their
 * subtables is not likely to be shorter than that of the initial state.
 * Moreover, with comb-compression is the number of elements present in
 * each table what matters instead of its absolute size.

- why then not test whether there is a rule which matches keywords (and
  if there is none, introduce it), let it match them and then add an
  almost perfect hashing to check them? Well, hashing should slow down
  the engine. Moreover, lexical tokens which are not catched by such
  a rule would need another rule, which is not so simple to figure out.
- probably perfect hashing is not much different from the literal tokens
  table: with hashing we can test if a string belongs to a set. What we
  need here is to determine where the string ends. The problem is not
  much different from the substring search of Aho and Corasick. However,
  I do not know if there is an efficient implementation since a trie is
  just a normal automaton. Probably hashing can be computed while making
  transitions, and when stopping checked with the known hash values.
  This would be convenient if it is possible then to avoid compressing
  tables so as to compensate the loss of speed. Well, a perfect hashing
  would mean that it is possible to perform the same work as an automa
  does by calculating a value ... I guess that the hash function will
  eventually take the same time/space as the automaton.

- why I do not support decomposition forms? There is even a third case
  of folding which it that of ligatures, or precomposed characters which
  are the union of more characters (not diacritical marks). There are
  cases in which the user needs to equate them and cases in which it must
  not (e.g. when building a typesetting program).
  Keep into account that the support of decomposition forms could change
  the picture: they could increase transition table size, but probably
  not (or not much) time, but they might increase matching of keywords
  represented as strings.
  Decomposition forms could require to generate all the permutations of
  the forms, but only on characters which have them, like e.g. accented
  vowels. If it is like that, it might even be convenient to have a
  special reader which transforms the input in its canonical form.
  Supporting canonical equivalence is something more complex than caseless
  matching.

- a possible way to speed up recognizion is to exploit some statistical
  properties of the text. E.g. if we keep a cache of the most frequent
  three-characters prefixes encountered so far, then probably that could
  be used to make a first, fast check, and get to the state reached
  after that quickly (on average). This would cater for whitespace,
  frequent keywords and symbols, etc.
  After having matched the text against the chache, if a match is found,
  the nextstate in the cache match is used as start state.
  If no match occurs (including when there are no characters), then
  the normal processing is done.
   .. try the cache
 *
 * In the automata engine it is possible to cache the last transition, i.e.
 * the next state together with the origin state and category, and make a
 * test when the next character is processed so as to avoid to access the
 * transition table when they are the same as before. This, however, does
 * not speed up the engine.
 *
 * Subgraphs
 *
 * Common parts in an automaton can be factored out, and transiton tables
 * then reduced. E.g. <comments> can occur in any lexeme. It is like a
 * subgraph. This, however, is not a good example since it could be factored
 * out by automa minimization.
 * Since this requires at least one or two states for each subgraph call, it is
 * convenient if a subgraph contains at least 3 states. It may be useful to
 * keep a usage count of nonterminal rules to determine which ones can became
 * subgraphs.
 * The minimization algorithm factors out the common heads of the graphs
 * of the lexemes, and not the intermediate parts or the tails.
 * Subgraphs can be implemented as calls to the lexer. States have an
 * attribute that tells that a subgraph needs to be called.
 * Alternatively, special transitions can be used. This can be better because
 * transitions already have a next state associated.
 * This problem is similar to that of calling the lexer on subsets of lexemes.
 * There is a need for a stack: when a "call subgraph" state is encountered,
 * the next state is stacked, and upon termination of the automaton subgraph,
 * the state is recovered.
 * Multiple occurrences of a same subgraph are not reduced to one by
 * compression or sharing since they are equal in shape only, but not in
 * the actual values contained in their subtables. Storing them once means
 * exactly folding them at the cost of making the edges to the outside become
 * "dynamic", i.e. be computed at runtime.
 * Subgraphs seems not simple to implement, expecially for the identification
 * of what pieces of a graph can become subgraphs.
 * A means to detect subgraphs could be to store pieces of token rules in some
 * dictionary so as to recognize multiple occurrences of them in the lexicon.
 * However, it is not simple to detect the repetition of e.g. a concatenation
 * of three terminal strings since they can even occur in the middle of others.
 * Moreover, since elements can have common heads, the resulting DFA might
 * eventually not have a common subgraph there.
 * All the more, we do not know if common and sufficiently large pieces of
 * graphs occur in practice enough to pay off. It is likely that they could
 * occur when using lexers as pattern matchers to detect selected pieces
 * of text in large texts since in that case there could be patterns which
 * are similar to each other.
 * Therefore this optimization seems not promising and thus it is not
 * implemented.
 *
 *
 * Looping states
 *
 * There is a means to optimize sequences of characters of the same category,
 * like {a|..|z}*. The lexer remains in the same state until one character which
 * does not belong to the category is found.
 * It spares some tests on the state, and the statements to make a transition.
 * A looping state is one which has edges to itself, and possibly other
 * outgoing ones. There is a need to check at the end of the loop if the
 * state was final.
 *
 * There can be several edges for several categories which lead a state
 * to loop. This is due to the fact that categories are the minimal subsets of
 * characters with the same behaviour among all states. E.g. when a {a|..|z}*
 * is present and also a {a|..|k}*.
 * To determine that a state is looping, an attribute is kept.
 *
 * The cursor and the state in final looping states is recorded only once
 * at the end of their dedicated loop.
 *
 * There are different degrees of looping states: loop on a same character, a
 * same category, and a same category set. The ones on a same category do
 * not speed up the engine, and the ones on a same character would be of
 * some use only in few cases (not even when skipping whitespace, which is
 * made not only by spaces). The character or category could be appended to
 * the subtable of the state (providing that various algorithms do make a
 * distinction on where to use tab.length vs numOfSymbs). This, however,
 * is not done since it provides no benefits.
 * When the category of the current character is equal to that of the previous
 * one, looping can be done immediately. However, this bears no gain: the
 * time spent in saving and testing is equal to that gained.
 * Also the disabling of pruning on looping states does not lead to any
 * improvement. It leads to a loss of space of 3% and an increase in speed
 * of 0.1%. This is because the majority of looping states have no fallback.
 * A state becomes looping independently of being pruned. The edge which makes
 * a state loop onto itself can also be in its fallback table. The transition
 * to the next state is thus computed by fallback if needed.
 * The use of meta-categories does not provide any benefits too.
 * It would spare the access to the subtable, but introduce that to another
 * one. In effect, the transition subtable plays there the same role
 * because it allows to determine which categories belong to the set of
 * the ones to loop on.
 *
 * Comments are a good case of looping states because they are long, and
 * therefore processing them fast speeds up lexing.
ok... lex looping states: measure performance because I am not sure that it pays off
    It makes no difference as it is implemented currently
 */

class ParserLexGen {

    /** The lexer object for error reporting. */
    private ParserLexer lex;

    /** The reference to the generated NFA. */
    ParserFA nfa;

    /** The reference to the corresponding DFA. */
    ParserFA dfa;

    /** The reference to the generated (encoded) automa. */
    ParserTables aut;

    /** The trace flags. */
    int trc;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    c   FA encoding main actions
     *    g   main actions
     *    h   details
     *    n   FA encoding details
     * </pre></blockquote><p>
     */

    static final int FL_C = 1 << ('c'-0x60);
    static final int FL_G = 1 << ('g'-0x60);
    static final int FL_H = 1 << ('h'-0x60);
    static final int FL_N = 1 << ('n'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Check that all the tokens are regular and then generate the
     * lexer tables.
     *
     * @param      gram reference to the grammar object
     */

    /* The storage for the NFA is released after having transformed it
     * into a DFA, and the latter after having encoded it.
     * For testing, such storage could be retained.
     *
     * A ParserFA is created to hold the NFA, then another one to hold
     * the DFA, and then the former deleted (unless otherwise specified,
     * which it useful for testing), and finally a ParserTables is created
     * and the DFA deleted.
     */

    public void genLexer(ParserGrammar gram){
        this.lex = gram.lex;
        this.nfa = new ParserFA(gram,this.trc,
            null,null);
        this.nfa.buildNfa();                    // build the NFA
        if ((FL_G & this.trc) != 0){
            Trc.out.println("-----NFA-----");
//            this.nfa.trace(true,true,false,Trc.out);
            this.nfa.trace(true,true,false);
        }
        if (this.nfa.sthead == null) return;    // empty

        if ((this.lex.fatcnt == 0) &&           // no fatals
            (this.lex.errcnt == 0)){            // no errors
            this.dfa = this.nfa.buildDfa();     // turn it into a DFA
            if ((FL_G & this.trc) != 0){
                Trc.out.println("-----DFA-----");
//                this.dfa.trace(true,true,false,Trc.out);
                this.dfa.trace(true,true,false);
            }
            if ((RETAIN_FA & this.mode) == 0){  // free nfa memory
                this.nfa = null;
            }
            this.dfa.minimizeDfa();             // reduce it
            if ((FL_G & this.trc) != 0){
                Trc.out.println("----- minimized DFA-----");
//                this.dfa.trace(true,true,false,Trc.out);
//                this.dfa.trace(true,true,false);
                this.dfa.trace(false,true,false);
            }
            buildCat();                         // build the categories
            genTables();                        // generate runtime tables
        }
        if ((RETAIN_FA & this.mode) == 0){      // free memory
            this.nfa = null;
            this.dfa = null;
        }
    }

    /** The table of character categories. */
    IntSet[] catTable;

    /**
     * Build the character categories.
     * The category of the symbols which are not mentioned in any transition
     * (if any) is assigned the value zero.
     */

    /* Basically, all sets of characters present in the edges are taken
     * and intersected so as to determine the largest pieces which behave
     * the same in all states (i.e. lead to the same next states):
     *
     *    for each set (i.e. all transitions){
     *        take current set
     *        scan category table{
     *            if element = current continue
     *            if they do not intersect continue
     *            split
     *        }
     *    }
     *    for each set (i.e. all transitions){
     *        take current set
     *        scan category table{
     *            take category number, generate transition
     *        }
     *    }
     */

// keep the
// sets ordered by lower element, and keep also the higher so as to restict
// the number of set intersection comparisons

    void buildCat(){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("--- buildCat init ---");
        }

        IntSet complement = new IntSet(Character.MIN_VALUE,
            Character.MAX_VALUE);
//[LOWER(lex_sym_t):UPPER(lex_sym_t)];

        Set<IntSet> tempSet = new HashSet<IntSet>();
        Set<IntSet> catSet = new HashSet<IntSet>();

        IntSet curSet = new IntSet();
        IntSet inter = new IntSet();
        int catNr = 0;
        for (ParserState h = this.dfa.sthead;
            h != null; h = h.next){                // scan all states
            if ((FL_H & this.trc) != 0){
                Trc.out.println("build_cat state: " + h +
                    " edge list ");
                Str st = new Str();
                ParserFA.transToString(h.transList,true,st);
                Trc.out.println(st);
            }
            for (ParserTrans ts = h.transList;     // scan transitions
                ts != null; ts = ts.next){
                curSet.assign(ts.set);
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("set " + curSet.toString(true));
                }
                complement.sub(curSet);            // update complement
                tempSet.clear();
                Iterator iter = catSet.iterator();
                while (iter.hasNext()){
                    IntSet elem = (IntSet)(iter.next());
                    if (curSet.isEmpty()) break;
                    if (curSet.equals(elem)){           // already there
                        curSet.clear();
                        break;
                    }
                    inter.assign(elem);
                    inter.and(curSet);
                    if (inter.isEmpty()){
                        continue;                       // no overlap
                    }
                    if (!inter.equals(elem)){           // not a superset
                        if ((FL_H & this.trc) != 0){
                            Trc.out.println("inter el " +
                                elem.toString(true));
                        }
                        elem.sub(inter);                // remove common symbols
                        if ((FL_H & this.trc) != 0){
                            Trc.out.println("split old " +
                                elem.toString(true));
                            Trc.out.println("split new " +
                                inter.toString(true));
                        }
                        tempSet.add(new IntSet(inter)); // insert in temporary
                    }
                    curSet.sub(inter);
                    if ((FL_H & this.trc) != 0){
                        Trc.out.println("new current " +
                            curSet.toString(true));
                    }
                }
                if (!curSet.isEmpty()){                 // add to list
                    tempSet.add(new IntSet(curSet));    // insert in temporary
                    if ((FL_H & this.trc) != 0){
                        Trc.out.println("add " +
                            curSet.toString(true));
                    }
                }
                if (!tempSet.isEmpty()){
                    catSet.addAll(tempSet);
                }
            }
            if ((FL_H & this.trc) != 0){
                Trc.out.println("buildCat end state: " + h);
            }
        }
        if (!complement.isEmpty()){             // assign a category to the remaining
            catSet.add(new IntSet(-1,-1));      // placeholder for it, lowest
        }

        this.catTable = new IntSet[catSet.size()];
        catSet.toArray(this.catTable);
        Arrays.sort(this.catTable);
        if (!complement.isEmpty()){             // category for all unspecified
            this.catTable[0] = complement;      // .. symbols always zero
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("build_cat done: ");
//            traceCatTab(Trc.out);
            traceCatTab(Trc.wrt);
        }
    }

    /**
     * Trace the category table.
     *
     * @param      trc trace stream
     */

//    void traceCatTab(PrintStream trc){
    void traceCatTab(PrintWriter trc){
        for (int i = 0; i < this.catTable.length; i++){
            trc.println(i + ": " + this.catTable[i].toString(true));
        }
    }

    /**
     * Generate the category map.
     *
     * @param      tab reference to the category table
     * @return     size of the generated table
     */

    /* Compression of the category table into a map: each category is
     * taken, and the ranges in it visited. Subranges in them which denote
     * blocks of equal values and of 2** boundaries are compressed into
     * a single block.  This works because there is little chance that
     * a same block of equal values be due to several ranges.
     * When only the subtable for the first 256 characters has some non-zero
     * values and all the other ones refer to a subtable full of zero
     * values, the top-level directory and the zeroes subtable are discarded.
     */

    void genCatMap(IntSet[] tab){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("genCategories");
        }
        int blkBits = ParserTables.CAT_BLK_BITS;
        int size = 1 << blkBits;
        int mask = size - 1;
        int dir = 16 - blkBits;                     // 2**dir = size of dir
        this.aut.catMap = new char[1 << dir][];     // allocate table
        char[][] table = this.aut.catMap;

        int[] ranges = new int[20];
        for (int i = 0; i < tab.length; i++){       // scan the table
            int nr = tab[i].toRanges(null);         // get the ranges of
            if (ranges.length < nr){                // .. this set
                ranges = new int[nr];
            }
            tab[i].toRanges(ranges);
            for (int j = 0; j < nr; j += 2){
                int lo = ranges[j];                 // current range
                int up = ranges[j+1];
                boolean full = false;
                while (lo <= up){                   // create blocks
                    int loBlock = lo >> blkBits;    // block numbers
                    int loOff = lo & mask;          // .. and offsets in them
                    int upBlock = up >> blkBits;
                    int upOff = up & mask;
                    if ((FL_H & this.trc) != 0){
                        Trc.out.println("from " + lo +
                            "(" + loBlock + "," + loOff + ") to "
                            + up + "(" + upBlock + "," + upOff + ")");
                    }

                    int max = size-1;               // subrange that is in
                    if ((upBlock == loBlock) &&     // .. this block
                        (upOff < max)){
                        max = upOff;
                    }
                    if ((loOff == 0) && (max == size-1)       // this block full
                        && full){                             // .. and previous
                        table[loBlock] = table[loBlock-1];    // .. also
                        if ((FL_H & this.trc) != 0){
                            Trc.out.println("to previous");
                        }
                    } else {
                        if (table[loBlock] == null){          // not yet present
                            table[loBlock] = new char[size];  // allocate it
                            if ((FL_H & this.trc) != 0){
                                Trc.out.println("allocated");
                            }
                        }
                        for (int k = loOff; k <= max; k++){
                            table[loBlock][k] = (char)i;
                        }
                        if ((loOff == 0) && (max == size-1)){ // full block
                            full = true;
                        }
                    }
                    lo = (lo | mask) + 1;         // first of next block
                }
            }
        }
        boolean onepage = true;                   // number of tables
        for (int i = 0; i < table.length; i++){
            compr: {
                for (int j = 0; j < i; j++){
                    if (table[i] == table[j]) break compr;
                    if (Arrays.equals(table[i],table[j])){
                        table[j] = table[i];
                        if ((FL_H & this.trc) != 0){
                            Trc.out.println("reduced: " + j + " to " + i);
                        }
                        break compr;
                    }
                }
                if (!onepage) continue;           // already more than one
                if (i == 0) continue;             // check pages > 0
                char[] page = table[i];           // .. non-shared
                for (int j = 0; j < page.length; j++){
                    if (page[j] != 0){
                        onepage = false;
                        break;
                    }
                }
            }
        }
        this.aut.catMap0 = table[0];
        if (onepage){                             // discard directory
            this.aut.catMap = null;               // .. and empty pages
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("genCategories done, onepage: " + onepage);
//            this.aut.traceCatMap(Trc.out);
            this.aut.traceCatMap(Trc.wrt);
        }
    }

    /**
     * Generate the encoded tables for the automa and the categories.
     * By default it generates fallback relocated and comb-vector
     * compressed transition tables.
     */

    void genTables(){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("genTables");
        }

        if (((BASIC_TABLE | FALLBACK_TABLE |
            COMB_TABLE) & this.mode) == 0){
            this.mode |= FALLBACK_TABLE | COMB_TABLE | RELOCATED;
        }

        if (this.aut == null){                  // is null in testing
            this.aut = new ParserTables();
            this.aut.trc = this.trc;
        }
        genCatMap(this.catTable);               // generate category map

        int sn = 0;
        for (ParserState h = this.dfa.sthead;   // determine max state nr
            h != null; h = h.next){             // .. renumbering states
// is this possible? are there state numbers stored in some sets?
            h.num = sn++;
        }
        sn++;                                   // 0 = no state
        if (sn > Character.MAX_VALUE){          // too many states
            this.lex.message(ParserLexer.ERR_EXCLEX,
                null,ParserLexer.MSG_AT_EOF);
            throw this.lex.excObj;
        }

        ParserState[] equiv = new ParserState[sn];
        if ((RELOCATED & this.mode) == 0){
            red: for (ParserState h = this.dfa.sthead;  // fold equal transition
                h != null; h = h.next){                 // .. tables
                ParserTrans th = h.transList;
                cmp: for (ParserState s = this.dfa.sthead;
                    s != h ; s = s.next){
                    ParserTrans ts = s.transList;       // compare transitions
                    for (; (th != null) && (ts != null);
                        th = th.next, ts = ts.next){
                        if (th.set != ts.set) continue cmp;
                        if (th.nextState != ts.nextState) continue cmp;
                    }
                    if (th != ts) continue cmp;
                    equiv[h.num] = s;               // equal
                    if ((FL_G & this.trc) != 0){
                        Trc.out.println("folded: " + s + " to: " + h);
                    }
                    continue red;
                }
            }
        }

        this.aut.transTable = new char[sn][];

        this.aut.stateAttrs = new int[sn];
        if (this.dfa.sthead != null){               // store initial state
            this.aut.initialState =
                (char)(this.dfa.sthead.num + 1);
        }
        this.aut.numOfStates = sn;
        this.aut.numOfSymbs = this.catTable.length;
//Trc.out.println("cats " + this.aut.numOfSymbs);
//Trc.out.println("states " + sn);

        int tranSize = this.catTable.length;     // size of the table of a state
        IntSet inter = new IntSet();
        IntSet cur = new IntSet();
        for (ParserState h = this.dfa.sthead;    // fill transition table
            h != null; h = h.next){
//                tok_code = 0;
//                if (h.lexset != null){         // token code of first lexeme
//                    tok_code = h.lexset.lptr.tokNum;
//                }
//                looping = false;
//                save = false;
            if (equiv[h.num] != null){            // table shared
                this.aut.transTable[h.num+1] =
                    this.aut.transTable[equiv[h.num].num+1];
//Trc.out.println("reduced " + this.aut.transTable[h.num].length);
                continue;
            }
            this.aut.transTable[h.num+1] =            // allocate table for state
                new char[tranSize];
            for (ParserTrans t = h.transList;
                t != null; t = t.next){
                int nextState = t.nextState.num + 1;  // nr of next state
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("edges: " + t);
                }
                cur.assign(t.set);
                for (int i = 0;                       // find categories which
                    i < this.catTable.length; i++){   // .. make up the set
                    inter.assign(this.catTable[i]);   // .. of this transition
                    inter.and(cur);
                    if (!inter.isEmpty()){            // found
                        if ((FL_H & this.trc) != 0){
                            Trc.out.println("cat found: " + i);
                        }
                        this.aut.transTable[h.num+1][i] = (char)nextState;
                        cur.sub(inter);
                        if (cur.isEmpty()) break;
                    }
                }
            }
        }
        for (ParserState h = this.dfa.sthead;         // determine looping states
            h != null; h = h.next){
            for (int i = 0; i < tranSize; i++){       // scan next states
                if (this.aut.transTable[h.num+1][i] == h.num+1){
                    this.aut.stateAttrs[h.num+1] |= ParserTables.LOOPING;
                    break;
                }
            }
        }

        int maxtok = (this.dfa.tokTable == null) ? 0  // in test it can be null
            : this.dfa.tokTable.length;
        if ((FL_G & this.trc) != 0){
            Trc.out.printf("genTables maxtok %d\n",maxtok);
        }
        if (maxtok+1 > ParserTables.MAX_TOKNR){       // too many tokens
            this.lex.message(ParserLexer.ERR_EXCLEX,
                null,ParserLexer.MSG_AT_EOF);
            throw this.lex.excObj;
        }
        int terNr = 0;                                // number of terminals
        ParserDic[] ordTok = new ParserDic[maxtok];   // ordered names
        for (int i = 0; i < maxtok; i++){
            ParserDic d = this.dfa.tokTable[i];
            if (d == null) continue;
            if (d.kind == ParserDic.TER){             // remember entry
                ordTok[terNr++] = d;
            }
        }
        Arrays.sort(ordTok,0,terNr);                  // sort terminal names
        this.aut.tokStrings = new String[maxtok];
        this.aut.tokNumbers = new char[maxtok];
        this.aut.tokOrder = new char[maxtok];
        this.aut.terNum = terNr;
        for (int i = 0; i < terNr; i++){              // copy strings and numbers
            int n = ordTok[i].tokNum;                 // .. of terminals
            ParserDic d = this.dfa.tokTable[n];
            this.aut.tokStrings[i] = String.valueOf(d.code);
            this.aut.tokNumbers[i] = (char)n;
            this.aut.tokOrder[n] = (char)i;
        }
        int ntNr = 0;                                 // number of nonterminals
        for (int i = 0; i < maxtok; i++){
            ParserDic d = this.dfa.tokTable[i];
            if (d == null) continue;
            if (d.kind != ParserDic.TER){             // remember entry
                ordTok[ntNr++] = d;
            }
        }
        Arrays.sort(ordTok,0,ntNr);
        for (int i = 0; i < ntNr; i++){               // copy strings and numbers
            int n = ordTok[i].tokNum;                 // .. of nonterminals
            ParserDic d = this.dfa.tokTable[n];
            this.aut.tokStrings[i+terNr] = String.valueOf(d.code);
            this.aut.tokNumbers[i+terNr] = (char)n;
            this.aut.tokOrder[n] = (char)(i+terNr);
        }

        int setnum = 1;                               // determine return codes
        int[] setMap = new int[sn];
        sx: for (ParserState h = this.dfa.sthead;     // fill map
            h != null; h = h.next){
            if (h.tokset == null) continue;
// better use an hash table
            for (ParserState s = this.dfa.sthead;     // look for duplicates
                s != h ; s = s.next){
                if (h.tokset.equals(s.tokset)){       // share the set
                    this.aut.stateAttrs[h.num+1] |=
                        this.aut.stateAttrs[s.num+1] & ParserTables.FINAL;
                    setMap[h.num] = s.num;
                    continue sx;
                }
            }
            if (setnum > ParserTables.MAX_TOKCODE){   // too many tokens codes
                this.lex.message(ParserLexer.ERR_EXCLEX,
                    null,ParserLexer.MSG_AT_EOF);
                throw this.lex.excObj;
            }
            this.aut.stateAttrs[h.num+1] |=
                setnum++ << ParserTables.TOKCODE_SHIFT;
            setMap[h.num] = h.num;
        }

        this.aut.tokLists = new char[setnum][];
        for (ParserState h = this.dfa.sthead;       // fill lists of tokens
            h != null; h = h.next){
            if (h.tokset == null) continue;
            if (setMap[h.num] != h.num) continue;
            int[] lset = h.tokset.toArray();
            char[] arr = new char[lset.length];
            for (int j = 0; j < lset.length; j++){
                arr[j] = (char)lset[j];
            }
            int code = (this.aut.stateAttrs[h.num+1] &
                ParserTables.FINAL) >>> ParserTables.TOKCODE_SHIFT;
            this.aut.tokLists[code] = arr;
        }

        if ((FL_H & this.trc) != 0){
            for (int i = 0; i < this.aut.tokLists.length; i++){
                Trc.out.println(i + " tok set: " +
                    this.aut.tokSetToString(i));
            }
        }

//        d = this.terDic.search("BOS",TER_SPE);
//        lex_desc.bos_vt = d != null;
//        d = this.terDic.search("BOL",TER_SPE);
//        lex_desc.bol_vt = d != null;
//        d = this.terDic.search("EOL",TER_SPE);
//        lex_desc.eol_vt = d != null;
//        d = this.terDic.search("EOS",TER_SPE);
//        lex_desc.eos_vt = d != null;

        for (int i = 0; i < sn; i++){              // complete attributes
            if ((this.aut.stateAttrs[i] &
                (ParserTables.LOOPING | ParserTables.FINAL)) != 0){
                this.aut.stateAttrs[i] |= ParserTables.SPECIAL;
            }
        }

        if ((FL_N & this.trc) != 0){
            Trc.out.println("genTables base tables");
        }
        this.aut.numOfToks = maxtok;
        if ((TOKENS_MAP & this.mode) != 0){
            mergeCodes();
        }
        autSize(this.aut);

        compression = 0;
        long sizeBase = this.aut.size;

        if ((COMB_TABLE & this.mode) != 0){
            mergeTrans(this.aut.transTable,
                this.aut.stateAttrs,this.aut.initialState);
            compression = (int)(((float)(sizeBase -
                this.aut.size)/sizeBase)*100);
        }

        if ((FL_G & this.trc) != 0){
            Trc.out.println("genTables end");
//            this.aut.trace(Trc.out);
            this.aut.trace(Trc.wrt);
        }
    }

    /** The degree of compression done on the transition tables. */
    int compression;

    /**
     * Compute the size of the encoded automaton and store it in
     * the automaton itself.
     *
     * @param      aut reference to the automa
     */

    private void autSize(ParserTables aut){
        int ns = aut.numOfStates;
        long transTableSize = transSize(aut);

        long cattableSize = 0;
        char[][] table = aut.catMap;
        if (table == null){
            cattableSize = aut.catMap0.length * 2 + 4;
        } else {
            cattableSize = table.length * 4 + 4;      // top directory
            for (int i = 0; i < table.length; i++){
                find: {
                    for (int j = 0; j < i; j++){
                        if (table[i] == table[j]) break find;
                    }
                    cattableSize += table[i].length * 2 + 4;
                }
            }
        }

        int len;
        long tokNamesSize = 0;
        if (aut.tokStrings != null){
            len = aut.tokStrings.length;
            tokNamesSize = len * 4 + 4;                // top level directory
            for (int i = 0; i < len; i++){
                String name = aut.tokStrings[i];
                tokNamesSize += name.length() * 2 + 8;
            }
            tokNamesSize += (len * 2 + 4) * 2;         // tokNumbers and tokOrder
        }

        long tokSetsSize = 0;
        len = 0;
        if (aut.tokLists != null){
            len = aut.tokLists.length;
            tokSetsSize = len * 4 + 4;                 // top directory
// no sharing?
            for (int i = 0; i < len; i++){
                char[] list = aut.tokLists[i];
                if (list != null){
                    tokSetsSize += list.length * 2 + 4;   // this set
                }
            }
        } else if (aut.tokMap != null){
            tokSetsSize = aut.tokMap.length * 2 + 4;
        }

        long attrSize = ns * 4 + 4;                    // attributes

        aut.size = transTableSize;
        if (aut.stateAttrs == null){
            attrSize = 0;
        }
        aut.size += attrSize;
        aut.size += cattableSize;
        aut.size += tokNamesSize;
        aut.size += tokSetsSize;
        if ((FL_N & this.trc) != 0){
            Trc.out.println("trans: " + transTableSize +
                " attrs: " + attrSize +
                " cats: " + cattableSize +
                " toks: " + tokNamesSize +
                " tokSets: " + tokSetsSize +
                " total: " + aut.size);
            Trc.out.println("states: " + ns +
                " categories: " + aut.numOfSymbs +
                " tokens sets: " + len);
            Trc.out.println("edges: " + this.entries +
                " null edges: " + this.noentries);
        }
    }

    /** The number of significant entries. */
    private int entries = 0;

    /** The number of no-state entries. */
    private int noentries = 0;

    /**
     * Deliver the size of the transition table of the encoded automaton.
     *
     * @param      aut reference to the automa
     * @return     size
     */

    private long transSize(ParserTables aut){
        entries = 0;
        noentries = 0;
        int ns = aut.numOfStates;
        long size = 0;
        if (aut.transTable != null){            // sum size of subtables
            size = aut.transTable.length * 4 + 4;
            loop: for (int i = 0; i < aut.transTable.length; i++){
                char[] tab = aut.transTable[i];
                if (tab == null) continue;
                for (int j = 0; j < i; j++){
                    if (tab == aut.transTable[j]){
                        continue loop;          // shared
                    }
                }
                size += tab.length * 2 + 4;
                for (int j = 0; j < tab.length; j++){
                    if (tab[j] > 0) this.entries++;
                    else this.noentries++;
                }
            }
        }
        if ((FL_N & this.trc) != 0){
            Trc.out.printf("transSize -1- %s\n",size);
        }
        if (aut.tabMerged != null){
            size = aut.tabMerged.length * 4 + 4;
            for (int i = 0; i < aut.tabMerged.length; i++){
                if (aut.tabMerged[i] > 0) entries++;
                else noentries++;
            }
        }
        if ((FL_N & this.trc) != 0){
            Trc.out.printf("transSize -2- %s\n",size);
        }
        sb: if (aut.stateBase != null){
            if ((aut.tabMerged != null) &&
                ((RELOCATED & this.mode) != 0)) break sb;
            size += aut.stateBase.length * 4 + 4;
        }
        if ((FL_N & this.trc) != 0){
            Trc.out.printf("transSize -3- %s\n",size);
        }
        if (aut.fallback != null){
            size += aut.fallback.length * 2 + 4;
        }
        if ((FL_N & this.trc) != 0){
            Trc.out.printf("transSize -4- %s\n",size);
        }
        return size;
    }

   /* These parameters control optimization.
    * They are mainly for internal use in ParserTest or in Parser, but
    * not to be used by applications since there is only one engine for
    * applications and that is the one for compressed tables.
    * Since generation is done inside prs.analyse(), a mode controls how
    * it requests generation of the lexer.
    * This is done by setting the mode in ParserBnf.
    * Generation could be invoked separately, but for applications it is
    * simpler to call only one method.
    */

    /** Whether it produces a basic transition table. */
    static final int BASIC_TABLE = 1 << 1;

    /** Whether it produces a comb-merged transition table. */
    static final int COMB_TABLE = 1 << 2;

    /** Whether it produces a fallback transition table. */
    static final int FALLBACK_TABLE = 1 << 3;

    /** Whether it produces relocated transitions. */
    static final int RELOCATED = 1 << 5;

    /** Whether it should print state numbers when tracing. */
    static final int STATE_NUMBERS = 1 << 6;

    /** Whether it should represent tokens sets as a map. */
    static final int TOKENS_MAP = 1 << 7;

    /** Whether it should retain the FAs, used for testing. */
    static final int RETAIN_FA = 1 << 16;

    /** The mode. */
    int mode;

    /**
     * Merge the transition subtables compressing them in a unique table.
     * This method transforms the origin, plain tables into a merged
     * one in which state tables are intermingled occupying the holes
     * that are present in them (comb-vector). To tell if an entry is that
     * of the state at hand and not a hole in its subtable, the state base
     * is recorded in entries (check value).
     * It applies to transition tables which are a matrix char[][] and
     * with the no-state represented as 0.
     * Tables whose values are all no-state might be shared.
     * Merging is done by fitting subtables which have holes also at the
     * beginning into the first place which allows it.
     * Holes at beginning or at the end need correspond to real elements
     * of the merge table because they are elements which are accessed.
     * The subtable of the state no-state is not stored at all, but it
     * it so for the ones of final states, which have all entries equal to
     * no-state. This is so because there is a need to assign a base to
     * them since they are accessed.
     * The compression is higher starting with the subtables which have more
     * elements.
     *
     * To support sharing in merged tables (with non-relocated transitions)
     * the state base can be used as check value. However, bases might not
     * be unique: two subtables which are not shared get the same base if
     * their elements fit into each other.
     * The solution is to never allocate subtables at the same position as
     * others, but find out a new position, unless the ones which occupy it
     * are subtables which share the same (they are processed after, though,
     * and thus need not be taken into account when checking the there is
     * already a table at that position).
     * When a subtable is empty, i.e. made of all no-state values, it needs
     * to have a unique base too so as to make sure that such a base value
     * is not used for other subtables, and thus appear as check in entries
     * which by chance get overlayed on its ones, generating thus entries
     * that can feign as other entries.
     *
     * State bases as check values could limit the size of the merged
     * table to 64K entries, or require more bits to be stored.
     * To avoid it, 16 bits can be used to hold the check values, and
     * ensure that in the slice of the merged table in which a subtable
     * could be placed there are no pieces of other subtables with the same
     * check value.
     * When the size of the subtables is lower or equal to the maximum
     * value which can be contained in the check value no ambiguities can arise
     * since any subtable may not be placed at the same position; any position
     * which is higher that that has a different (modulo) value, and the
     * first position which has the same (modulo) values does not overlap
     * the table.
     *
     * Note that the comb-vector compression is done by finding a place in
     * which the elements of a comb fit into holes of the merge. It could be
     * possible to fit it elements into identical elements of the merge if
     * the check values would be sets insead of simple values. This is possible
     * if the number of the subtables is not high, and certainly < 64.
     * Since states can easily be more than that, such a digging is seldom
     * possible.
     *
     * The merge table is made of integers to allow to get a value and
     * its associated check value with one single array access.
     *
     * When RELOCATED is not set, it merges tables without relocating
     * transitions. It serves mainly for testing.
     *
     * It is possible to perform folding of columns, reducing the table
     * size by 30%. It would be the same as using metacategories.
     * However, this reduces also the speed of the lexing engine.
... it would be fine to measure how much
     * There are normally no equal rows, and therefore there is no point
     * in sharing them (and besides that, relocation would not allow it).
     * The Dragon book reports another optimization: if all incoming arcs
     * of states have the same symbol, and there are no states that have
     * the same incoming symbol, then we can shorten the check vector by
     * indexing it with states, and checking not check[base+j], but
     * check[merge[base+j]]=j. However, this is a rather peculiar case.
     * In general, values in matrices may represent anything, and not row
     * numbers as in a lexer.
     *
     * When relocation is used (which is the normal case), we insert the
     * state attributes in the tabmerge (which requires space for check
     * values, and probably makes compression lower). This is the price to
     * pay for relocation (there are no state numbers, but bases, and
     * thus it is not possible to have a state attribute table indexed with
     * state numbers, which means that attributes must be attached to state
     * tables). Note that when relocation is selected, row sharing is
     * automatically disabled.
     * We use bases as check values also because we relocate the tables:
     * if we had somewhere the table numbers, then we could use them to access
     * the base vector, and also use them to test check values, but we do not
     * have table numbers, but directly bases (as it is the case with relocated
     * tables), and then we cannot have table numbers as check values because
     * we would have none to test with.
     * With relocation, before a row there is always an entry for the attributes
     * and another for the fallback (even if it has not been selected), and
     * the lexer engine uses them.
     *
     * Note that it is not possible to print easily a matrix for relocated
     * tables because we do not have the base vector, and therefore we do
     * not know where the rows start. To do it, the generator can be told
     * to keep the state base.
     */

    private void mergeTrans(char[][] transTable, int[] stateAttrs, int init){
        if ((FL_N & this.trc) != 0){
            Trc.out.println("mergeTrans");
            Trc.out.println("relocated: " +
                ((RELOCATED & this.mode) != 0));
        }

        int combmode = CombVector.HOLES_ACCESSED;
        if ((FALLBACK_TABLE & this.mode) != 0){
            combmode |= CombVector.FALL_BACK;
        }
        if ((RELOCATED & this.mode) == 0){
            combmode |= CombVector.FOLD_ROWS;
        }
        if ((FL_N & this.trc) != 0){
            Trc.out.printf("combmode %s\n",combmode);
        }
        int hole = 0;
        CombVector comb = new CombVector(hole,combmode);
        comb.checkBits = 16;                          // check values in 16 bits

        int[][] mat = new int[transTable.length][];   // create the int[] tables
        loop: for (int i = 0; i < mat.length; i++){
            char[] tab = transTable[i];
            if (tab == null) continue;
            for (int j = 0; j < i; j++){              // skip the identical ones
                if (tab == transTable[j]){
                    mat[i] = mat[j];
                    continue loop;                    // shared
                }
            }
            if ((RELOCATED & this.mode) != 0){        // prepend 2 elements
                mat[i] = new int[tab.length+2];
                mat[i][0] = -i-1;                     // use unique values, otherwise ..
                mat[i][1] = -i-1;                     // .. they fallback
                for (int j = 0; j < tab.length; j++){ // copy the row
                    mat[i][j+2] = tab[j];
                }
            } else {
                mat[i] = new int[tab.length];         // copy the row
                for (int j = 0; j < tab.length; j++){
                    mat[i][j] = tab[j];
                }
            }
        }
        if ((FL_C & this.trc) != 0){
            comb.settrc("ab");
        }
        comb.merge(mat);                        // compress matrix
        comb.settrc("");
        //comb.sanityCheck();
        //comb.statistics();
        if (comb.tabMerged.length > Character.MAX_VALUE){
            this.lex.message(ParserLexer.ERR_EXCLEX,
                null,ParserLexer.MSG_AT_EOF);
            throw this.lex.excObj;
        }
        if ((FL_N & this.trc) != 0){
            Trc.out.printf("comb.tabMerged %s\n",comb.tabMerged.length);
        }

        // pack the entries and the check values, and relocate them

        for (int i = 0; i < comb.tabMerged.length; i++){
            int ck = comb.check[i];
            int el = comb.tabMerged[i];
            if (ck >= 0){                       // not a hole
                if ((RELOCATED & this.mode) != 0){
                    ck += 2;
                    if (el > 0){                // not an attribute entry
                        el = comb.base[el] + 2; // relocate it
                    }
                }
            } else {
                ck = 0;
            }
            comb.tabMerged[i] = (el << 16) | (ck & 0xffff);
        }
        int ns = this.aut.numOfStates;
        if ((RELOCATED & this.mode) != 0){            // relocate
            for (int i = 0; i < ns; i++){             // displace base
                if (comb.base[i] >= 0){
                    comb.base[i] += 2;
                }
                if (comb.base[i] > Integer.MAX_VALUE){
                    this.lex.message(ParserLexer.ERR_EXCLEX,
                        null,ParserLexer.MSG_AT_EOF);
                        throw this.lex.excObj;
                }
                if ((FALLBACK_TABLE & this.mode) != 0){
                    if (comb.fallTable[i] >= 0){
                        comb.fallTable[i] += 2;       // displace falltable
                    }
                }
            }
            // insert state attributes and fallback, that are
            // always present, even if fallback not selected
            int nshift = ParserTables.NSHIFT;
            int nmask = ParserTables.MASK << nshift;
            for (int i = 0; i < ns; i++){
                int idx = comb.base[i] - 2;
                if (idx < 0) continue;
                comb.tabMerged[idx] &= ~nmask;        // insert state attributes
                comb.tabMerged[idx++] |=
                    stateAttrs[i] & nmask;

                int ck = (char)comb.tabMerged[idx];   // insert fallback
                int el = comb.base[i];                // autofallback, in case no fallback selected
                if (comb.fallTable != null){          // fallback selected
                    el = comb.fallTable[i];
                }
                comb.tabMerged[idx++] = (el << nshift) | ck;
            }
            this.aut.initialState =                   // relocate initial state
                (char)(comb.base[init]);
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("tabMerged:");
            for (int i = 0; i < comb.tabMerged.length; i++){
                Trc.out.println(i +  ": " + (int)(comb.tabMerged[i] >>> 16) +
                    "\t" + (int)(comb.tabMerged[i] & 0xffff));
            }
            Trc.out.println("base table");
            for (int i = 0; i < comb.base.length; i++){
                Trc.out.println(i +  ": " + comb.base[i]);
            }
        }

        long oldsize = transSize(this.aut);
        this.aut.tabMerged = comb.tabMerged;
        if ((STATE_NUMBERS & this.mode) != 0){   // keep the bases
            this.aut.stateBase = comb.base;
            if ((FL_N & this.trc) != 0){
                Trc.out.println("state numbers");
            }
        }
        if ((RELOCATED & this.mode) != 0){
            this.aut.stateAttrs = null;
        } else {
            this.aut.fallback = new char[comb.fallTable.length];
            for (int i = 0; i < comb.fallTable.length; i++){
                this.aut.fallback[i] = (char)comb.fallTable[i];
            }
        }

        this.aut.transTable = null;              // remove origin table
        autSize(this.aut);                       // compute again size
        long newTranSize = transSize(this.aut);
        if ((FL_N & this.trc) != 0){
            Trc.out.println("relocated: " +
                ((RELOCATED & this.mode) != 0));
            Trc.out.println("old trans size: " + oldsize);
            Trc.out.println("merge trans size: " + newTranSize);
            Trc.out.println("merge table length: " + comb.tabMerged.length);
            Trc.out.println("new table size: " + this.aut.size);
        }
    }

    /**
     * Build the tokens sets map as a comb-vector.
     */

    public void mergeCodes(){
        if ((FL_N & this.trc) != 0){
            Trc.out.println("mergeCodes");
        }
        char[][] lists = this.aut.tokLists;
        int[][] tabs = new int[lists.length][];   // copy into tables
        for (int i = 0; i < tabs.length; i++){
            char[] ls = lists[i];
            if (ls == null) continue;
            int max = 0;
            for (int j = 0; j < ls.length; j++){  // determine max value
                if (ls[j] > max) max = ls[j];
            }
            tabs[i] = new int[max+1];
            int[] t = tabs[i];
            for (int j = 0; j < ls.length; j++){  // copy
                t[ls[j]] = 1;
            }
        }
        CombVector comb = new CombVector(0,CombVector.FOLD_ROWS);
        try {
            comb.merge(tabs);                     // merge them
        } catch (OutOfMemoryError exc){
            this.lex.message(ParserLexer.ERR_EXCLEX,
                null,ParserLexer.MSG_AT_EOF);
            throw this.lex.excObj;
        }
        this.aut.tokMap = new char[comb.tabMerged.length+1]; // copy offsetted
        for (int i = 0; i < comb.tabMerged.length; i++){     // .. by 1, base 0
            this.aut.tokMap[i+1] = (char)comb.tabMerged[i];  // .. reserved
        }
        int ns = this.aut.numOfStates;
        for (int i = 0; i < ns; i++){             // replace codes with bases
            int code = (this.aut.stateAttrs[i] &
                ParserTables.FINAL) >>> ParserTables.TOKCODE_SHIFT;
            if (code == 0) continue;
            int bas = comb.base[code] + 1;
            if (bas > ParserTables.MAX_TOKCODE){  // too large
                this.lex.message(ParserLexer.ERR_EXCLEX,
                    null,ParserLexer.MSG_AT_EOF);
                throw this.lex.excObj;
            }
            this.aut.stateAttrs[i] &= ~ParserTables.FINAL;
            this.aut.stateAttrs[i] |= bas << ParserTables.TOKCODE_SHIFT;
        }

        this.aut.tokLists = null;
        if ((FL_N & this.trc) != 0){
            Trc.out.println("mergeCodes size: " +
                (this.aut.tokMap.length*2 + 4));
        }
    }

    // Methods and fields to test the unencoded DFA

    /** The reference to the input. */
    //private Object inp;

    /** The reference to the reader. */
    //private BufReader stream;

    /** The trace flags. */
    //private static final int FL_A = 1 << ('a'-0x60);
    //private static final int FL_B = 1 << ('b'-0x60);

    /**
     * Construct an automa generator on the specified input.
     *
     * @param   inp reference to the input
     */

    /*
    public ParserLexGen(Object inp){
        this.inp = inp;
        this.stream = new BufReader(inp,1024);
    }
    */

    /**
     * Scan the text and deliver the next lexeme(s).
     *
     * @return     set of tokens
     */

    /*
    public IntSet lex(){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("lex start " + this.dfa.sthead);
        }
        ParserState acceptState = null;
        ParserState state = this.dfa.sthead;
        int lastPos = 0;                    // last position matched
        if (this.stream.cursor == this.stream.end){
            this.stream.mark();
        } else {
            this.stream.markPos = this.stream.cursor;  // mark start of lexeme
        }
        loop: do {
            if ((ParserState.FINAL & state.status) != 0){
                lastPos = this.stream.cursor - this.stream.markPos;
                acceptState = state;
            }
            if (this.stream.cursor == this.stream.end){ // get symbol, no data
                int n = this.stream.readBlock(); // get next block
                if (n < 0){                      // no symbol, eof
                    this.stream.cursor++;        // cater for cursor-- below
                    break;                       // no more characters
                }
            }
            char ch = this.stream.buffer[this.stream.cursor++];   // get symbol and advance
            if ((FL_B & this.trc) != 0){
                Trc.out.println("char: " + ch);
            }
            state = move(state,ch);              // move(state,symbol)
            if ((FL_B & this.trc) != 0){
                Trc.out.println("ch: " + Integer.toHexString(ch) +
                    " next: " + state);
            }
        } while (state != null);
        IntSet res = null;
        if (acceptState != null){                // recognized
            this.stream.cursor = lastPos + this.stream.markPos;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("lexeme at: " +
                    (this.stream.index - this.stream.end +
                    this.stream.markPos) + " " +
                    String.valueOf(this.stream.buffer,
                       this.stream.markPos,
                       this.stream.cursor - this.stream.markPos) +
                       " " + tokensToString(acceptState.tokset));
            }
            res = acceptState.tokset;
        } else {                                 // no match, back to wrong char
            this.stream.cursor--;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("no match at: " + this.stream.cursor);
            }
        }
        if ((FL_A & this.trc) != 0){
            Trc.out.println("lex return: " +
                (acceptState != null) + " at: " +
                (this.stream.index - this.stream.end +
                    this.stream.markPos) + ":" +
                (this.stream.index - this.stream.end +
                    this.stream.cursor));
        }
        return res;
    }
    */

    /**
     * Deliver the next state reachead by a move from a state and a symbol.
     *
     * @param      h reference to the state
     * @param      s symbol
     * @return     reference to the next state
     */

    /*
    ParserState move(ParserState h, char s){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("move " + h + " " + Integer.toHexString(s));
        }
        for (ParserTrans t = h.transList;  // scan its edges
            t != null; t = t.next){
            if ((FL_G & this.trc) != 0){
                Trc.out.println("edge: " + t.set);
            }
            if (t.set.contains(s)){
                h = t.nextState;
                break loop;
            }
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("move " + h);
        }
        return h;
    }
    */

    /**
     * Deliver the text matched
     *
     * @return     String containing the text matched
     */

    /*
    public String toString(){
        if (this.stream.cursor == this.stream.markPos){
            return "";
        }
        return String.valueOf(this.stream.buffer,this.stream.markPos,
            this.stream.cursor - this.stream.markPos);
    }
    */
}
