/*
 * @(#)BytesRow.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;

/**
 * The <code>BytesRow</code> class provides a means for referring to
 * byte string slices.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

public class BytesRow implements Serializable, Cloneable {

    /**
     * The buffer holding the data.
     *
     * @serial
     */
    public byte[] buffer;

    /**
     * The start offset of the data.
     *
     * @serial
     */
    public int offset;

    /**
     * The number of data.
     *
     * @serial
     */
    public int length;

    /** SUID form JDK 1.2 */
    private static final long serialVersionUID = -860344265703644786L;

    /** The empty row constant. */
    public static final BytesRow EMPTY = new BytesRow();

    /**
     * Construct a new <code>BytesRow</code> which refers to the
     * slice passed as argument.
     *
     * @param      arr array
     * @param      off offset
     * @param      len slice length
     */

    public BytesRow(byte[] buf, int off, int len){
        this.buffer = buf;
        this.offset = off;
        this.length = len;
    }

    /**
     * Construct a new <code>BytesRow</code> which refers to the
     * array passed as argument.
     *
     * @param      arr array
     */

    public BytesRow(byte[] buf){
        this.buffer = buf;
        this.offset = 0;
        this.length = buf.length;
    }

    /**
     * Construct a new <code>BytesRow</code> which refers to no
     * slice.
     */

    public BytesRow(){
    }

    /**
     * Clone this object.
     *
     * @return     a copy of the object
     */

    public Object clone(){
        BytesRow t = null;
        try {
            t = (BytesRow)super.clone();
        } catch (CloneNotSupportedException e){
        }
        return t;
    }

    /**
     * Determine if this row refers to the same slice as the specified object.
     * It delivers <code>true</code> when the argument is not <code>null</code>
     * and is a <code>BytesRow</code> object that refers to the same array,
     * with the same offset and length.
     *
     * @param   other the object to compare
     * @return  true if equal
     */

    public boolean equals(Object other){
        if (this == other) return true;
        if (other == null) return false;
        if (!(other instanceof BytesRow)) return false;
        BytesRow s = (BytesRow)other;
        if (this.buffer != s.buffer) return false;
        if (this.offset != s.offset) return false;
        if (this.length != s.length) return false;
        return true;
    }

    /**
     * Return the hashcode for this object.
     *
     * @return     hash code value
     */

    public int hashCode(){
        int h = System.identityHashCode(this.buffer) +
            this.offset + this.length;
	return h;
    }

    /**
     * Deliver an array with the contents of the referred slice.
     *
     * @return     array
     */

    public byte[] toArray(){
        if (this.buffer == null) return null;
        byte[] bb = new byte[this.length];
        System.arraycopy(this.buffer,this.offset,bb,0,this.length);
        return bb;
    }
}
