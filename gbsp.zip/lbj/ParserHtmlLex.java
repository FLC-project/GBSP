/*
 * @(#)ParserHtmlLex.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;
import lbj.IoStream;
import lbj.ParserLex;

/**
 * The <code>ParserHtmlLex</code> represents lexical analyzer for html.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

class ParserHtmlLex extends ParserLex {

    public ParserHtmlLex(){
        super();
    }
    public ParserHtmlLex(ParserTables au){
        super(au);
        au.clearLexerData();
    }
/*
.. when implementing a handwritten lexer, it is convenient to use
   the Lexer and LexerStream classes. However, here we need to comply
   to the ParserLex class. Of course, we can internally create a
   class that inherits from LexerStream, but then we have to make lex()
   call its methods, which it not very efficient
.. well, the Lexer and LexerStream classes are made for lexers that
   do recognize only one token at a time, and only the specified one,
   and therefore they are a bit different from what is needed here.
.. why not allow one to generate the automa for several lexers and
   call them in sequence so as to simplify the generation of handwritten
   lexers? There is a need to mark and reposition the input only.
   Currently, we put together the lexer and parser tables. Having several
   lexer tables means some waste of memory and also that lexemes are
   numbered differently, which means that we have to convert them to
   return them properly. This is a bit uncomfortable. Of course, managing
   all of them in the same lexer is a lot simpler.
   The current ParserLex seems a bit sticky: we would perhaps want to
   take a string with the rule of a lexeme, generate the automaton, then
   call the lexer on it without bothering about numbering lexemes.

... have a main that loops and delivers all the lexemes so as to test this

... an alternative is to redefine the lexer class and insert in it a tweak
    to get a pcdata when in it ... we can have a rule for pcdata that
    generates something that is not allowed in tags ... well, what we need
    is to assign a token number ot pcdata without disturbing the lexer
*/
    static final int FL_A = 1 << ('a'-0x60);
    static final int FL_W = 1 << ('w'-0x60);

    private int state;
    private int subState;
    private int prev;
    private ParserHtmlLexer lx;
    Str s = new Str();

    int tokStr;
    int tokNameStr;
    int tokNqStr;
    int tokPCDATA;
    int tokScript;
    int tokStyle;
    int tokScriptBody;
    int tokStyleBody;
    int tokDelimiter;
    int tokEquals;

    public int lex(){
        if (this.lx == null){
            this.lx = new ParserHtmlLexer(this.stream);
        }
        if (this.aut != null){
            if (this.tokStr == 0){           // initialise
                this.tokStr = this.aut.symNr("string");
                this.tokNameStr = this.aut.symNr("namestring");
                this.tokNqStr = this.aut.symNr("nonquoted string");
                this.tokPCDATA = this.aut.symNr("#PCDATA");
                this.tokScript = this.aut.symNr('t',"<SCRIPT");
                this.tokStyle = this.aut.symNr('t',"<STYLE");
                this.tokScriptBody = this.aut.symNr("script-token");
                this.tokStyleBody = this.aut.symNr("style-token");
                this.tokDelimiter = this.aut.symNr("delimiter");
                this.tokEquals = this.aut.symNr('t',"=");
                if ((FL_A & lx.trc) != 0){
                    for (int i = 0; i < this.aut.tokStrings.length; i++){
                        Trc.out.println(this.aut.tokStrings[i]);
                    }
                }
            }
        }
        int res = 0;
        int kind = 0;
        boolean found = false;
        doit: for(;;){
            if ((FL_W & lx.trc) != 0){
                Trc.out.println("loop state: " + this.state +
                    " " + this.subState + " " + lx.getLineNr());
            }
            if (lx.getProcInstr(s)) continue;
            switch (this.state){
            case 0:                              // element contents or tags
                switch (this.subState){
                case 0:                          // element contents or tags
                    if (lx.getUpToTag(s)){       // if something got, then pcdata
                        res = this.tokPCDATA;
                        found = true;
                        break doit;
                    }
                    if (lx.getTagName(s)){       // nothing got, try with a tag
                        kind = 1;
                        this.state = 1;
                        found = true;
                        break doit;
                    }
                    break doit;
                case 1:                          // script contents
                    if (lx.getUpToCloseTag(s)){
                        res = this.tokScriptBody;
                        this.subState = 0;
                        found = true;
                        break doit;
                    }
                    if (lx.getTagName(s)){       // nothing got, try with a tag
                        kind = 1;
                        this.state = 1;
                        this.subState = 0;
                        found = true;
                        break doit;
                    }
                    break doit;
                case 2:                          // style contents
                    if (lx.getUpToCloseTag(s)){
                        res = this.tokStyleBody;
                        this.subState = 0;
                        found = true;
                        break doit;
                    }
                    if (lx.getTagName(s)){       // nothing got, try with a tag
                        kind = 1;
                        this.state = 1;
                        this.subState = 0;
                        found = true;
                        break doit;
                    }
                    break doit;
                }
            default:                             // attributes
                if (lx.gdel("/>") ||
                    lx.gdel('>')){
                    this.state = 0;
                    kind = 2;
                    found = true;
                    break doit;
                }
                if (lx.getStr(s)){
                    res = this.tokStr;
                    found = true;
                    break doit;
                }
                if (lx.getNamestr(s)){
                    res = this.tokNameStr;
                    if (this.prev != this.tokEquals){  // if not after = it is a keyword
                        kind = 2;
                    }
                    found = true;
                    break doit;
                }
                if (lx.getNqStr(s)){
                    res = this.tokNqStr;
                    found = true;
                    break doit;
                }
                if (lx.gdel('=')){
                    kind = 2;
                    found = true;
                    break doit;
                }
                break doit;
            }
        }
        this.stream.cursor = lx.cursor;
        this.stream.end = lx.end;
        if (found){
            String tokenString = "";
            if ((this.stream.markPos >= 0) &&
                (this.stream.cursor > this.stream.markPos)){
                tokenString = toString();
            }
            if ((this.aut != null) && (tokenString.length() > 0)){
                if (kind == 1){
                    tokenString = tokenString.toUpperCase();
                } else if (kind == 2){
                    tokenString = tokenString.toLowerCase();
                }
                if ((kind == 1) || (kind == 2)){
                    int res1 = this.aut.symNr('t',tokenString);
                    if (res1 >= 0){
                        res = res1;
                    }
                    if (res == this.tokScript){
                        this.subState = 1;
                    } else if (res == this.tokStyle){
                        this.subState = 2;
                    }
                }
                if (this.aut.tokLists[1].length != 1){
                    this.aut.tokLists[1] = new char[1];
                }
                this.aut.tokLists[1][0] = (char)res;
                if ((FL_W & lx.trc) != 0){
                    Trc.out.println("found " + tokenString + " " +
                        res + " " + this.aut.tokLitName(res) + " " +
                        this.aut.tokSetToString(1));
                }
                this.prev = res;
                res = 1;
            }
        }
        if ((FL_W & lx.trc) != 0){
            Trc.out.println("return " + res);
        }
        return res;
    }

    static public void main(String[] args){
        IoStream gra = new IoStream();           // init gram stream
        IoStream inp = new IoStream();           // init text stream
        try {
            gra.open(args[0],IoStream.CHARS);
            inp.open(args[1],IoStream.CHARS);
        } catch (Throwable exc){
            Trc.out.println("no file");
            return;
        }
        ParserBnf prs = new ParserBnf();
        if (!prs.analyse(gra)){                      // parse source grammar
            Trc.out.println("erroneous grammar");
        }
        gra.close();                                 // terminate input
        if ((prs.lex.fatcnt != 0) ||                 // errors or fatals
            (prs.lex.errcnt != 0)) return;
        ParserHtmlLex lex = new ParserHtmlLex(prs.getTables());
        lex.stream = new BufReader(inp,1024);

        if (args.length > 2){
            lex.settrc(args[2]);
            lex.lx.settrc(args[2]);
        }
        doit: for (;;){
            if (lex.eof()) break;
            int res = lex.lex();
            if (res <= 0){
                if (lex.eof()) break;
                Trc.out.print("unknown lexeme");
                break;
            }
        }
        try {
            inp.close();
        } catch (Throwable exc){
            Trc.out.println("close error");
            return;
        }
    }
}
