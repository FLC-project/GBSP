/*
 * @(#)ListBundle_en.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

/**
 * The <code>ListBundle_en</code> class provides the English locale for
 * the testing of the <code>Listing</code> class.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

public class ListBundle_en extends ListBundle {
}