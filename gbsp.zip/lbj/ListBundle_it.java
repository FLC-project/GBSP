/*
 * @(#)ListBundle_it.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;

/**
 * The <code>ListBundle_it</code> class provides the Italian locale for
 * the testing of the <code>Listing</code> class.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

public class ListBundle_it extends ListResourceBundle {
    public Object[][] getContents() {
        return contents;
    }

    // LOCALIZE THIS

    public static final String[] MSGTAB = {
        "TOOMANY, troppi errori",                 // 0
        "BADLIN, lionea troppo lunga, troncata",  // 1
        "BADTKN, token illegale",                 // 2
        "PREEND, fine prematura del sorgente",    // 3
        "EXCCHAR, charatteri eccedenti",          // 4
        "ILLSTMT, frase illegale",                // 5
        "MULDEF, definizione multipla",           // 6
        "NOCORE, memoria insufficente",           // 7
        "UNEXLIN, linee insapettate",             // 8
    };

    private static final Object[][] contents = {
        {"MSGTAB",   MSGTAB},
        {"SECT",     "Sezione"},
        {"TITLE",    "Titolo"},
        {"MYERR",    "MYERR, token errato"},
        {"SOURCE",   "Testo sorgente"},
    };

    // END OF MATERIAL TO LOCALIZE
}
