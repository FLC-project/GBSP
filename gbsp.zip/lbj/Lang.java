/*
 * @(#)Lang.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;

/**
 * The <code>Lang</code> class provides objects which represent the
 * current locale for applications.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

/**
 * A <code>Lang</code> serves to all classes, like e.g. <code>Cli</code>,
 * which have a locale-dependent behaviour. A <code>Lang</code> allows
 * to change the locale of all such objects with a single change.
 * Classes for which localization occurs only when doing something, like e.g.
 * printing messages, on the base of a locale received as an argument to
 * methods, do not need it.
 * A <code>Lang</code> represents a common, current "locale" for an
 * application, or a part of an application. It can be the default one or
 * a fixed one.
 * This relieves from the burden of changing the locale of all objects
 * which provide localized data when there is a need to make the whole
 * application change the locale on the fly.
 * This is done by using a <code>Lang</code> object in <code>Formatter</code>,
 * <code>Cli</code>, etc., objects. The latter, when created, are linked
 * to a language. When the locale in the language changes, the actions which
 * depend on the default locale change the language. It is like having a
 * default locale which is not a unique one for the entire VM, but for any
 * part which needs to have a common language.
 *
 * Classes which print an error message before aborting can use the
 * default locale instead of storing in them a reference to a locale
 * because aborting is a last resort, and in most cases a rather poor
 * technique, which is not worth localization.
 */

public class Lang {

    /** The current locale. */
    private Locale current;

    /**
     * Construct a new <code>Lang</code> for the current default Locale.
     */

    public Lang(){
        this.current = Locale.getDefault();
    }

    /**
     * Construct a new <code>Lang</code> for a given Locale.
     */

    public Lang(Locale loc){
        this.current = loc;
    }

    /**
     * Deliver the current locale.
     *
     * @return     locale
     */

    public Locale getDefault(){
        return this.current;
    }

    /**
     * Set the current locale.
     *
     * @param      loc locale
     */

    public void setDefault(Locale loc){
        this.current = loc;
    }
}
