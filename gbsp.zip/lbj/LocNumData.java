/*
 * @(#)LocNumData.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.text.*;

/**
 * The <code>LocNumData</code> class provides the locale dependent
 * conventions for the representation of numbers.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

public class LocNumData {

    /* Instance fields */

    /** True if the minus sign is prefix. */
    public boolean minusPref;

    /** The string for infinity. */
    public String  infinity;

    /** The string for NaN. */
    public String  nan;

    /** The local currency symbol. */
    public String  csign;

    /** The international currency symbol. */
    public String  intnCsign;

    /** The (thousands) group separator. */
    public char    groupSep;

    /** The group size. */
    public int     groupSize;

    /** The decimal separator. */
    public char    decSep;

    /** The monetary decimal separator. */
    public char    monDecSep;

    /** The character for zero. */
    public char    zeroDigit;

    /** The exponential symbol. */
    public char    expSym;

    /** The minus sign.*/
    public char    minusSign;

    /** The percent sign.*/
    public char    percent;

    /** The permille sign. */
    public char    perMill;

    /** The positive prefix for currency. */
    public byte    cyPosPref;

    /** The positive suffix for currency. */
    public byte    cyPosSuff;

    /** The negative prefix for currency. */
    public byte    cyNegPref;

    /** The negative suffix for currency. */
    public byte    cyNegSuff;

    /** The space character in affixes. */
    public char    space;

    /** The length of affixes. */
    public int     affLength;

    /** The default values. */
    public static final LocNumData DEFAULT = new LocNumData();

    /**
     * Construct a locale data object with default values.
     */

    public LocNumData(){
        this.minusPref = true;
        this.groupSize = 3;
        this.infinity = "\u221E";
        this.nan = "\uFFFD";
        this.csign = "$";
        this.intnCsign = "USD";
        this.groupSep = ',';
        this.decSep = '.';
        this.monDecSep = '.';
        this.zeroDigit = '0';
        this.expSym = 'E';
        this.minusSign = '-';
        this.percent = '%';
        this.perMill = '\u2030';
        this.space = 0;
        this.affLength = 0;
    }

    /**
     * Construct a locale data object for a given DecimalFormat
     * of DecimalFormatSymbols.
     *
     * @param      number formatter
     * @param      decimal symbols
     */

    public LocNumData(DecimalFormat nf, DecimalFormatSymbols ds){
        this();
        if (nf != null){
            this.minusPref = nf.getNegativePrefix().length() != 0;
            this.groupSize = nf.getGroupingSize();
        }
        if (ds != null){
            this.infinity = ds.getInfinity();
            this.nan = ds.getNaN();
            this.csign = ds.getCurrencySymbol();
            this.intnCsign = ds.getInternationalCurrencySymbol();
            this.groupSep = ds.getGroupingSeparator();
            this.decSep = ds.getDecimalSeparator();
            this.monDecSep = ds.getMonetaryDecimalSeparator();
            this.zeroDigit = ds.getZeroDigit();
            //this.expSym = ds.getExponentialSymbol();
            this.expSym = 'E';
            this.minusSign = ds.getMinusSign();
            this.percent = ds.getPercent();
            this.perMill = ds.getPerMill();
        }
    }

    /**
     * Complete the locale data with the masks for affixes for
     * monetary values.
     *
     * @param      monetary number formatter
     */

    public void monetary(NumberFormat nf){
        DecimalFormat cf;

        if (nf.getClass() != DecimalFormat.class)
            return;
        cf = (DecimalFormat)nf;
        cyPosPref = affixMsk(cf.getPositivePrefix(),this);
        cyPosSuff = affixMsk(cf.getPositiveSuffix(),this);
        cyNegPref = affixMsk(cf.getNegativePrefix(),this);
        cyNegSuff = affixMsk(cf.getNegativeSuffix(),this);
    }

    /**
     * Deliver the mask that represents an affix.
     *
     * @param      aff affix
     * @param      locData locale data
     * @return     mask
     */

    /*
     * These are the supported affixes:
     * <p>
     * prefixes: "" "(" "($" "($ " "-" "-$" "-$ " "$-" "$ -" "$" "$ "
     * suffixes: "" "$)" " $)" ")" "$" " $" "-"
     * <p>
     * The given (locale) affix is parsed to determine its contents,
     * which is coded as:
     * <ul>
     * <li>b0  $
     * <li>b1  sp before
     * <li>b2  sp after
     * <li>b3  (
     * <li>b4  )
     * <li>b5  - minus before
     * <li>b6  - minus after
     * </ul>
     */

    public byte affixMsk(String aff, LocNumData locData){
        int    l;
        int    msk = 0;
        char   c;
        char   sp = ' ';
        char   minus = locData.minusSign;

        l = aff.length();
        if (l > 0){                                // affix present
            c = aff.charAt(0);
            if (c == '('){ msk |= 1<<3;            // (...
            } else if (c == ')'){ msk |= 1<<4;     // )...
            } else if (c == minus){ msk |= 1<<5;   // -...
            } else if (Character.isSpaceChar(c)){  // suffix
                msk |= 1<<1;
                sp = c;
            } else {
                msk |= 1<<0;
            }
            if (l > 1){
                msk |= 1<<0;
                c = aff.charAt(l-1);
                if (Character.isSpaceChar(c)){
                    msk |= 1<<2;
                    sp = c;
                }
                if (c == minus){ msk |= 1<<6;
                } else if (c == ')'){ msk |= 1<<4; }
            }
        }
        locData.space = sp;
        if ((msk & 1<<0) != 0){
            int l1 = this.intnCsign.length();
            int l2 = this.csign.length();
            this.affLength += (l1 > l2) ? l1 : l2;
        }
        for (int x = 1; x <= 6; x++){
            if ((msk & 1<<x) != 0) this.affLength++;
        }
        return (byte)msk;
    }
}
