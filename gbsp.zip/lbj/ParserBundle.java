/*
 * @(#)ParseBundle.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;

/**
 * The <code>ParserBundle</code> class provides the English locale for
 * the <code>Parser</code> class.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

public class ParserBundle extends ListResourceBundle {
    public Object[][] getContents() {
        return contents;
    }

    // LOCALIZE THIS

    public static final String[] MSGTAB = {

        //  informational

        "SUCCESS, successful operation",                     //  0
        "",                                                  //  1

        //  warnings

        "BADTOK, bad token",                                 //  2
        "NOREC, sentence not recognised",                    //  3
        "",                                                  //  4
        "STRNCL, string not closed",                         //  5
        "BADLIN, too long line, truncated",                  //  6
        "DEADEND, no terminal string produced",              //  7
        "NOGEN, not generated from the starting symbol",     //  8
        "SKIP, text skipped",                                //  9
        "MULOCC, multiple occurrence",                       // 10
        "NTNCL, nonterminal not closed",                     // 11
        "ULESS, useless element",                            // 12
        "NOLEX, defined in LEXIS, but not a lexeme",         // 13
        "DEADALT, alternative produces no terminal strings", // 14
        "HIDNT, definition hides a nonterminal",             // 15
        "",                                                  // 16
        "EXERR, illegal input",                              // 17
        "TRMERR, TERMINALS used in it, ignored",             // 18

        //  errors

        "PREEND, premature end of input",                    // 19
        "EXCCHAR, exceeding character(s)",                   // 20
        "ILLSTMT, illegal statement",                        // 21
        "MULDEF, multiple definition",                       // 22
        "MISTOK, missing",                                   // 23
        "MISFAC, missing factor",                            // 24
        "MISNT, missing nonterminal",                        // 25
        "MISNUM, missing number",                            // 26
        "NOTCHAR, non-character symbol",                     // 27
        "MISNAM, missing name",                              // 28
        "MISTER, missing terminal",                          // 29
        "CIRDEF, circular definition",                       // 30
        "LEXUSE, illegal use of lexeme",                     // 31
        "MISEL, missing element",                            // 32
        "UNLEX, undefined lexeme",                           // 33
        "MULNTR, multiple definition of nonterminal",        // 34
        "UNDEF, undefined nonterminal",                      // 35
        "DUPPROD, duplicated production",                    // 36
        "NOUSE, does not redefine itself",                   // 37
        "MULREP, replaces a nonterminal already replaced elsewhere",  // 38
        "SYNNT, illegal use of a syntax nonterminal",        // 39
        "NREG, non regular lexicon, lexer not generated",    // 40
        "DISEXP, the constraint is useless",                 // 41
        "ILLNUM, illegal number",                            // 42
        "NACONS, construct not allowed here",                // 43
        "ILLDEF, illegal definition",                        // 44
        "NOTALL, element not allowed",                       // 45
        "EMPLEX, produces the empty string or no string",    // 46
        "EMPRNG, empty range",                               // 47
        "CASEIN, case-insensitivity not allowed here",       // 48
        "OUTALPHA, terminal (string) not in alphabet",       // 49
        "ILLAUTO, autoreference not allowed",                // 50
        "NOTSET, does not represent a set of characters",    // 51
        "MISKEY, missing keyword",                           // 52
        "CONFLGR, grammar with conflicts",                   // 53
        "",                                                  // 54
        "",                                                  // 55
        "",                                                  // 56
        "",                                                  // 57
        "",                                                  // 58
        "",                                                  // 59

        //  fatals

        "NOCORE, insufficient core",                         // 60
        "UNEXLIN, unexpected line(s)",                       // 61
        "EMPTYG, empty grammar",                             // 62
        "MISGRA, missing GRAMMAR",                           // 63
        "IOERR, i/o error",                                  // 64
        "NOTSTART, missing start nonterminal",               // 65
        "UNDEFS, undefined starting nonterminal",            // 66
        "LISTING, error while creating listing",             // 67
        "OUTLIMIT, limits exceeded",                         // 68
        "TRCFLAG, illegal trace flag:",                      // 69
        "NOUSEST, useless starting nonterminal",             // 70
        "COMNCL, comment not closed",                        // 71
        "EXCLEX, too large lexer",                           // 72
        "EXCPRS, too large parser",                          // 73
        "ERRGRA, erroneous grammar",                         // 74
        "NOCPUT, cpu time cannot be measured",               // 75
        "COMNOP, comment not open",                          // 76
    };

    private static final Object[][] contents = {
        {"MSGTAB",     MSGTAB},
        {"SOURCE",     "Source text"},
        {"SUMMARY",    "Summary"},
        {"NONTER",     "Non-terminals"},
        {"TERMINALS",  "Terminals"},
        {"SHORTHANDS", "Shorthands"},
        {"REPLACEMS",  "Replacements"},
        {"NAME",       "name"},
        {"LINE",       "line"},
        {"USAGE",      "usage"},
        {"ATTRS",      "attributes"},
        {"LEXEME",     "lexeme"},
        {"LEXEMES",    "Lexemes"},
        {"ONLY",       "only"},
        {"AUTOINC",    "autoinclusive"},
        {"TYPE2",      "type-2"},
        {"REGULAR",    "regular"},
        {"TYPE3F",     "finite"},
        {"REDEFINED",  "redefined"},
        {"ORIGIN",     "origin"},
        {"TOTAL",      "Total"},
        {"NTEMP",      "Non-terminals that produce the empty string"},
        {"REPEMP",     "Replacements that produce the empty string"},
        {"NTEMPONLY",  "Non-terminals that produce the empty string only"},
        {"REPEMPONLY", "Replacements that produce the empty string only"},
        {"UNDEF",      "undefined"},
        {"LEXERTAB",   "Lexer tables size"},
        {"PARSERTAB",  "Parser tables size"},
        {"TOKSETS",    "Tokens sets"},
        {"GENTIM",     "Generation time"},
        {"PRSTIM",     "Parse time"},
        {"MILLIS",     "millisecond(s)"},
        {"PARSING",    "Parsing"},
        {"STATS",      "Statistics"},
        {"TREE",       "Parse tree"},
        {"TRANSL",     "Translation"},
        {"GRAMMAR",    "Grammar"},
        {"LL1",        "LL(1)"},
        {"CFG",        "Context-free"},
        {"LITERAL",    "literal"},
    };

    // END OF MATERIAL TO LOCALIZE
}
