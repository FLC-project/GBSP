/*
 * @(#)ParserFA.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;
import java.io.*;
import lbj.ParserLexer.*;
import lbj.ParserNode.*;
import lbj.ParserGrammar.*;
import lbj.CaseFolding.*;

/**
 * The <code>ParserFA</code> represents (unencoded) Finite Automa.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

/* This class contains the building blocks to construct automata, such as
 * states and transitions (edges) and to operate on them: converting into
 * DFAs, minimizing, comparing, etc.
 *
 * To speed up minimization, a hash table is kept to make transitions
 * with sets of characters on them, represented as IntSets objects, unique
 * so as to test equality in a fast way. To have it, the methods which
 * create transitions use an hash table. This is done there instead of
 * inside minimization because there would be there a need to visit all
 * edges and unify the ones that represent the same set of characters with
 * distinct IntSet objects.
 * To merge FAs in such a way that the result can be minimised, only one
 * table is kept and used for all the FAs. This is done by allocating it
 * the first time, and passing it to the constructor.
 *
 * The temporary storage needed by the methods is placed in FAs so as
 * to allow operations such as NFA to DFA transformation to be callable
 * one inside another should there be a need to do it.
 */

class ParserFA implements Cloneable {

    /** The reference to the grammar object. */
    private ParserGrammar gram;

    /** The lexer object for error reporting. */
    private ParserLexer lex;

    /** The head of the list of the states. */
    ParserState sthead;

    /** The tail of the list of the states. */
    private ParserState sttail;

    /** The start state. */
    ParserState startState;

    /** The end state (for automa with one end state). */
    ParserState endState;

    /** The number of the states. */
    private int numOfStates;

    /** The enclosing automa. */
    private ParserFA father;

    /** The trace flags. */
    int trc;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    g   main actions
     *    h   details
     * </pre></blockquote><p>
     */

    static final int FL_G = 1 << ('g'-0x60);
    static final int FL_H = 1 << ('h'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Construct a Finite Automa.
     *
     * @param      gram reference to the grammar object
     * @param      trc trace flags
     * @param      tok token table
     * @param      hash hashtable for transitions
     */

    ParserFA(ParserGrammar gram, int trc, ParserDic[] tok, Map<IntSet,IntSet> hash){
        this.gram = gram;
        if (gram != null) this.lex = gram.lex;
        this.trc = trc;
        this.tokTable = tok;
        this.symbMap = hash;
        if (hash == null) this.symbMap = new HashMap<IntSet,IntSet>();
        if ((FL_G & this.trc) != 0){
            Trc.out.println("new FA");
        }
    }

    /**
     * Construct a Finite Automa with the grammar reference, trace
     * flags, token table, etc. as for the given enclosing one, and
     * with a start and end states.
     *
     * @param      fa reference to the enclosing fa
     */

    ParserFA(ParserFA fa){
        this.gram = fa.gram;
        this.lex = fa.lex;
        this.trc = fa.trc;
        this.tokTable = fa.tokTable;
        this.symbMap = fa.symbMap;
        if (fa.symbMap == null) this.symbMap = new HashMap<IntSet,IntSet>();
        if ((FL_G & this.trc) != 0){
            Trc.out.println("new FA");
        }
        this.stini = fa.stini;
        this.stfin = fa.stfin;
        this.startState = newState();   // allocate its initial state
        this.endState = newState();     // allocate its final state
        this.endState.status |= ParserState.FINAL;
        this.father = fa;
    }

    /**
     * Clone this object.
     *
     * @return     a copy of the object
     */

    public Object clone(){
        ParserFA t = null;
        try {
            t = (ParserFA)super.clone();
            t.stini = new ParserState[this.stini.length];
            t.stfin = new ParserState[this.stfin.length];
            t.sthead = null;
            t.sttail = null;
            ParserState[] map = new ParserState[t.numOfStates];
            for (ParserState h = this.sthead;     // clone states
                h != null; h = h.next){
                ParserState s = (ParserState)h.clone();
                map[h.num] = s;
                if (t.sthead == null){            // append state to list
                    t.sthead = s;
                } else {
                    t.sttail.next = s;
                }
                t.sttail = s;
                s.tokset = (IntSet)h.tokset.clone();
                if (h.nfa_name != null){
                    s.nfa_name = (ParserState[])h.nfa_name.clone();
                }
                s.list = null;
            }
            for (ParserState h = t.sthead;        // clone transitions
                h != null; h = h.next){
                h.parent = map[h.parent.num];
                ParserTrans pr = null;
                for (ParserTrans ts = h.transList;
                    ts != null; ts = ts.next){
                    ParserTrans tn = (ParserTrans)ts.clone();
                    tn.nextState = map[ts.nextState.num];
                    if (pr == null){              // append
                        h.transList = tn;
                    } else {
                        pr.next = tn;
                    }
                }
            }
        } catch (CloneNotSupportedException e){
        }
        return t;
    }

    /**
     * An automaton state.
     */

    static class ParserState implements Cloneable {

        /** The number of the state. */
        int num;

        /** The reference to the next state in the list. */
        ParserState next;

        /** The head of the transition list. */
        ParserTrans transList;

        /** The head of the temporary list. */
        ParserState list;

        /** The reference to the parent state. */
        private ParserState parent;

        /** The reference to set of NFA states represented by a DFA one. */
        private ParserState[] nfa_name;

        /** The reference to the set of recognised tokens. */
        IntSet tokset;

        /** The marked status. */
        private static final int MRK = 1 << 0;

        /** The special state status. */
        private static final int SPECIAL = 1 << 1;

        /** The looping state status. */
        private static final int LOOPING = 1 << 2;

        /** The save state status. */
//????
        private static final int SAVE = 1 << 3;

        /** The final state status. */
        static final int FINAL = 1 << 4;

        /** The nonpurgeable status. */
        private static final int NOPURGE = 1 << 5;

        /** The visited status. */
        private static final int VISITED = 1 << 6;

        /** The reached with a non-empty edge status. */
        private static final int HEAVY = 1 << 7;

        /** The reached with a non-empty loop status. */
        private static final int HEAVY_LOOP = 1 << 8;

        /** The status. */
        int status;

        /** 
//        private cbkn       node_ptr_t         // pointer to callback node

        /**
         * Clone this object.
         *
         * @return     a shallow copy of the object
         */

        public Object clone(){
            ParserState t = null;
            try {
                t = (ParserState)super.clone();
            } catch (CloneNotSupportedException e){
            }
            return t;
        }

        /**
         * Deliver a string representing the input symbols on this transition.
         *
         * @return     string
         */

        public String toString(){
            return Integer.toString(this.num);
        }

        /**
         * Deliver a string representing the name of a DFA state as
         * set of NFA state numbers.
         *
         * @return     string
         */

        public String dfaName(){
            ParserState[] nf = this.nfa_name;
            Str st = new Str();
            st.append("(");
            int len = (nf == null) ? 0 : nf.length;
            for (int i = 0; i < len; i++){
                st.append(Integer.toString(nf[i].num));
                if (i < nf.length-1){
                    st.append(",");
                }
            }
            st.append(")");
            return st.toString();
        }

        /**
         * Trace a state.
         *
         * @param   full <code>true</code> to have extensive trace
         */

        private void trace(boolean full){
            if (full){
                Trc.out.println("---state: " +
                    System.identityHashCode(this) + "----");
                Trc.out.println("num:      " + this.num);
                Trc.out.println("next:     " + this.next);
                Trc.out.println("transList:" + this.transList);
                Trc.out.println("list:     " + this.list);
                Trc.out.println("parent:   " + this.parent);
                Trc.out.print("nfa_name: ");
                traceNfan(nfa_name);
                Trc.out.println();
                Trc.out.println("mrk:      " + ((MRK & this.status) != 0));
                Trc.out.println("special:  " + ((SPECIAL & this.status) != 0));
                Trc.out.println("looping:  " + ((LOOPING & this.status) != 0));
                Trc.out.println("save:     " + ((SAVE & this.status) != 0));
                Trc.out.println("final:    " + ((FINAL & this.status) != 0));
                Trc.out.println("tokset:   " + this.tokset);
/*
                if (cbkn == null){
                    Trc.out.println("cbkn:     null");
                } else {
                    Trc.out.println("cbkn:     " + cbkn.cbk);
                }
*/
                traceTrans(this.transList);
            } else {
                Trc.out.println("state: " + this.num +
                    (((FINAL & this.status) != 0) ? " final" : ""));
                traceNfan(this.nfa_name);
/*
                if (cbkn != null){
                   Trc.out.println(">>" + cbkn.cbk);
                }
*/
                Trc.out.println(this.tokset);
                for (ParserTrans t = this.transList;
                    t != null; t = t.next){
                    t.trace();
                }
            }
        }
    }

    /**
     * Construct a state and link it to the list of states.
     */

    ParserState newState(){
        ParserState s = new ParserState();
        s.num = this.numOfStates++;
        if (this.sthead == null){      // append state to list
            this.sthead = s;
        } else {
            this.sttail.next = s;
        }
        this.sttail = s;
        if ((FL_G & this.trc) != 0){
            Trc.out.println("new_state: " + s.num);
        }
        return s;
    }

    /**
     * Construct the specified state if not already present.
     *
     * @param      n number of the state
     */

    ParserState newState(int n){
        ParserState pr = null;
        for (ParserState s = this.sthead;   // locate state
            s != null; s = s.next){
            if (s.num == n){                // found
                return s;
            } else if (s.num > n){          // point found
                break;
            }
            pr = s;
        }
        ParserState s = new ParserState();
        s.num = n;
        if (pr == null){                    // insert at beginning
            s.next = this.sthead;
            this.sthead = s;
        } else {                            // insert in the middle
            s.next = pr.next;
            pr.next = s;
        }
        int max = 0;
        for (ParserState h = this.sthead; h != null;
            h = h.next){
            if (h.num > max) max = h.num;
        }
        this.numOfStates = max + 1;
        if ((FL_G & this.trc) != 0){
            Trc.out.println("new_state: " + s.num);
        }
        return s;
    }

    /**
     * An automaton transition.
     */

    static class ParserTrans implements Cloneable {

        /** The reference to the next transition in the list. */
        ParserTrans next;

        /** The reference to the next state. */
        ParserState nextState;

        /** The kind of input. */
        private int kind;

        /** The symbol kind. */
        private static final int SYM = 0;

        /** The empty kind. */
        private static final int EMPTY = 1;

        /** The set kind. */
        private static final int SET = 2;

        /** The symbol input. */
        private int sym;

        /** The (nonempty) set input. */
        IntSet set;

        /**
         * Clone this object.
         *
         * @return     a shallow copy of the object
         */

        public Object clone(){
            ParserTrans t = null;
            try {
                t = (ParserTrans)super.clone();
            } catch (CloneNotSupportedException e){
            }
            return t;
        }

        /**
         * Deliver a string representing the input symbols on this transition.
         *
         * @param      st string
         */

        public void toString(Str st){
            switch (this.kind){
            case EMPTY:
                st.append("\"\"");
                break;
            case SYM:
                symToLit(this.sym,st);
                break;
            case SET:
                this.set.toString(st,true);
                break;
            }
        }

        /**
         * Deliver a string representing the input symbols on this transition.
         *
         * @return     string
         */

        public String toString(){
            Str st = new Str();
            toString(st);
            return st.toString();
        }

        /**
         * Trace this transition.
         */

        private void trace(){
            Trc.out.println(toString() + " " + nextState);
        }
    }

    /**
     * Insert in a string the representation of an input symbol.
     *
     * @param      s symbol
     * @paran      st string
     */

    private static void symToLit(int s, Str st){
        int l = st.length;
        st.append((char)s);
        st.strQuoted(st.buffer,l,1,st);
        st.cutInsert(l,1,(char[])null,0,0,0);
/*
        CASE s OF
        (t_bos): t = "BOS";
        (t_bol): t = "BOL";
        (t_eol): t = "EOL";
        (t_eos): t = "EOS";
        } else {
            str_lit (""//CHAR(s),t);
        ESAC;
*/
    }

    /**
     * Construct a transition between two states.
     *
     * @param      fs from state
     * @param      ts to state
     * @param      s input symbol
     */

    ParserTrans newTrans(ParserState fs, ParserState ts, int s){
        return appendTrans(fs,ParserTrans.SYM,s,null,ts);
    }

    /**
     * Construct a transition between two states.
     *
     * @param      fs from state
     * @param      ts to state
     * @param      s set of input symbols
     */

    ParserTrans newTrans(ParserState fs, ParserState ts, IntSet s){
        IntSet set = uniqueIntSet(s);
        return appendTrans(fs,ParserTrans.SET,0,set,ts);
    }

    /** The hashtable to make unique the sets of symbols as objects. */
    private Map<IntSet,IntSet> symbMap;

    /**
     * Deliver a unique IntSet object by taking the one stored in a
     * hash table which is equal to the specified one, if any present,
     * or by storing (and returning) the specified one otherwise.
     *
     * @param      s the set
     */

    private IntSet uniqueIntSet(IntSet s){
        IntSet set;
        set = (IntSet)(this.symbMap.get(s));
        if (set == null){
            set = new IntSet(s,0);
            this.symbMap.put(set,set);
        }
        return set;
    }

    /**
     * Construct a transition between two states for the empty string.
     *
     * @param      fs from state
     * @param      ts to state
     */

    ParserTrans newTrans(ParserState fs, ParserState ts){
        return appendTrans(fs,ParserTrans.EMPTY,0,null,ts);
    }

    /**
     * Append a transition to the list of transitions of a state.
     *
     * @param      fs from state
     * @param      k kind
     * @param      sym scalar symbol
     * @param      set set of characters
     * @param      ts to state
     */

    private ParserTrans appendTrans(ParserState fs, int kind,
        int sym, IntSet set, ParserState ts){
        ParserTrans t;
        sea: {
            ParserTrans pr = null;
            for (t = fs.transList;
                t != null; t = t.next){      // find transition or last
                if ((t.nextState == ts) &&   // do not insert duplicates
                    (t.kind == kind) &&
                    (t.sym == sym) &&
                    (t.set == set)){
                    break sea;
                }
                if (((kind == ParserTrans.SYM) ||
                    (kind == ParserTrans.SET)) &&
                    ((t.kind == ParserTrans.SYM) ||
                    (t.kind == ParserTrans.SET))){
                    if (t.nextState == ts){          // merge
                        IntSet m;
                        if (t.kind == ParserTrans.SET){
                            m = new IntSet(t.set);
                        } else {
                            m = new IntSet(t.sym);
                        }
                        if (set == null){            // single symbol
                            m.add(sym);
                        } else {                     // set
                            m.add(set);
                        }
                        t.kind = ParserTrans.SET;
                        t.set = uniqueIntSet(m);
                        break sea;
                    }
                }
                pr = t;
            }
            t = new ParserTrans();
            t.nextState = ts;
            t.kind = kind;
            t.set = set;
            t.sym = sym;
            if (pr == null){                // append
                fs.transList = t;
            } else {
                pr.next = t;
            }
        } // sea
        if ((FL_G & this.trc) != 0){
            Trc.out.println("trans: " + fs +
                " -" + t + "-> " + t.nextState);
        }
        return t;
    }

    /**
     * Trace a list of transitions.
     *
     * @param      t head of the list of transitions
     */

    private static void traceTrans(ParserTrans t){
        Trc.out.println("---transition list: ");
        if (t == null){
            Trc.out.println("null");
        } else {
            Str st = new Str();
            for (; t != null; t = t.next){
                st.length = 0;
                t.toString(st);
                st.shrink(23);
                for (int i = st.length; i < 25; i++){
                    st.append(' ');
                }
                Trc.out.println("s: " + st + "  next: " +
                    t.nextState);
            }
        }
    }

    /**
     * Deliver a string representing a list of transitions.
     *
     * @param      t head of the list of transitions
     * @param      n <code>true</code> to have nfa state names in dfa states
     * @param      st return string
     */

    static void transToString(ParserTrans t, boolean n, Str st){
        st.append('{');
        for (; t != null; t = t.next){
            t.toString(st);
            st.append("->");
            if (n){
                st.append(t.nextState.dfaName());
            } else {
                st.append(t.nextState.toString());
            }
            if (t.next != null) st.append(", ");
        }
        st.append('}');
    }

    /**
     * Trace the names of the NFA states represented by a DFA one.
     *
     * @param      nf reference to the set
     */

    private static void traceNfan(ParserState[] nf){
        if (nf != null){
            Trc.out.print("(");
            for (int i = 0; i < nf.length; i++){
                Trc.out.print(nf[i]);
                if (i < nf.length-1){
                    Trc.out.println(", ");
                }
            }
            Trc.out.println(")");
        }
    }

    /**
     * Trace the automaton.
     *
     * @param      num <code>true</code> to have the nfa names,
     *             <code>false</code> to have the numbers
     * @param      lex <code>true</code> to trace the names of the recognized
     *             tokens
     * @param      eclo <code>true</code> to trace the e-closure
     *             of states
     * @param      trc the trace stream
     */

    void trace(boolean num, boolean lex, boolean eclo){
        trace(num,lex,eclo,Trc.wrt);
    }

//    void trace(boolean num, boolean lex, boolean eclo, PrintStream trc){
    void trace(boolean num, boolean lex, boolean eclo, PrintWriter trc){
        Str st = new Str();
        for (ParserState h = this.sthead; h != null; h = h.next){
            st.length = 0;
            transToString(h.transList,(h.nfa_name != null) & num,st);
            trc.print(
                (((h.nfa_name == null) | !num) ? h.toString() : h.dfaName()) +
                (((ParserState.FINAL & h.status) != 0) ? "*:" : ":") +
                " " + st);
            if (eclo){
                st.length = 0;
                e_closureToString(h,st);
                trc.print(" e-closure: {" + st + "}");
            }
            if ((h.tokset != null) && lex){
                trc.print(" ");
                trc.print(tokensToString(h.tokset));
            }
            trc.println();
        }
    }

    /**
     * Deliver a string representing a set of tokens.
     *
     * @param      s reference to the set
     * @return     string, null if there is no set
     */

    public String tokensToString(IntSet s){
        Str st = new Str();
        if (s != null){
            int[] lset = s.toArray();
            for (int i = 0; i < lset.length; i++){
                if (i > 0) st.append(" ");
                st.append(this.tokTable[lset[i]].toString());
            }
            return st.toString();
        }
        return null;
    }

    /**
     * Determine the states which can be reached starting from a given
     * list of states by following the empty edges.  The states in the
     * list are left marked.
     *
     * @param      s head of the list
     */

    /* It keeps a list of transitions which represent the reacheable
     * states. When visiting the list, other states are added if they
     * are not marked. Effectively, their transition list is appended
     * to the current one.
     * When no more states can be added, the current list contains the
     * closure.
     */

    private void e_closure(ParserState s){
        if ((FL_H & this.trc) != 0){
            Trc.out.print("e_closure of: ");
        }
        ParserState h = s;
        for (; h != null; h = h.list){        // mark the states in the list
            if ((FL_H & this.trc) != 0){
                Trc.out.print(" " + h);
            }
            h.status |= ParserState.MRK;
        }
        if ((FL_H & this.trc) != 0){
            Trc.out.println();
        }
        h = s;
        for (; h != null; h = h.list){        // scan the list
            if ((FL_H & this.trc) != 0){
                Trc.out.println("visiting: " + h);
            }
            ParserState ta = h;
            ParserTrans tr = h.transList;
            for (; tr != null; tr = tr.next){
                if (tr.kind != ParserTrans.EMPTY) continue;
                if ((ParserState.MRK & tr.nextState.status) != 0){
                    continue;
                }
                tr.nextState.status |=
                    ParserState.MRK;          // mark it as belonging to the closure
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("also: " + tr.nextState);
                }
                tr.nextState.list = ta.list;  // put state into list after the current
                ta.list = tr.nextState;
                ta = tr.nextState;
            }
        }
    }

    /**
     * Remove the marks from a list of states.
     *
     * @param      s head of the list
     */

    private static void rem_mrk(ParserState s){
        for (; s != null; s = s.list){
            s.status &= ~(ParserState.MRK |
                ParserState.HEAVY);            // remove marks
        }
    }

    /**
     * Deliver a string representing the e-closure of a state.
     *
     * @param      s reference to the state
     */

    void e_closureToString(ParserState s, Str st){
        e_closure(s);                    // do the closure
        rem_mrk(s);                      // remove marks
        for (; s != null; s = s.list){
            st.append(s.toString());
            if (s.list != null) st.append(", ");
        }
    }

    /** The table which maps token numbers to their nodes. */
    ParserDic[] tokTable;

    /**
     * Build the NFA from the token rules.
     */

    /* Shape of automa
     *
     * The automaton which represent the empty language has either one
     * non-accepting state, or two unconnected states.
     * The second form is used when combining automa.
     * The lexing engine, when run on it, returns an empty set of recognised
     * tokens.
     *
     * The Thompson construction is used, with the exception that union
     * is obtained by merging the start and end states.
     * One initial state is created, and the NFAs of the lexemes
     * plugged directly into it. This spares from generating e-edges,
     * which would be needed if a dedicated NFA was created for each
     * lexeme. However, to make the check that the NFA of each lexeme
     * contains only terminals belonging to the alphabet, the edges
     * of the initial states are isolated, and merged later with
     * the ones of the NFAs of the other lexemes.
     *
     * The construction of NFAs when operations (difference, intersection,
     * complement) on operands which are sets of characters occur is optimized.
     * The set operations are applied directly on the sets contained in the
     * NFA representations of the operands. All NFA constructions produce
     * directly a single edge when the operands are sets instead of building
     * NFAs:
     *      - alternatives: when they are both single-edge to the same end
     *        state, the second is added to the first
     *      - set complements: they apply only to single-edge, and thus
     *        produce a single-edge
     *      - groups: only the simple ones can produce a set; when applied on
     *        single-edge, produce a single edge
     *      - nonterminals: when their definitions are single-edge, no
     *        enveloping with e-edges is done
     *      - differences and intersections: when the operands are single-edge,
     *        the operation is performed directly
     *
     * The lexer generator works also without knowing TR, EM, TY2, etc.,
     * when there are cycles (they are treated as left autoreferences with
     * an empty string as repetead body, which is then descarted when the DFA
     * is built), undefined nonterminals (a disconnected NFA is generated and
     * then reduced), empty strings, and autoinclusions (a disconnected NFA
     * is generated).
     * No NFA is built for nonterminals which contain autoreferences in
     * operands since it produces several NFAs which reference each other,
     * which is a problem for some algorithms. To block this, a prepass is
     * done to flag as the ones that does.
     * There is no need that the encoded automa work properly when errors are
     * present.
     *
     * Alphabet
     *
     * When computing the alphabet, VT is set temporarily to full Unicode.
     * If there are errors in the alphabet, it is set it to full Unicode
     * so as to avoid further error messages for errors that might not be
     * there.
     * To check that token rules produce strings which belong to VT+, a check
     * is done that all the sets in transitions of the DFA belong to
     * the alphabet. Note that it would not be correct to check that the
     * terminal characters belong to the alphabet by visiting the terminal
     * dictionary since in it there are also terminals that appear as second
     * operand in differences. With difference and intersection, the second
     * operand can only subset the first, and thus if in the result there are
     * extra-alphabet characters, an error could be reported on the first
     * operand. However, this can only be done on lexemes since it is
     * rather difficult to figure out how the nonteminals used by it contribute
     * to the final result. E.g. there can be one nonterminal which occurs
     * as second operand in difference in a lexeme and as first in another
     * one, and that contains extra-alphabet characters.
     * Since it is not possible to check nonterminals, but only lexemes,
     * errors appear only on lexemes.
     *
     * Errors
     *
     * The easiest way to check conditions on the operands is to do it
     * when generating the NFA.
     * To check the legality of set complement and ranges, a solution is
     * to synthetise (possibly on the fly during a recursive visit)
     * an attribute which tells that a node generates a set of characters:
     * a terminal which is a character and a range have it set, alternatives,
     * difference, intersection keep it set.
     * This would be better than issuing errors during the generation of NFAs.
     * However, this is not simple when there are complement, difference and
     * intersection. It would help if such an attribute could be computed
     * before generating the NFA, which is not the case since the only way is
     * to build a NFA.
     * Moreover, this does not help for ranges since it is not possible to
     * know if an element which is a set contains only one element, including
     * when it has a case-insensitive clause. Therefore it is not done.
     * For ranges there is a need to determine what nonterminal produces a
     * character in order to check the legality of the ranges anyway, i.e.
     * irrespectively on supporting the complement and the other operations.
     *
     * When there are errors because of autoreferences in operands, the
     * calculation of the Chomsky type can provide wrong results.
     * However, not calculating it can produce many errors on nonterminals
     * which are correct. Therefore, the calculation of the attributes
     * TR, EM and EO is done always (which can provide wrong results) so as
     * to allow the algoritm which computes the type to do its best.
     * The NFA is generated when there are errors anyway so as to calculate
     * EM, EO, and TR.
     *
     * The check that token rules do not generate the empty language or the
     * empty string is obtained by setting  -TR on them.
     */

    public void buildNfa(){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("--- build_nfa init ---");
        }
        int tokMax = -1;                         // maximum token number.
        for (ParserNode a = this.gram.lex_list;  // scan lexemes
            a != null; a = a.alt){
            if (a.def.tokNum > tokMax){
                tokMax = a.def.tokNum;
            }
        }
        this.tokTable = new ParserDic[tokMax+1]; // fill lexemes table
        for (ParserNode a = this.gram.lex_list;
            a != null; a = a.alt){
            this.tokTable[a.def.tokNum] = a.def;
            if ((FL_G & this.trc) != 0){
                Trc.out.println(a.def.tokNum + " " + a);
            }
        }

        int cnt = 0;
        for (ParserDic h = this.gram.ntDic.head; // number the nonterminals
            h != null; h = h.suc){               // .. used in lexis
            if ((ParserNode.GRAM & h.status) != 0){
                continue;
            }
            h.ntNum = cnt++;
        }
        check_auto();                            // check autoreferences
        this.stini = new ParserState[cnt];       // temporary references
        this.stfin = new ParserState[cnt];       // .. to nonterminal NFAs

        this.gram.alphabet = new IntSet(         // process alphabet
            Character.MIN_VALUE,Character.MAX_VALUE);
        al: if (this.gram.alphaRule != null){
            boolean def = vi_def(this.gram.alphaRule);
            if (!def) break al;                  // do not generate other errors
            ParserError m = this.lex.excLast;
            ParserFA anfa = new ParserFA(this);
            anfa.vi_nfa(null,this.gram.alphaRule,
                anfa.startState,anfa.endState,0);
            ParserFA adfa = anfa.nfa_to_dfa();   // transform NFA into DFA
            alp: if (anfa.isSet()){
                if (m != this.lex.excLast){      // some errors: avoid
                    break alp;                   // .. further ones, keep
                }                                // .. largest alphabet
                ParserTrans t = anfa.startState.transList;
                if (t == null){
                    this.gram.alphabet = new IntSet();
                } else {
                    switch (t.kind){
                    case ParserTrans.SYM:
                        this.gram.alphabet = new IntSet(t.sym);
                        break;
                    case ParserTrans.SET:
                        this.gram.alphabet = t.set;
                        break;
                    }
                }
            } else {
                this.lex.message(ParserLexer.ERR_NOTSET,
                    "",this.gram.alphaRule.point);
            }
            if ((FL_G & this.trc) != 0){
                Trc.out.println("alphabet: " +
                    this.gram.alphabet.toString(true));
            }
        }

        this.sthead = null;
        this.sttail = null;
        this.numOfStates = 0;
        ParserState si = newState();             // allocates initial
        this.startState = si;
        ParserTrans siEdges = null;
        ParserTrans siLastEdge = null;
        for (ParserNode h = this.gram.lex_list;  // scan the lexemes
            h != null; h = h.alt){
            if ((ParserNode.TY2 & h.status) != 0){  // with autoref. in operands
                for (ParserNode a = h.def.def;      // set TR on its alternatives
                    a != null; a = a.alt){          // .. to suppress deadend errors
                    if ((ParserNode.TY2 & h.status) != 0){
                        a.status |= ParserNode.TR;
                    }
                }
                continue;
            }
            si.transList = null;                 // needed for alphabet check
            ParserState ps = this.sttail;
            ParserState sf = newState();         // allocate its final state
            sf.status |= ParserState.FINAL;
            sf.tokset = new IntSet(h.def.tokNum);
            if ((FL_G & this.trc) != 0){
                Trc.out.println("token: " + h +
                    " state: " + sf + " " + sf.tokset +
                    " " + ((h.def != null) ?
                    h.def.toString(0,0) : ""));
            }
            vi_nt_nfa(h.def,si,sf,0);            // build NFA for lexeme
            int b = reacheableStates(si,2,sf);          // all reacheables, and
            if ((ParserState.MRK & sf.status) != 0){    // .. nonempty paths
                if (b <= 0){
                    h.def.status |= ParserNode.TY3F;
                } else if (b >= 1){
                    // there could be a previous one that was finite
                    h.def.status &= ~ParserNode.TY3F;
                }
            }
            rem_mrk(si);

            vt: for (ParserState s = si;
                s != null; s = s.next){          // scan edges
                for (ParserTrans tr = s.transList;
                    tr != null; tr = tr.next){
                    switch (tr.kind){
                    case ParserTrans.SYM:
                        if (this.gram.alphabet.contains(tr.sym)){
                            continue;
                        }
                        break;
                    case ParserTrans.SET:
                        if (this.gram.alphabet.contains(tr.set)){
                            continue;
                        }
                        break;
                    case ParserTrans.EMPTY:
                        continue;
                    }
                    this.lex.message(
                        ParserLexer.ERR_OUTALPHA,"",h.point);
                    break vt;
                }
                if (s == si) s = ps;
            }
            if (siEdges == null){                // append to edge list
                siEdges = si.transList;
            } else {
                siLastEdge.next = si.transList;
            }
            for (ParserTrans tr = si.transList;
                tr != null; tr = tr.next){
                siLastEdge = tr;
            }
        }
        si.transList = siEdges;
        this.stini = null;                       // terminate them
        this.stfin = null;
        for (ParserDic h = this.gram.ntDic.head; // clear AIN and TY2
            h != null; h = h.suc){               // .. used here
            h.status &= ~(ParserNode.AIN | ParserNode.TY2);
        }
    }

    /** 
     * Visit a node and check that its referenced nonterminals are defined.
     *
     * @param      a reference to the node
     * @return     <code>true</code> if all nonterminals are defined
     */

    private boolean vi_def(ParserNode a){
        for (;a != null; a = a.alt){                 // scan all alternatives
            for (ParserNode s = a; s != null;        // scan all successors
                s = s.suc){
                ex: switch (s.kind){
                case ParserNode.S_TER: 
                    break;
                case ParserNode.S_NT:
                    ParserDic d = s.def;
                    if (d == null) return false;
                    if (d.def == null) return false;
                    if ((ParserNode.MRK & d.status) == 0){   
                        d.status |= ParserNode.MRK;
                        if (!vi_def(d.def)) return false;
                        d.status &= ~ParserNode.MRK;
                    }
                    break;
                }
                for (ParserNode csp = s.constr;
                    csp != null; csp = csp.suc){
                    if (!vi_def(csp.gnode)) return false;
                }
            }
        }
        return true;
    }

    /** 
     * Check that autoreferences are not present in elements which
     * are directly or indirectly operands of complement, difference, etc.
     * Register an error when there are and mark temporarily them as TY2.
     * Mark as AIN the nonterminals which contains autoreferences.
     * These attributes are cleared at the end of lexer generation.
     */

    /* This is called on all the nonterminals which could use operators
     * in their rule, i.e. all the ones which are lexemes or occur in the
     * lexicon. The check is done by visiting all the nonterminals called
     * directly and indirectly and when a reference is encountered which
     * is in an operand, by reporting an error on all the references inside
     * it to the origin nonterminal.
     * Since this is done on all nonterminals which are in the lexicon,
     * all the autoreferences are checked. It is much more difficult to
     * make the same check by visiting lexemes only since there would be
     * a need to check autoreferences of several nonterminals on a single
     * visit, taking into account that inside an operand only the autoreferences
     * to nonterminals which have been encountered before entering in it
     * must be rejected.
     */

    private void check_auto(){
        for (ParserDic h = this.gram.ntDic.head;
            h != null; h = h.suc){
            if (h.def == null) continue;       // no definition
            if (((ParserNode.LEXEME |          // do not visit the unreacheables
                ParserNode.LXS) & h.status) == 0){
                continue;                      // no operators in grammar
            }
            vi_nt_ckauto(h,h,false);
            this.gram.ntDic.unmark(false);     // remove marks
        }
    }

    /** 
     * Check that a reference to a given nonterminal is not present in an
     * element which is directly or indirectly an operand of complement,
     * difference, etc. Register an error if it is, and mark the nonterminal
     * as type-2.
     *
     * @param      h reference to the element
     * @param      k reference to the nonterminal
     * @param      oper <code>true</code> if inside an operator
     */

    private void vi_nt_ckauto(ParserDic h, ParserDic k, boolean oper){
        if ((FL_G & this.trc) != 0){
            Trc.out.printf("ck_auto: start %s %s\n",h,oper);
        }
        h.status |= ParserNode.MRK;
        for (ParserNode a = h.def;
            a != null; a = a.alt){              // scan all alternatives
            boolean op = oper;
            if (!oper){
                l: for (ParserNode s = a;
                    s != null; s = s.suc){      // detect operator: in
                    if (((ParserNode.S_DIFF |   // .. alpha beta - gamma
                        ParserNode.S_AND) &     // .. all elements are
                        s.oper) != 0){          // .. inside an operand
                        op = true;
                        break l;
                    }
                }
            }
            for (ParserNode s = a;
                s != null; s = s.suc){          // scan all successors
                switch (s.kind){
                case ParserNode.S_NT:
                    ParserDic d = s.def;
                    if (d == null) break;
                    boolean ope = op || (s.oper != 0);
                    if ((ParserNode.MRK & d.status) != 0){
                        if (d == k){            // autoreference
                            k.status |= ParserNode.AIN;
                        }
                        au: if ((d == k) && ope){   // autoreference in operand
                            k.status |= ParserNode.TY2;
                            // avoid several identical errors
                            for (ParserError m = this.lex.excObj; m != null; m = m.next){
                                if (m.code == ParserLexer.ERR_ILLAUTO && m.post == s.point){
                                    break au;
                                }
                            }
                            this.lex.message(
                                ParserLexer.ERR_ILLAUTO,"",s.point);
                            if ((FL_G & this.trc) != 0){
                                Trc.out.printf("ck_auto: auto %s %s %s\n",s,ParserLexer.ERR_ILLAUTO,s.point);
                            }
                        }
                        continue;               // done
                    }
                    vi_nt_ckauto(d,k,ope);
                }
            }
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.printf("ck_auto: end %s %s\n",h,oper);
        }
    }

    /** The initial states of the lexemes. */
    private ParserState[] stini;

    /** The final states of the lexemes. */
    private ParserState[] stfin;

    /**
     * Build the NFA for a token rule.
     *
     * @param      h reference to the element
     * @param      is reference to the initial state
     * @param      fs reference to the final state
     * @param      ins case-insensitive kind
     */

    /* To determine if there is a left or a right autoreference, a
     * e-closure of the initial state of the sub-NFA for the current,
     * autoreferenced nonterminal is done.  If the state from which
     * the transition ought to have been placed is in the closure
     * (it is marked), then there is a left autoreference, otherwise
     * it is a right one. E.g. with <L> ::= <A> a | a .  <A> ::= <L> b | b,
     * when visiting <A>, a start ("is" argument) state is created, and
     * a transition ought to have been put on it for <L>.
     * However, <L> is already on the stack of the nonterminals being
     * visited, so it is an autoreference. If its starting state reaches
     * the "is" one with an e-transition, then it is a left autoreference.
     * Basically, the idea is that an autoreference is represented by
     * an e-transition from/to the state which represents the start/end
     * of the recognizion of the nonterminal.
     * There is a need to support autoreferences present in any nonterminal,
     * be it the one which defines a lexeme, or one which is referred to by
     * it. Thus, the arrays to hold the initial and final states are
     * dimensioned to hold references for all the nonterminals occurring
     * in the lexis.
     * There is also a need to support multiple autoreferences to a same
     * nonterminal (present in distinct alternatives).
     * When operands are processed, new FAs are created with the same
     * stini and stfin as the father one because no autoreferences are
     * allowed between operands and the enclosed nonterminals.
     * When that occurs, such lexemes are not processed here because have
     * been marked as type-2. Edges across different FAs are not supported
     * by NFA to DFA transformation, minimization, etc.
     * When no autoreferences are present, it plugs directly the generated
     * piece of automa in the specified place.
     *
     * The NFA is built by using the Thompson's construction, optimized
     * by merging the start and end states in alternatives (since each
     * of them has a NFA with no incoming edges into the start state and
     * no outgoing from the end state, they can be merged), and by
     * representing Kleene groups as one state with an edge onto itself
     * (which is correct for the same reasons).
     */

    private void vi_nt_nfa(ParserDic h, ParserState is,
        ParserState fs, int ins){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("vi_nt_nfa h: " + h + " init: " +
                is + " final: " + fs);
        }
        int tn = h.ntNum;
        if ((ParserNode.MRK & h.status) == 0){        // not yet visited
            h.status |= ParserNode.MRK;
            if ((FL_G & this.trc) != 0){
                Trc.out.println("graph for: " + h + " " + h.kind + " " +
                ((ParserNode.AIN & h.status) != 0));
            }
            if (h.def != null){                       // with a rule behind
                if ((ParserNode.AIN & h.status) != 0){
                    ParserState si = newState();      // allocates initial
                    ParserState sf = newState();      // allocates final
                    newTrans(is,si);                  // epsilon
                    newTrans(sf,fs);                  // epsilon
                    this.stini[tn] = si;
                    this.stfin[tn] = sf;
                    vi_nfa(h,h.def,si,sf,ins);        // scan its definition
                    this.stini[tn] = null;
                    this.stfin[tn] = null;
                } else {
                    vi_nfa(h,h.def,is,fs,ins);        // scan its definition
                }
            } else if (h.kind != ParserDic.NTER){     // terminal
                grf_str(is,fs,h,ins);                 // edge for it
            }
            h.status &= ~ParserNode.MRK;
        } else {                                      // autoreference
            this.stini[tn].list = null;               // evaluate e-closure
            int b = reacheableStates(
                this.stini[tn],0,is);                 // all reacheables
            if (b < 0){                                   // left autoreference
                if ((ParserState.MRK & is.status) != 0){  // <L> beta
                    newTrans(this.stfin[tn],fs);          // back edge
                }
            } else {                                   // right autoreference
                newTrans(is,this.stini[tn]);           // back edge
            }
            if ((FL_G & this.trc) != 0){
                Trc.out.println(
                    ((b < 0) ? "left" : "right") + " autoref.: " + h +
                    " i: " + is + " f: " + fs +
                    " stini: " + this.stini[tn] +
                    " stfin: " + this.stfin[tn]);
            }
            rem_mrk(this.stini[tn]);                  // remove e_closure marks
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("vi_nt_nfa end " + h);
        }
    }

    /**
     * Visit a rule and generate the NFA for its definition.
     *
     * @param      h reference to the element
     * @param      a reference to the rule
     * @param      is reference to the initial state
     * @param      fs reference to the final state
     * @param      ins case-insensitive kind
     */

    private void vi_nfa(ParserDic h, ParserNode a,
        ParserState is, ParserState fs, int ins){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("vi_nfa h: " + h + " init: " +
                is + " final: " + fs);
        }
        if (a == null){                           // undefined
            newTrans(is,fs);
            if ((FL_G & this.trc) != 0){
                Trc.out.println("vi_nfa TR: " + h);
            }
        }
        for (; a != null; a = a.alt){             // scan all alternatives
            if ((h != null) &&
                ((ParserNode.TY2 & h.status) != 0)){
                a.status |= ParserNode.TR;        // in error, do not
                continue;                         // .. produce other errors
            }
            if ((ParserNode.S_RNG & a.oper) != 0){
                int lo = 0;
                int hi = 0;
                if (a.def != null){               // get lower bound
                    lo = toChar(a);
                }
                if (a.alt.def != null){
                    hi = toChar(a.alt);           // get upper  bound
                }
                if ((lo > hi) && (lo >= 0) &&
                    (hi >= 0)){                   // empty
                    this.lex.message(ParserLexer.ERR_EMPRNG,
                        "",a.alt.point);
                } else if ((lo >= 0) && (hi >= 0)){
                    newTrans(is,fs,new IntSet(lo,hi));
                }
                a = a.alt;
                if (a == null) break;
            } else {
                vi_alt(h,a,is,fs,ins);            // build alternative
            }
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("vi_nfa end " + h);
        }
    }

    /**
     * Check that the specified node sequence is a valid range bound
     * and deliver it.
     *
     * @param      a reference to the sequence
     * @return     bound
     */

    private int toChar(ParserNode a){
        int res = -1;
        doit: {
            err: {
                if (a.constr != null){                  // with constraints
                    break err;
                }
                if (((a.oper == 0) ||
                       (a.oper == ParserNode.S_RNG)) && // terminal
                    (a.kind == ParserNode.S_TER) &&
                    (((ParserNode.CASEINSENS |
                       ParserNode.CASEINSENS_FULL) &    // no case clause
                       a.status) == 0) &&
                    (a.suc == null)){
                    if (a.def.code.length == 1){
                        res = a.def.code[0];
                        break doit;
                    }
                } else {
                    ParserFA op1 = new ParserFA(this);
                    op1.vi_alt(null,a,                  // build nfa
                        op1.startState,op1.endState,0);
                    if (op1.isSet()){
                        ParserTrans t1 = op1.startState.transList;
                        if (t1 != null){
                            if (t1.kind == ParserTrans.SET){
                                if (t1.set.size() == 1){
                                    res = t1.set.set[0];
                                    break doit;
                                }
                            } else if (t1.kind == ParserTrans.SYM){
                                res = t1.sym;
                                break doit;
                            }
                        }
                    }
                }
            }
            if ((FL_G & this.trc) != 0){
                Trc.out.printf("toChar: NOTCHAR\n");
            }
            this.lex.message(ParserLexer.ERR_NOTCHAR,"",a.point);
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("toChar: " + a + " : " + res);
        }
        return res;
    }

    /**
     * Visit an alterntive and generate the NFA for it.
     *
     * @param      h reference to the enclosing nonterminal
     * @param      a reference to the alternative
     * @param      is reference to the initial state
     * @param      fs reference to the final state
     * @param      ins case-insensitive kind
     */

    private void vi_alt(ParserDic h, ParserNode a,
        ParserState is, ParserState fs, int ins){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("vi_alt h: " + h + " init: " +
                is + " final: " + fs);
        }
        ParserNode op1b = a;                       // handle binary operators
        ParserNode op1e = null;
        ParserNode n = a;
        for (; n != null; n = n.suc){
            if (((ParserNode.S_DIFF |
                ParserNode.S_AND) & n.oper) != 0){
                op1e = n;
                break;
            }
        }
        if (op1e != null){
            ParserFA op1 = new ParserFA(this);
            op1.vi_conc(null,op1b,op1e,            // build nfa
                op1.startState,op1.endState,ins);
            if ((FL_G & this.trc) != 0){
                Trc.out.println("vi_nfa op1: " + op1b + "..." + op1e);
//                op1.trace(false,false,false,Trc.out);
                op1.trace(false,false,false);
            }
            while (n != null){
                ParserNode op2b = n.suc;           // second operator
                ParserNode op2e = null;
                n = n.suc;
                for (; n != null; n = n.suc){
                    if (((ParserNode.S_DIFF |
                        ParserNode.S_AND) & n.oper) != 0){
                        op2e = n;
                        break;
                    }
                }
                if ((FL_G & this.trc) != 0){
                    Trc.out.println("vi_nfa op2: " + op2b + "..." + op2e);
                }
                if ((ParserNode.S_DIFF & op1e.oper) != 0){       // difference
                    op1 = difference(op1,op2b,op2e,ins);
                } else if ((ParserNode.S_AND & op1e.oper) != 0){ // intersection
                    op1 = intersection(op1,op2b,op2e,ins);
                }
                op1e = op2e;
            }
            op1.markAttr(a);
            merge(op1,is,fs);                      // merge into current
        } else {
            vi_conc(h,a,null,is,fs,ins);
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("vi_alt end " + h + " " + a);
        }
    }

    /**
     * Determine if this NFA generates strings, the empty string, only
     * the empty strings, and a finite number of strings.
     *
     * @param      s reference to the element in which the attributes
     *             are stored
     */

    private void markAttr(ParserNode s){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("markAttr " + s);
        }
        ParserState is = this.startState;
        ParserState fs = this.endState;
        int b = reacheableStates(is,2,fs);          // all reacheables, and
        if ((ParserState.MRK & fs.status) != 0){    // .. nonempty paths
            s.status |= ParserNode.TR;
            if (b <= 0){
                s.status |= ParserNode.TY3F;
            } else if (b >= 1){
                // there could be a previous one that was finite
                s.status &= ~ParserNode.TY3F;
            }
            if ((FL_G & this.trc) != 0){
                Trc.out.println("markAttr TR: " + s);
            }
        }
        if ((ParserNode.TY2 & s.def.status) != 0){
            s.status |= ParserNode.TR;              // in error, do not
        }                                           // .. produce other errors
        rem_mrk(is);
        if ((ParserNode.EM & s.status) == 0){
            reacheableStates(is,1,fs);              // follow e-edges only
            if ((ParserState.MRK & fs.status) != 0){
                s.status |= ParserNode.EM;
                if ((FL_G & this.trc) != 0){
                    Trc.out.println("markAttr EM: " + s);
                }
            }
            rem_mrk(is);
        }
        if ((b < 0) &&
            ((ParserNode.EM & s.status) != 0)){
            s.status |= ParserNode.EO;              // no non-empty edge
            if ((FL_G & this.trc) != 0){
                Trc.out.println("markAttr EO: " + s);
            }
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("markAttr end " + s);
        }
    }

    /**
     * Visit a sequence and generate the NFA for it.
     *
     * @param      h reference to the enclosing nonterminal
     * @param      first reference to the first element of the sequence
     * @param      last reference to the last element of the sequence
     * @param      is reference to the initial state
     * @param      fs reference to the final state
     * @param      ins case-insensitive kind
     */

    private void vi_conc(ParserDic h, ParserNode first, ParserNode last,
        ParserState is, ParserState fs, int ins){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("vi_conc h: " + h + " init: " +
                is + " final: " + fs);
        }
/*
        DCL s     node_ptr_t,
                cfb   ParserState,
                s1,s2 ParserState,
                cb    ParserState,
                p     ParserTrans,
                hh    ParserDic,
                au    BOOL,
                csp   constr_ptr_t,
                q     ParserState,
                tpr   ParserTrans;
*/
        ParserState ci = is;
        for (ParserNode s = first; s != null; // scan all successors
            s = s.suc){
            if (s.constr != null){            // constraint present
                ParserState s1 = newState();  // initial state that becomes obsolete
                newTrans(ci,s1);              // epsilon
                ci = s1;
            }
            ParserState cf;
            if ((s != last) &&                // there is a sequence
                (s.suc != null)){
                cf = newState();              // allocate intermediate state
            } else {
                if (s.constr != null){        // constraint present
                    cf = newState();          // ending state that becomes obsolete
                    newTrans(cf,fs);
                } else {
                    cf = fs;                  // use the given one
                }
            }
//                if (s.cbk != null){             // callback present
//                    cb = newState();                 // allocate callback state
//                    cb.cbkn = s;
//                    cfb = cf;                      // save old state
//                    cf = cb;                       // use the new one
//                }

            int insens = 0;
            if ((ParserNode.CASEINSENS & s.status) != 0){
                insens = ParserNode.CASEINSENS;
            } else if ((ParserNode.CASEINSENS_FULL & s.status) != 0){
                insens = ParserNode.CASEINSENS_FULL;
            } else {
                insens = ins;
            }

            if ((FL_H & this.trc) != 0){
                Trc.out.println("vi_conc node: " + s +
                    " " + s.kind + " " + Integer.toHexString(s.status));
            }
            if ((ParserNode.S_COMPL & s.oper) != 0){        // set complement
                complementSet(ci,cf,s);
                ci = cf;
                continue;
            } else if ((ParserNode.S_COMCL & s.oper) != 0){ // complement
                complement(ci,cf,s,insens);
                ci = cf;
                continue;
            } else if ((ParserNode.S_UPTO & s.oper) != 0){  // upto
                upto(ci,cf,s,insens);
                ci = cf;
                continue;
            }
            vi_primary(h,s,ci,cf,insens);
            ci = cf;
            if (s == last) break;
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("vi_conc end " + h + " " + first);
        }
    }

    /**
     * Visit a primary and generate the NFA for it.
     *
     * @param      h reference to the enclosing nonterminal
     * @param      s reference to the element
     * @param      is reference to the initial state
     * @param      fs reference to the final state
     * @param      ins case-insensitive kind
     */

    private void vi_primary(ParserDic h, ParserNode s, ParserState is,
        ParserState fs, int ins){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("vi_primary h: " + h + " " + s + " init: " +
                is + " final: " + fs);
        }
        ParserState ci = is;
        ParserState cf = fs;
        int insens = ins;
        el: switch (s.kind){
        case ParserNode.S_TER:
            grf_str(ci,cf,s.def,ins);
            break;
        case ParserNode.S_NT:                         // nonterminal
            ParserDic d = s.def;
            if (d == null){
                newTrans(ci,cf);                      // bypass
                break;
            }
            if ((ParserNode.G_GRP & d.status) == 0){  // not a group
                ParserState sfin = newState();                  // new final state
                // n.b. even if ci and cf are different, there
                // could be a loop between them, so use a new state
                // so as to make reacheableStates work properly
                vi_nt_nfa(d,ci,sfin,insens);            // expand its graph

                int b = reacheableStates(ci,2,sfin);          // all reacheables, and
                if ((ParserState.MRK & sfin.status) != 0){    // .. nonempty paths
                    if (b <= 0){
                        d.status |= ParserNode.TY3F;
                    } else if (b >= 1){
                        // there could be a previous one that was finite
                        d.status &= ~ParserNode.TY3F;
                    }
                }
                rem_mrk(ci);

                newTrans(sfin,cf);
                break;
            }
            ParserNode body = d.body();
            ParserState s1;
            ParserState s2;
            switch (ParserNode.G_GRP & d.status){
            case ParserNode.G_GRO:                    // simple group
                vi_nfa(d,body,ci,cf,insens);          // expand its graph
                break el;
            case ParserNode.G_OPT:                    // optional group
                vi_nfa(d,body,ci,cf,insens);          // expand its graph
                newTrans(ci,cf);                      // bypass
                break el;
            case ParserNode.G_RE0:                    // kleene group
                if (d.def.alt != null){               // 0..inf
                    s1 = newState();                  // new initial state
                    newTrans(ci,s1);                  // link to old initial state
                    newTrans(s1,cf);                  // link to old final state
                    vi_nfa(d,body,s1,s1,insens);      // loop onto itself
                } else {                              // 0..n
                    for (ParserNode n = d.def;        // generate list of
                        n != null; n = n.suc){        // .. options
                        if (n.suc != null){
                            cf = newState();          // allocate intermediate state
                        } else {
                            cf = fs;
                        }
                        vi_nfa(d,body,ci,cf,insens);  // expand its graph
                        newTrans(ci,cf);              // bypass
                        ci = cf;
                    }
                }
                break el;
            case ParserNode.G_RE1:                    // positive group
                if (d.def.alt != null){               // l..inf
                    ParserNode base = d.def;
                    if (base.suc == null){            // s1 only if one &1
                        s1 = newState();              // new initial state
                        newTrans(ci,s1);              // link to old initial state
                        ci = s1;
                    }
                    s2 = newState();                  // new final state
                    newTrans(s2,cf);                  // link to old final state
                    for (ParserNode n = base; n != null; n = n.suc){
                        if (n.suc != null){
                            cf = newState();          // allocate intermediate state
                        } else {
                            cf = s2;
                            newTrans(cf,ci);          // loop edge
                        }
                        vi_nfa(d,body,ci,cf,insens);  // expand its graph
                        ci = cf;
                    }
                    break el;
                } else {                              // l [:h]
                    for (ParserNode n = d.def;
                        n != null; n = n.suc){
                        if (n.suc != null){
                            cf = newState();          // allocate intermediate state
                        } else {
                            cf = fs;
                        }
                        vi_nfa(d,body,ci,cf,insens);  // expand its graph
                        if (n.def != d.def.def){
                            newTrans(ci,cf);          // bypass
                        }
                        ci = cf;
                    }
                }
            }
        }
/*
                csp = s.constr;
                if (csp != null){
                    tpr = cf.transList;                // save transitions from e1
                    cf.transList = null;               // isolate NFA of e1
                    reacheableStates(ci);              // group its states
                    rem_mrk(ci);
                    q = ci;
                    while (q != null){                 // mark them
                        q.save = TRUE;
                        q = q.list;
                    }
                    while (csp != null){
                        CASE csp.kind OF
                        (c_not,c_equ,c_diff):
                            s1 = newState();               // final non-accepting state
// correct here and below?
                            vi_nfa(h,csp.node,ci,s1,ins);  // generate e2
                        (c_succ):                          // costr-succ present
                            s1 = newState();               // final non-accepting state
                            vi_nfa(h,csp.node,cf,s1,ins);  // generate e2 conc e1
                        (c_term):                          // costr-term present
                            s2 = newState();               // initial state of constr
                            q = ci;                        // from all states of e1
                            while (q != null;              // add null edge to constraint
                                all_tre (q,s2,p);
                                q = q.list;
                            }
                            s1 = newState();               // final non-accepting state
                            vi_nfa(h,csp.node,s2,s1,ins);  // generate e2 U e1
                        ESAC;
                        csp.accs = s1;
                        csp = csp.next;
                    }
                    union_nfa (ci,cf,cf,f,s.constr);       // check the constraints
                    app_tr (cf,tpr);                       // restore edges
                }
                if (s.cbk != null){                // callback present
                    all_tre (cf,cfb,p);
                    cf = cfb;
                }
*/
        if ((FL_G & this.trc) != 0){
            Trc.out.println("vi_primary end " + h + " " + s);
        }
    }

    /**
     * Build the NFA for a terminal string.
     *
     * @param   ci reference to the initial state   
     * @param   cf reference to the ending state   
     * @param   d pointer to the terminal element   
     * @param   ins case-insensitive kind
     */

    private void grf_str(ParserState ci, ParserState cf, ParserDic d,
        int ins){
        if ((FL_H & this.trc) != 0){
            Trc.out.println("grf_str");
        }
        if (d == ParserGrammar.dic_emp){                 // empty string
            newTrans(ci,cf);
            return;
        }
        ex: {
            if ((ins & ParserNode.CASEINSENS_FULL) != 0){
                char[] t = new char[d.code.length * 3];
                int n = 0;
                for (int i = 0; i < d.code.length; i++){
                    char c = d.code[i];
                    char[] map = CaseFolding.ordMap;
                    int lo = 0;
                    int hi = map.length - 4;
                    int k = 0;
                    while (lo <= hi){                    // binary search
                        k = (lo + (hi - lo ) / 2) & ~3;  // middle index
                        if (c <= map[k]) hi = k-4;       // it is above
                        if (c >= map[k]) lo = k+4;       // it is below
                    }
                    if (lo-4 > hi){                      // found
                        char ch;
                        for (int j = k+1; j < k+4; j++){
                            if ((ch = map[j]) == 0) break;
                            t[n++] = ch;
                        }
                    } else {
                        char l = Character.toLowerCase(c);
                        t[n++] = l;
                    }

                }
                if ((FL_H & this.trc) != 0){
                    Trc.out.print("variant start: ");
                    Trc.literalize(t,0,n);
                    Trc.out.println();
                }
                variantForm(t,0,n,ci,cf);
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("variant end");
                }
                break ex;
            }
            if (d.kind == ParserDic.TER_SPE){ // special
//                if (d.name-> == "BOS") newTrans(ci,cf,t_bos);
//                if (d.name-> == "BOL") newTrans(ci,cf,t_bol);
//                if (d.name-> == "EOL") newTrans(ci,cf,t_eol);
//                if (d.name-> == "EOS") newTrans(ci,cf,t_eos);
                break ex;
            }
            int l = d.code.length;
            ParserState q = ci;
            for (int i = 0; i < l; i++){      // expand string
                char c = d.code[i];
                ParserState s;
                if (i < l-1){                 // intermediate
                    s = newState();
                } else {
                    s = cf;
                }
                ParserTrans tr = newTrans(q,s,c);
                if ((ins & ParserNode.CASEINSENS) != 0){  // ASCII case insensitive
                    tr.sym = Character.toLowerCase(c);
                    if ((c <= 0x7f) &&
                        ((Str.UPPER[c] != c) || (Str.LOWER[c] != c))){
                        tr.sym = Str.LOWER[c];
                        newTrans(q,s,Str.UPPER[c]);
                    }
                }
                q = s;
            }
        }
    }

    /**
     * Build the NFA which recognizes all the case-variants of a
     * terminal string. It does not generate duplicated edges for
     * single mappings, but it does for one:string mappings because they
     * are few and difficult to remove (they are eliminated afterwards
     * anyway).
     *
     * @param   s string
     * @param   off start offset in the string
     * @param   len length of the piece of the string
     * @param   ci reference to the initial state   
     * @param   cf reference to the ending state   
     */

    private void variantForm(char[] s, int off, int len, ParserState ci,
        ParserState cf){
        if (off == len) return;
        char[] map = CaseFolding.ordMap;
        for (int i = off; i < len; i++){
            ParserState next;
            if (i < len-1){                 // intermediate
                next = newState();
            } else {                        // ending
                next = cf;
            }
            char ch = s[i];
            newTrans(ci,next,ch);
            if ((FL_H & this.trc) != 0){
                Trc.out.println(" " + ci + "-" + i + "-" +
                    Integer.toHexString(ch) + "->" + next);
            }
            char u = Character.toUpperCase(ch);
            if (u != ch){
                newTrans(ci,next,u);
                if ((FL_H & this.trc) != 0){
                    Trc.out.println(" " + ci + "-u-" +
                        Integer.toHexString(u) + "->" + next);
                }
            }
            char l = Character.toLowerCase(ch);
            boolean mapped = false;                   // find its mapping
            {
                int lo = 0;
                int hi = map.length - 4;
                int k = 0;
                while (lo <= hi){                     // binary search
                    k = (lo + (hi - lo ) / 2) & ~3;   // middle index
                    if (ch <= map[k]) hi = k-4;       // it is above
                    if (ch >= map[k]) lo = k+4;       // it is below
                }
                if (lo-4 > hi){                       // found
                    mapped = true;
                }
            }

            if ((l != ch) && (l != u) && (!mapped)){
                newTrans(ci,next,l);
                if ((FL_H & this.trc) != 0){
                    Trc.out.println(" " + ci + "-l-" +
                        Integer.toHexString(l) + "->" + next);
                }
            } else {
                l = ch;
            }
                                                       // find the ones which
            int idx;                                   // .. have equal mapping
            loop: for (idx = 0; idx < map.length; idx += 3){
                cmp: {
                    char c = map[idx++];
                    if ((c == 0) || (c == 0xffff)) continue;

                    int r = idx;
                    ck: {
                        for (; r < idx+3; r++){        // measure it
                            if (map[r] == 0) break;
                        }
                        int k = idx;
                        for (int j = i; (j < len) && (k < r);
                            j++, k++){
                            if (s[j] != map[k]) break ck;
                        }
                        if (k < r) break ck;
                        ParserState next1 = next;
                        if ((r - idx) > 1){
                            if (i < len - (r - idx)){  // intermediate
                                next1 = newState();
                            } else {                   // ending
                                next1 = cf;
                            }
                            if ((FL_H & this.trc) != 0){
                                Trc.out.println(" {");
                            }
                        }
                        if ((c != ch) && (c != u) && (c != l)){
                            newTrans(ci,next1,c);
                            if ((FL_H & this.trc) != 0){
                                Trc.out.println(" " + ci + "-m-" +
                                    Integer.toHexString(c) +
                                    "->" + next1);
                            }
                        }
                        if ((r - idx) > 1){            // one:string, branch
                            variantForm(s,i + (r - idx),len,next1,cf);
                            if ((FL_H & this.trc) != 0){
                                Trc.out.println(" }");
                            }
                        }
                    }
                }
            }
            ci = next;
        }
    }


/*
Routine union_nfa
Description:  generates the DFA from a piece of automaton which is the
        union of expressions e1 and constraints. Then it checks that there
        the conditions on constraints are satisfied. Then it generates empty
        branches to a unique accepting state according with the constraint.
        In the union the states belonging to e1 are marked as `save'.
Calling sequence:
        union_nfa (si,e1,sf,f,cs)
        si:   pointer to initial state of both expressions
        e1:   pointer to accepting state of e1
        f:    pointer to the final state of the enclosing expression
        cs:   pointer to the constraint list
Return conditions:
        sf:   new ending state

    private union_nfa: PROC (ParserState si, ParserState e1,
        sf ParserState LOC,f ParserState, cs constr_ptr_t){
        DCL sh      ParserState,
                h       ParserState,
                tpr,p   ParserTrans,
                ae1,ae2 BOOL,
                se2     BOOL,
                acc     BOOL,
                ace2    BOOL,
                acs     BOOL,
                csp     constr_ptr_t;

        if ((FL_G & this.trc) != 0){
            Trc.out.println("union_nfa si: " + si + " e1: " + e1);
        }
        sh = nfa_to_dfa(si,this.numOfStates);    // transform NFA into DFA
        sf = newState();                         // new final state
        sf.final = e1.final;
        e1.final = false;
        reacheableStates(sh);
        rem_mrk(sh);
        csp = cs;
        while (csp != null){
            acc,ace2 = false;
            h = sh;
            while (h != null){                   // scan list
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("union_nfa state " + h + " " + h.special);
                }
                ae1, ae2, se2 = false;
                acs = false;
                for (i = 0; i < h.nfa_name.length; i++){
                    ParserState x = h.nfa_name[i];
                    ae1 |= x == e1;
                    ae2 |= x == csp.accs;
                    se2 |= ~x.save;
                }
                switch (csp.kind){
                case c_equ:
                    if (ae1){
                        if (ae2){                // accepts both
                            acs = true;          // accept state for this constr
                            acc = true;
                        } else {
                            h.parent = sf;       // final non accepting state
                        }
                    }
                    ace2 = true;
                    break;
                case c_not:
                    if (ae1){
                        acs = true;              // accept state for this constr
                        if (se2) acc = true;
                    } else {
                        if (ae2){                // accepts e2 only
                            h.parent = sf;       // final non accepting state
                            ace2 = true;
                        }
                    }
                    break;
                case c_diff:
                    if (ae1){
                        if (!ae2){               // accepts e1 and not e2
                            acs = true;          // accept state for this constr
                            acc = true;
                        } else {
                            h.parent = sf;       // final non accepting state
                            ace2 = true;
                        }
                    }
                    break;
                case c_succ:
                    if (ae1){
                        acs = true;              // accept state for this constr
                        acc = true;
                    } else {
                        if (ae2){                // accepts e2 only
                            h.parent = sf;       // final non accepting state
                            ace2 = true;
                        }
                    }
                    break;
                case c_term:
                    if (ae1){
                        if (ae2){                // accepts e1 and e2
                            rem_edges(h);
                        }
                        acs = true;              // accept state for this constr
                        acc = true;
                    }
                    ace2 = true;
                    break;
                }
                if ((FL_H & this.trc) != 0){
                    if (h.parent != null){
                         Trc.out.println("non-accepting: " + h);
                    }
                }
                h.special = acs;
                h = h.list;
            }
            if (~acc || ~ace2){
                message(ERR_DISEXP,"",csp.node.point);
            }
            csp = csp.next;
        }
        h = sh;
        while (h != null){                       // scan list
            if (h.special && (h.parent == null)){
                all_tre (h,sf,p);                // make it an ending state
            }
            h.special = false;
            TERMINATE (h.nfa_name);
            h.nfa_name = null;
            h = h.list;
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("union_nfa swap: " + si + " " + sh);
        }
        tpr = si.transList;                      // swap initial states
        si.transList = sh.transList;
        sh.transList = tpr;
    }
*/

    /**
     * Build the list of the states reacheable from a given state.
     *
     * @param      s head of the list
     * @param      k kind: 0 all edges, 1 only e-edges, 2 all edges and
     *             seek nonempty loops
     * @param      fs end state, not to go past it
     * @return     < 0 if the end state is not reached with a nonempty path,
     *             (i.e. not reached, or reached with empty paths only),
     *             0 reachead with a nonempty path, 1 reached with a nonempty
     *             loop, 2 as 0, but the path contains nonempty loops
     */

    /* To determine if the end state is reached by nonempty edges, when all 
     * reacheable states have been collected, they are visited repeatedly,
     * marking HEAVY all next-states reached by nonempty edges, and all
     * next-states anyway if the current one is HEAVY.
     * This propagation proceeds until no more states can be marked.
     * This is needed since during any visit of the states, the marks
     * brought by the incoming edges of a state are not known for all
     * such edges.
     * Since this is done only on the reacheable states, unreacheable
     * states that reach the end one with nonempty edges do not propagate
     * HEAVY on it. Dead ends of course do not propagate it.
     * Since the propagation is done completely, HEAVY gets set also when
     * a path exists which contains loops with nonempty edges.
     * If the end state has such a mark, then it is reached by a path which
     * has at least one non e-edge.
     * If the end state is reached and it does not have such a mark, then
     * it is reached by e-edges only.
     */

    int reacheableStates(ParserState s, int k, ParserState fs){
        if ((FL_H & this.trc) != 0){
            Trc.out.println("reacheableStates: " + s + " " + k + " " + fs);
        }
        int res = -1;
        ParserState h = s;
        h.status |= ParserState.MRK;           // mark the starting state
        h.list = null;
        for (; h != null; h = h.list){         // scan list
            if (fs != null){                   // do not follow it
                if (h == fs) continue;
            }
            if ((FL_H & this.trc) != 0){
                Trc.out.println("state: " + h + " " +
                    ((ParserState.SPECIAL & h.status) != 0));
            }
            ParserState ta = h;
            ParserTrans tr = h.transList;      // scan edges to collect
            for (; tr != null; tr = tr.next){  // .. unmarked states
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("next: " + tr.nextState + " " +
                        ((ParserState.MRK & tr.nextState.status) != 0));
                }
                if (tr.kind == ParserTrans.SET){
                    if (tr.set.isEmpty()){     // empty set
                        continue;
                    }
                }
                switch (tr.kind){
                case ParserTrans.SYM:
                    if (k == 1) continue;
                    break;
                case ParserTrans.SET:
                    if (k == 1) continue;
                    break;
                case ParserTrans.EMPTY:
                    break;
                }
                if ((ParserState.MRK & tr.nextState.status) != 0){
                    continue;
                }
                tr.nextState.status |=
                    ParserState.MRK;           // mark it as belonging to the graph
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("also: " + tr.nextState);
                }
                tr.nextState.list = ta.list;   // put into list after the current
                ta.list = tr.nextState;
                ta = tr.nextState;
            }
        }
        if (k != 1){                           // propagate heaviness
            if (k == 2){
                cycles(s,null,0);              // mark loops
            }
            boolean change = true;
            do {
                change = false;                         // no changes yet
                for (h = s; h != null; h = h.list){     // scan list
                    for (ParserTrans tr = h.transList;
                        tr != null; tr = tr.next){
                        ParserState next = tr.nextState;
                        boolean heavy =
                            (ParserState.HEAVY & h.status) != 0;
                        if (tr.kind != ParserTrans.EMPTY){
                            heavy = true;
                        }
                        if (heavy &&
                           ((ParserState.HEAVY & next.status) == 0)){
                            next.status |=
                                ParserState.HEAVY;      // non-empty
                            change = true;
                        }
                        if (((ParserState.HEAVY_LOOP &
                            h.status) != 0) &&
                            ((ParserState.HEAVY_LOOP & next.status) == 0)){
                            next.status |=
                                ParserState.HEAVY_LOOP; // non-empty
                            change = true;
                        }
                    }
                }
            } while (change);
        }
        if (fs != null){
            if ((ParserState.HEAVY & fs.status) != 0){
                res = 0;
            }
            if ((ParserState.HEAVY_LOOP & fs.status) != 0){
                res = 1;
            }
        }
        if ((FL_H & this.trc) != 0){
            for (h = s; h != null; h = h.list){    // scan list
                Trc.out.println("reached " + h);
            }
            Trc.out.println("reached res: " + res);
        }
        return res;
    }

    /**
     * Mark the nonempty loops in the reacheable states of this NFA.
     *
     * @param      s start state
     */

    /* If this automaton were a purged DFA, any loop would be a nonempty
     * loop. However, this method is applied to NFAs, which can also
     * contain unreacheable states, or states which do not have paths
     * to the end state. A repeated visit of the edges of states carrying
     * along an attribute is not simple to do in this case. A recursive
     * visit of the edges is done instead. States are marked, and when a
     * marked state is encountered, a loop occurs. During the visit, the
     * encountered edges are kept in a stack. When a loop is detected, the
     * stack is examined, the edges in it which make the loop identified,
     * and all the traversed states marked HEAVY_LOOP. Since in the visit
     * all paths with distinct states are traversed, all simple loops are
     * identified. During the subsequent propagation of the attributes make by
     * reacheableStates, HEAVY_LOOP is also propagated. If the end state is
     * reached, and has HEAVY_LOOP on it, a path with a nonempty loop from
     * the start state to the end state exists.
     * Note that during a recursive visit it is simple to tell if a path
     * reaches the end state, but it is difficult to tell if it contains
     * nonempty loops. The visit could have reached a state which has two
     * branches: one to a previous state, and another not. If second one
     * is taken first, the presence of a nonempty loop is not known, and
     * the end state reached telling there is none. Later, the other edge
     * is taken, but the end state not reached. In such a case, the edges
     * should be visited again. This is too complex, and thus a propagation
     * is done instead.
     * Note that there is no need for an extra fast algorithm since NFAs
     * here are small.
     * Note also that this is applied to the reacheable states of a whole
     * NFA. Outgoing edges from the end state which loop into it are
     * considered as relevant.
     * The stack is allocated each time because this method is called only
     * once in a NFA.
     *
     * There is an iterative algorithm to determine the cyclic states.
     * States are visited repeatedly building for each one the set of states
     * which have an edge to them transitively.
     * All edges are visited. The states they reach are accessed and for each,
     * the "from" state added to the set attached to the "to" state.
     * The process is repeated until nothing changes.
     * If a state contains itself in its set, there is a loop on it.
     * However, this does not tell what the loop is. There would be a need
     * to carry along some attribute on states placed in such sets to
     * remember if loops contain nonempty edges. This makes the algorithm
     * complex.
     */

    private void cycles(ParserState s, ParserTrans[] stack, int stackTop){
        if ((FL_H & this.trc) != 0){
            Trc.out.println("cycles: " + s);
        }
        s.status |= ParserState.VISITED;
        l: for (ParserTrans tr = s.transList;         // visit edges
            tr != null; tr = tr.next){
            ParserState next = tr.nextState;
            if ((FL_H & this.trc) != 0){
                Trc.out.println("nextstate: " + next + " " +
                    ((ParserState.VISITED & next.status) != 0));
            }
            if ((stack == null) ||
                (stack.length < this.numOfStates)){
                stack = new ParserTrans[this.numOfStates];
                stackTop = this.numOfStates;
            }
            stack[--stackTop] = tr;
            if ((ParserState.VISITED & next.status) != 0){
                boolean nonempty = false;
                if (stack[stackTop].kind != ParserTrans.EMPTY){
                    nonempty = true;
                }
                int first = stackTop;
                for (int i = stackTop+1; (i < this.numOfStates) &&
                    (stack[i].nextState != next); i++){
                    first = i;
                    if (stack[i].kind != ParserTrans.EMPTY){
                        nonempty = true;
                    }
                }
                if ((FL_G & this.trc) != 0){
                    Trc.out.print((nonempty ? "nonempty " : "") + "cycle " +
                        next);
                    for (int i = first; i >=  stackTop; i--){
                        Trc.out.print(" " + stack[i] + " -> " +
                             stack[i].nextState);
                    }
                    Trc.out.println();
                }
                if (nonempty){
                    for (int i = stackTop; i <= first; i++){
                        ParserState nx = stack[i].nextState;
                        nx.status |= ParserState.HEAVY_LOOP;
                        if ((FL_H & this.trc) != 0){
                           Trc.out.println("cycles loop heavy: " + nx);
                        }
                    }
                }
                stackTop++;
                continue;
            }
            cycles(next,stack,stackTop);
            stackTop++;
        }
        s.status &= ~ParserState.VISITED;
        if ((FL_H & this.trc) != 0){
            Trc.out.println("cycles end " + s);
        }
        return;
    }

    /**
     * Eliminate the useless parts of a NFA.  The states which may not
     * be reached from the starting one, or which have no outgoing
     * transitions and are not final are removed. Mark the states which
     * have an e-transition to a final state as final.
     * Note that the opposite is not true: states which are final and
     * have e-transitions to other states do not make them final (otherwise
     * recognizion would announce a match when they are reached by other
     * paths as well).
     */

    /* In a (minimized) automaton each state which is not final and have only
     * edges to itself can be removed. Any edges to it can also be removed.
     * Moreover, groups of non-final states which have only edges to states
     * in the same group can be removed. 
     * Furthermore, any state which is not reacheable from the start state(s)
     * (i.e. is inaccesible) can be removed, and each group of states which
     * have edges to themselves, but are not connected to the initial state(s)
     * can be removed.
     * States like these could be present in general in a DFA if in the origin
     * NFA they are present. This is not the case in the NFAs built from rules
     * since by construction all states are connected, and can reach a final
     * state.
     * However, it can be the case when complementation is done.
     * Such states can also be removed from the DFA before minimization.
     *
     * First, it collects all the states which can be reached from the
     * starting one. Then it visits them and it marks the final ones
     * and the ones which have a transition to a final one. It repeats
     * the process until nothing changes.  In so doing, the states get
     * marked starting from the final ones down to the starting one.
     * The ones which are not marked do not have a path to a final one,
     * and thus are useless either because there is no path from a starting
     * state to them (i.e. they are inaccessible), or they do not lead to
     * a final one.
     *
     * When complementing !{<char>}*, an automaton which is disconnected
     * is generated and then purged. To retain its initial and final
     * stated, which would otherwise be removed, the NOPURGE mark is
     * forced on them, and purge() does not remove them.
     * Marking the states with e-edges to final as FINAL when purge() is
     * called in complement is irrelevant since FINAL is then removed
     * from states anyway.
     *
     * Purge is not needed at the end of the construction of a DFA because
     * by construction, unreacheable NFA states are not taken into account.
     * Therefore, when there are expressions which denote the empty language,
     * the part of the NFA which follows is descarted. When that expression
     * is not at the end, it produces an automa with no final states.
     * Not minimal, but correct. The effort to purge it does not pay off.
     */

    void purge(){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("purge_nfa");
        }
        ParserState s = this.sthead;
        reacheableStates(s,0,null);          // collect reacheable states
        rem_mrk(s);
        boolean change = true;               // mark states that lead to final states
        while (change){
            change = false;                  // no changes yet
            if ((FL_H & this.trc) != 0){
                Trc.out.println("purge-loop");
            }
            for (ParserState h = s;
                h != null; h = h.list){          // scan list
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("state: " + h + " " +
                    ((ParserState.MRK & h.status) != 0) + " " +
                    ((ParserState.FINAL & h.status) != 0));
                }
                if ((ParserState.MRK & h.status) != 0){
                    continue;                    // done
                }
                boolean m = false;
//?? parent is not null when called from union_nfa
                if (h.parent != null){           // it inherits from parent
                    if ((ParserState.FINAL &
                        h.parent.status) != 0){
                        h.status |= ParserState.FINAL;
                        if ((FL_H & this.trc) != 0){
                            Trc.out.println("inherits final");
                        }
                    }
                    if ((ParserState.MRK &       // depends from a useful state
                        h.parent.status) != 0){
                        m = true;
                    }
                }
                ParserTrans tr = h.transList;
                for (; tr != null; tr = tr.next){
                    if ((FL_H & this.trc) != 0){
                        Trc.out.print("edge: " + h + " ");
                        tr.trace();
                    }
                    if ((ParserState.MRK &             // leads to a  state
                        tr.nextState.status) != 0){    // .. which has a path
                        m = true;                      // .. to a final one
                    }
                    if (tr.kind == ParserTrans.EMPTY){ // e-trans
                        if ((ParserState.FINAL &       // leads to a final state
                            tr.nextState.status) != 0){
                            h.status |= ParserState.FINAL;
                            if (h.tokset == null){     // for testing
                                if (tr.nextState.tokset != null){
                                    h.tokset = new IntSet(tr.nextState.tokset);
                                }
                            } else {
                                h.tokset.add(tr.nextState.tokset);
                            }
                            if ((FL_H & this.trc) != 0){
                                Trc.out.println("becomes final: " + h);
                            }
                        }
                    }
                }
                if ((ParserState.FINAL & h.status) != 0){
                    m = true;
                }
                if (!m) continue;
                h.status |= ParserState.MRK;
                change = true;
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("useful: " + h);
                }
            }
        }
        for (ParserState h = s; h != null;   // scan list and remove edges
            h = h.next){
            rem_edges(h);
        }
        int f = 0;
        this.numOfStates = 0;
        ParserState pr = null;
        for (ParserState h = s; h != null;){         // scan list and remove states
            ParserState ne = h.next;
            if (((ParserState.MRK | ParserState.NOPURGE) &
                h.status) == 0){                     // useless state
                if (pr == null){
                    this.sthead = h.next;
                } else {
                    pr.next = h.next;
                }
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("state removed: " + h);
                }
            } else {
                h.num = this.numOfStates++;          // renumber it
                pr = h;
                if ((ParserState.FINAL & h.status) != 0){
                    f++;
                }
            }
            h.status &= ~(ParserState.MRK | ParserState.NOPURGE);
            h.list = null;
            h = ne;
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("final FA states: " + f);
        }
    }

    /**
     * Eliminate the useless edges of a state.
     *
     * @param      s head of the list
     */

    private void rem_edges(ParserState s){
        ParserTrans tpr = null;
        ParserTrans tr = s.transList;
        while (tr != null){
            ParserTrans p = tr.next;
            if ((ParserState.MRK &        // edge to a useless state
                tr.nextState.status) == 0){
                if ((FL_H & this.trc) != 0){
                    Trc.out.print("edge removed: " + s + " ");
                    tr.trace();
                }
                if (tpr == null){         // remove from list
                    s.transList = p;
                } else {
                    tpr.next = p;
                }
            } else {
                tpr = tr;
            }
            tr = p;
        }
    }

    /**
     * Build the DFA from the NFA.
     */

    ParserFA buildDfa(){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("--- build_dfa init ---");
            Trc.out.println("nfa states " + this.numOfStates);
        }
        return nfa_to_dfa();             // transform NFA into DFA
    }

    /**
     * Build a DFA from a NFA.
     *
     * @return     reference to the created DFA
     */

    /* The NFA can have several transitions from a state to a same next state,
     * and each of them can have a set or symbols. However, each transition
     * has a single next state. When for a same symbol there are two states,
     * there are two transitions.
     *
     * Building a DFA requires to scan the transitions of the NFA and building
     * the sets of NFA states which are reached by sets of input symbols.
     * This means that there is a need to build sets of NFA states which, when
     * all edges from a set of NFA states have been examined, will eventually
     * be duplicates of existing DFA states, or become new states.
     * In order not to create state (objects) which are then discarded,
     * temporary storage is kept which is reused at each iteration of the
     * algorithm. This allows to create states and transitions which are the
     * final ones, and avoid to throw objects away.
     * To create the DFA there is a need to visit the transitions of the
     * NFA states which make up a DFA one, and perform quite a lot of set
     * operations on the symbols and the states. This is so since it is too
     * lengthy to compute the next state for all symbols on the edges.
     * NFA transitions have sets of symbols and have a next state. The sets
     * of symbols in them must be compared with the ones collected so far
     * so as to determine the subsets of symbols which lead to the same
     * (set of) states. To do it, set objects of symbols are needed
     * and also sets to compute intesections. These are allocated as need
     * occurs and reused to make the same processing on the next states.
     * For this, IntSet objects are used, which can be cleared and reused
     * without implying reallocation of memory.
     * Keeping arrays of booleans for states or sets of ranges is not much
     * different. The latter are faster in clearing and visiting and take less
     * memory when there are many elements.
     * The NFA states reached from a set of NFA states when reading a
     * symbol is stored as a set of integers.
     * To build then the NFA name there is a need to pick up the NFA states
     * whose numbers are those in the set.
     * To check in a fast way that a set of NFA states contains the same
     * states as another one (which is a DFA state), a HashMap is used.
     * The generated DFA has one transition from two states at most (with a
     * set of symbols on it). This comes from the construction since to build
     * the transitions from a set of states, all the already built ones are
     * visited to add/split them.
     */

    private ParserFA nfa_to_dfa(){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("nfa_to_dfa init NFA state: " + this.sthead);
        }

        ParserFA dfa = new ParserFA(this.gram,
            this.trc,this.tokTable,this.symbMap);

        ParserState bs = this.sthead;
        int sn = 0;
        for (ParserState h = this.sthead;       // determine max state nr
            h != null; h = h.next){
            if (h.num > sn) sn = h.num;
        }

        sn++;
        bs.list = null;                         // e-closure of initial NFA state
        e_closure(bs);
        rem_mrk(bs);
        ParserState[] stArr =                   // allocate array for building
            new ParserState[sn];                // .. DFA state names
        int[] states = new int[sn];
        int n = 0;
        for (ParserState h = bs; h != null;     // build name
            h = h.list){
            if ((FL_H & this.trc) != 0){
                Trc.out.println("dfa init nfa state: " + h);
            }
            stArr[n++] = h;                     // store pointers
        }
        ParserState s = dfa.newState();         // create new DFA state with the name
        dfa.startState = s;
        s.nfa_name = new ParserState[n];
        System.arraycopy(stArr,0,s.nfa_name,0,n);
        synth_attr(s);                          // synthetize attributes
        if ((FL_H & this.trc) != 0){
            Trc.out.println("dfa start state: " + s.dfaName());
        }

        this.symbSets = new IntSet[20];         // allocate temporary storage
        this.stateSets = new IntSet[20];
        this.nfaStates = new ParserState[sn];
        for (ParserState h = bs; h != null;     // build table of NFA states
            h = h.next){
            this.nfaStates[h.num] = h;
        }

        Map<IntSet,ParserState> dfaHash = new HashMap<IntSet,ParserState>(); // hashtable of dfa states
        ParserState sh = s;                     // head of created DFA

        for (ParserState h = s; h != null;      // scan DFA non visited states
            h = h.next){
            if ((FL_H & this.trc) != 0){
                Trc.out.println("---dfa state: " + h + " " + h.dfaName());
            }
            n = edge_list(h);                   // build edge list
            n = close_list(n);                  // e-close and purge list

            if ((FL_H & this.trc) != 0){
                Trc.out.println("generate trans");
            }
            for (int i = 0; i < n; i++){              // generate DFA transitions
                ParserState sta = (ParserState)
                    (dfaHash.get(this.stateSets[i]));
                if (sta == null){                     // no such state (yet)
                    IntSet set = new                  // create nfa name
                        IntSet(this.stateSets[i],0);
                    set.toArray(states);
                    int m = (int)(set.size());
                    for (int k = 0; k < m; k++){
                        stArr[k] = this.nfaStates[states[k]];
                    }
                    s = dfa.newState();               // create new DFA state
                    s.nfa_name = new ParserState[m];  // name
                    System.arraycopy(stArr,0,s.nfa_name,0,m);
                    synth_attr(s);                    // synthetize attributes
                    if ((ParserState.FINAL &
                        s.status) != 0){              // final
                        dfa.endState = s;             // record last final, the
                    }                                 // .. end when there is one
                    if ((FL_H & this.trc) != 0){
                        Trc.out.println("new dfa state: " +
                            s + " " + s.dfaName());
                    }
                    sta = s;
                    dfaHash.put(set,sta);
                }
                dfa.newTrans(h,sta,this.symbSets[i]);
            }

            h.transList = transOrder(h.transList);    // order transitions
        }
        this.symbSets = null;                         // release temporary storage
        this.stateSets = null;
        this.nfaStates = null;
        if ((FL_G & this.trc) != 0){
            Trc.out.println("end nfa_to_dfa dfa: " + sh);
        }
        return dfa;
    }

    /**
     * Order a list of transitions.
     *
     * @param      tr reference to the head of the list
     * @return     reference to the ordered list
     */

    private ParserTrans transOrder(ParserTrans tr){
        ParserTrans ord = null;             // order transitions
        ParserTrans nextTr = null;;
        for (; tr != null;){
            nextTr = tr.next;
            ParserTrans pr = null;
            ParserTrans cur = ord;
            while (cur != null){            // seek insertion point
                int lo_cur = cur.sym;
                if (cur.kind == ParserTrans.SET){
                    lo_cur = cur.set.first();
                }
                int lo_tr = tr.sym;
                if (tr.kind == ParserTrans.SET){
                    lo_tr = tr.set.first();
                }
                if (lo_cur > lo_tr){        // point found
                    break;
                }
                pr = cur;
                cur = cur.next;
            }
            if (pr == null){                // insert at beginning
                tr.next = ord;
                ord = tr;
            } else {                        // insert in the middle
                tr.next = cur;
                pr.next = tr;
            }
            tr = nextTr;
        }
        if ((FL_H & this.trc) != 0){
            Str st = new Str();
            transToString(ord,false,st);
            Trc.out.println("ordered trans: " + st);
        }
        return ord;
    }


    /** Temporary sets of symbols for all transitions of a DFA state. */
    IntSet[] symbSets;

    /** Temporary sets of NFA states for all transitions of a DFA state. */
    IntSet[] stateSets;

    /** Temporary map from NFA state numbers to references. */
    ParserState[] nfaStates;

    /**
     * Build the list of all edges from the current DFA state, in which
     * each edge has attached a set of symbols and the set of states to
     * which to transit with any of the symbols in the set.
     *
     * @param      h reference to the state of the DFA
     * @return     n number of transitions
     */

    private int edge_list(ParserState h){
        if ((FL_H & this.trc) != 0){
            Trc.out.println("edge_list for: " + h.dfaName());
        }
        IntSet cs = new IntSet();
        IntSet inter = new IntSet();
        int n = 0;
        for (int i = 0; i < h.nfa_name.length; i++){ // scan edges of the set of states
            if ((FL_H & this.trc) != 0){
                Trc.out.println("nfa state: " + h.nfa_name[i]);
            }
            for (ParserTrans ts = h.nfa_name[i].transList;
                ts != null; ts = ts.next){           // scan all edges of this state
                cs.clear();
                switch (ts.kind){
                case ParserTrans.SYM:
                    cs.add(ts.sym);                  // single symbol
                    break;
                case ParserTrans.SET:
                    cs.add(ts.set);                  // set
                    break;
                case ParserTrans.EMPTY:
                    continue;                        // empty
                }
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("trans " + cs.toString(true));
                }
                int nn = n;
                for (int j = 0; j < n ; j++){
                    if (cs.isEmpty()) break;
                    if (this.symbSets[j].equals(cs)){          // same set
                        cs.clear();
                        this.stateSets[j]
                            .add(ts.nextState.num);            // add state
                        break;
                    }
                    inter.assign(this.symbSets[j]);
                    inter.and(cs);
                    if (inter.isEmpty()) continue;             // no overlap
                    ins: if (inter.equals(this.symbSets[j])){  // a superset
                        this.stateSets[j]                      // add state
                            .add(ts.nextState.num);
                    } else {                                   // not a superset
                        if ((FL_H & this.trc) != 0){
                            Trc.out.println("inter el " +
                                edgeToString(j));
                        }
                        if (this.stateSets[j].                 // to that state
                            contains(ts.nextState.num)){       // .. yet
                            break ins;
                        }
                        this.symbSets[j].sub(inter);           // remove common symbols
                        if ((FL_H & this.trc) != 0){
                            Trc.out.println("split old " +
                                edgeToString(j));
                        }
                        nn = storeEdge(nn,inter,
                            this.stateSets[j],ts.nextState.num);
                    }
                    cs.sub(inter);
                }
                if (!cs.isEmpty()){                            // add to list
                    nn = storeEdge(nn,cs,null,ts.nextState.num);
                }
                n = nn;
            }
        }
        if ((FL_H & this.trc) != 0){
            Trc.out.println("edge_list end for: " + h.dfaName());
            for (int i = 0; i < n; i++){
                Trc.out.println(edgeToString(i));
            }
        }
        return n;
    }

    /**
     * Deliver a string representing an egde.
     *
     * @param      i index of the edge in the temporary table
     */

    private String edgeToString(int i){
        return this.symbSets[i].toString(true) +
            " -> " + this.stateSets[i].toString(false);
    }

    /**
     * Store a transition in the table of the ones of the current
     * state. If there is no room, resize the table.
     * The set of states to reach is the union of the ones denoted by
     * the <code>states</code> and <code>state</code> arguments.
     *
     * @param      n number of transitions in the table
     * @param      symbs set of symbols
     * @param      states set of NFA states
     * @param      state additional NFA state
     * @return     n updated number of transitions
     */

    private int storeEdge(int n, IntSet symbs, IntSet states,
        int state){
        if ((FL_H & this.trc) != 0){
            Trc.out.println("storeEdge " + states + " " + state);
        }
        if (n == this.symbSets.length){
            int curlen = this.symbSets.length;
            int newlen = curlen + 20;
            if (newlen < 0){
                this.lex.message(ParserLexer.ERR_NOCORE,"",0);
                throw this.lex.excObj;
            }
            IntSet[] p = new IntSet[newlen];
            System.arraycopy(this.symbSets,0,p,0,curlen);
            this.symbSets = p;
            p = new IntSet[newlen];
            System.arraycopy(this.stateSets,0,p,0,curlen);
            this.stateSets = p;
        }
        if (this.stateSets[n] == null){          // store the new set
            if (states == null){
                this.stateSets[n] = new IntSet();
            } else {
                this.stateSets[n] = new IntSet(states);
            }
        } else {
            this.stateSets[n].assign(states);
        }
        this.stateSets[n].add(state);
        if (this.symbSets[n] == null){
            this.symbSets[n] = new IntSet(symbs);
        } else {
            this.symbSets[n].assign(symbs);
        }
        if ((FL_H & this.trc) != 0){
            Trc.out.println("appended " +
                edgeToString(n));
        }
        return n + 1;
    }

    /**
     * Perform the e_closure on all sets of states for the transitions
     * in the temporary table and merge the ones which lead to the same
     * states.
     *
     * @param      n number of transitions
     * @return     n updated number of transitions
     */

    /* When inserting the edges in the temporary storage we do not take
     * into account the states, and rather take into account the sets of
     * symbols. It is difficult to merge edges which lead to the same
     * states at that time because all the times a change is done on the
     * set of states of an edge, there is a chance that it becomes equal
     * to one which is already in the table. Thus it is done when all
     * edges have been collected.
     * The ones which leat to the same states are merged in a single one
     * for the union of input symbols.
     */

    private int close_list(int n){
        if ((FL_H & this.trc) != 0){
            Trc.out.println("close_list");
        }

        int[] stateNrs = new int[20];
        for (int i = 0; i < n; i++){          // make e-closure on edges
            if ((FL_H & this.trc) != 0){
                Trc.out.println("build_dfa edge: " +
                    edgeToString(i));
            }
            ParserState q = null;             // build list for e_closure
            IntSet s = this.stateSets[i];
            int nr = (int)s.size();
            stateNrs = s.toArray(stateNrs);
            for (int k = 0; k < nr; k++){
                int j = stateNrs[k];
                this.nfaStates[j].list = q;
                q = this.nfaStates[j];
            }
            e_closure(q);
            rem_mrk(q);
            for (; q != null; q = q.list){    // store the closure
                s.add(q.num);
            }
        }
        for (int i = 0; i < n; i++){          // merge edges to same states
            for (int j = i+1; j < n; j++){
                if (this.stateSets[j].equals(this.stateSets[i])){
                    this.symbSets[i].add(this.symbSets[j]);
                    if ((FL_H & this.trc) != 0){
                        Trc.out.println("merged " +
                            edgeToString(i));
                    }
                    IntSet sy = this.symbSets[j];   // remove, and place it at
                    IntSet st = this.stateSets[j];  // .. the end as spare
                    System.arraycopy(this.symbSets,j+1,
                        this.symbSets,j,n-j-1);
                    System.arraycopy(this.stateSets,j+1,
                        this.stateSets,j,n-j-1);
                    n--;
                    this.symbSets[n] = sy;          // restore the spare
                    this.stateSets[n] = st;
                    j--;
                }
            }
        }
        if ((FL_H & this.trc) != 0){
            Trc.out.println("close_list purged edge_list " + n);
            for (int i = 0; i < n; i++){
                Trc.out.println(edgeToString(i));
            }
        }
        return n;
    }

    /**
     * Synthetises the attributes of a DFA state from those of the
     * represented NFA states.
     *
     * @param      s reference to the state
     */

    private void synth_attr(ParserState s){
        for (int i = 0; i < s.nfa_name.length; i++){
            ParserState h = s.nfa_name[i];
            if ((ParserState.FINAL & h.status) != 0){  // final NFA state
                s.status |= ParserState.FINAL;
                if (s.tokset == null){
                    if (h.tokset != null){
                        s.tokset = new IntSet(h.tokset);
                    }
                } else {
                    s.tokset.add(h.tokset);
                }
            }
            s.status |= h.status & ParserState.SPECIAL;
        }
    }

    /**
     * Minimizes this DFA.
     */

    /* These are the two algorithms for minimizing a DFA. The second one
     * is used here.
     *
     * Triangular matrix:
     *
     *     1. for each p final and q non-final mark (p,q)
     *     2. for each pair of distinct (p,q) both final or both non-final:
     *        if for some a, (d(p,a),d(q,a)) is marked:
     *            mark (p,q)
     *            recursively mark all pairs in the list associated to (p,q)
     *            and on the lists of the other pairs that gets marked in this
     *            step
     *        else
     *            for all inputs a
     *                put (p,q) in the list for (d(p,a),d(q,a)) unless
     *                d(p,a) = d(q,a)
     *
     *  Partitions:
     *
     *     1. build an initial partition of two groups: the one of the final
     *        states and the one of the non-final ones
     *     2. for each group in the current partition:
     *        keep the group as it is if for all inputs the states in it
     *        have a transition to states in a same group, otherwise
     *        split the group to make this true.
     *        N.B. the states must be in a same group for each input,
     *        no matter if they are in different groups for different inputs.
     *     3. make the new partition current, and repeat step 2.
     *
     * There is an additional condition for step 1, that the states
     * accept the same lexemes. Note that the accepting of lexemes
     * is represented here as a set of token numbers, while in traditional
     * lexers it is represented as a reference to a (semantic) action.
     *
     * Groups are represented as lists of states, and partitions as arrays.
     * A group is processed by taking its elements one by one: placing the
     * first on a new group by itself, then testing the second against the
     * first and placing it in its group if all its transitions go to states
     * in the same (old) group as the state(s) collected so far, otherwise
     * in a newly created group, and then by repeating this for the remaining
     * ones.
     * Each state in a group is checked against the sub-groups in which
     * the current one is being split so as to find the one to join,
     * or create a new one if none appropriate is found.
     * Since states are kept in a same group when all their transitions lead
     * to states in a same (old) group, this could change if the new groups
     * were taken into account. This is why the process is repeated until no
     * changes occur in groups.
     * Then, the state with the lowest number in each group is taken as its
     * representative, and transitions to states in a group are redirected to
     * its representative.
     * This can lead to have several transitions in a state to a same next
     * state, which are then collapsed before computing the character
     * categories.
     *
     * Transition lists are kept ordered and symbol sets unique so as
     * to make comparison of lists of transitions of states fast.
     * However, there are cases in which the transitions of a state,
     * even if collectively they denote the same set of symbols as those
     * of another one, have such set split in a different way (because
     * the nextstates are different, but belong to the same group).
     * To compare such states, an array remapped is kept, indexed by group
     * number, which contains the transitions of the first state of the
     * group, remapped so as to merge transitions that go to states in the
     * same group. To check that a state is equivalent to the first one
     * in a partition, a remapped list is built for it, and that list is
     * compared with the one in the array. At each new cycle the remapped
     * array is cleared because groups could have changed. Remapped transitions
     * are kept in a free list so as to avoid to allocate and deallocate
     * them each many times.
     */

    void minimizeDfa(){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("minimize start");
//            trace(false,true,false,Trc.out);
            trace(false,true,false);
        }

        int sn = 0;
        for (ParserState h = this.sthead;       // determine max state nr
            h != null; h = h.next){
            if (h.num > sn) sn = h.num;
        }

        ParserState[] curPart =                 // current partition
            new ParserState[sn+1];
        ParserState[] newPart =                 // new partition
            new ParserState[sn+1];
        ParserTrans[] remapped =                // remapped transitions of groups
            new ParserTrans[sn+1];
        int[] groupNr = new int[sn+1];          // group numbers of states

        int n = 0;                                     // build initial partition
        for (ParserState h = this.sthead; h != null;   // visit all states
            h = h.next){
            ParserState s1 = h;
            for (int i = 0; i < n; i++){               // scan the collected ones
                ParserState s = curPart[i];
                boolean equiv = false;
                comp: {
                    if ((ParserState.FINAL & h.status) != 0){      // final state
                        if ((ParserState.FINAL & s.status) == 0){  // different
                            break comp;
                        }
                        if (h.tokset == null){
                            equiv = s.tokset == null;
                        } else {
                            equiv = h.tokset.equals(s.tokset);     // compare tokens
                        }
                        break comp;                                // .. recognised
                    } else {
                        if ((ParserState.FINAL & s.status) != 0){  // different
                            break comp;
                        }
                    }
                    equiv = true;
                }
                if (equiv){                            // in an existing group
                    if ((FL_H & this.trc) != 0){
                        Trc.out.println("with: " + curPart[i]);
                    }
                    s1.list = curPart[i];              // add to it
                    curPart[i] = s1;
                    s1 = null;
                    break;
                }
            }
            if (s1 != null){                           // in no groups
                curPart[n] = s1;                       // create new one
                curPart[n].list = null;
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("new group");
                }
                n++;
            }
        }
        for (int i = 0; i < n; i++){                   // fill in group numbers
            for (ParserState g = curPart[i];           // scan group
                g != null; g = g.list){
                groupNr[g.num] = i;
            }
        }

        ParserTrans spare = new ParserTrans();
        spare.kind = ParserTrans.SET;
        spare.set = new IntSet();
        int m = 0;                                     // fragment now
        boolean change = true;                         // .. partitions
        while (change){
            if ((FL_H & this.trc) != 0){
                Trc.out.println("---new cycle--- partition");
                for (int i = 0; i < n; i++){
                    Trc.out.print(i + ": ");
                    for (ParserState g = curPart[i];
                        g != null; g = g.list){
                        Trc.out.print(" " + g);
                    }
                    Trc.out.println();
                }
            }
            change = false;
            for (int i = 0; i < n; i++){               // scan current partition
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("processing group: " + i);
                }
                ParserState group = curPart[i];        // current group
                if (group == null) continue;
                newPart[m] = group;                    // place first in new group
                group = group.list;
                newPart[m].list = null;
                int mm = m++;
                ParserState next;
                for (ParserState g = group;            // scan remaining of current group
                    g != null; g = next){
                    next = g.list;
                    if ((FL_H & this.trc) != 0){
                        Trc.out.println("processing state: " + g);
                    }
                    ParserState s1 = g;
                    for (int j = mm; j < m; j++){      // scan the previous ones in group
                        ParserState s2 = newPart[j];   // take first, all have
                        boolean equiv = false;         // .. the same transitions
                        comp: {
                            ParserTrans t1 = s1.transList;
                            ParserTrans t2 = s2.transList;
                            while ((t1 != null) && (t2 != null)){
                                if ((t1.set != t2.set) ||
                                    (groupNr[t1.nextState.num] !=
                                    groupNr[t2.nextState.num])){
                                    break;
                                }
                                t1 = t1.next;
                                t2 = t2.next;
                            }
                            equiv = t1 == t2;
                            if (!equiv){               // make a deeper comparison
                                if ((FL_H & this.trc) != 0){
                                    Trc.out.println("deeper");
                                }
                                t1 = remapTrans(s1.transList,groupNr,spare);
                                if (remapped[j] == null){
                                    t2 = remapTrans(s2.transList,
                                        groupNr,spare);
                                    remapped[j] = t2;
                                }
                                ParserTrans t1Save = t1;
                                while ((t1 != null) && (t2 != null)){
                                    if (!t1.set.equals(t2.set) ||
                                        (groupNr[t1.nextState.num] !=
                                        groupNr[t2.nextState.num])){
                                        break;
                                    }
                                    t1 = t1.next;
                                    t2 = t2.next;
                                }
                                equiv = t1 == t2;
                                ParserTrans last = null;    // temporary transitions back in spare
                                for (t1 = t1Save; t1 != null; t1 = t1.next){
                                    last = t1;
                                }
                                if (last != null){
                                    last.next = spare;
                                    spare = t1Save;
                                }
                            }
                        } // comp
                        if (equiv){                    // in an existing group
                            if ((FL_H & this.trc) != 0){
                                Trc.out.println("with: " + newPart[j]);
                            }
                            s1.list = newPart[j];      // add to it
                            newPart[j] = s1;
                            s1 = null;
                            break;
                        }
                    }
                    if (s1 != null){                   // in no groups
                        newPart[m] = s1;               // create new one
                        newPart[m].list = null;
                        if ((FL_H & this.trc) != 0){
                            Trc.out.println("new group");
                        }
                        m++;
                        change = true;
                    }
                }
            }
            for (int i = 0; i < m; i++){               // write group numbers
                for (ParserState g = newPart[i];       // scan group
                    g != null; g = g.list){
                    groupNr[g.num] = i;
                }
            }
            ParserState[] tmp = curPart;
            curPart = newPart;
            newPart = tmp;
            n = m;
            m = 0;

            for (int i = 0; i < n; i++){               // clear remapped trans
                if (remapped[i] == null) continue;
                ParserTrans last = null;
                for (ParserTrans t = remapped[i]; t != null; t = t.next){
                    last = t;
                }
                last.next = spare;
                spare = remapped[i];
                remapped[i] = null;
            }
        }
        if ((FL_H & this.trc) != 0){
            Trc.out.println("minimize end partitioning");
            for (int i = 0; i < n; i++){
                Trc.out.print(i + ": ");
                for (ParserState g = curPart[i];
                    g != null; g = g.list){
                    Trc.out.print(" " + g);
                }
                Trc.out.println();
            }
        }

        // reduce now the automaton

        ParserState[] nfas = null;                // temp for rebuilding names
        ParserState[] stateMap = newPart;         // build map, reuse newPart
        for (int i = 0; i < n; i++){              // put state translation
            ParserState s = curPart[i];           // .. in stateMap
            int min = s.num;                      // determine representative
            int nf = 0;
            if (s.nfa_name != null){
                nf = s.nfa_name.length;
            }
            for (ParserState g = s.list;          // it is the one with the
                g != null; g = g.list){           // .. minimum state number
                if (g.num < min){
                    min = g.num;
                    s = g;
                }
                if (g.nfa_name != null){
                    nf += g.nfa_name.length;
                }
            }
            if ((nfas == null) || (nf > nfas.length)){
                nfas = new ParserState[nf];
            }
            int nn = 0;
            for (ParserState g = curPart[i];      // fill now the translation
                g != null; g = g.list){           // .. map and rebuild name
                stateMap[g.num] = s;
                if (nf == 0) continue;
                ins: for (int k = 0; k < g.nfa_name.length; k++){
                    for (int j = 0; j < nn; j++){
                        if (g.nfa_name[k] == nfas[j]) continue ins;
                    }
                    nfas[nn++] = g.nfa_name[k];
                }
            }
            if (nf == 0) continue;
            if (s.nfa_name.length != nn){         // larger name, allocate
                s.nfa_name = new ParserState[nn]; // .. a new one
            }
            System.arraycopy(nfas,0,s.nfa_name,0,nn);
            if ((FL_H & this.trc) != 0){
                Trc.out.println("representative: " + s +
                    " " + s.dfaName());
            }
        }

        ParserState tail = null;
        ParserState head = null;
        ParserState next = null;
        IntSet union = new IntSet();
        for (ParserState h = this.sthead; h != null;  // visit all states
            h = next){
            if ((FL_H & this.trc) != 0){
                Trc.out.println("state: " + h);
            }
            next = h.next;
            if (stateMap[h.num] == h){                // keep this state
/*
// I moved here the merging of transitions, but I do not remember why. The code below does
// not seem to merge them
                boolean merged = false;
                ParserTrans ts = h.transList;            // scan all transitions
                ParserTrans pr = null;
                ins: for (ParserTrans tr = h.transList;
                    tr != ts; tr = tr.next){
                    if (tr.nextState == ts.nextState){   // transition found
                        union.assign(tr.set);
                        union.add(ts.set);
                        tr.set = uniqueIntSet(union);
                        if ((FL_H & this.trc) != 0){
                            Trc.out.println("trans merged: " + tr);
                        }
                        pr.next = ts.next;               // discard current one
                        merged = true;
                        break;
                    }
                    pr = ts;
                }
*/
                if (tail == null){                    // insert at beginning
                    head = h;
                } else {                              // append
                    tail.next = h;
                }
                h.next = null;
                tail = h;
            } else {
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("remove: " + h);
                }
                continue;
            }
            ParserTrans ts = h.transList;             // scan all transitions
            ParserTrans pr = null;                    // .. translate state 
            for (; ts != null; ts = ts.next){         // .. and merge if needed
                ts.nextState = stateMap[ts.nextState.num];
                if ((FL_H & this.trc) != 0){
                    Trc.out.printf("trans: %s -%s-> %s\n",
                        h,ts,ts.nextState);
                }
// this is the code of merging that I moved above
                boolean merged = false;
                ins: for (ParserTrans tr = h.transList;
                    tr != ts; tr = tr.next){
                    if (tr.nextState == ts.nextState){   // transition found
                        union.assign(tr.set);
                        union.add(ts.set);
                        tr.set = uniqueIntSet(union);
                        if ((FL_H & this.trc) != 0){
                            Trc.out.println("trans merged: " + tr);
                        }
                        pr.next = ts.next;               // discard current one
                        merged = true;
                        break;
                    }
                }
                if (!merged) pr = ts;
            }
        }
        this.sthead = head;
        this.sttail = tail;
        int ns = 0;                                     // renumber states
        for (ParserState h = this.sthead; h != null;
            h = h.next){
            h.num = ns++;
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("minimize reduced: " + this.numOfStates +
                " to: " + ns);
        }
        this.numOfStates = ns;
        if (this.startState != null){
            this.startState = stateMap[this.startState.num];
        }
        if (this.endState != null){
            this.endState = stateMap[this.endState.num];
        }
        //purge();                               // remove useless parts,
                                                 // .. ineffective here
        if ((FL_G & this.trc) != 0){
//            trace(false,true,false,Trc.out);
            trace(false,true,false);
        }
    }

    /**
     * Deliver an ordered list of remapped transitions. Transitions
     * to states that belong to a same group are merged.
     *
     * @param      tlist origin list of transitions
     * @param      groupNr mapping from state numbers to group numbers
     * @param      spare head of the spare list of transitions
     * @return     head of the ordered remapped list
     */

    private ParserTrans remapTrans(ParserTrans tlist, int[] groupNr,
        ParserTrans spare){
        ParserTrans ord = null;
        l: for (ParserTrans t = tlist; t != null;   // scan list
            t = t.next){
            for (ParserTrans to = ord; to != null;  // seek one in ord with
                to = to.next){                      // .. same state in group
                if (groupNr[to.nextState.num] ==
                    groupNr[t.nextState.num]){
                    to.set.add(t.set);              // found, add to it
                    continue l;
                }
            }
            ParserTrans cur = null;
            if (spare.next == null){
                cur = new ParserTrans();
                cur.kind = ParserTrans.SET;
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("new spare");
                }
                cur.set = new IntSet(t.set);        // create a new one
            } else {                                // .. to add to it
                cur = spare.next;
                spare.next = spare.next.next;
                cur.set.assign(t.set);
            }
            cur.nextState = t.nextState;
            cur.next = ord;
            ord = cur;
        }
        ord = transOrder(ord);
        return ord;
    }

    /**
     * Compare this automaton with the specified one for equality.
     * They are equal iff there exists an isomorphism between states
     * such that two correspondins states have the same transitions.
     *
     * @param      au the automaton to compare
     */

    /* There is no requirement that the transitions in states be
     * ordered, or even be exactly the same as long as they represent
     * the same sets of symbols.
     * Each one of the two automa must be connected. The states which
     * are not reacheable from the starting one are not tested.
     */

    /* When transitions lead to states that are not already announced
     * as equivalent they are tentatively set as such, and put forward
     * to be visited and thus checked. When they are visited, all
     * their transitions and their nextstates checked.
     */

    boolean equals(ParserFA au){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("equals");
        }

        int sn = 0;
        for (ParserState h = this.sthead;       // determine max state nr
            h != null; h = h.next){
            if (h.num > sn) sn = h.num;
        }
        ParserState[] equiv = new ParserState[sn+1];
        sn = 0;
        for (ParserState h = au.sthead;         // determine max state nr
            h != null; h = h.next){
            if (h.num > sn) sn = h.num;
        }
        boolean[] linked = new boolean[sn+1];
        ParserTrans spare = null;
        int[] ranges = new int[20];
        boolean res = true;
        ParserState s = au.sthead;
        if (this.sthead != null){
            this.sthead.list = null;
        }
        cmp: for (ParserState h = this.sthead;  // compare states
            h != null;){
            if ((FL_H & this.trc) != 0){
                Trc.out.println("compare: " + h + " " + s);
            }
            if (s == null){
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("diff states nr");
                }
                res = false;
                break cmp;
            }

            // build transition table for first and second
            // compare entries: if they go to equivalent states, then ok,
            // if the states are not in relation, make them equivalent,
            // otherwise the automata are different.
            // Transition lists are cloned because there is a need to
            // order them to make comparison simple, while at the same
            // time not to change the original ones.

            ParserTrans t1 = null;
            ParserTrans t2 = null;
            for (int a = 0; a < 2; a++){           // for both automata
                ParserTrans ord = null;
                ParserTrans t = h.transList;
                if (a > 0) t = s.transList;
                for (; t != null; t = t.next){     // build ordered transitions
                    ParserTrans cur = null;
                    if (spare == null){
                        cur = new ParserTrans();
                        cur.kind = ParserTrans.SET;
                        if ((FL_H & this.trc) != 0){
                            Trc.out.println("new spare");
                        }
                    } else {
                        cur = spare;
                        spare = spare.next;
                    }
                    cur.set = t.set;
                    cur.nextState = t.nextState;
                    cur.next = ord;
                    ord = cur;
                }
                if (a == 0) t1 = transOrder(ord);
                else t2 = transOrder(ord);
            }

            ParserTrans t1Save = t1;
            ParserTrans t2Save = t2;
            while ((t1 != null) && (t2 != null)){   // compare transitions
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("compare: " + t1 + " " + t2);
                }
                eq: if (t1.set.equals(t2.set)){     // same sets
                    if (equiv[t1.nextState.num] ==
                        t2.nextState){              // equivalent next states
                        break eq;
                    } else if (equiv[t1.nextState.num] == null){
                        if (!linked[t2.nextState.num]){    // free, make equivalent
                            equiv[t1.nextState.num] = t2.nextState;
                            linked[t2.nextState.num] = true;
                            if ((FL_H & this.trc) != 0){
                                Trc.out.println(t1.nextState +
                                    "<=?=>" + t2.nextState);
                            }
                            for (ParserState x = h; x != null;
                                x = x.list){
                                if (t1.nextState == x) break eq;
                            }
                            t1.nextState.list = h.list;
                            h.list = t1.nextState;
                            break eq;
                        } else {
                            if ((FL_H & this.trc) != 0){
                                Trc.out.println("diff trans next: " + h + " " + s);
                            }
                            res = false;
                            break cmp;            // not equal
                        }
                    }
                    if ((FL_H & this.trc) != 0){
                        Trc.out.println("diff trans next: " + h + " " + s);
                    }
                    res = false;
                    break cmp;              // not equal
                } else {
                    if ((FL_H & this.trc) != 0){
                        Trc.out.println("diff trans sym: " +
                            h + " " + t1 + " " + s + " " + t2);
                    }
                    res = false;
                    break cmp;              // not equal
                }
                t1 = t1.next;
                t2 = t2.next;
            }
            if (t1 != t2){                  // remaining ones not equal
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("diff trans nr: " + h + " " + s);
                }
                res = false;
                break cmp;
            }
            ParserTrans last = null;        // temporary transitions back in spare
            for (t1 = t1Save; t1 != null; t1 = t1.next){
                last = t1;
            }
            if (last != null){
                last.next = spare;
                spare = t1Save;
            }
            last = null;
            for (t2 = t2Save; t2 != null; t2 = t2.next){
                last = t2;
            }
            if (last != null){
                last.next = spare;
                spare = t1Save;
            }

            eq: if (equiv[h.num] != s){     // not yet equivalent
                if (equiv[h.num] == null){
                    if (!linked[s.num]){    // free, make equivalent
                        equiv[h.num] = s;
                        linked[s.num] = true;
                        if ((FL_H & this.trc) != 0){
                            Trc.out.println(h + "<=!=>" + s);
                        }
                        break eq;
                    }
                }
                if ((FL_H & this.trc) != 0){
                    Trc.out.println("diff: " + h + " " + s);
                }
                res = false;
                break cmp;
            }
            h = h.list;
            if (h != null) s = equiv[h.num];
            if ((FL_H & this.trc) != 0){
                Trc.out.println("equal");
            }
        } // cmp

        // check then that all states have an equivalent

        if (res){
            for (ParserState h = this.sthead;
                h != null; h = h.next){
                if (equiv[h.num] == null){  // it does not have an equivalent
                    if ((FL_H & this.trc) != 0){
                        Trc.out.println("widow: " + h);
                    }
                    res = false;
                    break;
                }
                if ((ParserState.FINAL & h.status) !=
                    (ParserState.FINAL & equiv[h.num].status)){
                    if ((FL_H & this.trc) != 0){
                        Trc.out.println("diff-final: " + h + " " + equiv[h.num]);
                    }
                    res = false;
                    break;
                }
            }
        }
        if (res){
            for (ParserState h = au.sthead;
                h != null; h = h.next){
                if (!linked[h.num]){        // it does not have an equivalent
                    if ((FL_H & this.trc) != 0){
                        Trc.out.println("orphan: " + h);
                    }
                    res = false;
                    break;
                }
            }
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("equals: " + res);
        }
        return res;
    }


    /**
     * Deliver the complemented NFA for an element.
     *
     * @param   ci reference to the initial state   
     * @param   cf reference to the ending state   
     * @param   d pointer to the element   
     * @param   ins case-insensitive kind
     */

    /* Complementation is done with the following algorithm:
     *
     *       0.  the piece of NFA is transformed into a DFA.
     *       1.  a new final state is created, and an else edge is
     *           created in all states to it for the states that have the
     *           transition function undefined for some input symbols.
     *           A loop edge for all symbols is added in the newly created
     *           final state, and also an empty edge to a newly created
     *           external final state (this serves to have the graph end in
     *           only one states without outgoing edges).
     *           It is applied also to the last state of the NFA, which does
     *           (which might not have any edges). This means that !abc
     *           matches abcxxx.
     *       2.  an empty edge is created from non final states to the
     *           newly created final state.
     *       3.  edges and states that do not eventually lead to the new final
     *           state are removed.
     *
     * The increase in states when complementing is the normal one implied in
     * the DFA transformation. Complementation cannot be made directly on NFAs
     * in a simple way. Even when NFAs do not have epsilon edges, the complement
     * is not straightforward. Consider a NFA for: "a | ab":
     *
     *      (0)--a-->((1))
     *       |
     *       `--a-->(2)--b-->((3))
     *
     * The complement is made by all strings which are not "a" and not "ab".
     * Complementing the final states and adding catch all edges leads to:
     *
     *      ((0))--a-->(1)
     *        |
     *        `--a-->((2))--b-->(3)
     *       
     * catch-all edges have been omitted in the picture.
     * With input "a", the NFA reaches a final state, so it accepts it
     * incorrectly. The problem is that there are a final and a non final
     * states for input "a". There would be a need to change the NFA semantics
     * to saying that an input is accepted if all paths in the NFA lead to
     * a final state, not only one, which is not viable.
     * Alternatively, there is a need to keep track of the set of states each
     * input may lead to, which is the same as computing the DFA. 
     * Moreover, it is not simple to write a rule which represents the
     * complement of an expression. It requires to build the complemented DFA
     * and derive then a grammar (which is also quite different from the
     * original one, i.e. it is not simply related to it).
     * In other words, there are no simple transformations to apply to an
     * expression to write its complement. This means that it is not viable
     * to transform the internal representation of the grammar and then
     * use the normal FA construction.
     * Therefore the DFA is computed first and then the complement done on it.
     * From the expression, a NFA is created. Its ending state is marked
     * as FINAL with no attached sets of recognised lexemes. This is needed
     * so as to make the automa methods work properly: they recognise states
     * as final when they are FINAL.
     *
     * After having complemented the DFA, there is a need to remove the
     * useless states. E.g. "!!a", when complemented would have a final state
     * which is then made non-final making it become a dead end to be removed.
     *
     * The union of the complement FA with the overall NFA being built
     * is made by appending the list of states of the FA to the overall one,
     * and renumbering the states (while updating the state counter),
     * and discarding then the FA. The NFA names of the FA being appended
     * are also discarded.
     * Before appending, the FINAL marks are removed.
     *
     * In order to combine automa, there is a need to represent them by
     * automa which have one initial state with no incoming edges in it
     * and one ending state without outgoing edges from it, as done in the
     * Thompson's construction. Such are the automa created here.
     * Therefore, the ones that recognize the empty language are represented
     * as two unconnected states.
     */

    private void complement(ParserState ci, ParserState cf, ParserNode s,
        int ins){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("complement: " + s);
        }
        ParserFA nfa = new ParserFA(this);
        nfa.vi_primary(s.def,s,nfa.startState,nfa.endState,ins);
        if ((FL_G & this.trc) != 0){
            Trc.out.println("internal NFA");
//            nfa.trace(false,false,false,Trc.out);
            nfa.trace(false,false,false);
        }
        ParserFA dfa = nfa.nfa_to_dfa();          // transform NFA into DFA
        if ((FL_G & this.trc) != 0){
            Trc.out.println("complement DFA");
//            dfa.trace(false,false,false,Trc.out);
            dfa.trace(false,false,false);
        }
        dfa.complement();                         // complement it
        dfa.markAttr(s);                          // determine TR, EM, etc.
        merge(dfa,ci,cf);                         // merge into current
    }

    /**
     * Merge the specified FA at the end of this one.
     *
     * @param   fa rererence to the FA
     */

    private void merge(ParserFA fa){
        for (ParserState h = fa.sthead;           // renumber states
            h != null; h = h.next){
            h.num = this.numOfStates++;
        }
        this.sttail.next = fa.sthead;             // append in current FA
        this.sttail = fa.sttail;
    }

    /**
     * Merge the specified FA into this one at the specified place.
     *
     * @param   fa rererence to the FA
     * @param   male rererence to the male state to plug to
     * @param   female rererence to the female state to plug to
     */

    /* To dig the FA in place, the edges of the start state of the FA
     * are added to the male's ones, and the edges to its end state are
     * redirected to the female.
     * Nothing is done on the attributes since it is meaningless in general.
     */

    private void merge(ParserFA fa, ParserState male, ParserState female){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("merge into: " + male + " " + female);
//            trace(false,false,false,Trc.out);
            trace(false,false,false);
        }
        ParserTrans last = null;
        for (ParserTrans ts = male.transList;     // add all edges of its start
            ts != null; ts = ts.next){            // .. state to male
            last = ts;                            // seek last
        }
        if (last == null){
            male.transList = fa.startState.transList;
        } else {
            last.next = fa.startState.transList;
        }

        for (ParserState h = fa.sthead;           // redirect edges to end
            h != null;){
            for (ParserTrans ts = h.transList;
                ts != null; ts = ts.next){
                if (ts.nextState == fa.endState){
                    ts.nextState = female;
                }
            }
            ParserState next = h.next;
            if ((h != fa.startState) &&
               (h != fa.endState)){
                h.num = this.numOfStates++;
                h.next = null;
                if (this.sthead == null){         // append state to list
                    this.sthead = h;
                } else {
                    this.sttail.next = h;
                }
                this.sttail = h;
            }
            h = next;
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("merged");
//            trace(false,false,false,Trc.out);
            trace(false,false,false);
        }
    }

    /**
     * Test if this FA represents a (possibly empty) set of characters.
     *
     * @return     <code>true</code> if it is a set
     */

    private boolean isSet(){
        if ((FL_G & this.trc) != 0){
            Trc.out.printf("isSet states %s\n",this.numOfStates);
        }
        boolean res = false;
        doit: {
            if (this.numOfStates <= 1){                // already a DFA
                res = true;
                break doit;
            }
            tras: if (this.numOfStates == 2 || this.numOfStates == 3){
                ParserState start = this.startState;
                if (start == null) start = this.sthead;
                ParserTrans t = start.transList;
                if (t != null){
                    if (t.next != null) break tras;
                    if (t.kind == ParserTrans.EMPTY) break tras;
                    t = t.nextState.transList;
                    if (t != null){
                        if (t.next != null) break tras;
                        if (t.kind != ParserTrans.EMPTY) break tras;
                    }
                }
                res = true;
                break doit;
            }
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.printf("isSet res %s\n",res);
        }
        return res;
    }

    /**
     * Complement this DFA.
     */

    private void complement(){
        ParserState catchall = newState();        // catch-all error state
        newTrans(catchall,catchall,this.gram.alphabet);
        catchall.status |= ParserState.FINAL;
        ParserState ends = newState();            // new ending state
        newTrans(catchall,ends);
        ends.status |= ParserState.FINAL;
        this.endState = ends;

        IntSet compl = new IntSet();
        for (ParserState h = this.sthead;              // swap final and
            h != null; h = h.next){                    // .. intemediate
            if (h == catchall) continue;
            if (h == ends) continue;
            if ((ParserState.FINAL & h.status) == 0){  // not a final,
                h.status |= ParserState.FINAL;         // .. becomes final
                newTrans(h,ends);
            } else {
                h.status &= ~ParserState.FINAL;        // no more final
            }
            compl.assign(this.gram.alphabet);
            for (ParserTrans ts = h.transList;         // edges for all
                ts != null; ts = ts.next){             // .. symbols not present
                switch (ts.kind){
                case ParserTrans.SYM:
                    compl.sub(ts.sym);                 // single symbol
                    break;
                case ParserTrans.SET:
                    compl.sub(ts.set);                 // set
                    break;
                }
            }
            if (!compl.isEmpty()){
                newTrans(h,catchall,compl);
            }
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("complemented");
//            trace(false,false,false,Trc.out);
            trace(false,false,false);
        }
        this.startState.status |= ParserState.NOPURGE; // never remove it
        ends.status |= ParserState.NOPURGE;            // never remove it
        purge();                                       // purge it now
        for (ParserState h = this.sthead;              // remove final
            h != null; h = h.next){
            h.status |= ParserState.FINAL;
            h.status = 0;
            h.nfa_name = null;
        }
        if ((FL_G & this.trc) != 0){
            Trc.out.println("purged");
//            trace(false,false,false,Trc.out);
            trace(false,false,false);
            Trc.out.println("--end");
        }
    }

    /**
     * Deliver the complemented transition for an element representing
     * a set of symbols.
     *
     * @param   ci reference to the initial state   
     * @param   cf reference to the ending state   
     * @param   s pointer to the element   
     */

    private void complementSet(ParserState ci, ParserState cf, ParserNode s){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("complementSet " + s);
        }
        boolean err = false;
        switch (s.kind){
        case ParserNode.S_TER:
            if (s.def == ParserGrammar.dic_emp){  // empty
                err = true;
                break;
            } else if (s.def.code.length != 1){   // not a char
                err = true;
                break;
            } else if (((ParserNode.CASEINSENS |
                ParserNode.CASEINSENS_FULL) & s.status) == 0){
                IntSet cmpl = new IntSet(this.gram.alphabet);
                cmpl.sub(s.def.code[0]);
                newTrans(ci,cf,cmpl);
                s.status |= ParserNode.TR | ParserNode.TY3F;
                break;
            } // no break here
        case ParserNode.S_NT:                     // nonterminal
            ParserFA fa = new ParserFA(this);
            fa.vi_nt_nfa(s.def,fa.startState,     // build nfa
                fa.endState,0);
            if ((FL_G & this.trc) != 0){
                Trc.out.println("internal NFA");
//                fa.trace(false,false,false,Trc.out);
                fa.trace(false,false,false);
            }
            if (!fa.isSet()){                     // not a set
                err = true;
                break;
            }
            IntSet cmpl = new IntSet(this.gram.alphabet);
            ParserTrans t = fa.startState.transList;
            if (t != null){
                switch (t.kind){
                case ParserTrans.SYM:
                    cmpl.sub(t.sym);
                    break;
                case ParserTrans.SET:
                    cmpl.sub(t.set);
                    break;
                }
            }
            if (cmpl.isEmpty()) break;            // empty set
            newTrans(ci,cf,cmpl);
            s.status |= ParserNode.TR | ParserNode.TY3F;
            break;
        default:
            err = true;
            break;
        }
        if (err){
            s.status |= ParserNode.TR | ParserNode.TY3F;
            this.lex.message(ParserLexer.ERR_NOTSET,"",s.point);
        }
    }

    /**
     * Deliver the upto NFA for an element.
     *
     * @param   ci reference to the initial state   
     * @param   cf reference to the ending state   
     * @param   d pointer to the element   
     * @param   ins case-insensitive kind
     */

    /* The upto operator ~alpha is implemented as:
     *
     *     [ !{ {<alphabet>}* alpha {<alphabet>}* } ] alpha
     *
     * The NFA for the inner expression is build first, and then
     * complemented. Then the initial NFA is reduced to represent alpha
     * and appended to the complemented one.
     * This is done to spare a second generation of a NFA for alpha, which
     * would produce the same errors as the first one.
     */

    private void upto(ParserState ci, ParserState cf, ParserNode s,
        int ins){
        if ((FL_G & this.trc) != 0){
            Trc.out.println("upto: " + s);
        }
        ParserFA nfa = new ParserFA(this);

        IntSet any = new IntSet(this.gram.alphabet);
        ParserState any1 = nfa.newState();        // first any
        nfa.newTrans(nfa.startState,any1);
        nfa.newTrans(any1,any1,any);
        ParserState alphasi = nfa.newState();     // alpha initial
        nfa.newTrans(any1,alphasi);
        ParserState alphasf = nfa.newState();     // alpha final
        nfa.vi_primary(s.def,s,alphasi,alphasf,ins); // alpha

        ParserState saved_tail = nfa.sttail;
        ParserState any2 = nfa.newState();        // second any
        nfa.newTrans(alphasf,any2);
        nfa.newTrans(any2,any2,any);
        nfa.newTrans(any2,nfa.endState);
        if ((FL_G & this.trc) != 0){
            Trc.out.println("upto NFA");
//            nfa.trace(false,false,false,Trc.out);
            nfa.trace(false,false,false);
            Trc.out.println("--");
        }
        ParserFA compl = nfa.nfa_to_dfa();        // transform NFA into DFA
        if ((FL_G & this.trc) != 0){
            Trc.out.println("upto first");
//            compl.trace(false,false,false,Trc.out);
            compl.trace(false,false,false);
            Trc.out.println("--");
        }
        compl.complement();
        newTrans(compl.startState,compl.endState);   // empty

        newTrans(compl.endState,alphasi);         // append alpha
        nfa.sthead = alphasi;                     // remove added parts:
        nfa.sttail = saved_tail;                  // .. obtain again alpha
        nfa.sttail.next = null;
        alphasf.transList = null;
        compl.endState = alphasf;
        compl.merge(nfa);                         // merge alpha in compl
        if ((FL_G & this.trc) != 0){
            Trc.out.println("upto");
//            compl.trace(false,false,false,Trc.out);
            compl.trace(false,false,false);
            Trc.out.println("--");
        }
        compl.markAttr(s);                        // determine TR, EM, etc.
        merge(compl,ci,cf);                       // merge compl into current
    }

    /**
     * Deliver the difference NFA of a FA and a concatenation of elements.
     *
     * @param      op1 reference to the FA of the first operand
     * @param      op2b reference to the first element
     * @param      op2e reference to the last element
     * @param      ins case-insensitive kind
     * @return     a DFA representing the difference
     */

    /* Difference is implemented as: a - b = !(!a | b).
     * When the operands are sets, it is optimised.
     */

    private ParserFA difference(ParserFA op1, ParserNode op2b,
        ParserNode op2e, int ins){
        ParserFA op2 = new ParserFA(this);
        op2.vi_conc(null,op2b,op2e,               // build op2
            op2.startState,op2.endState,ins);
        if (op1.isSet() && op2.isSet()){
            ParserTrans t1 = op1.startState.transList;
            ParserTrans t2 = op2.startState.transList;
            IntSet m = null;
            if (t1 != null){
                if (t1.kind == ParserTrans.SET){
                    m = new IntSet(t1.set);
                } else {
                    m = new IntSet(t1.sym);
                }
                if (t2 != null){
                    if (t2.kind == ParserTrans.SET){
                        m.sub(t2.set);
                    } else {
                        m.sub(t2.sym);
                    }
                    t1.kind = ParserTrans.SET;
                    t1.set = uniqueIntSet(m);
                }
                if ((FL_G & this.trc) != 0){
                    Trc.out.println("difference-set: " + t1);
                }
            }
            return op1;
        }

        op1.endState.status |= ParserState.FINAL;
        op1 = op1.nfa_to_dfa();                   // transform NFA into DFA
        if ((FL_G & this.trc) != 0){
            Trc.out.println("difference: " + op2b + "..." + op2e);
//            op1.trace(false,false,false,Trc.out);
            op1.trace(false,false,false);
        }
        op1.complement();                         // complement op1
        op1.endState.status |= ParserState.FINAL; // complement removes it
        op1.merge(op2,op1.startState,op1.endState);

        ParserFA dfa = op1.nfa_to_dfa();          // transform it into DFA
        dfa.complement();                         // complement it
        if ((FL_G & this.trc) != 0){
            Trc.out.println("difference:");
//            dfa.trace(false,false,false,Trc.out);
            dfa.trace(false,false,false);
            Trc.out.println("--");
        }
        return dfa;
    }

    /**
     * Deliver the intersection NFA of a FA and a concatenation of elements.
     *
     * @param      op1 reference to the FA of the first operand
     * @param      op2b reference to the first element
     * @param      op2e reference to the last element
     * @param      ins case-insensitive kind
     * @return     a DFA representing the intersection
     */

    /* Intersection is implemented as: a & b = !(!a | !b).
     * When the operands are sets, it is optimised.
     */

    private ParserFA intersection(ParserFA op1, ParserNode op2b,
        ParserNode op2e, int ins){
        ParserFA op2 = new ParserFA(this);
        op2.vi_conc(null,op2b,op2e,               // build op2
            op2.startState,op2.endState,ins);
        if (op1.isSet() && op2.isSet()){
            ParserTrans t1 = op1.startState.transList;
            ParserTrans t2 = op2.startState.transList;
            IntSet m = null;
            if (t1 != null){
                if (t1.kind == ParserTrans.SET){
                    m = new IntSet(t1.set);
                } else {
                    m = new IntSet(t1.sym);
                }
                if (t2 != null){
                    if (t2.kind == ParserTrans.SET){
                        m.and(t2.set);
                    } else {
                        m.and(t2.sym);
                    }
                    t1.kind = ParserTrans.SET;
                    t1.set = uniqueIntSet(m);
                } else {
                    op1.startState.transList = null;  // empty
                }
                if ((FL_G & this.trc) != 0){
                    Trc.out.println("intersection-set: " + t1);
                }
            }
            return op1;
        }

        op1.endState.status |= ParserState.FINAL;
        op1 = op1.nfa_to_dfa();                   // transform NFA into DFA
        if ((FL_G & this.trc) != 0){
            Trc.out.println("difference: " + op2b + "..." + op2e);
//            op1.trace(false,false,false,Trc.out);
            op1.trace(false,false,false);
        }
        op1.complement();                         // complement op1
        op2.endState.status |= ParserState.FINAL;
        op2 = op2.nfa_to_dfa();                   // transform into DFA
        op2.complement();                         // complement op2
        op1.merge(op2,op1.startState,op1.endState);

        op1.endState.status |= ParserState.FINAL; // complement removes it
        ParserFA dfa = op1.nfa_to_dfa();          // transform it into DFA
        dfa.complement();                         // complement it
        if ((FL_G & this.trc) != 0){
            Trc.out.println("intersection:");
//            dfa.trace(false,false,false,Trc.out);
            dfa.trace(false,false,false);
            Trc.out.println("--");
        }
        return dfa;
    }
}