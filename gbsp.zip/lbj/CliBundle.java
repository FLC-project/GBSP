/*
 * @(#)CliBundle.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;
import lbj.Cli.*;

/**
 * The <code>CliBundle</code> class provides the English locale for
 * the <code>Cli</code> class.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */


public class CliBundle extends ListResourceBundle {
    public Object[][] getContents() {
        return contents;
    }

    // LOCALIZE THIS

    public static final Qualifier ENCOD =
        new Qualifier('e',"enc",null,"encoding",Cli.AR_VALREQ | Cli.AR_ENC,
            String.class,"encoding");

    private static final Qualifier IND_FILE =      // default indirect argument
        new Qualifier(' ',"@",null,"file",Cli.AR_IND |
            Cli.AR_VALREQ,String.class,"indirect file",
            new Qualifier[] {ENCOD}
        );

    private static final Qualifier[] DEF_IND = {   // default restricted argument
        IND_FILE,
    };
    private static final Qualifier[] DEF_ARGS = {  // default arguments
        IND_FILE,
        new Qualifier(' ',"arg-display",  null,"",0,void.class,"display arguments"),
        new Qualifier(' ',"help",         null,"",0,void.class,"display help"),
        new Qualifier(' ',"usage",        null,"",0,void.class,"usage"),
        new Qualifier(' ',"usage-brief",  null,"",0,void.class,"usage brief"),
        new Qualifier(' ',"usage-verbose",null,"",0,void.class,"usage verbose"),
        new Qualifier(' ',"usage-all",    null,"",0,void.class,"usage all"),
        new Qualifier(' ',"version",      null,"",0,void.class,"version"),
    };

    private static final String[] MSGTAB = {
        "SUCCESS, successful operation",      //  0
        "MISNAME, missing name",              //  1
        "SECURITY, security violation",       //  2
        "UNKARG, unknown argument",           //  3
        "MISVAL, missing value",              //  4
        "SEQUENCE, out of sequence",          //  5
        "ILLNAME, illegal name",              //  6
        "STRNOCL, string not closed",         //  7
        "NOCLO, list not closed",             //  8
        "NOCORE, insufficient core",          //  9
        "UNEXP, unexpected character",        // 10
        "MISPAR, missing parameter",          // 11
        "MISQUAL, missing qualifier",         // 12
        "ILLTYPE, illegal type",              // 13
        "AMBNAME, ambiguous name",            // 14
        "IOERR, io error",                    // 15
        "INIT, not initialised",              // 16
        "ILLIND, illegal indirect argument",  // 17
        "NOCBK, no such callback",            // 18
        "REPQUAL, repeated qualifier",        // 19
        "NOLIST, list not allowed",           // 20
        "ILLQUAL, illegal qualifier",         // 21
        "ILLATTR, illegal attribute",         // 22
        "NOCMD, missing command name",        // 23
        "NULLCMD, null command",              // 24
        "NEST, endless indirect file nesting",// 25
        "UNKCMD, unknown command",            // 26
        "ILLVAL, illegal value",              // 27
        "ILLPAR, illegal parameter",          // 28
        "RANGE, out of range",                // 29
        "ILLNUM, illegal number",             // 30
        "OUTLIMIT, limits exceeded",          // 31
        "ILLFILE, illegal file",              // 32
        "INVDEF, invalid command definition", // 33
        "NORES, no resource",                 // 34
        "INDFILE, error in indirect file",    // 35
        "NOINIT, initialisation failed",      // 36
    };

    private static final Object[][] contents = {
        {"DEFARGS", DEF_ARGS},
        {"DEFIND",  DEF_IND},
        {"MSGTAB",  MSGTAB},

        // LOCALIZE THIS

        {"USAGE", "Usage:"},
        {"BRIEFREM", "Use %s;%s for more assistance."},
        {"USGALL", "%t>;Use %2s %sm;."},
        {"QU_DISPLAY", "to display the arguments"},
        {"QU_USAGE", "for default usage information"},
        {"QU_BRIEF", "for brief usage information"},
        {"QU_VERBOSE", "for verbose usage information"},
        {"QU_ALL", "for all usage information"},
        {"QU_HELP", "for help"},
        {"QU_VERSION", "to display the version"},
        {"EMPTY", ""},
        {"YESNO", "yes|no"},
        {"VALUES", new String[] {"no","yes","false","true","off","on"}},
        {"BOH","??"},
        {"ASSIST", "%%%s-W-USE, use %s;%s for more assistance"},
        {"SORRYH", "sorry, no help available"},
        {"SORRYV", "sorry, no version available"},
        {"ONFILE", "on file"},
        {"OR", "or"},
        {"ARGUMENT", "argument"},
        {"INT8",  "signed 8-bits integer"},
        {"INT16", "signed 16-bits integer"},
        {"INT32", "signed 32-bits integer"},
        {"INT64", "signed 64-bits integer"},
        {"UNINT8",  "unsigned 8-bits integer"},
        {"UNINT16", "unsigned 16-bits integer"},
        {"UNINT32", "unsigned 32-bits integer"},
        {"UNINT64", "unsigned 64-bits integer"},
        {"BOOL",  "boolean"},
        {"CHAR",  "character"},
        {"FLOAT",  "float"},
        {"DOUBLE",  "double"},
        {"STRING",  "string"},
        {"DATE",  "date/time"},
        {"NOVALUE",  "no value"},

        // END OF MATERIAL TO LOCALIZE
    };
}
