/*
 * @(#)Formatter.java       1.0 98/11/04
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.text.*;
import java.util.*;
import java.math.*;
import java.lang.reflect.*;
import lbj.Varg.*;
import lbj.IoStream.*;
//import lbj.FormFloat.*;

/**
 * The <code>Formatter</code> class provides text formatting.
 *
 * @author  Angelo Borsotti
 * @version 1.0   04 Nov 1998
 */

/**
 * The text formatting operation takes a format argument and an io list
 * arguments. It interprets the format and produces a textual representation
 * of the values in the io list.
 * The format specifies the external form of the values being transferred
 * and the layout of data within the records.
 * Text formatting can be done on a stream or on a string. A formatting
 * object can be initialized both with a constructor and dynamically with
 * a clause. Likewise, the completion of the formatting operations can
 * be achieved both with a cluse or a <code>close()</code> method.
 * Its behaviour is incremental: subsequent calls are equivalent to a
 * single call in which the format and the io list are the concatenations
 * of the ones of all the calls.
 * The methods are not synchronised.
 * It is possible to load the format, the io list and later to format them.
 * E.g.:
 * <p><blockquote><pre>
 *        pk.f("aaa");
 *        pk.v(1);
 *        pk.v(2);
 *        pk.write();      // format the io list
 * </pre></blockquote><p>
 * The <code>f()</code> registers the format (a companion <code>l()</code>
 * registers a localised format). The <code>v()</code> registers an io
 * list element.
 * The <code>write()</code> call consumes the io list, but not the format,
 * which can then be reused to format another io list.
 * It is also possible to pass the io list in the same call:
 * <p><blockquote><pre>
 *        pk.write("%3x",pk.v(1).v(2));
 * </pre></blockquote><p>
 * The <code>writeln()</code> methods flush the record at the end (before
 * executing an exit callback, if any).
 * The formatting operations are done on a record, which has a length, and a
 * cursor denoting the current insertion position in it ranging from 0 (the
 * first position) up to (and including) length (the last+1 position).
 * The lenght is the net number of characters, excluding any `\n' and/or `\0'
 * that might be inserted at the end of it.
 * <p>
 * Format:
 * <p><blockquote><pre>
 *    format:        [format-text] {format-spec | [format-text]}*
 *
 *    format-text:   characters, that are neither % nor \n nor \f
 *
 *    format-spec:   \% [repetition] {format-clause | parens-clause }
 *    repetition:    {number}* | param | "[]" [ arg ] | #
 *    format clause: {conv-clause | edit-clause | io-clause } [;]
 *    parens-clause: ( format %)
 *    dim:           {digit}+ | *
 * </pre></blockquote><p>
 * Spaces and other format effectors may not be used within format-specs
 * except when format-specs provide them.
 * Format clauses are made of all characters from `<code>%</code>' up
 * to (and not including) the first `<code>%</code>', `<code>,</code>'
 * or space. Additionally, a  `;' may be used to terminate a format-clause
 * (except for `\n' and `\f').
 * It has only a delimiting effect. To introduce it in a clause, precede it
 * with an grave accent (``'), that makes the following character a normal one
 * (including ``'). It can be used only in the clauses in which a string
 * is allowed.
 * To represent a `%' within a format-text, it has to be written twice (`%%').
 * A `\n' in format-text is equivalent to a `%/'; a `\f' is equivalent to
 * `%/%/e;'.
 * For numbers (repetition, widths, etc.) in format-specs, the decimal notation
 * is assumed.
 * <p>
 * During the execution, the format and the io list are scanned from left to
 * right. The interpretation of the format terminates when the end of it has
 * been reached. If at that point there are still elements in the io list
 * the format can conditionally be rescanned to format them (this is allowed
 * only if the previous scan used at least one non-positional element).
 * Each occurrence of a format-text and format-spec is
 * interpreted, and the appropriate action taken as follows:
 * <p>
 * format-text:
 * <p>
 * <dd>
 * It denotes fixed parts of the records. The string of the format-text is
 * transferred to the record as if a format-spec `%s' and an argument in the
 * io list that delivers the same string were encountered.
 * <p>
 * format-specification:
 * <p>
 * <dd>
 * It denotes the external representations of values, and it allows to
 * editing the record or control the actual i/o operations.
 * If it contains a repetition, it is equivalent to a sequence of as many
 * clauses as the number denoted by the repetition (after having replaced
 * any param in it with their values).
 * The repetition can be 0, in which case the format-spec is not considered
 * (and its syntax and semantics not checked).
 * <p>
 * If it is a conversion-clause, then one (or more) arguments are taken
 * from the io list, the conversion function selected by the conversion-code
 * and its qualifiers is applied to its value, and the resulting string
 * is tansferred to the record.
 * If it is an editing-clause or an io-clause, then the editing or io function
 * selected by the code in it and by its qualifiers is applied to the
 * record without reference to the arguments.
 * Some clauses allow a length or width. If it is a param, it denotes a variable
 * integral value, which is taken from the io list.
 * If it is a parens-clause, then the format that is contained in it
 * is repeatedly scanned according to the repetition factor.
 * If none is specified, 1 is taken by default.
 * <p>
 * An array repetition factor denotes n elements, where n is the number of
 * the elements of the array (or the array slice), which replace virtually
 * the array itself in the io list.
 * A String or StringBuffer can be treated as an array, and thus can be
 * sliced.
 * <p>
 * A repetition factor which is `#' is unlimited. A clause which has
 * an unlimited repetition factor in front of it is repeated at most
 * as many times as the number of remaining elements in the io list,
 * or the current array, if an array is being processed.
 * A parens clause with an unlimited repetition factor is not reentered
 * if at the end the elements are exausted.
 * <p>
 * When a clause contains an array repetition factor, an array is taken
 * from the io list as specified for conv clauses.
 * When a clause (which is not a parens-clause) contains an array repetition
 * factor, it is repeated at most as many times as the elements of the array.
 * i.e. it is equivalent to a parens clause with an array repetition factor
 * in front of it and that clause inside. E.g. %[]c is equivalent to %[](%c%).
 * <p>
 * When a parens-clause contains an array repetition factor, the clauses in it
 * are bound to take values from the elements of the array.
 * The repetition factor of a parens-clause with an array repetition factor in
 * it is the (first) dimension of the array.
 * The parens clause is repeated at most as many times as the elements of the
 * array. If during the processing of it, the elements of the array are
 * exhausted, the parens clause is ended and processing restarted after it.
 * An array repetition factor in a clause which is nested in a parens-clause
 * with an array repetition factor in it denotes a reference to an inner array.
 * I.e. the outer array is made of references to arrays.
 * A null element is treated as a reference to an empty array.
 * A clause which requires an element while the array has been exhaused makes
 * the enclosing parens-clause be terminated.
 * A parens-clause is not repeated if there are no more elements and an array
 * is being processed.
 * <p>
 * The elements of the io list can denote elementary values, strings, arrays,
 * and objects in general. Slices of strings and arrays can also be specified
 * by indicating the start (inclusive) and end (non inclusive) index.
 * <p>
 * In a format, some formatting parameters can be indicated literally, and
 * can also be denoted by a value taken from the io list. That value can
 * be any value which can be converted to an integral value.
 * <p><blockquote><pre>
 * param: * [[+|-] <digit>+ ]
 * </pre></blockquote><p>
 * If a number is not specified, it denotes the current element in the io
 * list (possibly redirected to an array); the current element then is
 * advanced to the next. Otherwise, it indicates the position of the element:
 * if + is specified, the element at the n-th relative position from the
 * current, if - is specified, the n-th before the current, and otherwise
 * the n-th element. If a number is specified, the element is always taken
 * from the (top-level) io list (i.e. not from an array).
 * <p>
 * In clauses which format elements, if no element indicator is specified,
 * the current element in the io list is taken (and for some clauses other
 * elements subsequent to it), and the current element advanced to the next
 * one, otherwise $ is specified:
 * <p><blockquote><pre>
 * arg: $ [[+|-] {digit}+ ]
 * </pre></blockquote><p>
 * If no number is specified, it is as if also a $ were not specified,
 * If + is specified, the n-th element from the current is taken, of before
 * the current if - is specified, or the n-th element otherwise. Note that
 * inside an array param clause it denotes an element of the array.
 * Clauses which require more than one value take the 2nd, 3rd, etc.
 * always after the first element.
 * <p>
 * An error is returned if:
 * <ul>
 * <li>the format has an illegal syntax, or
 * <li>an attempt to move the cursor below 0 or above the record length
 *   is made, or
 * <li>an io-clause is encountered and there is neither a file reference
 *   nor an output callback, or
 * <li>the type of a value in the io list is not compatible with the
 *   any of the ones expected by a corresponding clause, or
 * <li>there are less arguments in the io list than those indicated in the
 *   format, or
 * <li>the format does not allow to visit all the elements in the io list
 *   (this check can be disabled).
 * </ul>
 * When an error occurs, the <code>res</code> field represents the error
 * code and the <code>excObj</code> field the FormatterError object.
 * In the latter, the <code>code</code> field contains the same value as
 * <code>res</code>, and the <code>value</code> field the index in the
 * format at which the error occurred, except for <code>ERR_MISMATCH</code>
 * for which it represents the index of the first unused value in the io
 * list. Moreover, the <code>path</code> field contains the file pathname
 * if the error is ERR_IOERR.
 * When an error occurs, and the formatter has opened a file, it closes
 * that file.
 * <p>
 * <b>Value representation</b>
 * <p><blockquote><pre>
 * conv-clause: code {qualifier}* [width] [arg]
 * code:        character [character]        (see below)
 * qualifier:   {character}*                 (see below)
 * width:       min [: [max]] | : max
 * min:         [-]{digit}+ | param
 * max:         {digit}+ | param
 * </pre></blockquote><p>
 * The width can also occur before or within the qualifiers, but after all
 * numeric qualifiers.
 * If width is not specified, 0 is taken by default. Max must either not be
 * specified, or be 0 or greater than min (if present).
 * Precision and exponent can be specified only for floating point clauses.
 * Exponent can be specified only for the e and g conversions.
 * Qualifiers can be specified in any order.
 * <p>
 * It transforms a value into its external representation (r), which is a string
 * whose length depends on the value being converted, and it inserts (part of)
 * it in a portion of the record.
 * That portion may be as wide as r (free format), or may have a given length
 * (fixed format).
 * Free format is selected if width = 0, fixed format otherwise. If max is
 * not specified, it is taken equal to min.
 * Left justification is done if a negative width is specified, right otherwise.
 * In the fixed format case, a field of at least w = abs(min) and at most max
 * characters starting from the cursor is written into the record as follows:
 * <ul>
 * <li>if length(r) <= w, then r is justified to the left or to the right in
 *   the field (according to the justification).
 *   The unused part, if any, is filled with padding characters.
 * <li>otherwise, if length(r) <= max, the string is written as it is,
 * <li>otherwise the string is truncated (on the left if the right justification
 *   is selected, otherwise on the right) and transferred.
 *   If the qualifier z is present, or if evidentiation is selected as
 *   the default, w ``overflow indicator'' characters (*) are transferred
 *   instead. By default evidentiation is not selected.
 *   The truncation is applied to the external representation including the
 *   sign, base, etc., if any.
 * </ul>
 * In the free format case, the string delivered by the conversion is inserted
 * at the cursor (left justification).
 * <p>
 * After the transfer, the cursor is implicitely advanced to the next available
 * position, and the maximum position is set to the larger between the current
 * and the (old) maximum.
 * <p>
 * External representations
 * <p>
 * The external representation is the one defined below for the type of the
 * value, which is determined by the code:
 * <ul>
 * <li><code>i</code>    integral<br>
 *     <code>u</code>    unsigned integral<br>
 *     <code>j</code>    integral index<br>
 *   <p>
 *   Integral values are the ones whose type is one of the predefined integer,
 *   boolean or charater types, their wrapper types, or the BigInteger type.
 *   Integer values are represented as one or more digits in a decimal default
 *   base without leading zeroes and with a leading (or trailing) minus if
 *   negative. The digits, the sign, its position, the grouping separator
 *   and the length of groups are taken according to the current locale.
 *   `0' as padding character denotes the locale zero. When selected together
 *   with grouping, grouping separators are included also in leading filling
 *   zeroes. The code `<code>j</code>' selects the intrinsic signedness of the value to
 *   be converted (i.e. singed except for characters); `<code>u</code>' makes the values
 *   to be interpreted as unsigned integers.
 *   The specified integral minimum number of digits is generated by numerically
 *   padding the number.
 *   The code `j' takes as value the index of the next array element. It
 *   can be used only when an array is being formatted.
 *   The following qualifiers are available:
 *   <p><blockquote><pre>
 *   [+] [' | ^] [f&lt;c&gt;] [h] [b|o|d|x|X|r|R] [a] [integral.] [L]
 *
 *         +       + sign if >= 0
 *         '       thousands grouping according to current locale
 *         ^       thousands grouping disable (default)
 *         &lt;c&gt;     numeric filling character for the integral part. The
 *                 grouping separators are removed if &lt;c&gt; is space.
 *                 If no &lt;c&gt; is available it has no effect.
 *         .       it terminates the integral
 *         h       base, 0 octal, 0x (0X if qualifier X) hexadecimal
 *         b       binary base
 *         o       octal base
 *         d       decimal base
 *         x X     hexadecimal base, x: a-f0-9, X: A-F0-9
 *         r R     r: lowercase roman base, R: uppercase roman (the number
 *                 must not be greater than 199999).
 *         a       alignment: in fixed format the sign and the radix are
 *                 aligned to the left, and the rest to the right
 *                 (this overrides the justification).
 *         L       use only Latin-1 characters instead of Unicode characters
 *   </pre></blockquote><p>
 * <li><code>f</code>    float, double, integral
 *     <code>fm</code>   float, double currency
 * <p>
 *   Floating values are the ones whose type is one of the predefined
 *   numeric, boolean or character types, BigInteger, BigDecimal, or their
 *   wrapper types.
 *   Floating values are represented either with a fixed point: [-]iii.ddd,
 *   or with a scientific notation: [-]iii.dddE[-]eee.
 *   The number of integral digits iii is at least that indicated by
 *   integral, padded with trailing numeric filling characters if the
 *   value has less significant digits. In the scientific notation the
 *   exponent is scaled so that iii be greater or equal to 10**integral.
 *   At least one integral digit is included (possibly `0').
 *   The actual number if characters occupied by the integral part is that
 *   number plus the thousands separators (e.g. 5 with thousands separators
 *   produces an integral part long 6).
 *   The decimal separator is not included if the ddd is 0 (unless the
 *   qualifier `!' is specified).
 *   The number of decimal digits ddd is that denoted by decimal, and if
 *   it is not specified it is the minimum number of digits if the format
 *   is free, otherwise 6.
 *   The number of exponent digits eee is the minimum needed to represent
 *   the exponent.
 *   If the decimal is lower than the natural one, rounding is done.
 *   Currency values are represented either with the local notation (default),
 *   or with the international one.
 *   All the locale dependent characteristics (digits, grouping separator,
 *   decimal separator, etc.) are the ones defined in the current locale
 *   (see %ml).
 *   The following qualifiers are available:
 *   <p><blockquote><pre>
 *   non-monetary:
 *
 *   [+] [' | ^] [f&lt;c&gt;] [integral] [. | !] [decimal] [d|e|E|g|G] [a] [L] [C|M]
 *   integral:   {digit}+ | *
 *   decimal:    {digit}+ | *
 *
 *   P<pattern>
 *
 *   monetary:
 *
 *   [+ | (] [' | ^] [f&lt;c&gt;] [integral] [. | !] [decimal] [i] [c] [=] [a] [L]
 *
 *         +       + sign if >= 0
 *         (       surrounded by parentheses if < 0
 *         '       thousands grouping according to current locale
 *         ^       thousands grouping disable (default)
 *         f&lt;c&gt;    numeric filling character for the integral part. The
 *                 grouping separators are removed if &lt;c&gt; is space.
 *                 If no &lt;c&gt; is available it has no effect.
 *         .       it terminates the integral or it introduces the decimal
 *         !       forces the decimal separator to be present when the precision
 *                 is 0 (N.B. it can be specified also without an integral
 *                 or decimal)
 *         d       fixed point notation (default); it can be useful to
 *                 separate the decimal from the width
 *         e E     scientific, e: [-]m.ddde[-]-xx, E: [-]m.dddE[-]xx
 *         g G     scientific (e if g, E if G) if the exponent that would be
 *                 generated with the qualifier `e' were less than 4, or
 *                 if the integral part would be greater than the specified
 *                 integral number of digits (6 if none specified), otherwise
 *                 otherwise fixed point notation.
 *         i       international representation for currecny
 *         c       eliminates the currency symbol
 *         a       alignment: as for `i' code.
 *         L       use only Latin-1 characters instead of Unicode characters
 *                 for infinity, NaN and grouping (space instead of \u00a0)
 *         C       the value is multiplied by 100 and the percent sign is
 *                 appended
 *         M       the value is multiplied by 1000 and the permille sign is
 *                 appended
 *         P       &lt;pattern&gt; is the NumberFormat pattern to be used for
 *                 formatting the number. No other qualifiers are allowed.
 *                 For BinInteger and BigDecimal, the value converted is that
 *                 of the number promoted to a double.
 *   </pre></blockquote><p>
 *   The following representations are given to special numbers:
 *   <p><blockquote><pre>
 *        -Inf  or a locale one:  negative infinity (e.g. -1.0/0)
 *        +Inf  or a locale one:  positive infinity (e.g. 1.0/0)
 *        NaN   or a locale one:  NaN's (e.g. 0.0/0)
 *   </pre></blockquote><p>
 * <li><code>b</code>    booleans
 *   <p>
 *   Boolean values are the ones whose type is one of the predefined integer,
 *   boolean or charater types, ot their wrapper types.
 *   They are represented in several possible ways according to the
 *   qualifiers:
 *   <p><blockquote><pre>
 *        [b | t | T | y | Y | o | O]
 *
 *        b       0/1
 *        t T     t: true/false (default), T: TRUE/FALSE
 *        y Y     y: yes/no, Y: YES/NO
 *        o O     o: on/off, O: ON/OFF
 *   </pre></blockquote><p>
 * <li><code>c</code>    characters
 * <p>
 *   Character values are the ones whose type is one of the predefined integer,
 *   boolean or charater types, ot their wrapper types.
 *   Character values are represented by default as themselves.
 *   The following qualifiers are available:
 *   <p><blockquote><pre>
 *        [o | x | U | b | B&lt;c&gt;&lt;c&gt;] [h] [j | e | r] [d] [l | u | t]
 *
 *        o    convert all characters in range &#92;u0000 .. &#92;u001F
 *             in octal \ooo, and the ones in &#92;u007F .. &#92;u00FF
 *             in Unicode &#92;unnnn form
 *        x    convert all characters not in &#92;u0020 .. &#92;u007E
 *             in hexadecimal \xnnnn (with lowercase letters)
 *        U    same, in Unicode &#92;unnnn form
 *        b    interpret each byte as a bit string (the h qualifier is
 *             in this case ignored). By default, 0 bits are represented
 *             as 0 and 1 bits by 1. It takes effect only on character
 *             values (as defined above) and byte[] strings.
 *        B&lt;c&gt;&lt;c&gt;  same as b, but it is followed by a two characters which give
 *             the representations for 0 and 1 bits. If no &lt;c&gt; is available it
 *             has no effect.
 *        h    convert html special characters ("><&) into html entities
 *        j    include delimiters (' for characters, " for strings), and
 *             escape \ in front of special characters, and Unicode &#92;u for
 *             nonprintable characters by default
 *        e    escape Java special characters as for 'j' above, but do not
 *             enclose in delimiters. It serves to compose strings incrementally.
 *        r    convert LF characters into line separators
 *        l    convert to lowercase according with the current locale.
 *             For Turkish:
 *             latin small letter i -> latin capital letter I with dot above U+0130,
 *             latin small letter dotless i U+0131 -> latin capital letter I
 *        u    convert to uppercase according with the current locale.
 *             For Turkish it is the opposite of lowercase conversion.
 *             For all locales:
 *             sharp s U+00df -> SS
 *             ligatures: ff, fi, fl, long st, st, ffi, ffl -> FF, FI,
 *                  FL, ST, ST, FFI, FFL
 *        t    convert to titlecase according with the current locale.
 *             For Turkish, same as for uppercase conversion. For all
 *             locales, ligatures are expanded with the first letter
 *             capitalised.
 *   </pre></blockquote><p>
 * <li><code>s</code>    character strings, and values of any type
 * <p>
 *   Character string values are the ones whose type is one of the predefined
 *   String, StringBuffer, char[] and byte[] types, and also Str types.
 *   Character string values are lexically represented as strings of
 *   characters of length L. A null argument value is taken as an empty
 *   string.
 *   If the type of the value is not a string or a character, the qualifiers
 *   which are appropriate for the value are allowed, otherwise the same
 *   qualifiers as for characters are available, and:
 *   <p><blockquote><pre>
 *        m
 *
 *        m    the string taken from the io list (possibly a slice) is
 *             interpreted as a key to access the current resouce bundle,
 *             from which the associated string is taken.
 *   </pre></blockquote><p>
 *   If the value is 1. boolean, 2. integral, 3. float/double, 4. character,
 *   5. date, it has the same semantics as their respective clauses.
 *   If the value that of an object whose class implements Formatter.Api,
 *   the representation is that delivered by its format() method.
 *   Otherwise, if the value is an instance of <code>Throwable</code>, then the
 *   message localized with the current locale of Formatter is taken.
 *   Otherwise, if the value's class defines the <code>toString()</code>
 *   method, it is called to obtain the external representation, otherwise
 *   a representation is automatically constructed by key/value pairs
 *   separated by equal signs of all the accessible fields of the value.
 *   <p>
 * <li><code>p</code>    pointer
 *   <p>
 *   Pointer values are represented as hexadecimal hash values, or null.
 *   The hash values are the ones defined for the Objct class even if
 *   redefined in a subclass.
 *   Except when null, they have the number of digits needed to represent
 *   all bits of the address.
 *   The following qualifiers are available:
 *   <p><blockquote><pre>
 *        [c | h ] [o]
 *
 *        c    prefix with the class name and "."
 *        h    prefix with the class hash value and "."
 *        o    represent null pointers with `0' instead of "null"
 *   </pre></blockquote><p>
 *   When the value is that of an object whose class implements the Formatter.Api
 *   class, its method format() is called. It should insert the external
 *   representation of the reference of that object, which can in general
 *   be different from that of the value of the object. A same format()
 *   would provides both, depending on the code of the clause.
 *   <p>
 * <li><code>d</code>    date and time
 *   <p>
 *   Date and time are represented as specified in DateFormat.
 *   The following qualifiers are available:
 *   <p><blockquote><pre>
 *        [d | s | m | l | f] [D | S | M | L | F] | P<string>
 *
 *        d    DEFAULT date format
 *        s    SHORT date format
 *        m    MEDIUM date format
 *        l    LONG date format
 *        f    FULL date format
 *        D    DEFAULT time format
 *        S    SHORT time format
 *        M    MEDIUM time format
 *        L    LONG time format
 *        F    FULL time format
 *        P    pattern, <string> as defined in SimpleDateFormat
 *   </pre></blockquote><p>
 *   If no qualifiers are specified, `d' is taken as default.
 *   <p>
 * <li>?    condition
 *   The conditional clause has the following syntax:
 *   <p><blockquote><pre>
 *        %? clause [ %: clause ]
 *
 *        clause:   format-text | format-spec
 *   </pre></blockquote><p>
 *   <p>
 *   The conditional clause takes a boolan value, and it processes
 *   the first clause if the value is true, otherwise the second
 *   one, if present.
 *   Note that only one clause is allowed. If several clauses need occur,
 *   a parens-clause must be used.
 *   <p>
 * <li>General qualifiers
 *   <p>
 *   The following general qualifiers are defined:
 *   <p><blockquote><pre>
 *        [p<c>] [z | Z] [A] [n]
 *
 *        p&lt;c&gt;  padding with the character c that follows the qualifier.
 *              If 'p' is not present, then padding is done with spaces.
 *              If no <c> is available it has no effect.
 *        z     overflow evidence. If truncation is done, the field is filled
 *              with * characters.
 *        Z     silent truncations: the opposite of z.
 *        A     centering: the representation is centered in the field
 *        n     do not break the record before the field in wrap mode
 *   </pre></blockquote><p>
 * </ul>
 * <b>Editing</b>
 *   <p><blockquote><pre>
 *   edit-clause: code {qualifier}* [width]
 *   code:                                     (see below)
 *   qualifier:                                (see below)
 * </pre></blockquote><p>
 * The width can also occur before or within the qualifiers.
 * If width is not specified, 1 is taken by default if the code is not t,
 * otherwise it depends on the qualifier.
 * <p>
 * The following codes (editing functions) are defined:
 * <p><blockquote><pre>
 *   x        space: insert width blanks.
 *   t        absolute tabulation: move the cursor to the position width.
 *   t+       relative tabulation (skip right): move the cursor rightwards
 *            by width positions.
 *   t-       relative tabulation (skip left): move the cursor leftwards
 *            by width positions.
 *   t=       set tab, at current position if width not specified,
 *            at width otherwise.
 *   t&gt;    move the cursor to the next tab position, or to the max of
 *            cursor if no tab present; if width is specified, move ahead
 *            width tabs.
 *   t&lt;    move to the previous tab position, or at the beginning of the
 *            record if no tab present; if width is specified, move backwards
 *            width tabs.
 *   t&       tabs to the width-th tab stop (tab nr. 0 if width is not
 *            specified), or to the max of the record if there are less than
 *            n stops (it has the same effect as as %t0%t>n).
 *   ts       set tabs every width columns, 8 if width not specified.
 *   tc       clear tab at the current position, if width not specified,
 *            otherwise at the width one.
 *   tC       clear all tabs from the specified position onwards, or all
 *            if not specified.
 *   e        erase width characters before cursor, all if width not specified.
 *   e&gt;    erase width characters at cursor onwards, all if width not
 *            specified.
 *   a[s | [l] [a]] [j [+|-]]
 *            initialize. If specified, it must occur before processing any
 *            other clause (except %md). If it is not specified, it is as if
 *            %as%mg with a string location of a suitable size were specified.
 *            Creating a formatter on a file, however, bears an implicit
 *            initialization.
 *            If 's' is specified, a string (char[]) location is taken from
 *            the io list, and used to hold the output. If a slice is specified,
 *            its length is taken as the record length, otherwise the record
 *            length is that of the array.
 *            Otherwise the output is directed to a file, which has the default
 *            encoding.
 *            If 'l' is specified, the file is taken as a listing file (i.e.
 *            carriage positioning characters will be inserted in it).
 *            If 's' is not specified, and a value which can be converted to
 *            a string is present in the io list, a file with that string as
 *            pathname is opened. Otherwise that value must denote a
 *            BufferedWriter which is taken to have been opened previously,
 *            or a Writer or an OutputStreamWriter or an IoStream which are
 *            opened. If `a' is specified, the open is made in append.
 *            A record whose lenght is taken from the io list is then
 *            allocated dynamically.
 *            [j [+|-]] sets the error handling as for %mj[+|-]. However, it
 *            does not apply to the errors which occur within a <code>f()</code>
 *            or <code>v()</code> in the same call.
 *   z        terminate the operations. It releases the memory allocated and
 *            closes the file if it was opened by write(). To perform other
 *            formatting operations on the object with the format string in
 *            which %z occurs, initialization should be done explicitly
 *            with %a.
 *   mj[+|-]  if `+' is specified, make the methods abort when an error occurs,
 *            if `-' is specified, make them return an error status, otherwise
 *            make them throw a FormatterError (default).
 *   md&lt;fl&gt; enable tracing. Any character is allowed, but only the ones
 *            that control tracing have effect. Tracing is disabled before
 *            exiting so that a subsequent call need not be affected.
 *            `-' clears the trace flags set up to that point.
 *   mu       set the user data pointer in the object to the value taken
 *            from the io list.
 *   ml[d|s]&lt;num&gt; set the locale denoted by &lt;num&gt; (width, default: 0)
 *            to the locale taken from the io list either as string or Locale
 *            or Lang.
 *            If `s' is specified, it makes also that locale become the current one.
 *            The locale 0 indicates a neutral locale, 1 the default locale.
 *            The locale 0 may not be defined, the ones greater than 1 may not
 *            be redefined. By default the current locale is 0.
 *            The positional notation can be used to denote the name in the
 *            io list. Setting the locale 1 makes the default either fixed,
 *            or hooked to the Lang specified.
 *   ml&lt;num&gt; set the locale to that denoted by &lt;num&gt; (width, default: 0).
 *            It apples to the next conversion clauses until changed.
 *   mm[d|s]<num> set the resource denoted by &lt;num&gt; (width, default: 0)
 *            to the resource bundle whose name is taken from the io list.
 *            If `s' is specified, it makes also that bundle become the
 *            current one. The bundle is localised with the default locale.
 *            The positional notation can be used to denote the name in the
 *            io list.
 *   mm&lt;num&gt;  sets the resource bundle to that denoted by &lt;num&gt; (width,
 *            default: 0). It apples to the next string clauses until changed.
 *   mo-      set insert mode.
 *   mo       set overstrike mode. N.B.  width may not be specified.
 *   mz[-]    select evidentiation as the default; z- deselects it.
 *   mw[-]    enable wrap mode if - is not specified, otherwise it disables it.
 *   mi       indent to column width (the current one if not specified).
 *   mit      indent to the current value of tab nr. width (tab nr. 0 if width
 *            has not been specified).
 *   mi+      increment indentation by width (2 if width not specified).
 *   mi-      decrement indentation by width (2 if width not specified).
 *   mh&lt;str&gt; heading of continuation lines, inserted before the indentation.
 *            Use %mh; to clear it.
 *   mh$      same, string taken frm the io list.
 *   mt&lt;str&gt;  tail of continuation lines, inserted at the end of lines
 *            which are wrapped.
 *   mt$      same, string taken frm the io list.
 *   mr       resume insertion, To be used in insert callbacks to insert
 *            the characters which have caused the call of the callback.
 *   mb&lt;w&gt;  set the break at position w, the current one if not specified.
 *            N.B. pendings, if any, are inserted after the current position.
 *   mb+&lt;w&gt; sets the break w positions ahead of the current, 0 by default.
 *   mb-&lt;w&gt; sets the break w positions before the current, 0 by default.
 *   mbo      breaks off: clauses that set breaks no longer set them.
 *   mbd      breaks off after the next. N.B. to delimit a zone in the format
 *            with a break at the beginning and no breaks inside use
 *            %mbd;...%mbi;
 *   mbi      breaks on: enables again breaks.
 *   mn&lt;str&gt; set the line separator to &lt;str&gt;. By default it is the
 *            platform one, except when the file is an <code>IoStream</code>,
 *            in which case it is that of the file.
 *   mn$      same, string taken frm the io list.
 *   me       terminate the enclosing parens-clause (if any) if an array is
 *            being formatted and there are no more elements.
 *   mp       turn on paging mode by setting to width (default 60) the page
 *            size. When a line to be printed falls out of the current page, an
 *            automatic end-page clause is performed, and a user page callback,
 *            if any, is called. That callback can make use of write() to
 *            produce a page heading, and use the pagnr field of the object,
 *            which contains the page number. An additional pagns field is
 *            available to hold a secondary page number. Page numbers are
 *            initialised to 1. %mp0 turns off paging.
 *   mp>&lt;w&gt; ensure that in the current page there are at least w lines
 *            available, otherwise it makes the next record be printed on a
 *            new page.
 *   mf[-]    enable (disable) flushing after all io operations. By default
 *            flushing is not done.
 *   mc       remove trailing blanks from all lines when emitted.
 *   mc-      do not remove trailing blanks.
 *   ma       cause an error if there are any unused elements in the io list
 *            (default).
 *   ma-      do not cause such an error.
 *   ma+      repeat the format if it allows to use all the elements in the
 *            io list, and cause an error otherwise.
 *   mg       make the text record grow when there is not enough space.
 *   mg-      revert to the default non-growing mode.
 *   &#64;&lt;str&gt; register &lt;str&gt; as pending. &lt;str&gt; is
 *            terminated by the first non-escaped % or ;.
 *   &#64;$   pending taken from the io-list (dynamic pending).
 *   &#64;-&lt;str&gt;  break-disappear pending.
 * </pre></blockquote><p>
 * The clause m can be followed by a list of sub-clauses, like e.g.: "%mo-zb;".
 * The clauses mi, mh, mt take effect only in wrap mode, otherwise they are
 * registered, but do not produce any effect.
 * If the cursor is moved to a position which is greater than the maximum,
 * then the gap between them is filled with blanks, and the maximum set
 * to the current.
 * Note that the cursor can be moved from 0 to to the last+1 position included.
 * The effect produced on the carriage by the output of format effectors (tab,
 * backspace, etc.) is not reflected in the cursor, which denotes the position
 * in the record. As a consequence, format effectors and tabulation may not
 * be used together.
 * <p>
 * <b>I/O control</b>
 * <p><blockquote><pre>
 *   io-clause: code {qualifier}*
 *   code:                                     (see below)
 *   qualifier:                                (see below)
 * </pre></blockquote><p>
 * The i/o control functions (except =) perform an i/o operation.
 * They allow precise control over the positioning of the record.
 * The record and the appropriate representation of the carriage control
 * information are transferred.
 * The initial position of the carriage at the time the file is opened is such
 * that the first character of the first record is printed at the beginning of
 * the first unoccupied line (regardless of any positioning information attached
 * to the text record).
 * <p>
 * The carriage placement is described by means of the following abstract
 * operations on the current column, line and page (c,l,p) considering columns
 * as being numbered from zero starting at the left margin, and lines from zero
 * starting at the top margin.
 * <p><blockquote><pre>
 * n(x): the carriage is moved x lines downward, at the beginning of the line
 *       (new position: (0,(l+x) mod H,p+(l+x)/H), where H is the number of
 *       lines per page);
 * t(x): the carriage is moved w pages downward at the beginning of the line
 *       (new position: (0,0,p+x)).
 * </pre></blockquote><p>
 * The following control functions are provided:
 * <p><blockquote><pre>
 *   /   next record: the record is printed on the next line
 *       (n(1), print record, n(0));
 *   /f  next page: the record is printed on the top of the next page
 *       (t(1), print record, n(0));
 *   /o  current line: the record is printed on the current line
 *       (print record, n(0));
 *   /p  prompt: the record is printed on the next line. The
 *       carriage is left at the end of the line (n(1), print record);
 *   /w  emit: no carriage control is performed (print record);
 *   /e  end page: defines the positioning of the next record, if any, to be at
 *       the top of the next page (this overrides the positioning performed
 *       before the printing of the record). It does not cause any i/o
 *       operation.
 * </pre></blockquote><p>
 * The following qualifiers are defined:
 * <p><blockquote><pre>
 *       n     conditional operation: the operation is performed only
 *             if the record is not empty
 *       N     equivalent to %mw-;%@;%<io-code>n: it flushes a non-empty
 *             record terminating the wrap mode and the pendings.
 * </pre></blockquote><p>
 * After the I/O transfer, the cursor and the maximum are set to 0.
 * There a need to make a distinction between listing files, i.e. the ones
 * for which carriage control information is transferred, and text files,
 * for which [cr]lf is used to separate lines (records). The write() method
 * outputs the appropriate carriage control characters to position the
 * carriage according to the format-spec by taking into account that the
 * initial position when the object is initialised is the first position
 * at the top of the page, and the position reached by the last output in
 * order to optimize the current one.
 * <p>
 * When the output is on a string, no io operations can be performed unless
 * a record output callback is provided.
 * <p>
 * Prompting does does not work well when the output is not a listing because
 * in such a case there is no guarantee that prompts are printed at the
 * beginning of a new line.<br>
 * Prompting is meant to be used with interactive terminals, when after
 * a prompt, a line is read and then processed. Some systems, when the
 * line is entered, echo a n(1) (e.g., upon pressing "enter", they echo
 * also a line-feed). This means that the printing of a subsequent prompt
 * need not perform a n(1) (which would otherwise produce an empty line).
 * The behaviour of prompting is to assume that the cursor is at a new line
 * after prompting when the standard convention of the underlying platform
 * is to echo a newline after "enter".
 * This means that a write operation, like e.g. "next record", which would
 * be done immediately after the printing of a prompt and before the reading
 * of a line would not move the cursor to the next line.
 * <p>
 * Wrap/no-wrap modes
 * <p>
 * In normal mode, if there is not enough space to insert in the record an
 * external representation or a format-text the string is truncated, inserted
 * and an ERR_NOSPACE reported, unless the Formater is told to grow the
 * buffer with %mg (the latter has no effect in wrap mode).
 * <p>
 * In wrap mode, instead, the record is broken at a suitable point, any trailing
 * blanks removed, the record flushed, the remaining part inserted in it (now
 * a new one), and then the original string inserted.
 * When a record is flushed, the tail (if any) is inserted, the record
 * emitted and the indentation and heading (if any) introduced in the (new)
 * record.
 * An io-clause (except end-page) cause the the tail to be inserted, and the
 * record emitted, leaving it in such a state that a subsequent conv-clause
 * of format-text insert also the indentation and heading.
 * To complete a sequence of wrapped lines, a %mw-%/ should be done.
 * <p>
 * To let the user customize the break algorithm, a callback is provided.
 * That callback can e.g. find a suitable place to break the record, flush it,
 * and then insert in the new one the remainder and the current piece.
 * When write() detects that there is not enough space, and a user insert
 * callback has been registered, it calls it. A user insert may not call
 * itself again (by calling write() in it and making it wrap). A user heading
 * callback may neither call itself again not call a user insert. The only
 * allowed calls are from a user insert to a user head. The callbacks can use
 * write().
 * The user insert can just indentify a suitable break and make lastbrk in
 * the object point to it. In such a case it returns and the insertion is then
 * done as usual (the pendings and the user head are inserted).
 * Otherwise, the user method can do all the work: flush the record, insert the
 * remainder and the currect piece, etc., in which case it must set the insdone
 * flag in the object pointed to by the cptr field of the object. This is not
 * necessary if a %mr is done in it.
 * The advantage of the first is that all the work to break save the remainder
 * and flush the record need not be done in the user method.
 * In this case, when the user method is done, insert forces a no-break
 * so that a break is not attempted at the cursor, and instead the one set
 * by the method is taken.
 * In the second case the callback has full control on the record. It can
 * use the %mr clause to insert the current string (the one that made the
 * callback called). The %mr clause inserts the heading (possibly obtained with
 * a user heading callback).
 * <p>
 * If there is no user insert callback, a break is done at the cursor. A break,
 * however, is never done before a tail. A default break point is taken which is
 * the point where the last external representation or a format-text has been
 * inserted.
 * The algorithm used to wrap the record fills the record as much as possible
 * without breaking it before tails, pendings, and explicit no-breaks.
 * In overwrite mode, when the cursor is moved to a position in the middle of
 * the record an attempt is made not to break the piece in the middle of which
 * something is overwritten, provided that such piece was the last one inserted.
 * The algorithm keeps track of the last insertion only, and uses it as a break
 * point.
 * The carriage positioning specified in a io-clause that make the record
 * wrap are used to emit the first record (note that clauses other than
 * next-record and next-page can place the carriage at a position that it
 * different from the cursor); next-record positioning is used for the
 * subsequent records possibly emitted in the same io-clause or as a result
 * of a wrap. This means, e.g. that if a next-page causes the record to be
 * broken, the first one is placed at a new page, and the second at a new
 * line below the first.
 * In wrap mode, io functions other than %/ and %/f produce their specific
 * carriage positioning, but de-synchronize the carriage and the cursor.
 * It is better thus not to mix direct control of the carriage and automatic
 * control with wrap mode.
 * <p>
 * If a heading (%mh) is greater than the record length an ERR_NOSPACE occurs.
 * The indentation is not taken into account because it can change later.
 * If an indentation or a tail (%mi, %mt) is greater than the record length an
 * ERR_NOSPACE occurs.
 * <p>
 * Pendings
 * <p>
 * Pendings are string that are inserted in the record only when a conv-clause
 * or a format-text are processed, and can be otherwise explicitly discarded.
 * This allows to book the insertion of some separating characters which are
 * effectively inserted only if and when a subsequent insertion is done, usually
 * in another, conditioned, write(). They are specified by %@.
 * A %@; clears the pendings.
 * Break-disappear pendings are the ones that are not inserted when they would
 * be placed at the end of a continuation record.
 * In wrap mode a break is not done before a pending.
 * A \n as the last character of a pending makes the record be flushed at
 * that point (with the insertion of tail, indentation and heading) if and
 * when the pending is inserted. A \n in an intermediate position is considered
 * as a normal character. A \n as last character in a break-disappear pending
 * is ignored.
 * An io-clause inserts a pending if one is present which is not a break
 * disappear one (and then removes it).
 * <p>
 * Formatting methods
 * <p>
 * The formatting method processes the format and the io list in the following
 * way:
 * <ul>
 * <li>write() before starting the scan of the format calls entry_cbk().
 *   Then it scans the format, and then it calls exit_cbk(). By default
 *   they perform no action. When processing an io clause, it performs
 *   io operations by calling out_cbk(). When it inserts an external
 *   representation in the record and there is no space it calls ins_cbk()
 *   if one is defined (none by default). That callback can make room in
 *   the record or do the whole insertion (in the latter case it must indicate
 *   it by setting insdone).
 *   When the record is full, it flushes it and it reuses it again. Before
 *   reusing it, it calls head_cbk(), if any.
 *   When the record has to be printed at the top of a page, it calls
 *   page_cbk(), if any.
 *   A subclass can redefine any callback.
 * <li>write() calls the callbacks which correspond to the clause's codes,
 *   which are:
 *   <table>
 *   <tr><td>code</td><td>callback    </td><td>code</td><td>callback   </td><tr>
 *   <tr><td>/   </td><td>io_cbk()    </td><td>i   </td><td>int_cbk()  </td><tr>
 *   <tr><td>    </td><td>text_cbk()  </td><td>j   </td><td>int_cbk()  </td><tr>
 *   <tr><td>@   </td><td>pend_cbk()  </td><td>m   </td><td>mode_cbk() </td><tr>
 *   <tr><td>a   </td><td>init_cbk()  </td><td>p   </td><td>ptr_cbk()  </td><tr>
 *   <tr><td>b   </td><td>bool_cbk()  </td><td>s   </td><td>str_cbk()  </td><tr>
 *   <tr><td>c   </td><td>str_cbk()   </td><td>t   </td><td>skip_cbk() </td><tr>
 *   <tr><td>d   </td><td>date_cbk()  </td><td>u   </td><td>int_cbk()  </td><tr>
 *   <tr><td>e   </td><td>edit_cbk()  </td><td>x   </td><td>blank_cbk()</td><tr>
 *   <tr><td>f   </td><td>float_cbk() </td><td>z   </td><td>term_cbk() </td><tr>
 *   </table>
 *   In addition to these, callbacks are predefined for the remaining
 *   lowercase latin letters so that a subclass can redefine them and
 *   use the corresponding letter as a clause code. If a subclass needs to
 *   introduce additional clauses, it must redefine the dispatch_cbk()
 *   method, which is invoked when no callback has been found to process
 *   a clause code.
 *   In addition to this, a user defined class can implement the Formatter.Api
 *   interface, and provide then the format() method, which is called
 *   when a value is present in the io list for such a class. The format()
 *   method can parse the qualifiers and insert into the record the
 *   appropriate representation of values of that class.
 *   The indended use it to have a subclass when the basic behaviour of
 *   Formatter need be changed, or new clauses need be introduced, and to
 *   implement the Formatter.Api in the other cases.
 * <li>write() upon return leaves in the object a return status and message.
 * <li>it is up to the callbacks to parse the format-spec advancing the pointer
 *   to the format, to pop the appropriate values from the io list, and to
 *   perform the appropriate action(s) on the record.
 *   The only waiver to advance the pointer to the format for callbacks
 *   is when the clause is made by only one character, in which case it
 *   is allowed not to advance it.
 *   Upon entry the index into the format is that of the clause code.
 *   Callbacks can take several arguments from the io list. It is recommended
 *   to obtain all the values before performing an action on the record.
 *   A pointer to a user object is also provided in the object so as to allow
 *   callbacks to get values from some user-defined location which need not
 *   be passed at each call.
 *   The callbacks are called with a repetition factor in the object which
 *   indicates the number of times the operation could be
 *   done. It is up to a callback to perform the operation that number of times,
 *   in which case it has to set the repetition factor to a value <= 0 before
 *   returning, or to do it only once, in which case it must leave it unchanged.
 *   In the latter case the callback will be called repeatedly until the
 *   repetition is exhausted.
 *   If an error is encountered, the callback set an error code in the object.
 *   The format pointer must denote the point in error.
 *   The record has to be filled as much as possible in order to make the
 *   spotting of the error easier.
 * <li>if the execution of a formatting method returns an error, execution
 *   is terminated. If inside a user callback a Formatter object is used with the
 *   error throw mode, and an error occurs, that error is catched by the
 *   enclosing write() call, which reports that the callback failed.
 * <li>when a repetition is specified, the format-spec is scanned repeatedly,
 *   except when it is made of format-text only which does not contain \n.
 * <li>format-specs and parens-clauses preceded by a zero repetition factor
 *   are skipped and the syntax and semantics of the clauses contained in
 *   them (except for the %( and %)) are not checked.
 * <li>tracing of the operations done can be enabled by setting trace
 *   flags in the trc field of the object. Since that field is initialised
 *   by the %a callback, it is not possible to produce tracing for calls
 *   that start with %a.
 * <li>callbacks can call write() and pass the same object received as
 *   argument to it. It acts on the current record, cursor, maximum cursor,
 *   tabs, callbacks and mode. The result of the interpretation of the
 *   format and io list passed to it are applied to that object.
 * </ul>
 */

/*
 * Design issues
 *
 * Syntax of format
 * 
 * It is a good principle to have a general syntax for format-specs,
 * allow to recognize a clause in a format irrespectively on the
 * specific clause. This requires to have a means to tell where a clause
 * ends. This allows in the future to introduce new qualifiers
 * without invalidating existing formats, which would otherwise be
 * the case if clauses where terminated by the first character which may
 * not belong to them (according with a current syntax, which can change
 * in the future).
 * This also allows to parse them before calling callbacks, and to skip them
 * when the repetition is 0.
 * There are several solutions:
 * 
 *  1. clauses are not embedded in the format text. A format is a sequence
 *     of clauses, e.g.: "i7,s2,'aaa',s2". This is more suited to the
 *     creation of tables, where text occurs seldom. A simple message
 *     would be "'message'".
 *  2. clauses are embedded in the format, which is a text, and are
 *     delimited by parenteses, e.g.: "...(i7,o+,t2)..(is7)...".
 *     This has the drawback to require an extra character in simple
 *     cases, e.g.:  "...(s)....", but it is clear. Inside the (),
 *     clauses are separated by commas. Repetitions are a problem because
 *     they contain also text, and thus there is a need for an escape,
 *     e.g. "... (3(i4'text'))...", which need be doubled to denote itself.
 *     Moreover, there is also a need to quote the parentheses to denote
 *     themselves. The possibility to switch the mode from clauses to text
 *     would lead to use it instead of closing the clauses, e.g.:
 *     "...(i7', 'i7)..." instead of "...(i7), (i7)...". If a format starts
 *     with a (, it can continue to the end by mixing text and quoted
 *     clauses, e.g.: "('....'i7'....')". To overcome this, repetitions can
 *     be indicated by a clause, e.g.: "...(3)(i4)text()", which makes
 *     parens-clauses difficult to read. A clause terminates at the closing
 *     or at the comma or at the quote.
 *  3. clauses are embedded in the format, and the qualifiers are enclosed
 *     in some delimiters, e.g.: "...%i(a-7:9)...". This makes simple the
 *     cases of clauses with a single code, while it makes more difficult the
 *     others, e.g.: "...%i(l)....". Since most clauses have qualifiers, this
 *     is not a good solution.
 *  4. clauses are embedded in the format, are started with a dedicated
 *     character and are terminated by some known charactes. E.g., they start
 *     with %<char>, continue with letters, digits +|-|* and terminate at
 *     the first punctuation, which is not part of the clause, with the
 *     exception of ; that is discarded. This has the advantage of
 *     requiring only two characters in simple cases, like e.g.:
 *     "...%s...", but limits the syntax of clauses. A solution to overcome
 *     this is to quote the other characters, e.g.: "...%ip`...", which
 *     serves only when a qualifier has a character argument.
 *  5. as the previous one, but the terminators are fixed: % ; sp , (the
 *     quote is allowed anyway). Since clauses are most of the times followed
 *     by other clauses or by such punctuation, it seems that a dedicated
 *     %. terminator for the cases in which there is a need to follow a
 *     clause with one of those characters is appropriate.
 *     However, a closing single character (e.g. ;) that is considered
 *     part of the clause is, however clearer. It requires to double it when
 *     it has to be printed. It is a bit of a problem for the io-clauses
 *     because they are usually followed by any sort of character. Most of
 *     the times they should be followed by the terminator.
 *     Since there are clauses (see: date) which can accept a parens-clause
 *     after the code (and qualifiers), clauses are allowed to terminate
 *     also at the %) (be it preceded by ` or not).
 *
 * Printf-style clauses, i.e. <width><qual><code> do not allow to have
 * qualifiers that depend on the clause, which is instead allowed if
 * the code comes first.
 *
 * In format-text it is not possible to introduce \n and \f. The ` character
 * can escape the meaning of the following one instead of the %% that works
 * for the % only. However, it is not that bad that it is impossible to
 * put \n and \f in it.
 *
 * Left justification is expressed with a negative width in order to
 * allow to control it with a negative value passed in the io list.
 *
 *
 * Io list
 *
 *   * to store io list elements, an array is used, which is reallocated
 *     if not large enough. Elements can be cast to long, double, and objects.
 *   * since it is possible to know the type of the elements in the io list,
 *     that information need not be present in the format.
 *   * the interpretation of the elements in the io list is driven by the
 *     format. However, since the type of the elements is known, it is
 *     possible to have generic clauses. E.g. there is no need in an
 *     integer clause to tell the exact type of the element. Moreover, the %s
 *     clause (it means conversion to string of any data) selects the
 *     appropriate conversion.
 *     Generally, the clauses require elements to be of a specific type(s).
 *     E.g. a float clause could take any numeric value.
 *   * the slice limits are kept in the integral and length fields of io list
 *     elements: start index in integral and slice length in length.
 *     In the v() methods, slices are denoted by the start and end+1 indexes.
 *   * there are "v" methods for all the data types which are taken
 *     by the predefined clauses (e.g. String, StringBuffer, etc.).
 *     This allows to determine their type without testing it.
 *     Moreover, it allows to determine the length for the ones which have
 *     a length without making a test, which would be necessary where a single
 *     method provided.
 *     In addition, it allows to get a string from within callbacks without
 *     making a cast in the caller (which needs also to catch the cast
 *     exception).
 *     Note that this allows to have v((String)null) be treated as a null
 *     String, which would be impossible if there were only one v(Object).
 *   * there are "v" methods for wrapper classes that extract the value
 *     and store it as a basic one. This allows to treat, e.g. an Integer
 *     as if it were an int.
 *   * object slices are useful for user-defined objects that gets
 *     converted to strings. Checking is done at the time of conversion
 *     in callbacks.
 *
 *
 * Format
 *
 *   * the format argument is a String because the most common case is a
 *     literal format.
 *     A char[] is allocated to hold the format, and reallocated when the one
 *     present because of a previous call is not sufficient.
 *     The format argument is copied in it. This is because the access to
 *     a char[] is much faster since it does not invoke a method call as
 *     the String does.
 *     Since to access 3 characters in a String takes the same time as
 *     copying the String into an char[], it is preferable to keep the
 *     format in a char[]. This allows also to provide a version that accepts
 *     a char[] or a StringBuffer as format.
 *     It is convenient to put a NUL at the end of the format array because
 *     parsing is simpler since it is always possible match the next character
 *     against a given one without testing if the character exists. In the few
 *     contexts in which a NUL need be matched the test is more complex (a test
 *     is made to determine if the NUL is the end of the format or not), but
 *     this pays off.
 *     If there were a need to accept a char[] as format argument, then
 *     that argument would need be copied into the format array, much the
 *     same as when the argument is a string.
 *
 *
 * Format and io list
 *
 * A clause with a repetition factor, like e.g.: %3i* gets only once
 * the field width from the io list and then formats 3 elements.
 * It is possible to obtain the same by scanning the clause 3 times:
 * call_cbk clears an index endQuals, which makes the first call to getQuals
 * parse the qualifiers and set it to the end of them, and skip them the
 * subsequent times.
 * This allows str_cbk and ptr_cbk to call the user-defined callbacks
 * several times without reparsing again and again the qualifiers.
 * Thus, the width occurs only once and before all the values.
 * Note that this allows to keep the parsing of the qualifiers and
 * the formatting of a value in a same user-defined callback and
 * allows also that callback to have its own specific qualifiers.
 * I.e. write() has no knowkedge on them, and it is independent on them.
 *
 *
 * Order and number of elements in the io list
 *
 * Let's consider this example:
 *
 *        %*i*    2,10,5    rep: 2, width: 10, value: 5
 *
 * The position in the io list of the repetition factor is correct: it
 * only be before the values.
 * The position of the variable width can only be before:
 *
 *        %3i*    5,1,2,3   width: 5, values: 1,2,3
 *
 * It can not occur between the values. However, it would be more revealing
 * to have it after. E.g. with a single value %i* 5,10 value: 5, width: 10.
 * It is then not correct to tell that a repeated clause is equivalent to
 * as many clauses as the repetition factor.
 * To make it equivalent there is a need to have the widths occur several
 * times. This would be the case under the concept that a width is
 * tied to a value, i.e. that it serves to format that particular value.
 * With it, it would also be possible to place it after the value in the
 * io list.
 *
 * There are two alternatives:
 *
 *  1. each particular value which is formatted can need its own parameters.
 *     This is the most general one, but also the less comfortable. In this,
 *     arrays with elements that need their width need contain it. This is
 *     possible only with arrays of integers; in general there is a need to
 *     have arrays of objects containing values and widths.
 *  2. the format defines the shape of the text record, in which some
 *     widths can be dynamic. This is more concise, but it requires to refrain
 *     from using the repetitions when each value needs its own width.
 *
 * For arrays, there are the following requirements:
 *
 *   * to be able to print an array by controlling the number of elements
 *     printed in a line. To do it, a variable repetition factor is needed
 *     inside the parens clause of the array, and its value must be taken
 *     from some place other than the array.
 *   * to be able to have write() calls for arrays which can be used
 *     irrespectively on the number of the elements of the actual arrays
 *     being formatted, e.g. not to have to change a write() call to tune
 *     it to an array because of the need to insert parameters.
 *
 * There are the following problems with arrays and formatting parameters.
 * In %[]( ... %i* ... %) when an array is processed the io list is
 * redirected to it, which means that such array must contain the
 * widths. This is a problem because widths are formatting parameters
 * and not data, and thus they ought not be there.
 * Moreover, although it is possible for arrays of integers to
 * have widths among elements, that is not possible in general,
 * and additionally it is not possible to format with a variable
 * width an array which does not have the widths in it.
 *
 * A solution could be to have it in the unnested, top level io list,
 * but there is anyway a need to eat only one io list element, not
 * many. This could mean that variable repetitions and widths are
 * always taken from the io list, which is rescanned after the
 * array at each iteration, so as to match variable repetitions and
 * widths occurrences in the parens-clause with io list elements.
 * There is, however, a need to define what happens when the parens-clause
 * is incompletely scanned.
 * An alternative is to state that after the array has been processed, the
 * scanning of the io list restarts from the first element not yet scanned,
 * but that does not allow to write a format that is independent from the
 * number of the elements of an array.
 * The parens clause can be incompletely scanned either because of
 * exhaustion of the array or zero repetition factors.
 * This has to do with the parsing of the format, which is skipped when
 * there are such things, and errors in it not detected.
 * Note that these io list elements would have to be written after
 * the array, and not before as it is usually the case for the
 * other variables. This problem occurs in general with parens-clauses:
 * the specification of * (e.g. a variable width) inside a parens-clause
 * implies the repetition of values in the io list.
 * E.g. %3(... %i* ...) requires to repeat 3 times the width in the io list.
 *
 * To overcome this problem of synchnonisation with the io list to cater
 * for incomplete processing of a parens clause, the parameters can be put
 * in an array for a parens clause: the array boxes them and thus it allows
 * to skip the whole set or parameters.
 * Since the clauses in an array parens clause take the elements from the
 * array and not from the io list, it could look uniform to access the
 * parameters from an array of parameters. This would mean to have in the
 * format a %[](...%) and in the io list a v(array).v(parameters) in which
 * the v(parameters) must always be present. This is a bit a problem.
 * They must be present because the parens clause could be executed at a
 * point in which a variable width is needed. The only case in which it
 * could be absent is when there is nowhere in the parens clause a variable
 * parameter. But that is difficult to tell.
 * A means can be to indicate the parameters array with a * in the format:
 * %[]*(...%). If it is present, then there is a parameters array, if not,
 * there isn't. But then why not indicate the number of the parameters:
 * %[]3*(...%) ? This would relieve from having a parameters array. And why
 * not indicate it in the io list by means of a method? E.g. v(p1,...,pn).
 * For a non-array parens clause there is a similar problem:
 * %*n( for a variable repetition factor, n-th io list element,
 * %n*m( for a list of parameters, m-th io list element.
 * In a parens clause, if there is a parameters list (i.e. a * in front of
 * it), positional parameters are counted relatively to it, otherwise
 * they are taken from the io list. This allows: %[](... %i*n...).
 * Note also that all this requires extra effort for the user to cater for
 * a case which occurs seldom.
 * Moreover, the elements present in an io list are not boxed for
 * parens clauses: if a parens clause requires less elements than the
 * clauses in it (notably, zero), no dummy elements are required, and
 * thus why it should be so for parameters? For a non-array parens
 * clause it is reasonable to require only the parameters which are
 * actually needed because the elements are in the io list, are written
 * explicitly, and thus there user knows when the parens clause is
 * scanned incompletely and that case can indicate less elements and less
 * parameters. In this case, boxing parameters into an array is more a
 * nuisance than a benefit.
 *
 * Another solution is to let the values run on arrays, but the formatting
 * parameters be taken positionally. E.g. %i*3. In so doing, it is difficult
 * to distinguish between positional values in the array and in the io list.
 * I.e. if %i*3 indicates that the width is the third element in the io list,
 * there is no way to indicate the third in the array. However, since it is
 * not useful for these kind of values to be taken from the array, they can
 * always be taken from the io list.
 *
 * It is also possible to have a parameters list, filled with a p() method.
 * The p() and v() methods could be called intermixedly.
 * The idea is to have a parameters list which matches the format.
 * To make an easy match, the format should be taken literally and any
 * unquoted * matched with a parameter (and *n matched with the n-th
 * parameter). This makes the matching independent on the processing
 * of the parens-clauses.  Alternatively, when a parens clause is
 * processed again, the parameters list is repositioned to the point it
 * was when the clause was entered the first time, and when the clause
 * is terminated, it is repositioned to the maximum position it reached
 * when it processed the clause. This is not entirely satisfactory when
 * a parens clause (and even any clause) is not processed at all or
 * not processed completely at least one time.
 * However, a parameter list, expecially when positional arguments are
 * used, confuses the user.
 *
 * Since all these alternatives are quite complex, the simpler one is
 * chosen to have repetitions and widths be taken from the io list or array
 * except when they are positional, in which case they are always taken
 * from the top level io list. This allows not to repeat them several
 * times.
 * This implies to write the argument number in front of them, which need
 * be changed when an argument is inserted before, but that does not seem
 * such a big problem.
 *
 *
 * Positional elements
 *
 * They are indicated by $. It comes from many shells in which the
 * parameters are indicated as $1, $2, etc. (and also from printf, in
 * which all arguments are either positional or non-positional).
 * Printf supports *nn$, or nn$ as width, which means that width is taken
 * as the value of the n-th argument.
 * The rationale for it is to support localization, e.g. to create a language
 * independent date-and-time printing method that is called with a dynamic
 * format, and an argument list which does not depend on the country. E.g.
 *
 *         printf(format,weekday,month,day,hour,min,2,2);
 *
 *   For American usage, with format:
 *
 *         "%1$s, %2$s %3$d, %4$*6$.*7$d:%5$*6$.*7$d"
 *
 *   it produces: "Sunday, July 3, 10:02"
 *   For German usage, with format:
 *
 *         "%1$s, %3$s %2$d, %4$*6$.*7$d:%5$*6$.*7$d"
 *
 *   it produces: Sonntag, 3 Juli, 10:02
 *   By tabbing over the format, the same result can be obtained:
 *
 *         American:    %s, %s %i, %ip02;:%ip02
 *         German:      %s, %t=%s%t<%mo-%i %t>, %ip02;:%ip02
 *
 * The real benefit of numbered (positional) arguments is that with them it
 * is possible to mention a single argument more than one time, or in other
 * words, that it is possible to tell in the format what vaules replace
 * placeholders in a way which does not depend on the processing of the
 * format. However, it depends on the ordering of arguments. It would be
 * much better if arguments were named.
 *
 * Syntax: %<rep-factor><code>. Since the code is not a digit, then there
 * is no problem in having %$9i:
 *
 *       %i*1         =  width $1, value current
 *       %i1$1        =  width 1, value $1
 *       %f*1.        =  integral $1, value current
 *       %f*1.1       =  integral $1, decimal 1, value current
 *       %f*1.$1      =  integral $1, value $1
 *       %f*1.1$1     =  integral $1, decimal 1, value $1
 *       %f*1.*1$1    =  integral $1, decimal $1, value $1
 *       %f*.*$1      =  integral current, decimal current, value $1
 *       %f*1.*2d*3$4 =  integral $1, decimal $2, width $3, value $4
 * 
 * Syntactically there is no problem if there is a character to denote the
 * argument. Since now there are no problems when the integral, width, etc.,
 * are numeric, there is no problem when they are preceded by an * providing
 * that the newly introduced qualifier "position" for the value is denoted
 * by a character so as to distinguish it from other numeric qualifiers.
 * The problem is that when a clause is simple, it is also easy to spot
 * the meaning of the numeric qualifiers in it, e.g.: %3i9 matches 3
 * fields of wide 9, while when there are other numeric qualifiers, it
 * is less evident what they mean. It would have been better to state
 * %f3i2d9 than %f3.2d9. Well, that is not too bad.
 *
 * Clauses like e.g. %a take several values from the io list. $n indicates
 * the first one and the others are after it.
 * Thus, at least during a callback, the values are extracted sequentially.
 * However, they do not eat elements.
 * %2i$1 means twice the element nr. 1. It would be rather complex
 * to take arguments sequentially after it (and not eating them).
 * It is easy to make the arguments run, but it is quite more complex
 * not to eat them.
 * A callback which reads several values should step to the next one
 * calling nextArg() before calling getval(). If told to repeat
 * this several times, it must reposition to the first element before each
 * iteration. This makes thigs complex. It it better to state that the access
 * to several values something very special, which should not be done by user
 * callbacks.
 *
 * When positional arguments are intoduced in the syntax, there is a need
 * to put some constraint in the placement of the param's which can occur
 * in qualifiers. Since the processing is sequential, then *.* takes the
 * integral and the decimal in this order, and *d*. in the opposite one.
 * Even worse, %i$1* takes * as $2, while %i*$1 takes * as the current
 * element. This is not good even without positional arguments.
 * To overcome it, getQuals proceses the numeric qualifiers in the order
 * they are defined: when a numeric qualifier is matched, all the
 * preceding numeric qualifiers may no longer be matched. Keep a bit set
 * of the numeric qualifiers not matched to clear the preceding ones.
 *
 * There is no check that the format is completed and the io list not,
 * i.e. that there are elemets in the io list which do not match a clause
 * because with positional arguments it is also be possible to take only
 * some of them.
 *
 * Note that, as a general rule, the values which are formatted are
 * arguments, and the ones which control the formatting are parameters.
 * The difference is that the former are indicated by $ and are taken
 * from the top-level io list or from an array, while the latter are
 * denoted by * and are always taken from the top-level io list.
 * Editing clauses have usually parameters. 
 *
 *
 * Unlimited repetition factor
 *
 * It serves to reuse a format for many io lists when the lists have
 * different lenghts, or not to bother about giving in the format the
 * number of elements in the io list.
 * It can be allowed only if there is a guarantee that no endless loop is
 * entered. E.g. that in the processing of the clause at least an element
 * is consumed in the io list, or that the repetition is bound.
 * It can not be represented as %( because it would not be possible to
 * apply it to the other clauses.
 *
 *
 * Autorepeat
 *
 * the rescanning of the format when there are unused elements is useful
 * expecially when formatting data for tracing.
 * There is a need to determine when a scan of the format has exhaused
 * the io list, and how: a format can address the io list elements by using
 * positional arguments, which means no advancing elements in the io list.
 * However they have been used. This is not an error and no reason to
 * autorepeat the format.
 * When the format is finished, the io list is back in its top level scan,
 * i.e. no array is open.  If a format has touched all values in the io
 * list (top ones), then they match. Otherwise they do not.
 * If it has touched less, but it has touched some with a non-positional
 * notation, then it can be rescanned.
 * The check and the autorepeat can be disabled to cater for some unusual
 * situation.
 *
 *
 * Call-lived data
 *
 * A Cdata is allocated as needed and kept there for subsequent calls.
 * It is cheaper to use some more memory than to spend time in allocation
 * and memory management.
 *
 * The data whose lifetime is the single callback call are kept in a
 * Cdata object which is allocated only once in write(), and that is
 * newly allocated each time it is called nestedly. In some cases there
 * are also nested callbacks, for which call_cbk saves and restores
 * the needed data (such as repfact).
 *
 * The user would like to use write() in callbacks, which means that
 * write() has to detect that it is called nestedly (which can be done by
 * setting a flag in the object) and thus save some of the values.
 * It saves only the values which are alive inside a call.
 * There are other values, like e.g. the tab stops or the callbacks
 * table, or the mode which could be saved or not. Since it is perhaps
 * rare the case in which that is useful, or perhaps there are cases
 * in which it is desirable to make such changes in callbacks, it is
 * better not to save them.
 * To support nesting of write() calls:
 *
 *   * callbacks are called by call_cbk. User defined callbacks can call
 *     write().
 *   * callbacks access the data concerning format and io list of the current
 *     write() call.
 *   * inside a callback, f() and v() can be called repeatedly so as to set
 *     the format and io list. Note that it is useful to let the user to set
 *     the format once with f() and to call write() repeatedly on different
 *     io lists.
 *   * all call-dependent data are stored on Cdata, and that is done by f(),
 *     v() and write() when called nestedly. It could be done by call_cbk,
 *     but since it can not know if the callback needs really them, it should
 *     do it always. To detect that the call is nested, call_cbk increases
 *     nestcall; the current Cdata contains also nestcall, and when the two are
 *     different, there is a need to allocate a new one to store its data.
 *   * exc, res, msg, excObj are not call-dependent data:
 *
 *     - when an error occurs before calling a user callback, it is not
 *       called, and when it occurs after, there is no problem.
 *     - when the error occurs in the callback, the nested write() is
 *       terminated and:
 *
 *       . if the mode is abort, the program is aborted,
 *       . if the mode is errThrow, an exception is thrown, and
 *         if the callback catches it, it can continue, and decide if
 *         recover the error (in which case it must clear exc, res, etc.)
 *         or let the calling write() terminate. If it does not catch
 *         the exception, it will be catched by the calling write().
 *       . otherwise, it is as if the callback catched the exception.
 *
 *     This means that these values are not call-dependent. N.B. If they were
 *     put in Cdata, then mode_resume might not work properly.
 *
 *   Note that each nesting level has its own temporary objects for storing
 *   the format, io list, etc.
 *
 *
 * Handling of errors
 *
 * Errors are represented by the Error FormatterError so as to avoid
 * declaring it in all methods. Moreover, this.res represents the error
 * status so as to allow to test whether an error occurred.
 * The problem is in the f and v methods, which are called before write().
 * If they fail, the subsequent write() must not be executed, and also
 * the subsequent v's must be empty. This is difficult if they return
 * with an error status (not an exception) because in calls like e.g.
 * f("a").v(1).v(2)... there is a need to check some error status so as
 * to terminate the whole statement.
 * Note that if a preceding write() reported an error, that should not
 * prevent to execute any following ones, including its f and v's.
 * This means that f and v may not skip their body when an error status is
 * present at the time of the call. N.B. f and v can cause an OutOfMemory,
 * and thus if one fails, a subsequent one might fail or not because another
 * thread might in the meantime have freed some memory.
 * The problem is that a write() at the end of the sequence would clear
 * upon entry and then report success at exit.
 * The sequences of calls are: [f() {v()}*] write().
 * The technique to make a v() and write() call inside an expression
 * (e.g. f().v().write()) skip the following one when there is an error
 * it to make it return a predefined, known object, and the following
 * one test if the current object is is so as to skip.
 * This allows to clear always the status upon entry in f(), v() and write()
 * so as not to need an error-clear method.
 * When an error occurs, the object is left consistent. E.g. if a v()
 * fails, the nubmer of io list elements is cleared.
 * A sequence (possibly made by just only one call), is guaranteed
 * to always return in one of the defined way to the caller class.
 *
 * The problem with exceptions is that when they are catched because they
 * do not represent an error condition, but only a termination condition,
 * there is a need to avoid to allocate and discard an exception object
 * each time. An exception object is allocated and a reference kept
 * in the object so as to avoid this. N.B. it the preallocation fails it
 * can only be because of lack of memory, but then something should be done
 * even if this is a problem that occurs with all the throw new().
 * In the FormatterError the status is duplicated so as to let callers to
 * test it without carrying the object.
 *
 * To reuse an exception object, its stack trace in it is not changed
 * when an exception is thrown from within methods called by write()
 * so as not to slow down execution because that exception might not be
 * a real one. It is updated only when the exception is really thrown
 * by signalError.
 * Moreover, when an exception object is created, either it is discarded
 * because it does not represent an error, or it is eventually used as
 * such. I.e. the exception is never changed into a different one.
 *
 * Write() catches memory exhaustion errors because they can occur
 * in a lot of places, including all method calls. All other exceptions
 * are catched locally by the methods when they use something which 
 * can throw and exception. This releaves from inserting in write()
 * a number of catch statements for exceptions which are not evident
 * at that point.
 *
 * When the output is on a file, and the method terminates in error,
 * (which is not an io error), the record is flushed in order to make
 * easier to spot the error.
 *
 * FormatterError objects contain all the data that are to be printed
 * (e.g. a copy of the format) instead of a reference to the formatter
 * object because when the format calls itself recursively (which can
 * occur in subclasses, like e.g. Listing), the data in the formatter
 * object could have changed, and no longer be the same as they were
 * when the error was detected.
 *
 *
 * Construction and initialization
 *
 * It is possible to have dedicated constructors to set a formatting object
 * to work on a string or file. A constructor can take, or allocate, the
 * record, etc., more or less as init_cbk. A constructor could also solve
 * the problem of the tracing, which now can be specified before the init
 * by means of a special test. There is anyway a need for a constructor.
 * A clause is more flexible because it allows to reuse a same object.
 * It is useful for testing, otherwise a number of objects must be created.
 * The %a restarts a formatting object, it initializes all the fields which
 * could have been modified by a previous write(), including all temporary
 * arrays, such as the tab.
 * Since %a sets the error handling mode to throw exceptions, if an error
 * occurs in it, it throws an exception regardless on a previous %mj.
 * To change it, j[+|-] is allowed in %a.
 *
 * To detect if a object has been terminated, a test is done on the field
 * <code>closed</code>, which is set to true upon termination. By default
 * it is false, which allows the use of format objects that have not been
 * explicitly initialized, but disallows to use of the ones that have been
 * terminated.
 * A test is made in call_cbk to detect that a clause is being executed
 * on a terminated object.
 * A test is also made on the call to the exit callback to skip it when a
 * %z has been processed.
 *
 *
 * The text record
 *
 * The text record is represented as an array of characters because it
 * is much more efficient than a String or a StringBuffer even if the
 * latter provides methods for inserting and deleting slices. Moreover,
 * a char[] is the only modifyable string holder which can be output.
 *
 *
 * Dynamic memory
 *
 * Dynamic memory is allocated only when needed: tabs and callback table
 * at the first definition.
 *
 *
 * Callbacks
 *
 * Inner classes to implement the callback table are too complex and
 * inefficient, and produce the generation of a lot of .class files.
 * The callback table is thus implemented by a switch. Subclasses can
 * redefine the callbacks, add some and provide their own dispatcher.
 * To avoid subclasses provide a dispatcher, all the redefinable callbacks
 * are predefined as empty (or better, as returning an error).
 * These are the pros and cons:
 *
 *   Empty, all predefined cbks:
 *
 *   -  no need for user dispatcher
 *   -  known names x_cbk for all, also int_cbk, etc., unless we
 *      want to block the redefinition of the standard ones, which is
 *      no good.
 *   -  need for a long list of methods and a long switch
 *
 *   No empty cbk:
 *
 *   -  dispatcher needed
 *   -   more flexible: the dispatcher can be programmed to call
 *      a different callback by testing some field
 *   -  more complex
 *
 *   Mid-way solution:
 *
 *   -  predefined empty callbacks for the undefined lowercase letter codes
 *   -  redefinable dispatcher
 *
 * There is a need to detect if out_cbk has been redefined. This can
 * be done by calling out_cbk anyway and issuing an error from the
 * predefined one. There is also a need to detect if page_cbk and some
 * few others have been redefined. This is useful to avoid to allocate
 * memory and some savings which are needed only if these callbacks are
 * really present, which is the case when the empty default ones have
 * been redefined. Since it is not possible to detect it, the necessary
 * preparation for the worst case is always needed.
 *
 * Another solution is to let user classes that define data that need be
 * formatted provide their own callback, to which the qualifiers are
 * passed. This is more flexible than to have them define the toString()
 * method, which has no parameters, allocates a new string and is unable
 * to write directly into a text record (because it does not receive it
 * as argument). Currently, callbacks have access to all the fields and
 * the internal methods. Perhaps it is possible to find a callback API
 * which allows them to do the necessary things.
 * This does not eliminate the need to redefine some basic callbacks,
 * which, howerver, are few, well known and easily redefinable in subclasses.
 * Moreover, the user may need to define some special callback that performs
 * some action not related to the io list.
 * To format objects of user classes implementing the Api, there is a
 * need to parse the qualifiers and to get the value. Their format() is
 * called from within str_cbk. There is a need to specify qualifiers
 * and to get them.
 * To solve the problem, a flag is put in Cdata to make a frmGetQuals
 * skip after the first time it is called by str_cbk; the reading of the
 * clause code can be done by repositioning pfor. This allows to parse
 * only once the qualifiers including the ones which read a value from
 * the io list. Moreover, str_cbk would force repfact to 1 before calling
 * the callbacks, and thus user callbaks need not loop over repfact.
 * The flag should be cleared by call_cbk and set by frmGetQuals.
 * However, in a %<n>s<qual> the <qual> are the right ones for the <n>
 * values, which means that they ought to have the same type. If a value
 * treated by a different callback is present, that would be formatted
 * with the <quals>. This can produce a meaningful result only if the
 * qualifiers are meaningful to it (e.g. they are the common ones).
 *
 * The init callback is included in the switch only for completeness.
 * It needs to be called at the beginning, even before entering the
 * loop because it sets the locations that are needed in it.
 *
 * Parens-clauses are handled by calling recursively the method that
 * interprets the format
 *
 * After a callback has returned, the pointer to the format is advanced
 * after the code if it has not been advanced by the callback.
 * Callbacks that require a clause longer than a simple one-character code
 * must advance the pointer so as to leave it past the clause. The only
 * waiver is the terminating semicolon, which can, but need not be passed.
 * This allows to detect spurious characters that are present after clauses.
 *
 *
 * Miscellaneous format clauses
 *
 *  * \n in format-text is treated as %/ because otherwise it could confuse
 *    the user since the cursor would no longer represent the carriage.
 *    It is treated as an ordinary character when contained in a io llist
 *    argument.
 *  * There are a number of issues regarding real numbers:
 *   
 *    - the clauses for integrals and decimals and exponent appear before
 *      the general qualifiers and the width to make the clause depict
 *      the number by specifying the form of the components in their order.
 *      When there is a need to separate a decimal from the width, a `d'
 *      has to be used.
 *    - there is no need to control the exponent because a scientific
 *      notation need not be aligned on the decimal point, and thus a 2 or
 *      3 digit exponent is acceptable.
 *    - the decimals ought to be lower than the supported precision, which
 *      depends on the size of the number (or better, the whole number of
 *      significant digits depend on the size).
 *      The proper representation of precision could be obtained by starting
 *      from a E representation with a precision larger than that of the
 *      float kind (i.e. DBL_DIG or LDBL_DIG), plus 2-3 digits.
 *      This delivers all the digits of the number followed by zeroes, with
 *      no spurious digits as the %f instead does. One digit is given before
 *      the decimal point. However, spurious digits are inserted only after
 *      the maximum precision supported. It can be stated that if a precision
 *      greater than the supported one is requested, the digits after the
 *      supported one may not be trusted. This is the same as printf, and
 *      relieves from formatting the number twice. It could be nice in free
 *      format to remove the leading zeroes from precision. This, however,
 *      seems of little use in practice.
 *
 *  * Java Unicode excapes: there is a difference between having the
 *    sequence generated for all non-ASCII characters (> 127), which is a
 *    global behaviour, and the sequence generated by frm_ins for all non-ASCII
 *    printable characters. The latter requires a qualifier: u for s and c codes.
 *    It is not provided for i and f because the padding with 0's and the
 *    grouping separators would need be calculated taken the \u0000 expansion
 *    of the sign. In general, it is of little use to expand \u0000 when
 *    formatting data other than strings because thereafter there are no tools
 *    which can use such data, while for strings at least the Java compiler
 *    can read them.
 *    The former needs something more radical: ins_rec and all other places
 *    in which a character is inserted. This would be useful only for generating
 *    java programs, but to do it identifiers, strings and comments (the only
 *    places in which a \u0000 sequence can occur) are formatted as strings.
 *    Note also that a general treatment would require to have records big
 *    enough to hold the longest expanded text record.
 *  * Alignment `a' is meaningful only for numeric formatting, and thus
 *    frm_ins does not attempt to expand the characters in the prefix.
 *    In order to allow to generate the desired number of digits and perform
 *    alignment, all int_cbk and float_cbk support the `f' code and the integral
 *    value. It is then possible to produce, say, 10 digits aligned in a field
 *    of 12 having thus aligned positive and negative values and having the
 *    same number of digits for all.
 *  * When there is a need to send the output on a file which is kept in
 *    memory, it could be useful to assign a pointer to the memory in %a.
 *    A file open callback could be useful for that and also to customise
 *    file opening, but it would be called in init_cbk where the user callback
 *    table is not yet available.
 *  * "aaa\nbbb" produces the same output (at least in text files) as the
 *    format-text. To have the same (or something similar) with "aaa\fbbb",
 *    \f is defined to be equivalent to %/%/e, which means that it inserts
 *    (for text files) a \n, and a \f if followed by a record.
 *  * Tab expansion of strings could be supported. However, that is not
 *    simple because the external representation of a string with expanded
 *    tabs depends on the position in which is inserted in the record (and on
 *    the tab setting). There is a need to calculate it in det_length and
 *    frm_ins. However, in wrap mode when the string is wrapped it becomes
 *    close to impossible because the string would have to be expanded again
 *    in the new record.
 *  * flush: by default after an io operation no flush is done, and thus
 *    if there is a need for it, which is the case when the device is line
 *    oriented, then a flush() must be enabled.
 *    The best would be to have the buffer flushed when an io operation is
 *    done on a line-oriented device. To detect this, probably it is possible
 *    to make a test on the file path. In most of the cases it is needed when
 *    the output is on a terminal used interactively, i.e. with read and
 *    write intermixed, and the user knows it.
 *    Flush is now the sames as that of the IoStream: if the stream is
 *    autoflushed, so is the Formatter.
 *  * current date: there is no dedicated clause to format the current date
 *    because it can simply be obtained with v(new Date()).
 *  * a clause could be introduced, say, %&, which takes a string from the
 *    io list and interprets it as part of the format. The difficulty is to
 *    save/restore the pointers and to let the error indication work properly.
 *    This seems to be too much complex for the benefits is provides because
 *    a similar effect can be achieved by creating dynamically the format
 *    by concatenating the pieces.
 *  * Trowables values could be converted into theis localised message.
 *    This is not done because it is possible to do it directly in the
 *    io list.
 *  * the %[]( clause does not support collections. It could step over the
 *    elements by calling their iterator. However, that would require to keep
 *    a stack of references to iterators in addition to the current one which
 *    keeps only array indexes.
 *
 *
 * Wrap mode
 *
 * In a %/%s, after the %/ the record is at the beginning of a new line, and
 * thus indent and head must be emitted. This must not occur the first time.
 * Thus, there is a need to keep a flag that tells it. This is a bit
 * different from the flag firstio which tells whether an io has been done
 * on a page, and iscol0 which tells where the carriange has been left
 * after the last i/o.
 *
 * Headings are printed after the indentation. Headings that are printed
 * before usually contain data such as line numbers, which are not constant,
 * and thus they are better be done with a callback. That callback is
 * different from the insertion one because it has to be called before.
 *
 * There are the following alternatives to break the record when there
 * is a need to insert in it some characters that need be put on the
 * same line as the preceding ones (like, e.g. the tail that closes the
 * lines, or the pendings):
 *
 *  1. to let the user mark explicit break points (e.g. %m|). Breaks can
 *     occur at them and at spaces, but not if they are in quoted strings
 *     (this can be implemented by replacing spaces in strings with nbsp's,
 *     but this would not cover quoted strings which are built without a
 *     %sc. Well, the ones which are built with a %se can be covered.
 *     But this can be undesirable when the lines are strings obtained by
 *     a head and tail of " and %se clauses.
 *     Explicit breaks need an array similar to the tab one.
 *  2. same as above, but to delimit zones in which breaks must not
 *     occur (like, e.g. in quoted strings), there are break enable/disable
 *     clauses.
 *  3. to scan the record to find the blanks outside strings. It seems
 *     possible to scan it backwards: when a " is encountered, and it is
 *     not preceded by an odd number of backslashes, it is the end of a
 *     quoted string, which is closed by a " preceded by 0 or an even number
 *     of backslashes. This would solve the problem of disabling breaks in
 *     quoted strings.
 *
 *  Moreover:
 *
 *  1. %mb<str> can specify the characters at which a break can occur
 *     (i.e. not only spaces).
 *  2. to have non-breaking spaces, \240 or \xa0 characters can be used
 *     (nbsp): a break may not occur at them. It is the same code used
 *     in html. A counter can be kept that tells the number of nbsp's in
 *     the record: it indicates if there is a need to scan the record
 *     to replace them and how long to do it. The nbsp's can be present in
 *     strings, which means that there is a need to scan them to discover
 *     it even when the insert is simple. This can conflict with html
 *     generation, in which there could be a need to produce such codes.
 *  3. another possibility is to allow nbsp's only in format-text, being the
 *     ones present in strings always nbsp's. This can be implemented by
 *     marking the blanks in format-text as breaks in a breaks table, and
 *     to replace the \240 in them with blanks. This gives a penalty for
 *     the ordinary blanks (there is a need to allocate the break table),
 *     but it could make the search of breaks faster.
 *
 * Breaks are seldom used: in insert mode when characters are shifted out of
 * the record, and when there is no space for pendings. Thus, it is better
 * to spend time only when a break has to be applied.
 *
 * A simpler solution is to keep a pointer to the last string which has
 * been inserted, and that it could have been wrapped. I.e. each time
 * a conv-clause is done, the generated string can be wrapped to a new
 * line, and it should be if and when a pending has to be appended to it,
 * but there is no space for it. A pointer is kept to the beginning of
 * that string, which tells the wrap point.
 * The technique is to attempt the insertion of the string making the output
 * of the current line if insufficient, and the insertion in the next.
 * If this tells that it is impossible, then the string is truncated
 * and an ERR_NOSPACE occurs. The insertion of such a never-fitting string
 * is done on a new line to show the part which would never fit.
 * At a break the tail is inserted, and if there is no room for it,
 * a break is attempted, and if that is not possible, an ERR_NOSPACE occurs.
 * After having identified the break, the rest of the record (remainder)
 * is saved, the record flushed, the new line started and the remainder
 * inserted. At this point the insertion of the string is attempted again,
 * and if the remainder took so much space as not to allow the insertion,
 * a flush is done again.  Whether there is enough room depends on whether
 * we are at the beginning of a continuation line or not.
 * In wrap mode at the beginning of a continuation line indentation and
 * heading are inserted so as to occupy the space. Then:
 *
 *  1. a test is made to determine if the string can be put on the record.
 *     If it can be put, it is inserted: it can be the last one of a
 *     sequence of insertions, with no need for continuation lines.
 *  2. otherwise a continuation line must be used.
 *  3. in insert mode in the middle of the record, the current:max
 *     part is removed, and then the pendings (if any), the current
 *     piece and the remainder are inserted, each one with its own
 *     breaking characteristics.
 *     In insert mode at the end, and in overwrite mode the pendings
 *     (if any) and the current piece are inserted, each one with its own
 *     breaking characteristics.
 *
 * The pack_rec procedure takes a list of pieces and tries to place them
 * in the record to fill it as much as possible making the necessary attempts.
 * Each piece might have a break in it, can be put on a new record or may
 * not, is a break-disapper pending or not. E.g., representing breaks with
 * / and the cursor with:
 *
 *       pr/ec^ + insert + rema/inder
 *
 * The procedure is called with int m, char *s, int l  tuples to describe
 * the pieces.
 * The technique to put in the record each piece in sequence until one is
 * found that does not fit requires to keep track of the last break point
 * so as to break the record at it. It allows also to start with the current
 * contents and break point of the record and proceed incrementally.
 * The technique to look ahead to find the longest sequence of pieces that
 * can be put allows to avoid to put in the record something that needs to
 * be moved when a break occurs. On the other hand it might require to move
 * a part of what is present in the record at the beginning anyway, and
 * also it requires to scan all the pieces including what is present in the
 * record at the beginning. The first one is chosen.
 * A difficulty is that pendings which are before a piece that does not
 * fit need be trimmed before checking if they fit. If that were not done,
 * they might be put on a new record. On the other hand, if they do not fit,
 * the record is broken and the attempt made again (with trimmed pendings
 * first).
 * To handle this, a pre-loop is made in which for each piece its trimmed
 * lenght is computed. Then, when pieces are inserted, a dedicated test
 * is made when a piece does not fit to see if it is followed by anotker one
 * and if it fits if trimmed.
 * When a wrap is done, the break point is reset to the beginning of the
 * record and the mode is forced to break-before-piece to avoid wrappind
 * endlessly.
 * When a break is done which is before the cursor there is a need to save
 * a piece of the record.
 * When a piece is inserted:
 *
 *  1. if there is no space, the record must be flushed. Thus, it is
 *     trimmed of the trailing blanks, and if there is enough space for
 *     the tail, it is flushed.
 *  2. as above
 *  3. as above
 *  4. otherwise the record must be broken. If the break is at the
 *     beginning, then an ERR_NOSPACE occurs because if a break were
 *     made there, it will only defer the very same problem at the
 *     next line. Otherwise the break point (the point of last insert)
 *     is taken, the part of the record from it up to the end cut, and
 *     a flush attemped again. If it fails, an ERR_NOSPACE occurs.
 *     Otherwise, the part cut is pasted and the insetion attempted
 *     again.
 *
 * Note that there is no need to take into account that the current
 * insertion point is not the maximum because if the piece to be inserted
 * fits, then no wrap is done, and if it does not fit, then it overwrites
 * the previous contents of the record at least up to the maximum, which
 * then need not be taken into account.
 * Note that the insert mode can be really used only in non-wrap mode because
 * in wrap mode there is no guarantee that the record has not been flushed.
 *
 * The usefulness of a flush operation (i.e. a %/ done if the record is not
 * empty) is to be able to write a while statement in which the elements
 * of a possibly empty list are printed, and then a statement prints the
 * last line, if something is present in it. The general qualifier n for
 * io-clauses that does it.
 * In wrap mode it seems that it is less useful because the record is
 * flushed only when something is inserted in it. However, if a %/ is
 * done because there is a need to force a newline, and that is done
 * in a conditional statement, there is then a need to make a conditional
 * flush of the record.
 *
 * Memory to keep temporarily pieces of a record which is being wrapped
 * are kept in preallocated automatic memory unless their size is large,
 * in which case they are allocated.
 *
 * pack_rec does not handle the repeated insertion of main pieces with a
 * blank tail. To support the current semantics, there is never a need
 * to determine the trimmed length of the main piece, and thus there
 * is never a need to expand it before packing. The current semantics
 * does not insert a piece with a blank tail that overflows in the current
 * line by trimming it: it tries to place the piece and its tail
 * at a new line (and signals an error if that is not possible).
 * A more permissive semantics could be to try to place the
 * piece in such a case. Note that the difference with the current
 * semantics occurs only when there are pieces that have a blank tail,
 * which should be avoided when working in wrap mode.
 *
 *
 * Pendings
 *
 * In wrap mode at times there is a need to write a list in which some
 * items are more closely related than others. To show this, it is
 * possible to force a flush after them so as to make the printout clearer.
 * For this reason, a \n is allowed in the pendings.
 *
 * The case of lists is different from that of characters that need prefix
 * or suffix the record when output. The deferred ones could be eliminated
 * at line break, expecially the blanks.
 *
 * Without pendings, the sequence: start: "list: %i%"  iteration: ", %i"
 * end: "" in wrap mode could make commas appear at the beginning of a new
 * line. The sequence: %*(%i, %) leaves a comma at the end.
 * The pendings: %*(%i%@, %) defers the insertion at the first conv-clause,
 * and does not break lines before the pendings. The following additional
 * kinds of pendinds could be supported:
 *
 *      @!   permanent normal
 *      @=   permanent break-disappear
 *      @^   permanent normal suffixed*
 *
 * Permanent pendings are not cancelled after the first clause that makes
 * them be inserted: they are kept until explicitly cleared.
 * Suffixed pendings are the ones that are inserted after the string of
 * the first conv-clause or format-text.
 * Permanent suffixed pendings can be useful in loops in which they are set at
 * the beginning, and then a sequence of write() called. E.g.:
 *
 *      Start: "list: %@^, "  iteration: "%i"  end: "%@;"
 *
 * With normal pendings:
 *
 *      Start: "list: %i%@!, "  iteration: "%i"     end: "%@;"    (1)
 *      Start: "list:%@ "       iteration: "%i@, "  end: "%@;"    (2)
 *
 * (1) works when the list has at least one element, (2) works for all
 * lists, including the empty ones.
 * Pendings are useful when there are several optional items to print:
 *
 *      if ... write(p,"%i%@, ",x);
 *      if ... write(p,"%i%@, ",y);
 *      write(p,"%@;");
 *
 * It is burdensome to rekon at the point in which an item is emitted
 * that there is a previous one that has been printed.
 * The previous example may not be written with pendings that take effect
 * after the first conv-clause:
 *
 *      if ... write(p,"%@^, %i",x);
 *      if ... write(p,"%@^, %i",y);
 *      write(p,"%@;");
 *
 * The second %@ would replace the former, but not be printed before the item.
 * The correct way to use a permanent suffixed pending is to use the
 * sequence of the first list example.
 * Since it is possible to cover all the cases with normal pendings, the
 * other kinds are not provided.
 *
 * In a sequence of pendings: %@...%@..., the pendings after the first one
 * can:
 *
 *  1. append characters to the previous one. The break-disappear
 *     attribute are taken to be those of the first one.
 *  2. it replaces the previous one. A %@; clears it.
 *
 * The second alternative is chosen because the first one seems to be useful
 * only in cases that occur seldom. When there is a need to append, the
 * pending has to be fully specified.
 *
 * A char[] is allocted to keep the pendings the first time that it is
 * needed. Its size has a minimum so as to avoid a probable reallocatio.
 * However if it is not sufficient, a larger one is allocated.
 *
 * Pendings are implemented by non-break insertions. When a conv-clause
 * or a format-text is encountered and there are pending characters,
 * them and the string are taken to be inserted.
 * If there is not enough space, the pending characters, trimmed by the
 * trailing blanks are placed. If they do not fit, a break is attempted.
 * If a break exists, then the record is emitted at that position, trimmed
 * by any trailing blanks, otherwise it is emitted at the current
 * position.
 *
 * When a break-disappear pending does not fit, the record must be flushed
 * (if there is enough space for the tail, it is inserted and the record
 * flushed; if an attempt to place the piece were done, and there is no
 * space for the piece and the tail, a larger break would be done).
 * When a break-disappear pending fits, and the following piece also, there is
 * still a chance that the pending goes at the end of the line: it occurs
 * when a non-break piece is inserted and the one following the pending
 * occupies the whole record and there is a tail. This can be solved by
 * keeping a pointer and a length to the last start of a break-disappear,
 * which is then removed by endline when endline receives a record and
 * the slice from that pointer to the max is long as the recorded length.
 * To handle \n in pendings a flag is kept in the object to remember that
 * there is a \n to be done after the pending. The \n is not rekoned in the
 * length of the pending in order not to complicate the tests on the space.
 * A user insert should take into account that if there is not enough
 * space in the new record to insert the tail to flush the pendings, an
 * ERR_NOSPACE occurs.
 *
 * Pack_rec is called in io_cbk because a \n clause in wrap mode must insert
 * the tail. In such case, if the record is broken, the original carriage
 * positioning is used for the first part printed, and those of a %/ on
 * the second part so as to avoid to place the two pieces on two separate
 * pages in the case of a %/f clause.
 * Rec_emit emits the record using the current carriage positioning,
 * which is registered with set_carriage that takes into account
 * whether the file is a listing file, the pending formfeed, etc.
 * Io_cbk does optionally a pack_rec and always a rec_emit.
 * A %/f in wrap does a formfeed. This is so because io_cbk sets properly the
 * carriage, which is then used by the rec_emit done inside the startline
 * called by pack_rec.
 * In insert, set_carriage is called to set the carriage to %/ so as
 * to make the rec_emit called in startline to emit the record at a
 * new line.
 * insert calls pack_rec (which calls startline) and startline,
 * which calls rec_emit. Io_cbk calls pack_rec. There is never a recursive
 * call.
 *
 *
 * Redirection of format
 *
 * It is possible to support redirection of format: to redirect the format
 * to a given string in a callback, to call write(), which would thus format
 * arguments according to it (which needs to take the ap from the old one),
 * and then to restore it back. This is equivalent to expanding the clause
 * that called the callback with a given one. This can be provided also with a
 * clause. There is a need in it to store somewhere the pointers to the
 * suspended formats.
 * If there is a desire to make the write() in a callback use the
 * arguments of the main io list, a flag should be introduced in the
 * object to make write() not load a new ap, and skip va_start and va_end.
 * There is no evidence that this feature be really useful, and thus it
 * is not provided.
 *
 *
 * Parsing of qualifiers
 *
 * The parsing of qualifiers is done by a (somehow) general purpose
 * method, which returns the set of qualifiers present in a clause,
 * including the numberic ones. This allows also to indicate which
 * ones have been specified, instead of relying on defaults.
 * The method accepts qualifiers specified in any order as long as
 * there are no repetitions. This is appropriate because it is difficult
 * for the user to remember a particular ordering in qualifiers.
 * The method could accept qualifiers which are letters followed by - or +.
 * This, however, is used only in edit-clauses, in which there is little need
 * for a centralised method because one or two qualifiers only are used.
 * Moreover, %m allows repetition, with execution when qualifiers are
 * encountered. There might be a difference is qualifiers are parsed
 * and then the result executed. Should the need occur, it is possible
 * to extend the method in this direction.
 * Since the qualifiers have the same syntax for all clauses, it is
 * easy to have a unique method, otherwise there would be a need to
 * tell the syntax of the allowed qualifiers. The method accepts a
 * string which specifies the sets of allowed qualifiers terminated by
 * a semicolon. The first one must contain the non-alternative ones,
 * and the following the alternative ones.
 * The qualifiers that indicate padding (e.g. p<char>) occur twice in
 * the clauses of floating values. Since it is difficult to allow repetition
 * of a same qualifier, because it ought to be supported for some of them
 * and rejected for some others, two distinct qualifiers have been defined.
 * The cases are:
 *
 *       [+] [r] [b | o | d | x | X] [']
 *       [+] [' | ^] [f<c>] [integral] [. | !] [decimal] [e | E | g | G] [=]
 *       [+ | (] [' | ^] [f<c>] [integral] [. | !] [decimal] [i] [=]
 *       [b | t | T | y | Y | o | O]
 *       [o | x | b | B<c><c> ] [h] [c | e] [d]
 *       [m] [length] [. | !]
 *
 *       [p<c>] [z | Z] [a] [n] [-][min] [:] [max]
 *
 *       qual's:   + ' ^ . ! = ( : - a b c d e E f g G h i m n o O p r t Y x X y
 *                 Y z Z
 *
 *       sub-codes:  l L s m f
 *
 * There is a need not to overlap the character used to better specify
 * the code, e.g. the `l' in %il with the general qualifiers, otherwise
 * it would no longer be possible to write them in any order.
 * The corresponding sets are:
 *
 *       "+r'an","bodxX","zZ"
 *       "+an","'^","eEgG","zZ",
 *       "ian","+(","'^","zZ",
 *       "an","btTyYoO","zZ",
 *       "hdan","ox","ce","zZ",
 *       "hdman","ox","ce","zZ",
 *
 * The qualifiers p, f and B have a fixed special syntax, and parsed always
 * as such. The numeric qualifiers come in these forms:
 *
 *        n.m   n!m  n.!  [-]m:n
 *
 * For . and !, they must be present in order to match the pattern,
 * while for :, it can be absent together with the following number.
 * The latter is indicated with \t.
 * They are specified as "1.!2", "1." and "-:\t9" meaning that a number
 * indicates a sequence of digits, - a sequence possibly preceded by -,
 * and .!: alternative separators. Different digits are used to distinguish
 * the numbers.
 * Having a general qualifier parsing method, there is then a need to
 * fill the cdata properly with the meaning of qualifiers.
 * A \t as first character in an alternative set makes the matched
 * character be stored in the `kind' field of the cdata.
 *
 *
 * Paging
 *
 * To support paging, the number of the line in the current page kept.
 * When a line would be printed out of the page, a form feed is forced
 * on it. It works with text and listing files. An absolute line counter
 * which, when modulo page height = 0 causes a form feed does not avail
 * because when a form feed is explicitly forced it it looses synchronization.
 * A page heading callback is also provided which formats the heading as
 * the user needs. %mp takes the page height and initialize all the counters.
 * When the page height is 0, no paging is done.
 * In order to prevent a page heading callback to call itself endlessly,
 * paging is disabled before calling it, but not line counting because
 * there is a need to keep it updated so as to rekon the occupation on
 * the page done by the heading.
 *
 *
 * Internationalization
 *
 * Locales: for the default locale, it is set first to null, and each
 * time before using it a test is done to detect if it is equal to the
 * previous one. This allows to support changes to the default locale
 * made by the caller (or callbacks). A resizable array of min 3-4 locales
 * is kept to hold the locales.
 * To speed up the test, only the reference is tested. This means that
 * if the user has set the default locale to the same as the current one,
 * but it has done so by creating a new Locale, the test will fail and
 * the new one loaded. This is expected to happen much less than the
 * tests which are made.
 *
 * Localised text: to have locale dependent strings produced, it is
 * allowed to register resource bundled by giving them an identification
 * number.  An array of bundles is kept. The most common case of localised
 * output is that of applications which produce an output in a given
 * (default) locale, in which there can also be data (e.g. numbers, dates)
 * formatted according to another locale.
 * It is different from numbers and dates: here the text is all in the
 * same language. It can on the other hand be useful to have several
 * resource bundles open from which to take strings.
 * Localised text is obtained with qualifier `m' in the string clause.
 *
 * Localization of plurals: for plurals, conditional format is provided. E.g.:
 * "there %?is:are; %i file%?s". The first is taken when the next io list
 * element is true, and the second when it is false.
 *
 * Literals: "true", "false", "null" are printed mainly for debugging programs,
 * and thus need not be localised. This is also done in order not to make
 * formatter read a bundle only for that.
 *
 * Default locale: an application which sets the default locale as
 * the current one can work either in localized (i.e. make the formatting
 * follow the changes of the default locale) or in non-localized mode.
 * the latter is obtained by redefining the locale nr. 1, which
 * blocks it.
 *
 * Changes to the default locale: when the default locale changes, all
 * the data which depended on it (locNumData and resources) are invalidated.
 * This allows to avoid to refresh all resources at once, leaving that
 * to be done when they are used. Resources are not reset to null because
 * non-null pointers serve to reject redefinition.
 *
 * When a Formatter is told to create a file, the encoding is the default
 * one: it may not be controlled because that is a simplified way to
 * create files.
 *
 * In some languages, notably Arabic, the minus sign is writter after
 * the number (this might be due to the writing direction which is from
 * right to left, except that numbers are written from left to right).
 * the display direction as forward because a number has to be printed,
 * then the characters are in the proper order.
 * Bidi writing is not supported by Formatter.
 *
 * Resource bundles contain typically Strings. They could also contain
 * char[] objects, but that in practice never occurs because it would
 * make difficult the writing of strings since char[] does not have
 * literals.
 *
 *
 * Arrays
 *
 *   * it is possible to tell the io list elements that are arrays (by
 *     examining the classname). Thus, there is no need to indicate in the
 *     format that the current element in the io list is an array.
 *   * it is possible to test that the io list is exhausted. There is no need
 *     to access the next element to know that the current one is the last,
 *     and thus that it is not possible to move to the next.
 *   * of course, any enumeratable objects can be passed and virtually replace
 *     itself with its elements in the io list.
 *   * however, a char[] can be formatted as a string. This means that an
 *     array is expanded, unless a clause is found which eats it.
 *   * it can be useful to provide expansion for objects as well (at least
 *     for debugging). %(...%) could provide repetition as long as the object
 *     is exhausted. An object in the io list which does not provide a
 *     toString method (different from the Object's one) would effectively
 *     be replaced by its fields (public, protected or private depending on
 *     the caller).
 *   * a clause can denote the current index, e.g. %j with the integer-clause
 *     qualifiers.
 *
 * Requirements for arrays:
 *
 *   * format each element differently. E.g. take a [3,2] matrix in which 
 *     the first element of each row denotes a length and the second
 *     a height, and there is a need to show it in the printout.
 *   * print the elements in such a way that they can be recognised
 *     as such. E.g. in the Java array initializers each (sub-)array is
 *     indicated by enclosing its elements in curly brackets, which allow
 *     to tell what values belong to a sub-array.
 *   * It must be possible to print an array by placing a given
 *     number of elements in each line (which might produce a last incomplete
 *     line), and then print something after it. This means to have a parens
 *     clause repeated as long as the array is not exhausted.
 *   * print a slice of an array. There is no evidence whether for a
 *     multidimensional array it is useful to slice the inner dimensions.
 *     It is not clear if this is needed in the cases in which the inner
 *     dimensions have different lengths (in an array whose elements are
 *     arrays, the elements can have different lengths among each other).
 *   * let the user decide to format a char[] as a string or as an array.
 *
 * There are two alternatives:
 *
 *  1. use the notation %[...](:
 *
 *     - %[](:  intrinsic dimensions
 *     - %[n1,n2...](: the ones specified, which act as defaults
 *       for inner %(
 *     - for %(:
 *
 *       . if the current element in the io list is an array, the repeat
 *         factor is the array length
 *       . otherwise the repeat factor is 1
 *
 *     - in %[10,2](...%3(...%( the last %( takes the repetition 2,
 *       There is a need to restore the superseded dimensions.
 *       E.g. in %[2,3,4](...%[5](...%)...%[]%(...%)...%) the last [] should
 *       denote [3], and in: %[2,3,4](...%[5](...%[]( the last denotes 4.
 *       To do this there is a need to save in the current scan_format the
 *       old values and to restore them. Note that there should be only one
 *       active stack on which only a part is overwritten.
 *       To distinguish the default repetition from that based on the
 *       intrinsic number of elements, %( can denote the default, and
 *       %[]( the intrinsic one.
 *     - %[s1:e1,s2:e2...] denotes array slices
 *     - %[*]( takes from the io list a repetition first and then an
 *       array.  This can make the indication in the io list of a slice
 *       strange because it forces to specify dimensions and the array
 *       in the reverse ordering.
 *
 *     The indication of the bounds in %[...]( allows to avoid to repeat
 *     the bounds inside the parens-clause. E.g. in:
 *
 *          %[n]( row: %[m]( element: %c%) %)
 *
 *     the inner bounds are evaluated over and over again.
 *     The idea of indicating the inner dimensions in the parens-clase is
 *     not good in general because it requires to repeat them when the elements
 *     are formatted individually. E.g:
 *
 *          %[2]( first: %[3](...%) second: %[3](...%) %).
 *
 *     Note that normally matrixes have rows with the same lengths.
 *
 *     While in C a multidimensional array is a sequence of elements,
 *     and thus there is only a need to control how may times the inner
 *     parens-clauses have to be repeated to mimic the inner dimensions,
 *     in Java multidimensional arrays are arrays of pointers, and thus
 *     they may not be scanned sequentially as the C ones.
 *     There is always the need to open an inner array.
 *     This means that an inner %( does not mean only a default repetition,
 *     but also a sub-array opening, much the same as %[](.
 *  2. use the notation %[]( or %[...%]:
 *
 *     - %[] or %[... %] takes an array from the io list, and repeats the
 *       clauses in it as long as there are elements.
 *     - in the parens-clause %[]( opens an inner array.
 *     - arrays accept also String and StringBuffer arguments and expand them
 *     - an %[]( for an empty array is not entered
 *     - any null argument is accepted as empty array
 *
 *     The %[... %] notation is simpler, but it requires to specify slices
 *     in the io list.
 *     If we had a language construct to specify slices, we would not
 *     put them in the format. E.g.:
 *
 *          %3s     str(1:4)
 *
 *     Since we have not it, we can put the limits in the io list:
 *
 *          %3s     v(str,1,4)
 *
 *     For arrays we could do the same:
 *
 *          %[](    v(arr,2,3)
 *
 *     This means that we are slicing only the outermost level.
 *     Basically this solution is a simplification of the first one.
 *
 * The notation %[][]c could mean %[](%[]c%). However, it does not seem
 * much useful because it linerarizes the array, and thus it destroys
 * its structuring in sub-arrays, which is seldom needed.
 *
 * For an array the length is known, and thus a parens clause can be
 * repeated as many times as the length, irrespectively on its contents,
 * which could, however consume earlier the elements, and thus make the
 * parens clause terminate earlier.
 * There are two alternatives:
 *
 *  1. proceed in a parens-clause until its repetition is exhaused
 *     or a clause is encoutered which needs an element and the elements
 *     are exhaused, or
 *  2. the same, but when a clause is encountered that processes the
 *     last element, the parens clause is terminated after it.
 *
 * The difference is that the first one processes the clauses after the
 * one that handles the last, while the second does not. The first can
 * obtain also the effect of the second with the %me clause.
 *
 * To print a long array, several lines each with n elements can be used:
 * %[](%10( %i)\n). Note that the last line could be incomplete, but
 * nevertheless be printed.
 * A conv-clause that terminates because it does not find an element
 * terminates the directly enclosing parens-clause by going at the
 * end of it. The interpretation of the outer enclosing ones proceeds
 * as usual until the end of the one that has the [] in front of it is
 * reached, and then terminated because there are no more elements.
 *
 * In a %[](...%3(x %c %)...%) the termination criteria for the inner
 * parens-clause could be the consumption of the array or the absence
 * of an element. In the former case, when the %c has taken the last
 * element and the %) is reached, the parens clause would not be reentered,
 * while it would in the second case producing an `x'.
 * The former is the correct one because in %[](%10( %i)\n) when
 * formatting the last incomplete row, a trailing space would be produced
 * otherwise. Note also that the termination of the directly enclosing
 * parens clause when no more elements are available, but not of the outer
 * ones is what allows to print the \n in the example.
 * A nested parens-clause must be entered if there are no more elements in
 * the array because it could also contain text only.
 * Note that, to keep the rule for the premature termination of a
 * parens clause hold in all cases (i.e. that a parens clause is
 * abandoned when a clause which needs an element is processed and there
 * are none available), when a conversion clause with a repetition
 * factor is processed and there are not enough elements, the clause
 * is abandoned and also the parens clause. See the following examples:
 * of formats applied to "ab":
 *
 *          %[](%3c;=%)          ab
 *          %[](%c;=%)           a=b=
 *          %[](%c;=%c;=%)       a=b=
 *          %[](%2c;=%)          ab=
 *          %[](%c;=%c;=%c;=%)   a=b=
 *
 * Note that an array parens clause in which the elements are not scanned,
 * like e.g.: %[](%i$1%) ends anyway because the parens clause is repeated
 * at most as many times as the number of the elements.
 * There is a difference between the positional indication and the normal
 * one: the other one consumes an element, the former not. This means that
 * parens clauses can still be terminated when the elements have been
 * consumed.
 *
 * A test on the availability of an element is done on the current
 * element in getval to detect the unavailability of the element because
 * callbacks are entered without testing before if there are
 * elements since it is not known the number of elements they take.
 * There is no test at the end because the repetition is known in advance,
 * and thus in a callback with a loop the loop is terminated anyway.
 * However, in the loop a callback could read more elements. To cater for
 * this (e.g. a %[]y), scan_format catches the ERR_EXHAUST exception when
 * an array repetition factor is active and continues.
 * The test on the completion of an array is done in getval because
 * callbacks can have a loop in which several elements of the io list
 * are taken. It would be difficult to make the loop terminate to force
 * a callback return so that scan_format can terminate a parens-clause.
 * Moreover there can be callbacks that take several elements not in
 * a loop, for which a test after each one would be required.
 * In a %[]c there is a need to skip only the clause itself when the
 * array is empty, and not the rest of an enclosing parens-clause.
 * This is different from the case in which there is no array at all
 * (i.e. the elements of the enclosing parens-clause are exhausted), but
 * one was expected.
 * When a parens-clause for an array is processed, and a conv-clause is
 * encountered which finds only a part of the io list elements it requires,
 * it terminates the parens-clause and does not execute the offending
 * clause. This is so because a clause, as a rule, obtains first the
 * needed values and only then it performs an action.
 *
 * With array elements, a short int need be treated as a short, and a
 * char as a one-byte integer need be treated as such. The same for floats.
 * I.e. it is no longer possible to rely on the promotion.
 *
 * The base reference and the current index are kept to obtain the
 * elements, and to backtrack and proceed. To access elements, a switch
 * must be used for all element types.
 *
 *
 * Tracing
 *
 * There is a need to allow tracing inside callbacks and inside write()
 * calls present in callbacks. Since keeping the trc setting after the
 * return of write() makes a subsequent one emit tracing, trc must be
 * cleared upon exit. But then that of the enclosing one should be
 * restored upon reentering in it.
 * Trace flags are given with the %md cluse, which should be restated
 * in each format whose processing needs be traced.
 * This makes tracing localised on a call, but it cancels also tracing
 * of an enclosing call.  This means that trc must be saved and restored
 * should a clause change it, but %md should be allowed to change it.
 * The problem is that in this way there is no way to trace f(), v()
 * and the beginning of write().
 * To solve it, a settrc method is provided for debugging purposes only.
 * The idea of having a %md is to let the user control everything with
 * clauses. The problem is that if write() clears trc on entry, then there
 * is no way for settrc can steal in it.
 * The problem is also that inside a cbk a f().v() call is traced
 * with the current trace flags, and the .write() after it is traced
 * with the new ones.
 * Well, it is not wrong that inside a cbk tracing occurred with the
 * current trc setting.
 * The solution is to have a write() add its tracing flags to the
 * ones already present in trc, and restore trc upon exit. This means
 * that the current tracing is used, and that it can be set outside.
 * If one does not want any tracing in it, it can use %md-.
 *
 *
 * Testing:
 *
 * In order to test exceptions, a special %mx clause has been introduced:
 *
 *   - %mxo throws an OutOfMemory exception to test it.
 *   - %mxg allows to test all cases of getval.
 *
 * To make troubleshooting easier, a selfchecker can be introduced: a method
 * which examines the object and tells what is wrong with it. It could also
 * be called by the user. It is a method which checks the consistency of the
 * object, like e.g. that the indexes refer to existing positions in the text
 * record, etc.
 *
 *
 * State values
 *
 * In a Formatter object there is a need to keep a number of state values
 * that collectively represent the current mode of working.
 * If they are represented as booleans, at best they occupy a byte, and
 * at worst an integer since there is no primitive boolean type in the VM.
 * Since an application in general will not have many formatter objects,
 * it is chosen to represent these values as booleans instead of bits
 * in an integer, which would require more code in the class to access them.
 *
 *
 * Printing objects
 *
 * It could be useful to format objects which are not arrays by passing
 * simply a reference to them.
 * This is very useful for tracing because it allows to avoid writing
 * the names of variables in format text and repeating them in the io list.
 * It could also be useful in general when there is a need to represent
 * externally objects.
 * That can be provided by making %[]( open objects, and inside it have
 * $nnnn denote the fields.  This is more flexible than the positional
 * indication. This is needed because there is no guarantee that the fields
 * of an object are printed in a defined order. This means that the only
 * safe way to format an object would be to use a %s for its fields, like
 * e.g.: %[](%s %), or better %[](%j = %s %).
 * However, the support for %[] for objects is rather heavy and allows only
 * to specify how fieds are separated since the only conversion clause which
 * is meaningful is %s in it. It seems that it does not pay off.
 * For the time being, only the possibility to format objects in a standard
 * way with %s is provided.
 * This allows to trace easily objects without a need to write the names
 * of fields in formats.
 * Unfortunately, that is not possible for the variables because there
 * seems to be no way to access them by name.
 *
 *
 * Proportional fonts
 *
 * With proportional fonts the problem of producing a listing becomes
 * much more complex because it is no longer possible to reason in terms
 * of print positions. The same occurs perhaps with the monospaced fonts
 * in which some glyphs occupy more than one character (I do not know it
 * that is the case, but perhaps with some Unicode characters that can
 * occur).
 * The problem is to give an abstract view of the text record, in which
 * characters can be manipulated, counted, tabbed to, and keep behind
 * it the properties of them, such as the font, position, etc.
 * It is necessary to be able to measure the space occupied by the
 * characters so as to tab (e.g. to go to the next tab, the position of
 * the cursor must be known), and also the height to determine if a page is
 * full.
 * There is also a need to be able to erase a portion of text, which might
 * also start in the middle of a character (depending on the meaning of %e).
 * A property record can be kept, in which for each character of the
 * text record the position and the font is kept. Or, an array of triples
 * (character index, font, position).
 *
 * It would perhaps be appripriate to allow to produce PostScript output.
 * It should not be difficult because only few commands are needed, mainly
 * the ones to change the font and to place the cursor.
 * In the old days we liked to produce device independent output so as
 * to be able to print it on any printer. Nowadays this should be done
 * in PostScript. However, this does not seem to be that simple if font sizes
 * and baselines are taken into account.
 * Moreover, if text meant to be displayed is to be produced, perhaps there
 * would be a need to follow a different standard.
 * As it is now, write() builds strings, and allows to control pretty
 * well the placement of characters in them. When they contain Latin-x
 * characters, they can also be printed into a monospaced font keeping
 * a one-to-one graphycal rendering.
 * It seems that with a Java graphic context, by using all its methods
 * it is possible to place text where needed, and then to produce
 * a printable output. There is a need to know how the characters are
 * layed out when a string is placed and what happens when a newline is
 * printed.
 * Probably there is a need for an in-band (intermixed in text) or out-band
 * (accompanying text, but outside of it) markup language which allows to
 * lay out text and graphics be them displayed on a window or printed.
 * However, if to avoid inventing a new file format, it it better to stay
 * with the current, albeit unsatisfactory solution to produce Postscript
 * files for printing and something else for displaying.
 *
 * To use variable width fonts it is not possible to keep tabs as they
 * are now. An array must be kept with the positions (in whatever unit
 * of measure they are expressed)
 *
 * The usage of a text widget to determine the length of the text is probably
 * not efficient, but probably it handles bidi writing.
 *
 * The problem seems to define precisely the semantics of formatting and
 * of the text record. Field widths and tabulation has been introduced to
 * control layout. Then it has also been used to obtain external representations
 * which otherwise ought to be computed outside write(). There is then a need
 * to place the cursor both on page positions and on character positions.
 * To do the latter there is a need to define what gets into the text record
 * as a result of formatting, and in particular of tabbing. I.e. what goes
 * into the record when a fixed format is used. With monospaced fonts blanks
 * are included so as to reach the width, but with proportional ones, there
 * ought to be a command for cursor placement, which should be represented
 * by some logical space so as not to force the user know the actual (e.g.
 * Postscript) directive. The insertion of characters in the middle will not
 * be easy if the semantics is that to keep the characters placed at a given
 * page position stay there.
 * The problem of erasing occurs also when formatting with fixed format:
 * if Postscript does not have a command for erasing it is impossible to
 * trim the external representation exactly (i.e. in the middle of a character).
 * Instead, there would be a need to compute its lenght character by character
 * to determine the longest which is smaller than the width.
 * There are two kinds of tabubation: 1. the move of the cursor in the
 * text record (as now) and the move of the actual cursor in the page.
 *
 * Alternatively, the actual Postscript commands can be embedded in the
 * text record, and an array kept to index the user-visible characters.
 * This has the disadvantage to force to allocate a record not knowing
 * the length which is actually required.
 * In the other solution there is a need to represent the fonts (including
 * the kind, size, boldness, slantness) and the positions. This can
 * either be kept as a direct mapping for each character, or as a list (which
 * makes more difficult to erase and insert character, but easier all the rest).
 *
 * Another alternative is to produce PDF.
 * The problem is perhaps that the current formatting mechanism should
 * be prepared to work with proportional fonts. E.g. to align real numbers on
 * the decimal point. Probably for reals m:n can indicate the size of the
 * integral and the fractional part, or the total size and that of the
 * integral one.
 */


public class Formatter {

    /* Formatting object */

    /** The pointer to the text record. */
    public char[] buffer;

    /** The record length. */
    public int length;

    /** The current index in the text record. */
    public int cursor;

    /** The maximum index in the text record. */
    public int max;

    /** The last+1 index in the text record. */
    public int end;

    /** The enabling of text record growth. */
    private boolean grow;

    /** The Pointer to the call-data object. */
    public Cdata cptr;

    /** The pointer to the tab stops. */
    protected byte[] tabs;

    /** The presence of the basic callbacks. */
    protected int cbkpres;

    /** Whether a user insert has been called. */
    protected boolean inusrins;

    /** Whether a user heading has been called. */
    protected boolean inusrhdr;

    /** The result. */
    public int res;

    /** The exception object. */
    protected FormatterError excObj;

    /** The error handling. On error 0: ret 1: throw 2: abort.. */
    protected int errthrow;

    /** On error return a status code. */
    public static final int RET_STATUS = 0;

    /** On error return an exception. */
    public static final int ERR_THROW  = 1;

    /** On error abort. */
    public static final int ERR_ABORT  = 2;

    /** The trace flags. */
    protected int trc;

    /** The nesting of the current call. */
    protected int nestcall;

    /** The format/io-list check: 0 = enabled, 1 = disabled, 2 = autorepeat. */
    protected byte match;


    /** The file, if output to a file. */
    protected IoStream file;

    /** The message describing the result. */
    public String path;

    /** The file opened by write(). */
    protected boolean openfile;

    /** Whether flush is enabled. */
    protected boolean flush;

    /** Whether the file is a listing one. */
    protected boolean listing;

    /** Whether the i/o is the first one in a page. */
    protected boolean firstio;

    /** Whether the carriage is at column 0. */
    protected boolean iscol0;

    /** Whether the carriage is at the beginning of continuation line. */
    protected boolean newcont;

    /** Whether a form feed is pending. */
    protected boolean pendff;

    /** The removal of trailing blanks. */
    protected boolean remtrail;

    /** The proposed prefix carriage characters. */
    protected String prefix;

    /** The proposed suffix carriage characters. */
    protected String suffix;

    /** The line number. */
    public int linnr;

    /** The number of lines per page. */
    public int pageh;

    /** The current page number. */
    public int pagnr;

    /** The secondary page number. */
    public int pagns;

    /** The line separator. */
    protected String curLineSep;

    /** The reference to the user data object. */
    public Object udptr;

    /** The reference to the line heading. */
    protected char[] head;

    /** The lengthheading. */
    protected int headLength;

    /** The reference to the line tail. */
    protected char[] tail;

    /** The length of the line tail. */
    protected int tailLength;

    /** The indentation. */
    protected int indent;

    /** Whether insert mode is on. */
    protected boolean insert;

    /** Whether wrap mode is on. */
    protected boolean wrap;

    /** Whether default overflow evidence is on. */
    protected boolean evid;

    /** Whether the pendings is break-disappear. */
    protected boolean penddis;

    /** Whether the pendings is terminated by \n. */
    protected boolean pendnl;

    /** Whether breaks are enabled. */
    protected boolean breakon;

    /** Whether the breaks are disabled after the next one. */
    protected boolean breakdef;

    /** The reference to the last pending disappear inserted. */
    protected int lastdis;

    /** The lenght of lastdis. */
    protected int dislen;

    /** The minimum length of pendings. */
    protected static final int PND_MIN = 7;

    /** The reference to pendings. */
    protected char[] pend;

    /** The lenght of pend. */
    protected int pendLength;

    /** The index of the last insertion. */
    protected int lastbrk;

    /** The locales array. */
    public Locale[] locArr;

    /** The index of the current locale. */
    public int locNum;

    /** The array of number locale data. */
    protected LocNumData[] nlArr;

    /** The resources array. */
    public ResourceBundle[] resArr;

    /** The bundle names array. */
    public String[] bunArr;

    /** The number of resources. */
    public int resNum;

    /** Whether the default locale is fixed. */
    protected boolean locFixed;

    /** The hook to the common locale. */
    private Lang lang;

    /** Whether this object has been closed. */
    protected boolean closed;

    /**
     * The class describes the data which are relevant for a single
     * call of the formatting methods.
     */

    public static class Cdata {

        /** The nesting level of current call. */
        protected int nestlev;

        /** The pointer to the format. */
        public char[] formt;

        /** The length of the format. */
        public int forLength;

        /** The current index into the format. */
        public int pfor;

        /** The index of the beginning % of clause. */
        protected int pspec;

        /** The current nesting level of the format. */
        protected int nest;

        /** The current argument index in io list. */
        protected int ap;

        /** The pointer to the io list. */
        protected IoElem[] ioList;

        /** The number of elements in the io list. */
        protected int ioElemNr;

        /** The current nesting of io list redirection to an array. */
        protected int ionest;

        /** The number of elements visited. */
        protected int ioElemDone;

        /** The number of elements visited non-positionally. */
        protected int ioElemNonPos;

        /** The pointer to the stack of array references. */
        protected Parrs[] astack;

        /** The element position number. */
        protected int elemNum;

        /** The positionality: 0: not, 1: forward 2: backwards 3: absolute. */
        protected byte elemPos;

        /** The repetition factor. */
        public int repfact;

        /** The kind of conversion. */
        public char kind;

        /** Whether overflow evidentiation is enabled. */
        protected boolean evid;

        /** The padding character. */
        protected char padd;

        /** The width. */
        protected int minw;

        /** The maximum width. */
        protected int maxw;

        /** The justification. */
        protected int just;

        /** The integral part. */
        public int integral;

        /** The decimal part. */
        public int decimal;

        /** The sign forcing. */
        protected char sign;

        /** The thousand separator or the disabling of it. */
        protected char thou;

        /** The currency disable. */
        protected char cncy;

        /** The numeric filling. */
        protected char nfill;

        /** The decimal radix separator. */
        protected char dradix;

        /** The representation of a bit which is 0. */
        protected char bitrep0;

        /** The representation of a bit which is 1. */
        protected char bitrep1;

        /** Whether the minimum indicates the lower length. */
        protected boolean lowbound;

        /** Whether a break before piece is allowed. */
        protected boolean brk;

        /** Whether insert has been competed by a user method. */
        protected boolean insdone;

        /** The mode of conversion. */
        protected int mode;

        /** The field width. */
        protected int fldwid;

        /** The length of representation times the repetition factor. */
        protected int repwid;

        /** The length of the representation. */
        protected int replen;

        /** The length of the prefix (sign). */
        protected int preflen;

        /** The pointer to the (external) representation. */
        public Object eptr;

        /** The type of eptr. */
        protected byte erType;

        /** The start index in eptr. */
        public int eptrStart;

        /** The actual length of eptr. */
        public int erLength;

        /** The preallocated area for the external representataion. */
        protected char[] extRep;

        /** The pointer to the Cdata of caller. */
        protected Cdata cptr;

        /** The pointer to Cdata of callee. */
        protected Cdata fcptr;

        /** The qualifier presence bits. */
        protected long pres;

        /** The temporary string. */
        protected char[] str;

        /** The preallocated remnd piece. */
        protected char[] remndb;

        /** The preallocated reins piece. */
        protected char[] reminsb;

        /** The array of pieces to be inserted. */
        protected Piece[] pieces;

        /** The index in format past qualifiers. */
        protected int endQuals;

        /** The start index of the slice. */
        public int sliceStart;

        /** The length of slice. */
        public int sliceLength; 

        /** The return values of getval. */
        public boolean val_bool;

        /** The current value as char. */
        public char val_char;

        /** The current value as byte. */
        public byte val_byte;

        /** The current value as short. */
        public short val_short;

        /** The current value as int. */
        public int val_int;

        /** The current value as long. */
        public long val_long;

        /** The current value as float. */
        public float val_float;

        /** The current value as double. */
        public double val_double;

        /** The current value as Object. */
        public Object val_obj;
    }

    /** The lengh of the preallocated representation. */
    protected static final int REP_MIN = 70;

    private static class Parrs {

        /** The number of elements. */
        private int nr;

        /** The pointer to base. */
        private Object ap;

        /** The current index. */
        private int ix;

        /** The start index. */
        private int startix;

        /** The end index. */
        private int endix;

        /** The element type. */
        private byte type;
    }

    /** The empty string. */
    protected static final char[] EMPTY_STR = new char[0];

    /* Result values and messages */

    /** The file specification is illegal. */
    public static final int ERR_ILLFILE = 2;

    /** There is not enough space in the record. */
    public static final int ERR_NOSPACE = 14;

    /** The record is missing. */
    public static final int ERR_NOREC = 15;

    /** A character is missing. */
    public static final int ERR_NOCHAR = 16;

    /** The code is unknown or missing. */
    public static final int ERR_ILLCODE = 17;

    /** A closed ) is found, but no open one is present. */
    public static final int ERR_NOOPN = 18;

    /** An open ( is not closed. */
    public static final int ERR_NOCLO = 19;

    /** A number is missing. */
    public static final int ERR_NONUM = 20;

    /** The number is too low. */
    public static final int ERR_TOOLOW = 21;

    /** The cursor is placed out of the record. */
    public static final int ERR_OUTREC = 22;

    /** The tab is missing. */
    public static final int ERR_NOTAB = 23;

    /** The number is too large. */
    public static final int ERR_TOOLRG = 24;

    /** The format and io list do not match. */
    public static final int ERR_MISMATCH = 25;

    /** The format is illegal. */
    public static final int ERR_FORMAT = 26;

    /** No file nor output callback present. */
    public static final int ERR_STREAM = 27;

    /** A system error has occurred. */
    public static final int ERR_SYSTEM = 28;

    /** No locale is present. */
    public static final int ERR_LOCALE = 29;

    /** The number is negative. */
    public static final int ERR_NEGNUM = 30;

    /** An endless recursion would occur. */
    public static final int ERR_NEST = 31;

    /** A comma is missing. */
    public static final int ERR_MISCMA = 32;

    /** The io list is illegal. */
    public static final int ERR_IOLIST = 33;

    /** The io list has been exhaused. */
    public static final int ERR_EXHAUSTED = 34;

    /** The object is not initialized. */
    public static final int ERR_INIT = 35;

    /** The type is illegal. */
    public static final int ERR_ILLTYPE = 36;

    /** The index is illegal. */
    public static final int ERR_INDEX = 37;

    /** The value is illegal. */
    public static final int ERR_VALUE = 38;

    /** The resource is missing. */
    public static final int ERR_RESOURCE = 39;

    /**
     * A formatting error. It indicates the violation of a condition which
     * has been encountered during the execution of a method due either
     * to some external cause or to a programming error.
     */

    public static class FormatterError extends Failure {

        /**
         * The additional value.
         *
         * @serial
         */
        public int value;

        /**
         * The file path, if ERR_IOERR.
         *
         * @serial
         */
        public String path;

        /**
         * The additional string value.
         *
         * @serial
         */
        private String key;

        /**
         * The index in the format.
         *
         * @serial
         */
        private int pfor;

        /**
         * The length of the format.
         *
         * @serial
         */
        private int forLength;

        /**
         * The format.
         *
         * @serial
         */
        private char[] formt;

        /**
         * The index of the faulty spec in the format.
         *
         * @serial
         */
        private int pspec;

        /**
         * Create a FormatterError.
         *
         * @param      c error code
         * @param      o stream on which it occurs
         */

        FormatterError(int c, Object o){
            super(c,'F',null,null,message(c),null,o);   // message describing result
        }

        /**
         * Deliver the strings representing the failure.
         *
         * @param      loc locale, null if no locale
         * @return     strings
         */

        public String[] getMessages(Locale loc){
            int n = 1;
            if (this.path != null) n++;
            if (this.formt != null) n++;
            String[] res = new String[n];
            Locale l = loc;
            if (loc == null) l = Locale.getDefault();
            ResourceBundle bun =
                ResourceBundle.getBundle(
                IOBundle.class.getName(),l);
            res[0] = header("Formatter",'F') +
                ((String[])(bun.getObject("MSGTAB")))[this.code];
            n = 1;
            if (this.path != null){
                res[n++] = bun.getString("ONFILE") + ": " + this.path;
            }
            if ((this.code != IOError.ERR_IOERR) && (this.formt != null)){
                int pfor = this.pfor;
                res[n++] = 
                    bun.getString("ONFORMAT") +
                    " " + String.valueOf(this.formt,0,this.forLength) +
                    " " + bun.getString("POSITION") +
                    ": " + (this.pfor-1) + ": " +
                    String.valueOf(this.formt,this.pspec,
                    pfor-this.pspec) +
                    ((this.key == null) ? "" : ", " + this.key);
            }
            return res;
        }
    }

    /**
     * Deliver the locale neutral message which corresponds to a given
     * error code.
     *
     * @param      c error code
     */

    private static String message(int c){
        String[] msgtab = IOBundle.MSGTAB;
        if (msgtab == null) return Integer.toString(c);
        else if (c >= 0) return msgtab[c];
        else return Integer.toString(c);
    }

    /**
     * Initialize the exception and return status.
     */

    private void excInit(){
        this.res = 0;
        this.excObj = null;
    }

    /**
     * Terminate the exception and return status.
     */

    private void excTerm(){
        if (this.res != 0){
            if (this.openfile){
                try {
                    this.file.close();       // close the file
                    this.openfile = false;
                } catch (Throwable exc){
                }
            }
            signalError();
        } else {
            this.excObj = null;
        }
    }

    /**
     * Create an exception object if one is not present.
     *
     * @param      code error code
     * @param      exc additional exception
     */

    private void registerError(int code, Throwable exc){
        this.res = code;
        if (this.excObj == null){
            this.excObj = new FormatterError(code,this);
            Cdata qu = this.cptr;
            if (qu != null){
                this.excObj.pfor = qu.pfor;
                this.excObj.forLength = qu.forLength;
                this.excObj.formt = (char[])qu.formt.clone();
                this.excObj.pspec = qu.pspec;
            }
            this.excObj.exc = exc;
            if (this.cptr != null){
                this.excObj.value = this.cptr.pfor;
            }
            this.excObj.path = this.path;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("registerError: " + message(code) +
                    " " + this.excObj.pspec + " " + this.excObj.pfor);
            }
        }
    }

    /**
     * Create an exception object if one is not present.
     *
     * @param      code error code
     */

    private void registerError(int code){
        registerError(code,null);
    }

    /**
     * Handle an error: it aborts the program or it throws an exception.
     *
     * @param      code error code
     */

    private void signalError(){
        Cdata qu = this.cptr;
        if (qu != null) qu.ioElemNr = 0;      // empty the io list
        if ((FL_A & this.trc) != 0){
            Trc.out.println("error signal " + this.res +
                " at: " + qu.pfor + " " + this.errthrow);
        }
        if (this.errthrow == ERR_ABORT){
            if ((FL_A & this.trc) != 0){
                Trc.out.println("error abort");
            }
            this.excObj.print(System.err,Locale.getDefault(),false);
            System.exit(1);
        } else if (this.errthrow == ERR_THROW){
            if ((FL_A & this.trc) != 0){
                Trc.out.println("error throw");
            }
            this.excObj.fillInStackTrace();
            throw this.excObj;
        }
    }

    /**
     * Throw an error and it registers the error data.
     *
     * @param      code error code
     */

    public void error(int code){
        registerError(code);
        throw this.excObj;
    }

    /**
     * Throw an error and it registers the error data.
     *
     * @param      code error code
     * @param      exc additional exception
     */

    public void error(int code, Throwable exc){
        registerError(code,exc);
        throw this.excObj;
    }

    /**
     * Throw an error and it registers the error data.
     *
     * @param      code error code
     * @param      exc additional exception
     * @param      key additional string value
     */

    public void error(int code, Throwable exc, String key){
        registerError(code,exc);
        this.excObj.key = key;
        throw this.excObj;
    }


    /* Constructors */

    /**
     * Construct a new <code>Formatter</code> with no text record in it.
     */

    public Formatter(){
        this(ERR_THROW);
    }

    /**
     * Construct a new <code>Formatter</code> with no text record in it,
     * and with a given error handling policy.
     *
     * @param      et kind of handling
     */

    public Formatter(int et){
        Class sup;
        Class c;
        Method[] methArr;
        this.cbkpres = 0;
        String meth;
        this.errthrow = et;               // no other init needed because
                                          // .. %a needed
        try {
            c = this.getClass();
            while ((c != null) && (c != Formatter.class)){
                methArr = c.getDeclaredMethods();
                for (int i = 0; i < methArr.length; i++) {
                    meth = methArr[i].getName();
                    if (meth.equals("out_cbk"))        this.cbkpres |= OUTCBK;
                    else if (meth.equals("entry_cbk")) this.cbkpres |= ENTRYCBK;
                    else if (meth.equals("exit_cbk"))  this.cbkpres |= EXITCBK;
                    else if (meth.equals("ins_cbk"))   this.cbkpres |= INSERTCBK;
                    else if (meth.equals("head_cbk"))  this.cbkpres |= HEADCBK;
                    else if (meth.equals("page_cbk"))  this.cbkpres |= PAGECBK;
                }
                c = c.getSuperclass();
            }
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (SecurityException exc){
            registerError(ERR_INIT,exc);
        }
        excTerm();
    }

    /**
     * Construct a new <code>Formatter</code> with a char[] as text record.
     *
     * @param  buf The record
     */

    public Formatter(char[] buf){
        this(buf,(buf == null) ? 0 : buf.length);
    }

    /**
     * Construct a new <code>Formatter</code> with a char[] as text record.
     *
     * @param  buf The record
     * @param  len The length of the portion of the buffer which is to be
     *         used as text record.
     */

    public Formatter(char[] buf, int len){
        this();
        initialize(buf,len,null,false,false);
    }

    /**
     * Construct a new <code>Formatter</code> with a file for a default
     * record length of 80.
     *
     * @param  fil The file, either as a Writer, BufferedWriter, PrintStream,
     *         IoStream, or as a filespec.
     */

    public Formatter(Object fil){
        this(fil,80,false,false);
    }

    /**
     * Construct a new <code>Formatter</code> with a file.
     *
     * @param  fil The file, either as a Writer, BufferedWriter, PrintStream,
     *         IoStream, or as a filespec.
     * @param  len The length of the text record.
     */

    public Formatter(Object fil, int len){
        this(fil,len,false,false);
    }

    /**
     * Construct a new <code>Formatter</code> with a file.
     *
     * @param  fil The file, either as a Write, BufferedWriter, PrintStream,
     *         IoStream, or as a filespec.
     * @param  len The length of the text record
     * @param  app True if open in append
     * @param  lis True if listing file
     */

    public Formatter(Object fil, int len, boolean app, boolean lis){
        this();
        initialize(null,len,fil,app,lis);
    }

    /**
     * Close this <code>Formatter</code>. It is equivalent to the execution
     * of a <code>%z</code> clause, except that it closes the file anyway.
     */

    public void close(){
        excInit();
        try {
            this.openfile = true;    // force close()
            terminate();
        } catch (FormatterError exc){
        }
        excTerm();
    }

    /**
     * Deliver a reference to the file.
     *
     * @return reference
     */

    public IoStream getFile(){
        return this.file;
    }


    /* Callbacks */

    /** The flag denoting the presence of the output callback. */
    private static final int OUTCBK    = 1 << 0;

    /** The flag denoting the presence of the entry callback. */
    private static final int ENTRYCBK  = 1 << 1;

    /** The flag denoting the presence of the exit callback. */
    private static final int EXITCBK   = 1 << 2;

    /** The flag denoting the presence of the insert callback. */
    private static final int INSERTCBK = 1 << 3;

    /** The flag denoting the presence of the heading callback. */
    private static final int HEADCBK   = 1 << 4;

    /** The flag denoting the presence of the page callback. */
    private static final int PAGECBK   = 1 << 5;

    /** The names of the basic callbacks. */
    private static String[] CBKNAM = {
        "output","entry","exit","insert",
        "line heading","text","page heading"};

    /** The constant formatter denoting an error in inline calls. */
    private static final Formatter ERR_OBJ = new Formatter();  // error object


    /* Trace */

    /*
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    a   basic operations
     *    b   format-specs and arguments (user trace)
     *    c   actions
     *    d   internal details of callbacks
     *    e   even more details
     *    f   details of floats
     *    i   io list
     *    l   loop: data at the call and return of callbacks
     *    m   allocation
     *    n   nesting
     *    r   record at return of callbacks
     * </pre></blockquote><p>
     */

    /*
     * Internal constants for trace flags
     */

    protected static final int FL_A = 1 << ('a'-0x60);
    protected static final int FL_B = 1 << ('b'-0x60);
    protected static final int FL_C = 1 << ('c'-0x60);
    protected static final int FL_D = 1 << ('d'-0x60);
    protected static final int FL_E = 1 << ('e'-0x60);
    protected static final int FL_F = 1 << ('f'-0x60);
    protected static final int FL_I = 1 << ('i'-0x60);
    protected static final int FL_L = 1 << ('l'-0x60);
    protected static final int FL_M = 1 << ('m'-0x60);
    protected static final int FL_N = 1 << ('n'-0x60);
    protected static final int FL_R = 1 << ('r'-0x60);

    /**
     * Deliver a trace flag.  Trace flags mapping is a = b1, b = b2 ...
     *
     * @param      c character
     */

    private boolean fl(char c){
        return ((1 << (c - 0x60)) & trc) != 0;
    }

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Trace the point in the format.
     *
     * @param      s comment string
     * @param      rep additional integer value printed
     */

    protected void trcpoint(String s, int rep){
        Cdata qu = this.cptr;
        Trc.out.println(s + " for: " + qu.formt[qu.pfor] +
            " at " + qu.pfor + " cur: " + this.cursor +
            " max: " + this.max + " nest:" + qu.nest +
            " rep: " + rep + " res: " + this.res);
    }

    /**
     * Trace the point in the record.
     *
     * @param      s comment string
     * @param      rep additional integer value printed
     */

    protected void trcrec(){
        Trc.out.print("record: |");
        Trc.literalize(this.buffer,this.cursor);
        Trc.out.print("^");
        Trc.literalize(this.buffer,this.cursor,
            (this.max-this.cursor >= 0 ? this.max-this.cursor : 0));
        Trc.out.println("| cur(^) at " + this.cursor);
    }


    /* Io list handling */

    /**
     * An io list element.
     */

    public static class IoElem {

        /** The type of the element. */
        private byte type;

        /** Whether the element has been visited. */
        private byte done;

        /** The integral value of the element. */
        private long integral;

        /** The floating point value of the element. */
        private double real;

        /** The reference value of the element. */
        private Object obj;

        /** The slice length of the element. */
        private int length;

        /**
         * Copy an io list element into the current one.
         *
         * @param      src source element
         */

        private void copy(IoElem src){
            this.type = src.type;
            this.done = src.done;
            this.integral = src.integral;
            this.real = src.real;
            this.obj = src.obj;
            this.length = src.length;
        }

    }

    /* The constants for the type of elements. */

    /** The boolean type. */
    public static final byte FRM_BOOL    =  0;

    /** The character type. */
    public static final byte FRM_CHAR    =  1;

    /** The byte type. */
    public static final byte FRM_BYTE    =  2;

    /** The short type. */
    public static final byte FRM_SHORT   =  3;

    /** The int type. */
    public static final byte FRM_INT     =  4;

    /** The long type. */
    public static final byte FRM_LONG    =  5;

    /** The float type. */
    public static final byte FRM_FLOAT   =  6;

    /** The double type. */
    public static final byte FRM_DOUBLE  =  7;

    /** The byte[] type. */
    public static final byte FRM_BYTES   =  8;

    /** The char[] type. */
    public static final byte FRM_CHARS   =  9;

    /** The String type. */
    public static final byte FRM_STRING  = 10;

    /** The StringBuffer type. */
    public static final byte FRM_STRBUF  = 11;

    /** The Date type. */
    public static final byte FRM_DATE    = 12;

    /** The Object type. */
    public static final byte FRM_OBJ     = 13;

    /** The String as array type. */
    public static final byte FRM_ASTRING = 14;

    /** The StringBuffer as array type. */
    public static final byte FRM_ASTRBUF = 15;

    /** The user defined type. */
    public static final byte FRM_USER    = 16;

    /** The BigInteger type. */
    public static final byte FRM_BIGINT  = 17;

    /** The BigDecimal type. */
    public static final byte FRM_BIGDEC  = 18;

    /**
     * Guarantee that there is a free element in the array of the io list.
     * Enlarge it if needed. Set the result and exception fields to success
     * or error accordingly so as to make all <code>v</code> methods exit with
     * these fields set properly.
     *
     * @return     Cdata object
     */

    private Cdata ensureCapacity(){
        Cdata qu = null;
        int   len = 0;
        int   newlen = 0;

        excInit();
        alloc: try {
            qu = ensure_cdata();
            if (qu.ioList != null){
                len = qu.ioList.length;
            }
            if (qu.ioElemNr < len){               // slots available
                qu.ioList[qu.ioElemNr].done = 0;  // init current element
                break alloc;
            }
            newlen = len + IOELEMALL;
            if (newlen < 0) error(IOError.ERR_OUTLIMIT);
            IoElem[] newIoList = new IoElem[newlen];
            if (qu.ioList != null){
                System.arraycopy(qu.ioList,0,newIoList,0,len);
            }
            for (int i = len; i < newlen; i++){
                newIoList[i] = new IoElem();
            }
            qu.ioList = newIoList;
            if ((FL_M & this.trc) != 0){
                Trc.out.println("iolist allocated: " + qu.ioList.length);
            }
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (FormatterError exc){
        } finally {
            if (this.res != 0){
                if (qu != null) qu.ioElemNr = 0;   // empty the io list
            }
        }
        excTerm();
        return qu;
    }

    /** The allocation granularity of elements. */
    protected static final int IOELEMALL = 10;

    /**
     * Deliver a copy of the current io list. It is meant to be used
     * to reload later a group of io list elements in a single operation.
     *
     * @return     io list
     */

    public IoElem[] getIoList(){
        IoElem[] list;
        Cdata    qu;

        if ((FL_A & this.trc) != 0)
            Trc.out.println("getIolist");
        excInit();
        list = null;
        try {
            qu = ensure_cdata();
            if (qu.ioElemNr != 0){
                list = new IoElem[qu.ioElemNr];
                System.arraycopy(qu.ioList,0,list,0,qu.ioElemNr);
                for (int i = 0; i < qu.ioElemNr; i++){
                    list[i] = new IoElem();
                    list[i].copy(qu.ioList[i]);
                    list[i].done = 0;
                }
                qu.ioElemNr = 0;
            }
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        }
        excTerm();
        if ((FL_A & this.trc) != 0)
            Trc.out.println("getIolist done");
        return list;
    }

    /**
     * Register all the elements contained in an IoElem[] value in the
     * io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(IoElem[] v){
        Cdata qu;
        if (this == ERR_OBJ) return ERR_OBJ;
        for (int i = 0; i < v.length; i++){
            qu = ensureCapacity();
            if (this.res != 0) return ERR_OBJ;
            qu.ioList[qu.ioElemNr++].copy(v[i]);
        }
        return this;
    }

    /**
     * Register all the elements contained in a Varg value in the
     * io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(Varg v){
        Cdata qu;
        if (this == ERR_OBJ) return ERR_OBJ;
        for (int i = 0; i < v.argNr; i++){
            qu = ensureCapacity();
            if (this.res != 0) return ERR_OBJ;
            IoElem p = qu.ioList[qu.ioElemNr++];
            Vargument src = v.list[i];
            p.type = src.type;
            p.done = 0;
            p.integral = src.integral;
            p.real = src.real;
            p.obj = src.obj;
            p.length = src.length;
            if ((p.obj != null) &&
                (p.obj instanceof Formatter.Api)){
                p.type = FRM_USER;
            }
        }
        return this;
    }

    /**
     * Register a boolean value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(boolean v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_BOOL;
        qu.ioList[qu.ioElemNr++].integral = v ? 1 : 0;
        return this;
    }

    /**
     * Register a Boolean value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(Boolean v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_BOOL;
        qu.ioList[qu.ioElemNr++].integral = v.booleanValue() ? 1 : 0;
        return this;
    }

    /**
     * Register a character value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(char v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_CHAR;
        qu.ioList[qu.ioElemNr++].integral = (char)v;
        return this;
    }

    /**
     * Register a Character value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(Character v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_CHAR;
        qu.ioList[qu.ioElemNr++].integral = v.charValue();
        return this;
    }

    /**
     * Register a byte value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(byte v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_BYTE;
        qu.ioList[qu.ioElemNr++].integral = v;
        return this;
    }

    /**
     * Register a Byte value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(Byte v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_BYTE;
        qu.ioList[qu.ioElemNr++].integral = v.byteValue();
        return this;
    }

    /**
     * Register a short value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(short v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_SHORT;
        qu.ioList[qu.ioElemNr++].integral = v;
        return this;
    }

    /**
     * Register a Short value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(Short v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_SHORT;
        qu.ioList[qu.ioElemNr++].integral = v.shortValue();
        return this;
    }

    /**
     * Register an int value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(int v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_INT;
        qu.ioList[qu.ioElemNr++].integral = v;
        return this;
    }

    /**
     * Register an Integer value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(Integer v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_INT;
        qu.ioList[qu.ioElemNr++].integral = v.intValue();
        return this;
    }

    /**
     * Register a long value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(long v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_LONG;
        qu.ioList[qu.ioElemNr++].integral = v;
        return this;
    }

    /**
     * Register a Long value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(Long v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_LONG;
        qu.ioList[qu.ioElemNr++].integral = v.longValue();
        return this;
    }

    /**
     * Register a BigInteger value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(BigInteger v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_BIGINT;
        qu.ioList[qu.ioElemNr++].obj = v;
        return this;
    }

    /**
     * Register a float value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(float v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_FLOAT;
        qu.ioList[qu.ioElemNr++].real = v;
        return this;
    }

    /**
     * Register a Float value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(Float v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_FLOAT;
        qu.ioList[qu.ioElemNr++].real = v.floatValue();
        return this;
    }

    /**
     * Register a double value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(double v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_DOUBLE;
        qu.ioList[qu.ioElemNr++].real = v;
        return this;
    }

    /**
     * Register a Double value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(Double v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_DOUBLE;
        qu.ioList[qu.ioElemNr++].real = v.doubleValue();
        return this;
    }

    /**
     * Register a BigDecimal value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(BigDecimal v){
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        qu.ioList[qu.ioElemNr].type = FRM_BIGDEC;
        qu.ioList[qu.ioElemNr++].obj = v;
        return this;
    }

    /**
     * Register a byte[] value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(byte[] v){
        return v(v,0,(v == null)? 0 : v.length);
    }

    /**
     * Register a byte[] slice value in the io list with a start index
     * of 0. The length must not he greater thant that of the value.
     *
     * @param      v value
     * @param      length of the slice
     * @return     this
     */

    public Formatter v(byte[] v, int length){
        return v(v,0,length);
    }

    /**
     * Register a byte[] slice value in the io list. The indexes
     * must denote a valid slice.
     *
     * @param      v value
     * @param      start index (inclusive)
     * @param      end index (non inclusive)
     * @return     this
     */

    public Formatter v(byte[] v, int start, int end){
        IoElem p;
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        p = qu.ioList[qu.ioElemNr];
        p.type = FRM_BYTES;
        p.obj = v;
        p.integral = start;
        if (v != null) p.length = v.length;
        else p.length = 0;
        if ((start < 0) || (end < 0) ||
            (end-start < 0) || (end > p.length)){
            qu.ioElemNr = 0;                  // empty the io list
            registerError(ERR_INDEX);
            signalError();
        } else {
            p.length = end-start;
            qu.ioElemNr++;
        }
        if (this.res != 0) return ERR_OBJ;
        return this;
    }

    /**
     * Register a char[] value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(char[] v){
        return v(v,0,(v == null)? 0 : v.length);
    }

    /**
     * Register a char[] slice value in the io list with a start index
     * of 0. The length must not he greater thant that of the value.
     *
     * @param      v value
     * @param      length of the slice
     * @return     this
     */

    public Formatter v(char[] v, int length){
        return v(v,0,length);
    }

    /**
     * Register a char[] slice value in the io list. The indexes
     * must denote a valid slice.
     *
     * @param      start index (inclusive)
     * @param      end index (non inclusive)
     * @return     this
     */

    public Formatter v(char[] v, int start, int end){
        IoElem p;
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        p = qu.ioList[qu.ioElemNr];
        p.type = FRM_CHARS;
        p.obj = v;
        p.integral = start;
        if (v != null) p.length = v.length;
        else p.length = 0;
        if ((start < 0) || (end < 0) ||
            (end-start < 0) || (end > p.length)){
            qu.ioElemNr = 0;                  // empty the io list
            registerError(ERR_INDEX);
            signalError();
        } else {
            p.length = end-start;
            qu.ioElemNr++;
        }
        if (this.res != 0) return ERR_OBJ;
        return this;
    }

    /**
     * Register a Str value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(Str v){
        return v(v.buffer,0,(v == null)? 0 : v.length);
    }

    /**
     * Register a Str slice value in the io list with a start index
     * of 0. The length must not he greater thant that of the value.
     *
     * @param      v value
     * @param      length of the slice
     * @return     this
     */

    public Formatter v(Str v, int length){
        return v(v.buffer,0,length);
    }

    /**
     * Register a Str slice value in the io list. The indexes
     * must denote a valid slice.
     *
     * @param      start index (inclusive)
     * @param      end index (non inclusive)
     * @return     this
     */

    public Formatter v(Str v, int start, int end){
        return v(v.buffer,start,end);
    }

    /**
     * Register a String value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(String v){
        return v(v,0,(v == null)? 0 : v.length());
    }

    /**
     * Register a String slice value in the io list with a start index
     * of 0. The length must not he greater thant that of the value.
     *
     * @param      v value
     * @param      length of the slice
     * @return     this
     */

    public Formatter v(String v, int length){
        return v(v,0,length);
    }

    /**
     * Register a String slice value in the io list. The indexes
     * must denote a valid slice.
     *
     * @param      v value
     * @param      start index (inclusive)
     * @param      end index (non inclusive)
     * @return     this
     */

    public Formatter v(String v, int start, int end){
        IoElem p;
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        p = qu.ioList[qu.ioElemNr];
        p.type = FRM_STRING;
        p.obj = v;
        p.integral = start;
        if (v != null) p.length = v.length();
        else p.length = 0;
        if ((start < 0) || (end < 0) ||
            (end-start < 0) || (end > p.length)){
            qu.ioElemNr = 0;                  // empty the io list
            registerError(ERR_INDEX);
            signalError();
        } else {
            p.length = end-start;
            qu.ioElemNr++;
        }
        if (this.res != 0) return ERR_OBJ;
        return this;
    }

    /**
     * Register a StringBuffer value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(StringBuffer v){
        return v(v,0,(v == null)? 0 : v.length());
    }

    /**
     * Register a String slice value in the io list with a start index
     * of 0. The length must not he greater thant that of the value.
     *
     * @param      v value
     * @param      length of the slice
     * @return     this
     */

    public Formatter v(StringBuffer v, int length){
        return v(v,0,length);
    }

    /**
     * Register a StringBuffer slice value in the io list. The indexes
     * must denote a valid slice.
     *
     * @param      v value
     * @param      start index (inclusive)
     * @param      end index (non inclusive)
     * @return     this
     */

    public Formatter v(StringBuffer v, int start, int end){
        IoElem p;
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        p = qu.ioList[qu.ioElemNr];
        p.type = FRM_STRBUF;
        p.obj = v;
        p.integral = start;
        if (v != null) p.length = v.length();
        else p.length = 0;
        if ((start < 0) || (end < 0) ||
            (end-start < 0) || (end > p.length)){
            qu.ioElemNr = 0;                  // empty the io list
            registerError(ERR_INDEX);
            signalError();
        } else {
            p.length = end-start;
            qu.ioElemNr++;
        }
        if (this.res != 0) return ERR_OBJ;
        return this;
    }

    /**
     * Register a Date value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(Date v){
        IoElem p;
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        p = qu.ioList[qu.ioElemNr];
        p.type = FRM_DATE;
        p.obj = v;
        p.integral = 0;
        p.length = 0;
        qu.ioElemNr++;
        return this;
    }

    /**
     * Register a Number value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(Number v){
        IoElem p;
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        Class c = v.getClass();
        p = qu.ioList[qu.ioElemNr];
        if (c == Byte.class){
            p.type = FRM_BYTE;
            p.integral = v.intValue();
        } else if (c == Short.class){
            p.type = FRM_SHORT;
            p.integral = v.shortValue();
        } else if (c == Integer.class){
            p.type = FRM_INT;
            p.integral = v.intValue();
        } else if (c == Long.class){
            p.type = FRM_LONG;
            p.integral = v.longValue();
        } else if (c == Float.class){
            p.type = FRM_FLOAT;
            p.real = v.floatValue();
        } else if (c == Double.class){
            p.type = FRM_DOUBLE;
            p.real = v.doubleValue();
        }
        qu.ioElemNr++;
        if (this.res != 0) return ERR_OBJ;
        return this;
    }


    /**
     * Register an Object value in the io list.
     *
     * @param      v value
     * @return     this
     */

    public Formatter v(Object v){
        IoElem p;
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        p = qu.ioList[qu.ioElemNr];
        p.obj = v;
        if (v instanceof Formatter.Api){
            p.type = FRM_USER;
        } else {
            p.type = FRM_OBJ;
        }
        p.integral = 0;
        if ((v != null) && (v.getClass().isArray())){
            p.length = Array.getLength(v);
        } else {
            p.length = -1;
        }
        qu.ioElemNr++;
        if (this.res != 0) return ERR_OBJ;
        return this;
    }

    /**
     * Register an Object slice value in the io list with a start index
     * of 0. The length must not he greater thant that of the value.
     *
     * @param      v value
     * @param      length of the slice
     * @return     this
     */

    public Formatter v(Object v, int length){
        return v(v,0,length);
    }

    /**
     * Register an Object slice value in the io list. The indexes are
     * checked by a subsequent write().
     *
     * @param      v value
     * @param      start index (inclusive)
     * @param      end index (non inclusive)
     * @return     this
     */

    public Formatter v(Object v, int start, int end){
        IoElem p;
        if (this == ERR_OBJ) return ERR_OBJ;
        Cdata qu = ensureCapacity();
        if (this.res != 0) return ERR_OBJ;
        p = qu.ioList[qu.ioElemNr];
        if (v instanceof Formatter.Api){
            p.type = FRM_USER;
        } else {
            p.type = FRM_OBJ;
        }
        p.obj = v;
        p.integral = start;
        p.length = end-start;
        if ((start < 0) || (end < 0) ||
            (end-start < 0)){
            qu.ioElemNr = 0;                  // empty the io list
            registerError(ERR_INDEX);
            signalError();
        } else {
            qu.ioElemNr++;
        }
        if (this.res != 0) return ERR_OBJ;
        return this;
    }

    /**
     * Format values and text. Apply the conversion, editing and io
     * functions contained in the format argument to the values passed as
     * argument and to the output stream to which it is applied.
     * It is equivalent to a <code>write</code> with an io list built
     * from the specified values.
     *
     * @param      f format
     * @param      args value to be formatted
     */

    public void format(String f, Object ... args){
        Cdata qu;
        if (this == ERR_OBJ) return;
        for (int i = 0; i < args.length; i++){        // scan the args and create an io list
            qu = ensureCapacity();
            if (this.res != 0) return;
            IoElem p = qu.ioList[qu.ioElemNr++];
            Class c = args[i].getClass();
            Object v = args[i];
            if (c == Boolean.class){
                p.type = FRM_BOOL;
                p.integral = ((Boolean)v).booleanValue() ? 1 : 0;
            } else if (c == Character.class){
                p.type = FRM_CHAR;
                p.integral = ((Character)v).charValue();
            } else if (c == Byte.class){
                p.type = FRM_BYTE;
                p.integral = ((Byte)v).byteValue();
            } else if (c == Short.class){
                p.type = FRM_SHORT;
                p.integral = ((Short)v).shortValue();
            } else if (c == Integer.class){
                p.type = FRM_INT;
                p.integral = ((Integer)v).intValue();
            } else if (c == Long.class){
                p.type = FRM_LONG;
                p.integral = ((Long)v).longValue();
            } else if (c == BigInteger.class){
                p.type = FRM_BIGINT;
                p.obj = v;
            } else if (c == Float.class){
                p.type = FRM_FLOAT;
                p.real = ((Float)v).floatValue();
            } else if (c == Double.class){
                p.type = FRM_DOUBLE;
                p.real = ((Double)v).doubleValue();
            } else if (c == BigDecimal.class){
                p.type = FRM_BIGDEC;
                p.obj = v;
            } else if (c == byte[].class){
                p.type = FRM_BYTES;
                p.obj = v;
                p.integral = 0;
                if (v != null) p.length = ((byte[])v).length;
                else p.length = 0;
            } else if (c == char[].class){
                p.type = FRM_CHARS;
                p.obj = v;
                p.integral = 0;
                if (v != null) p.length = ((char[])v).length;
                else p.length = 0;
            } else if (c == Str.class){
                p.type = FRM_CHARS;
                p.obj = ((Str)v).buffer;
                p.integral = 0;
                if (v != null) p.length = ((Str)v).length;
                else p.length = 0;
            } else if (c == String.class){
                p.type = FRM_STRING;
                p.obj = v;
                p.integral = 0;
                if (v != null) p.length = ((String)v).length();
                else p.length = 0;
            } else if (c == StringBuffer.class){
                p.type = FRM_STRBUF;
                p.obj = v;
                p.integral = 0;
                if (v != null) p.length = ((StringBuffer)v).length();
                else p.length = 0;
            } else if (c == Date.class){
                p.type = FRM_DATE;
                p.obj = v;
                p.integral = 0;
                p.length = 0;
            } else {
                p.obj = v;
                if (v instanceof Formatter.Api){
                    p.type = FRM_USER;
                } else {
                    p.type = FRM_OBJ;
                }
                p.integral = 0;
                if ((v != null) && (c.isArray())){
                    p.length = Array.getLength(v);
                } else {
                    p.length = -1;
                }
            }
        }
        write(f,false,true);
    }

    /**
     * Format values and text. Apply the conversion, editing and io
     * functions contained in the format argument to the values passed as
     * argument and to the output stream to which it is applied and
     * return the result as a string.
     *
     * @param      f format
     * @param      args value to be formatted
     */

    public static String printf(String f, Object ... args){
        Formatter frm = new Formatter();
        frm.format("%mg");
        frm.format(f,args);
        return frm.toString();
    }

    /**
     * Traces the io list.
     */

    protected void ioListTrace(){
        Cdata  qu = this.cptr;
        String s;
        byte   t;
        IoElem e;

        if (qu.ioList == null){
            Trc.out.println("io list empty");
            return;
        }
        Trc.out.println("io list nr: " + qu.ioElemNr +
           " up: " + qu.ioList.length);
        for (int i = 0; i < qu.ioElemNr; i++){
            e = qu.ioList[i];
            t = e.type;
            Trc.out.print(i);
            switch (t){
            case FRM_BOOL:   s = "boolean"; break;
            case FRM_CHAR:   s = "char"; break;
            case FRM_BYTE:   s = "byte"; break;
            case FRM_SHORT:  s = "short"; break;
            case FRM_INT:    s = "int"; break;
            case FRM_LONG:   s = "long"; break;
            case FRM_FLOAT:  s = "float"; break;
            case FRM_DOUBLE: s = "double"; break;
            case FRM_BYTES:  s = "byte[]"; break;
            case FRM_CHARS:  s = "char[]"; break;
            case FRM_STRING: s = "String"; break;
            case FRM_STRBUF: s = "StringBuffer"; break;
            case FRM_DATE:   s = "Date"; break;
            case FRM_OBJ:    s = "Object"; break;
            case FRM_USER:   s = "Api"; break;
            case FRM_BIGINT: s = "BigInteger"; break;
            case FRM_BIGDEC: s = "BigDecimal"; break;
            default:         s = "unknown";
            }
            Trc.out.print(" " + s + " t: " + t + " ");
            if (t <= FRM_LONG){
                Trc.out.print(e.integral);
            } else if ((t == FRM_FLOAT) ||
                (t == FRM_DOUBLE)){
                Trc.out.print(e.real);
            } else {
                if (e.obj != null){
                    Trc.out.print(e.obj.toString());
                } else {
                    Trc.out.print("null");
                }
                Trc.out.print(" " + e.integral + " : " +
                    e.length);
            }
            Trc.out.println(" " + e.done);
        }
    }

    /**
     * Deliver the type of the element registered in Cdata.
     *
     * @return     type of the element
     */

    public byte getElemType(){
        Cdata qu = this.cptr;;
        int   idx;
        byte  type;

        idx = getElemIdx();       // check existence of element
        if (this.res != 0) error(this.res);
        if (qu.ionest >= 0){
            Parrs p = qu.astack[qu.ionest];
            switch (p.type){
            case FRM_ASTRING: return FRM_CHAR;
            case FRM_ASTRBUF: return FRM_CHAR;
            }
            type = p.type;
        } else {
            type = qu.ioList[idx].type;
        }
        if ((FL_I & this.trc) != 0)
            Trc.out.println("elment type: " + type);
        return type;
    }

    /**
     * Deliver the index of the element registered in the Cdata.
     *
     * @return     index with respect to the io list or the array
     *             depending on what the element denotes
     */

    public int getElemIdx(){
        int   idx, max;
        Parrs p = null;
        Cdata qu = this.cptr;

        if (qu.ioList == null){               // no list present
            this.res = ERR_EXHAUSTED;
            return 0;
        }
        if (qu.ionest >= 0){                  // in array
            p = qu.astack[qu.ionest];
            idx = p.ix;
            max = p.nr;
            if ((FL_I & this.trc) != 0){
                Trc.out.println("ix: " + p.ix);
            }
        } else {
            idx = qu.ap;
            max = qu.ioElemNr;
            if ((FL_I & this.trc) != 0){
                Trc.out.println("ap: " + qu.ap);
            }
        }
        if ((FL_I & this.trc) != 0){
            Trc.out.println("elemPos: " + qu.elemPos);
        }
        switch (qu.elemPos){
        case 1:
            idx += qu.elemNum;
            if (idx < 0){
                this.res = IOError.ERR_OUTLIMIT;
                return 0;
            }
            break;
        case 2: idx -= qu.elemNum; break;
        case 3: idx = qu.elemNum; break;
        }
        if ((idx < 0) || (idx >= max)){
            this.res = ERR_EXHAUSTED;
            return 0;
        }
        if ((FL_I & this.trc) != 0)
            Trc.out.println("idx: " + idx);
        return idx;
    }

    /**
     * Deliver the index of the element registered in the Cdata and
     * check that it is valid.
     *
     * @return     index with respect to the io list or the array
     *             depending on what the element denotes
     */

    public int getElemIndex(){
        Cdata qu = this.cptr;;
        int   idx = 0;

        if (qu.ionest >= 0){
            idx = getElemIdx();       // check existence of element
            if (this.res != 0) error(this.res);
        } else {
            error(ERR_INDEX);
        }
        return idx;
    }

    /**
     * Parse a number denoting a positional argument and register it
     * in the Cdata.
     */

    private void getArgNum(){
        Cdata   qu = this.cptr;
        char    c;

        c = qu.formt[qu.pfor];
        getkind: {
            if (c == '+'){
                qu.pfor++;
                qu.elemPos = 1;                // relative forward
            } else if (c == '-'){
                qu.pfor++;
                qu.elemPos = 2;                // relative backward
            } else if ((c < '0') || (c > '9')){
                qu.elemPos = 0;                // current
                break getkind;
            } else {
                qu.elemPos = 3;                // absolute
            }
            qu.elemNum = frm_num();            // get number
        }
        if ((FL_I & this.trc) != 0){
             Trc.out.println("getArgNum: " +
                 qu.elemNum + " " + qu.elemPos);
        }
    }

    /**
     * Step to the next argument.
     */

    private void nextArg(){
        Cdata qu = this.cptr;;
        if (qu.elemPos != 0){
            qu.elemNum++;                 // step to next
        }
    }

    /**
     * Deliver the next available value taken from the current array
     * or the io list. Update the pointer, the number of remaining
     * elements, and the repetition factor.
     * Upon return:
     * <ul>
     * <li>repfact = 0 if last element
     * <li>nr      = 0 if last element
     * </ul>
     *
     * @param      t type of the desired value
     */

    public void getval(byte t){
        Cdata   qu = this.cptr;;
        byte    at = 0;
        IoElem  e = null;
        long    integral = 0;
        double  real = 0;
        Object  obj = null;
        Object  arr;
        int     idx;

        if ((FL_I & this.trc) != 0){
             Trc.out.println("getval: t: " + t +
                 " ionest " + qu.ionest);
        }
        idx = getElemIdx();              // check existence of element
        if (this.res != 0) error(this.res);
        try {
            if (qu.ionest >= 0){         // in array
                Parrs p = qu.astack[qu.ionest];
                arr = p.ap;
                at = p.type;
                switch (at){
                case FRM_BOOL:    integral = ((boolean[])arr)[idx] ? 1 : 0;
                                  break;
                case FRM_CHAR:    integral = ((char[])arr)[idx];    break;
                case FRM_BYTE:    integral = ((byte[])arr)[idx];    break;
                case FRM_SHORT:   integral = ((short[])arr)[idx];   break;
                case FRM_INT:     integral = ((int[])arr)[idx];     break;
                case FRM_LONG:    integral = ((long[])arr)[idx];    break;
                case FRM_FLOAT:   real     = ((float[])arr)[idx];   break;
                case FRM_DOUBLE:  real     = ((double[])arr)[idx];  break;
                case FRM_ASTRING: integral = ((String)arr).charAt(idx);
                                  at = FRM_CHAR;
                                  break;
                case FRM_ASTRBUF: integral = ((StringBuffer)arr).charAt(idx);
                                  at = FRM_CHAR;
                                  break;
                default:          obj = ((Object[])arr)[idx];
                                  break;
                }
                if (qu.elemPos == 0){          // non positional
                    p.ix++;
                }
            } else {                           // in io list
                e = qu.ioList[idx];
                at = e.type;
                integral = e.integral;
                real = e.real;
                obj = e.obj;
                if (qu.elemPos == 0){          // non positional
                    qu.ap++;
                    qu.ioElemNonPos++;
                }
                if (e.done == 0) qu.ioElemDone++;
                e.done = 1;
            }
            if (t <= FRM_LONG){
                if (at == FRM_BIGINT){
                    integral = ((BigInteger)(obj)).intValue();
                    at = FRM_LONG;
                }
            }
            if ((FL_I & this.trc) != 0){
                 Trc.out.println("getval: at: " + at);
            }
            switch (t){
            case FRM_BOOL:
                if (at > FRM_LONG) error(ERR_ILLTYPE);
                qu.val_bool = (integral == 1) ? true : false;
                break;
            case FRM_CHAR:
                if (at > FRM_LONG) error(ERR_ILLTYPE);
                qu.val_char = (char)integral;
                break;
            case FRM_BYTE:
                if (at > FRM_LONG) error(ERR_ILLTYPE);
                qu.val_byte = (byte)integral;
                break;
            case FRM_SHORT:
                if (at > FRM_LONG) error(ERR_ILLTYPE);
                qu.val_short = (short)integral;
                break;
            case FRM_INT:
                if (at > FRM_LONG) error(ERR_ILLTYPE);
                qu.val_int = (int)integral;
                break;
            case FRM_LONG:
                if (at > FRM_LONG) error(ERR_ILLTYPE);
                qu.val_long = integral;
                break;
            case FRM_FLOAT:
                switch (at){
                case FRM_FLOAT:
                case FRM_DOUBLE: qu.val_float = (float)real; break;
                case FRM_BIGINT: qu.val_float = ((BigInteger)(obj)).floatValue(); break;
                case FRM_BIGDEC: qu.val_float = ((BigDecimal)(obj)).floatValue(); break;
                default:
                    if (at > FRM_LONG) error(ERR_ILLTYPE);
                    qu.val_float = (float)integral;
                }
                break;
            case FRM_DOUBLE:
                switch (at){
                case FRM_FLOAT:
                case FRM_DOUBLE: qu.val_double = real; break;
                case FRM_BIGINT: qu.val_double = ((BigInteger)(obj)).doubleValue(); break;
                case FRM_BIGDEC: qu.val_double = ((BigDecimal)(obj)).doubleValue(); break;
                default:
                    if (at > FRM_LONG) error(ERR_ILLTYPE);
                    qu.val_double = (double)integral;
                }
                break;
            case FRM_BYTES:
                if (at != FRM_BYTES) error(ERR_ILLTYPE);
                qu.val_obj = (byte[])obj;
                break;
            case FRM_CHARS:
                if (at != FRM_CHARS) error(ERR_ILLTYPE);
                qu.val_obj = (char[])obj;
                break;
            case FRM_STRING:
                if (at != FRM_STRING) error(ERR_ILLTYPE);
                qu.val_obj = (String)obj;
                break;
            case FRM_STRBUF:
                if (at != FRM_STRBUF) error(ERR_ILLTYPE);
                qu.val_obj = (StringBuffer)obj;
                break;
            case FRM_BIGINT:
                if (at != FRM_BIGINT) error(ERR_ILLTYPE);
                qu.val_obj = obj;
                break;
            case FRM_BIGDEC:
                if (at != FRM_BIGDEC) error(ERR_ILLTYPE);
                qu.val_obj = obj;
                break;
            case FRM_DATE:
                if (at != FRM_DATE) error(ERR_ILLTYPE);
                qu.val_obj = obj;
                break;
            default:
                if (at < FRM_BYTES) error(ERR_ILLTYPE);
                qu.val_obj = obj;
                break;
            }  
        } catch (ClassCastException exc){
            error(ERR_ILLTYPE,exc);
        }
        if (qu.ionest >= 0){                   // array
            if ((FL_I & this.trc) != 0){
                Trc.out.println("getval: nr: " +
                    qu.astack[qu.ionest].nr + " ap: " +
                    qu.astack[qu.ionest].ap + " rep: " +
                    this.cptr.repfact);
            }
            qu.sliceStart = 0;
            if (obj != null){
                switch (at){
                case FRM_BYTES:
                    qu.sliceLength = ((byte[])qu.val_obj).length;
                    break;
                case FRM_CHARS:
                    qu.sliceLength = ((char[])qu.val_obj).length;
                    break;
                case FRM_STRING:
                    qu.sliceLength = ((String)qu.val_obj).length();
                    break;
                case FRM_STRBUF:
                    qu.sliceLength = ((StringBuffer)qu.val_obj).length();
                    break;
                case FRM_OBJ:
                    qu.sliceLength = -1;
                    break;
                }
            } else {
                qu.sliceLength = 0;
            }
        } else {                                // top level string
            qu.sliceStart = (int)integral;
            qu.sliceLength = e.length;
            if ((FL_I & this.trc) != 0){
                Trc.out.println("getval: start: " + qu.sliceStart +
                    " length " + qu.sliceLength + " type: " + at);
            }
        }
    }

    /**
     * Deliver a String by taking a (possibly slice of) char[], String,
     * StringBuffer or Object value from the io list.
     */

    protected String valString(){
        Cdata   qu = this.cptr;
        int     start = 0;
        int     len = 0;
        Object  v;
        byte    valtype;
        String  str = null;

        valtype = getElemType();
        switch (valtype){
        case FRM_STRING:
            getval(FRM_STRING);
            start = qu.sliceStart;
            len = qu.sliceLength;
            str = (String)qu.val_obj;
            if (str == null){
                str = "";
            } else if ((start != 0) ||         // slice
                (len != str.length())){
                str = str.substring(start,start+len);
            }
            break;
        case FRM_STRBUF:
            getval(FRM_STRBUF);
            start = qu.sliceStart;
            len = qu.sliceLength;
            StringBuffer sb = (StringBuffer)(qu.val_obj);
            if (qu.val_obj == null){
                str = "";
            } else if ((start != 0) ||         // slice
                (len != sb.length())){
                str = sb.substring(start,start+len);
            }
            break;
        case FRM_BYTES:
            getval(FRM_BYTES);
            start = qu.sliceStart;
            len = qu.sliceLength;
            if (qu.val_obj == null){
                str = "";
            } else {
                str = new String((byte[])(qu.val_obj),start,len);
            }
            break;
        case FRM_CHARS:
            getval(FRM_CHARS);
            start = qu.sliceStart;
            len = qu.sliceLength;
            if (qu.val_obj == null){
                str = "";
            } else {
                str = String.valueOf((char[])(qu.val_obj),start,len);
            }
            break;
        default:
            getval(FRM_OBJ);
            len = qu.sliceLength;
            if (qu.val_obj == null){
                str = "";
            } else {
                str = qu.val_obj.toString();
                len = str.length();
                if (qu.sliceLength >= 0){        // specified
                    if (qu.sliceStart+qu.sliceLength > len){
                        error(ERR_INDEX);
                    }
                    start = qu.sliceStart;
                    len = qu.sliceLength;
                    str = str.substring(start,start+len);
                }
            }
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("valString: " + str);
        }
        return str;
    }

    /**
     * Deliver a char[] by taking a (possibly slice of) char[], String,
     * StringBuffer or Object value from the io list. Return the value
     * in the array referred to by eptr, possibly enlarging it if too small.
     * The actual length is returned in erLength.
     *
     * @param      min minimum size of the array that receives the value
     */

    protected void valChArr(int min){
        Cdata   qu = this.cptr;
        int     start = 0;
        int     len = 0;
        Object  v;
        byte    valtype;
        boolean def = false;
        char[]  arr;

        valtype = getElemType();
        switch (valtype){
        case FRM_STRING:
            getval(FRM_STRING);
            v = qu.val_obj;
            break;
        case FRM_STRBUF:
            getval(FRM_STRBUF);
            v = qu.val_obj;
            break;
        case FRM_BYTES:
            getval(FRM_BYTES);
            v = qu.val_obj;
            break;
        case FRM_CHARS:
            getval(FRM_CHARS);
            v = qu.val_obj;
            break;
        default:
            getval(FRM_OBJ);
            v = qu.val_obj;
            len = 0;
            if (v != null){
                v = v.toString();
                len = ((String)v).length();
            }
            valtype = FRM_STRING;
            if (qu.sliceLength >= 0){        // specified
                if (qu.sliceStart+qu.sliceLength > len){
                    error(ERR_INDEX);
                }
                len = qu.sliceLength;
                start = qu.sliceStart;
            } else {
                start = 0;
            }
            def = true;
        }
        if (v == null){                      // treat null as empty
            v = EMPTY_STR;
            len = 0;
            start = 0;
            valtype = FRM_CHARS;
        } else if (!def){
            start = qu.sliceStart;
            len = qu.sliceLength;
        }
        qu.erLength = len;
        if (len == 0){                       // empty string
            return;
        }
        arr = (char[])qu.eptr;
        if (len >= min) min = len;
        if ((arr == null) ||                 // allocate it
            (arr.length < min)){
            arr = new char[min];             // allocate
            qu.eptr = arr;
        }
        switch (valtype){
        case FRM_STRING:
            ((String)v).getChars(start,start+len,arr,0);
            break;
        case FRM_STRBUF:
            ((StringBuffer)v).getChars(start,start+len,arr,0);
            break;
        case FRM_BYTES:
            int k = 0;
            for (int j = start; j < len+start; j++){
                arr[k++] = (char)(((byte[])v)[j] & 0xff);
            }
            break;
        case FRM_CHARS:
            System.arraycopy(((char[])v),start,arr,0,len);
            break;
        default:
            ((String)v).getChars(start,start+len,arr,0);
        }
    }

    /**
     * Parse an array repetition clause and insert the properties of
     * the array on top of the array stack. Return ERR_EXHAUSTED if
     * no more io list elements are present.
     */

    private void get_arr(){
        Cdata   qu = this.cptr;
        Object  p;
        String  name;
        Class   arrClass = null;
        Parrs   cur;
        int     idx;
        int     i;

        qu.pfor++;                                // skip [
        if (qu.formt[qu.pfor++] != ']'){
            error(ERR_FORMAT);
        }
        getarr: {
            if (qu.formt[qu.pfor] == '$'){        // found
                qu.pfor++;
                getArgNum();
            }
            idx = getElemIdx();                   // check existence of element
            if (this.res != 0) break getarr;
            getval(FRM_OBJ);                      // get address
            qu.elemPos = 0;                       // non positional arg
            p = this.cptr.val_obj;
            i = 0;
            name = null;
            dim: if (p != null){
                arrClass = p.getClass();          // check that it is an array
                if ((arrClass == String.class) ||
                    (arrClass == StringBuffer.class)){
                    i = 1;
                    break dim;
                }
                name = arrClass.getName();
                for (i = 0; i < name.length(); i++){
                    if (name.charAt(i) != '[') break;
                }
                if (i == 0) error(ERR_ILLTYPE);
            }
            if ((FL_I & this.trc) != 0){
                Trc.out.println("get_arr " + name +
                    " nr. of dimensions: " + i +
                    " ionest: " + qu.ionest);
            }
            if ((qu.astack == null) ||
                (qu.astack.length < i)){
                qu.astack = new Parrs[i];
            }
            qu.ionest++;                         // push address, etc.
            if (qu.ionest < 0){
                error(IOError.ERR_OUTLIMIT);
            }
            if (qu.astack[qu.ionest] == null){
                qu.astack[qu.ionest] = new Parrs();
            }
            cur = qu.astack[qu.ionest];
            cur.ap = p;
            if (p == null){
                cur.nr = 0;                      // null-pointed array
                cur.ix = 0;
            } else {
                int siz;
                cur.ix = 0;
                if (arrClass == String.class){
                    cur.nr = ((String)p).length();
                } else if (arrClass == StringBuffer.class){
                    cur.nr = ((StringBuffer)p).length();
                } else {
                    cur.nr = Array.getLength(p);
                }
                siz = cur.nr;
                if (qu.ionest == 0){             // top level array
                    cur.nr = (int)qu.ioList[idx].length;
                    cur.ix = (int)qu.ioList[idx].integral;
                }
                if ((cur.ix < 0) || (cur.nr < 0) ||
                    (cur.ix+cur.nr > siz)) error(ERR_INDEX);
                if (cur.ix+cur.nr < 0){
                    error(IOError.ERR_OUTLIMIT);
                }
                if (arrClass == String.class){
                    cur.type = FRM_ASTRING;
                } else if (arrClass == StringBuffer.class){
                    cur.type = FRM_ASTRBUF;
                } else {
                    switch (name.charAt(1)){
                    case 'Z': cur.type = FRM_BOOL;   break;
                    case 'B': cur.type = FRM_BYTE;   break;
                    case 'C': cur.type = FRM_CHAR;   break;
                    case 'S': cur.type = FRM_SHORT;  break;
                    case 'I': cur.type = FRM_INT;    break;
                    case 'J': cur.type = FRM_LONG;   break;
                    case 'F': cur.type = FRM_FLOAT;  break;
                    case 'D': cur.type = FRM_DOUBLE; break;
                    default:
                        Class elemClass = arrClass.getComponentType();
                        if (elemClass == String.class){
                            cur.type = FRM_STRING;
                        } else if (elemClass == StringBuffer.class){
                            cur.type = FRM_STRBUF;
                        } else if (elemClass == byte[].class){
                            cur.type = FRM_BYTES;
                        } else if (elemClass == char[].class){
                            cur.type = FRM_CHARS;
                        } else if (elemClass == BigInteger.class){
                            cur.type = FRM_BIGINT;
                        } else if (elemClass == BigDecimal.class){
                            cur.type = FRM_BIGDEC;
                        } else {
                            cur.type = FRM_OBJ;
                        }
                    }
                }
            }
            if ((FL_I & this.trc) != 0){
                Trc.out.println("array pointers stack:");
                for (i = 0; i <= qu.ionest; i++){
                    Trc.out.println("  " + i +
                    " ap: " + qu.astack[i].ap +
                    " nr: " + qu.astack[i].nr +
                    " ix: " + qu.astack[i].ix +
                    " type: " + qu.astack[i].type);
                }
            }
        }
    }

    /**
     * Register a format string in the object.
     *
     * @param      f format
     */

    public Formatter f(String f){
        int   len = 0;
        int   flen = 0;
        Cdata qu;

        if ((FL_A & this.trc) != 0){
            Trc.out.println("write-f: " + f);
        }
        if (this == ERR_OBJ) return ERR_OBJ;
        excInit();
        doit: try {
            qu = ensure_cdata();
            if (qu.formt != null){
                len = qu.formt.length - 1;
            }
            if (f != null) flen = f.length();
            if ((len < flen) || (qu.formt == null)){  // not enough space
                if (flen+1 < 0){
                    registerError(IOError.ERR_OUTLIMIT);
                    break doit;
                }
                qu.formt = new char[flen+1];          // new array
                if ((FL_M & this.trc) != 0)
                    Trc.out.println("format allocated: " +
                        String.valueOf(qu.formt,0,qu.forLength));
            }
            if (flen > 0) f.getChars(0,flen,qu.formt,0);
            qu.forLength = flen;
            qu.formt[qu.forLength] = '\0';
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        }
        excTerm();
        if ((FL_A & this.trc) != 0)
            Trc.out.println("write-f done");
        if (this.res != 0) return ERR_OBJ;
        return this;
    }

    /**
     * Register a localised format string in the object.
     *
     * @param      s key of the format string as stored in the current
     *             resource bundle
     */

    public Formatter l(String s){
        String str;

        if ((FL_A & this.trc) != 0){
            Trc.out.println("write-l: " + s);
        }
        if (this == ERR_OBJ) return ERR_OBJ;
        excInit();
        try {
            str = getLizedStr(s);
            f(str);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (FormatterError exc){
        }
        excTerm();
        if ((FL_A & this.trc) != 0){
            Trc.out.println("write-f done");
        }
        if (this.res != 0) return ERR_OBJ;
        return this;
    }

    /**
     * Format values and text as <code>write()</code> and then flush.
     */

    public void writeln(){
        write(null,true,true);
    }

    /**
     * Perform the same action as a <code>write()</code> with the same
     * arguments, but do not empty the io list.
     */

    public void rewriteln(){
        write(null,true,false);
    }

    /**
     * Format values and text as <code>write(f)</code> and then flush.
     */

    public void writeln(String frm){
        write(frm,true,true);
    }

    /**
     * Perform the same action as a <code>write()</code> with the same
     * arguments, but do not empty the io list.
     */

    public void rewriteln(String frm){
        write(frm,true,false);
    }

    /**
     * Format values and text as <code>write(f,l)</code> and then flush.
     */

    public void writeln(String f, Formatter l){
        write(f,true,true);     // N.B. l defined to allow to write an argument
    }

    /**
     * Perform the same action as a <code>write()</code> with the same
     * arguments, but do not empty the io list.
     */

    public void rewriteln(String f, Formatter l){
        write(f,true,false);     // N.B. l defined to allow to write an argument
    }

    /**
     * Format values and text. Apply the conversion, editing and io
     * functions contained in the format argument to the output stream to
     * which it is applied.
     * It is equivalent to a <code>write</code> with no format and no io list.
     */

    public void write(){
        write(null,false,true);
    }

    /**
     * Perform the same action as a <code>write()</code> with the same
     * arguments, but do not empty the io list.
     */

    public void rewrite(){
        write(null,false,false);
    }

    /**
     * Format values and text. Apply the conversion, editing and io
     * functions contained in the format argument to the values passed as
     * argument and to the output stream to which it is applied.
     * It is equivalent to a <code>write</code> with no io list.
     *
     * @param      f format
     * @param      l io list
     */

    public void write(String f, Formatter l){
        write(f,false,true);     // N.B. l defined to allow to write an argument
    }

    /**
     * Perform the same action as a <code>write()</code> with the same
     * arguments, but do not empty the io list.
     */

    public void rewrite(String f, Formatter l){
        write(f,false,false);     // N.B. l defined to allow to write an argument
    }

    /**
     * Format values and text. Apply the conversion, editing and io
     * functions contained in the format argument, possibly converting the
     * values of the remaining arguments, to the output stream to which it
     * is applied.
     * If the stream contains a file reference, then the output is directed
     * to that file, otherwise (the file reference is null) the output is
     * performed to the string referenced by it.
     * The operation stops when the scanning of the format argument ends.
     *
     * @param      f format
     */

    public void write(String frm){
        write(frm,false,true);
    }

    /**
     * Perform the same action as a <code>write()</code> with the same
     * arguments, but it do not empty the io list.
     */

    public void rewrite(String frm){
        write(frm,false,false);
    }

    /** Default text record length for default initialization. */
    private static int DEFLT_LENGTH = 80;

    /**
     * Format. The actual internal method that formats.
     *
     * @param      f format
     * @param      flush true if writeln
     * @param      clear true if the io list has to be emptied
     */

    private void write(String frm, boolean flush, boolean clear){
        Cdata  qu = null;
        int    trc = this.trc;                    // saved
        int    savIoElemNr = 0;

        if (this == ERR_OBJ) return;
        excInit();
        try {
            if ((FL_A & this.trc) != 0){
                Trc.out.println("write format: " + frm);
            }
            if ((FL_I & this.trc) != 0){
                ioListTrace();
            }
            if ((FL_A & this.trc) != 0){
                Trc.out.println("cbk pres: " +
                    Integer.toOctalString(this.cbkpres));
            }

            qu = ensure_cdata();
            if (frm != null) f(frm);              // register format
            if (((FL_A|FL_N) & this.trc) != 0){
                Trc.out.println("write actual format: " +
                    String.valueOf(qu.formt,0,qu.forLength) +
                    " io list elements: " + qu.ioElemNr);
            }
            qu.pfor = 0;
            qu.pspec = qu.pfor;
            qu.nest = 0;
            qu.ap = 0;
            qu.ionest = -1;
            qu.ioElemDone = 0;
            qu.ioElemNonPos = 0;
            savIoElemNr = qu.ioElemNr;

            if ((qu.formt[qu.pfor] == '%') &&
                (qu.formt[qu.pfor+1] == 'm')){    // mode, to enable trace
                qu.pfor++;
                call_cbk('m',1,null,true);
            }
            if ((FL_A & this.trc) != 0){
                if (this.nestcall > 0)            // trace nesting
                    Trc.out.println("write: nestcall " +
                        this.nestcall);
            }
            if ((qu.formt[qu.pfor] == '%') &&
                (qu.formt[qu.pfor+1] == 'a')){    // initialization
                qu.pfor++;
                call_cbk('a',1,null,true);        // initialize
            }
            if (this.buffer == null){             // not initialised
                initialize(new char[DEFLT_LENGTH],
                    DEFLT_LENGTH,null,false,false);
                this.grow = true;
            }
            if (((FL_A|FL_B) & this.trc) != 0){
                Trc.out.println("write: format ");
                Trc.literalize(qu.formt,qu.forLength);
                Trc.out.println();
            }
            if ((this.cbkpres & ENTRYCBK) != 0){   // present
                call_cbk('1',1,ENTRYFRM,true);     // entry callback
            }
            int done;
            do {
                done = qu.ioElemNonPos;
                scan_format(null,false,false);          // interpret format
                if (qu.ioElemDone == qu.ioElemNr) break;
                if (done == qu.ioElemNonPos) break;     // no progress
                if (this.match != 2) break;
                if ((FL_I & this.trc) != 0){
                    Trc.out.println("write: autorepeat " +
                        done + " " + qu.ioElemNonPos);
                }
                qu.pfor = 0;
                qu.pspec = qu.pfor;
            } while (true);
            if ((FL_I & this.trc) != 0){
                ioListTrace();
            }
            if ((this.match != 1) && (qu.ioElemDone != qu.ioElemNr)){
                registerError(ERR_MISMATCH);
                for (int k = 0; k < qu.ioElemNr; k++){
                    if (qu.ioList[k].done == 0){
                        this.excObj.value = k;
                        break;
                    }
                }
                throw this.excObj;
            }
            if ((FL_A & this.trc) != 0){
                Trc.out.println("write: end scan");
            }
            if (flush) flush_rec(false);
            if ((this.cbkpres & EXITCBK) != 0){    // present
                if (this.buffer != null){          // skip after %z
                    call_cbk('2',1,EXITFRM,true);  // exit callback
                }
            }
        } catch (OutOfMemoryError exc){            // for the implicit new's
            registerError(IOError.ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (FormatterError exc){
        } finally {
            if ((this.res != 0) && (this.buffer != null)){
                int res = this.res;
                this.res = 0;                      // allow flush_rec to work
                try {
                     flush_rec(true);              // emit incomplete record
                } catch (Throwable exc){
                }
                this.res = res;
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("write: returning: " +
                    message(this.res) + " max: " + this.max +
                    " cur: " + this.cursor);
                if (this.res != 0){
                    Trc.out.println("at: " + qu.pfor);
                }
            }

            if (qu != null){
                if (clear){
                    qu.ioElemNr = 0;               // empty the io list
                } else {
                    qu.ioElemNr = savIoElemNr;     // restore the io list
                    for (int i = 0; i < qu.ioElemNr; i++){
                        IoElem e = qu.ioList[i];
                        e.done = 0;
                    }
                }
            }
            if (qu.cptr != null) this.cptr = qu.cptr;
            if ((FL_N & this.trc) != 0){
                Trc.out.println("write: unnesting lev: " +
                    this.cptr.nestlev);
            }
            this.trc = trc;                        // restore
            excTerm();
        }
    }

    /**
     * Ensure that a Cdata is available for the current level of
     * nesting of write() call. If it is not, allocate a new one.
     */

    private Cdata ensure_cdata(){
        if ((FL_N & this.trc) != 0){
            Trc.out.println("write nestcall: "
                + this.nestcall +
                " nestlev: " + ((this.cptr == null)? 0
                    : this.cptr.nestlev));
        }
        if ((this.cptr == null) ||            // no Cdata available
            ((this.nestcall != this.cptr.nestlev) &&
            (this.cptr.fcptr == null))){
            Cdata cdata = new Cdata();
            cdata.cptr = this.cptr;           // keep it for %mr
            if (this.cptr != null){
                this.cptr.fcptr = cdata;      // link forward
            }
            this.cptr = cdata;
            cdata.extRep = new char[REP_MIN]; // preallocate extRep
            cdata.erLength = REP_MIN;
            if (((FL_M|FL_N) & this.trc) != 0){
                Trc.out.println("cdata allocated");
            }
        } else {
            if ((this.nestcall != this.cptr.nestlev))
            this.cptr = this.cptr.fcptr;      // next becomes current
            if ((FL_N & this.trc) != 0){
                Trc.out.println("cdata advanced");
            }
        }
        this.cptr.nestlev = this.nestcall;
        return this.cptr;
    }

    /**
     * Ensure that an array for the external representation be available.
     */

    void ensure_extRep(int l1, int l2){
        Cdata qu = this.cptr;
        int newlen = (l1 > l2) ? l1 : l2;        // greatest of l1, l2
        if ((qu.extRep == null) ||               // not enough
            (qu.extRep.length < newlen)){
            qu.extRep = new char[newlen];        // allocate it
            if ((FL_M & this.trc) != 0){
                Trc.out.println("extrep allocated: " + newlen);
            }
        }
        qu.erLength = qu.extRep.length;
    }

    /* Callbacks calling */

    /**
     * The interface for all classes which provides the Formatter interface,
     */

    public static interface Api {
        public void format(Formatter p);
    }

    /** The internal format clause of the output callback. */
    private static final char[] OUTFRM   = {'%','0',0};

    /** The internal format clause of the entry callback. */
    private static final char[] ENTRYFRM = {'%','1',0};

    /** The internal format clause of the exit callback. */
    private static final char[] EXITFRM  = {'%','2',0};

    /** The internal format clause of the insert callback. */
    private static final char[] INSFRM   = {'%','3',0};

    /** The internal format clause of the heading callback. */
    private static final char[] HEADFRM  = {'%','4',0};

    /** The internal format clause of the page callback. */
    private static final char[] PAGEFRM  = {'%','6',0};

    /**
     * Dispatch. It is the default dispatcher, which returns an error.
     * It is meant to be redefined in subclasses.
     *
     * @param      code character code
     */

    protected void dispatch_cbk(char code){
        this.res = ERR_ILLCODE;
    }

    /* The default callbacks. */

    protected void entry_cbk(){}
    protected void exit_cbk(){}
    protected void ins_cbk(){}
    protected void head_cbk(){}
    protected void page_cbk(){}
    protected void g_cbk(){this.res = ERR_ILLCODE;}
    protected void l_cbk(){this.res = ERR_ILLCODE;}
    protected void k_cbk(){this.res = ERR_ILLCODE;}
    protected void n_cbk(){this.res = ERR_ILLCODE;}
    protected void o_cbk(){this.res = ERR_ILLCODE;}
    protected void q_cbk(){this.res = ERR_ILLCODE;}
    protected void r_cbk(){this.res = ERR_ILLCODE;}
    protected void v_cbk(){this.res = ERR_ILLCODE;}
    protected void w_cbk(){this.res = ERR_ILLCODE;}
    protected void y_cbk(){this.res = ERR_ILLCODE;}

    /**
     * Call a callback. If the callback is internal, i.e. not related
     * to a code present in the format, a temporary format is created, and
     * the repetition factor in the cdata kept unchanged.
     *
     * @param      code character code
     * @param      rep repetition factor to be passed
     * @param      frm format if internal callback
     * @param      trc true if tracing can be done
     */

    private void call_cbk(char code, int  rep, char[] frm,
        boolean trc){
        int     pfsav = 0;
        int     pfini = 0;
        char[]  formsav = null;
        char[]  formini = null;
        int     savrep = 0;
        int     savlen = 0;
        Cdata   qu = this.cptr;

        if (frm != null){                    // internal call
            pfsav = qu.pfor;
            formsav = qu.formt;
            savlen = qu.forLength;
            qu.formt = frm;
            qu.pspec = 0;
            qu.pfor = 1;
            savrep = qu.repfact;             // save it: cbk's may change it
        }
        pfini = qu.pfor;
        formini = qu.formt;
        if ((FL_D & this.trc) != 0){
            Trc.out.println("call_cbk: " + code +
                " (0x" + Integer.toHexString(code) +
                ") at: " + qu.pfor);
        }
        endfor: {
            if ((code < ' ') || (code > '~')){
                this.res = ERR_ILLCODE;          // unknown/missing code
                break endfor;
            }
            if ((code != 'a') && (code != 'm')){
                if (this.closed){
                    this.res = ERR_INIT;         // object not initialised
                    break endfor;
                }
            }
            if (trc && ((FL_B & this.trc) != 0)){
                Trc.out.println("doing: ");
                if ((code >= '0') && (code <= '6')){
                    Trc.out.println(CBKNAM[code-'0']);
                } else {
                    int pf = skip_format(
                        ((code=='5') ? F_TXT : F_CODE),0,-1);
                    char[] str = new char[pf-qu.pspec];
                    System.arraycopy(qu.formt,qu.pspec,
                        str,0,pf-qu.pspec);
                    Trc.literalize(str);
                    Trc.out.println();
                }
            }
            qu.repfact = rep;
            qu.elemPos = 0;
            qu.endQuals = 0;
            try {
                if (code == 'a') this.nestcall = 0;  // current call not nested
                this.nestcall++;                     // for write() called in it
                if (this.nestcall < 0){
                    error(IOError.ERR_OUTLIMIT);
                }
                if (((FL_L|FL_N) & this.trc) != 0){
                    trcpoint("calling callback",rep);
                    Trc.out.println("nestcall: " + this.nestcall);
                }

                switch (code){
                case '/': io_cbk();    break;
                case '0': out_cbk();   break;
                case '1': entry_cbk(); break;
                case '2': exit_cbk();  break;
                case '3': ins_cbk();   break;
                case '4': head_cbk();  break;
                case '5': text_cbk();  break;
                case '6': page_cbk();  break;
                case '@': pend_cbk();  break;
                case 'a': init_cbk();  break;
                case 'b': bool_cbk();  break;
                case 'c': str_cbk();   break;
                case 'd': date_cbk();  break;
                case 'e': edit_cbk();  break;
                case 'f': float_cbk(); break;
                case 'i': int_cbk();   break;                
                case 'j': int_cbk();   break;
                case 'm': mode_cbk();  break;
                case 'p': ptr_cbk();   break;
                case 's': str_cbk();   break;
                case 't': skip_cbk();  break;
                case 'u': int_cbk();   break;
                case 'x': blank_cbk(); break;
                case 'z': term_cbk();  break;

                case 'g': g_cbk();  break;
                case 'l': l_cbk();  break;
                case 'k': k_cbk();  break;
                case 'n': n_cbk();  break;
                case 'o': o_cbk();  break;
                case 'q': q_cbk();  break;
                case 'r': r_cbk();  break;
                case 'v': v_cbk();  break;
                case 'w': w_cbk();  break;
                case 'y': y_cbk();  break;

                default:
                    dispatch_cbk(code);
                    if (this.res != 0){
                        qu.pfor++;
                        break endfor;
                    }
                }
            } catch (FormatterError exc){
            } finally {
                this.nestcall--;
                if ((FL_N & this.trc) != 0){
                    Trc.out.println("returning nestcall: "
                       + this.nestcall);
                }
                if ((FL_D & this.trc) != 0){
                    Trc.out.println("pfor " + qu.pfor +
                       " 0x" + Integer.toHexString(qu.formt[qu.pfor]) +
                       " repfact " + qu.repfact + " " + this.res);
                }
                if (frm != null){            // internal call: restore format ..
                    qu.pfor = pfsav;         // .. also in the case of error ..
                    qu.formt = formsav;      // .. to make registerError work
                    qu.forLength = savlen;
                    qu.repfact = savrep;
                }
            }
            if ((this.res != 0) && (this.res != ERR_EXHAUSTED)){
                break endfor;
            }
            if (code == '5'){                // text_cbk can also return with
                break endfor;                // .. pfor at beginning of clause
            }
            if (frm != null) break endfor;   // internal call, no check
            if (qu.pfor == pfini) qu.pfor++; // it forgot to step ove
            if ((qu.pfor == pfini+1) &&
                ((formini[pfini] == '\n') ||
                (formini[pfini] == '\f'))){
                break endfor;
            }
            if ((FL_D & this.trc) != 0){
                Trc.out.println("pfor " + qu.pfor + " " + qu.formt[qu.pfor] +
                    " [-1] " + qu.formt[qu.pfor-1]);
            }
            switch(qu.formt[qu.pfor]){
            case ';':                                // possibly terminating ;
                if (qu.formt[qu.pfor-1] == '`'){
                    this.res = ERR_ILLCODE;
                    break endfor;
                }
                qu.pfor++;
                break endfor;
            case '%': case ',': case ' ':            // other terminating chars
                if (qu.formt[qu.pfor-1] == '`'){
                    this.res = ERR_ILLCODE;
                }
                break endfor;
            default:
                if (qu.pfor == qu.forLength){
                    break endfor;
                }
                if (qu.formt[qu.pfor-1] == ')'){     // callbacks that take
                    if (qu.pfor - pfini < 2){        // .. a ( %
                        this.res = ERR_ILLCODE;
                        break endfor;
                    }
                    if (qu.formt[qu.pfor-2] != '%'){
                        this.res = ERR_ILLCODE;
                    }
                    break endfor;
                }
            }
            this.res = ERR_ILLCODE;
        } // endfor
        if ((FL_L & this.trc) != 0){
            trcpoint("return from callback",qu.repfact);
        }
        if ((FL_R & this.trc) != 0){
            trcrec();
        }
        if (frm != null){                  // internal call: restore format
            qu.pfor = pfsav;
            qu.formt = formsav;
            qu.forLength = savlen;
            qu.repfact = savrep;
        }
        if (this.res != 0){
            error(this.res);
        }
    }


    /* Format parsing and processing */

    /**
     * Scan the format and process its contents. When a parens-clause is
     * found it calls itself recursively.
     *
     * @param      inArr reference to the array descriptor, if
     *             processing an array
     * @param      repUnd <code>true</code> if the repetition factor
     *             is undefined
     * @param      <code>true</code> if inside a parens-clause with an
     *             unlimited repetition factor
     */

    /*
     * When a parens clause is encountered, scan_format calls itself
     * recursively. The nested execution processes also the terminating
     * %) so that when back in the calling one, if the repetition is
     * terminated, the processing of the parens clause is also completed
     * and the next clause can be analysed. I.e. although the opening
     * %( is processed by the caller, the closing %) is processed by the
     * callee. The nested scan_format must end when a %) is encountered,
     * which means that it must detect it in its main loop. Thus, there is
     * no need to detect it again in the calling one. Well, the nested one
     * could just not detect it and proceed until it finds a clause it does
     * not know.  The calling one would then match the %) and proceed.
     * The difficulty for the nested one is to detect that it cannot proceed
     * because it would have to catch an error_nocode. It would be simpler to
     * test the %).  The nested one can return when it encounters a %) without
     * advancing. The caller can then match it. This relieves from the need
     * to keep a nesting level, but makes write() need to test that the
     * format has been completed, and not that it has stopped at an unmatched
     * %). The nesting level is needed anyway or something similar because
     * a scan_format must know that it is inside a parens clause which has
     * an array in front of it. It is needed also to detect extra %) and
     * not closed %(.
     * <p>
     * There is a need to distinguish the ERR_EXHAUSTED which occurred
     * in getting the array in %[] from that occurring inside a clause
     * because the former skips to the end of the enclosing parens clause,
     * if any, while the latter skips the clause alone. Since the skip to be
     * done depends on the context, and that is known only to the single
     * execution of scan_format, then it is better be done inside it and not
     * where scan_format gets back to the caller.
     * Note also that to distinguish a %[]c from a %[](, a pointer to the
     * descriptor of the array in front of the current clause is kept, which
     * is not null in the first case, while it is null when processing the
     * clauses nested in the parens clause because they do not have a []
     * directly in front of them.
     */

    private void scan_format(Parrs inArr, boolean repUnd, boolean once){
        Cdata    qu = this.cptr;
        int      startf, stspec;
        char     code, cod;
        int      i;
        int      rep_fact, nr;
        int      apt = 0;
        char     c, c1;
        boolean  stop = false;
        Parrs    arr = null;
        boolean  repUndef;

        if ((FL_L & this.trc) != 0){
            Trc.out.println("scan: nest: " + qu.nest);
        }
        loop: while (qu.pfor < qu.forLength){       // scan the format
            c = qu.formt[qu.pfor];
            if ((FL_L & this.trc) != 0){
                Trc.out.println("scan loop " + qu.pfor);
            }
            stspec = qu.pspec = qu.pfor;            // remember start format
            if ((c != '\n') && (c != '\f')){        // not \n, \f clauses
                if ((c != '%') ||
                    (qu.formt[qu.pfor+1] == '%')){  // format-text
                    call_cbk('5',1,null,true);      // call text callback
                    if (once) break loop;
                    continue;
                }
                qu.pfor++;                          // skip %
                if (qu.formt[qu.pfor] == ')'){      // treat nesting
                    if (qu.nest == 0){              // unmatched close par.
                        error(ERR_NOOPN);
                    } else {
                        if ((FL_B & this.trc) != 0)
                            Trc.out.println("doing: %)");
                        qu.pfor++;                  // skip close par.
                        stop = true;
                        break loop;                 // terminate current level
                    }
                } else if (qu.formt[qu.pfor] == '?'){    // conditional
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("doing: %?");
                    }
                    qu.pfor++;
                    getval(FRM_BOOL);
                    boolean cond = qu.val_bool;
                    if (cond){
                        scan_format(inArr,repUnd,true);  // interpret spec
                    } else {
                        qu.pfor = skip_format(F_CLAUSE,0,-1);
                    }
                    if (qu.formt[qu.pfor] == '%'){
                        if (qu.formt[qu.pfor+1] == ':'){
                            qu.pfor += 2;;
                            if ((FL_B & this.trc) != 0){
                                Trc.out.println("doing: %:");
                            }
                            if (!cond){                  // interpret spec
                                scan_format(inArr,repUnd,true);
                            } else {
                                qu.pfor = skip_format(F_CLAUSE,0,-1);
                            }
                        }
                    }
                    if (once) break loop;
                    continue;
                }
            }
            arr = null;
            repUndef = false;
            done: {
                rep_fact = frm_param(-1,false);     // get repetition
                if (rep_fact < 0){                  // not specified
                    rep_fact = 1;
                    if (qu.formt[qu.pfor] == '['){  // array rep factor
                        get_arr();
                        if (this.res == 0){
                            arr = qu.astack[qu.ionest]; // remember there is one
                            rep_fact = arr.nr;          // there is a prev %[]
                            inArr = arr;
                        }
                    } else if (qu.formt[qu.pfor] == '#'){
                        qu.pfor++;
                        if (qu.ionest < 0){             // top level
                            rep_fact = qu.ioElemNr - qu.ap;
                        } else {
                            rep_fact = qu.astack[qu.ionest].nr -
                                qu.astack[qu.ionest].ix;
                        }
                        repUnd = true;
                        repUndef = true;
                    }
                }
                if ((this.res == ERR_EXHAUSTED) &&      // missing array
                    ((inArr != null) || repUnd)){
                    qu.pfor = skip_format(F_CODE,1,-1);
                    if ((FL_L & this.trc) != 0){
                        Trc.out.println("%[] done ionest " +
                            qu.ionest + " skipped: " +
                            String.valueOf(qu.formt,qu.pspec,
                            qu.pfor-qu.pspec));
                    }
                    this.res = -1;
                    stop = true;
                    break loop;
                } else if (this.res != 0){
                    error(this.res);
                }
                if (rep_fact == 0){                 // skip over format
                    qu.pfor = skip_format(F_CODE,0,-1);
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("rep 0 skipped: " +
                           String.valueOf(qu.formt,qu.pspec,
                           qu.pfor-qu.pspec));
                    }
                    break done;
                }
                code = qu.formt[qu.pfor];
                if ((FL_L & this.trc) != 0){
                    Trc.out.println("scan: code " + code +
                        " rep_fact: " + rep_fact);
                }
                startf = qu.pfor;                         // save index of
                endspec: do {                             // .. start of code
                    qu.pfor = startf;                     // restart index
                    if ((FL_L & this.trc) != 0){          // .. to format
                        Trc.out.println("scan: rep loop: " + qu.pfor);
                    }
                    qu.pspec = stspec;
                    if (code == '('){                     // parens-clause
                        qu.pfor++;                        // skip open par.
                        scan: {
                            c = qu.formt[qu.pfor];
                            if ((c == '\n') ||
                                (c == '\f')) break scan;  // \n or \f codes
                            c1 = '\0';
                            if (qu.pfor < qu.forLength){
                                c1 = qu.formt[qu.pfor+1];
                            }
                            if ((c != '%') || (c1 == '%')){        // format-text
                                call_cbk('5',-rep_fact,null,true); // text cbk
                                if (this.cptr.repfact <= 0){       // text only
                                    break done;
                                }
                                if ((FL_B & this.trc) != 0){
                                    Trc.out.println("no text only");
                                }
                            }
                            if ((FL_B & this.trc) != 0){
                                Trc.out.println("doing: " +
                                    String.valueOf(qu.formt,qu.pspec,
                                    qu.pfor-qu.pspec));
                            }
                        }
                        if (arr != null) apt = arr.ix;    // store ptr to elem
                        qu.nest++;
                        scan_format(inArr,repUnd,false);  // interpret spec
                        if ((FL_L & this.trc) != 0){
                            Trc.out.println("scan back in scan: rep: " +
                               rep_fact + " res: " + this.res);
                        }
                        qu.nest--;
                        if (this.res == -1){              // [] aborted
                            this.res = 0;
                            break endspec;
                        }
                        if (inArr != null){               // inside array
                            if (inArr.ix >= inArr.nr){    // none available
                                break endspec;
                            }
                        }
                        if (repUnd){                      // undef rep fact
                            if (qu.ionest < 0){           // top level
                                if (qu.ap >= qu.ioElemNr)
                                break endspec;
                            } else {
                                if (qu.astack[qu.ionest].ix >=
                                    qu.astack[qu.ionest].nr){
                                    break endspec;
                                }
                            }
                        }
                        continue;
                    }
                    cod = code;
                    if ((code == '\n') ||
                        (code == '\f')) cod = '/';        // call io_cbk
                    try {
                        call_cbk(cod,rep_fact,null,true); // call callback
                        if ((FL_L & this.trc) != 0){
                            Trc.out.println("scan after cbk " +
                                this.res + " arr: " + arr +
                                " pfor: " + qu.pfor);
                        }
                    } catch (FormatterError exc){
                        if ((this.res == ERR_EXHAUSTED) &&
                            (inArr != null)){
                            int nest;
                            if (arr != null) nest = 0;    // %[]c
                            else nest = 1;                // %[](..%c..%[]..%)
                            qu.pfor = qu.pspec + 1;       // past %
                            qu.pfor = skip_format(F_CODE,nest,-1);
                            if ((FL_L & this.trc) != 0){
                                Trc.out.println("clause done ionest " +
                                    qu.ionest + " skipped: " +
                                    String.valueOf(qu.formt,qu.pspec,
                                    qu.pfor-qu.pspec));
                            }
                            if (arr == null){
                                this.res = -1;
                                stop = true;
                                break loop;
                            } else {                      // %[]c
                                this.res = 0;
                            }
                        } else if ((this.res == ERR_EXHAUSTED) && repUnd){
                            int nest;
                            if (repUndef) nest = 0;       // %#c
                            else nest = 1;                // %#(..%c..%#..%)
                            qu.pfor = qu.pspec + 1;       // past %
                            qu.pfor = skip_format(F_CODE,nest,-1);
                            if (!repUndef){
                                this.res = -1;
                                stop = true;
                                break loop;
                            } else {                      // %#c
                                this.res = 0;
                            }
                        } else {
                            error(this.res);
                        }
                    }
                    if (qu.repfact <= 0){                 // repet. completed
                        break endspec;
                    }
                } while (--rep_fact > 0);                 // real execution
                if ((FL_L & this.trc) != 0){
                    Trc.out.println("endspec " + qu.pfor);
                }
            }  /* done */
            if (arr != null){                             // there is a [] rep.
                qu.ionest--;
                if (qu.ionest < 0) inArr = null;          // end of it
                if ((FL_L & this.trc) != 0){
                    Trc.out.println("arr denesting " + arr +
                        " " + qu.ionest);
                }
            }
            if ((FL_L & this.trc) != 0){
                Trc.out.println("end iteration " + once +
                    " " + qu.pfor);
            }
            if (once) break loop;
        } /* loop */
        if (!stop){
            if (qu.formt[qu.pfor] == '\0'){           // format ended
                if (qu.nest > 0) error(ERR_NOCLO);    // open par. not closed
            }
        }
        if ((FL_L & this.trc) != 0)
            Trc.out.println("scan: un-nest: " + this.res);
    }


    /**
     * Find the end of a clause, and optionally return it.
     * The returned string has the escape sequences reduced.
     * The state indicates where the current pointer into the format
     * is pointing to:
     * <table>
     * <tr><td>F_CLAUSE: </td><td>at a format clause,</tr>
     * <tr><td>F_CODE:   </td><td>in the repetition factor or in the code,</tr>
     * <tr><td>F_SPEC:   </td><td>in the qualifiers,</tr>
     * <tr><td>F_SPECP:  </td><td>in the qualifiers of a pending clause,</tr>
     * <tr><td>F_TXT:    </td><td>in a format-text.</tr>
     * </table>
     *
     * @param      state see above
     * @param      nest nesting level at which to stop
     * @param      off >= 0 if the skipped string is to be returned.
     *             It is returned in eptr of the Cdata starting at off.
     *             erLength is the index past the last character.
     *             < 0 if not wanted.
     * @return     index of the last skipped character + 1.
     */

    public int skip_format(int state, int nest, int off){
        Cdata   qu = this.cptr;
        int     pfor = 0;
        int     tf = 0;
        int     tfe = 0;
        char    ch;
        char[]  str = null;
        boolean store = off >= 0;

        tf = off;
        if (!store){                       // set tf = index to start of str
            tfe = tf;                      // .. and tfe = index to end
        } else {
            str = (char[])this.cptr.eptr;
            tfe = str.length;
        }
        if ((FL_D & this.trc) != 0){
            Trc.out.println("start skip at: " +
                qu.pfor + " " + qu.formt[qu.pfor] +
                " nest: " + nest);
        }
        pfor = qu.pfor;
        scan: while (pfor < qu.forLength){
            ch = qu.formt[pfor];
            if ((FL_E & this.trc) != 0){
                Trc.out.println("state: " + F_NAME[state] +
                    " char: " + ch + " nest: " + nest +
                    " str: " + str);
            }
            tran: switch (state){
            case F_CLAUSE:                         // start of clause
                if (ch == '%'){                    // not format-text
                    if (store){
                        if (tf == tfe){
                            str = extend();
                            tfe = str.length;
                        }
                        str[tf++] = ch;
                    }
                    pfor++;
                    state = F_CODE;
                } else {
                    state = F_TXT;
                }
                break;
            case F_CODE:                           // code, repetition
                if (ch == '*'){                    // skip repetition factor
                    if (store){
                        if (tf == tfe){
                            str = extend();
                            tfe = str.length;
                        }
                        str[tf++] = ch;
                    }
                    pfor++;
                } else if (ch == '['){             // array
                    do {
                        if (store){
                            if (tf == tfe){
                                str = extend();
                                tfe = str.length;
                            }
                            str[tf++] = ch;
                        }
                        if (ch == ']') break;
                        ch = qu.formt[++pfor];
                    } while (true);
                    pfor++;
                } else {
                    while ((ch >= '0') &&          // numeric
                        (ch <= '9')){
                        if (store){
                            if (tf == tfe){
                                str = extend();
                                tfe = str.length;
                            }
                            str[tf++] = ch;
                        }
                        ch = qu.formt[++pfor];
                    }
                }
                if (pfor >= qu.forLength) break scan;
                ch = qu.formt[pfor++];
                switch (ch){
                case '(':                          // another parens-clause
                    nest++;
                    state = F_TXT;
                    break tran;
                case ')':                          // close parens-clause
                    nest--;
                    state = F_TXT;
                    if (store){
                        if (tf == tfe){
                            str = extend();
                            tfe = str.length;
                        }
                        str[tf++] = ch;
                    }
                    if (nest == 0){
                        break scan;
                    }
                    continue;
                case '\n': case '\f':              // special codes
                    if (nest == 0){
                        if (store){
                            if (tf == tfe){
                                str = extend();
                                tfe = str.length;
                            }
                            str[tf++] = ch;
                        }
                        break scan;
                    }
                case '@': case '[':                // special codes
                    state = F_SPECP;
                    break tran;
                }
                state = F_SPEC;
                break;
            case F_SPEC:                           // qualifiers
            case F_SPECP:                          // qualifiers of %@
                switch (ch){
                case '`':
                    pfor++;
                    if (pfor >= qu.forLength) break scan;
                    ch = qu.formt[pfor];
                    break;                         // escape
                case ';':
                    if (nest == 0){
                        if (str == null) pfor++;   // skip only
                        break scan;                // when get string, do not ..
                    }                              // ..  skip ;
                    state = F_TXT;
                    break;
                case '%':                          // termination of spec
                    if (nest == 0) break scan;
                    state = F_TXT;
                    break tran;
                case ',': case ' ':                // termination of spec ..
                    if (state == F_SPEC){          // .. for normal specs
                        if (nest == 0) break scan;
                        state = F_TXT;
                    }
                    break;
                }
                pfor++;
                break;
            case F_TXT:                            // format-text
                pfor++;
                if (ch == '%'){
                    if (qu.formt[pfor] == '%'){
                        pfor++;
                    } else {
                        if (nest == 0){            // end of format-text
                            pfor--;
                            break scan;
                        }
                        state = F_CODE;            // single %
                    }
                } else if ((ch == '\n') ||
                    (ch == '\f')){
                    if (nest == 0){                // end of format-text
                        pfor--;
                        break scan;
                    }
                    state = F_CODE;                // \n
                }
                break;
            }
            if (store){
                if (tf == tfe){
                    str = extend();
                    tfe = str.length;
                }
                str[tf++] = ch;
            }
        }
        if ((FL_D & this.trc) != 0){
            Trc.out.println("end skip at: " + pfor +
                " " + qu.formt[qu.pfor] +
                " len: " + tf);
        }
        if (str != null){                          // return string present
            this.cptr.erLength = tf;
        }
        return pfor;
    }

    /**
     * Extend the buffer for the external representation by a default
     * amount.
     */

    private char[] extend(){
        char[] cur = (char[])this.cptr.eptr;
        int newlen = cur.length+10;
        if (newlen < 0) error(IOError.ERR_OUTLIMIT);
        char[] p = new char[newlen];
        System.arraycopy(cur,0,p,0,cur.length);
        this.cptr.eptr = p;
        return p;
    }

    public static final int F_CODE   = 0;
    public static final int F_SPEC   = 1;
    public static final int F_SPECP  = 2;
    public static final int F_TXT    = 3;
    public static final int F_CLAUSE = 4;
    public static final String[] F_NAME =
            {"code","spec","specp","txt","clause"};

    /**
     * Get a numeric parameter from the format, or from the io list if
     * <code>*</code> is specified. The number ranges from -32768 to
     * 32767.
     *
     * @param      d default value returned if no number found
     * @param      true if negative number allowed
     * @return     number
     */

    public int frm_param(int def, boolean neg){
        Cdata   qu = this.cptr;
        int     start;
        int     width;
        boolean minus;
        char    ch;
        int     savionest;

        ch = qu.formt[qu.pfor];
        if ((FL_D & this.trc) != 0){
            Trc.out.println("frm_param: for: " + ch);
        }
        doit: {
            if (ch  == '*'){                     // read it from io list
                savionest = qu.ionest;
                ch = qu.formt[++qu.pfor];        // skip *
                if (((ch >= '0') && (ch <= '9')) ||   // positional
                    (ch == '-') || (ch == '+')){
                    getArgNum();
                    qu.ionest = -1;               // always top level
                }
                getval(FRM_INT);
                qu.ionest = savionest;
                qu.elemPos = 0;                   // non positional now
                def = this.cptr.val_int;
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("* from io list: " + def);
                }
                if ((def < 0) && !neg){
                    error(ERR_NEGNUM);
                }
                break doit;
            }
            minus = false;
            if (neg && (ch == '-')){             // check number present
                ch = qu.formt[qu.pfor+1];
                if ((ch < '0') || (ch > '9')){   // not present
                    error(ERR_NONUM);
                }
                minus = true;
                qu.pfor++;                       // skip it
            }
            start = qu.pfor;
            width = 0;
            while (true){
                ch = qu.formt[qu.pfor];
                if ((ch < '0') || (ch > '9')) break;
                width = width*10 + (ch - '0');
                if (minus){
                    if (width > 32768) error(ERR_TOOLOW);
                } else {
                    if (width > 32767) error(ERR_TOOLRG);
                }
                qu.pfor++;
            }
            if (qu.pfor > start){                // number present
                def = width;
                if (minus) def = -def;
            }
        }
        if ((FL_D & this.trc) != 0){
            Trc.out.println("frm_param: for: " +
                qu.formt[qu.pfor] + " val: " + def);
        }
        return def;
    }

    /**
     * Get a number from the format. The number ranges from 0 to
     * 32767.
     *
     * @return     number
     */

    public int frm_num(){
        Cdata   qu = this.cptr;
        int     start;
        int     width;
        boolean minus;
        char    ch;

        start = qu.pfor;
        width = 0;
        while (true){
            ch = qu.formt[qu.pfor];
            if ((ch < '0') || (ch > '9')) break;
            width = width*10 + (ch - '0');
            if (width > 32767) error(ERR_TOOLRG);
            qu.pfor++;
        }
        if (qu.pfor == start){                // number absent
            error(ERR_NONUM);
        }
        return width;
    }


    /**
     * Parse the qualifiers in the format and deliver them in cdata.
     * The allowed qualifiers are passed as a string. The presence of
     * the qualifiers is reported as bits in a long.
     *
     * @param      s string of the sets of qualifiers, each set
     *             terminated by a semicolon
     */

    /* The allowed qualifiers are passed in an array of longs. To
     * accomodate 64 qualifiers a mapping is used. The qualifiers are:
     *
     * character   A..Z   a..z   !  #  '  (  +  -  .  /  :  =  ^
     * qual.code   0..25 26..51 52 53 54 55 56 57 58 59 60 61 62
     *
     * In the mapping the value 0 is reserved for illegal qualifiers
     * so as to detect easily if a character is allowed or not.
     * The first long is for the alternative qualifiers: the ones
     * that can be all or partly present; the following longs are
     * for the subsets of exclusive qualifiers: only one in each
     * subset is allowed. Negative patterns are for numbers.
     * The numeric qualifiers come in these forms:
     *
     * 1. a number, followed by a separator (one among some allowed)
     *    and by another number. A separator must be present. E.g.
     *    1.2,  1., .2.  This is indicated as "i.f", where `.' can also
     *    be a sequence of ("one of") separators.
     * 2. a number, possibly followed by a separator and another number.
     *    E.g.: 1:2, 1, 1:, :2. The difference with the previous one is
     *    that a number by itself is allowed here, while in the former
     *    case it must be followed by a separator.
     *    This is indicated as "n:m".
     * 3. the same as 1., but with no second number. This is indicated
     *    as "i.".
     * 4. $ followed by a number. This is indicated as "$".
     *
     * Upon return, <code>kind</code> field in <code>cdata</code> is set to
     * the match found in the second pattern.
     */

    public void frmGetQuals(long[] patt){
        Cdata   qu = this.cptr;
        boolean neg;
        int     num1 = 0;
        int     num2 = 0;
        int     savNum = 0;
        char    pres1 = ' ';
        char    pres2 = ' ';
        int     psav, pf;               // saved pfor 
        char    c, ch;
        int     i;
        int     p;                      // index in pattern
        char    padd = ' ';
        char    nfill = ' ';
        char    bitrep0 = '0';
        char    bitrep1 = '1';
        int     sets = 0;               // bits for the active subpatterns
        int     cursets;
        int     numsets;                // preceding numeric sets
        long    tentQual;               // sep in num quals tentalively found

        if ((FL_D & this.trc) != 0){
            Trc.out.print("getqual pfor: " + qu.pfor + " for: " +
                qu.formt[qu.pfor] + " patt: ");
            if (patt != null){
                for (i = 0; i < patt.length; i++){
                    Trc.out.print(" ");
                    if (patt[i] == -1){
                        Trc.out.print('$');
                    } else {
                        for (c = '!'; c <= 'z'; c++){
                            if ((patt[i] & qualMap[c]) != 0)
                                 Trc.out.print(c);
                        }
                    }
                }
            }
            Trc.out.println();
        }
        if (qu.endQuals > 0){                    // already parsed, skip
            qu.pfor = qu.endQuals;
            if ((FL_D & this.trc) != 0){
                Trc.out.println("getqual skip to: " + qu.pfor);
            }
            return;
        }
        if (patt != null){
            sets = (1 << patt.length) - 1;       // one bit for each subpattern
        }
        qu.pres  = 0;                            // initialise presence set
        qu.kind = ' ';
        qu.integral = -1;
        qu.decimal = -1;
        qu.minw = 0;
        qu.maxw = 0;
        qu.elemNum = 0;
        qu.elemPos = 0;                          // non positional arg
        endqual: while (qu.pfor < qu.forLength){
            if (patt == null) break endqual;
            c = qu.formt[qu.pfor];
            if ((FL_D & this.trc) != 0){
                Trc.out.println("pfor: " + qu.pfor +
                    " (" + c + ")");
            }
            if (c > 'z') break endqual;          // it belongs to no patt.
            dupl: {
                if ((c >= '0') && (c <= '9'))
                     break dupl;
                if (c == '*') break dupl;
                if (c == '-') break dupl;
                if (c == '$') break dupl;
                if (qualMap[c] == 0){
                    break endqual;               // belongs to no patterns
                }
                if ((qu.pres & qualMap[c]) != 0){
                    break endqual;               // already specified
                }
            }

            // to test if it has already been specified, there is a need
            // to check all but the numeric ones, which are checked by
            // removing them from the sets to be matched

            int sav_pfor = -1;                   // index at which
            int sav_pfor_end = -1;               // .. a number is found
            cursets = sets;
            numsets = 0;
            scanset: for (i = 0; cursets != 0; i++){
                p = cursets & 1;
                cursets = cursets >>> 1;
                if ((FL_D & this.trc) != 0){
                    Trc.out.println("patt nr: " + i +
                       " pfor: " + qu.pfor);
                }
                if (p == 0) continue;            // already visited

                if (patt[i] == -1){              // $
                    numsets |= (1 << i);
                    c = qu.formt[qu.pfor];
                    if (c == '$'){               // found
                        qu.pfor++;
                        getArgNum();
                        sets &= ~numsets;        // remove it and preceding
                        continue endqual;
                    }
                    continue scanset;
                }
                if (patt[i] < 0){                // numeric pattern
                    numsets |= (1 << i);
                    tentQual = 0;
                    psav = qu.pfor;
                    num1 = 0;
                    pres1 = ' ';
                    num2 = 0;
                    pres2 = ' ';
                    if (((N_MSK | I_MSK) & patt[i]) != 0){
                        neg = (N_MSK & patt[i]) != 0;  // negative allowed
                        pf = qu.pfor;
                        if ((pf != sav_pfor) ||        // number not yet parsed
                            (!neg && (num1 < 0))){
                            num1 = frm_param(0,neg);   // get number
                        } else {                       // avoid backtracking
                            qu.pfor = sav_pfor_end;
                            num1 = savNum;
                            if ((FL_D & this.trc) != 0)
                                Trc.out.println("reuse: " + num1);
                        }
                        if (qu.pfor > pf){             // found
                            pres1 = (neg) ? 'n' : 'i';
                            sav_pfor = pf;
                            sav_pfor_end = qu.pfor;
                            savNum = num1;
                        }
                        c = qu.formt[qu.pfor];
                    }
                    numfound: {
                        if ((c < 'a') && ((qualMap[c]       // match separator
                            & patt[i]) != 0)){              // found
                            tentQual |= qualMap[c];         // remember it
                            if ((FL_D & this.trc) != 0){
                                Trc.out.println("found sep: " + c);
                            }
                            qu.pfor++;
                            c = qu.formt[qu.pfor];
                        } else if (((C_MSK & patt[i]) != 0) // optional :
                            && (pres1 != ' ')){             // .. not found, and
                            break numfound;                 // .. number found
                        } else {                            // patt not matched
                            qu.pfor = psav;
                            c = qu.formt[qu.pfor];
                            if ((FL_D & this.trc) != 0){
                                Trc.out.println("backup: " +
                                    qu.pfor);
                            }
                            continue scanset;
                        }
                        if (((M_MSK | F_MSK) & patt[i]) != 0){
                            pf = qu.pfor;
                            num2 = frm_param(0,false);      // get number
                            if (qu.pfor > pf){              // found
                                pres2 = ((M_MSK & patt[i]) != 0) ? 'm' : 'f';
                            }
                        }
                    }
                    sets &= ~numsets;                       // remove it
                                                            // .. and preceding
                    qu.pres |= tentQual;                    // mark it
                    if (pres1 == 'i') qu.integral = num1;   // integr. specified
                    if (pres2 == 'f') qu.decimal = num2;    // decimal specified
                    if (pres1 == 'n') qu.minw = num1;       // minw specified
                    if (pres2 == 'm') qu.maxw = num2;       // maxw specified
                    continue endqual;
                }
                                                            // normal pattern
                if ((patt[i] & qualMap[c]) == 0){           // not found
                     continue;
                }
                qu.pres |= qualMap[c];                      // mark it
                if ((FL_D & this.trc) != 0){
                    Trc.out.println("found: " + c);
                }
                if (i == 1) qu.kind = c;
                if ((c == 'p') || (c == 'f') ||
                    (c == 'B')){
                    if (qu.formt[qu.pfor+1] == '`'){     // escape
                        qu.pfor++;
                    }
                    if (qu.pfor >= qu.forLength){        // missing ch
                        continue endqual;
                    }
                    qu.pfor++;
                    switch (c){
                    case 'p': padd = qu.formt[qu.pfor]; break;
                    case 'f': nfill = qu.formt[qu.pfor]; break;
                    case 'B':
                        bitrep0 = qu.formt[qu.pfor];
                        if (qu.formt[qu.pfor+1] == '`'){ // escape
                            qu.pfor++;
                        }
                        if (qu.pfor >= qu.forLength){    // missing ch
                            error(ERR_NOCHAR);
                        }
                        qu.pfor++;
                        bitrep1 = qu.formt[qu.pfor];
                        break;
                    }
                }
                if (i > 0) sets &= ~(1 << i);            // remove it
                qu.pfor++;
                continue endqual;
            }
            break endqual;                               // not found
        }
        qu.endQuals = qu.pfor;                           // remember end
        qu.evid = this.evid;                             // init object
        qu.padd = ' ';
        qu.just = 1;
        qu.sign = ' ';
        qu.thou = '\0';
        qu.cncy = ' ';
        qu.nfill = ' ';
        qu.bitrep0 = '0';
        qu.bitrep1 = '1';
        qu.dradix = ' ';
        qu.lowbound = false;
        qu.brk = this.breakon | this.breakdef;
        qu.insdone = false;
        qu.preflen = 0;
        setqual: {
            if (sets == 0) break setqual;
            if ((qualMap['+'] & qu.pres) != 0) qu.sign = '+';    // sign
            if ((qualMap['('] & qu.pres) != 0) qu.sign = '(';    // () negative
            if ((qualMap['\''] & qu.pres) != 0) qu.thou = ',';   // thous. sep
            if ((qualMap['^'] & qu.pres) != 0) qu.thou = '\0';   // no th. sep
            if ((qualMap['.'] & qu.pres) != 0) qu.dradix = '.';  // dec. radix
            if ((qualMap['!'] & qu.pres) != 0) qu.dradix = '!';  // same, forced
            if ((qualMap['z'] & qu.pres) != 0) qu.evid = true;   // evidence
            if ((qualMap['Z'] & qu.pres) != 0) qu.evid = false;  // no evidence
            if ((qualMap['n'] & qu.pres) != 0) qu.brk = false;   // no break
            if ((qualMap[':'] & qu.pres) != 0) qu.lowbound = true; // min:, :max
            if ((qualMap['p'] & qu.pres) != 0) qu.padd = padd;   // padding
            if ((qualMap['f'] & qu.pres) != 0) qu.nfill = nfill; // num filling
            if ((qualMap['B'] & qu.pres) != 0){                  // bit repres
                qu.bitrep0 = bitrep0;
                qu.bitrep1 = bitrep1;
            }
            if ((qu.maxw > 0) &&
                (qu.maxw < qu.minw)){           // max < mix
                qu.maxw = qu.minw;
                error(ERR_TOOLOW);
            }
            if (qu.minw <= 0){
                qu.just = -1;                   // free format/width<0: just left
                qu.minw = -qu.minw;
            }
            if ((qualMap['a'] & qu.pres) != 0){ // middle alignment
                qu.just = 0;                    // override justification
            }
            if ((qualMap['A'] & qu.pres) != 0){ // centered alignment
                qu.just = 2;                    // override justification
            }
        }
        if ((FL_D & this.trc) != 0){
            Trc.out.println("kind " + qu.kind + " evid " + qu.evid +
                " padd 0x" + Integer.toHexString(qu.padd) +
                " minw " + qu.minw + " maxw " + qu.maxw +
                " just " + qu.just);
            Trc.out.println("integral " + qu.integral +
                " decimal " + qu.decimal + " sign " + qu.sign +
                " thou " + qu.thou + " cncy " + qu.cncy);
            Trc.out.println("nfill " + qu.nfill +
                " dradix " + qu.dradix + " lowbound " + qu.lowbound +
                " bitrep " + qu.bitrep0 + qu.bitrep1 +
                " brk " + qu.brk);
            Trc.out.print("quals: " + Long.toHexString(qu.pres) + " ");
            for (i = 0; i <= 'z'; i++){
                if ((qualMap[i] & qu.pres) != 0){
                    Trc.out.print((char)i);
                }
            }
            Trc.out.println();
        }
    }

    /** The map delivering the mask of a qualifier from its ASCII value. */
    public static final long[] qualMap = {
              0,     0,     0,     0,     0,     0,     0,     0, // 0 .. 7
              0,     0,     0,     0,     0,     0,     0,     0, // 8 .. 15
              0,     0,     0,     0,     0,     0,     0,     0, // 16 .. 23
              0,     0,     0,     0,     0,     0,     0,     0, // 24 .. 31
              0,1L<<52,     0,1L<<53,     0,     0,     0,1L<<54, // 32 .. 39
         1L<<55,     0,     0,1L<<56,     0,1L<<57,1L<<58,1L<<59, // 40 .. 47
              0,     0,     0,     0,     0,     0,     0,     0, // 48 .. 55
              0,     0,1L<<60,     0,     0,1L<<61,     0,     0, // 56 .. 63
              0,1L<< 0,1L<< 1,1L<< 2,1L<< 3,1L<< 4,1L<< 5,1L<< 6, // 64 .. 71
         1L<< 7,1L<< 8,1L<< 9,1L<<10,1L<<11,1L<<12,1L<<13,1L<<14, // 72 .. 79
         1L<<15,1L<<16,1L<<17,1L<<18,1L<<19,1L<<20,1L<<21,1L<<22, // 80 .. 87
         1L<<23,1L<<24,1L<<25,     0,     0,     0,1L<<62,     0, // 88 .. 95
              0,1L<<26,1L<<27,1L<<28,1L<<29,1L<<30,1L<<31,1L<<32, // 96 .. 103
         1L<<33,1L<<34,1L<<35,1L<<36,1L<<37,1L<<38,1L<<39,1L<<40, // 104 .. 111
         1L<<41,1L<<42,1L<<43,1L<<44,1L<<45,1L<<46,1L<<47,1L<<48, // 112 .. 119
         1L<<49,1L<<50,1L<<51};                                   // 120 .. 122

    /**
     * Define a set of qualifiers.
     *
     * @param      s qualifiers
     * @return     bitset denoting the qualifiers
     */

    public static long qualSet(String s){
        long res = 0;
        char c;
        for (int i = 0; i < s.length(); i++){
            c = s.charAt(i);
            if (qualMap[c] == 0){
               Trc.out.println("illegal qualifier: 0x"
                   + Integer.toHexString(c) + " in " + s);
               System.exit(1);
            }
            res |= qualMap[c];
        }
        return res;
    }

    /**
     * Define a set of numeric qualifiers.
     *
     * @param      s qualifiers
     * @return     bitset denoting the qualifiers
     */

    public static long qualNum(String s){
        long res = 0;
        char c;
        if (s == "$"){
            res = -1;                             // special one
        } else {
            res = qualSet(s);
            res |= 1L << 63;                      // make it negative
        }
        return res;
    }

    /* Flags for numeric qualifiers. */
    private static final long N_MSK = qualMap['n'];
    private static final long M_MSK = qualMap['m'];
    private static final long I_MSK = qualMap['i'];
    private static final long F_MSK = qualMap['f'];
    private static final long C_MSK = qualMap[':'];


    /* Elementary record manipulation */

    /**
     * Initialise the pointers to a record. In the object, <code>rec</code>
     * and <code>lenght</code> should denote the record.
     */

    private void rec_init(){
        this.cursor = 0;
        this.max = 0;
        this.end = this.length;
        this.lastbrk = 0;
        this.lastdis = 0;
    }

    /**
     * Insert a string in the current record and update its pointers.
     * If there is no room, only the part that fits is inserted,
     * and a non-zero value returned.
     *
     * @param      s pointer to the string
     * @param      type code of its type
     * @param      off start index in it
     * @param      len number of characters to be inserted. If < 0,
     *             the cursor is left at the beginning of the insertions,
     *             otherwise at the end.
     */

    private void ins_rec(Object start, byte type, int off, int len){
        int    ln;
        int    space;                           // free space in record

        ln = len > 0 ? len : -len;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("ins_rec: |" +
                String.valueOf(makeString(start,type,off,ln)) +
                "| at: " + this.cursor + " new cur: " +
                (this.cursor+(len>0?len:0)));
        }
        if (ln > 0){
            if (this.insert){                   // test if room available
                space = this.end - this.max;
            } else {
                space = this.end - this.cursor;
            }
            if (ln > space){
                if (this.grow){
                    bufferExtend(ln - space);
                    if (this.insert) space = this.end - this.max;
                    else space = this.end - this.cursor;
                }
            }
            if (ln > space){                    // no space
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("ins_rec: no space");
                }
                ln = space;                     // cut it to show error
                this.res = ERR_NOSPACE;
            }
            if ((this.insert) &&
                (this.cursor < this.max)){             // insert in the middle
                if (ln > 0){
                    if (this.cursor <= this.lastbrk){  // shift also last break
                        this.lastbrk += ln;
                    }
                    if (this.cursor <= this.lastdis){  // and last break-dis
                        this.lastdis += ln;
                    }
                    System.arraycopy(this.buffer,this.cursor,
                        this.buffer,this.cursor+ln,this.max-this.cursor);
                    this.max += ln;
                }
            }    
            switch (type){                      // copy string
            case FRM_BYTES:
                int k = this.cursor;
                for (int j = off; j < off+ln; j++){
                    this.buffer[k++] = (char)(((byte[])start)[j] & 0xff);
                }
                break;
            case FRM_CHARS:
                System.arraycopy(start,off,this.buffer,this.cursor,ln);
                break;
            case FRM_STRING:
                ((String)start).getChars(0,ln,this.buffer,this.cursor);
                break;
            case FRM_STRBUF:
                ((StringBuffer)start).getChars(0,ln,this.buffer,this.cursor);
                break;
            }
            if (this.max < this.cursor+ln){     // adjust max
                this.max = this.cursor+ln;
            }
            if (len > 0) this.cursor += ln;     // advance
            if (this.max < this.cursor){        // adjust max again
                this.max = this.cursor;
            }
            this.newcont = false;               // not at start of a cont. line
        }
        if (this.res != 0){
            error(this.res);
        }
    }

    /**
     * Extend the text record. It allocates a new record whose size is
     * enlarged by a half or by that passsed as argument, if greater.
     *
     * @param      s space to be added
     */

    private void bufferExtend(int s){
        char[] cur = this.buffer;
        if ((FL_M & this.trc) != 0){
            Trc.out.println("extend: " + cur.length);
        }
        int newlen = this.length;
        if (s > this.length / 2) newlen += s;
        else newlen += this.length / 2;
        if (newlen < 0) error(IOError.ERR_OUTLIMIT);
        if (newlen <= cur.length) return;    // the real buffer is o.k.
        char[] p = new char[newlen];
        System.arraycopy(cur,0,p,0,cur.length);
        this.buffer = p;
        this.length = newlen;
        this.end = this.length;

        if (this.tabs != null){              // extend the tabs
            byte[] curt = this.tabs;
            int newlent = (this.length+8)/8;
            if (newlent < 0) error(IOError.ERR_OUTLIMIT);
            byte[] pt = new byte[newlent];
            System.arraycopy(curt,0,pt,0,curt.length);
            this.tabs = pt;
        }
    }

    /**
     * Adjust the pointers to the last break position and the
     * last break pending disappear piece to reflect the cutting of
     * a piece of the record.
     *
     * @param      s index of the start of the part meant to be cut
     * @param      l number of characters of the part
     */

    private void adjcut_brk(int start, int len){
        if (start <= this.lastbrk){
            if (this.lastbrk - len < start){     // break position erased
                this.lastbrk = start;
            } else {                             // break position moved
                this.lastbrk -= len;
            }
        }
        if (start <= this.lastdis){
            if (this.lastdis - len < start){     // break-dis position erased
                this.lastdis = 0;
                this.dislen = 0;
            } else {                             // break position moved
                this.lastdis -= len;
            }
        }
    }

    /**
     * Cut a piece of the record.
     *
     * @param      s pointer to the start of the piece to be cut
     * @param      e pointer to the end
     * @param      p address of the pointer to the area
     * @param      l number of characters of the piece
     */

    private void cut_rec(int start, int end, char[] p, int len){
        System.arraycopy(this.buffer,start,p,0,len);  // save remainder
        if ((FL_C & this.trc) != 0){
            Trc.out.println("save: |" +
                String.valueOf(p,0,len) + "|");
        }
        this.max = start;                          // cut it from record
        adjcut_brk(start,len);                     // adjust pointers in cut
    }

    /**
     * Delete a piece of the record at the current position. If the
     * part to be deleted exceeds the record, and error is caused and
     * only the part which lays in the record is deleted.
     *
     * @param      l length of the piece to be cut, > 0 if after the cursor,
     *             < 0 if before it.
     */

    private void del_rec(int len){
        int start, end;

        if (len < 0){                           // before the cursor
            start = this.cursor + len;
            end = this.cursor;
        } else {                                // after it
            start = this.cursor;
            end = this.cursor + len;
        }
        if ((start < 0) ||                      // too large
            (end > this.max)){
            this.res = ERR_TOOLRG;
            if (len < 0){
                len = - this.cursor;
                start = 0;
            } else {
                len = this.max - this.cursor;
                end = this.max;
            }
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("del_rec: start " + start +
                " end " + end + " cur " + this.cursor +
                " max " + this.max + " len " + len);
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("deleting: " + start +
                ":" + (end-1));
        }
        enddel: if (len < 0){
            if (this.max == this.cursor){          // no tail
                this.cursor += len;
                break enddel;
            }
            System.arraycopy(this.buffer,this.cursor, // shift cur+max to beginning
                this.buffer,start,this.max - this.cursor);
            this.cursor += len;
        } else {
            if (this.max == end) break enddel;  // no tail
            System.arraycopy(this.buffer,end,   // shift cur+len:max
                this.buffer,this.cursor,this.max-end);
        }
        this.max -= Math.abs(len);
        adjcut_brk(start,Math.abs(len));        // adjust pointers in cut
        if ((FL_C & this.trc) != 0){
            Trc.out.println("del_rec: max " +
                this.max + " cur " + this.cursor);
        }
        if (this.res != 0) error(this.res);
    }


    /* Record insertion methods */

    /** Reduce %% to %. */
    public static final int REDPERC =  1 <<  1;

    /** Expand non printable characters as \ooo. */
    public static final int EXPOCT  =  1 <<  2;

    /** Expand non printable characters as \xnn. */
    public static final int EXPHEX  =  1 <<  3;

    /** Expand html sequences. */
    public static final int EXPHTML =  1 <<  4;

    /** Expand as a Java string literal body. */
    public static final int JSTRLIT =  1 <<  5;

    /** Surround with ". */
    public static final int ENCLQUO =  1 <<  6;

    /** surround with '. */
    public static final int ENCLAPX =  1 <<  7;

    /** Expand as binary. */
    public static final int EXPBIN  =  1 <<  8;

    /** Expand non-ASCII Unicodes as \u0000. */
    public static final int EXPUNI  =  1 <<  9;

    /** Convert to lowercase. */
    public static final int LOWCASE =  1 << 10;

    /** Convert to uppercase. */
    public static final int UPPCASE =  1 << 11;

    /** Convert to titlecase. */
    public static final int TITCASE =  1 << 12;

    /** Expand newlines. */
    public static final int EXPNL =  1 <<  13;

    /**
     * Insert a string which is an external representation into
     * the record, possibly flushing it in wrap mode. The mode field in
     * the cdata indicates the conversions and other addons to be done
     * on the string. If there is not enough space, it inserts what it
     * can and causes an error.
     * When it is called with a null string, it resumes the insertion
     * done at the previous call.
     *
     * @param      ep pointer to the string
     * @param      type code of the type of ep
     * @param      off start index in the string
     * @param      siz its length (from off)
     * @param      rep number of times the string has to be inserted
     */

    public void insert(Object ep, byte type, int off, int siz, int rep){
        Cdata  qu = this.cptr; 
        int    space;                        // free space in record
        int    relpos;                       // relative insertion pos. in rem.
        int    last;                         // lastbrk - blanks

        if (off + siz < 0){
            error(IOError.ERR_OUTLIMIT);
        }
        if (ep != null){
            if (qu.minw == 0) qu.just = -1;      // free format: left justify
            if ((FL_C & this.trc) != 0){
                Trc.out.println("insert cur: " + this.cursor +
                    " mode: " + qu.mode + " rep: " + rep +
                    " siz: " + siz + " insert: " + this.insert +
                    " off: " + off + " type: " + type);
                Trc.out.print("inserting: |");
                Trc.literalize(makeString(ep,type,off,siz));
                Trc.out.println("|");
            }
            qu.replen = det_length(ep,type,off,siz,qu.mode);
            qu.repwid = qu.replen * rep;         // lenght of insert wanted 
            if (qu.repwid < 0){
                error(IOError.ERR_OUTLIMIT);
            }
            qu.eptr = ep;
            qu.erType = type;
            qu.eptrStart = off;
            qu.erLength = siz;
                                                 // determine field width now
            if (qu.minw == 0){                   // free format
                qu.fldwid = qu.repwid;
                if ((qu.maxw > 0) &&
                    (qu.repwid > qu.maxw)){      // maximum specified, :max
                    qu.fldwid = qu.maxw;
                }
            } else {                             // fixed format, min [:max]
                qu.fldwid = qu.minw;
                if (qu.lowbound){
                    if (qu.repwid > qu.minw){
                        qu.fldwid = qu.repwid;   // no less than min, min:
                    }
                    if ((qu.maxw > 0) &&
                        (qu.repwid > qu.maxw)){  // no more than max, [min]:max
                        qu.fldwid = qu.maxw;
                    }
                }
            }
        }
        doit: {
            if ((this.wrap) && this.newcont){          // at beginning of
                if ((FL_C & this.trc) != 0){           // .. contin. line
                    Trc.out.println("insert: startline");
                }
                startline(false);
            }
            if (this.insert){                          // test if room available
                space = this.end - this.max;
            } else {
                space = this.end - this.cursor;
            }
            if ((FL_C & this.trc) != 0){
                Trc.out.println("insert: " + qu.fldwid +
                    " + " + this.pendLength + " space: " +
                    space + " pend: " + this.pendnl +
                    " grow: " + this.grow);
            }
            if (qu.fldwid > space - this.pendLength ){
                if (this.grow){
                    bufferExtend(qu.fldwid + this.pendLength - space);
                    if (this.insert) space = this.end - this.max;
                    else space = this.end - this.cursor;
                }
            }
            if ((qu.fldwid > space - this.pendLength) ||  // not enough space ..
                this.pendnl){                             // .. or flush required
                set_carriage('n');
                brkins: {
                    if ((this.pendnl) &&                  // there is room for
                        (this.pendLength <= space)){      // .. the pending
                        break brkins;
                    }
                    if (ep == null){                      // resume insertion
                        error(ERR_NOSPACE);
                    }
                    if ((this.cbkpres & INSERTCBK) != 0){     // present
                        if (this.inusrins || this.inusrhdr){  // endless
                            error(ERR_NEST);                  // ..  recursion
                        }
                        qu.insdone = false;
                        this.inusrins = true;          // inside user insert
                        call_cbk('3',1,INSFRM,true);   // insert callback
                        this.inusrins = false;
                        if (qu.insdone) break doit;
                        qu.brk = false;
                    }
                }
                if (!this.wrap){                       // no wrap mode
                    qu.fldwid = space;
                    this.res = ERR_NOSPACE;
                } else {
                    int mode = (qu.brk)? PK_BRK : 0;
                    pack_rec(1,
                        mode|PK_MAIN,qu.eptr,type,qu.eptrStart,qu.fldwid,
                          0,null,(byte)0,0,0);
                    break doit;
                }
            } else {
                if (this.pendLength > 0){
                    if (this.penddis){                 // break-disappear
                        this.lastdis = this.cursor;    // remember it
                        this.dislen = this.pendLength;
                    }
                    ins_rec(this.pend,FRM_CHARS,       // insert pendings
                        0,this.pendLength);
                    this.pendLength = 0;
                    this.pendnl = false;
                    this.newcont = false;
                }
            }
            rec_ins();                     // insert it
        }
        this.newcont = false;              // not at start of cont. line
        if (this.res != 0) error(this.res);
    }


    /**
     * Deliver a char[] out of a char[], String or StringBuffer.
     *
     * @param      ep pointer to the Object
     * @param      type code of the type of ep
     * @param      off start index in the string
     * @param      siz its length (from off)
     */

    protected static char[] makeString(Object ep, byte type, int off, int siz){
        char[] tmp = new char[siz];
        if (ep == null) return tmp;
        switch (type){
        case FRM_BYTES:
            int k = 0;
            for (int j = off; j < off+siz; j++){
                tmp[k++] = (char)(((byte[])ep)[j] & 0xff) ;
            }
            break;
        case FRM_CHARS:
            System.arraycopy(ep,off,tmp,0,siz);
            break;
        case FRM_STRING:
            ((String)ep).getChars(off,off+siz,tmp,0);
            break;
        case FRM_STRBUF:
            ((StringBuffer)ep).getChars(off,off+siz,tmp,0);
            break;
        }
        return tmp;
    }

    /**
     * Determine the length of a string which is an external
     * representation by taking into account the conversions and addons
     * to be done.
     *
     * @param      ep pointer to the string
     * @param      type code of the type of ep
     * @param      off start index in the string
     * @param      siz its length
     * @param      mode  mode of conversion
     * @return     length
     */

    private int det_length(Object ep, byte type, int off, int siz, int mode){
        int  l;                              // length of representation * rep
        int  tp;
        boolean tit;

        l = siz;                             // determine natural length of rep.
        if (mode != 0){                      // characters in ep reduced/exp.
            int delta = 0;                   // delta size
            tit = (TITCASE & mode) != 0;
            char c = ' ';
            for (tp = off; tp < off+siz; tp++){    // scan ep
                switch (type){
                case FRM_BYTES:
                    c = (char)((((byte[])ep)[tp]) & 0xff); break;
                case FRM_CHARS:
                    c = ((char[])ep)[tp]; break;
                case FRM_STRING:
                    c = ((String)ep).charAt(tp); break;
                case FRM_STRBUF:
                    c = ((StringBuffer)ep).charAt(tp); break;
                }
                if ((REDPERC & mode) != 0){        // %% count as %
                    char c1 = '\0';
                    if (tp < off+siz-1){
                        switch (type){
                        case FRM_BYTES: c1 = (char)((((byte[])ep)[tp+1]) & 0xff);
                             break;
                        case FRM_CHARS: c1 = ((char[])ep)[tp+1];
                             break;
                        case FRM_STRING: c1 = ((String)ep).charAt(tp+1);
                             break;
                        case FRM_STRBUF: c1 = ((StringBuffer)ep).charAt(tp+1);
                             break;
                        }
                    }
                    if ((c == '%') && (c1 == '%')){
                        tp++;
                        delta--;
                        continue;
                    }
                }
                if (((UPPCASE & mode) != 0) ||         // uppercase
                    (tit && (tp == off))){             // titlecase
                    if ((c == '\u00df') ||             // sharp s
                        (c == '\ufb00') ||             // ligature ff
                        (c == '\ufb01') ||             // ligature fi
                        (c == '\ufb02') ||             // ligature fl
                        (c == '\ufb05') ||             // ligature long st
                        (c == '\ufb06')){              // ligature st
                        delta++ ;
                        continue;
                    } else if ((c == '\ufb03') ||      // ligature ffi
                        (c == '\ufb04')){              // ligature ffl
                        delta += 2;
                        continue;
                    }
                }
                if (((EXPOCT|EXPHEX|EXPUNI) & mode) != 0){ // expand non printables
                    switch (c){
                    case '\\': case '\b': case '\t':   // non printable, \ form
                    case '\n': case '\f': case '\r':
                        delta++;
                        continue;
                    default:
                        if ((c < ' ') || (c > '~')){   // others non printable
                            if ((EXPOCT & mode) != 0){
                                if (c <= 0xff){
                                    delta += 3;        // \ooo
                                    continue;
                                }
                            }
                            delta += 5;                // \x0000 or \u0000
                            continue;
                        }
                    }
                }
                if ((EXPBIN & mode) != 0){         // bit strings
                    delta += 7;
                    continue;
                }
                if ((EXPHTML & mode) != 0){        // html specials
                    switch (c){
                    case '\"': delta += 5; break;
                    case '>':  delta += 3; break;
                    case '<':  delta += 3; break;
                    case '&':  delta += 4; break;
                    }
                }
                if ((JSTRLIT & mode) != 0){        // Java string literal
                    switch (c){
                    case '\'': delta++; break;     // \ form
                    case '\"':
                        if ((EXPHTML & mode) == 0) // not yet converted
                            delta ++;
                        break;
                    }
                }
                if ((EXPNL & mode) != 0){          // expand newlines
                    if (c == '\n'){
                        delta += this.curLineSep.length()-1;
                    }
                }
            }
            if (((ENCLQUO|ENCLAPX) & mode) != 0){  // surround "
                delta += 2;
            }
            l += delta;                            // extend or reduce l
            if (l < 0) error(IOError.ERR_OUTLIMIT);
        }
        if ((FL_D & this.trc) != 0){
            Trc.out.println("det_length: " + l +
                " mode: " + mode);
        }
        return l;
    }


    /**
     * Insert the string which is the current external representation in
     * the record by taking into account the conversions, addons,
     * alignment, justification, etc. If there is no space, the sting
     * is cut.
     * With middle justification it aligns the non-numeric head of the
     * string to the left and the rest to the right.
     * This allows to apply it to any external representation, even the ones
     * which are not generated from numeric formats.
     * There is no need to align the suffix - or ( because alignment implies
     * right justification.
     */

    private void rec_ins(){
        Cdata qu = this.cptr;
        int   l;
        int   sl;
        int   w;
        int   fill;
        int   i;
        int   ep; 
        byte  type;
        char  c;
        byte[]        ebytes  = null;
        char[]        echars  = null;
        String        estring = null;
        StringBuffer  estrbuf = null;

        if (qu.fldwid > 0){
            if (this.cursor > this.end - qu.fldwid){     // it does not fit
                if (this.grow){
                    bufferExtend(this.cursor + qu.fldwid - this.end);
                } else {
                    qu.fldwid = this.end - this.cursor - // cut and insert it to ..
                        - this.pendLength;               // .. show the error
                    this.res = ERR_NOSPACE;
                }
            }
        }
        l = qu.repwid;
        sl = qu.replen;
        w = qu.fldwid;
        ep = qu.eptrStart;
        type = qu.erType;
        switch (type){
        case FRM_BYTES:
            ebytes = (byte[])qu.eptr; break;
        case FRM_CHARS:
            echars = (char[])qu.eptr; break;
        case FRM_STRING:
            estring = (String)qu.eptr; break;
        case FRM_STRBUF:
            estrbuf = (StringBuffer)qu.eptr; break;
        }
        fill = 0;                            // determine fill, possibly cut l
        if (l < w){                          // fillers needed
            fill = w-l;                      // nr of fillers
        }
        if ((FL_D & this.trc) != 0){
            Trc.out.println("field: " + w + " length: " + l +
                " fill: " + fill + " mode: " + qu.mode +
                " cur: " + this.cursor + " ins: " + this.insert +
                " minw: " + qu.minw + " sl: " + sl + " just: " +
                qu.just + " pref: " + qu.preflen);
        }

        boolean nobreak = this.wrap && !qu.brk;    // no break qualifier

        if ((this.insert) &&
            (this.cursor < this.max)){             // insert in the middle
            if (w > 0){
                if (this.cursor <= this.lastbrk){  // shift also last break
                    this.lastbrk += w;
                }
                if (this.cursor <= this.lastdis){  // shift also last break-dis
                    this.lastdis += w;
                }
                System.arraycopy(this.buffer,this.cursor,
                    this.buffer,this.cursor+w,this.max-this.cursor);
                this.max += w;
            } else {
                if (this.breakon || this.breakdef){
                    if (!nobreak){
                        this.lastbrk = this.cursor;    // new last insertion place
                    }
                }
            }
        } else {
            if (this.breakon || this.breakdef){
                if (!nobreak){
                    this.lastbrk = this.cursor;    // new last insertion place
                }
            }
        }
        this.breakdef = false;
        if (qu.just == 0){                         // middle justification
            if ((fill > 0) && (sl == l)){          // only when repeated once
                while (sl > 0){
                    c = ' ';
                    switch (type){
                    case FRM_BYTES: c = (char)(ebytes[ep] & 0xff); break;
                    case FRM_CHARS: c = echars[ep]; break;
                    case FRM_STRING: c = estring.charAt(ep); break;
                    case FRM_STRBUF: c = estrbuf.charAt(ep); break;
                    }
                    if (qu.preflen-- == 0) break;
                    this.buffer[this.cursor++] = c;
                    ep++;                          // move past the sign
                    sl--;
                    l--;
                }
            }
        }
        if (qu.just >= 0){
            int suffill = fill / 2;
            int postfill = fill - suffill;
            if (qu.just == 2){
                fill = suffill;
            }
            for (; fill > 0; fill--){              // leading fillers
                this.buffer[this.cursor++] = qu.padd;
            }
            if (qu.just == 2) fill = postfill;
        }
        endtrf:
        if (w == 0){
            break endtrf;
        } else if (qu.evid && (l > w)){
            for (i = 0; i < w; i++){         // truncation and evidence
                this.buffer[this.cursor++] = '*';
            }
        } else if (qu.mode == 0){            // string need not be scanned
            int  nr, rem;
            nr = l > w ? w : l;              // nr of char to be copied
            if (sl == 1){                    // single repeated char
                c = ' ';
                switch (type){
                case FRM_BYTES: c = (char)(ebytes[ep] & 0xff); break;
                case FRM_CHARS: c = echars[ep]; break;
                case FRM_STRING: c = estring.charAt(ep); break;
                case FRM_STRBUF: c = estrbuf.charAt(ep); break;
                }
                for (int ix = this.cursor; ix < this.cursor+nr; ix++){
                    this.buffer[ix] = c;
                }
                this.cursor += nr;
                break endtrf;
            }
            if (sl == 0) break endtrf;       // no characters
            rem = nr % sl;                   // remainder
            if ((FL_D & this.trc) != 0){
                Trc.out.println("rem: " + rem + " nr: " +
                    nr + " sl: " + sl + " type: " + type +
                    " ep: " + ep);
            }
            if ((qu.just >= 0) && (rem > 0)){       // cut left
                switch (type){
                case FRM_BYTES:
                    int off = ep+(sl-rem);
                    int k = this.cursor;
                    for (int j = off; j < off+rem; j++){
                        this.buffer[k++] = (char)(ebytes[j] & 0xff);
                    }
                    break;
                case FRM_CHARS:
                    System.arraycopy(echars,ep+(sl-rem),
                        this.buffer,this.cursor,rem);
                    break;
                case FRM_STRING:
                    estring.getChars(ep+(sl-rem),ep+sl,this.buffer,this.cursor);
                    break;
                case FRM_STRBUF:
                    estrbuf.getChars(ep+(sl-rem),ep+sl,this.buffer,this.cursor);
                    break;
                }
                this.cursor += rem;
                nr -= rem;
            }
            while (nr > 0){                  // copy now the repeated pieces
                rem = (nr > sl) ? sl : nr;
                switch (type){
                case FRM_BYTES:
                    int k = this.cursor;
                    for (int j = ep; j < ep+rem; j++){
                        this.buffer[k++] = (char)(ebytes[j] & 0xff);
                    }
                    break;
                case FRM_CHARS:
                    System.arraycopy(echars,ep,this.buffer,this.cursor,rem);
                    break;
                case FRM_STRING:
                    estring.getChars(ep,ep+rem,this.buffer,this.cursor);
                    break;
                case FRM_STRBUF:
                    estrbuf.getChars(ep,ep+rem,this.buffer,this.cursor);
                    break;
                }
                this.cursor += rem;
                nr = (nr > sl) ? nr-sl : 0;
            }
        } else {                             // scan and copy
            int  nch;
            int  head = 0;
            if (qu.str == null){
                int strl = this.curLineSep.length();
                if (strl < 10) strl = 10;
                qu.str = new char[strl];
            }
            if ((qu.just >= 0) && (l > w)){             // cut left
                head = l - w;
            }
            nch = l > w ? w : l;
            nch += head;
            if ((ENCLQUO & qu.mode) != 0){              // surround "
                if (nch > 0){
                    this.buffer[this.cursor++] = '"';
                }
                nch -= 2;
            } else if ((ENCLAPX & qu.mode) != 0){       // surround '
                if (nch > 0){
                    this.buffer[this.cursor++] = '\'';
                }
                nch -= 2;
            }
            head = reprTransf(nch,head,sl,ep,type,
                ebytes,echars,estring,estrbuf);
            if ((ENCLQUO & qu.mode) != 0){              // surround "
                if (head > 0) head--;
                else this.buffer[this.cursor++] = '"';
            } else if ((ENCLAPX & qu.mode) != 0){       // surround '
                if (head > 0) head--;
                else this.buffer[this.cursor++] = '\'';
            }
        }
        if ((qu.just < 0) || (qu.just == 2)){
            for (; fill > 0; fill--){                   // trailing fillers
                this.buffer[this.cursor++] = qu.padd;
            }
        }
        if (this.cursor > this.max){
            this.max = this.cursor;
        }
        if ((FL_D & this.trc) != 0){
            Trc.out.println("insert end cur: " + this.cursor
                + " max: " + this.max);
        }
        if (this.res != 0) error(this.res);
    }

    /** The expansion of a double quote in HTML. */
    private static final char[] STRQUOT = {'&','q','u','o','t',';'};

    /** The expansion of a greater than in HTML. */
    private static final char[] STRGT   = {'&','g','t',';'};

    /** The expansion of a less than in HTML. */
    private static final char[] STRLT   = {'&','l','t',';'};

    /** The expansion of an ampersand in HTML. */
    private static final char[] STRAMP  = {'&','a','m','p',';'};

    /**
     * Transfer a string of characters into the external representation while
     * expanding them.
     *
     * @param      nch number of character to be generated
     * @param      head number of character to be discaded at beginning
     * @param      sl size of the string
     * @param      ep start offset into the string
     * @param      type type of conversion
     * @param      ebytes reference to the string, if byte[]
     * @param      echars same, if char[]
     * @param      estring same, if String
     * @param      estrbuf same, if StringBuffer
     */

    private int reprTransf(int nch, int head, int sl, int ep, byte type,
        byte[] ebytes, char[] echars, String estring, StringBuffer estrbuf){
        Cdata   qu = this.cptr;
        int     lim;
        int     ps, pb;
        char    c;
        int     tp;
        boolean tur;
        boolean tit;
        int     mode = qu.mode;
        int     end;

        if ((FL_D & this.trc) != 0){
            Trc.out.println("reprTransf: " + nch);
        }
        tur = false;
        if ((this.locArr != null) &&
            this.locArr[this.locNum] != null){
            tur = this.locArr[this.locNum].         // turkish
                getLanguage().equals("tr");
        }
        tit = (TITCASE & mode) != 0;
        lim = 0;
        end = ep + sl;
        endtr: for (tp = ep; nch > 0; tp++){        // scan ep
            char[] str = qu.str;
            ps = 0;
            pb = 0;
            c = ' ';
            switch (type){
            case FRM_BYTES: c = (char)(ebytes[tp] & 0xff); break;
            case FRM_CHARS: c = echars[tp]; break;
            case FRM_STRING: c = estring.charAt(tp); break;
            case FRM_STRBUF: c = estrbuf.charAt(tp); break;
            }
            ins: {
                if ((REDPERC & mode) != 0){         // %% count as %
                    char c1 = '\0';
                    if (tp+1 < end){
                        switch (type){
                        case FRM_BYTES: c1 = (char)(ebytes[tp+1] & 0xff); break;
                        case FRM_CHARS: c1 = echars[tp+1]; break;
                        case FRM_STRING: c1 = estring.charAt(tp+1); break;
                        case FRM_STRBUF: c1 = estring.charAt(tp+1); break;
                        }
                    }
                    if ((c == '%') && (c1 == '%')){
                        tp++;
                        str[ps++] = c1;
                        break ins;
                    }
                }
                if ((LOWCASE & mode) != 0){            // lowercase
                    if (tur){
                        if (c == 'I'){
                            c = '\u0131';              // dotless small i
                        } else if (c == '\u0130'){     // dotted I
                            c = 'i';	               // dotted i
                        }
                    } else {
                        c = Character.toLowerCase(c);
                    }
                }
                if (((UPPCASE & mode) != 0) ||         // uppercase
                    (tit && (tp == ep))){              // titlecase
                    boolean upp = (UPPCASE & mode) != 0;
                    if (tur){
                        if (c == 'i') {
                            c = '\u0130';              // dotted capital i
                        } else if (c == '\u0131'){     // dotless small i
                            c = 'I';
                        }
                    }
                    switch (c){
                    case '\u00df':                         // sharp s
                        str[ps++] = 'S';
                        if (upp) str[ps++] = 'S';
                        else str[ps++] = 's';
                        break ins;
                    case '\ufb00': str[ps++] = 'F';
                        if (upp) str[ps++] = 'F';
                        else str[ps++] = 'f';
                        break ins;
                    case '\ufb01': str[ps++] = 'F';
                        if (upp) str[ps++] = 'I';
                        else str[ps++] = 'i';
                        break ins;
                    case '\ufb02': str[ps++] = 'F';
                        if (upp) str[ps++] = 'L';
                        else str[ps++] = 'l';
                        break ins;
                    case '\ufb05':
                    case '\ufb06': str[ps++] = 'S';
                        if (upp) str[ps++] = 'T';
                        else str[ps++] = 't';
                        break ins;
                    case '\ufb03': str[ps++] = 'F';
                        if (upp){
                            str[ps++] = 'F'; str[ps++] = 'I';
                        } else {
                            str[ps++] = 'f'; str[ps++] = 'i';
                        }
                        break ins;
                    case '\ufb04': str[ps++] = 'F';
                        if (upp){
                            str[ps++] = 'F'; str[ps++] = 'L';
                        } else {
                            str[ps++] = 'f'; str[ps++] = 'l';
                        }
                        break ins;
                    default:
                        if (upp) c = Character.toUpperCase(c);
                        else c = Character.toTitleCase(c);
                    }
                }
                if (((EXPOCT|EXPHEX|EXPUNI) & mode) != 0){ // non printables
                    switch (c){
                    case '\\':
                        str[ps++] = '\\';
                        str[ps++] = '\\';
                        break ins;
                    case '\b': if (c <= 13) c = 'b';
                    case '\t': if (c <= 13) c = 't';
                    case '\n': if (c <= 13) c = 'n';
                    case '\f': if (c <= 13) c = 'f';
                    case '\r': if (c <= 13) c = 'r';
                        str[ps++] = '\\';              // non printable,
                        str[ps++] = c;                 // .. \ form
                        break ins;
                    default:
                        if ((c < ' ') || (c > '~')){   // others non printable
                            if ((EXPOCT & mode) != 0){
                                if (c <= 0xff){
                                    ps = pb = 4;
                                    for (int x = 0; x < 3; x++){
                                        str[--pb] = (char)((c & 0x7) + '0');
                                        c >>= 3;
                                    }
                                    str[--pb] = '\\';
                                    break ins;
                                }
                            }
                            ps = pb = 6;
                            for (int x = 0; x < 4; x++){
                                int rem = c & 0xf;
                                str[--pb] = (char)(rem +
                                    ((rem <= 9) ? '0' : 'a' - 10));
                                c >>= 4;
                            }
                            str[--pb] = ((EXPHEX & mode) != 0) ? 'x' : 'u';
                            str[--pb] = '\\';
                            break ins;
                        }
                    }
                }
                if ((EXPBIN & mode) != 0){             // bit strings
                    int  ix;
                    char msk;
                    msk = 1;
                    for (ix = 0; ix < 8; ix++){
                        str[ps++] = ((c & msk) != 0) ?
                            qu.bitrep1 : qu.bitrep0;
                        msk <<= 1;
                    }
                    break ins;
                }
                if ((EXPHTML & mode) != 0){            // html specials
                    switch (c){
                    case '\"':
                         str = STRQUOT; ps = pb + 6; break ins;
                    case '>':
                         str = STRGT; ps = pb + 4; break ins;
                    case '<':
                         str = STRLT; ps = pb + 4; break ins;
                    case '&':
                         str = STRAMP; ps = pb + 5; break ins;
                    }
                }
                if ((JSTRLIT & mode) != 0){            // Java string literal
                    switch (c){
                    case '\'': 
                        str[ps++] = '\\';
                        str[ps++] = c;
                        break ins;
                    case '\"':                         // not yet conv. in html
                        if ((EXPHTML & mode) == 0){
                            str[ps++] = '\\';
                            str[ps++] = c;
                            break ins;
                        }
                    }
                }
                if ((EXPNL & mode) != 0){              // expand newlines
                    if (c == '\n'){
                        for (int j = 0;
                            j < this.curLineSep.length(); j++){
                            str[ps++] = this.curLineSep.charAt(j);
                        }
                        break ins;
                    }
                }
                str[ps++] = c;                         // normal character
            }
            for (; pb < ps; pb++, lim++){
                if (head > 0) head--;
                else this.buffer[this.cursor++] = str[pb];
                if (--nch == 0) break endtr;
            }
            if (lim == sl){                            // restart
                tp = ep-1;                             // +1 already done
                lim = 0;
            }
        }
        return head;
    }

    /**
     * Start a record by optionally flushing the previous one and inserting
     * the heading into the new one.
     *
     * @param      n true if flush requested
     */

    private void startline(boolean nl){
        int len;

        if (nl) rec_emit();                      // flush record
        this.newcont = false;                    // prevent a user cbk to make
                                                 // .. this be executed again
        doit: try {
            if ((this.cbkpres & HEADCBK) != 0){  // present
                if (this.inusrhdr){              // endless recursion
                    error(ERR_NEST);
                }
                this.inusrhdr = true;            // in user heading callback
                call_cbk('4',1,HEADFRM,true);    // heading callback
                this.inusrhdr = false;
                break doit;
            }
            int stop = this.cursor+this.indent;
            if (stop < 0) error(IOError.ERR_OUTLIMIT);
            for (int ix = this.cursor; ix < stop; ix++){
                this.buffer[ix] = ' ';
            }
            this.cursor = stop;
            if (this.headLength != 0){           // insert head
                ins_rec(this.head,FRM_CHARS,0,this.headLength);
            }
        } finally {
            this.max = this.cursor;
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("startline: |" +
                String.valueOf(this.buffer,0,this.max) +
                "| cur: " + this.cursor);
        }
    }

    /**
     * End a record by removing a pending break disappear and trailing
     * blanks, and inserting the tail.
     */

    private void endline(){
        int len;

        if ((FL_C & this.trc) != 0){
            Trc.out.println("endline lastdis " +
                this.lastdis + " len " + this.dislen);
        }
        if (this.max - this.lastdis ==
            this.dislen){                     // record ended by a break-dis
            this.max -= this.dislen;          // remove it
            this.dislen = 0;
        }
        while (this.max > 0){                 // remove trailing blanks
            if (this.buffer[--this.max] != ' '){
                this.max++;
                break;
            }
        }
        this.cursor = this.max;
        if (this.tailLength > 0){             // insert tail now
            ins_rec(this.tail,FRM_CHARS,0,this.tailLength);
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("endline: |" +
                String.valueOf(this.buffer,0,this.max) + "|");
        }
    }


    /* Data for packing pieces into the text record */

    /** Break just before it allowed. */
    private static final int PK_BRK  =  1 <<  0;

    /** Pending piece. */
    private static final int PK_PEN  =  1 <<  1;

    /** Break-disappear pend piece. */
    private static final int PK_DIS  =  1 <<  2;

    /** Flush \n. */
    private static final int PK_NL   =  1 <<  3;

    /** Main piece. */
    private static final int PK_MAIN =  1 <<  4;

    private static class Piece {

        /** The mode: break/nobreak, etc. */
        private   int    mode;

        /** The pointer to the start of the piece. */
        private   Object start;

        /** The type of the piece. */
        private   byte   type;

        /** The start index in the piece. */
        private   int    off;

        /** The length of the piece. */
        private   int    len;

        /** The lenght of trailing blanks trimmed piece. */
        private   int    rlen;

        /**
         * Define the data of a piece.
         *
         * @param      s start
         * @param      t type
         * @param      o offset
         * @param      l length
         * @param      trim true to trim it
         */

        private void def(Object s, byte t, int o, int l, boolean trim){
            int  i;

            this.start = s;
            this.type = t;
            this.off = o;
            this.len = l;
            this.rlen = this.len;
            if (!trim) return;
            i = this.off + l;                 // determine length with
            switch (this.type){               // .. trailing blanks removed
            case FRM_BYTES:
                byte[] bar = (byte[])this.start;
                while (i > this.off){
                    if (!Character.isSpaceChar((char)(bar[--i] & 0xff))){i++; break;}
                }
                break;
            case FRM_CHARS:
                char[] arr = (char[])this.start;
                while (i > this.off){
                    if (!Character.isSpaceChar(arr[--i])){i++; break;}
                }
                break;
            case FRM_STRING:
                String str = (String)this.start;
                while (i > this.off){
                    if (!Character.isSpaceChar(str.charAt(--i))){i++; break;}
                }
                break;
            case FRM_STRBUF:
                StringBuffer sb = (StringBuffer)this.start;
                while (i > this.off){
                    if (!Character.isSpaceChar(sb.charAt(--i))){i++; break;}
                }
                break;
            }
            this.rlen = i - this.off;              // ln of trimmed pendings
        }
    }

    /**
     * Create a new piece if it is not already present.
     *
     * @param      pidx index in the array of pieces
     */

    private Piece newPiece(int pidx){
        Cdata qu = this.cptr;
        if (qu.pieces[pidx] == null){         // element not present
            qu.pieces[pidx] = new Piece();    // allocate it
        }
        return qu.pieces[pidx];
    }

    private static final int PKS_TRY   = 0;
    private static final int PKS_FLUSH = 1;
    private static final int PKS_BRK   = 2;
    private static final int PKS_INS   = 3;
    private static final int PKS_CUT   = 4;
    private static final String[] PKS_STAT = {
            "PKS_TRY","PKS_FLUSH","PKS_BRK",
            "PKS_INS","PKS_CUT"};
    private static final int REMSIZE   = 50; // size of cut buffers

    /**
     * Pack a sequence of pieces into the record as best as possible,
     * and wrap it if there is no room. It works as an automaton driven by
     * a sequence of pieces to be inserted and by the current status of
     * breaking and availability of space in the record.
     *
     * @param      n number of pieces
     * @param      m1 mode of first piece
     * @param      s1 string of first piece
     * @param      t1 its type
     * @param      o1 start index
     * @param      l1 its lenght
     * @param      m2 mode of second piece
     * @param      s2 string of second piece
     * @param      t2 its type
     * @param      o2 start index
     * @param      l2 its lenght
     */

    private void pack_rec(int n, int m1, Object s1, byte t1, int o1, int l1,
        int m2, Object s2, byte t2, int o2, int l2){
        Cdata   qu = this.cptr;
        int     i;
        int     l = 0;
        int     lt;
        int     s, brk;
        char[]  remnd, remins;               // indexes into remainders
        int     lrem, lr2;                   // remainder length
        int     m;
        Piece   pptr;
        int     pidx, p;
        int     state;

        if ((FL_C & this.trc) != 0){
            Trc.out.println("pack_rec n: " + n +
                " m1: " + m1 + " t1: " + t1 +
                " o1: " + o1 + " l1: " + l1 +
                " m2: " + m2 + " t2: " + t2 +
                " o2: " + o2 + " l2: " + l2 +
                " lastbrk: " + this.lastbrk);
        }
        if ((o1 + l1 < 0) || (o2 + l2 < 0)){
            error(IOError.ERR_OUTLIMIT);
        }
        if (qu.pieces == null){               // pieces array not present
            qu.pieces = new Piece[10];        // allocate it
        }
        remins = null;
        pidx = 0;                             // build array of pieces
        i = 0;
        while (i < n){
            pptr = newPiece(pidx);
            pptr.mode = (i==0) ? m1 : m2;
            if ((PK_MAIN & pptr.mode) != 0){
                if (this.pendLength > 0){          // pendings
                    if ((FL_C & this.trc) != 0){
                        Trc.out.println("auto-ins pending");
                    }
                    m = pptr.mode;
                    pptr.mode = (this.penddis) ? PK_DIS : PK_PEN;
                    pptr.def(this.pend,FRM_CHARS,0,
                        this.pendLength,true);
                    pidx++;
                    if (this.pendnl){              // flush after it
                        pptr = newPiece(pidx);
                        pptr.mode = PK_NL;
                        pptr.def(EMPTY_STR,FRM_CHARS,0,0,false);
                        pidx++;
                    }
                    pptr = newPiece(pidx);
                    pptr.mode = m;
                }
            }
            if ((FL_C & this.trc) != 0){
                Trc.out.println("pack_rec i: " + i);
            }
            pptr.def(
                ((i==0) ? s1 : s2),                // start
                ((i==0) ? t1 : t2),                // type
                ((i==0) ? o1 : o2),                // offset
                ((i==0) ? l1 : l2),                // len
                    !((PK_MAIN & pptr.mode) != 0)
                );
            if ((PK_MAIN & pptr.mode) != 0){       // main piece
                if ((this.insert) && (this.cursor  // insert in the middle
                    < this.max)){
                    lr2 = 0;
                    if ((this.cursor < this.lastbrk) &&  // there is a break
                        (this.lastbrk < this.max)){      // ..  in remainder
                        lr2 = this.max - this.lastbrk;
                    }
                    lrem = this.max - this.cursor;
                    if (lrem <= REMSIZE){
                        if (qu.reminsb == null){
                            qu.reminsb = new char[REMSIZE];
                        }
                        remins = qu.reminsb;
                    } else {
                        remins = new char[lrem];         // allocate it
                    }
                    cut_rec(this.cursor,this.max,remins,lrem);
                    lrem -= lr2;
                    pidx++;
                    pptr = newPiece(pidx);
                    pptr.mode = PK_BRK;
                    pptr.def(remins,FRM_CHARS,0,lrem,true);
                    if (lr2 > 0){
                        pidx++;
                        pptr = newPiece(pidx);
                        pptr.mode = PK_BRK;
                        pptr.def(remins,FRM_CHARS,lrem,lr2,true);
                    }
                } else {                                 // ov/strike or ins end
                    if (this.cursor < this.max){         // insert in the middle
                        this.max = this.cursor;          // del overwr. remainder
                        if (this.lastbrk > this.cursor){ // and also break point
                            this.lastbrk = 0;
                        }
                        pptr.mode = 0;
                    }
                }
            }
            i++;
            pidx++;
        }
        if ((FL_C & this.trc) != 0){
            for (p = 0; p < pidx; p++){
                pptr = qu.pieces[p];
                Trc.out.println(" piece: " + p + " |" +
                    String.valueOf(makeString(
                        pptr.start,pptr.type,pptr.off,pptr.rlen)) +
                    "| rlen: " + pptr.rlen +
                    " mode " + Integer.toHexString(pptr.mode) +
                    " space: " + (this.end - this.cursor));
            }
        }

        remnd = null;
        lt = this.tailLength;
        p = 0;
        brk = 0;
        if (this.lastbrk <= this.cursor) brk = this.lastbrk;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("brk: " + brk);
        }
        state = PKS_TRY;
        auto: do {
            pptr = qu.pieces[p];
            if ((FL_C & this.trc) != 0){
                Trc.out.print("pack_rec: state: " +
                    PKS_STAT[state]);
                if (p < pidx){
                    Trc.out.print(" piece: |" +
                        String.valueOf(makeString(
                            pptr.start,pptr.type,pptr.off,pptr.rlen)) +
                        "| rlen: " + pptr.rlen +
                        " mode " + Integer.toHexString(pptr.mode) +
                        " space: " + (this.end - this.cursor));
                }
                Trc.out.println();
            }
            done: switch (state){
            case PKS_TRY:
                if (p >= pidx) break auto;
                l = pptr.len;
                if ((this.wrap) && this.newcont){   // at beg. of contin. line
                    startline(false);               // flush and head
                }
                if ((PK_NL & pptr.mode) != 0){      // flush (n.b. after
                    state = PKS_FLUSH;              // ..  startline)
                    break done;
                }
                if (this.cursor <= this.end - pptr.len){  // enough space
                    state = PKS_INS;
                    break done;
                }
                if ((PK_DIS & pptr.mode) != 0){     // break-disappear
                    this.pendLength = 0;            // de-register pendings
                    this.pendnl = false;
                    state = PKS_FLUSH;
                    break done;
                }
                if (p + 1 < pidx){                  // followed by a piece
                    if (this.cursor <= this.end     // it fits with trailing ..
                        - pptr.rlen - lt){          // .. blanks removed
                        l = this.end - this.cursor; // occupy till the end to ..
                        state = PKS_INS;            // .. make the following
                        break done;                 // .. wrap
                    }
                }
                if ((PK_BRK & pptr.mode) == 0){     // break before not allowed
                    state = PKS_CUT;
                    break done;
                }
                state = PKS_BRK;
                break done;
            case PKS_FLUSH:
                try {
                    endline();                      // insert tail successful
                    rec_emit();                     // flush record
                    p++;
                    state = PKS_TRY;
                    brk = 0;
                    break done;
                } catch (FormatterError e){
                }
                this.res = 0;                       // nospace: try a larger
                state = PKS_CUT;                    // ..  break
                break done;
            case PKS_BRK:
                try {
                    endline();                      // insert tail successful
                } catch (FormatterError e){
                }
                if (this.res == 0){
                    startline(true);                // flush and head
                    brk = 0;
                    if (((PK_DIS | PK_NL) & pptr.mode) != 0){
                        p++;
                        state = PKS_TRY;
                    } else {
                        state = PKS_INS;
                    }
                    break done;
                }
                this.res = 0;                       // nospace: try a larger
                state = PKS_CUT;                    // .. break
                break done;
            case PKS_CUT:
                if (brk == 0){                      // show the error
                    state = PKS_INS;
                    break done;
                }
                l = this.max - brk;
                if (l <= REMSIZE){
                    if (qu.remndb == null){
                        qu.remndb = new char[REMSIZE];
                    }
                    remnd = qu.remndb;
                } else {
                    remnd = new char[l];            // allocate it
                }
                cut_rec(brk,this.max,remnd,l);      // save it
                endline();                          // try again now
                startline(true);                    // flush and head
                set_carriage('n');                  // avoid a second ff
                ins_rec(remnd,FRM_CHARS,0,l);       // insert remainder
                remnd = null;
                brk = 0;
                pptr.mode |= PK_BRK;
                if ((PK_NL & pptr.mode) != 0){
                    try {
                        endline();
                    } catch (FormatterError e){
                        break auto;                 // unsuccessful
                    }
                    rec_emit();                     // flush record
                    p++;
                    state = PKS_TRY;
                    break done;
                }
                if ((PK_DIS & pptr.mode) == 0){     // try now with this
                    state = PKS_TRY;                // ..  new record
                    break done;
                }
                l = pptr.len;
                state = PKS_INS;
                break done;
            case PKS_INS:
                if ((PK_BRK & pptr.mode) != 0){     // break before it allowed
                    brk = this.cursor;              // remember break
                }
                if ((PK_DIS & pptr.mode) != 0){     // break-disappear
                    this.lastdis = this.cursor;     // remember it
                    this.dislen = pptr.len;
                }
                if ((PK_MAIN & pptr.mode) != 0){
                    rec_ins();
                } else {
                    ins_rec(pptr.start,pptr.type,pptr.off,l); // insert piece
                    if (((PK_PEN|PK_DIS) & pptr.mode) != 0){  // pending piece
                        this.pendLength = 0;                  // de-register it
                        this.pendnl = false;
                    }
                }
                p++;
                state = PKS_TRY;
                break done;
            }
            if ((FL_C & this.trc) != 0){
                Trc.out.println("pack_rec: next state: " +
                    PKS_STAT[state] + " cur: " + this.cursor);
            }
        } while (true);
    }


    /* Initialization and termination */

    /**
     * Initialize the object.
     */

    protected void init_cbk(){
        Cdata    qu = this.cptr;
        char[]   buffer = null;
        int      length = 0;
        Object   file   = null;
        boolean  listing = false;
        boolean  append = false;

        excInit();
        this.errthrow = 1;
        qu.pfor++;

        frmGetQuals(INIT_QUALS);
        if ((qualMap['j'] & qu.pres) != 0){       // set error handling
            if ((qualMap['-'] & qu.pres) != 0){
                this.errthrow = 0;
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("on error return status");
                }
            } else if ((qualMap['+'] & qu.pres) != 0){
                this.errthrow = 2;
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("on error abort");
                }
            }
        }
        if ((qualMap['s'] & qu.pres) != 0){       // output to a string
            file = null;
            getval(FRM_CHARS);                    // external record
            buffer = (char[])(qu.val_obj);
            length = qu.sliceLength;
        } else {
            listing = (qualMap['l'] & qu.pres) != 0;
            if (getElemType() != FRM_OBJ){        // file
                append = ((qualMap['a'] & qu.pres) != 0);
                file = valString();
            } else {
                getval(FRM_OBJ);                  // file argument
                file = qu.val_obj;
            }
            nextArg();
            getval(FRM_INT);                      // record length
            length = qu.val_int;
        }
        initialize(buffer,length,file,append,listing);
        this.closed = false;
    }

    private static final long[] INIT_QUALS =
        {qualSet("j"),qualSet("sl"),qualSet("a"),qualSet("+-")};

    /**
     * Initialize the object.
     *
     * @param      buf text record
     * @param      len its length
     * @param      fil output stream
     * @param      app true to open the stream in append
     * @param      lis true if listing file
     */

    private void initialize(char[] buf, int len, Object fil,
        boolean app, boolean lis){

        this.match = 0;
        this.inusrins = false;
        this.inusrhdr = false;
        this.flush = false;
        this.grow = false;
        this.firstio = true;             // no io done on the page
        this.iscol0 = true;              // carriage at column 0
        this.newcont = false;            // first line is not continuation
        this.pendff = false;             // no pending form feed
        this.remtrail = false;           // trailing blanks not removed
        this.prefix = "";
        this.suffix = "";
        this.linnr = 1;
        this.pageh = 0;                  // no paging
        this.pagnr = 1;
        this.pagns = 1;
        this.curLineSep = lineSep;
        this.head = EMPTY_STR;
        this.headLength = 0;
        this.tail = EMPTY_STR;
        this.tailLength = 0;
        this.indent = 0;
        this.insert = false;             // overstrike mode
        this.wrap = false;               // no wrap mode
        this.evid = false;               // default no overflow evident.
        this.penddis = false;
        this.pendnl = false;
        this.breakon = true;             // breaks enabled
        this.breakdef = false;           // no breaks deferred
        this.dislen = 0;
        this.pend = null;
        this.pendLength = 0;
        this.locNum = 0;
        this.locArr = null;
        this.nlArr = null;
        this.resArr = null;
        this.bunArr = null;
        this.locFixed = false;
        this.lang = null;

        this.file = null;
        this.listing = false;
        this.path = "";
        this.openfile = false;
        if (fil == null){                // text record on a string
            this.buffer = buf;
            this.length = len;
            if (this.buffer == null){    // no record
                error(ERR_NOREC);
            }
            if (this.length > this.buffer.length){
                error(ERR_VALUE);
            }
        } else {
            Class c = fil.getClass();
            if (c == String.class){
                this.path = (String)fil;
                try {
                    this.file = new IoStream();
                    int mode = IoStream.WRITE;
                    if (app) mode = IoStream.APPEND;
                    this.file.open(this.path,mode | IoStream.CHARS);
                    if ((this.file.getMode() & IoStream.AUTOFLUSH) != 0){
                        this.flush = true;
                    }
                    this.openfile = true;
                } catch (IOError exc){
                    error(ERR_ILLFILE,exc);
                }
            } else {
                if (fil instanceof IoStream){
                    this.file = (IoStream)fil;
                    this.path = this.file.getPath();
                    this.curLineSep = this.file.getLineSep();
                } else {
                    try {
                        this.file = new IoStream();
                        this.file.open(this.path,fil,IoStream.WRITE);
                        this.path = this.file.getPath();
                    } catch (IOError exc){
                        error(ERR_ILLFILE,exc);
                    }
                }
                if ((this.file.getMode() & IoStream.AUTOFLUSH) != 0){
                    this.flush = true;
                }
            }
            this.length = len;
            this.buffer = new char[this.length];            // allocate it
            this.listing = lis;
        }
        rec_init();
        if (this.tabs != null){
            if (this.tabs.length != (this.length+8)/8){
                this.tabs = null;
            } else {
                clearFromTab(0);
            }
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("initialized on " +
                ((fil != null)? fil.toString()+ " " + fil.getClass():
                "string") + " length: " + this.length  +
                " " + this.path);
        }
    }

    /**
     * Terminate the object. It frees all dynamic memory and leaves
     * null in the pointers.
     */

    protected void term_cbk(){
        Cdata qu = this.cptr;
        qu.pfor++;                            // skip code
        terminate();
    }

    /**
     * Terminate the object. It frees all dynamic memory and leaves
     * null in the pointers.
     */

    protected void terminate(){
        flush_rec(true);                      // flush the record
        if (this.file != null){               // output on file
            this.cursor = this.max = 0;
        }
        this.buffer = null;
        this.tabs = null;
        this.head = null;
        this.tail = null;
        this.closed = true;
        if ((FL_B & this.trc) != 0){
            Trc.out.println("terminated");
        }
    }

    /**
     * Ensure that the object is flushed and the system resources freed.
     */

    protected void finalize() throws Throwable {
        super.finalize();
        if (this.buffer != null){             // still alive
            flush_rec(true);                  // flush the record
        }
    }

    /* Format-text and conv-clauses callbacks */

    /**
     * Process a format-text.
     */

    protected void text_cbk(){
        Cdata qu = this.cptr;
        int   startf, endf;
        int   width, i;
        char  c;

        if ((FL_C & this.trc) != 0){
            Trc.out.println("text: for: " + qu.pfor);
        }
        if ((FL_D & this.trc) != 0){
            Trc.out.println("text: nest: " + qu.nest);
        }

        startf = qu.pfor;                            // save the start
        width = 0;                                   // count extra %'s
        for (; qu.pfor < qu.forLength; qu.pfor++){   // seek the end
            c = qu.formt[qu.pfor];
            if ((c == '\n') || (c == '\f')) break;
            if (c == '%'){
                if (qu.formt[qu.pfor+1] != '%') break;
                qu.pfor++;
                width++;                             // count extra %'s
            }
        }
        endf = qu.pfor;                              // end of text
        doit: {
            if (qu.repfact < 0){                     // in a parens-clause
                qu.repfact = -qu.repfact;
                if ((qu.formt[qu.pfor] != '%') ||
                    ((qu.pfor < qu.forLength) &&
                    (qu.formt[qu.pfor+1] != ')'))){  // not only text in it
                    qu.pfor = startf;                // restore it
                    break doit;
                }
                qu.pfor += 2;                        // skip %)
            }
            if ((FL_D & this.trc) != 0){
                Trc.out.println("text: for: " +
                    startf + " .. " + qu.pfor +
                    " w: " + width);
            }

            frmGetQuals(null);
            qu.mode = (width != 0) ? REDPERC : 0;
            insert(qu.formt,FRM_CHARS,startf,endf-startf,
                qu.repfact);                         // insert in record
            qu.repfact = 0;
        }
    }

    /**
     * Process clauses for integer values.
     * The values taken from the io list are converted into the largest
     * integer (or unsigned) size available in order to extract the
     * digits without causing overflow. The thousands separator is
     * obtained from the current locale.
     */

    /*
     * To convert values, they are promoted to longs depending on the
     * interpretation as signed or unsigned integers. In the unsigned
     * case, the bits which did not exist in the original values are
     * cleared. To cater for long unsigned values, when a value is
     * lower than zero, it is first divided by the base in unsigned
     * arithmetic (i.e. if the base is a power of two, it is logically
     * shifted, and if the base is ten, it is shifted by one and then
     * divided by five). This leads to a number which is positive, for
     * which the subsequent divisions and remainders produce positive
     * values.
     * The type of the value is that of the io list elements, which can
     * also be casted if needed. E.g. (byte)123 for literals, which are
     * of type int othewise.
     * The thousands separators are included for all bases because it is
     * meaningful also for non-decimal bases. All locales have one defined.
     *
     * The minimum length of the allocated external representation is such
     * as to hold the longest integer including sign, grouping, etc.
     * For Big numbers, a special check is done.
     */

    protected void int_cbk(){
        Cdata    qu = this.cptr;
        char     code;
        char     radix;                        // radix of conversion
        char     base;                         // base of number
        int      ep;                           // index in external rep.
        int      epFirst;                      // index of first digit
        long     v = 0;                        // value to be converted
        int      grSize;                       // grouping size
        char     minusSign;                    // minus sign
        char     zeroDigit;                    // first digit
        byte     valtype;
        int      i;
        int      nd = 0;
        long     ba = 0;
        long     rem;
        long     vv = 0;
        boolean  negative;
        char     first;
        int      grCount;
        int      hex = 0;
        int      ermin;
        char     groupSep;
        String   big = null;
        LocNumData locData = null;

        code = qu.formt[qu.pfor++];
        frmGetQuals(INT_QUALS);
        base = 'd';
        if ((qualMap['h'] & qu.pres) != 0){          // insert base
            base = 'h';
        }
        radix = 'd';                                 // default base
        if (qu.kind != ' ') radix = qu.kind;

        handleLocale('n');                           // obtain locale
        locData = this.nlArr[this.locNum];
        groupSep = locData.groupSep;
        if ((qualMap['L'] & qu.pres) != 0){          // ASCII only
            if (groupSep == '\u00a0'){
                groupSep = ' ';
            }
        }
        grSize = locData.groupSize;
        minusSign = locData.minusSign;

        if ((qualMap['\''] & qu.pres) == 0){
            groupSep = '\0';                          // no thousands separator
            grSize = Integer.MAX_VALUE;               // never insert
        }
        if (qu.nfill == '0') qu.nfill = locData.zeroDigit; // locale one

        while (qu.repfact-- > 0){
            ermin = 0;
            if (code == 'j'){
                v = getElemIndex();
                valtype = -1;                         // skip switch
            } else {
                valtype = getElemType();
            }
            switch (valtype){
            case -1: break;
            case FRM_BYTE:
                getval(FRM_BYTE);
                v = qu.val_byte;
                if (code == 'u') v &= 0xffL;
                break;
            case FRM_CHAR:
                getval(FRM_CHAR);
                v = qu.val_char;
                v &= 0xffffL;                         // always unsigned
                break;
            case FRM_SHORT:
                getval(FRM_SHORT);
                v = qu.val_short;
                if (code == 'u') v &= 0xffffL;
                break;
            case FRM_INT:
                getval(FRM_INT);
                v = qu.val_int;
                if (code == 'u') v &= 0xffffffffL;
                break;
            case FRM_BIGINT:
                getval(FRM_BIGINT);
                big = ((BigInteger)(qu.val_obj)).toString();
                ermin = big.length();
                if (grSize != Integer.MAX_VALUE){    // grouping
                    ermin += (ermin + grSize - 1) / grSize;
                    if (ermin < 0) error(IOError.ERR_OUTLIMIT);
                }
                ermin += 3;                          // sign and base
                if (ermin < 0) error(IOError.ERR_OUTLIMIT);
                v = ((BigInteger)(qu.val_obj)).longValue();
                break;
            default:
                getval(FRM_LONG);
                v = qu.val_long;
                break;
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("value: " + v);
            }
            ensure_extRep(qu.minw,ermin);            // ensure large enough
            if ((FL_D & this.trc) != 0){
                Trc.out.println("code " + code +
                    " radix " + radix + " base " + base +
                    " erLength " + qu.erLength);
            }
                                                     // build the external repr.
                                                     // convert into digits
            ep = qu.erLength;
            switch (radix){                          // determine base and
            case 'b': ba = 2; break;                 // .. nr of digits
            case 'o': ba = 8; break;
            case 'd': ba = 10; break;
            case 'x': ba = 16;
                hex = 'a' - 10; break;
            case 'X': ba = 16;
                hex = 'A' - 10; break;
            }
            negative = false;
            if (code == 'i'){
                if (v < 0){                          // make it positive
                    negative = true;
                    v = -v;
                }
            }
            convert:
            if ((radix == 'r') || (radix == 'R')){
                if (v >= 200000) error(ERR_VALUE);
                ep = int_roman((int)v,radix,qu.extRep);
                if (negative && !locData.minusPref){ // include suffix sign
                    qu.extRep[ep++] = minusSign;
                }
                System.arraycopy(qu.extRep,0,        // shift it
                    qu.extRep,qu.erLength-ep,ep);
                ep = qu.erLength-ep;
                grSize = Integer.MAX_VALUE;          // never insert
                grCount = grSize;
            } else if (valtype == FRM_BIGINT){
                int off = 0;
                nd = big.length();
                int len = nd;
                negative = false;
                if (((BigInteger)(qu.val_obj)).signum() < 0){
                    negative = true;
                    off = 1;
                    nd--;
                }
                if (negative && !locData.minusPref){ // include suffix sign
                    qu.extRep[--ep] = minusSign;
                }
                grCount = grSize;
                for (int j = len-1; j >= off; j--){
                    if (grCount-- == 0){
                        qu.extRep[--ep] = groupSep;
                        grCount = grSize-1;
                    }
                    rem = big.charAt(j) - '0';
                    qu.extRep[--ep] = (char)(rem +
                        ((rem <= 9) ? locData.zeroDigit : hex));
                }
            } else {
                if (negative && !locData.minusPref){ // include suffix sign
                    qu.extRep[--ep] = minusSign;
                }
                first = ' ';
                if (v < 0){                          // first unsigned
                    vv = v;                          // division and
                    v >>>= 1;                        // remainder
                    v /= (ba>>>1);
                    i = (int)(vv - (v * ba));
                    first = (char)(i + ((i <= 9) ? locData.zeroDigit : hex));
                } 
                if ((FL_D & this.trc) != 0){
                    Trc.out.println("v: " + v + " vv " +
                        vv + " first " + first);
                }
                grCount = grSize;
                if ((FL_D & this.trc) != 0){
                    Trc.out.println("grCount: " + grCount);
                }
                nd = 0;
                if (first != ' '){
                    if (grCount-- == 0){
                        qu.extRep[--ep] = groupSep;
                        grCount = grSize-1;
                    }
                    qu.extRep[--ep] = first;
                    nd++;
                }
                do {
                    if (grCount-- == 0){
                        qu.extRep[--ep] = groupSep;
                        grCount = grSize-1;
                    }
                    rem = (int)(v % ba);             // remainder
                    qu.extRep[--ep] = (char)(rem +
                        ((rem <= 9) ? locData.zeroDigit : hex));
                    nd++;
                    v /= ba;
                } while (v > 0);
            }
            if ((FL_D & this.trc) != 0){
                Trc.out.println("rep: |" +
                    String.valueOf(qu.extRep,ep,qu.erLength-ep) +
                    "| base: " + ba + " nd: " + nd);
            }
            if (qu.integral > 0){                    // padding
                if (Character.isSpaceChar(qu.nfill)){
                    grSize = Integer.MAX_VALUE;      // never insert
                    grCount = grSize;
                }
                int fill = qu.integral-nd;
                for (; fill > 0; fill--){            // leading fillers
                    if (grCount-- == 0){
                        qu.extRep[--ep] = groupSep;
                        grCount = grSize-1;
                        if (fill-- == 0) break;
                    }
                    qu.extRep[--ep] = qu.nfill;
                }
            }
            epFirst = ep;
            if (base != 'd'){                        // include base
                switch (radix){
                case 'o': case 'x': case 'X':
                    if (radix != 'o'){
                       qu.extRep[--ep] = radix;
                    }
                    qu.extRep[--ep] = '0';
                }
            }
            if (negative){                           // include sign
                if (locData.minusPref){
                    qu.extRep[--ep] = minusSign;
                }
            } else if (qu.sign == '+'){
                qu.extRep[--ep] = '+';
            }
            if ((FL_D & this.trc) != 0){
                Trc.out.println("rep now: |" +
                    String.valueOf(qu.extRep,ep,qu.erLength-ep) +
                    "|");
                Trc.out.println("minusPref: " + locData.minusPref +
                    " loc: " + this.locNum + " grSize: " + grSize);
            }
            qu.preflen = epFirst - ep;
            qu.mode = 0;
            insert(qu.extRep,FRM_CHARS,          // ins. in record
                ep,qu.erLength-ep,1);
        }
    }

    private static final long[] INT_QUALS =
        {qualSet("+hnfpL"),qualSet("bodxXrR"),qualSet("'^"),qualSet("aA"),
        qualSet("zZ"),qualNum("i."),qualNum("n:m"),qualNum("$")};


    /**
     * Convert a number in a roman one. The highest roman figure used
     * is 100000, and thus if the number has more than 5 digits, that
     * figure is repeated several times.
     *
     * @param      n number
     * @param      radix 'r' if lowercase roman figures, else uppercase
     * @param      extRep array in which the number is returned
     * @return     lenght of the number returned
     */

    private int int_roman(int n, char radix, char[] extRep){
        int      i, next;
        int      rem, base;
        int      ep;
        String[] letter;
        int      len;

        i = 0;
        base = 100000;
        ep = 0;
        if (radix == 'r') letter = ROMAN_LLETTER;
        else letter = ROMAN_ULETTER;
        while (true){
            while (n >= base){
                len = letter[i].length();
                letter[i].getChars(0,len,extRep,ep);
                ep += len;
                n -= base;
            }
            if (n <= 0) return ep;           // exhausted
            next = i + 1;
            rem = base / ROMAN_BASE[next-1];
            if (ROMAN_BASE[next-1] == 2){
                next++;
                rem = rem / ROMAN_BASE[next-1];
            }
            if (n + rem >= base){            // subtractive form
                len = letter[next].length();
                letter[next].getChars(0,len,extRep,ep);
                ep += len;
                n += rem;
            } else {                         // normal form
                i++;
                base = base / ROMAN_BASE[i-1];
            }
        }
    }

    private static final String[] ROMAN_LLETTER =
        {"(((i)))","i)))","((i))","i))","m","d","c","l","x","v","i"};
    private static final String[] ROMAN_ULETTER =
        {"(((I)))","I)))","((I))","I))","M","D","C","L","X","V","I"};
    private static final int[]  ROMAN_BASE  = {2,5,2,5,2,5,2,5,2,5,2};


    /**
     * Ensure that the array of locale data contains the data for the
     * current locale. If there is no array, it allocates one. If the
     * array is too short, it extends it. If the needed entry is null
     * it allocates the element.
     *
     * @param      n for numbers
     *             d for DateFormatter
     */

    void handleLocale(char t){
        int     arrSize;
        boolean newloc = false;

        arrSize = LOC_QUANTUM;
        if (this.locNum >= arrSize){
            arrSize = this.locNum + 1;
            if (arrSize < 0) error(IOError.ERR_OUTLIMIT);
        }
        if (t != 'd'){
            if (this.nlArr == null){                        // no locale array
                this.nlArr = new LocNumData[arrSize];
            } else if (this.nlArr.length <= this.locNum){   // short array
                LocNumData[] curnl = this.nlArr;
                int newlen = curnl.length + LOC_QUANTUM;
                if (newlen < 0) error(IOError.ERR_OUTLIMIT);
                LocNumData[] newnl = new LocNumData[newlen];
                System.arraycopy(curnl,0,newnl,0,curnl.length);
                this.nlArr = newnl;
            }
        }
        if (this.locNum == 0){                              // neutral
            if (this.locArr == null){
                this.locArr = new Locale[arrSize];
            }
            this.locArr[0] = Locale.US;
        }
        Locale curr = null;
        if (this.locNum == 1){                              // default one
            curr = getDefault();
            newloc = curr != this.locArr[1];                // fast test
        } else {
            curr = this.locArr[this.locNum];
        }
        if (t != 'd'){
            if ((this.nlArr[this.locNum] == null) ||        // nl entry null
                ((this.locNum == 1) &&                      // .. or default
                newloc)){                                   // .. changed
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("handleLocale: " + curr);
                }
                NumberFormat nf =
                    NumberFormat.getNumberInstance(curr);
                DecimalFormatSymbols ds =
                    new DecimalFormatSymbols(curr);
                if (nf.getClass() != DecimalFormat.class){
                    this.nlArr[this.locNum] = new LocNumData(null,ds);
                } else {
                    this.nlArr[this.locNum] =
                        new LocNumData((DecimalFormat)(nf),ds);
                }
            }
        }
        if (newloc){                                         // default changed
            this.locArr[1] = curr;
            invalidateRes();
        }
    }

    /** The allocation quantum. */
    private static final int LOC_QUANTUM = 4;

    /**
     * Invalidate the resources bundles present in the resource array.
     */

    private void invalidateRes(){
        if (this.resArr == null) return;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("recources invalidated");
        }
        for (int i = 0; i < this.resArr.length; i++){
            if (this.resArr[i] != null){
                this.resArr[i] = INV_RES;
            }
        }
    }

    /**
     * An invalid bundle.
     */

    private static class InvBundle extends ListResourceBundle {
        public Object[][] getContents() {
            return null;
        }
    }

    /**
     * The invalid bundle.
     */

    private static ResourceBundle INV_RES = new InvBundle();

    /**
     * Deliver the default locale, which is the real default one
     * unless it has been fixed.
     *
     * @return     locale
     */

    private Locale getDefault(){
        if (this.locFixed){
            return this.locArr[1];
        } else if (this.lang != null){
            return this.lang.getDefault();
        } else {
            return Locale.getDefault();
        }
    }

    /**
     * Process the clauses for real numbers.
     */

    protected void float_cbk(){
//        FormFloat.float_cbk(this);
        float_cbk(this);
    }

    /**
     * Process the clause for boolean values.
     */

    protected void bool_cbk(){
        Cdata    qu = this.cptr;
        char     code;
        String   ep = null;
        boolean  v;                              // value to be converted

        code = qu.formt[qu.pfor++];
        frmGetQuals(BOOL_QUALS);
        if ((FL_D & this.trc) != 0)
            Trc.out.println("code " + code +
                " kind " +  qu.kind);
        while (qu.repfact-- > 0){
            getval(FRM_BOOL);
            v = qu.val_bool;
            if ((FL_B & this.trc) != 0)
                Trc.out.println("value: " + v);
            switch (qu.kind){                    // build the external repr.
            case 'b':
                ep = v ? "1" : "0"; break;
            case 'T':
                ep = v ? "TRUE" : "FALSE"; break;
            case 'y':
                ep = v ? "yes" : "no"; break;
            case 'Y':
                ep = v ? "YES" : "NO"; break;
            case 'o':
                ep = v ? "on" : "off"; break;
            case 'O':
                ep = v ? "ON" : "OFF"; break;
            case 't':
            default:
                ep = v ? "true" : "false"; break;
            }
            qu.mode = 0;
            insert(ep,FRM_STRING,0,ep.length(),1); // insert in record
        }
    }

    private static final long[] BOOL_QUALS =
        {qualSet("np"),qualSet("btTyYoO"),qualSet("A"),
        qualSet("zZ"),qualNum("n:m"),qualNum("$")};

    /**
     * Process the clauses for character and string values.
     */

    protected void str_cbk(){
        Cdata    qu = this.cptr;
        char     code;
        Object   v;                            // argument value
        int      len = 0;
        String   str = null;
        byte     valtype;
        int      start = 0;
        int      bin = 0;
        int      pfor = qu.pfor;               // index of code in format

        code = qu.formt[qu.pfor++];            // skip code
        getqual: {
            if (code == 'c'){
                frmGetQuals(CHAR_QUALS);
            } else {
                int savepfor = qu.pfor;
                int saveend = qu.endQuals;
                try{
                    frmGetQuals(STR_QUALS);    // parse it to test then
                } catch (FormatterError e){    // .. the element type having
                }                              // .. processed $x clauses
                valtype = getElemType();
                switch (valtype){
                case FRM_CHAR:
                case FRM_STRING:
                case FRM_STRBUF:
                case FRM_BYTES:
                case FRM_CHARS:
                case FRM_OBJ:
                    if (this.res != 0){
                        error(this.res);
                    }
                    break;
                default:
                    qu.pfor = savepfor;
                    qu.endQuals = saveend;
                    break getqual;
                }
            }
            qu.mode = 0;
            bin = 0;
            if (((qualMap['b'] & qu.pres) != 0) ||
                ((qualMap['B'] & qu.pres) != 0))
                bin = EXPBIN;                          // bit string
            if ((qualMap['o'] & qu.pres) != 0)
                qu.mode |= EXPOCT;                     // expand \ooo
            if ((qualMap['x'] & qu.pres) != 0)
                qu.mode |= EXPHEX;                     // expand \xnn
            if ((qualMap['U'] & qu.pres) != 0)
                qu.mode |= EXPUNI;                     // expand \u0000
            if ((qualMap['h'] & qu.pres) != 0)
                if ((qu.mode & EXPBIN) == 0)
                    qu.mode |= EXPHTML;                // expand html
            if ((qualMap['j'] & qu.pres) != 0){
                qu.mode |= JSTRLIT;
                if (((EXPOCT|EXPHEX|EXPUNI) & qu.mode) == 0)  // neither o nor x
                    qu.mode |= EXPUNI;
                if (code == 'c') qu.mode |= ENCLAPX;
                else qu.mode |= ENCLQUO;
            }
            if ((qualMap['e'] & qu.pres) != 0){
                qu.mode |= JSTRLIT;
                if (((EXPOCT|EXPHEX|EXPUNI) & qu.mode) == 0)  // neither o nor x
                    qu.mode |= EXPUNI;
            }
            if ((qualMap['r'] & qu.pres) != 0){
                qu.mode |= EXPNL;
            }
            if ((qualMap['l'] & qu.pres) != 0) qu.mode |= LOWCASE;
            if ((qualMap['u'] & qu.pres) != 0) qu.mode |= UPPCASE;
            if ((qualMap['t'] & qu.pres) != 0) qu.mode |= TITCASE;
        }
        while (qu.repfact-- > 0){
            int rep;
            qu.mode &= ~EXPBIN;
            v = null;
            valtype = getElemType();
            if ((FL_B & this.trc) != 0)
                Trc.out.println("valtype: " + valtype +
                    " pfor: " + qu.pfor);
            getval: if ((code == 's') && (valtype != FRM_CHAR)){
                switch (valtype){          // value from io list
                case FRM_STRING:
                case FRM_STRBUF:
                case FRM_BYTES:
                case FRM_CHARS:
                case FRM_OBJ:
                    if ((qualMap['m'] & qu.pres) == 0) break;
                    String key = valString();
                    str = getLizedStr(key);
                    v = str;
                    len = str.length();
                    start = 0;
                    valtype = FRM_STRING;
                    break getval;
                }
                makestr: switch (valtype){
                case FRM_BOOL:
                    qu.pfor = pfor;
                    rep = qu.repfact;
                    qu.repfact = 1;
                    bool_cbk();
                    qu.repfact = rep;
                    continue;
                case FRM_BYTE:
                case FRM_SHORT:
                case FRM_INT:
                case FRM_LONG:
                    qu.pfor = pfor;
                    rep = qu.repfact;
                    qu.repfact = 1;
                    int_cbk();
                    qu.repfact = rep;
                    continue;
                case FRM_FLOAT:
                case FRM_DOUBLE:
                    qu.pfor = pfor;
                    rep = qu.repfact;
                    qu.repfact = 1;
                    float_cbk();
                    qu.repfact = rep;
                    continue;
                case FRM_STRING:
                    getval(FRM_STRING);
                    v = qu.val_obj;
                    break;
                case FRM_STRBUF:
                    getval(FRM_STRBUF);
                    v = qu.val_obj;
                    break;
                case FRM_BYTES:
                    getval(FRM_BYTES);
                    v = qu.val_obj;
                    qu.mode |= bin;
                    break;
                case FRM_CHARS:
                    getval(FRM_CHARS);
                    v = qu.val_obj;
                    break;
                case FRM_DATE:
                    qu.pfor = pfor;
                    rep = qu.repfact;
                    qu.repfact = 1;
                    date_cbk();
                    qu.repfact = rep;
                    continue;
                case FRM_USER:
                    qu.pfor = pfor;
                    rep = qu.repfact;
                    qu.repfact = 1;
                    getval(FRM_OBJ);
                    ((Formatter.Api)(qu.val_obj)).format(this);
                    qu.repfact = rep;
                    continue;
                default:
                    getval(FRM_OBJ);
                    v = qu.val_obj;
                    len = 0;
                    valtype = FRM_STRING;
                    getstr: if (v != null){
                        if (qu.val_obj instanceof Throwable){
                            // this should be atomic, but there is no way
                            Locale.setDefault(getDefault());
                            str = ((Throwable)v).getLocalizedMessage();
                            if (str == null) str = ((Throwable)v).toString();
                            // end atomic region
                            v = str;
                            len = str.length();
                            break getstr;
                        }
                        Method m = null;
                        try {
                            Class<?> cl = v.getClass();
                            if (cl == String.class){
                                valtype = FRM_STRING;
                                if (qu.sliceLength < 0){    // not specified
                                    qu.sliceLength = ((String)v).length();
                                }
                                break makestr;
                            } else if (cl == StringBuffer.class){
                                valtype = FRM_STRBUF;
                                if (qu.sliceLength < 0){    // not specified
                                    qu.sliceLength = ((StringBuffer)v).length();
                                }
                                break makestr;
                            } else if (cl == byte[].class){
                                valtype = FRM_BYTES;
                                if (qu.sliceLength < 0){    // not specified
                                    qu.sliceLength = ((byte[])v).length;
                                }
                                qu.mode |= bin;
                                break makestr;
                            } else if (cl == char[].class){
                                valtype = FRM_CHARS;
                                if (qu.sliceLength < 0){    // not specified
                                    qu.sliceLength = ((char[])v).length;
                                }
                                break makestr;
                            }
                            m = cl.getMethod("toString",(Class[])null);
                        } catch (NoSuchMethodException e){
                        } catch (SecurityException e){
                        }
                        if (m.getDeclaringClass() != Object.class){
                            str = v.toString();
                            v = str;
                            len = str.length();
                        } else {
                            Class cl = v.getClass();
                            StringBuffer sb = new StringBuffer();
                            Field[] f = cl.getDeclaredFields();
                            for (int i = 0; i < f.length; i++){
                                sb.append(f[i].getName()).append(" = ");
                                try{
                                    sb.append(f[i].get(v).toString());
                                } catch (ExceptionInInitializerError exc){
                                } catch (IllegalAccessException exc){
                                }
                                if (i < f.length-1) sb.append(", ");
                            }
                            v = sb;
                            len = sb.length();
                            valtype = FRM_STRBUF;
                        }
                    } else {
                        v = EMPTY_STR;
                        valtype = FRM_CHARS;
                    }
                    if (qu.sliceLength >= 0){        // specified
                        if (qu.sliceStart+qu.sliceLength > len){
                            if ((FL_I & this.trc) != 0){
                                Trc.out.println("slice: " + qu.sliceStart +
                                   " " + qu.sliceLength + " " + len);
                            }
                            error(ERR_INDEX);
                        }
                        len = qu.sliceLength;
                        start = qu.sliceStart;
                    } else {
                        start = 0;
                    }
                    break getval;
                } // makestr
                if (v == null){                      // treat null as empty
                    v = EMPTY_STR;
                    len = 0;
                    start = 0;
                    valtype = FRM_CHARS;
                } else {
                    start = qu.sliceStart;
                    len = qu.sliceLength;
                }
            } else {                                 // character
                getval(FRM_CHAR);
                qu.extRep[0] = qu.val_char;
                v = qu.extRep;
                len = 1;
                valtype = FRM_CHARS;
                qu.mode |= bin;
            } // getval
            if ((FL_B & this.trc) != 0){
                Trc.out.println("value: " +
                    String.valueOf(makeString(v,valtype,start,len))
                        + " " + valtype);
            }
            insert(v,valtype,start,len,1);       // insert in record
        }
    }

    private static final long[] CHAR_QUALS =
        {qualSet("hdnp"),qualSet("oxbBU"),qualSet("jer"),qualSet("lut"),
        qualSet("A"),qualSet("zZ"),qualNum("n:m"),qualNum("$")};

    private static final long[] STR_QUALS =
        {qualSet("hdnpm"),qualSet("oxbBU"),qualSet("jer"),qualSet("lut"),
        qualSet("A"),qualSet("zZ"),qualNum("n:m"),qualNum("$")};

    /**
     * Obtain a string from the current resource bundle. Internal
     * method.
     *
     * @param      key string of the key
     * @return     localized string
     */

    public String getLizedStr(String key){
        String str = null;

        ResourceBundle res = null;
        try {
            res = getResource(this.resNum);
            str = res.getString(key);
        } catch (MissingResourceException exc){
            error(ERR_RESOURCE,exc,'"' + key +
                "\" " + this.bunArr[this.resNum]);
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("str: " + str + " " + this.locArr[1]);
        }
        return str;
    }

    /**
     * Obtains a string from the current resource bundle.
     *
     * @param      key string of the key
     * @return     localized string
     */

    public String getLizedString(String key){
        String str = null;
        ResourceBundle res = null;

        if ((FL_B & this.trc) != 0){
            Trc.out.println("key: " + key + " " + this.resNum);
        }
        excInit();
        try {
            res = getResource(this.resNum);
            str = res.getString(key);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (MissingResourceException exc){
            registerError(ERR_RESOURCE,exc);
            this.excObj.key = key +
                " " + this.bunArr[this.resNum];
        } catch (FormatterError exc){
        }
        excTerm();
        if ((FL_B & this.trc) != 0)
            Trc.out.println("str: " + str + " " + this.locArr[1]);
        return str;
    }

    /**
     * Process the clause for date values. It takes from the
     * format a string which is passed to strftime.
     */

    protected void date_cbk(){
        Cdata   qu = this.cptr;
        char    code;
        char    ch;
        boolean patt;                          // true if pattern mode
        DateFormat df;
        Date    date = null;

        code = qu.formt[qu.pfor++];
        ch = qu.formt[qu.pfor];
        patt = false;
        handleLocale('d');                     // obtain locale
        if (ch == 'P'){                        // pattern
            qu.pfor++;
            patt = true;
            qu.eptr = qu.extRep;
            qu.pfor = skip_format(F_SPEC,0,0);        // get pattern
            String str = String.valueOf(
                qu.extRep,0,qu.erLength);
            df = new SimpleDateFormat(str,
                this.locArr[this.locNum]);
            if ((FL_D & this.trc) != 0)
                Trc.out.println("date format: |" + str + "|");
        } else {
            int kindDate = -1;
            int kindTime = -1;
            getkind: for (int i = 1; i <= 2; i++){
                switch (ch){
                case 'd': kindDate = DateFormat.DEFAULT; break;
                case 's': kindDate = DateFormat.SHORT; break;
                case 'm': kindDate = DateFormat.MEDIUM; break;
                case 'l': kindDate = DateFormat.LONG; break;
                case 'f': kindDate = DateFormat.FULL; break;
                case 'D': kindTime = DateFormat.DEFAULT; break;
                case 'S': kindTime = DateFormat.SHORT; break;
                case 'M': kindTime = DateFormat.MEDIUM; break;
                case 'L': kindTime = DateFormat.LONG; break;
                case 'F': kindTime = DateFormat.FULL; break;
                default: break getkind;
                }
                qu.pfor++;
                if ((i == 1) && (qu.formt[qu.pfor] == ch)){   // repeated
                    break getkind;
                }
                ch = qu.formt[qu.pfor];
            }
            if ((kindDate == -1) && (kindTime == -1)){
                kindDate = DateFormat.DEFAULT;
            }
            frmGetQuals(DATE_QUALS);
            if ((kindDate >=0) && (kindTime >= 0)){
                df = DateFormat.getDateTimeInstance(
                    kindDate,kindTime,this.locArr[this.locNum]);
            } else if (kindDate >=0){
                df = DateFormat.getDateInstance(
                    kindDate,this.locArr[this.locNum]);
            } else {
                df = DateFormat.getTimeInstance(
                    kindTime,this.locArr[this.locNum]);
            }
        }
        while (qu.repfact-- > 0){
            getval(FRM_DATE);                  // date value
            date = (Date)qu.val_obj;
            String ep = df.format(date);
            if ((FL_B & this.trc) != 0)
                Trc.out.println("inserting date-time: " + ep);
            qu.mode = 0;
            insert(ep,FRM_STRING,0,ep.length(),1); // insert in record
        }
    }

    private static final long[] DATE_QUALS =
        {qualSet("np"),qualSet("A"),qualSet("zZ"),
        qualNum("n:m"),qualNum("$")};

    /**
     * Process the clause for reference values.
     */

    protected void ptr_cbk(){
        Cdata    qu = this.cptr;
        char     code;
        String   cname = null;
        Object   v;
        int      ptr;
        int      rem;
        int      ep = 0;
        Class    cl;
        byte     valtype;
        int      pfor = qu.pfor;                   // index of code in format

        code = qu.formt[qu.pfor++];
        valtype = getElemType();
        if (valtype != FRM_USER){
            frmGetQuals(PTR_QUALS);
        }
        while (qu.repfact-- > 0){
            int rep;
            valtype = getElemType();
            if (valtype == FRM_USER){
                qu.pfor = pfor;
                rep = qu.repfact;
                qu.repfact = 1;
                getval(FRM_OBJ);
                ((Formatter.Api)(qu.val_obj)).format(this);
                qu.repfact = rep;
                continue;
            } else {
                getval(FRM_OBJ);
                v = qu.val_obj;
                if ((FL_B & this.trc) != 0)
                    Trc.out.println("value: " + v);
                cl = Object.class;
                if (v != null) cl = v.getClass();
                if ((qualMap['c'] & qu.pres) != 0){       // class name prefix
                    int cnlen;
                    cname = cl.getName();                 // class name
                    cnlen = cname.length();
                    int len = cnlen + 1 + 8;              // name@xxxxxx
                    ensure_extRep(len,0);
                    cname.getChars(0,cnlen,qu.extRep,0);
                    qu.extRep[cnlen] = '.';
                    ep = cnlen + 1;
                } else {
                    if ((qualMap['h'] & qu.pres) != 0){   // class address prefix
                        ptr = System.identityHashCode(cl);
                        ep = 0;
                        for (int i = 0; i < 8; i++){
                            rem = (ptr>>>((8-i-1)*4)) & 0xf;
                            qu.extRep[ep++] =
                                (char)(rem + ((rem <= 9) ? '0' : 'a' - 10));
                        }
                        qu.extRep[ep++] = '.';
                    }
                }
                qu.mode = 0;
                if (v == null){
                    if ((qualMap['o'] & qu.pres) != 0){    // insert in record
                        insert("0",FRM_STRING,0,1,1);
                    } else {
                        insert("null",FRM_STRING,0,4,1);
                    }
                } else {
                    ptr = System.identityHashCode(v);
                    for (int i = 0; i < 8; i++){
                        rem = (ptr>>>((8-i-1)*4)) & 0xf;
                        qu.extRep[ep++] =
                            (char)(rem + ((rem <= 9) ? '0' : 'a' - 10));
                    }
                    insert(qu.extRep,FRM_CHARS,0,ep,1); // insert in record
                }
            }
        }
    }

    private static final long[] PTR_QUALS =
        {qualSet("npo"),qualSet("ch"),qualSet("A"),
        qualSet("zZ"),qualNum("n:m"),qualNum("$")};


    /* Edit-clauses callbacks */

    /**
     * Process the clause for the insertion of blanks.
     */

    protected void blank_cbk(){
        Cdata  qu = this.cptr;
        int    width;

        qu.pfor++;
        width = frm_param(1,false);               // get width
        if ((FL_D & this.trc) != 0){
            Trc.out.println("insert blanks: " + width);
        }
        frmGetQuals(null);
        qu.mode = 0;
        insert(" ",FRM_STRING,0,1,width * qu.repfact);   // ins in rec
        qu.repfact = 0;
    }

    /**
     * Process the clauses that move the cursor.
     */

    protected void skip_cbk(){
        Cdata   qu = this.cptr;
        int     width, wid;
        int     i;
        char    code, mod;
        int     newcur;                        // new current in record
        boolean move;

        code = qu.formt[qu.pfor++];
        mod = ' ';
        switch (qu.formt[qu.pfor]){
        case '=': case '>': case '<':
        case 'c': case 'C': case 's':
        case '&': case '+': case '-':
            mod = qu.formt[qu.pfor++];
        }
        width = frm_param(-1,false);           // get width
        if ((FL_D & this.trc) != 0){
            Trc.out.println("skip: code " + code +
                " mod " + mod + " width " + width +
                " cur " + this.cursor);
        }
        while (qu.repfact-- > 0){
            wid = width;
            newcur = this.cursor;
            move = true;                       // a move cursor action
            endtab: switch (mod){
            case ' ':                          // tab absolute
                if (wid == -1) wid = 0;
                newcur = wid;                  // move the cursor
                qu.repfact = 0;                // no need to repeat
                break;
            case '+':                          // tab relative ahead
                if (wid == -1) wid = 1;
                newcur += wid;                 // new cursor
                if (newcur < 0) error(IOError.ERR_OUTLIMIT);
                break;
            case '-':                          // tab relative back
                if (wid == -1) wid = 1;
                newcur -= wid;                 // new cursor
                break;
            case '=':                          // set tab
                move = false;
                if (wid == -1){
                    wid = this.cursor;         // not specified: take current
                }
                if (wid > this.end){           // beyond end record
                    if (this.grow){
                        bufferExtend(wid-this.length);
                    } else {
                        error(ERR_OUTREC);
                    }
                }
                if (this.tabs == null){
                    this.tabs = new
                        byte[(this.length+8)/8];  // alloc/init lenght+1 tabs
                }
                assignTab(wid,true);
                if ((FL_B & this.trc) != 0)
                    Trc.out.println("tab set: " + wid);
                qu.repfact = 0;                // no need to repeat
                break;
            case 's':                          // set repetitive tabs
                move = false;
                if (wid == -1) wid = 8;
                if (this.tabs == null){
                    if (this.length + 8 < 0) error(IOError.ERR_OUTLIMIT);
                    this.tabs = new
                        byte[(this.length+8)/8];  // alloc/init lenght+1 tabs
                }
                for (i = wid-1; i <= this.length; i += wid){
                    assignTab(i,true);
                    if ((FL_B & this.trc) != 0)
                        Trc.out.println("tab set: " + i);
                }
                qu.repfact = 0;                // no need to repeat
                break;
            case 'c':                          // clear tab
                move = false;
                if (wid > this.end){           // beyond end record
                    if (this.grow){
                        bufferExtend(wid-this.length);
                    } else {
                        error(ERR_OUTREC);
                    }
                }
                if (wid == -1){
                    wid = this.cursor;         // not specified: take current
                }
                if (this.tabs == null) break endtab;
                assignTab(wid,false);
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("tab cleared: " + wid);
                }
                qu.repfact = 0;                // no need to repeat
                break;
            case 'C':                          // clear tabs
                move = false;
                if (wid == -1) wid = 0;        // not specified: all tabs
                if (wid > this.end){           // beyond end record
                    if (this.grow){
                        bufferExtend(wid-this.length);
                    } else {
                        error(ERR_OUTREC);
                    }
                }
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("tabs cleared from: " + wid);
                }
                if (this.tabs == null) break endtab;
                clearFromTab(wid);
                qu.repfact = 0;                // no need to repeat
                break;
            case '>':                          // move to next tab
            case '&':                          // move to tab
                if (wid == -1) wid = 1;
                if (mod == '>'){
                    if (wid == 0) break endtab;
                } else {
                    if (wid == 0) wid = 1;     // first tab
                }
                if (this.tabs == null){        // no next tab
                    newcur = this.max;
                    break endtab;
                } else {
                    if (mod == '>'){
                        newcur = this.cursor+1;   // from the next position on
                    } else {
                        newcur = 0;               // from the beginning
                    }
                }
                newcur = findTab(newcur,wid);  // find wid-th tab
                if (newcur < 0){               // tab not present
                    newcur = this.max;
                }
                break;
            case '<':                          // move to previous tab
                if (wid == -1) wid = 1;
                if (wid == 0) break endtab;
                if (this.tabs == null){        // no next tab
                    newcur = 0;
                    break endtab;
                } else {
                    newcur = this.cursor-1;    // from the previous pos. back
                }
                newcur = findTab(newcur,-wid); // find wid-th tab backwards
                if (newcur < 0) newcur = 0;    // tab not present
                break;
            }
            endtab:
            if ((FL_C & this.trc) != 0)
                Trc.out.println("tab to: " + newcur);
            if (newcur < 0){                   // out of record
                error(ERR_OUTREC);
            }
            if (newcur > this.end){
                if (this.grow){
                    bufferExtend(newcur-this.length);
                } else {
                    error(ERR_OUTREC);
                }
            }
            this.cursor = newcur;              // move the cursor
            if (move && ((FL_B & this.trc) != 0)){
                Trc.out.println("cursor moved to: " +
                    this.cursor);
            }
            if (!move && ((FL_D & this.trc) != 0)){
                write_tabtable();
            }
            if (this.max < this.cursor){      // append spaces
                for (int ix = this.max; ix < this.cursor; ix++){
                    this.buffer[ix] = ' ';
                }
                this.max = this.cursor;
            }
        }
        qu.repfact = 0;
    }

    /**
     * Methods to handle an array of bits.
     */

    private static final int BITSBYTE = 8;   // number of bits per byte 
    private static final int MASK = 0x7;     // mask to take the bit index
    private static final int NSHIFT = 3;     // nr of shifts for byte index 

    /**
     * Deliver the value of an element.
     *
     * @param      i index
     */

    private boolean getTab(int i){
        return (this.tabs[i >>> NSHIFT] & (1 << (i & MASK))) != 0;
    }

    /**
     * Assign an element.
     *
     * @param      i index
     * @param      v value
     */

    private void assignTab(int i, boolean v){
        if (v){
            this.tabs[i >>> NSHIFT] |= (1 << (i & MASK));
        } else {
            this.tabs[i >>> NSHIFT]  &= ~(1 << (i & MASK));
        }
    }

    /**
     * Clear all the elements from a given one onwards.
     *
     * @param      i index
     */

    private void clearFromTab(int i){
        int x = i >>> NSHIFT;                // index of byte
        this.tabs[x++] &=                    // clear bits in byte
            ~((1 << (i & MASK)) - 1);
        for (; x < this.tabs.length; x++){   // clear all subsequent bits
            this.tabs[x] = 0;
        }
    }

    /**
     * Find the n-th element whose value is true from a give index.
     *
     * @param      i index
     * @param      n, if >= 0 seek onwards, else backwards
     */

    private int findTab(int i, int n){
        if ((FL_D & this.trc) != 0){
            Trc.out.println("findTab: " + i + " " + n);
            write_tabtable();
        }
        int x = i >>> NSHIFT;                // index of byte
        byte msk = (byte)(1 << (i & MASK));  // bit mask of bit in element
        if (n >= 0){                         // search onwards
            for (; i <= this.end; i++){
                if (this.tabs[x] == 0){      // whole byte 0
                    i += 8;                  // skip it
                    x++;
                    if (i > this.end) break;
                }
                if (((this.tabs[x] & msk) != 0) &&
                    (--n == 0)) return i;    // n-th tab bit set
                msk <<= 1;
                if (msk == 0){               // step to next byte
                    msk = 1;
                    x++;
                }
            }
        } else {                             // search backwards
            for (; i >= 0; i--){
                if (this.tabs[x] == 0){      // whole byte 0
                    i -= 8;                  // skip it
                    x--;
                    if (i < 0) break;
                }
                if (((this.tabs[x] & msk) != 0) &&
                    (++n == 0)) return i;    // n-th tab bit set
                msk >>= 1;
                if (msk == 0){               // step to next byte
                    msk = (byte)(1 << 7);
                    x--;
                }
            }
        }
        return -1;                           // not found
    }

    /**
     * Trace an array of booleans
     */

    private void write_tabtable(){
        char[] s;

        s = new char[this.length+1];
        bitsToString(s);
        Trc.out.println("tabs: " + String.valueOf(s));
    }

    /**
     * Deliver a character array representing a boolean array for
     * tracing.
     *
     * @param      s result array
     */

    protected void bitsToString(char[] s){
        int i, len;

        len = 0;
        if (this.tabs != null){
            for (i = 0; i <= this.length; i++){
                s[len++] = getTab(i) ? '=' : '.';
            }
        }
    }

    /**
     * Process the clauses that cut the record.
     */

    protected void edit_cbk(){
        Cdata   qu = this.cptr;
        int     width, wid;
        char    code, mod;
        int     cut;

        code = qu.formt[qu.pfor++];
        mod = ' ';
        width = 0;
        switch (code){
        case 'e':                               // erase
            mod = qu.formt[qu.pfor];
            if (mod == '>') qu.pfor++;
            else mod = ' ';
            width = frm_param(-1,false);        // get width
            break;
        }
        if ((FL_D & this.trc) != 0){
            Trc.out.println("edit: code " + code +
                " mod " + mod + " width " + width +
                " cur " + this.cursor);
        }
        while (qu.repfact-- > 0){
            wid = width;
            switch (code){
            case 'e':                           // erase
                switch (mod){
                case ' ':
                    if (wid == -1){             // not specified
                        wid = this.cursor;      // length of cut
                    }
                    del_rec(-wid);
                    break;
                case '>':
                    if (wid == -1){             // not specified
                        wid = this.max - this.cursor;
                    }
                    del_rec(wid);
                    break;
                }
                break;
            }
            if (this.max < this.cursor){        // append spaces
                for (int ix = this.max; ix < this.cursor; ix++){
                    this.buffer[ix] = ' ';
                }
                this.max = this.cursor;
            }
        }
    }

    /**
     * Process the clauses that change the mode.
     */

    protected void mode_cbk(){
        Cdata   qu = this.cptr;
        int     tf;
        char    mode;
        int     width;
        int     newcur;
        char    ch;

        qu.pfor++;                                  // skip m
        loop: do {
            mode = qu.formt[qu.pfor++];
            if ((FL_C & this.trc) != 0){
                Trc.out.println("mode_cbk: " + mode);
            }
            switch (mode){
            case 'l':                                    // locale setting
                int locNum = 0;
                ch = qu.formt[qu.pfor];
                if ((ch == 'd') || (ch == 's')){         // define locale
                    String lang, country;
                    int arrSize;

                    qu.pfor++;
                    locNum = frm_param(0,false);         // locale id number
                    if (locNum < 1) error(ERR_VALUE);    // 0 reserved
                    redef: if (this.locArr != null){     // check redefinition
                        if (locNum >= this.locArr.length){
                            break redef;
                        }
                        if (locNum == 1) break redef;
                        if (this.locArr[locNum] == null){
                            break redef;
                        }
                        error(ERR_VALUE);                // redefinition
                    }
                    if (qu.formt[qu.pfor] == '$'){       // load from io list
                        qu.pfor++;
                        getArgNum();
                    }
                    Locale loc = null;
                    Lang hook = null;
                    switch (getElemType()){
                    case FRM_OBJ:
                        getval(FRM_OBJ);
                        if (qu.val_obj instanceof Locale){
                            loc = (Locale)(qu.val_obj);
                        } else if (qu.val_obj instanceof Lang){
                            hook = (Lang)(qu.val_obj);
                            loc = hook.getDefault();
                        } else {
                            error(ERR_LOCALE);
                        }
                        break;
                    default:
                        lang = valString();
                        int idx = lang.indexOf('_');
                        if (idx > 0){                        // country present
                            country = lang.substring(idx+1,
                               lang.length());
                            lang = lang.substring(0,idx);
                        } else {
                            country = "";
                        }
                        loc = new Locale(lang,country);
                        if ((FL_C & this.trc) != 0){
                            Trc.out.println("locale " + 
                                "|" + lang + "_" + country + "|");
                        }
                    }
                    if (this.locArr == null){            // no locale array
                        arrSize = LOC_QUANTUM;
                        if (locNum >= arrSize) arrSize = locNum + 1;
                        if (arrSize < 0) error(IOError.ERR_OUTLIMIT);
                        this.locArr = new Locale[arrSize];
                    } else if (this.locArr.length <= locNum){
                        Locale[] cur = this.locArr;
                        int newlen = cur.length + LOC_QUANTUM;
                        if (newlen < 0) error(IOError.ERR_OUTLIMIT);
                        Locale[] p = new Locale[newlen];
                        System.arraycopy(cur,0,p,0,cur.length);
                        this.locArr = p;
                    }
                    boolean newloc = false;
                    if (locNum == 1){
                        newloc = this.locArr[locNum] != loc;
                        if (hook == null){
                            this.locFixed = true;
                        } else {
                            this.locFixed = false;
                            this.lang = hook;
                        }
                    }
                    this.locArr[locNum] = loc;
                    if (ch == 's') this.locNum = locNum; // change locale
                    if (newloc){
                        if (this.nlArr != null){
                            this.nlArr[1] = null;        // previous invalid
                        }
                        invalidateRes();
                    }
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("defining locale " + locNum + " to " +
                            " " + this.locArr[locNum] + " curr: " + this.locNum);
                    }
                } else {                                 // change locale
                    locNum = frm_param(0,false);         // locale id number
                    if (locNum > 1){
                        if ((this.locArr == null) ||
                            (locNum >= this.locArr.length) ||
                            (this.locArr[locNum] == null)){
                            error(ERR_LOCALE);
                        }
                    }
                    this.locNum = locNum;
                    if ((FL_B & this.trc) != 0){
                        Trc.out.print("setting locale to " + locNum);
                        if  (locNum > 1)
                            Trc.out.print(" " + this.locArr[locNum]);
                        Trc.out.println();
                    }
                }
                break;
            case 'm':                                    // resource setting
                int resNum = 0;
                ch = qu.formt[qu.pfor];
                if ((ch == 'd') || (ch == 's')){         // define resource
                    String res;
                    int arrSize;

                    qu.pfor++;
                    resNum = frm_param(0,false);         // resource id number
                    if (this.resArr != null){            // check redefinition
                        if (resNum < this.resArr.length){
                            if (this.resArr[resNum] != null)
                                error(ERR_VALUE);        // redefinition
                        }
                    }
                    if (qu.formt[qu.pfor] == '$'){       // load from io list
                        qu.pfor++;
                        getArgNum();
                    }
                    res = valString();
                    arrSize = LOC_QUANTUM;
                    if (this.locArr == null){            // no locale array
                        this.locArr = new Locale[arrSize];
                    }
                    if (this.resArr == null){            // no resource array
                        if (resNum >= arrSize) arrSize = resNum + 1;
                        if (arrSize < 0) error(IOError.ERR_OUTLIMIT);
                        this.resArr = new ResourceBundle[arrSize];
                        this.bunArr = new String[arrSize];
                    } else if (this.resArr.length <= resNum){
                        ResourceBundle[] cur = this.resArr;
                        int newlen = cur.length + LOC_QUANTUM;
                        if (newlen < 0) error(IOError.ERR_OUTLIMIT);
                        ResourceBundle[] p = new
                            ResourceBundle[newlen];
                        System.arraycopy(cur,0,p,0,cur.length);
                        this.resArr = p;
                        String[] curs = this.bunArr;
                        String[] ps = new
                            String[curs.length+LOC_QUANTUM];
                        System.arraycopy(curs,0,ps,0,curs.length);
                        this.bunArr = ps;
                    }
                    if (this.locArr[1] != getDefault()){
                        this.locArr[1] = getDefault();
                        if (this.nlArr != null)
                            this.nlArr[1] = null;        // previous invalid
                    }
                    try {
                        this.resArr[resNum] =
                            ResourceBundle.getBundle(res,getDefault());
                        this.bunArr[resNum] = res;
                    } catch (MissingResourceException exc){
                        error(ERR_RESOURCE,exc);
                    }
                    if (ch == 's') this.resNum = resNum; // change resource
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("defining resource " + resNum +
                            " to " + "|" + res + "|" + this.resNum +
                            " " + this.resArr[resNum] + " " + getDefault());
                    }
                } else {                                 // change resource
                    resNum = frm_param(0,false);         // resource id number
                    if ((this.resArr == null) ||
                        (resNum >= this.resArr.length) ||
                        (this.resArr[resNum] == null)){
                        error(ERR_VALUE);
                    }
                    this.resNum = resNum;
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("setting resource to " + resNum +
                            " " + this.resArr[resNum]);
                    }
                }
                break;
            case 'd':                                 // enable trace
                qu.eptr = qu.extRep;
                qu.pfor = skip_format(F_SPEC,0,0);    // get string from format
                for (tf = 0; tf < qu.erLength; tf++){
                    char c = qu.extRep[tf];
                    if ((c >= 'a') && (c <= 'z')){    // take only lowercase ch.
                        this.trc |= 1 << (c - 0x60);
                    } else if (c == '-'){
                        this.trc = 0;
                    }
                }
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("setting trace to " +
                        String.valueOf(qu.extRep,0,qu.erLength));
                }
                break;
            case 'n':                                   // line separator
                if (qu.formt[qu.pfor] == '$'){          // load from io list
                    qu.pfor++;
                    getArgNum();
                    this.curLineSep = valString();
                } else {
                    qu.eptr = qu.extRep;
                    qu.pfor = skip_format(F_SPEC,0,0);  // string from format
                    this.curLineSep =
                        String.valueOf(qu.extRep,0,qu.erLength);
                }
                break;
            case 'x':                               // this is for testing only
                mode_test();
                break;
            case 'u':                               // set user data pointer
                getval(FRM_OBJ);                    // take pointer from io list
                this.udptr = qu.val_obj;
                break;
            case 'o':                               // overstrike
                mode = qu.formt[qu.pfor];
                if (mode == '-') qu.pfor++;
                else mode = ' ';
                this.insert = mode == '-';
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("setting mode: " +
                        (this.insert ? "insert" : "overstrike"));
                }
                break;
            case 'w':                               // wrap
                mode = qu.formt[qu.pfor];
                if (mode == '-') qu.pfor++;
                else mode = ' ';
                this.wrap = mode == ' ';
                this.newcont = false;               // restart with first line
                if (this.wrap) this.grow = false;
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("setting mode: " +
                        (this.wrap ? "wrap" : "nowrap"));
                }
                break;
            case 'z':                               // evidentiation
                mode = qu.formt[qu.pfor];
                if (mode == '-') qu.pfor++;
                else mode = ' ';
                this.evid = mode == ' ';
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("setting mode: " +
                        (this.evid ? "evidence" : "no-evidence"));
                }
                break;
            case 'i':                               // indent
                mode_indent();
                break;
            case 'h': case 't':                     // heading, tail
                mode_headtail(mode);
                break;
            case 'r':                               // resume insertion
                mode_resume();
                break;
            case 'j':                               // error signalling
                mode = qu.formt[qu.pfor];
                if (mode == '-'){
                    qu.pfor++;
                    this.errthrow = 0;
                } else if (mode == '+'){
                    qu.pfor++;
                    this.errthrow = 2;
                } else {
                    this.errthrow = 1;
                }
                if ((this.errthrow > 0) &&
                    (this.res != 0)){
                    error(this.res);                // do it now
                }
                break;
            case 'b':                               // set break
                mode_break();
                break;
            case 'e':                               // test element availability
                mode_arr();
                break;
            case 'p':                               // paging
                mode = qu.formt[qu.pfor];
                if (mode != '>'){
                    this.pageh = frm_param(60,false);     // get page height
                } else {
                    qu.pfor++;
                    int space = frm_param(0,false);       // get space required
                    if (this.pageh > 0){                  // paging on
                        int left =
                            this.pageh - this.linnr + 1;
                        if ((FL_C & this.trc) != 0){
                            Trc.out.println("space: " +
                                space + " " + left);
                        }
                        if (left < space){                // no room
                            this.linnr = this.pageh + 1;  // force tof
                            if (this.linnr < 0){
                                error(IOError.ERR_OUTLIMIT);
                            }
                        }
                    }
                }
                break;
            case 'f':                               // flush
                mode = qu.formt[qu.pfor];
                if (mode == '-') qu.pfor++;
                else mode = ' ';
                this.flush = mode == ' ';
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("setting flush: " + this.flush);
                }
                break;
            case 'c':                               // cut (remove) trailing
                mode = qu.formt[qu.pfor];           // .. blanks
                if (mode == '-') qu.pfor++;
                else mode = ' ';
                this.remtrail = mode == ' ';
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("setting trailing removal: " +
                        this.remtrail);
                }
                break;
            case 'a':                               // format/io-list match
                mode = qu.formt[qu.pfor];
                switch (mode){
                case '-': this.match = 1; qu.pfor++; break;
                case '+': this.match = 2; qu.pfor++; break;
                default: this.match = 0;
                }
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("setting match check: " +
                        this.match);
                }
                break;
            case 'g':                               // grow
                mode = qu.formt[qu.pfor];
                if (mode == '-') qu.pfor++;
                else mode = ' ';
                this.grow = mode == ' ';
                if (this.wrap) this.grow = false;
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("setting grow: " + this.grow);
                }
                break;
            default:
                qu.pfor--;
                break loop;
            }
            switch (qu.formt[qu.pfor]){
            case ';': case '%': case ',':           // spec terminated
            case ' ': case '\0': break loop;
            }
        } while (true);
    }

    /**
     * Process the clause that change the indentation.
     */

    private void mode_indent(){
        Cdata   qu = this.cptr;
        char    mode;
        int     width;
        int     newcur;

        mode = qu.formt[qu.pfor];
        switch (mode){
        case 't': case '-': case '+':
            qu.pfor++; break;
        default: mode = ' ';
        }
        width = frm_param(-1,false);       // get width
        switch (mode){
        case ' ':                          // to column
            if (width == -1){
                width = this.cursor;       // not specified
            }
            this.indent = width;
            break;
        case '+':                          // increment
            if (width == -1) width = 2;    // not specified
            this.indent += width;
            break;
        case '-':                          // decrement
            if (width == -1) width = 2;    // not specified
            this.indent -= width;
            break;
        case 't':                          // to tab
            if (width == -1) width = 0;    // not specified
            if (width == 0) width = 1;     // first tab
            if (this.tabs == null){        // no next tab
                this.indent = -1;          // error
                break;
            } else {
                newcur = 0;                // from the beginning
            }
            newcur = findTab(newcur,width);
            this.indent = newcur;
            break;
        }
        if (this.indent > this.length){
            if (this.grow){
                bufferExtend(this.indent-this.length);
            } else {
                error(ERR_OUTREC);
            }
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("setting indentation to: " +
                this.indent);
        }
    }

    /**
     * Process an internal test mode clause.
     */

    private void mode_test(){
        Cdata   qu = this.cptr;
        int     nr;
        int     i;
        long    pres;
        String  str;
        char    code;

        stop: {
            code = qu.formt[qu.pfor];
            if (code == 'm'){
                qu.pfor++;
//                frmGetQuals(FormFloat.MONE_QUALS);
                frmGetQuals(MONE_QUALS);
                if ((qualMap['^'] & qu.pres) == 0) qu.thou = '\'';
                else qu.thou = '^';
                if ((qualMap['i'] & qu.pres) != 0) qu.kind = 'i';
                else qu.kind = 'n';
                if ((qualMap['c'] & qu.pres) != 0) qu.cncy = '!';
            } else if (code == 'f'){
                qu.pfor++;
//                frmGetQuals(FormFloat.FLOAT_QUALS);
                frmGetQuals(FLOAT_QUALS);
                if ((qualMap['\''] & qu.pres) == 0) qu.thou = '^';
                else  qu.thou = '\'';
            } else if (code == 'q'){
                qu.pfor++;
                frmGetQuals(INT_QUALS);
                switch (qu.formt[qu.pfor]){
                case ' ': case ';':
                case ',': case '\0': break;
                default:
                    this.res = ERR_ILLCODE;
                }
                this.cursor = 0;
                pres = qu.pres;
                for (i = 0; i <= 'z'; i++){
                    if ((qualMap[i] & pres) != 0)
                        this.buffer[this.cursor++] = (char)i;
                }
                nr = this.cursor;
                this.max = this.cursor;
                if (this.res != 0){
                    error(this.res);
                }
                break stop;
            } else if (code == 's'){
                int kind;
                code = qu.formt[++qu.pfor];
                switch (code){
                case 'c': kind = F_CODE; break;
                case 's': kind = F_SPEC; break;
                case 'p': kind = F_SPECP; break;
                case 't': kind = F_TXT; break;
                default: break stop;
                }
                qu.pfor++;
                qu.eptr = qu.extRep;
                qu.pfor = skip_format(kind,0,0);         // get string
                insert(qu.extRep,FRM_CHARS,0,qu.erLength,1);
                if ((code == 'i') && (qu.formt[qu.pfor] == ':')) qu.pfor++;
                break stop;
            } else if (code == 'a'){                     // affixes
                qu.pfor++;
//                frmGetQuals(FormFloat.MONE_QUALS);
                frmGetQuals(MONE_QUALS);
                getval(FRM_STRING);
                LocNumData locData = new LocNumData(null,null);
                locData.cyNegPref = locData.affixMsk((String)(qu.val_obj),locData);
                if ((FL_D & this.trc) != 0){
                    Trc.out.print("msk: ");
                    for (i = 1<<6; i > 0; i >>= 1){
                        Trc.out.print(((locData.cyNegPref & i) != 0) ? "1" : "0");
                    }
                    Trc.out.println("");
                }
                int ep = REP_MIN;
//                ep = FormFloat.insAffix(true,true,qu,locData,ep,'c');
                ep = insAffix(true,true,qu,locData,ep,'c');
                insert(qu.extRep,FRM_CHARS,ep,REP_MIN-ep,1);
                break stop;
            } else if (code == 'e'){                     // elements
                qu.pfor++;
                frmGetQuals(CHAR_QUALS);
                getval(FRM_CHAR);
                qu.extRep[0] = qu.val_char;
                nextArg();
                getval(FRM_CHAR);
                qu.extRep[1] = qu.val_char;
                insert(qu.extRep,FRM_CHARS,0,2,1);
                break stop;
            } else if (code == 'v'){                     // value string
                qu.pfor++;
                str = valString();
                insert(str,FRM_STRING,0,str.length(),1);
                break stop;
            } else if (code == 'E'){                     // Exception
                char type;
                qu.pfor++;
                type = qu.formt[qu.pfor];
                switch (type){
                case 'o':                                // outofmemory
                    throw new OutOfMemoryError();
                case 'i':                                // io
                    error(IOError.ERR_IOERR);
                }
                break stop;
            } else if (code == 'g'){                     // getval
                char type;
                byte valtype = 0;
                qu.pfor++;
                type = qu.formt[qu.pfor];
                switch (type){
                case '1': valtype = FRM_BOOL; break;
                case 'c': valtype = FRM_CHAR; break;
                case 'b': valtype = FRM_BYTE; break;
                case 'h': valtype = FRM_SHORT; break;
                case 'i': valtype = FRM_INT; break;
                case 'l': valtype = FRM_LONG; break;
                case 'f': valtype = FRM_FLOAT; break;
                case 'd': valtype = FRM_DOUBLE; break;
                case 'B': valtype = FRM_BYTES; break;
                case 'C': valtype = FRM_CHARS; break;
                case 's': valtype = FRM_STRING; break;
                case 'S': valtype = FRM_STRBUF; break;
                case 'D': valtype = FRM_DATE; break;
                case 'o': valtype = FRM_OBJ; break;
                case 'u': valtype = FRM_USER; break;
                case 'I': valtype = FRM_BIGINT; break;
                case 'F': valtype = FRM_BIGDEC; break;
                }
                getval(valtype);
                break stop;
            } else {
                break stop;
            }
            str = qu.sign + "," + qu.thou + ",p" + qu.nfill +
                "," + qu.integral + qu.dradix + qu.decimal + "," +
                qu.kind + (qu.cncy==' '?"":"!") + "=" +
                (qu.evid?"z":"") + "p" + ((qu.just==0)?"a":"") +
                qu.padd + (((qu.just<0)&&(qu.minw>0))?"-":"") +
                qu.minw + (qu.lowbound?":":" ") + qu.maxw;
            str.getChars(0,str.length(),this.buffer,0);
            this.cursor = 0;
            this.cursor += str.length();
            this.max = this.cursor;
        }
    }

    /**
     * Process the clause that resume a suspended insertion
     * of an external representation in the record.
     */

    private void mode_resume(){
        int   space;                      // free space in record
        Cdata cptr;

        if (this.nestcall <= 1){          // not inside a nested write()
            error(ERR_NEST);
        }
        cptr = this.cptr;
        this.cptr = this.cptr.cptr;
        insert(null,(byte)0,0,0,1);       // resume insert in record
        this.cptr.insdone = true;
        this.cptr = cptr;
    }

    /**
     * Process the clause that registers a line head or tail.
     */

    private void mode_headtail(char mode){
        Cdata qu = this.cptr;
        int   len;

        if (mode == 'h'){                             // heading
            qu.eptr = this.head;
            if (qu.formt[qu.pfor] == '$'){            // load from io list
                qu.pfor++;
                getArgNum();
                valChArr(0);
                len = qu.erLength;
            } else {
                qu.pfor = skip_format(F_SPEC,0,0);    // get str from format
                len = qu.erLength;
            }
            if (len > this.length){                   // min limit: first line
                if (this.grow){
                    bufferExtend(len-this.length);
                } else {
                    this.head = EMPTY_STR;
                    this.headLength = 0;
                    error(ERR_OUTREC);
                }
            } else if (len > 0){                      // good
                this.head = (char[])qu.eptr;
                this.headLength = len;
            } else {                                  // empty
                this.head = EMPTY_STR;
                this.headLength = 0;
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("setting heading to " +
                    String.valueOf(this.head,0,this.headLength));
            }
        } else {                                      // tail
            qu.eptr = this.tail;
            if (qu.formt[qu.pfor] == '$'){            // load from io list
                qu.pfor++;
                getArgNum();
                valChArr(0);
                len = qu.erLength;
            } else {
                qu.pfor = skip_format(F_SPEC,0,0);    // get str from format
                len = qu.erLength;
            }
            if (len > this.length){                   // min limit: first line
                if (this.grow){
                    bufferExtend(len-this.length);
                } else {
                    this.tail = EMPTY_STR;
                    this.tailLength = 0;
                    error(ERR_OUTREC);
                }
            } else if (len > 0){                      // good
                this.tail = (char[])qu.eptr;
                this.tailLength = len;
            } else {                                  // empty
                this.tail = EMPTY_STR;
                this.tailLength = 0;
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("setting tail to " +
                    String.valueOf(this.head,0,this.tailLength));
            }
        }
    }

    /**
     * Process the clause that register the point at which the
     * record can be broken to wrap it, and the other ones to enable and
     * disable break mode.
     */

    private void mode_break(){
        Cdata   qu = this.cptr;
        char    mode;
        int     width = 0;

        mode = qu.formt[qu.pfor];
        switch (mode){
        case '-': case '+':
            qu.pfor++;
            width = frm_param(0,false);          // get width
            break;
        case 'o': case 'i': case 'd':
            qu.pfor++;
            break;
        default:
            mode = ' ';
            width = frm_param(0,false);          // get width
            break;
        }
        doit: {
            switch (mode){
            case ' ':                            // to column
                if (width == 0){
                    width = this.cursor;
                }
                break;
            case '+':                            // ahead
                width = this.cursor + width;
                if (width < 0) error(IOError.ERR_OUTLIMIT);
                break;
            case '-':                            // back
                width = this.cursor - width;
                break;
            case 'o':                            // break disable
                this.breakon = false;
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("breaks disabled");
                }
                break doit;
            case 'd':                            // break deferred
                this.breakdef = true;
                this.breakon = false;
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("breaks disabled after next");
                }
                break doit;
            case 'i':                            // break enable
                this.breakon = true;
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("breaks enabled");
                }
                break doit;
            }
            if ((width < 0) || (width > this.max)){
                error(ERR_OUTREC);
            }
            this.lastbrk = width;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("break set at " +
                    this.lastbrk);
            }
        }
    }

    /**
     * Process the clause that test if the array elements are
     * exhausted.
     */

    private void mode_arr(){
        Cdata qu = this.cptr;

        if ((qu.ionest >= 0) &&
            (qu.astack[qu.ionest].ix >=
            qu.astack[qu.ionest].nr)){
            if ((FL_B & this.trc) != 0){
                Trc.out.println("elements exhausted");
            }
            error(ERR_EXHAUSTED);
        }
    }

    /**
     * Processes the clause that register a pending insertion.
     */

    protected void pend_cbk(){
        Cdata   qu = this.cptr;
        int     startp, endp;
        int     startf;
        int     len = 0;

        qu.pfor++;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("pend: for: " + qu.pfor);
        }
        this.penddis = false;
        if (qu.formt[qu.pfor] == '-'){               // break-disappear
            this.penddis = true;
            qu.pfor++;
        }
        endpen: {
            this.pendnl = false;
            if (qu.formt[qu.pfor] == '$'){           // load from io list
                qu.pfor++;
                getArgNum();
                qu.eptr = this.pend;
                valChArr(PND_MIN);
                this.pendLength = qu.erLength;
                break endpen;
            } else {
                startp = 0;
                endp = 0;
                if (this.pend != null) endp = this.pend.length;
                startf = qu.pfor;
                load: for (; qu.pfor < qu.forLength;   // seek the end
                    qu.pfor++){
                    switch (qu.formt[qu.pfor]){
                    case '`': qu.pfor++; break;        // escape
                    case '%': case ';': break load;    // end
                    }
                    if (startp == endp){               // not enough, allocate
                        startp = -1;
                        break load;
                    }
                    this.pend[startp++] = qu.formt[qu.pfor];
                }
                if (startp >= 0){
                    this.pendLength = startp;
                    break endpen;
                }

                len = 0;                               // count chars
                qu.pfor = startf;
                cnt: for (; qu.pfor < qu.forLength;    // seek the end
                    qu.pfor++){                
                    switch (qu.formt[qu.pfor]){
                    case '`': qu.pfor++; break;        // escape
                    case '%': case ';': break cnt;     // end
                    }
                    len++;
                }
            }
            this.pend = new char[(len >= PND_MIN) ?
                len : PND_MIN];                        // allocate
            this.pendLength = len;
            startp = 0;                                // index in pend
            qu.pfor = startf;
            trf: for (; qu.pfor < qu.forLength;        // seek the end
                qu.pfor++){
                switch (qu.formt[qu.pfor]){
                case '`': qu.pfor++; break;            // escape
                case '%': case ';': break trf;         // end
                }
                this.pend[startp++] = qu.formt[qu.pfor];
            }
        }
        if (this.pendLength > 0){
            if (this.pend[this.pendLength-1] == '\n'){ // pending ends in \n
                this.pendLength--;
                this.pendnl = true;
                if (this.penddis) this.pendnl = false;
            }
        }
        if ((FL_C & this.trc) != 0){
            String s = "";
            if (this.pend != null){
                s  = String.valueOf(this.pend,0,this.pendLength) +
                    (this.pendnl ? " \\n" : "");
            }
            Trc.out.println("pendings: " + s);
        }
    }


    /* Io-clauses callbacks */

    /**
     * Emit the record. It is the default output callback, that writes the
     * carriage control characters and the record.
     */

    protected void out_cbk(){
        if ((FL_C & this.trc) != 0){
            Trc.out.println("out_cbk: " +
                this.file + " " + this.file.getClass() +
                " " + this.flush);
            carriage(this.prefix);
            Trc.out.print(String.valueOf(this.buffer,0,this.max) + " ");
            carriage(this.suffix);
            Trc.out.println();
        }
        try {
            IoStream wr = this.file;
            if (this.prefix.length() > 0) wr.write(this.prefix);
            if (this.max > 0) wr.write(this.buffer,0,this.max);
            if (this.suffix.length() > 0) wr.write(this.suffix);
            if (this.flush) wr.flush();
        } catch (IOError exc){
            error(IOError.ERR_IOERR,exc);
        }
    }

    /**
     * Trace the carriage control characters.
     *
     * @param      s string of the carriage control
     */        

    private void carriage(String s){
        char c;
        for (int i = 0; i < s.length(); i++){
            c = s.charAt(i);
            switch (c){
            case '\n': c = 'n'; break;
            case '\r': c = 'r'; break;
            case '\f': c = 'f'; break;
            default: c = '?';
            }
            Trc.out.println("<\\" + c + ">");
        }
    }

    /** The constant denoting no carriage positioning. */
    private static final int N_C = 0;

    /** The constant denoting the n(0) carriage positioning. */
    private static final int N_0 = 1;

    /** The constant denoting the n(1) carriage positioning. */
    private static final int N_1 = 2;

    /** The constant denoting the t(1) carriage positioning. */
    private static final int T_1 = 3;

    /** The platform dependent line terminator. */
    private static String lineSep = System.getProperty("line.separator");

    /**
     * Determine the carriage control characters that perform the required
     * carriage positioning.
     *
     * @param      code i/o qualifier that specifies the carriage positioning
     */        

    private void set_carriage(char code){
        int  prefix = N_C;                       // cc before record
        int  suffix = N_C;                       // cc after record

        if ((FL_D & this.trc) != 0){
            Trc.out.println("set_carriage: " +
                Integer.toHexString(code) + " " +
                this.iscol0 + " lis: " + this.listing +
                " " + this.firstio);
        }
        stop: {
            if (code == '\n') code = 'n';
            if (code == '\f') code = 'e';
            switch (code){
            case 'n': prefix = N_1; suffix = N_0; break;
            case 'f': prefix = T_1; suffix = N_0; break;
            case 'o': prefix = N_C; suffix = N_0; break;
            case 'p': prefix = N_1; suffix = N_C; break;
            case 'w': prefix = N_C; suffix = N_C; break;
            case 'e': this.firstio = true;
                this.pendff = true; break stop;
            }
            if (this.pendff){                    // pending new page
                this.pendff = false;
                prefix = T_1;
            }
            this.prefix = "";
            this.suffix = "";
            if ((FL_D & this.trc) != 0){
                Trc.out.println("prefix: " + prefix +
                    " suffix: " + suffix);
            }
            if (prefix == N_1){                  // n(1)
                if (this.listing){
                    if (!this.firstio){          // not first i/o in the page
                        if (!this.iscol0){       // carriage not at column 0
                            this.prefix = "\r\n";
                        } else {
                            this.prefix = "\n";
                        }
                    }
                }
            } else if (prefix == T_1){           // t(1)
                this.prefix = "\f";
                if (this.listing){
                    if (!this.iscol0){           // carriage not at column 0
                        this.prefix = "\r\f";
                    }
                }
            }
            if (suffix == N_0){                  // n(0)
                if (this.listing){
                    this.suffix = "\r";
                } else {                         // text file: separate with \n
                    this.suffix = this.curLineSep;
                }
            }
        }
    }

    /**
     * Emit the record with the current carriage control characters.
     * If paging is enabled, it emits a new page and calls a user page
     * heading callback (if any) if the current page is full.
     */

    private void rec_emit(){
        int    pageh;
        char[] rec;
        int    max;
        String prefix;
        String suffix;
        int    len, ln;

        if ((FL_B & this.trc) != 0){
            Trc.out.print("emitting: ");
            carriage(this.prefix);
            Trc.out.print(String.valueOf(this.buffer,0,this.max) + " ");
            carriage(this.suffix);
            Trc.out.println();
        }
        this.firstio = false;
        this.iscol0 = ((this.listing) && (this.suffix == "\r")) ||
            ((!this.listing) &&
            ((this.suffix == "\n") || (this.suffix == "\r\n")));
        len = this.prefix.length();                 // determine line nr
        for (int i = 0; i < len; i++){              // .. of record start
            if (this.prefix.charAt(i) == '\n'){
                this.linnr++;
                if (this.linnr < 0) error(IOError.ERR_OUTLIMIT);
            }
            if (this.prefix.charAt(i) == '\f'){
                this.linnr = 1;
                if (this.pageh > 0) this.pagnr++;   // make user cbk not inc. it
            }
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("start page: " + this.pagnr +
                " line: " +  this.linnr + " " + this.pageh);
        }
        if (this.pageh > 0){                        // paging
            if (this.linnr > this.pageh){           // out of page
                set_carriage('f');
                this.pagnr++;
                this.linnr = 1;
            }
            if (this.linnr == 1){                   // beginning of page
                if ((this.cbkpres & PAGECBK) != 0){ // present
                    prefix = this.prefix;           // save prefix and suffix
                    suffix = this.suffix;
                    pageh = this.pageh;             // turn off page mode to 
                    this.pageh = 0;                 // .. stop endless recursion
                    rec = this.buffer;              // save current record
                    max = this.max;
                    ln = this.length;
                    this.buffer = new char[this.length];  // alloc one for heading 
                    rec_init();
                    this.pendff = true;             // force ff
                    call_cbk('6',1,PAGEFRM,true);   // page callback
                    this.pageh = pageh;             // restore it
                    this.buffer = rec;              // restore it
                    this.length = ln;
                    rec_init();
                    this.max = max;
                    this.prefix = prefix;           // restore prefix and suffix
                    this.suffix = suffix;
                    if (!this.pendff){              // user cbk printed
                        if (this.listing){          // .. something
                            if (this.prefix == "\f"){  // do not print another
                                this.prefix = "\n";    // .. \f
                                this.linnr++;
                            }
                        } else {
                            this.prefix = "";
                        }
                        if (this.prefix == "\r\f"){
                            this.prefix = "\r\n";
                            this.linnr++;
                        }
                    }
                    if ((FL_B & this.trc) != 0){
                        Trc.out.print("linnr: " + this.linnr +
                            " new carr: ");
                        carriage(this.prefix);
                        carriage(this.suffix);
                        Trc.out.println();
                    }
                }
            }
        }
        len = this.suffix.length();                 // determine line nr
        for (int i = 0; i < len; i++){              // .. of record end
            if (this.suffix.charAt(i) == '\n'){
                this.linnr++;
                if (this.linnr < 0) error(IOError.ERR_OUTLIMIT);
            }
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("end line: " + this.linnr);
        }
        if (this.remtrail){
            while (this.max > 0){                   // remove trailing blanks
                if (this.buffer[--this.max] != ' '){
                    this.max++;
                    break;
                }
            }
        }
        call_cbk('0',1,OUTFRM,false);               // call output callback
        if ((FL_B & this.trc) != 0){
            Trc.out.println("rec_emit end");
        }
        rec_init();
        this.newcont = true;
    }

    /**
     * Process the io clauses.
     */

    protected void io_cbk(){
        Cdata   qu = this.cptr;
        char    code;

        code = qu.formt[qu.pfor];
        switch (code){
        case '/':
            qu.pfor++;
            switch (qu.formt[qu.pfor]){
            case 'f': case 'o': case 'p':
            case 'w': case 'e':
                code = qu.formt[qu.pfor];
                qu.pfor++; break;
            default: code = 'n';
            }
            break;
        case '\n': case '\f':
            qu.pfor++;
            break;
        }
        doit: {
            if (code != 'e'){                          // it includes \f
                if ((qu.formt[qu.pfor] == 'n') ||      // conditioned operation
                    (qu.formt[qu.pfor] == 'N')){
                    if (qu.formt[qu.pfor] == 'N'){
                        this.wrap = false;
                        this.pendLength = 0;           // de-register pendings
                        this.pendnl = false;
                    }
                    qu.pfor++;
                    if (this.max == 0) break doit;     // empty record
                }
            }
            if ((FL_D & this.trc) != 0){
                Trc.out.println("code: 0x" + Integer.toHexString(code) +
                    " rep: " + qu.repfact + " file: " + this.file);
            }
            if (this.file == null){                    // output on string
                if ((this.cbkpres & OUTCBK) == 0){     // not present
                    error(ERR_STREAM);
                }
            }
            while (qu.repfact-- > 0){
                if (code == '\f'){                     // \f equivalent to ..
                    set_carriage('n');                 // new line, end page
                } else {
                    set_carriage(code);
                    if (code == 'e') break doit;
                }
                if (this.wrap){                        // wrap mode
                    if (this.pendLength > 0){          // pendings
                        pack_rec(2,
                            (this.penddis)?PK_DIS:PK_PEN,
                                this.pend,FRM_CHARS,0,this.pendLength,
                            PK_NL,null,(byte)0,0,0);
                    } else {
                        pack_rec(1,PK_NL,null,(byte)0,0,0,0,null,(byte)0,0,0);
                    }
                } else {
                    rec_emit();
                }
                if (code == '\f') set_carriage(code);
            }
            if (code == 'p'){
                if (Prg.os != Prg.VMS){
                    this.firstio = true;
                }
            }
        }
    }

    /**
     * Emit the record if the output is on a file and if there
     * is something in it. It does not perform the operation if there
     * is a previous io error because the operation could cause another
     * one. However, it tries anyway to close the file if one has been
     * opened.
     *
     * @param      <code>true</code> to close also the file if it was
     *             opened by the formatter
     */

    private void flush_rec(boolean close){
        if ((FL_B & this.trc) != 0){
            Trc.out.println("flush " + this.file +
                " opened: " + this.openfile +
                " flush: " + this.flush);
        }
        doit: if (this.file != null){            // output on file
            if (this.res == IOError.ERR_IOERR){  // output does not work
                break doit;
            }
            if (this.max > 0){                   // last record not empty
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("flushing " +
                        this.max + " char(s)");
                }
                set_carriage('n');
                try {
                    rec_emit();
                } catch (FormatterError exc){
                    if (this.res == IOError.ERR_IOERR){
                        break doit;              // try to close it
                    }
                    error(this.res);
                }
            }
            try {
                if (!this.flush){
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("flush");
                    }
                    if ((this.file.getStatus() &
                        IoStream.IS_OPEN) != 0){
                        this.file.flush();       // do it if not done
                    }
                }
            } catch (IOError exc){
                error(IOError.ERR_IOERR,exc);
            }
        }
        if (this.openfile && close){             // opened by init_cbk
            if ((FL_B & this.trc) != 0)
                Trc.out.println("close");
            try {
                this.file.close();               // close the file
                this.openfile = false;
            } catch (IOError exc){
                error(IOError.ERR_IOERR,exc);
            }
        }
        if (this.res != 0) error(this.res);
    }

    /**
     * Deliver the content of the text record on a newly allocated
     * String.
     */

    public String toString(){
        return String.valueOf(this.buffer,0,this.max);

    }

    /**
     * Format the values in the io list with the specified format and
     * deliver the contents of the text record on a newly allocated
     * string. It is equivalent to performing <code>write()</code> and
     * <code>toString()</code>.
     */

    public String doString(){
        write();
        return String.valueOf(this.buffer,0,this.max);

    }

    /**
     * Deliver a reference to a resource bundle and update it if
     * the default locale has changed.
     *
     * @param      nr number of the resource.
     * @return     resource bundle
     */

    private ResourceBundle getResource(int nr){
        boolean newloc = false;

        if ((FL_B & this.trc) != 0){
            Trc.out.println("nr: " + nr);
        }
        excInit();
        if ((this.resArr == null) ||
            (nr >= this.resArr.length) ||
            (this.resArr[nr] == null)){
            error(ERR_RESOURCE);
        }
        newloc = getDefault() != this.locArr[1];     // fast test
        if (newloc ||                                // default changed
            (this.resArr[nr] == INV_RES)){
            try {
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("getResource: " +
                    this.bunArr[nr] + " " + getDefault());
                }
                this.resArr[nr] =
                    ResourceBundle.getBundle
                    (this.bunArr[nr],getDefault());
            } catch (MissingResourceException exc){
                error(ERR_RESOURCE,exc);
            }
        }
        if (newloc){                                 // default changed
            this.locArr[1] = getDefault();
            if (this.nlArr != null){
                 this.nlArr[1] = null;               // previous invalid
            }
        }
        return this.resArr[nr];
    }

    /**
     * Deliver a reference to a resource bundle created in a
     * Formatter object.
     *
     * @param      nr number of the resource.
     * @return     resource bundle
     */

    public ResourceBundle getBundle(int nr){
        ResourceBundle res = null;
        excInit();
        try {
            res = getResource(nr);
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (FormatterError exc){
        }
        excTerm();
        return res;
    }

    /**
     * Deliver a reference to the locale data for numbers.
     *
     * @param      nr number of the locale.
     * @return     reference to the data
     */

    public LocNumData getLocNumData(int nr){
        if ((FL_B & this.trc) != 0){
            Trc.out.println("nr: " + nr);
        }
        excInit();
        try {
            int savenum = this.locNum;
            if (nr > 1){
                if ((this.locArr == null) ||
                    (nr >= this.locArr.length) ||
                    (this.locArr[nr] == null)){
                    error(ERR_LOCALE);
                }
            }
            this.locNum = nr;
            handleLocale('n');              // obtain locale data
            this.locNum = savenum;
        } catch (OutOfMemoryError exc){
            registerError(IOError.ERR_NOCORE,exc);
        } catch (FormatterError exc){
        }
        excTerm();
        return this.nlArr[nr];
    }



    /*
     * Floating points by now are converted by using the very inefficient
     * Float or Double class methods.  There would be a need for better
     * methods to format floating point numbers, which take the mantissa
     * and the exponent and format them.
     * <p>
     * Taken a DecimalFormat, to control the external representation there
     * is a need to set:
     * <ul>
     * <li>min fractional (it sets the max automatically)
     * <li>min integral
     * <li>scientific representation and min nr of exponent digits
     * <li>decimal separator always shown
     * <li>grouping used/not-used
     * <li>grouping size
     * <li>decimal separators
     * <li>minus sign symbol
     * <li>locale digits
     * <li>the position of the currency symbol: before, or after the number
     *   both for positive and negative.
     * <li>whether there is a space or not between the number and currency
     * <li>if the currency symbol separates the sign and the number
     * <li>the use of the local or the international one
     * <li>the removal of the currency
     * </ul>
     * <p>
     * An array of LocNumdata is kept. The use of DecimalFormat is too heavy
     * and too inflexible.
     * <p>
     * The minimum number of digits in the fraction is inserted if the format
     * is free (and only in this case because when the format is fixed the
     * fraction, which is unpredictably long, can occupy the whole field.
     * The same for exponent, but also in fixed format because the number of
     * digits is low.
     * The effect of printing all decimals is that this can produde a lot
     * of digits for some numbers. However, if there is a need to limit it,
     * the decimal qualifier should be used.
     * <p>
     * g|G qualifiers: the normal notation is used if it does not produce a
     * number which has too many digits, and the scientific one if the
     * fractional part is too long or the integral part greater than the one
     * specified.
     * <p>
     * Since getval with FRM_DOUBLE delivers a double out of any value which
     * can be casted to it, there is no need here to make a special case for
     * float values.
     * <p>
     * The use of parentheses for negative values is not a locale dependent
     * feature, but a general one for monetary values. In some locales it
     * is the only one allowed. The `(' qualifier selects the parentheses
     * anyway.
     * <p>
     * A currency formatter is taken, the prefix and postfix got, its data
     * extracted, new prefixes and suffixes determined, a pattern applied,
     * the affixes, grouping, etc., set and the value formatted.
     * <p>
     * A floating point binary number, strictly speaking, represents a decimal
     * number which can have a lot of digits. This results in having values
     * which are not evenly spaced in the decimal base. Since, however, a binary
     * floating point number represents also the numbers which lay in an
     * interval around it, one can also choose in it the decimal number with
     * the smallest number os significant digits in the hope to have a better
     * number repertoire, hoping also that there are no holes and that the
     * operations could be implemented in such a way as to provide values
     * which are correct in that system. E.g. if one takes the binary values
     * which represent 0.1 and 0.2 and sum them he wants to obtain a value
     * which represents 0.3, and not let the errors sum so as to lead to a
     * floating binary number which represents 0.4.  However, even if this
     * property does not hold, the best that can be done is to represent a
     * flating point number with the decimal one that lays close to it and
     * that has less digits.
     * <p>
     * A number can be converted to and from the fixed point notation and
     * the scientific one in the following way. First, since there is a need not
     * to loose digits, a floating notation should be obtained by scaling the
     * number so as to make it have one integral digit (without making it
     * overflow or underflow). Then, the desired fixed point notation can be
     * obtained by placing the decimal point in its place and rounding, and the
     * scientific notation can be obtained by placing it in the specified place
     * and adjusting the exponent accordingly. This is not simple for values
     * which are close to the borders, and perhaps it is also not simple to
     * choose always the number which is closest to the base 2 floating point
     * one and that has the minimum number of digits. Thus these operations
     * are directly done on the decimal representation.
     * <p>
     * It is not simple how to find the decimal number which falls within
     * the interval denoted by a floating point binary number that has the
     * minimum number of digits, and how to find the closest when there are
     * several. Since these conversions do not occur often, it would be better
     * to have simpler, but well understood algorithms.
     * <p>
     * Formatting of percentages: the percent formatter is a DecimalFormatter
     * with a specific pattern that, however, seems incorrect for the locales
     * that want suffix -. Therefore it is not used, and the percent sign
     * included instead.
     * <p>
     * The technique used is to determine the intrinsic characteristics
     * for a locale so a to keep them the first time that locale is used.
     * When formatting a number, they are changed on the basis of
     * the qualifiers and used to format it.
     * <p><blockquote><pre>
     *       intrinsic               qualifiers
     *
     *       GroupingSeparator;
     *       GroupingSize;
     *       DecimalSeparator;
     *       MonetaryDecimalSeparator;
     *       ZeroDigit;
     *       ExponentialSymbol
     *       position of minus sign
     *       PositivePrefix          if (qu.sign != ' ') "+"
     *       PositiveSuffix
     *       NegativePrefix
     *       NegativeSuffix
     *       Infinity;               if ((qualMap['L'] & qu.pres) != 0) "1/0"
     *       NaN;                    if ((qualMap['L'] & qu.pres) != 0) "NaN"
     * </pre></blockquote><p>
     * In order to avoid to process a long string, the Float.toString or
     * the Double.toString methods are used, which provide the scientific
     * notation when the number is big. The string obtained is then processed
     * to scale, truncate, and localise it.
     *
     * @param      frm the formatter
     */

    static void float_cbk(Formatter frm){
        Cdata   qu = frm.cptr;
        char    code;
        char    ch;
        double  v = 0;                         // value to be converted
        int     i;
        int     len;
        boolean patt;                          // true if pattern mode
        boolean expo = false;                  // true if m.nEee used
        char    kind;
        char    decSep = '.';
        char    curDecSep = '.';
        char    thou = ',';
        boolean group = false;
        int     fract = 0;                     // nr of fractional digits
        String  infinity;
        String  nan;
        char    groupSep;
        LocNumData    locData = null;
        DecimalFormat nf = null;

        code = qu.formt[qu.pfor++];
        kind = 'n';
        ch = qu.formt[qu.pfor];
        if (ch == 'm'){                              // monetary
            kind = 'c';
            qu.pfor++;
        }
        patt = false;
        if (ch == 'P'){                              // pattern
            qu.pfor++;
            patt = true;
            qu.eptr = qu.extRep;
            qu.pfor = frm.skip_format(               // get pattern
                Formatter.F_SPEC,0,0);
            frm.frmGetQuals(null);
        } else if (kind == 'n'){
            frm.frmGetQuals(FLOAT_QUALS);
        } else {
            frm.frmGetQuals(MONE_QUALS);
        }
        frm.handleLocale('n');                       // obtain locale
        locData = frm.nlArr[frm.locNum];
        if (kind == 'c'){                            // the currency one
            if (locData.space == 0){
                locData.monetary(
                    NumberFormat.getCurrencyInstance
                        (frm.locArr[frm.locNum]));
            }
        }
        curDecSep = locData.decSep;
        if (kind == 'c'){                            // the currency one
            curDecSep = locData.monDecSep;
        }
        groupSep = locData.groupSep;
        infinity = locData.infinity;
        nan = locData.nan;
        if ((Formatter.qualMap['L'] & qu.pres) != 0){   // ASCII only
            if (groupSep == '\u00a0'){
                groupSep = ' ';
            }
            infinity = "Inf";
            nan = "NaN";
        }
        locSet: {
            if (patt){
                try {
                    nf = new DecimalFormat(
                        String.valueOf(qu.extRep,0,qu.erLength),
                        new DecimalFormatSymbols(frm.locArr[frm.locNum]));
                } catch (IllegalArgumentException e) {
                    frm.error(Formatter.ERR_FORMAT);
                }
                break locSet;
            }

            if (kind == 'n'){
                group = qu.thou != '\0';
            } else {
                group = qu.thou == '\0';
            }
            fract = -1;
            if (qu.decimal >= 0){                        // fix precision
                fract = qu.decimal;
            } else if (qu.minw != 0){
                fract = 6;
            }
        }
        while (qu.repfact-- > 0){
            byte       valtype;
            BigDecimal big = null;
            boolean    negative = false;
            String     numstr = null;
            int        exp = 0;
            int        off;
            int        rem;
            int        k;
            int        ep;
            int        grCount;
            int        grSize;
            int        epFirst;                 // index of first digit
            int        integr;                  // nr of integral digits
            boolean    special = false;

            valtype = frm.getElemType();
            if ((FL_D & frm.trc) != 0){
                Trc.out.println("valtype: " + valtype);
            }
            switch (valtype){
            case Formatter.FRM_FLOAT:
                frm.getval(Formatter.FRM_FLOAT);
                float f = qu.val_float;
                numstr = infinity;
                special = true;
                if (f == Float.NEGATIVE_INFINITY){
                    negative = true;
                } else if (Float.isNaN(f)){
                    numstr = nan;
                } else if (f != Float.POSITIVE_INFINITY){
                    numstr = Float.toString(f);
                    special = false;
                }
                break;
            case Formatter.FRM_BIGDEC:
                frm.getval(Formatter.FRM_BIGDEC);
                big = (BigDecimal)(qu.val_obj);
                if (patt){
                    v = big.doubleValue();
                } else {
                    numstr = big.toString();
                }
                break;
            case Formatter.FRM_STRING:
                frm.getval(Formatter.FRM_STRING);
                numstr = (String)(qu.val_obj);
                break;
            default:
                frm.getval(Formatter.FRM_DOUBLE);
                v = qu.val_double;
                numstr = infinity;
                special = true;
                if (v == Double.NEGATIVE_INFINITY){
                    negative = true;
                } else if (Double.isNaN(v)){
                    numstr = nan;
                } else if (v != Double.POSITIVE_INFINITY){
                    numstr = Double.toString(v);
                    special = false;
                }
            }
            if (special){
                ep = qu.extRep.length;
                qu.erLength = ep;
                ep = insAffix(negative,false,qu,locData,ep,kind);
                len = numstr.length();                       // determine length
                numstr.getChars(0,len,qu.extRep,ep-len);
                ep -= len;
                epFirst = ep;
                if (kind == 'c'){                            // the currency one
                    ep = insAffix(negative,true,qu,locData,ep,kind);
                } else {
                    if (negative){                           // include sign
                        if (locData.minusPref){
                            qu.extRep[--ep] = locData.minusSign;
                        }
                    } else if (qu.sign == '+'){
                        qu.extRep[--ep] = '+';
                    }
                }
                qu.preflen = epFirst - ep;
                qu.mode = 0;
                frm.insert(qu.extRep,Formatter.FRM_CHARS,  // ins. in record
                    ep,qu.erLength-ep,1);
                continue;
            }
            if (patt){
                numstr = nf.format(v);
                qu.preflen = 0;
                qu.mode = 0;
                frm.insert(numstr,Formatter.FRM_STRING,
                    0,numstr.length(),1);              // insert in record
                continue;
            }
            len = numstr.length();                     // determine length
            off = 0;
            negative = false;
            if (numstr.charAt(0) == '-'){
                off = 1;
                negative = true;
            }
            int lastdig = off;                         // last sig digit
            int firstdig = -1;                         // first sig digit
            int scale = 0;
            int decsep = len;                          // decimal separator
            exp = 0;
            for (int j = off; j < len; j++){
                char c = numstr.charAt(j);
                if (c == '.'){
                    decsep = j;
                } else if (c == 'E'){                  // exponent
                    if (decsep == len) decsep = j;     // . at end
                    boolean expneg = false;
                    if (numstr.charAt(++j) == '-'){
                        j++;
                        expneg = true;
                    }
                    for (; j < len; j++){
                        c = numstr.charAt(j);
                        exp = exp*10 + (c - '0');
                        if (exp < 0) frm.error(IOError.ERR_OUTLIMIT);
                    }
                    if (expneg) exp = -exp;
                    break;
                } else if (c != '0'){
                    lastdig = j;
                    if (firstdig < 0) firstdig = j;
                }
            }
            if (firstdig < 0) firstdig = off;
            scale = lastdig - firstdig + 1;
            if ((decsep >= firstdig) &&                // . in between
                (decsep <= lastdig)){
                scale--;
            }
            int deca = decsep - firstdig;
            if ((exp > 0) == (deca > 0)){              // same sign
                if ((exp > 0) != (exp + deca > 0)){    // result diff. sign
                    frm.error(IOError.ERR_OUTLIMIT);
                }
            }
            exp += deca;
            if (firstdig > decsep) exp++;              // 0.00nnn

            // scale is the number of significant digits starting at
            // firstdig; exp is the decimal exponent; off is the start of
            // the first significant digit (first non-zero or 0 if the only 
            // one).

            if ((FL_D & frm.trc) != 0){
                Trc.out.println("off " + off + " |" + numstr + "|" +
                    " firstdig " + firstdig + " lastdig " + lastdig +
                    " decsep " + decsep + " scale " + scale +
                    " exp " + exp);
            }

            int natexp = exp;
            int carry = 0;
            int cc = 0;
            int lastfract = 0;

            deca = 0;
            if ((Formatter.qualMap['C'] & qu.pres) != 0){  // percent
                deca = 2;                                  // * 100
            } else if ((Formatter.qualMap['M'] & qu.pres) != 0){ // per mille
                deca = 3;                                  // * 1000
            }
            if (exp > 0){
                if (exp + deca < 0){
                    frm.error(IOError.ERR_OUTLIMIT);
                }
            }
            exp += deca;

            expo = false;
            switch (qu.kind){
            case 'e': case 'E': case 'g': case'G':
                expo = true;
            }
            int savexp = exp;
            if (expo){                                 // determine exp
                if (qu.integral >= 0){                 // specified
                    integr = qu.integral;
                } else {
                    integr = 1;
                }
                if (exp < 0){
                    if (exp - integr > 0){
                        frm.error(IOError.ERR_OUTLIMIT);
                    }
                }
                exp -= integr;
            } else {
                integr = exp;
            }
            if ((FL_D & frm.trc) != 0){
                Trc.out.println("exp " + exp + " integr " + integr +
                    " negative " + negative);
            }

            if (fract >= 0){                           // fixed precision
                if (integr > 0){
                    if (integr + fract < 0){
                        frm.error(IOError.ERR_OUTLIMIT);
                    }
                }
                int xxx = round(frm,numstr,firstdig,
                    integr + fract,scale,decsep);
                carry = xxx & 1;
                cc = (xxx >> 1) & 1;
                lastfract = xxx >>> 2;
                if (cc > 0){
                    if (exp > 0){
                        if (exp + 1 < 0){
                            frm.error(IOError.ERR_OUTLIMIT);
                        }
                    }
                    exp++;
                    if (!expo) integr = exp;
                    numstr = "1";
                    scale = 1;
                    firstdig = 0;
                    lastdig = 0;
                    decsep = 0;
                    carry = 0;
                    lastfract = 0;
                    if (!expo) integr = exp;
                }
            }
            if ((qu.kind == 'g') || (qu.kind == 'G')){ // N.B. after
                int expmin = -4;                       // .. rounding
                int expmax = qu.integral >= 0 ? qu.integral : 6;
                if ((exp >= expmin) && (savexp < expmax)){
                    expo = false;
                    exp = savexp;
                    integr = exp;
                }
            }

            if ((FL_D & frm.trc) != 0){
                Trc.out.println("integral: " + integr +
                    " exp " + exp + " cc " + cc + " " + lastfract);
            }
            int ilead0 = 1;                        // integral leading 0's
            int intnum = 0;                        // integral digits
            int itrail0 = 0;                       // integral trailing 0's
            int flead0 = 0;                        // fraction leading 0's
            int fracnum = 0;                       // fraction digits
            int ftrail0 = 0;                       // fraction trailing 0's

            boolean dsep = true;
            if (integr > 0){
                ilead0 = 0;
                if (integr > scale){               // 0's at end
                    itrail0 = integr - scale;
                    intnum = scale;
                } else {
                    intnum = integr;
                }
            }
            if (integr < 0){
                if (scale - integr < 0){
                    frm.error(IOError.ERR_OUTLIMIT);
                }
            }
            if (fract < 0){                        // free fraction
                fracnum = scale - integr;
                if (fracnum < 0){                  // . beyond last
                    fracnum = 0;
                } else if (integr < 0){            // . before first
                    flead0 = -integr;
                    if (flead0 < 0){
                        frm.error(IOError.ERR_OUTLIMIT);
                    }
                    fracnum = scale;
                }
            } else {                               // fixed fraction
                fracnum = scale - integr;
                if (fracnum <= 0){                 // . beyond last
                    fracnum = 0;
                    ftrail0 = fract;
                } else if (integr < 0){            // . before first
                    flead0 = -integr;
                    if (flead0 < 0){
                        frm.error(IOError.ERR_OUTLIMIT);
                    }
                    fracnum = scale;
                    if (fracnum > fract - flead0){
                        fracnum = fract - flead0;
                    }
                    if (flead0 > fract){           // . 0000x  00x truncated
                        flead0 = fract;
                        fracnum = 0;
                    }
                } else {                           // . in betwen
                    if (fracnum < fract){
                        ftrail0 = fract - fracnum;
                    } else {
                        fracnum = fract;
                    }
                }
            }
            int temp = ilead0 + intnum;
            if (temp < 0) frm.error(IOError.ERR_OUTLIMIT);
            temp += itrail0;
            if (temp < 0) frm.error(IOError.ERR_OUTLIMIT);
            temp += flead0;
            if (temp < 0) frm.error(IOError.ERR_OUTLIMIT);
            temp += fracnum;
            if (temp < 0) frm.error(IOError.ERR_OUTLIMIT);
            temp += ftrail0;
            if (temp < 0) frm.error(IOError.ERR_OUTLIMIT);
            dsep = flead0 + fracnum + ftrail0 > 0;

            // integr is the number of digits after which the decimal
            // separator should be written (0 at this point).
            // ilead0 intnum itrail0      flead0 fracnum ftrail0
            //   000     iii   000     .    000    fff     000

            if ((FL_D & frm.trc) != 0){
                Trc.out.println("ilead0 " + ilead0 +
                    " intnum " + intnum + " itrail0 " + itrail0 +
                    " flead0 " + flead0 + " fracnum " + fracnum +
                    " ftrail0 " + ftrail0 + " dsep " + dsep);
            }
            int ersize = 16;                       // -0.e-% and 10 exp digits
            if (group){
                grSize = locData.groupSize;
                temp = intnum + itrail0 + grSize;
                ersize += (temp - 1) / grSize;
                if (ersize < 0){
                    frm.error(IOError.ERR_OUTLIMIT);
                }
            } else {
                grSize = Integer.MAX_VALUE;             // never insert
            }
            ersize += intnum + itrail0;                 // integral digits
            ersize += flead0 + fracnum + ftrail0;
            if (ersize < 0){
                frm.error(IOError.ERR_OUTLIMIT);
            }
            if (kind == 'c'){                           // the currency one
                ersize += locData.affLength;
                if (ersize < 0){
                    frm.error(IOError.ERR_OUTLIMIT);
                }
            }
            temp = ersize + 2;                          // +2 for . and %
            if (temp < 0){
                frm.error(IOError.ERR_OUTLIMIT);
            }
            frm.ensure_extRep(temp,0);
            if ((FL_D & frm.trc) != 0){
                Trc.out.println("ersize: " + ersize +
                    " " + qu.extRep.length);
            }
            ep = qu.erLength;
            if ((Formatter.qualMap['C'] & qu.pres) != 0){         // percent
                qu.extRep[--ep] = locData.percent;
            } else if ((Formatter.qualMap['M'] & qu.pres) != 0){  // per mille
                qu.extRep[--ep] = locData.perMill;
            }
            if (expo){                                  // exponent now
                int e;
                ep = insAffix((exp < 0),false,qu,locData,ep,kind);
                e = exp;
                if (e < 0) e = -e;
                if (e < 0) frm.error(IOError.ERR_OUTLIMIT);
                do {
                    rem = (int)(e % 10);                // remainder
                    qu.extRep[--ep] = (char)(rem + locData.zeroDigit);
                    e /= 10;
                } while (e > 0);
                ep = insAffix((exp < 0),true,qu,locData,ep,kind);
                if ((qu.kind == 'e') || (qu.kind == 'g')){
                    qu.extRep[--ep] = Character.toLowerCase
                        (locData.expSym);
                } else {
                    qu.extRep[--ep] = locData.expSym;
                }
            }
            ep = insAffix(negative,false,qu,locData,ep,kind);

            grCount = grSize;
            char c;
            if (fract < 0){                        // free fraction
                k = lastdig;
            } else {                               // fixed fraction
                k = lastfract;
                if (lastfract == 0) k = lastdig;   // no fract digit cut
            }
            for (; ftrail0 > 0; ftrail0--){
                qu.extRep[--ep] = locData.zeroDigit;
            }
            for (; fracnum > 0; fracnum--){        // copy fraction digits
                c = numstr.charAt(k--);
                if (c == '.') c = numstr.charAt(k--);
                rem = c - '0' + carry;
                carry = (rem > 9) ? 1 : 0;
                if (rem > 9) rem = 0;
                qu.extRep[--ep] = (char)(rem + locData.zeroDigit);
            }
            for (; flead0 > 0; flead0--){
                rem = 0 + carry;
                carry = (rem > 9) ? 1 : 0;
                if (rem > 9) rem = 0;
                qu.extRep[--ep] = (char)(rem + locData.zeroDigit);
            }
            if (dsep | (qu.dradix == '!')){
                qu.extRep[--ep] = curDecSep;
            }
            for (; itrail0 > 0; itrail0--){
                if (grCount-- == 0){
                    qu.extRep[--ep] = groupSep;
                    grCount = grSize-1;
                }
                qu.extRep[--ep] = locData.zeroDigit;
            }
            for (; intnum > 0; intnum--){          // copy integral part
                c = numstr.charAt(k--);
                if (c == '.') c = numstr.charAt(k--);
                if (grCount-- == 0){
                    qu.extRep[--ep] = groupSep;
                    grCount = grSize-1;
                }
                rem = c - '0' + carry;
                carry = (rem > 9) ? 1 : 0;
                if (rem > 9) rem = 0;
                qu.extRep[--ep] = (char)(rem + locData.zeroDigit);
            }
            if (ilead0 > 0){
                if (grCount-- == 0){
                    qu.extRep[--ep] = groupSep;
                    grCount = grSize-1;
                }
                qu.extRep[--ep] = locData.zeroDigit;
            }

            if (qu.integral > 0){                     // minimum specified
                if (Character.isSpaceChar(qu.nfill))  // numeric filling
                    grCount = Integer.MAX_VALUE;
                for (k = 0; k < qu.integral-integr; k++){
                    if (grCount-- == 0){
                        qu.extRep[--ep] = groupSep;
                        grCount = grSize-1;
                    }
                    qu.extRep[--ep] = qu.nfill;
                }
            }
            epFirst = ep;
            if (kind == 'c'){                         // the currency one
                ep = insAffix(
                    negative,true,qu,locData,ep,kind);
            } else {
                if (negative){                        // include sign
                    if (locData.minusPref){
                        qu.extRep[--ep] = locData.minusSign;
                    }
                } else if (qu.sign == '+'){
                    qu.extRep[--ep] = '+';
                }
            }
            if (valtype == Formatter.FRM_STRING){
                if ((FL_F & frm.trc) != 0){
                    String s;
                    s = "" + firstdig + " " + scale + " " +
                        decsep + " " + natexp + " " +
                        exp + " " + integr + " ";
                    s += String.valueOf(qu.extRep,ep,qu.erLength-ep);
                    frm.insert(s,Formatter.FRM_STRING,  // ins. in record
                        0,s.length(),1);
                    continue;
                }
             }

            qu.preflen = epFirst - ep;
            qu.mode = 0;
            frm.insert(qu.extRep,Formatter.FRM_CHARS,   // ins. in record
                ep,qu.erLength-ep,1);
        }
    }

    /** The qualifiers for floating clauses. */
    static final long[] FLOAT_QUALS =
        {Formatter.qualSet("+nfpdL"),Formatter.qualSet("eEgG"),
        Formatter.qualSet("'^"),Formatter.qualSet("CM"),
        Formatter.qualSet("aA"),Formatter.qualSet("zZ"),
        Formatter.qualNum("i.!f"),Formatter.qualNum("n:m"),
        Formatter.qualNum("$")};

    /** The qualifiers for monetary clauses. */
    static final long[] MONE_QUALS =
        {Formatter.qualSet("icanfpdL"),Formatter.qualSet("+("),
        Formatter.qualSet("'^"),Formatter.qualSet("aA"),
        Formatter.qualSet("zZ"),Formatter.qualNum("i.!f"),
        Formatter.qualNum("n:m"),Formatter.qualNum("$")};

    /**
     * Determine if the rounding of a number increases the number of
     * integral digits.
     * If carry = 1 there is a need to propagate it starting from
     * len-scale+fract-1 down; if cc = 1, the number of integral digits will
     * become incremented because of propagation.
     *
     * @param      frm the formatter
     * @param      numstr string of the number
     * @param      firstdig index of the first digit
     * @param      fract number of fractional digits
     * @param      scale number of digits
     * @param      decsep index of the decimal separator (if any)
     * @return     carry
     */

    private static int round(Formatter frm, String numstr, int firstdig,
        int fract, int scale, int decsep){
        if ((FL_D & frm.trc) != 0){
            Trc.out.println("round: " + numstr + " fract " + fract +
                " scale " + scale);
        }
        int carry = 0;
        int cc = 0;
        int lastfract = 0;
        rnd: if ((0 <= fract) && (fract < scale)){     // within scale
            int r;
            char c;

            r = firstdig + fract;
            if (r < 0) frm.error(IOError.ERR_OUTLIMIT);
            if ((firstdig < decsep) && (decsep <= r))  // first to cut
                r++;
            if ((FL_D & frm.trc) != 0){
                Trc.out.println("round at: " + r);
            }
            c = numstr.charAt(r);
            if (c == '.') c = numstr.charAt(--r);
            r--;
            lastfract = r;
            if (c == '5'){
                if (scale-fract == 1){           // just 5
                    c = numstr.charAt(r);
                    if (c == '.'){
                        c = numstr.charAt(--r);
                    }
                    c -= '0';
                    if ((c & 1) == 0) break rnd;
                }
                carry = 1;
            } else if (c > '5'){
                carry = 1;
            }
            if ((FL_D & frm.trc) != 0){
                Trc.out.println("prop: at " + r + " carry " +
                    carry);
            }
            cc = carry;
            for (;r >= firstdig; r--){
                int rem;
                c = numstr.charAt(r);
                if (c == '.') continue;
                rem = (int)c - '0' + cc;
                cc = (rem > 9) ? 1 : 0;
            }
        }
        if ((FL_D & frm.trc) != 0){
            Trc.out.println("round cc " + cc + " carry " + carry +
               " lastfract " + lastfract);
        }
        return (lastfract << 2) | (cc << 1) | carry;
    }

    /**
     * Deliver an affix according to the one passed as argument and
     * the qualifiers passed. The affix is delivered in extRep.
     *
     * @param      neg <code>true</code> if negative
     * @param      prefix <code>true</code> if prefix
     * @param      qu qualifiers
     * @param      locData locale data
     * @param      ep index in extRep
     * @param      kind 'c' if monetary
     */

    /* The elements to insert in the affix are coded into a mask, with
     * the following convention:
     *
     *   b0:  currency sign
     *   b1:  space
     *   b2:  space
     *   b3:  (
     *   b4:  )
     *   b5:  -
     */

    static int insAffix(boolean neg, boolean prefix, Cdata qu,
        LocNumData locData, int ep, char kind){
        byte   msk;
        String csign;

        if ((Formatter.qualMap['i'] & qu.pres) != 0){
            csign = locData.intnCsign;
        } else {
            csign = locData.csign;
        }
        if (neg){
            if (kind != 'c'){                   // not the currency one
                if (prefix == locData.minusPref){
                    qu.extRep[--ep] = locData.minusSign;
                }
                return ep;
            }
            msk = (prefix) ? locData.cyNegPref : locData.cyNegSuff;
        } else {
            if (kind != 'c'){                   // not the currency one
                return ep;
            }
            msk = (prefix) ? locData.cyPosPref : locData.cyPosSuff;
        }
        if ((msk & 1) != 0){
            if ((Formatter.qualMap['c'] & qu.pres) != 0) msk &= ~(0x7);
        }
        if (neg){
            if ((Formatter.qualMap['('] & qu.pres) != 0){
                msk &= ~((1<<5) | (1<<6));
                msk |= 1 << ((prefix)? 3 : 4);
            }
        }
        if ((msk & 1<<4) != 0) qu.extRep[--ep] = ')';
        if ((msk & 1<<2) != 0) qu.extRep[--ep] = locData.space;
        if ((msk & 1) != 0){
            for (int j = csign.length() - 1; j >= 0; j--){
                qu.extRep[--ep] = csign.charAt(j);
            }
        }
        if ((msk & 1<<1) != 0) qu.extRep[--ep] = locData.space;
        if ((msk & 1<<5) != 0) qu.extRep[--ep] = locData.minusSign;
        if ((msk & 1<<3) != 0) qu.extRep[--ep] = '(';
        return ep;
    }   
}
