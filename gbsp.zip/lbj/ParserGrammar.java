/*
 * @(#)ParserGrammar.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;
import lbj.ParserNode.*;
import lbj.ParserLexer.*;

/**
 * The <code>ParserGrammar</code> class provides a representation
 * for a grammar.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

//class ParserGrammar extends ParserEngine {
class ParserGrammar {

    /** The lexer for the BNF. */
    ParserLexer lex;

    /** The trace flags. */
    int trc;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    a   basic operations
     *    b   user trace
     *    c   lexer tables compression
     *    d   dictionary
     *    e   directory tables
     *    f   internal form
     *    g   lexer generation
     *    h   lexer generation details
     *    i   input lexing
     *    j   files
     *    k   Chomsky type
     *    l   left parse
     *    m   allocation
     *    n   lexer statistics
     *    p   parsing
     *    q   parsing details
     *    r   even more parsing details
     *    s   parse tree construction
     *    t   grammar semantic analysis
     *    u   grammar manipulation
     *    v   lexer values
     *    w   messages
     *    x   lexer
     *    z   stack trace
     * </pre></blockquote><p>
     */

    static final int FL_A = 1 << ('a'-0x60);
    static final int FL_B = 1 << ('b'-0x60);
    static final int FL_C = 1 << ('c'-0x60);
    static final int FL_D = 1 << ('d'-0x60);
    static final int FL_E = 1 << ('e'-0x60);
    static final int FL_F = 1 << ('f'-0x60);
    static final int FL_G = 1 << ('g'-0x60);
    static final int FL_H = 1 << ('h'-0x60);
    static final int FL_I = 1 << ('i'-0x60);
    static final int FL_J = 1 << ('j'-0x60);
    static final int FL_K = 1 << ('k'-0x60);
    static final int FL_L = 1 << ('l'-0x60);
    static final int FL_M = 1 << ('m'-0x60);
    static final int FL_N = 1 << ('n'-0x60);
    static final int FL_P = 1 << ('p'-0x60);
    static final int FL_Q = 1 << ('q'-0x60);
    static final int FL_R = 1 << ('r'-0x60);
    static final int FL_S = 1 << ('s'-0x60);
    static final int FL_T = 1 << ('t'-0x60);
    static final int FL_U = 1 << ('u'-0x60);
    static final int FL_V = 1 << ('v'-0x60);
    static final int FL_W = 1 << ('w'-0x60);
    static final int FL_X = 1 << ('x'-0x60);
    static final int FL_Y = 1 << ('y'-0x60);
    static final int FL_Z = 1 << ('z'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /** The start symbol entry. */
    ParserDic start_sy;

    /** The dictionary of non-terminals. */
    HashDic ntDic;

    /** The dictionary of terminal entries. */
    HashDic terDic;

    /** The dictionary of replacement entries. */
    HashDic repDic;

    /** The dictionary of shorthand entries. */
    HashDic shoDic;

    /** The dictionary entry for TERMINALS. */
    ParserDic dic_ter;

    /** The dictionary entry for the standard empty string. */
    static ParserDic dic_emp;

    /** The dictionary entry for the user empty string. */
    ParserDic dic_usrEmp;

    /** The list of lexemes. */
    ParserNode lex_list;

    /** The list of LEXIS. */
    ParserNode lxi_list;

    /** The current non-terminal being defined. */
    ParserDic defnt;

    /** The alphabet rule. */
    ParserNode alphaRule;

    /** The alphabet. */
    IntSet alphabet;

    /** The token to be ignored. */
    ParserDic ignore;

    /** The attributes. */
    int attr;

    /**
     * Construct the internal representation. Initialize the dictionaries.
     */

    ParserGrammar(){
        this.ntDic = new HashDic();
        this.terDic = new HashDic();
        this.repDic = new HashDic();
        this.shoDic = new HashDic();

        if (dic_ter == null){
            dic_ter = new ParserDic(ParserDic.TER_SPE,new Str("TERMINALS"));
            dic_emp = new ParserDic(ParserDic.TER,Str.EMPTY);
            dic_emp.status |= ParserNode.EO | ParserNode.EM;
        }
        this.lxi_list = null;
        this.lex_list = null;
    }

    /**
     * Dictionary:
     *
     * The nonterminal dictionary contains one entry for each nonterminal
     * and also one for each redefined terminal.
     * The entry points to its name and definition in the graph.
     * It is organised as an hash table and also as a list ordered as the
     * defining occurrences in the source.
     * The terminal dictionary contains one entry for each terminal.
     * It is organised in the same way.
     */

    /* These are the requirements for nonterminal names (including the internal
     * ones):
     *
     * - complete freedom in nonterminal names: the <...> notation is
     *   a means to denote nonterminals, which has the restriction that
     *   `>' may not be introduced, but this is not a restriction of the
     *   API for building the grammar. It can be overcome by allowing strings
     *   inside: <"...">. It could be useful to represent terminals which have
     *   a replacement.
     * - precision in the references in traces: use unambiguous names even
     *   in presence of cloned elements
     * - stability of internal names: e.g. internal names can start with a
     *   `&' which may not be confused with true names as long as none of
     *   them starts with `&'. At the first one encountered which does,
     *   internal names could be rendered in a different way. However, the
     *   previous traces would be difficult to understand.
     * - printing of the grammar in a way whih could be read back and the
     *   grammar rebuild.
     *
     * Note that there are no problems with the API since internal names are
     * not stored in a dictionary, and what matters are the references to
     * the dictionary entries. The problem here is to find an unambiguous way
     * for representing a grammar in textual form.
     * Note that it is not possible to generate unique names during the
     * processing of the grammar because even if at the time a new name is
     * needed, a unique one can be created, there is no guarantee that later
     * on that very same name does not occur in the input.
     * There would be a need to assign internal names only when no more true
     * names are inserted, but that is not good since in the meantime there is
     * a need to trace rules, and to understand them, which would be confusing
     * if at the end names are changed.
     *
     * It is impossible to meet all the requirements above at the same time.
     * An internal name, whatever the notation used, can clash with a true
     * name which is encountered later. A solution to overcome this can be
     * to keep a counter N of the number of `&' characters found at the
     * beginning of true names, and to prepend N+1 ampersands to internal
     * names.  This means that they actually change during tracing, but in
     * a way which is relatively easy to understand. To solve completely this,
     * a different notation must be used from the very beginning for internal
     * names, like e.g.: <<...>> or «...», or <&"...">. This requires,
     * however, to accept it in input as well, and to enter such names in
     * a dedicated dictionary, or in ntDic, but with the INTERN attribute,
     * and make search keep it into account.
     * This seems too much. Printing the grammar is always possible at the end
     * because there all nonterminal names are known, and thus unique names
     * can be found for internal nonterminals, albeit (possibly) different from
     * the ones assigned formerly. Reading it back is not done, however.
     * Thus a solution could be to use a notation like e.g.: «...», and forget
     * about reading it back. After all, traces have decorations which are
     * useful for understanding what is being done, and they are not meant to
     * be read back.
     *
     * For replacements, an apex can be added to the origin rule, which is
     * much less used than the replaced one, and it is used in the lexicon.
     * The same occurs also when disentangling the grammar even without
     * replacements.
     * This problem is a bit different from that of internal names: here
     * the names are visible to the user (and not only in traces), which means
     * that having unambiguous ones could be more important.
     * Note that it is not possible to add the apex to the origin entry because
     * it is already there in the hash table. It can be reused to hold the
     * redefined one (by changing .def, .point, .line), and a new one with
     * the apex introduced.
     * The solution is to keep the name unchanged, add an attribute, and build
     * the name in toString(). This allows to plug replacement rules into the
     * origin entries without a need to scan the grammar to change them.
     * Another reason is that there can be methods for accessing derivations of
     * nonterminals which have names as arguments, and the user knows what
     * names s/he wrote, not the ones with the apex.
     * Names are differentiated only in printing. Note that it is not even
     * necessary to insert them into the hash table of the dictionary: they are
     * simply added to the list, as done for internal names. Hash tables are
     * needed only when there is a need to seach names. Showing the exact
     * binding serves mainly in tracing, while it does not when generating
     * parser tables (for which also the angular brackets are not needed).
     * The notation which is used is to add an apex after the <...>, (i.e.
     * <...>') which allows to avoid any clashes with nonterminal names which
     * end with an apex.
     * When that occurs on a terminal, if it terminates with an apex, it is
     * enclosed in quotation marks, and the apex added after it.
     * Note that a nonterminal followed by an apex in the input is reported
     * as that nonterminal followed by an apex in double quotes, which means
     * that there is no ambiguity.
     *  
     * When a terminal is redefined, all its applied occurrences in grammar
     * rule are implicitly replaced by occurrences of a virtually introduced
     * syntactic category which has the same name followed by an apex.
     * It is not correct to flag with an apex the origin (non redefined)
     * symbols because when they are terminals, the result is confusing.
     * E.g. consider this grammar:
     *
     *     <S> ::= a
     *     LEXIS a
     *     a => b <>
     *
     * The resulting grammar would be:
     *
     *     <S> ::= a
     *     a ::= b a'
     *
     * The second rule would contain an "a'" which is a terminal, but is not
     * the right one.
     *
     * N.B. non-ASCII characters are not accepted as terminals as nonmeta:
     * to enter them, use quoted strings.
     * This allows to use the «...» notation.
     */

    static class HashDic extends HashTbl {

        /** The head of the ordered list. */
        ParserDic head;

        /** The last of the list. */
        ParserDic last;

        /** The last element added. */
        ParserDic lastAdded;

        /**
         * Search an element with a given code and kind.
         *
         * @param   buf string
         * @param   off start offset in it
         * @param   len string length
         * @param   kind of element
         * @return  reference to the element, <code>null</code> if not found
         */

        ParserDic search(char[] buf, int off, int len, int kind){
            if (this.elemNr == 0) return null;
            int hvalue = hashValue(buf,off,len);
            HashNode pr = null;
            HashNode e = null;
            ParserDic d = null;
            sea: for (e = this.hdir[hvalue];
                e != null; e = e.hlink){              // scan the chain
                d = (ParserDic)e;
                if (d.equals(buf,off,len)){
                    if (d.kind == kind) break sea;
                }
                pr = e;
            }
            hashLast(pr,hvalue);
            if (e == null) d = null;
            return d;
        }

        /**
         * Search an element with a given code and kind.
         *
         * @param   s string
         * @param   kind of element
         * @return  reference to the element, <code>null</code> if not found
         */

        ParserDic search(Str s, int kind){
            return search(s.buffer,0,s.length,kind);
        }

        /**
         * Search an element with a given code and non-terminal kind.
         *
         * @param   s string
         * @return  reference to the element, <code>null</code> if not found
         */

        ParserDic search(Str s){
            return search(s.buffer,0,s.length,ParserDic.NTER);
        }

        /**
         * Search an element which is <code>equals()</code> to the specified one.
         *
         * @param   el reference to the element
         * @return  reference to the element, <code>null</code> if not found
         */

        public ParserDic search(ParserDic el){
            if (el == null) return null;
            if (this.elemNr == 0) return null;
            int hvalue = hashValue(el.code,0,el.code.length);
            HashNode pr = null;
            HashNode e = null;
            ParserDic d = null;
            sea: for (e = this.hdir[hvalue];
                e != null; e = e.hlink){              // scan the chain
                d = (ParserDic)e;
                if (d.equals(el.code,0,el.code.length)){
                    if (d.kind == el.kind) break sea;
                }
                pr = e;
            }
            hashLast(pr,hvalue);
            if (e == null) d = null;
            return d;
        }

        /**
         * Ensure that this dictionary contains an element whose code
         * and kind are the same as the those passed as argument.
         * If it is not yet present, it allocates a new element for it.
         * It appends the new element at the end of the ordered list.
         *
         * @param   s string
         * @param   k kind
         * @return  <code>true</code> if the element has been inserted
         */

        boolean addUnique(Str s, int k){
            HashChars h = search(s.buffer,0,s.length,k);
            this.lastAdded = (ParserDic)h;
            if (h != null) return false;
            h = new ParserDic(k,s);                // allocate entry
            add(h);
            ParserDic d = (ParserDic)h;
            this.lastAdded = d;
            if (this.last == null) this.head = d;  // append to list
            else this.last.suc = d;
            this.last = d;
            return true;
        }

        /**
         * Create a new dictionary entry with the specified code and kind.
         *
         * @param   s string, <code>null</code> to generate a unique name
         * @param   k kind
         * @return  reference to the created element
         */

        public ParserDic newParserDic(Str s, int k){
            boolean intern = false;
            if (s == null){
                intern = true;
                s = this.intName;
                if (s.length == 0){          // first
                    s.append("&0");
                } else {                     // create an incremented name,
                    int carry = 1;           // .. no counters: no overlflow
                    for (int i = s.length-1; i > 0; i--){
                        s.buffer[i] += carry;
                        if (s.buffer[i] > '9'){
                            s.buffer[i] = '0';
                            carry = 1;
                        } else {
                            carry = 0;
                        }
                    }
                    if (carry > 0){
                        s.cutInsert(1,0,"1",1,0,1);
                    }
                }
            }
            HashChars h = new ParserDic(k,s);      // allocate entry
            ParserDic d = (ParserDic)h;
            if (intern) d.status |= ParserNode.INTER;
            return d;
        }

        /** The string for generating unique names. */
        private Str intName = new Str();

        /**
         * Append to the list of this dictionary an element whose code
         * and kind are the same as the those passed as argument.
         *
         * @param   s string, <code>null</code> to generate a unique name
         * @param   k kind
         * @return  <code>true</code> if the element has been inserted
         */

        void append(Str s, int k){
            ParserDic d = newParserDic(s,k);
            this.lastAdded = d;
            if (this.last == null) this.head = d;  // append to list
            else this.last.suc = d;
            this.last = d;
        }

        /**
         * Trace this dictionary.
         */

        private void sdic_trace(){
            ParserDic p = this.head;
            while (p != null){
                p.trace();
                p = p.suc;
            }
        }

        /** 
         * Remove the marks in this dictionary.
         *
         * @param   deep <code>true</code> to remove also the marks
         *          from the definitions
         */

        void unmark(boolean deep){
            for (ParserDic h = this.head; h != null; h = h.suc){
                h.status &= ~ParserNode.MRK;
                if ((deep) && (h.def != null)) h.def.unmark();
            }
        }

        /**
         * Remove the specified element from this dictionary.
         *
         * @param   el element
         * @return  <code>true</code> if the element was present
         */

        public boolean remove(ParserDic el){
            if (!super.remove(el)){
                return false;
            }
            ParserDic prev = null;
            for (ParserDic h = this.head; h != el; h = h.suc){
                prev = h;
            }
            if (prev == null){
                this.head = el.suc;
            } else {
                prev.suc = el.suc;
            }
            return true;
        }
    }

    /**
     * Trace all the dictionaries.
     */

    void dic_trace(){
        Trc.out.println("--- nt dictionary ---");
        this.ntDic.trace();
        Trc.out.println("--- ter dictionary ---");
        this.terDic.trace();
        Trc.out.println("--- sho dictionary ---");
        this.shoDic.trace();
        Trc.out.println("--- rep dictionary ---");
        this.repDic.trace();
    }

    /** 
     * Print the rules present in a dictionary.
     *
     * @param      d dictionary
     * @param      attd attributes to be shown on the entries
     * @param      attn attributes to bo shown on rules
     * @param      trc trace stream
     */

    void trace_dic(HashDic d, long attd, long attn){
        trace_dic(d,attd,attn,Trc.wrt);
    }

//    void trace_dic(HashDic d, long attd, long attn, PrintStream trc){
    void trace_dic(HashDic d, long attd, long attn, PrintWriter trc){
        Str st = new Str();
        for (ParserDic h = d.head; h != null; h = h.suc){
            trace_dic(d,h,attd,attn,st);
            if (st.length > 0) trc.println(st);
        }
    }

    /** 
     * Print the rules of the speified entry in the specified dictionary.
     *
     * @param      d dictionary
     * @param      h dictionary entry
     * @param      attd attributes to be shown on the entries
     * @param      attn attributes to bo shown on rules
     * @param      st return string
     */

    void trace_dic(HashDic d, ParserDic h, long attd, long attn, Str st){
        st.length = 0;
        if ((ParserNode.EXP_GRO & attn) == 0){
            if ((ParserNode.G_GRP & h.status) != 0){  // group
                return;
            }
            if ((ParserNode.INTER & h.status) != 0){  // internal to group
                return;
            }
        }
        h.toString(st,attd);
        st.append(" ");
        String del = "::=";
        boolean org = false;
        if (d == this.shoDic){
            del = "==";
            org = true;
        } else if (d == this.repDic){
            del = "=>";
        }
        st.append(del);
        if (h.def != null){
            st.append(" ");
            h.def.toString(st,ParserNode.REP_RULE | attn);
        } else if (org && (h.org != null)){
            st.append("@ ");
            h.org.toString(st,attd);
        }
    }

    /**
     * Add a new dictionary entry if not present and store the position
     * passed as argument in it. The position is stored only if the
     * element was not present.
     *
     * @param      d dictionary
     * @param      s string of its name
     * @param      k kind of node
     * @param      p point
     * @param      l line
     */

    /* The point and line are inserted only if the element is created.
     * This allows to keep the position of the first occurrence, and allows
     * to redefine it when a definition is processed.
     *
     * Note that the .def value is not passed because callers need to test
     * it detect multiple definitions (which is the case when it is not
     * null and a definition is being processed).
     */

    ParserDic addDic(HashDic d, Str s, int k, long p, long l){
        boolean add = true;
        if (s != null){
            add = d.addUnique(s,k);
        } else {
            d.append(s,k);
        }
        ParserDic h = d.lastAdded;
        if (add){
            h.point = p;
            h.line = l;
        }
        if ((FL_D & this.trc) != 0){
            Trc.out.println("adding: " + s + " " + k + " " + h.point);
        }
        return h;
    }

    /**
     * Add a new dictionary nonterminal entry if not present and store
     * the position passed as argument in it.
     *
     * @see        #addDic(ParserGrammar.HashDic,Str,int,long,long)
     */

    ParserDic addDic(HashDic d, Str s,
        long p, long l){
        return addDic(d,s,ParserDic.NTER,p,l);
    }

    /**
     * Construct a new node and store the position passed as argument
     * in it.
     *
     * @param      k kind of node
     * @param      pos position
     */

    ParserNode newNode(int k, long pos){
        ParserNode p = new ParserNode(k);
        p.point = pos;
        return p;
    }

    /**
     * Deliver a string which denotes the dictionary to which the
     * element passed as argument belongs.
     *
     * @param      d reference to the element
     * @return     string
     */

    String whichDic(ParserDic d){
        for (ParserDic h = this.ntDic.head; h != null; h = h.suc){
            if (h == d) return "%n";
        }
        for (ParserDic h = this.terDic.head; h != null; h = h.suc){
            if (h == d) return "%t";
        }
        for (ParserDic h = this.shoDic.head; h != null; h = h.suc){
            if (h == d) return "%s";
        }
        for (ParserDic h = this.repDic.head; h != null; h = h.suc){
            if (h == d) return "%r";
        }
        return null;
    }


    /* The analysis of the grammar. */

    /* These algorithms visit the rules repeatedly synthetizing the attributes.
     * When an attribute has been determined for a rule, that rule is not
     * visited again. Thus, the number of rules which are visited decreases
     * as the algorithm proceeds. Another solution would be to visit
     * recursively the grammar, avoiding endless recursions.
     * N.B. an alternative which refers to itself must not be skipped
     * because it is not known yet whether there is some other alternative of
     * the same nonterminal that produces a terminal string. If there are,
     * then also that alternative can produce it. Thus, that rule must be
     * visited again. This makes the visit more complex.
     * The algorithm marks the relevant alternatives, and the nonterminals
     * which have at least a relevant alternative.
     *
     * The unability to determine that an attribute is definitely false before
     * reaching the end of the algorithm can be quite common. When that is the
     * case, there is no advantage in keeping a MRK to skip (pieces of) rules
     * since it would be set only on nodes which have the attribute true.
     *
     * When the attribute is determined for a node, but it is not for the
     * alternative in which the node lies, no changes are reported, and,
     * if no other changes occur, the algorithm stops. This is because
     * a next cycle would change nothing.
     * This is common to all this kinds of algorithms.
     *
     * Looping algorithms visit all the productions, not only the ones
     * which are reacheable from the starting symbol. This is the correct
     * thing to do in most cases, otherwise conditions would not be checked
     * on them, and errors not reported (which means that when the grammar
     * is changed to make such nonterminals reacheable, then extra errors
     * will be reported, which is unfair).
     * Some algorithms can also be implemented as a recursive visit of
     * the grammar. However, it is safer to use looping algorithms because
     * they do not have the problem of avoiding the endless recursion and
     * also the need of visiting again the grammar to determine the attributes
     * of alternatives once those of the nonterminals are determined.
     * Note that during a recursive visit, it is possible to encounter first
     * usages of nonterminals and then definitions, which means that there
     * can be attributes which are determined later, and thus other visits
     * are required until nothing more changes.
     * There are some algorithms, like e.g. the one that computes the EO
     * attribute, in which there is a need to compute some attributes even
     * on circular definitions: they work by looping until no more changes
     * occurs and nonterminals have the attribute they eventually have even
     * if they refer to themseleves. I.e. such autoreferences do not prevent
     * the computation of the attribute: the final value of the attribute,
     * computed when no more changes occur, if set on the autoreference
     * nonterminals do not make the attribute of their rule change. If at the
     * end the attribute is false, and the rules do not change it, it remains
     * false, and the same if it is true. It is a stable state.
     * E.g. in <A> ::= <A> | "" after the first cycle it is known that the
     * second alternative produces only the empty string, and that all other
     * alternatives would do so under the condition that the same nonterminal
     * does. In this case it is sufficient to assume that rules produce only
     * the empty string, until an element which is known not to do is found.
     *
     * Since the grammar is disentangled (i.e. there are no rules which belong
     * to the grammar and to the lexicon), then most algorithms can have a
     * single loop in which they visit repeatedly the rules.
     * To interpret correctly the nodes, when visiting a GRAM rule, the nodes
     * which refer to nonterminals which are LEXEME are considered lexemes,
     * while they are not when LXS rules are visited.
     * When visiting GRAM rules, lexemes are skipped for TR, do not generate
     * empty strings, etc.
     * E.g. a rule <A>, which is referred to from the grammar and the lexicon
     * can use a nonterminal <D> which is a lexeme. <A> is cloned creating an
     * <A>', but <D> not. When <A> is visited, <D> is considered as a lexeme.
     * When <A>' is visited, <D> is not a lexeme.
     * In order to maintain flexibility, attributes such as LEXEME are not
     * marked on nodes, but are retrieved from the elements referred to by
     * them.
     *
     * If the algorithms were implemented into a recursive form, there would
     * be a need to pay attention to nonterminals which are lexemes and which
     * are used in two rules: a lexeme and a non-lexeme one because they must
     * be visited both in their replaced rule and not, which means that they
     * must not be simply marked as visited the first time (which can be the
     * one visit in which the normal branch is taken), unless when nonterminals
     * which have a replacement are visited, both branches are taken.
     *
     * When visiting recursively the grammmar there would be a need to remember
     * that a token has been entered so as to follow the normal binding
     * from then on. However, the problem seems to be still there since
     * there is a need to have two separate places to store the attributes
     * since the rules have two meanings. It is possible to store the
     * attributes of nonterminals into some fake entries, but no attributes
     * should be stored in nodes.
     * Morever, when using algorithms which loop over nonterminals, taking
     * care of the double binding (and meaning) seems quite complex.
     * Probably it is not even possible to replace the algorithms which loop
     * over the grammar until nothing more changes with recursive visits.
     * An alternative is to run the algorithm twice on the grammar first and
     * then on the lexicon and take the AND of the attributes determined in
     * that way. There is in such a case a need to cope with replacements since
     * when visiting the grammar, LEXEME nodes must not be visited, while when
     * visiting the lexicon we start from lexemes following the replacement,
     * and thereafter not following them.
     *
     * Let's see how one of the algorithms could be implemented with a
     * recursive visit to the grammar.
     * When evaluating TR a rule can be encountered which contains an
     * autoreference, like e.g. <A> ::= a <A> | a, and the TR attribute of
     * <A> is determined only by a subsequent rule (or alternative).
     * The first need be visited again.  Perhaps this could be done with a
     * second try only. Or, better, making the recursive vistit of <A>, when
     * a nonterminal is encountered, it is visited, except for the very same
     * rules which are being visited.
     * I.e. if the marking is done on rules instead of nonterminals, no endless
     * recursion is done, and all rules are visited, which means that in the
     * example above, the second alternative is visited and the attribute
     * determined. Let's see if there are cases in which a first alternative
     * needs a second be evaluated, which in turn needs the first. That would
     * spoil this technique. This case never occurs because the second can
     * either be evaluated or not, and in the latter case it can benefit from
     * a third alternative, and not by the previous one.
     * Algorithms such as EO seem a bit harder: in <A> ::= <A> | "", when the
     * first alternative is visited, a recursion is made and the second one
     * visited. However, the second one may not decrete that <A> is EO.
     * A solution could be to mark MRK the alternative, unwind recursion,
     * thus making the first alternative be known, get then the attribute of
     * the second since it has already been determined, and finally mark <A>
     * as EO. There is one case which is difficult to treat: <A> ::= a | <A>.
     * When the second alternative is visited, <A> is not visited again.
     * There is a need to do what can be done with the information available
     * at that point. The solution is that when <A> is visited again from
     * that alternative, it returns the attribute as known up to that point.
     * However, there is a case which is really difficult:
     *
     *    <S> ::= a <A>
     *    <A> ::= <B> b
     *    <B> ::= <S> | b
     *
     * <S> is visited, and in it <A>, and then <B> and in it <S>. The last
     * is not TR at that point, and all its alternatives seem to have been
     * visited, which is not true because there is one alternative of
     * one of its sons which is not. The solution is to mark as visited an
     * alternative when it is really over, but then a way must be found to
     * skip the visit of a cyclic alternative. This is not simple, since it
     * requires quite a bit of housekeeping.  In conclusion, the explorations
     * of the combinations of all the alternatives makes the technique of the
     * recursive visit difficult to implement.
     *
     * If replacements were not really plugged into the .def fields, there
     * would be a need in many places when accessing nonterminals to make a
     * test and to switch to .repl. This is the case for general algorithms
     * such as the ones which determine TR, etc.
     *
     * Since the grammar as divided in two, i.e. tokens are terminals which
     * cannot generate the empty string, then EM (and EO) are not propagated
     * to the grammar proper.
     *
     * There is no need to visit repDic on most algorithms, except the ones
     * which allow to find errors before the plugging of replacement rules into
     * the grammar.
     * Otherwise (i.e. if no plugging were done) the algorithms should be
     * run on the grammar first (and the looping ones must be run on GRAM
     * nonterminals only), and then on the lexis (which perhaps for the
     * looping ones it means on the non-GRAM nonterminals).
     *
     * Operators in lexis
     *
     * The result of operations (complement, etc.) might not be a terminal
     * string. E.g. <A> - <A>, and !{<char>}*, which denotes the empty
     * language. It is not possible to know it and also if the results of
     * operations contain the empty string or only the empty string until
     * (unless) an automaton is built.
     *
     * The first idea is to compute the attributes in two separate ways
     * for the grammar and the lexicon. This seems simple at first, but
     * it turns out to be more complex than using a mixed approach (see)
     * below. Moreover, type-2 lexemes which do generate terminal strings
     * are not recognised as such since the NFA construction is not able to
     * detect that, and thus are left -TR at the end.
     *
     * It is easy to calculate some attributes on the lexemes once a DFA has
     * been built: all the lexemes which are in the set of the recognised
     * ones in the initial state are EM, and the ones which are in no other
     * state are also EO. The ones which are in no state at all are -TR.
     * A solution to determine them on all nonterminals (or even their
     * alternatives) occurring in the lexis is to build a DFA for each of them
     * (and for each alternative). This is expensive.
     *
     * Another solution is to analyse the (piece of) NFA of each alternative
     * and nonterminal right after having generated it.
     * If there is no path from the starting state to the ending one,
     * then the nonterminal (alternative) is -TR. This is done on each
     * alternative by taking only its edges, and also on whole nonterminals
     * in the same way.
     * If there is a path made all by e-edges, the nonterminal is EM, and
     * if all paths are like that, the nonterminal is EO.
     * However, alternatives containing autoreferences have a NFA which has no
     * direct path from the start state to the end one (they have a loop on
     * the start or on the end one). This requires the introduction of void
     * (virtual) edges to make autoreferences resemble as ordinary ones
     * so as to use the normal algorithms to analyse their NFAs.
     * Moreover, when there are autoreferences, it is not possible to know
     * what a referred nonterminal generates until all the chain has been
     * generated.
     * This means that there is a need to make a second pass on such nonterminals
     * to complete the computation of the alternatives.
     * The first pass serves to compute TR on whole nonterminals, and during it
     * no void edges are introduced since they must reflect the fact that the
     * nonterminal generates strings, which is not known at that moment.
     * E.g. autoreferences can occur in alternatives which are not preceded by
     * others that generate strings.
     * This need be done on all nonterminals, not only on lexemes.
     * E.g. in <B> ::= a <S> b | c. <S> ::= a <B>, after the reference to <S>
     * is processed, a back edge to the reference of <B> in it to the start of
     * the NFA for <B> is present. However, the NFA for <B> is not yet complete
     * since its second alternative has not yet been processed. Therefore it is
     * not possible to calculate the attributes of <S>, which turns out not to
     * be TR at this moment.
     * There is a need to build a NFA in the first pass for all the nonterminals
     * cointaining autoreferences as to make this done.
     * During the second pass the void edges are created, and all alternatives
     * computed correctly.
     * In void edges the nonterminal they stand for is recorded.
     * When an autoreference is preceded by a path that does generate at least
     * a non-empty string, it is marked as LEF.
     * When returning from the top call of a nonterminal, its void edges
     * are analysed, and if a path that does not generate the empty string
     * found to the ending state of the nonterminal, that nonterminal is
     * marked as RIG.
     * At the end, the nonterminals which are LEF and RIG are marked as AIN.
     * This solution computes all attributes in a uniform way for nonterminals
     * and alternatives by examining the paths in the generated (pieces of)
     * NFAs (which requires the introduction of void edges), and it requires
     * to determine the attributes as all autoreferencing nonterminals by
     * making a second pass (this happens on few elements only, though).
     *
     * Another solution is to determine the attributes on nonterminals first
     * (which does not require void edges), and then to process autoreferencing
     * nonterminals again and compute the attributes by rolling them up.
     * But this is more complex than usind the tranditional algorithm.
     *
     * A better solution is to compute the attributes for the elements which
     * cannot be treated by the traditional algorithm: the ones which are
     * operators, to mark them and then use the traditional algorithm.
     * This marking is possible and easy because this NFA is computed
     * completely the first time it is generated.
     *
     * TR is set when there are undefined nonterminals so as not to generate
     * extra errors. It is also set on ranges for the same reason.
     * The detection of TR is done on each alternative, and the ones which
     * do not generate terminals reported.
     * TR is set on all alternatives of lexis nonterminals which have erroneous
     * autoreferences so as not to produce extra errors.
     * EM, EO are never set on ranges.
     *
     * TY2: complement, and intersection lead to type-1. Since they can only
     * be used in the lexis, which must be regular, the result of all
     * operations is considered to be regular, and the operands rejected when
     * they are not such.
     */

    /** 
     * Find irrelevant nonterminals. They are those for which this does
     * not hold: S =>* aAb and A =>* x (x in VT*), i.e. that are not present
     * in a derivation of the starting symbol or that do not produce
     * terminal strings.
     * Determine the attributes:
     * <ul>
     * <li>st: <code>true</code> for the nt's that derive from the start
     * <li>tr: <code>true</code> for the nt's that produce strings in VT*
     * <li>em: <code>true</code> for the nt's that produce the empty string.
     * </ul>
     */

    /* The algorithm synthetizes the terminal attribute for each sequence,
     * and then for each alternative, and finally for the enclosing node or
     * nonterminal that refers to that set of alternatives. When all the
     * alternatives have that attribute set, the enclosing node or nonterminal
     * is marked with the MRK attribute to remember that its visit is complete.
     *
     * A group which contains alternatives which are all irrelevant, eventually
     * does not have the TR attribute. Likewise, an alternative which contains
     * a nonterminal or a group which are irrelevant does not have it.
     * The only exception are groups which allow zero repetitions, which
     * can always produce the empty string.
     * A group which allows zero repetitions and contains alternatives
     * none of which produces terminals is effectively irrelevant.
     * At best the parser can report that the null repetition has been chosen,
     * which seems the interpretation closest to the grammar.
     * Note the difference with a nonterminal which produces the empty string.
     * E.g.: <A> ::= a <B> c. <B> ::= . makes the string "ac" be produced as:
     * <A> => a <B> c => ac having matched <B>, while in: <A> ::= a [ b ] c,
     * the group can be matched or can even not if it is considered as a
     * shorthand for <A> ::= a b c | a c.
     * It is debatable that groups should be considered as "macro"
     * substitutions in the grammar. It is an intuitive (albeit not a
     * hundred percent precise) description.
     * It does not enter constraints (at least the ones defined now)
     * and all other nodes whose purpose is not to produce strings.
     *
     * The algorithm determines the TR attribute for each alternative so as
     * to allow to prune or skip it when the parsing tables are generated
     * (or to make some other algorithm work: there are some in the literature
     * that work only on proper grammars). Moreover, there could be
     * nonterminals which have rules which produce terminal strings, and
     * other rules which do not. No messages would be reported if the
     * attribute were determined for whole nonterminals.
     *
     * The algorithm marks with TR all the alternatives which produce terminals.
     * Note that to know that a nonteminal does not produce terminals there is
     * a need to complete the execution of the algorithm unless the undefined
     * ones are not TR and thus are marked with MRK.
     * 
     * Error reporting has to be done with some care. An error should be
     * reported when there are alternatives (more than one) which are not TR.
     * When all are not TR, better have only one message. A group containing
     * a single alternative is similar to an occurrence of a nonterminal.
     * E.g. ... { a <A>} ... is similar to ... a <A> ...: if <A> is not TR, it
     * is reported where it is defined. If the group contains a sequence of
     * elements and is not TR, the reason is that one of them is not, and
     * thus the message will be reported on it. In order not to have an
     * additional message where the group occurs, G_GRO and G_RE1 groups
     * when containing a single alternative, are not included in the test.
     * When a group is TR, and is a G_OPT or G_RE0, then if it has only
     * one alternative, a message is not reported on it. If it is a G_GRO
     * or G_RE1, then all alternatives are visited, even when there is only
     * one (if there is only one, then it is certainly TR).
     * This is how the nonterminals representing groups are marked:
     *
     * alternatives   gr0   opt    re0       re1
     *                &nt   &nt  &nt &nt1  &nt &nt1
     *
     * -TR            -TR   +TR  +TR  -TR  -TR  -TR
     * +TR -TR        +TR   +TR  +TR  +TR  +TR  +TR
     * -TR -TR        -TR   +TR  +TR  -TR  -TR  -TR
     *
     * If an alternative starts with a group which is -TR as a whole, then
     * two messages appear on it (and in particular when the goup is the
     * only one element in the alternative). This is solved by using two
     * different messages.
     * For optional groups there is a need to detect the ones which have
     * more than one alternatives.
     * For re0 and re1 groups there is a need to inspect the nonterminal in
     * them which represents the alternatives.
     * Note that with groups we are not interested in the attributes of
     * the inner nonterminals (&nt1) as a whole, but in the alternatives
     * they contain. E.g. {<A>}* (with <A> not TR) produces terminals,
     * and thus no message should be reported on it. To cater for this,
     * the nonterminals which are internal, but do not have a group status
     * are not visited to detect errors.
     * On the other hand, in a group with several alternatives, like e.g.:
     * {<A>|<B>}* it is important to report an error message on the ones
     * which do not produce strings. This is useless when there is only
     * one because that could only be due to a nonterminal, and an error
     * message is already reported on it.
     */

    void find_irr(){
        if ((FL_T & this.trc) != 0){
            Trc.out.println("find_irr");
        }
        boolean change = false;
        do {
            change = false;                      // no changes yet
            if ((FL_T & this.trc) != 0){
                Trc.out.println("------ new cycle");
            }
            for (ParserDic h = this.ntDic.head;  // scan all nonterminals
                h != null; h = h.suc){
                if ((ParserNode.MRK & h.status) == 0){  // not yet visited
                    if (vi_nt_tr(h)){            // something new marked
                        change = true;           // one more element marked
                    }
                }
            }
            if ((FL_T & this.trc) != 0){
                Trc.out.println("end cycle " + change);
            }
        } while (change);
        if ((FL_T & this.trc) != 0){
            for (ParserDic h = this.ntDic.head; h != null;
                h = h.suc){
                if ((ParserNode.TR & h.status) != 0){
                    Trc.out.println(h.toString(ParserNode.TR,
                        ParserNode.TR));
                }
            }
        }
        this.ntDic.unmark(true);                 // unmark dic and rules
        if ((FL_T & this.trc) != 0){
            Trc.out.println("find_irr - unreacheable nts");
        }
        vi_nt_st(this.start_sy);
        if (this.alphaRule != null){             // mark the alphabet rule
            vi_st(this.alphaRule);
        }
        if (this.ignore != null){                // mark the ignore token
            vi_nt_st(this.ignore);
        }
        if ((FL_T & this.trc) != 0){
            Trc.out.println("find_irr - end");
        }
    }

    /** 
     * Visit an element and determine whether it produces a terminal string.
     *
     * @param      h reference to the element in whose definition
     *             the node lies
     * @return     <code>true</code> if a change occurred
     */

    /* Note that when an element in the sequence of successors of an
     * alternative is known to produce (or not) terminals, the visit
     * of the successors proceed to detect what they do so as to report
     * errors.
     */

    private boolean vi_nt_tr(ParserDic h){
        boolean change = false;
        if ((FL_T & this.trc) != 0){
            long att = ParserNode.TR | ParserNode.REP | ParserNode.SHO;
            Trc.out.println("vi_nt_tr: " +
                h.toString(att,att));
        }
        boolean alltr = false;
        boolean mrk = true;
        for (ParserNode a = h.def; a != null;      // scan all alternatives
            a = a.alt){
            if ((ParserNode.MRK & a.status) != 0){
                continue;                          // done
            }
            boolean mrka = true;
            boolean al = true;
            boolean op = false;
            l: for (ParserNode s = a;
                s != null; s = s.suc){             // detect operator: in
                if (((ParserNode.S_DIFF |          // .. alpha beta - gamma
                    ParserNode.S_AND) &            // .. all elements are
                    s.oper) != 0){                 // .. inside an operand
                    op = true;
                    break l;
                }
            }
            if (op){
                if ((ParserNode.GRAM & h.status) == 0){    // skip in grammar
                    al &= (ParserNode.TR & a.status) != 0;
                }
            } else if ((ParserNode.S_RNG & a.oper) == 0){
                for (ParserNode s = a; s != null;          // scan all successors
                    s = s.suc){
                    if (s.oper != 0){
                        if ((ParserNode.GRAM & h.status) == 0){  // skip in grammar
                            al &= (ParserNode.TR & s.status) != 0;
                        }
                    } else {
                        switch (s.kind){
                        case ParserNode.S_NT:
                            ParserDic d = s.def;
                            if (d == null) break;
                            if (((ParserNode.GRAM & h.status) != 0) &&
                                ((ParserNode.LEXEME & d.status) != 0)){
                                break;
                            }
                            al &= (ParserNode.TR & d.status) != 0;
                            mrka &= (ParserNode.MRK & d.status) != 0;
                            break;
                        }
                    }
                }
            } else {                         // ranges always TR or error
                a.status |= ParserNode.TR;
                a = a.alt;
            }
            if (al) a.status |= ParserNode.TR;
            if (mrka) a.status |= ParserNode.MRK;
            alltr |= al;
            mrk &= mrka;
        }
        if (alltr){
            if ((ParserNode.TR & h.status) == 0){
                h.status |= ParserNode.TR;
                change = true;
                if ((FL_T & this.trc) != 0){
                    Trc.out.println("produces terminals: " + h);
                }
            }
        }
        if (mrk){
            // then for sure the attribute is final. No changes to be
            // reported since MRK allows only to skip visits, which does
            // not add any changes
            h.status |= ParserNode.MRK;
            if ((FL_T & this.trc) != 0){
                Trc.out.println("marked");
            }
        }
        return change;
    }

    /** 
     * Visit a nonterminal and mark its referenced nonterminals (if any).
     *
     * @param      h reference to the nonterminal
     */

    /* It is not possible to set ST when a nonterminal occurrence is
     * encountered during parsing. If it were, it would block the epidemic.
     * As is done now, there is contagion. E.g. in:
     *
     *    <S> ::= d
     *    <A> ::= <B>
     *    <B> ::= b
     *
     * both <A> and <B> are flagged in error. It is the appropriate thing
     * to do to clean the grammar. If in the previous example <B> referred
     * <A>, both would be used somewhere, and nevertheless be unreacheable.
     */

    private void vi_nt_st(ParserDic h){
        if ((ParserNode.ST & h.status) == 0){             // not yet visited
            h.status |= ParserNode.ST;
            if ((FL_T & this.trc) != 0){
                Trc.out.println("vi_nt_st: " + h);
            }
            vi_st(h.def);                                 // scan its definition
            re: if ((ParserNode.INTER & h.status) == 0){  // do not check groups
                if ((ParserNode.SAME & h.status) != 0){   // it contains <>
                    break re;                             // .. already reached
                }
                ParserDic hh = h.org;                     // replacement: mark the
                if (hh == null) break re;                 // ..  origin one, which is
                if (hh.org != null) hh = hh.org;          // .. "lost"
                hh.status |= ParserNode.ST;
                vi_st(hh.def);
            }
        }
    }

    /** 
     * Visit a node and mark its referenced nonterminals.
     *
     * @param      a reference to the node
     */

    private void vi_st(ParserNode a){
        if ((FL_T & this.trc) != 0){
            Trc.out.println("vi_st: " + a);
        }
        for (;a != null; a = a.alt){                 // scan all alternatives
            for (ParserNode s = a; s != null;        // scan all successors
                s = s.suc){
                ex: switch (s.kind){
                case ParserNode.S_TER: 
                    break;
                case ParserNode.S_NT:
                    if (s.def == null) break;
                    vi_nt_st(s.def);
                    break;
                }
                for (ParserNode csp = s.constr;
                    csp != null; csp = csp.suc){
                    vi_st(csp.gnode);
                }
            }
        }
    }

    /** 
     * Mark the non-terminals which generate the empty string.
     */

    /* Algorithm:
     *
     *  1. all nonterminals are repeatedly visited until no more are marked EM
     *  2. when at least one alternative produces empty, the nonterminal
     *     is marked EM and no longer visited
     *  3. when all the alternatives produce a terminal, the nonterminal
     *     is marked MRK and no longer visited
     */

    void find_empty(){
        if ((FL_T & this.trc) != 0){
            Trc.out.println("find_empty");
        }
        boolean change;
        do {
            change = false;                      // no changes yet
            if ((FL_T & this.trc) != 0){
                Trc.out.println("new cycle");
            }
            for (ParserDic h = this.ntDic.head;  // scan all nonterminals
                h != null; h = h.suc){
                if ((ParserNode.MRK & h.status) == 0){ // not yet visited
                    if (vi_nt_em(h)){            // something new marked
                        change = true;           // one more element marked
                    }
                }
            }
            if ((FL_T & this.trc) != 0){
                Trc.out.println("end cycle " + change);
            }
        } while (change);
        this.ntDic.unmark(true);
        if ((FL_T & this.trc) != 0){
            Trc.out.println("find_empty - end");
        }
    }

    /** 
     * Visit a node and determine whether it produces the empty string.
     *
     * @param      h reference to the element in whose definition
     *             the node lies
     * @return     <code>true</code> if a change occurred
     */

    private boolean vi_nt_em(ParserDic h){
        boolean change = false;
        if ((FL_T & this.trc) != 0){
            Trc.out.println("vi_nt_em: " +
                h.toString(ParserNode.EM,ParserNode.EM));
        }
        boolean allem = false;
        boolean mrk = true;
        for (ParserNode a = h.def; a != null;      // scan all alternatives
            a = a.alt){
            if ((ParserNode.MRK & a.status) != 0){
                continue;                          // does not produces empty
            }
            boolean mrka = true;
            boolean al = true;
            boolean op = false;
            l: for (ParserNode s = a;
                s != null; s = s.suc){             // detect operator: in
                if (((ParserNode.S_DIFF |          // .. alpha beta - gamma
                    ParserNode.S_AND) &            // .. all elements are
                    s.oper) != 0){                 // .. inside an operand
                    op = true;
                    break l;
                }
            }
            if (op){
                al &= (ParserNode.EM & a.status) != 0;
            } else if ((ParserNode.S_RNG & a.oper) == 0){
                seq: for (ParserNode s = a; s != null; // scan all successors
                    s = s.suc){
                    if (s.oper != 0){
                        al &= (ParserNode.EM & s.status) != 0;
                    } else {
                        switch (s.kind){
                        case ParserNode.S_TER:
                            if (s.def == this.dic_emp) break;
                            // no need to test for lexemes because terminals
                            // are never the empty string be them lexemes or not
                            al = false;
                            break seq;                 // no empty produced
                        case ParserNode.S_NT:
                            ParserDic d = s.def;
                            if (d == null) break;
                            if (((ParserNode.GRAM & h.status) != 0) &&
                                ((ParserNode.LEXEME & d.status) != 0)){
                                al = false;
                                break seq;
                            }
                            al &= (ParserNode.EM & d.status) != 0;
                            mrka &= (ParserNode.MRK & d.status) != 0;
                            break;
                        }
                    }
                }
            } else {                         // ranges never EM
                al = false;
                a = a.alt;
            }
            if (mrka) a.status |= ParserNode.MRK;
            allem |= al;
            mrk &= mrka;
            if (al) break;         // do not proceed with the other alt's
        }
        if (allem){
            if ((ParserNode.EM & h.status) == 0){
                h.status |= ParserNode.EM;
                change = true;
                if ((FL_T & this.trc) != 0){
                    Trc.out.println("produces empty: " + h);
                }
            }
        }
        if (mrk){
            // then for sure the attribute is final. No changes to be
            // reported since MRK allows only to skip visits, which does
            // not add any changes
            h.status |= ParserNode.MRK;
            if ((FL_T & this.trc) != 0){
                Trc.out.println("marked");
            }
        }
        return change;
    }

    /** 
     * Find the nonterminals that produce only the empty string.
     */

    void find_eonly(){
        if ((FL_T & this.trc) != 0){
            Trc.out.println("find_eonly");
        }
        for (ParserDic d = this.ntDic.head;      // set it on all nonterminals
            d != null; d = d.suc){
            d.status |= ParserNode.EO;
        }
        boolean change = true;
        do {
            change = false;                      // no changes yet
            if ((FL_T & this.trc) != 0){
                Trc.out.println("------ new cycle");
            }
            for (ParserDic h = this.ntDic.head;  // scan all nonterminals
                h != null; h = h.suc){
                if ((ParserNode.MRK & h.status) == 0){  // not yet visited
                    if (vi_nt_eo(h)){            // something new marked
                        change = true;           // one more element marked
                    }
                }
            }
            if ((FL_T & this.trc) != 0){
                Trc.out.println("end cycle " + change);
            }
        } while (change);
        this.ntDic.unmark(true);                 // remove marks
        if ((FL_T & this.trc) != 0){
            Trc.out.println("find_eonly - end");
        }
    }

    /** 
     * Visit a node and determine whether it produces the empty string only.
     *
     * @param      h reference to the element in whose definition
     *             the node lies
     * @return     <code>true</code> if a change occurred
     */

    private boolean vi_nt_eo(ParserDic h){
        boolean change = false;
        if ((FL_T & this.trc) != 0){
            Trc.out.println("vi_nt_eo: " +
                h.toString(ParserNode.EM,ParserNode.EO));
        }
        boolean alleo = true;
        boolean mrk = true;
        for (ParserNode a = h.def; a != null;      // scan all alternatives
            a = a.alt){
            if ((ParserNode.MRK & a.status) != 0){
                continue;                          // done
            }
            boolean mrka = true;
            boolean al = true;
            boolean op = false;
            l: for (ParserNode s = a;
                s != null; s = s.suc){             // detect operator: in
                if (((ParserNode.S_DIFF |          // .. alpha beta - gamma
                    ParserNode.S_AND) &            // .. all elements are
                    s.oper) != 0){                 // .. inside an operand
                    op = true;
                    break l;
                }
            }
            if (op){
                al &= (ParserNode.EO & a.status) != 0;
            } else if ((ParserNode.S_RNG & a.oper) == 0){
                for (ParserNode s = a; s != null;      // scan all successors
                    s = s.suc){
                    if (s.oper != 0){
                        al &= (ParserNode.EO & s.status) != 0;
                    } else {
                        switch (s.kind){
                        case ParserNode.S_TER:
                            if (s.def == this.dic_emp) break;
                            al = false;
                            break;
                        case ParserNode.S_NT:
                            ParserDic d = s.def;
                            if (d == null) break;
                            if (((ParserNode.GRAM & h.status) != 0) &&
                                ((ParserNode.LEXEME & d.status) != 0)){
                                al = false;
                                break;
                            }
                            al &= (ParserNode.EO & d.status) != 0;
                            mrka &= (ParserNode.MRK & d.status) != 0;
                            break;
                        }
                    }
                }
            } else {                        // ranges never EO
                a = a.alt;
                al = false;
            }
            if (mrka) a.status |= ParserNode.MRK;
            alleo &= al;
            mrk &= mrka;
            if (!alleo) break;
        }
        if (!alleo){
            if ((ParserNode.EO & h.status) != 0){
                h.status &= ~ParserNode.EO;
                change = true;
                if ((FL_T & this.trc) != 0){
                    Trc.out.println("does not produce empty only: " + h);
                }
            }
        }
        if (mrk){
            // then for sure the attribute is final. No changes to be
            // reported since MRK allows only to skip visits, which does
            // not add any changes
            h.status |= ParserNode.MRK;
            if ((FL_T & this.trc) != 0){
                Trc.out.println("marked");
            }
        }
        return change;
    }


    /* Analysis of the Chomsky types of non-terminals. */

    /* A nonterminal <A> is autoiclusive if a derivation <A> => alpha <A> beta
     * exists in which alpha and beta are both not empty.
     * A nonterminal <A> is cyclic if a nontrivial derivation <A> => alpha
     * <A> beta exists in which alpha beta is empty (i.e. are both empty).
     * It is undecidable if a CFG produces a regular language. However, if
     * it has no autoinclusions, the language is regular.
     * There are also CFGs with autoinclusions that produce regular languages.
     * E.g.: <a> ::= <a> <a> | a . They are treated as CFG grammars because it
     * is not clear how to detect them.
     * E.g. <a> => <a> <a> => <a> <a> <a> => a <a> a, which means that it is
     * autoinclusive.
     * The idea behind is to try to replace the occurrences of nonterminals
     * by their definitions. If a nonterminal is not autoinclusive it is
     * possible to carry out the replacement until no nonterminals remain.
     * In some cases it is possible also when a nonterminal is autoinclusive,
     * but in such a way as to denote a repetition.
     *
     * Evaluation of autoinclusion.
     *
     * A nonterminal that generates only the empty string does not have any
     * autoinclusion. Otherwise:
     * For any rule:
     *
     *       <a> ::= <n1> <n2> ... <nn> .
     *
     * all nonterminals are examined to determine if they refer to <a> and if
     * they generate terminals before and/or after it. There is no
     * autoinclusion if there is no derivation:
     *
     *       <a> => x <a> y    with x and y non empty terminal strings
     *
     * If <a> occurs more than once in a rule, there is autoinclusion. Proof:
     * consider a rule <k> ::= <a> <a> . and the derivation:
     *        
     *       <a> => <k> => <a> <a> => <a> <a> <a> => x <a> y.
     *
     * Since <a> can produce nonempty terminal strings, there is autoinclusion
     * (if <a> can produce the empty string only, then it may not produce <k>).
     * If the rule for <k> contains other terminals or nonterminals, the
     * autoinclusion remains. If a nonterminal has several rules, the worst
     * case must be taken.
     * E.g. with <k> ::= A <a> | <a> A .
     *
     *       <a> => <k> => A <a> => A <k> => A <a> A
     *
     * If a rule is autoinclusive, then all nonterminals in it that produce
     * the nonterminal defined by that rule are autoinclusive:
     *
     *       if   <a> => <k> =*> A <a> A      <k> produces <a>
     *       then <a> => <k> =*> A <k> A.
     *
     * Note that the reverse is not true: if a rule refers to autoinclusive
     * nonterminals, it is not necessarily autoinclusive itself.
     *
     * Let's <S> be autoinclusive. Then all the nonterminals <A> which are
     * both derived from <S> and which derive <S> are autoinclusive.
     * I.e. <S> => ... <A> ... => a <S> a => a ... <A> ... a.
     * But then also <A> is autoinclusive because <A> => ... <S> ....
     * Moreover, if <S> => ... <B> ..., and <B> => ... <S> ...,
     * then <B> => a <S> a because <S> is autoinclusive, but then also
     * <B> => a ... <B> ... a.
     * Note that a nonterminal which produces an autoinclusive one is not
     * necessarily autoinclusive. E.g:
     *
     *       <A> ::= <B> .
     *       <B> ::= b <A> b .
     *       <C> ::= <B> .
     *
     * <C> is not autoinclusive though <B> is.
     *
     * Note that the worst case between all alternatives is taken because
     * in a rule <b> ::= b <b> | <a> b. the two alternatives taken together
     * make the rule autoinclusive.
     *
     * The following algorithm to determine autoinclusions is used:
     *
     *   1.  L(A) = 0, R(A) = 0, C(A) = 0
     *   2.  for all rules <A> ::= alpha <B> beta with alpha that generates a
     *       nonempty string, include <B> in L(A). Likewise for beta, include
     *       <B> in R(B), and for all the ones for which alpha beta generates
     *       the empty string include <B> in C(A)
     *   3.  if L(A) has changed, apply step 2 to all the new elements in it,
     *       but when inserting an element (possibly already present) in a set,
     *       insert it also in L(A). Do the same for the other sets.
     *   4.  if <A> belongs to both L(A) and R(A), then it is autoinclusive
     *
     * A nonterminal is put in L(A) or in R(A) if there is at least a rule
     * in which it appears with a nonempty left or right context sooner or
     * later in the derivations. Once a nonterminal is in a set, the
     * nonterminals derived from it are put in that set as well to remember
     * that the nonterminal came from others with a left (or right) context.
     *
     * The algorithm actually stops when <A> is found to belong to both
     * L(A) and R(A): there is no need to continue in that case.
     * To make the algorithm more efficient, only one set is kept, and the
     * elements in it are attributed with:
     *
     *     LEF:  when it has a nonempty left context
     *     RIG:  when it has a nonempty right context
     *
     * when inserting a nonterminal, the LEF and RIG attributes of the rule
     * (i.e. the nonterminal at the LHS of the rule) are inherited and
     * added to the current ones.
     *
     * The usual algorithm to determine the cyclic nonterminals is used:
     * it adds to the set all the ones which have left and right empty
     * contexts and loops until a cycle is found or no more changes occur.
     * It is possible to combine the two algorithms into a single one,
     * but the code becomes complex since there is a need to flag the
     * elements so as to remember whether they were inserted because of
     * autoinclusions or cyclicity. This is the case of elements with
     * empty contexts, which are inserted for both reasons, but which must
     * follow a different path.  An attribute MRK need be kept which tells
     * that no cycles are generated from that path.  Consider this example:
     *
     *        <S> ::= <A>
     *        <A> ::= a <S> a | a | <S>
     *
     * When visiting <A>, and the first <S> in it, MRK is set on it. Then,
     * the second <S> does not lead to a cycle, which is wrong. Inserting an
     * <S> in the set at the very beginning does not solve the problem because
     * it leads to consider this case as a cycle, which is not true:
     * <S> ::= a <S> a | b.
     * The solution is not to insert <S> in the set, and to inherit MRK:
     * a nonterminal which is MRK may only insert MRK nonterminals, provided
     * they are not already there as -MRK. A nonterminal which is -MRK can
     * insert -MRK nonterminals (if their contexts are empty) clearing MRK
     * when present.
     * On the whole, although a single visit of the grammar would be done,
     * it would be more complex and the operations done on each node longer,
     * and in addition, it would stop only when the nonterminal becomes
     * both autoinclusive and cyclic. Separate algorithms stop before.
     *
     * Undefined nonterminals do not generate terminal strings, and therefore
     * it is difficult to tell if they geneate the empty string or not.
     * This means that they spoil the evaluation of autoinclusion.
     * To proceed with it, either choice is good. Currently, an undefined
     * nonterminal is hold to generate the empty string.
     *
     * There is no need to stop at lexemes, but it improves performance
     *
     * Note that the determination of the type of nonterminals serves mainly
     * to the user, and secondly to the generation of the parser and lexer
     * (e.g. token rules which are formally type 2, but generate a regular
     * language can be processed by a DFA).
     *
     * Moreover, there is no need to find the cyclic alternatives since they
     * help little in the removal of cycles, which can be done also by knowing
     * only the cyclic nonterminals, and it leads anyway to a change in the
     * grammar.  E.g.
     *
     *       <A> ::= <B> | a
     *       <B> ::= <A> | b
     *
     * would be changed into:
     *
     *       <A> ::= b | a
     *       <B> ::= a | b
     *
     * The detection of cyclic rules is not really useful also in the reduction
     * of singletons in the generation of the encoded grammar.
     * Moreover, it is not even needed in the parsing algorithm, and not even
     * in the lexing one.
     *
     * Note that TY2 is not the same as AIN: there are TY2 nonterminals which
     * are not AIN: they refer directly or indirectly to nonterminals which
     * are AIN.
     * Note also that LEF and RIG (and AIN) do not allow to determine CYC:
     * e.g., when LEF is set the left context produces at least a nonempty
     * terminal string, but it can also produce an empty one. This means
     * that it is of no use for CYC.
     *
     * For the determination of the types of lexis nonterminals, see the
     * general descriptions of the analysis algorithms above.
     */

    /** 
     * Determine whether the nonterminals are autoinclusive and cyclic.
     */

    void eval_ctype(){
        if ((FL_K & this.trc) != 0){
            Trc.out.println("eval_ctype nt's");
        }
        for (ParserDic h = this.ntDic.head;    // temporarily use ntNum to
            h != null; h = h.suc){             // .. hold final LEF and RIG
            h.ntNum = 0;
        }
        this.set = new ParserDic[20];
        for (ParserDic h = this.ntDic.head;
            h != null; h = h.suc){
            if (h.def == null) continue;       // no definition
            eval_auto(h);                      // determine if autoinclusive
        }
        for (ParserDic h = this.ntDic.head;    // clear ntNum
            h != null; h = h.suc){
            h.status |= h.ntNum &              // restore LEF, RIG
                (ParserNode.LEF | ParserNode.RIG);
            h.ntNum = 0;
        }
        eval_type();                           // determine type

        if ((FL_K & this.trc) != 0){
            for (ParserDic h = this.ntDic.head;    // clear ntNum
                h != null; h = h.suc){
                Trc.out.printf("eval_ctype %s lef %s rig %s\n",
                    h,(ParserNode.LEF & h.status) != 0,
                    (ParserNode.RIG & h.status) != 0);
            }
        }
    }

    /** The set of nonterminals which are derived from a given one. */
    private ParserDic[] set;

    /** The number of elements in the set. */
    private int setNum;

    /** 
     * Determine whether a nonterminal is autoinclusive and cyclic.
     *
     * @param      hd reference to the nonterminal
     */

    private void eval_auto(ParserDic hd){
        if ((FL_U & this.trc) != 0){
            Trc.out.println("eval_auto ain: " + hd);
        }
        this.setNum = 0;
        int cur = vi_nt_ain(hd,hd);
        while (cur < this.setNum){
            if ((ParserNode.AIN & hd.status) != 0) break;
            if ((FL_K & this.trc) != 0){
                Trc.out.println("visiting: " + cur + " " +
                    this.setNum + " " + this.set[cur]);
            }
            int changed = vi_nt_ain(this.set[cur++],hd);    // lowest changed
            if (changed < cur) cur = changed;
        }
        hd.ntNum = hd.status;                               // remember LEF, RIG
        for (int i = 0; i < this.setNum; i++){              // remove marks
            ParserDic h = this.set[i];                      // .. vi_nt_ain changes
            h.status &= ~(ParserNode.LEF | ParserNode.RIG); // .. all of them
        }
        if ((ParserNode.EO & hd.status) != 0){              // generates only the empty string
            hd.status &= ~ParserNode.AIN;
        }

        if ((FL_U & this.trc) != 0){
            Trc.out.println("eval_auto cyc: " + hd);
        }
        this.setNum = 0;
        cur = vi_nt_cyc(hd,hd);
        while (cur < this.setNum){
            if ((ParserNode.CYC & hd.status) != 0) break;
            if ((FL_K & this.trc) != 0){
                Trc.out.println("visiting: cur " + cur + " setnum " +
                    this.setNum + " set " + this.set[cur]);
            }
            int changed = vi_nt_cyc(this.set[cur++],hd);    // repeat for the ones added to the set
            // this is actually useless: it never occurs
            if (changed < cur) cur = changed;
        }
        if ((FL_U & this.trc) != 0){
            Trc.out.println("eval_auto - end");
        }
    }

    /** 
     * Visit a nonterminal and update the set of derived nonterminals
     * which have nonempty left or right contexts.
     *
     * @param      h reference to the element in whose definition
     *             the node lies
     * @param      hd reference to the element whose autoinclusion
     *             need be determined
     * @return     index of lowest element changed
     */

    /* 
     * Attributes are kept to tell if a nonterminal is preceded or
     * followed by empty or nonempty strings. Note that the production
     * of an empty string and that of a nonempty one are not mutually
     * exclusive. A nonterminal can produce both, and thus a rule
     * alpha <A> beta can lead both to a cycle and an autoinclusion.
     * To determine what precedes a nonterminal, a couple of flags which
     * represent at any given point in the list of successors all the
     * preceding symbols are sufficient. To determine what follows, there
     * is a need to scan ahead the successors which are after a nonteminal.
     * If it were possible to scan them backwards, then a single back scan
     * would suffice.
     */

    private int vi_nt_ain(ParserDic h, ParserDic hd){
        if ((FL_K & this.trc) != 0){
            Trc.out.println("vi_nt_ain: " + h);
        }
        int cur = this.setNum;
        l: for (ParserNode a = h.def;
            a != null; a = a.alt){               // scan all alternatives
            ol: for (ParserNode s = a;
                s != null; s = s.suc){           // detect operator: in
                if (((ParserNode.S_DIFF |        // .. alpha beta - gamma
                    ParserNode.S_AND) &          // .. all elements are
                    s.oper) != 0){               // .. inside an operand
                    continue l;
                }
            }
            boolean lefSome = false;             // if head produces nonempty
            if ((FL_U & this.trc) != 0){
                Trc.out.println(h + " ::= " +
                   a.toString(ParserNode.REP_ALT | ParserNode.EXP_GRO));
            }
            for (ParserNode s = a; s != null;    // scan all successors
                s = s.suc){                      // ranges never have autoinclusions
                if (s.oper != 0){
                    if ((ParserNode.EO & s.status) == 0){
                        lefSome = true;
                    }
                    continue;
                }
                switch (s.kind){
                case ParserNode.S_TER:
                    if (s.def == this.dic_emp) break;
                    lefSome = true;
                    break;
                case ParserNode.S_NT:
                    ParserDic d = s.def;
                    if (d == null) break;
                    if (((ParserNode.GRAM & h.status) != 0) &&
                        ((ParserNode.LEXEME & d.status) != 0)){
                        lefSome = true;
                        break;
                    }
                    if ((FL_K & this.trc) != 0){
                        Trc.out.println("nt: " + d +
                            " eo: " + ((ParserNode.EO & d.status) != 0));
                    }
                    boolean rigSome = false;         // determine what follows
                    for (ParserNode r = s.suc; r != null; r = r.suc){
                        switch (r.kind){
                        case ParserNode.S_TER:
                            if (r.def == this.dic_emp) break;
                            rigSome = true;
                            break;
                        case ParserNode.S_NT:
                            ParserDic dd = r.def;
                            if (dd == null) break;
                            if (((ParserNode.GRAM & h.status) != 0) &&
                                ((ParserNode.LEXEME & dd.status) != 0)){
                                rigSome = true;
                                break;
                            }
                            if ((ParserNode.EO & dd.status) == 0){
                                rigSome = true;
                            }
                            break;
                        }
                    }
                    if ((FL_K & this.trc) != 0){
                        Trc.out.println("flags some: " +
                             lefSome + " " + rigSome);
                    }
                    int i = 0;
                    boolean added = false;
                    for (; i < this.setNum; i++){
                        if (this.set[i] == d) break;
                    }
                    if (i == this.setNum){                    // not found
                        if (this.setNum == this.set.length){
                            extend();
                        }
                        this.set[this.setNum++] = d;          // add it
                        if ((FL_K & this.trc) != 0){
                            Trc.out.println("added: " + d);
                        }
                        added = true;
                    }
                    int rig_lef = ParserNode.LEF | ParserNode.RIG;
                    int newstatus = h.status & rig_lef;
                    if (lefSome){
                        newstatus |= ParserNode.LEF;
                    }
                    if (rigSome){
                        newstatus |= ParserNode.RIG;
                    }
                    int oldstatus = d.status;
                    if ((((ParserNode.LEF & d.status) == 0) &&
                        ((ParserNode.LEF & newstatus) != 0)) ||
                        (((ParserNode.RIG & d.status) == 0) &&
                        ((ParserNode.RIG & newstatus) != 0))){
                        // nt d appears in some rule with nonempty left/right contexts
                        d.status |= newstatus;
                        if (i < cur) cur = i;
                    }
                    if ((FL_U & this.trc) != 0){
                        if (added || (oldstatus != d.status)){
                            Trc.out.println("changed: " + d +
                                " lef: " + ((ParserNode.LEF & d.status) != 0) +
                                " rig: " + ((ParserNode.RIG & d.status) != 0));
                        }
                    }
                    if (d == hd){                  // the starting one
                        if ((rig_lef & hd.status) == rig_lef){
                            hd.status |= ParserNode.AIN;
                            if ((FL_U & this.trc) != 0){
                                Trc.out.println("autoinclusive: " + hd);
                            }
                            break l;
                        }
                    }
                    if ((ParserNode.EO & d.status) == 0){
                        lefSome = true;
                    }
                    break;
                }
            }
        } // l;
        if ((FL_K & this.trc) != 0){
            Trc.out.println("vi_nt_ain return " + h + " " +
                cur + " " + this.setNum);
        }
        return cur;
    }

    /** 
     * Visit a nonterminal and update the set of derived nonterminals
     * which have empty left or right contexts.
     *
     * @param      h reference to the element in whose definition
     *             the node lies
     * @param      hd reference to the element whose cyclicity
     *             need be determined
     * @return     index of lowest element changed
     */

    private int vi_nt_cyc(ParserDic h, ParserDic hd){
        if ((FL_K & this.trc) != 0){
            Trc.out.printf("vi_nt_cyc: %s orig %s\n",h,hd);
        }
        int cur = this.setNum;
        l: for (ParserNode a = h.def;
            a != null; a = a.alt){               // scan all alternatives
            ol: for (ParserNode s = a;
                s != null; s = s.suc){           // detect operator: in
                if (((ParserNode.S_DIFF |        // .. alpha beta - gamma
                    ParserNode.S_AND) &          // .. all elements are
                    s.oper) != 0){               // .. inside an operand
                    continue l;
                }
            }
            boolean lefEmpty = true;             // if head produces empty
            if ((FL_U & this.trc) != 0){
                Trc.out.println(h + " ::= " +
                   a.toString(ParserNode.REP_ALT | ParserNode.EXP_GRO));
            }
            for (ParserNode s = a; s != null;    // scan all successors
                s = s.suc){
                if (s.oper != 0){
                    if ((ParserNode.EM & s.status) == 0){
                        lefEmpty = false;
                    }
                    continue;
                }
                switch (s.kind){
                case ParserNode.S_TER:
                    if (s.def == this.dic_emp) break;
                    lefEmpty = false;
                    continue l;
                case ParserNode.S_NT:
                    ParserDic d = s.def;
                    if (d == null) break;
                    if (((ParserNode.GRAM & h.status) != 0) &&
                        ((ParserNode.LEXEME & d.status) != 0)){
                        lefEmpty = false;
                        continue l;
                    }
                    if ((FL_K & this.trc) != 0){
                        Trc.out.println("nt: " + d +
                            " em: " + ((ParserNode.EM & d.status) != 0));
                    }
                    if (lefEmpty){
                        boolean rigEmpty = true;         // determine what follows
                        ri: for (ParserNode r = s.suc; r != null; r = r.suc){
                            switch (r.kind){
                            case ParserNode.S_TER:
                                if (r.def == this.dic_emp) break;
                                rigEmpty = false;
                                continue l;
                            case ParserNode.S_NT:
                                ParserDic dd = r.def;
                                if (dd == null) break;
                                if (((ParserNode.GRAM & h.status) != 0) &&
                                    ((ParserNode.LEXEME & dd.status) != 0)){
                                    rigEmpty = false;
                                    continue l;
                                }
                                if ((ParserNode.EM & dd.status) == 0){
                                    rigEmpty = false;
                                    break ri;
                                }
                                break;
                            }
                        }
                        if ((FL_K & this.trc) != 0){
                            Trc.out.println("flags: empty " + lefEmpty +
                                 " " + rigEmpty);
                        }
                        add: if (rigEmpty){
                            int i = 0;
                            for (; i < this.setNum; i++){
                                if (this.set[i] == d) break add;
                            }
                            if (this.setNum == this.set.length){
                                extend();
                            }
                            this.set[this.setNum++] = d;          // add it
                            if ((FL_K & this.trc) != 0){
                                Trc.out.println("added: " + d);
                            }
                            if (d == hd){                         // the starting one
                                hd.status |= ParserNode.CYC;
                                if ((FL_U & this.trc) != 0){
                                    Trc.out.println("cyclic: " + hd);
                                }
                                break l;
                            }
                        }
                    }
                    // this must be done here because otherwise when we encounter
                    // the nt that we are testing for cyclicity, we would not execute the
                    // code above, which is the one that tests the cyclicity
                    if ((ParserNode.EM & d.status) == 0){
                        lefEmpty = false;
                    }
                    break;
                }
            }
        } // l;
        if ((FL_K & this.trc) != 0){
            Trc.out.println("vi_nt_cyc return " + h + " " +
                cur + " " + this.setNum);
        }
        return cur;
    }

    /**
     * Extend the set by 20 elements.
     */

    public void extend(){
        int curLen = this.set.length;
        int newlen = curLen + 20;
        if (newlen < 0){
            this.lex.message(ParserLexer.ERR_NOCORE,"",
                ParserLexer.MSG_AT_EOF);
            throw this.lex.excObj;
        }
        ParserDic[] p = new ParserDic[newlen];
        System.arraycopy(this.set,0,p,0,curLen);
        this.set = p;
    }

    /** 
     * Determine the type of each nonterminal and terminal: it
     * is type 3 unless it uses type 2 elements or it is autoinclusive.
     * Determine if it generates a finite language.
     */

    private void eval_type(){
        if ((FL_K & this.trc) != 0){
            Trc.out.println("eval_type");
        }
        boolean change = true;
        do {
            change = false;                        // no changes yet
            if ((FL_K & this.trc) != 0){
                Trc.out.println("------ new cycle");
            }
            for (ParserDic h = this.ntDic.head;    // scan nonterminals
                h != null; h = h.suc){
                if ((ParserNode.MRK & h.status) == 0){  // not yet visited
                    if ((FL_K & this.trc) != 0){
                        Trc.out.println("visiting: " + h);
                    }
                    if (vi_nt_typ(h)){             // scan definition
                        change = true;
                    }
                }
            }
            if ((FL_K & this.trc) != 0){
                Trc.out.println("end cycle " + change);
            }
        } while (change);
        this.ntDic.unmark(true);                   // remove marks
        for (ParserDic h = this.ntDic.head;        // remove marks
            h != null; h = h.suc){
            for (ParserNode a = h.def;
                a != null; a = a.alt){             // unmark all alternatives
                a.status &= ~ParserNode.MRK;
            }
        }

        if ((FL_K & this.trc) != 0){
            Trc.out.println("eval_type - finite type-3");
        }

/*
        change = true;
        do {
            change = false;                        // no changes yet
            if ((FL_K & this.trc) != 0){
                Trc.out.println("------ new cycle");
            }
            for (ParserDic h = this.ntDic.head;    // scan nonterminals
                h != null; h = h.suc){
                // only the grammar ones
                if ((ParserNode.MRK & h.status) == 0){  // not yet visited
                    if ((FL_K & this.trc) != 0){
                        Trc.out.println("visiting: " + h);
                    }
                    if (vi_nt_typ3(h)){            // scan definition
                        change = true;
                    }
                }
            }
            if ((FL_K & this.trc) != 0){
                Trc.out.println("end cycle " + change);
            }
        } while (change);
        this.ntDic.unmark(true);                   // remove marks
        for (ParserDic h = this.ntDic.head;        // remove marks
            h != null; h = h.suc){
            for (ParserNode a = h.def;
                a != null; a = a.alt){             // unmark all alternatives
                a.status &= ~ParserNode.MRK;
            }
        }
*/

        for (ParserDic h = this.ntDic.head;    // temporarily use ntNum to
            h != null; h = h.suc){             // .. hold final LIN and RIM
            h.ntNum = 0;
        }
        for (ParserDic h = this.ntDic.head;
            h != null; h = h.suc){
            if (h.def == null) continue;       // no definition
            if ((ParserNode.GRAM & h.status) == 0){
                if ((ParserNode.TY3F & h.status) == 0){        // lexis, done in ParserFA
                    h.ntNum |= INL;
                }
                continue;
            }
            if ((ParserNode.EO & h.status) != 0) continue;     // generates only the empty string
            this.setNum = 0;
            int cur = vi_nt_incl(h,h);
            while (cur < this.setNum){
                if ((FL_K & this.trc) != 0){
                    Trc.out.println("visiting: " + cur + " " +
                        this.setNum + " " + this.set[cur]);
                }
                int changed = vi_nt_incl(this.set[cur++],h);    // lowest changed
                if (changed < cur) cur = changed;
            }
            if (((LIN | RIN) & h.ntNum) != 0){
                h.ntNum |= INL;
            }
        }
        // propagate the INL attribute

        change = true;
        while (change){
            change = false;
            l: for (ParserDic h = this.ntDic.head;
                h != null; h = h.suc){
                if (h.def == null) continue;           // no definition
                for (ParserNode a = h.def;
                    a != null; a = a.alt){             // scan all alternatives
                    for (ParserNode s = a; s != null;  // scan all successors
                        s = s.suc){                    // ranges never have autoinclusions
                        switch (s.kind){
                        case ParserNode.S_TER:
                            if (s.def == this.dic_emp) break;
                            break;
                        case ParserNode.S_NT:
                            ParserDic d = s.def;
                            if (d == null) break;
                            if (((ParserNode.GRAM & h.status) != 0) &&
                                ((ParserNode.LEXEME & d.status) != 0)){
                                break;
                            }
                            if ((INL & d.ntNum) != 0){
                                if ((INL & h.ntNum) == 0){
                                    h.ntNum |= INL;
                                    change = true;
                                }
                                continue l;
                            }
                            break;
                        }
                    }
                }
            } // l
        }
        // clear ntnum and set TY3F
        for (ParserDic h = this.ntDic.head;
            h != null; h = h.suc){
            if ((INL & h.ntNum) == 0){
                h.status |= ParserNode.TY3F;
            }
            h.ntNum = 0;
        }

        for (ParserDic h = this.terDic.head;       // scan terminals
            h != null; h = h.suc){
            if (h.def == null){                    // not redefined
                h.status |= ParserNode.TY3F;
                if ((FL_K & this.trc) != 0){
                    Trc.out.println("eval_type type-3f: " + h);
                }
            }
        }
        eval_littok();                             // determine literal tokens
        if ((FL_K & this.trc) != 0){
            Trc.out.println("eval_type - end");
        }
    }

    /** 
     * Visit a node and determine its type.
     * With respect to the syntax proper, lexemes are considered as
     * terminals, and thus are type 3 elements; with respect to the lexis,
     * lexemes have their own type.
     *
     * @param      h reference to the element in whose definition
     *             the node lies
     * @return     <code>true</code> if type 2
     */

    private boolean vi_nt_typ(ParserDic h){
        boolean change = false;
        boolean mrk = true;
        boolean ty3 = true;
        for (ParserNode a =  h.def;
            a != null; a = a.alt){              // scan all alternatives
            if ((ParserNode.MRK & a.status) != 0){
                continue;                          // done
            }
            boolean mrka = true;
            boolean al = true;
            for (ParserNode s = a;
                s != null; s = s.suc){          // scan all successors
                switch (s.kind){
                case ParserNode.S_NT:
                    ParserDic d = s.def;
                    if (((ParserNode.GRAM & h.status) != 0) &&
                        ((ParserNode.LEXEME & d.status) != 0)){
                        break;
                    }
                    if (d == null) break;
                    al &= (ParserNode.TY2 & d.status) == 0;
                    al &= (ParserNode.AIN & d.status) == 0;
                    mrka &= (ParserNode.MRK & d.status) != 0;
                }
            }
            if (mrka) a.status |= ParserNode.MRK;
            ty3 &= al;
            mrk &= mrka;
        }
        if (!ty3){
            if ((ParserNode.TY2 & h.status) == 0){
                h.status |= ParserNode.TY2;
                change = true;
                if ((FL_K & this.trc) != 0){
                    Trc.out.println("type-2: " + h);
                }
            }
        }
        if (mrk){
            h.status |= ParserNode.MRK;
            if ((FL_T & this.trc) != 0){
                Trc.out.println("marked");
            }
        }
        return change;
    }

    /** 
     * Finite languages.
     *
     * Finite languages are subsets of regular languages. It is possible
     * to tell rules which generate finite languages by generating DFAs
     * and checking that they do not have loops.
     * This is, e.g. the case of many tokens, including the ones whose
     * rules contain only a terminal strings and that have a replacement
     * that specifies the spelling, e.g. the case-variant forms allowed.
     * Note that {a|..|z}+ - {a|..|f}+ is infinite, {{a|..|f}+ | g} -
     * {a|..|f}+ is not.
     * A means to tell if a rule generates a finite number of lexemes
     * is to check that its NFA does not contain cycles.
     * When finding cycles in NFAs, some attention must be paid to the e-edges:
     * cycles made solely of epsilon edges must not be considered as cycles.
     * Note that a NFA with e-edges can have cycles of e-edges.
     * E.g.: in {[a]}*.
     * This means that a machine which interprets it could enter an infinite
     * loop on some paths. This does not mean that it recognizes a language
     * which is different from that of the corresponding DFA. A string is
     * recognised by a NFA if there is at least one path for it ending in
     * a final state, no matter if the path contains e-edges, and also no
     * matter if there are endless e-edges paths. Paths with e-edges do not
     * alter the set of recognised strings. The corresponding DFA removes
     * e-edges. Note that a machine which interprets a NFA must try all
     * possible paths to check if there is one that matches the string, and
     * thus it must not enter an endless loop, but rather detect it and avoid
     * it so as to make sure to try all paths.
     *
     * It is possible to determine if there is at least a path from the start
     * state to the end one which contains a nonempty loop.
     *
     * There is also a way to determine if there are cycles by looking at the
     * rules. That can be determined by visiting the rules and checking that
     * they do not refer to themselves, or do not refer to nonterminals which
     * have cycles, or do not contain repetitive groups (which is the same).
     * It is done by using the LEF and RIG attributes which are computed
     * when the types of nonterminals are determined. It discards automatically
     * cyclic alternatives. To determine if a nonterminal generates a finite
     * language, the same algorithm used to determine if it is a type-2 one
     * is used, but referred to left and right autoreferences here.
     * Note that cyclic alternatives do not make a language infinite.
     *
     * This is even better since it spares to build NFAs.
     * Since this algorithm cannot be applied to rules containing operations
     * such as complement, difference, etc., because there is a need to
     * build a NFA to tell what is the resulting language, a mixed approach
     * is used: the previous one is used to mark the elements in such rules
     * which are results of operations (for which a NFA is built anyway),
     * and this algorithm used for the overall computation, which does not
     * enter operations and takes instead the results of the other one.
     * 
     * Note that cyclic rules should not be taken into account. I.e. to
     * generate an infinite string, a nonterminal must have at least a rule
     * in which it refers to itself with a non-empty terminal at the right or
     * at the left. I.e. there must exist a derivation <A> => alpha <A> or
     * <A> alpha with a non-empty alpha.
     * It is also possible to detect cycles when building a NFA since cycles
     * can occur only when a nonterminal refers to itself, and that is handled
     * in a special way. However, there is a need to detect cyclic alternatives
     * there.
     */

    /** 
     * Visit a node and determine if it generates a finite language.
     * With respect to the syntax proper, lexemes are considered as
     * terminals, and thus are type 3 elements by definition; with respect
     * to the lexis, lexemes have their own type.
     * The finiteness of the rules of lexemes has been computed before, when
     * the FAs were build.
     *
     * @param      h reference to the element in whose definition
     *             the node lies
     * @return     <code>true</code> if it generates a finite language
     */

/*
In ntDic there should be nt with the original rules, and if disentangling, then
the mirror ones are somewhere else. Then, from ntdic, for the non-token rules
we compute the finiteness and otherwise we take the finiteness that has been computed
when building the DFAs (if there is one for each nt, or if there is a good path from its
start state to its end).
... when the rule is a lexer or lxs one, and there are operators (not only diff and and),
    the finiteness should be computed with the dfa also for autoinclusion and cyclicity,
    which is quite cumbersome: I should compute the heads and tails
... n.b. {a|..|z}+ <A> - ^{c}* ^{d}*  allowed!  but also ^{c}* <A>, so ...
*/

/*
    private boolean vi_nt_typ3(ParserDic h){
        boolean change = false;
        if (((ParserNode.LXS | ParserNode.LEXEME) & h.status) != 0){
            return false;
        }
        boolean mrk = true;
        boolean ty3f = true;
        l: for (ParserNode a = h.def;
            a != null; a = a.alt){              // scan all alternatives
            if ((ParserNode.MRK & a.status) != 0){
                continue;                       // done
            }
            boolean mrka = true;
            boolean al = true;
            boolean op = false;
            ol: for (ParserNode s = a;
                s != null; s = s.suc){          // detect operator: in
                if (((ParserNode.S_DIFF |       // .. alpha beta - gamma
                    ParserNode.S_AND) &         // .. all elements are
                    s.oper) != 0){              // .. inside an operand
                    op = true;
                    break;
                }
            }
            if (op){
                al &= (ParserNode.TY3F & a.status) != 0;
            } else if ((ParserNode.S_RNG & a.oper) == 0){
                boolean lefEmpty = true;            // if head produces empty
                for (ParserNode s = a;
                    s != null; s = s.suc){          // scan all successors
                    if (s.oper != 0){
                        al &= (ParserNode.TY3F & s.status) != 0;
                        if ((ParserNode.EM & s.status) == 0){
                            lefEmpty = false;
                        }
                        continue;
                    }
                    switch (s.kind){
                    case ParserNode.S_TER:
                        if (s.def == this.dic_emp) break;
                        lefEmpty = false;
                        break;
                    case ParserNode.S_NT:
                        ParserDic d = s.def;
                        if (d == null) break;
                        if (((ParserNode.GRAM & h.status) != 0) &&
                            ((ParserNode.LEXEME & d.status) != 0)){
                            lefEmpty = false;
                            break;
                        }
                        le: if (lefEmpty){
                            boolean rigEmpty = true;         // determine what follows
                            ri: for (ParserNode r = s.suc; r != null; r = r.suc){
                                switch (r.kind){
                                case ParserNode.S_TER:
                                    if (r.def == this.dic_emp) break;
                                    rigEmpty = false;
                                    break le;
                                case ParserNode.S_NT:
                                    ParserDic dd = r.def;
                                    if (dd == null) break;
                                    if (((ParserNode.GRAM & h.status) != 0) &&
                                        ((ParserNode.LEXEME & dd.status) != 0)){
                                        rigEmpty = false;
                                        break le;
                                    }
                                    if ((ParserNode.EM & dd.status) == 0){
                                        rigEmpty = false;
                                        break le;
                                    }
                                    break;
                                }
                            }
                            if (rigEmpty){
                                // here there is an element that is a nt and that
                                // is preceded and followed by others that all generate
                                // the empty string
                                // if cyclic, it does not contribute to generate strings
                                if ((ParserNode.CYC & d.status) != 0) continue;
                            }
                        }
                        al &= (ParserNode.TY3F & d.status) != 0;
                        mrka &= (ParserNode.MRK & d.status) != 0;
                    }
                }
            } else {                        // ranges always TY3F
                a = a.alt;
            }

            if (mrka) a.status |= ParserNode.MRK;
            ty3f &= al;
            mrk &= mrka;
        }
        if (ty3f){
            if ((ParserNode.TY3F & h.status) == 0){
                h.status |= ParserNode.TY3F;
                change = true;
                if ((FL_K & this.trc) != 0){
                    Trc.out.println("type-3f: " + h);
                }
            }
        }
        if (mrk){
            h.status |= ParserNode.MRK;
            if ((FL_T & this.trc) != 0){
                Trc.out.println("marked");
            }
        }
        return change;
    }
*/

    /** The left-inclusive attribute. */
    private static final int LIN = 1 << 2;

    /** The right-inclusive attribute. */
    private static final int RIN = 1 << 3;

    /** The infinite language attribute. */
    private static final int INL = 1 << 4;

    /**
     * Evaluate the left-inclusive and right-inclusive attributes of the
     * first nonterminal, and the nonempty left and right context attribute of
     * second nonterminal.
     *
     * @param      tab grammar
     * @param      nt first nonterminal
     * @param      orig second nonterminal
     */

    private int vi_nt_incl(ParserDic h, ParserDic hd){
        if ((FL_K & this.trc) != 0){
            Trc.out.println("vi_nt_incl: " + h);
        }
        int cur = this.setNum;
        l: for (ParserNode a = h.def;
            a != null; a = a.alt){               // scan all alternatives
            ol: for (ParserNode s = a;
                s != null; s = s.suc){           // detect operator: in
                if (((ParserNode.S_DIFF |        // .. alpha beta - gamma
                    ParserNode.S_AND) &          // .. all elements are
                    s.oper) != 0){               // .. inside an operand
                    continue l;
                }
            }
            boolean lefEmpty = true;             // if head produces empty
            if ((FL_U & this.trc) != 0){
                Trc.out.println(h + " ::= " +
                   a.toString(ParserNode.REP_ALT | ParserNode.EXP_GRO));
            }
            for (ParserNode s = a; s != null;    // scan all successors
                s = s.suc){                      // ranges never have autoinclusions
                if (s.oper != 0){
                    if ((ParserNode.EM & s.status) == 0){
                        lefEmpty = false;
                    }
                    continue;
                }
                switch (s.kind){
                case ParserNode.S_TER:
                    if (s.def == this.dic_emp) break;
                    lefEmpty = false;
                    break;
                case ParserNode.S_NT:
                    ParserDic d = s.def;
                    if (d == null) break;
                    if (((ParserNode.GRAM & h.status) != 0) &&
                        ((ParserNode.LEXEME & d.status) != 0)){
                        lefEmpty = false;
                        break;
                    }
                    if ((FL_K & this.trc) != 0){
                        Trc.out.println("nt: " + d +
                            " em: " + ((ParserNode.EM & d.status) != 0));
                    }
                    boolean rigEmpty = true;         // determine what follows
                    ri: for (ParserNode r = s.suc; r != null; r = r.suc){
                        switch (r.kind){
                        case ParserNode.S_TER:
                            if (r.def == this.dic_emp) break;
                            rigEmpty = false;
                            break;
                        case ParserNode.S_NT:
                            ParserDic dd = r.def;
                            if (dd == null) break;
                            if (((ParserNode.GRAM & h.status) != 0) &&
                                ((ParserNode.LEXEME & dd.status) != 0)){
                                rigEmpty = false;
                                break;
                            }
                            if ((ParserNode.EM & dd.status) == 0){
                                rigEmpty = false;
                                break;
                            }
                            break;
                        }
                    }
                    if ((FL_K & this.trc) != 0){
                        Trc.out.println("flags: empty " + lefEmpty +
                             " " + rigEmpty);
                    }
                    add: if (lefEmpty || rigEmpty){
                        int i = 0;
                        for (; i < this.setNum; i++){
                            if (this.set[i] == d) break add;
                        }
                        if (this.setNum == this.set.length){
                            extend();
                        }
                        this.set[this.setNum++] = d;          // add it
                        if ((FL_K & this.trc) != 0){
                            Trc.out.println("added: " + d);
                        }
                    }
                    if (d == hd){                         // the starting one
                        if (lefEmpty && !rigEmpty){
                            hd.ntNum |= LIN;
                            if ((FL_K & this.trc) != 0){
                                Trc.out.printf("LIN %s\n",hd);
                            }
                        }
                        if (rigEmpty && !lefEmpty){
                            hd.ntNum |= RIN;
                            if ((FL_K & this.trc) != 0){
                                Trc.out.printf("RIN %s\n",hd);
                            }
                        }
                        break l;
                    }
                    // this must be done here because otherwise when we encounter
                    // the nt that we are testing for inclusiveness, we would not execute the
                    // code above, which is the one that tests the inclusiveness
                    if ((ParserNode.EM & d.status) == 0){
                        lefEmpty = false;
                    }
                    break;
                }
            }
        } // l;
        if ((FL_K & this.trc) != 0){
            Trc.out.println("vi_nt_incl return " + h + " " +
                cur + " " + this.setNum);
        }
        return cur;
    }


    /**
     * Lexical tokens
     *
     * Lexical tokens are the ones whose rule defines one string only (apart
     * for case insensitiveness). Lexical tokens are a subset of the ones
     * defined by rules that generate finite languages.
     * They are defined by rules which contain
     *
     *    - terminals
     *    - nonterminals which generate one string only (possibly the empty)
     *    - simple and fixed repetition groups containing elements like these.
     *
     * It could be possible to include tokens whose rules have operators in
     * them, but that eventually produce one string only. However, this
     * would require to build a DFA without taking into account case folding.
     * Since in practice it is seldom the case that there is a need to define
     * literal tokens in this way, token rules that contain operators are
     * not recognized to generate literal tokens.
     * They are an important subset of tokens (keywords, delimiters, etc.)
     * and have a specific treatment in their representation in parse trees.
     */

    private void eval_littok(){
        if ((FL_K & this.trc) != 0){
            Trc.out.println("eval_littok");
        }
        boolean change = true;
        do {
            change = false;                        // no changes yet
            if ((FL_K & this.trc) != 0){
                Trc.out.println("------ new cycle");
            }
            for (ParserDic h = this.ntDic.head;    // scan nonterminals
                h != null; h = h.suc){
                if ((ParserNode.GRAM & h.status) != 0){
                    continue;
                }
                if ((ParserNode.MRK & h.status) == 0){  // not yet visited
                    if ((FL_K & this.trc) != 0){
                        Trc.out.println("visiting: " + h + " " +
                            h.def.toString(ParserNode.REP_RULE));
                    }
                    if (vi_nt_littok(h)){          // scan definition
                        change = true;
                    }
                }
            }
            if ((FL_K & this.trc) != 0){
                Trc.out.println("end cycle " + change);
            }
        } while (change);
        this.ntDic.unmark(true);                   // remove marks
        for (ParserDic h = this.terDic.head;       // scan terminals
            h != null; h = h.suc){
            if (h.def == null){                    // not redefined
                h.attr |= ParserNode.LIT_TOK;
            }
        }
    }

    /** 
     * Visit a node and determine if it generates a lexical token.
     *
     * @param      h reference to the element in whose definition
     *             the node lies
     * @return     <code>true</code> if it generates a lexical token
     */

    private boolean vi_nt_littok(ParserDic h){
        boolean change = false;
        boolean mrk = true;
        boolean ty3l = true;
        l: for (ParserNode a = h.def;
            a != null; a = a.alt){              // scan all alternatives
            if (a.alt != null){
                ty3l &= false;
                mrk = true;
                break l;
            }
            boolean mrka = true;
            boolean al = true;
            for (ParserNode s = a;
                s != null; s = s.suc){          // scan all successors
                if (s.oper != 0){
                    al = false;
                    break;
                } else {
                    switch (s.kind){
                    case ParserNode.S_NT:
                        ParserDic d = s.def;
                        if (d == null) break;
                        al &= (ParserNode.LIT_TOK & d.attr) != 0;
                        al &= (ParserNode.LEF & d.status) == 0;
                        al &= (ParserNode.RIG & d.status) == 0;
                        mrka &= (ParserNode.MRK & d.status) != 0;
                    }
                }
            }
            ty3l &= al;
            mrk &= mrka;
        }
        if (ty3l){
            if ((ParserNode.LIT_TOK & h.attr) == 0){
                h.attr |= ParserNode.LIT_TOK;
                change = true;
                if ((FL_K & this.trc) != 0){
                    Trc.out.println("literal token: " + h);
                }
            }
        }
        if (mrk){
            h.status |= ParserNode.MRK;
            if ((FL_T & this.trc) != 0){
                Trc.out.println("marked");
            }
        }
        return change;
    }

    /* Processing the lexis. */

    /* The lexis
     *
     * A lexeme is a symbol like a character, and thus it may not be the
     * empty string.
     * Considering lexemes as terminals, i.e. the grammar broken in two,
     * is different from considering it as a whole: not so for ST, but yes
     * for EM, EO, and the type of grammar.
     * On one hand, it is better to consider the grammar and the lexis as
     * a whole, on the other it is not so unnatural to consider them as two
     * different things. For ST there is no difference: all rules must be
     * connected.
     * For TR the difference is that errors in lexemes do not propagate on the
     * grammar (but they do on the nonterminals which are used by both).
     * For the EM (and EO), they are conditioned anyway by the condition that
     * lexemes may not produce the empty string.
     * The classification of rules is also conditioned by that.
     *
     * TERMINALS in effect does not denote all terminals, but only the
     * ones which are lexemes and which are not declared explicitly
     * TERMINALS is not accepted in shorthand RHS.
     * A need is to write dedicated replacement rules for the lexemes which
     * have some peculiarity, such as identifiers and keywords, and one
     * rule only for the remaining ones. TERMINALS does it.
     * Terminals are mentioned in the lexis list (possibly in shorthands)
     * to allow to be referred to from rules as shorthands, like e.g.
     * <id> => <> ~{<keyword>}. When that is done, it is also easy to
     * write replacement rules for them (by mentioning shorthands as their
     * LHS). Thus, in such a case TERMINALS has better to indicate what
     * terminal strings have not been declared explicitly as lexemes.
     * Another name would be more revealing, like e.g.: "OTHERS".
     * It would even be better to let it denote the terminal strings which
     * have also not been declared explicitly in a LHS of a replacement.
     * This is not much useful, though.
     *
     * In lexis, declaring terminal strings which do not belong to the
     * grammar (and thus are not present in the grammar at all or are present
     * in token rules) is an error. The same for terminals in shorthand RHS,
     * except for shorthands which are used in RHSs of rules.
     *
     * At the moment it is very difficult to accept a lexicon in which
     * at a same place in the text two different lexemes with different lengths
     * can occur. Therefore, to obtain this effect there is a need not to use
     * a lexer at all. This is obtained by not using terminal strings, but
     * characters. When terminal strings are used, they are the lexemes,
     * and the lexer in each context will recognize the longest which can
     * occur in that context. This is more or less the maximum which can be
     * done: the terminal vocabulary is made by the lexemes, and the
     * recognizion of which one occurs at any position in the text depends on
     * what lexemes the rule allow in that context.
     */

    /* Processing of shorthands and replacements:
     *
     *   - binding between shoDic and ntDic
     *   - filling .def of ntDic entries which denote shorthands with cloned,
     *     expanded shorthands definitions
     *   - circularity check of shorthands
     *   - mark ntDic entries in lexis as LEXEME, check duplicates in lexis,
     *     mark reacheable shorthands from lexis
     *   - report unreacheable (useless) shorhands
     *   - visit grammar from start, but not ntDic lexemes, mark ntDic
     *     entries as GRAM and mark terminals as LEXEME
     *   - check and plug replacements
     *   - visit ntDic lexemes and mark down reacheable elements as LXS
     *     rules which are used in grammar and lexicon have both GRAM and LXS
     *     marks
     *   - check that terminals in lexis are lexemes
     *   - check that GRAM rules do not use ranges and constraints
     *   - construct the list of lexemes and enumerate them
     *   - disentangle grammar and lexis
     *   - (find_empty mark nonterminals which produce the empty string)
     *   - report LEXEMES which produce the empty string
     */

    /** 
     * Check the conditions on the lexicon and process its contents.
     */

    void process_lexis(){
        bindShort();                       // bind and check shorthands
        if ((FL_X & this.trc) != 0){
            Trc.out.println("marking lexemes in grammar");
        }
        if ((ParserNode.LEXEME &
            start_sy.status) == 0){
            vi_nt_gram(this.start_sy);     // determine GRAM and term. lexemes
        }
        ck_rep();                          // check, plug replacements

        // clear lxs because is was used to mark the elements of lexis
        // to detect multiple definitions, and therefore there can be
        // lexemes which are marked, that now it should not.
        // At this point all lexemes are marked as LEXEME.

        for (ParserDic h = this.ntDic.head;  // clear LXS attribute
            h != null; h = h.suc){           // .. before using it to
            h.status &= ~ParserNode.LXS;     // .. mark lexicon rules
        }
        for (ParserDic h = this.terDic.head;
            h != null; h = h.suc){
            h.status &= ~ParserNode.LXS;
        }

        // N.B. replacements are visited automatically since origin rules
        // are not GRAM

        for (ParserDic h = this.ntDic.head;  // determine lexicon: mark LXS
            h != null; h = h.suc){
            if ((ParserNode.LEXEME & h.status) == 0) continue;
            ParserDic hh = h;
            if (h.repl != null) hh = h.repl;
            vi_nt_lxsmrk(h);
        }
        this.ntDic.unmark(false);

        if ((FL_X & this.trc) != 0){
            Trc.out.println("GRAM/LEXEME/LXS attributes");
            boolean first = true;
            ParserDic h = this.ntDic.head;
            while (h != null){
                String atr = "";
                if ((ParserNode.GRAM & h.status) != 0){
                    atr = " gram";
                }
                if ((ParserNode.LEXEME & h.status) != 0){
                    atr += " lexeme";
                }
                if ((ParserNode.LXS & h.status) != 0){
                    atr += " lexicon";
                }
                Trc.out.println(h + atr);
                h = h.suc;
                if ((h == null) && first){     // scan terminal dict
                    first = false;
                    h = this.terDic.head;
                }
            }
        }
        if (this.lxi_list != null){            // check that terminals
            vi_terck(this.lxi_list);           // .. in LEXIS are lexemes
            this.shoDic.unmark(false);
        }

        // until the grammar is disentangled, there is a need to process
        // replacements explicitly

        ck_special();                 // check use of special notations
        make_lexlist();               // construct the list of lexemes
        disentangle();                // disentangle grammar and lexis
    }


    /* Shorthands.
     *
     * Rationale:
     *
     * Duplicates in shorthands definitions could be errors, but overlaps among
     * shorthands in the definition of lexis could be useful. However, since
     * shorthands serve mainly to define sequences of replacements, overlaps
     * would not be accepted in that context, and therefore they are rejected.
     *
     * Even if the terminals which are lexemes are determined implicitly,
     * it is allowed to declare terminals in LEXIS and in shorthands.
     * One reason it to make explicit what elements are lexemes.
     * Moreover, since nonterminal tokens can be declared in lexis, for
     * uniformity it is allowed to declare terminals as well so as to allow
     * to enlist the whole lexicon.
     * Shorthands serve mainly to avoid to repeat the same replacement rules
     * over and over again for several terminals.
     * To avoid it, shorthands are introduced, which stands for a list of
     * lexemes. But then terminals can be declared in lexis also.
     * Shorthands serve little to declare what elements are lexemes, but serve
     * to group them.
     * It is not allowed to have generic shorthands, which can be used in
     * grammar RHS, and are not declared in LEXIS (but below it). This would be
     * confusing. This is why the usages from the grammar and replacements do
     * not mark .ST.
     *
     * When there are nonterminals which belong to both either the
     * grammar and the lexicon it is impossible to reject some of the usages of
     * shorthands in them, and allow some others. With reference to the
     * example in the section "Shorthand definitions", if <A> occurred in one
     * of such rules, it would be confusing to reject it being the rule a
     * grammar one and not being "c" present in the grammar, and accept it
     * being the rule a token rule.
     * Logically, the occurrence of <A> is first replaced in the grammar, and
     * on the resulting grammar the conditions apply. This means that "c" is
     * accepted as lexeme even if it is not defined in the grammar. If <A>
     * were not used in the grammar, "c" would be rejected.
     *
     * Implementation:
     *
     * In a ntr_list (LEXIS and shorthands definitions), elements may not
     * be repeated: to check that TERMINALS are not duplicated in ntr_list a
     * test is done when inserting elements in it. This allows to detect
     * this duplication and moreover the others earlier.
     * If a shorthand contains duplicated alternatives, and is used in
     * two places, only one error is reported (as well as when it occurs
     * as LHS of replacements, which would generate multiple definitions).
     * This is solved by discarding duplicates when shorthands are parsed.
     *
     * All occurrences of nonterminals in the LEXIS list and in shorthands
     * are stored in shoDic, including the undefined ones.
     * When the list after LEXIS or shorthand definitions are read, it is
     * not yet possible to check them because there could be names in it which
     * are defined afterwards. Thus, the list is stored as it is, names stored
     * in shoDic and the list checked later.
     * Definitions automatically bind occurreces.
     * Shorthands which are not defined by a shorthand definition are actually
     * references to nonterminals.
     * They refer to nonterminal entries with the .org field, not with their
     * .def field, otherwise it would be impossible to distinguish them
     * from the ones which are defined by shorthand definitions.
     * There is a need to distinguish the shorthands which have a definition
     * from the ones which mirror ntDic entries e.g. because when visiting
     * the lxi_list and encountering a nonterminal it is necessary to know
     * if that is a shorthand or not. In the former case there is a need to
     * mark all the nonterminals in its RHS as lexemes, in the latter
     * only that element is marked.
     * Nonterminal ntDic entries which are not defined and are shorthands
     * have .org field refer to the shorthand.
     * A shorthand may not be defined more than once, and if it is defined,
     * it must not be equal to a grammar nonterminal.
     * Shorthands which are defined by a shorthand definition have their
     * .def field refer to it.
     * An alternative implementation is to check that a nonterminal in ntr_list
     * is a nonterminal name: when it is, is it not added to shoDic, and the
     * reference to the element in ntDic is used instead. There would be a
     * need to change some binding and checking algorithms.
     * The technique to keep two distinct dictionaries allows to decouple the
     * processing and the building of the grammar from that of the shorthands.
     * When a nonterminal occurrence is found, it is either a grammar
     * nonterminal or an (already known) shorthand, or none. In all cases it
     * would be possible to perform the final binding immediately. This would
     * spare to bind the entries which have no definition because it is in 
     * the other dictionary.  However, when they are defined both as grammar
     * nonterminals and shorthands, with two dictionaries it is still possible
     * to continue the analysis instead of throwing away duplicated definitions.
     * Duplicated definitions could also be allowed: they could take priority
     * over the ones in ntDic. This can be useful to avoid to invalidate
     * shorthand definitions when the grammar changes.
     * Another reason is that LHSs of replacements must be either lexemes or
     * shorthands, and it is easier to check it if all of them are in only one
     * dictionary. Note that all nonterminals mentioned in lexis go in shoDic.
     * Entries in shoDic are bound with those in ntDic because when expanding
     * shorthand occurrences in RHSs with their rule, the entries which denote
     * grammar nonterminals must point to ntDic entries, and when linking
     * ntDic entries which denote shorthands to their definition there is a
     * need to go from ntDic entries to the corresponding shoDic entries.
     *
     * Shorthand definitions are kept as they are specified in the input.
     * An alternative implementation is to replace recursively shorthand
     * occurrences with their definition in shorthand definitions.
     * The problem with both implementations is that error reporting can
     * look strange. E.g. duplicated definitions are not reported in the
     * same ordering as that of occurrences in the source.
     * This is so because the lexis list is visited recursively, and elements
     * marked along the way. This means that an element which is defined in
     * a shorthand defined below is visited before the elements which are
     * after it in the list, and errors reported in this order.
     *
     * Binding takes into account that shorthands can occur both in grammar
     * and in replacement rules.
     * In the RHS of a replacement rule, the occurrence of a shorthand is always
     * bound to the definition of the shorthand (i.e. not to a replacement
     * definition which has that shorthand name as LHS), no matter if there
     * is a replacement whose LHS is that shorthand.
     * For ntDic, when a rule has in its RHS a shorthand which is not defined
     * in the grammar, that shorthand has an entry in ntDic which is linked
     * to a cloned, expanded copy of the definition of the shorthand.
     * This may not be done with repDic because there the shorthand has an
     * entry in repDic, which is used for other purposes and may not be used
     * for this. Thus, a ntDic entry is created for this. However, this must
     * be done only if the shorthand is used in some RHS of replacements
     * (which is not a <>) and not when it is used in a LHS only. To have
     * this, replacements wihch are also used from RHSs of replacements
     * are marked first.
     *
     * The entries in shoDic which mirror grammar nonterminals are kept
     * there (i.e. not removed) because they are used to bind replacements.
     * The entries in ntDic which mirror shorthands have their .def made to
     * refer to the cloned shorthands.
     *
     * Cloning:
     *
     * Cloning of shorthand RHSs to be referred to from rules may not be avoided
     * since there is a need to expand recursively shorthands.
     * Replacement of shorthands in rules is simple since there is no
     * need to scan the rules. It is sufficient to create rules for shorthands
     * expansions and link them to the ntDic entries which are already there.
     * Moreover, such entries are marked as groups. The point and line in
     * those ntDic entries are set to those of the nonterminals which define
     * the shorthands because if an error is found in the definition, which
     * need be reported on the nonterminal, it should appear in the source where
     * the shorthand is defined.
     *
     * Shorthands are not replaced in replacements before merging replacements
     * into the syntax because they act as groups also in that context.
     * When replacing shorthand occurrences in rules, if shorthands contain
     * grammar nonterminals which have a replacement, those nonterminals are
     * bound to refer to the origin ones because they have anyway a reference
     * to the replacement stored in them. Disentangling the grammar is done
     * afterwards.  If it were done at this stage, it would be done in an
     * incomplete way since in rules which are gram+lxs no decision could be
     * taken at that stage.
     *
     * Shorthands are replaced before running all algorithms, including the
     * ones which determine which terminals are lexemes.
     * Replacement of shorthands is done before find_irr() because otherwise
     * the nonterminals which look as undefined before substitution, but are
     * effectively defined since they are shorthand occurrences, would make
     * find_irr() report wrong results.
     *
     * Starty symbol as lexeme
     *
     * The start symbol can defined as lexeme (and also have a replacement).
     * This causes no problems because in such a case nothing gets marked
     * as GRAM, and therefore there is no marking that needs be redone
     * because of the substitution of the root at which it started.
     * Upon disentangling, start_sy is adjusted to refer to a replacement,
     * it any.
     */

    /** 
     * Bind undefined shorthands to defined nonterminals, check that defined
     * shorthands do not clash with nonterminals.
     * Check that undefined nonterminals in the grammar are not defined by
     * undefined shorthands.
     * Scan the lexis list and mark the nonterminals and terminals and
     * elements denoted by shorthands as LXS; mark nonterminals as LEXEME.
     * Check that a same nonterminal or terminal is not defined as lexemes
     * more than once. Report useless shorthands.
     */

    /* There are separate loops because the later ones access the shorthands
     * referred to from nonterminals, which must have been bound before, and
     * nonterminal usages can be encountered before definitions. Thus they
     * cannot be done in a same loop.
     */

    void bindShort(){
        if ((FL_X & this.trc) != 0){
            Trc.out.println("bindShort start");
        }

        // bind shorthands and nonterminals

        ParserDic h;

        // mark the replacements entries which are also referred to
        // from some RHSs of replacements (see description above)

        for (h = this.repDic.head; h != null; h = h.suc){
            for (ParserNode a = h.def; a != null; a = a.alt){
                for (ParserNode s = a; s != null; s = s.suc){
                    if (s.kind != ParserNode.S_NT) continue;
                    if ((ParserNode.SAME & s.status) != 0) continue;
                    s.def.status |= ParserNode.MRK;
                }
            }
        }
        for (h = this.shoDic.head; h != null; h = h.suc){
            h.status |= ParserNode.SHO;
            ParserDic hh = (ParserDic)            // find grammar nonterminal
                (this.ntDic.search(h));
            h.org = null;
            if (h.def == null){                   // must be a grammar nonterminal
                if ((hh == null) ||               // undefined
                    (hh.def == null)){
                    h.org = hh;
                    this.lex.message(
                        ParserLexer.ERR_UNDEF,"",h.point);
                } else {
                    h.org = hh;                   // ptr to real element
                    if ((FL_X & this.trc) != 0){
                        Trc.out.println("bindShort " + h + " " + hh.def);
                    }
                }
            } else {                              // shorthand
                if (hh != null){                  // ambiguous: same as a
                    if (hh.def != null){          // .. grammar nonterminal
                        this.lex.message(
                            ParserLexer.ERR_HIDNT,"",h.point);
                        h.org = hh;               // have a binding, otherwise
                                                  // .. it causes TR errors
                    } else {
                        h.org = hh;               // ptr to grammar nonterminal
                    }
                } else {
                    ParserDic rep = (ParserDic)(this.repDic.search(h));
                    if (rep == null) continue;
                    if ((ParserNode.MRK & rep.status) == 0){
                        continue;                 // not in RHS
                    }
                    this.ntDic.append(Str.EMPTY,ParserDic.NTER);
                    hh = this.ntDic.lastAdded;
                    hh.code = h.code;
                    hh.status = h.status;
                    hh.status &= ~ParserNode.SHO;
                    hh.point = h.point;
                    hh.line = h.line;
                    h.org = hh;                   // ptr to new nonterminal
                    if ((FL_X & this.trc) != 0){
                        Trc.out.println("repl RHS shorthands: " + hh);
                    }
                }
            }
        }
        this.repDic.unmark(false);

        // Now that shorthand entries which mirror grammar nonterminals
        // are bound, clone shorthand definitions which act as grammar
        // rules and attach them to grammar nonterminals which denote
        // shorthands. Note that in such rules there can be references
        // to entries which have been bound in the previous loop.

        for (h = this.shoDic.head; h != null; h = h.suc){
            if (h.def == null) continue;    // grammar nonterminal
            ParserDic hh = h.org;
            if (h.org == null) continue;
            hh.def = cloneShort(h,null);

            // this is to avoid to signal it as undefined 
            if (hh.def == null){            // empty (by error) shorthand
                hh.def = new ParserNode
                    (ParserNode.S_TER,hh.point,this.dic_emp);
            }
            hh.point = h.point;
            hh.line = h.line;
            this.shoDic.unmark(false);      // remove marks from dict's
            this.terDic.unmark(false);      // .. no need for repDic since
            this.ntDic.unmark(false);       // .. substitution only in grammar
            if (hh.def != null){            // shorthand not empty
                hh.def.suc = null;
            }
            hh.status &= ~ParserNode.G_GRP; // make it a group
            hh.status |= ParserNode.G_GRO;
        }

        if ((FL_X & this.trc) != 0){
            Trc.out.println("bindShort circ");
        }
        for (h = this.shoDic.head;          // find circular definitions
            h != null; h = h.suc){          // .. for ALL shorthands
            if (h.def != null){             // shorthand
                vi_nt_circ(h,true);
            }
        }

        if ((FL_X & this.trc) != 0){
            Trc.out.println("bindShort lxs");
        }
        vi_lxs(this.lxi_list,true);               // mark entries reacheable
                                                  // .. from lxi_list
        for (h = this.shoDic.head;                // find useless shorthands
            h != null; h = h.suc){
            if (h.def != null){                        // shorthand
                if ((ParserNode.ST & h.status) == 0){  // useless
                    this.lex.message(
                        ParserLexer.ERR_ULESS,"",h.point);
                }
            }
        }
        if ((FL_X & this.trc) != 0){
            Trc.out.println("bindShort end");
        }
    }

    /** 
     * Visit a shorthand and the ones referred to from its definitions
     * recursively and determine if there are circular references.
     * If there are, mark the shorthand as AIN.
     *
     * @param      h reference to the shorthand
     */

    /* When visiting an alternative and encountering a nonterminal, that
     * nonterminal is marked. If a marked nonterminal is found, a circular
     * definition is detected. When completing the visit of a nonterminal,
     * that nonterminal is unmarked so as to keep the marks only on the
     * ones which are on the stack of visits.
     */

    private boolean vi_nt_circ(ParserDic h, boolean show){
        if ((FL_X & this.trc) != 0){
            Trc.out.println("vi_nt_circ: " + h + " ");
            h.def.trace_exp();
            Trc.out.println();
        }
        h.status |= ParserNode.MRK;
        for (ParserNode a = h.def;a != null; a = a.alt){  // scan all alternatives
            switch (a.kind){
            case ParserNode.S_NT:
                ParserDic d = a.def;
                if (d.def == null) continue;              // nonterminal or undef
                boolean cir = true;
                if ((ParserNode.MRK & d.status) == 0){    // not (yet) circular
                    cir = vi_nt_circ(d,false);
                }
                if (show){                                // top leval call
                    if (cir){
                        this.lex.message(                 // circular def
                            ParserLexer.ERR_CIRCDEF,"",a.point);
                        h.status |= ParserNode.AIN;
                    }
                } else {
                    if (cir) return true;
                }
                break;
            }
        }
        h.status &= ~ParserNode.MRK;
        return false;
    }

    /** 
     * Visit a list of alternative nodes, mark each of them as LXS and
     * visit recursively the nonterminal ones (which are shorthands).
     * During the visit, the nonterminal nodes are markes as LEXEME.
     * TERMINALS is not checked because its duplication has already been
     * checked and it represents all the ones which have not been declared
     * anyway.
     *
     * @param      a reference to the list
     * @param      top <code>true</code> top visit
     */

    /* Note that when it is called on the lxi_list it visits the nodes
     * by starting the check on circular definitions, which it does not
     * when called inside. This check is done here instead of discarding
     * AIN elements so as to visit them as much as possible and detect
     * as many errors as possible.
     */

    private void vi_lxs(ParserNode a, boolean top){
        for (; a != null; a = a.alt){            // scan the list
            if ((FL_X & this.trc) != 0){
                Trc.out.println("vi_lxs: " + a);
            }
            ParserDic h = a.def;
            switch (a.kind){
            case ParserNode.S_TER:
                if (h == this.dic_emp) break;              // error
                if (h == this.dic_ter) break;              // TERMINALS
                if ((ParserNode.LXS & h.status) != 0){     // multiply defined as lexeme
                    this.lex.message(ParserLexer.
                        ERR_MULDEF,"",a.point);
                }
                h.status |= ParserNode.LXS;
                break;
            case ParserNode.S_NT:
                if (h.def != null){                        // shorthand
                    h.status |= ParserNode.ST;             // mark as reacheable
                    if ((ParserNode.MRK & h.status) == 0){ // not visited
                        h.status |= ParserNode.MRK;
                        vi_lxs(h.def,false);
                        if (top){
                            this.shoDic.unmark(false);
                        }
                    } 
                } else if (h.org != null){                     // nonterminal bound
                    if ((ParserNode.LXS & h.org.status) != 0){ // multiply defined as lexeme
                        this.lex.message(
                            ParserLexer.ERR_MULDEF,"",a.point);
                    } else {
                        h.org.status |= ParserNode.LEXEME;
                    }
                    h.org.status |= ParserNode.LXS;
                }
            }
            h.attr |= a.attr & (ParserNode.LEX_STR_NOSTORE |   // copy in dic
                ParserNode.LEX_STR_STORE |
                ParserNode.LEX_POINT_NOSTORE |
                ParserNode.LEX_POINT_STORE);
        }
    }

    /**
     * Deliver a copy of the definition of a shorthand, with the
     * shorthand occurrences in it expanded.
     *
     * @param      h reference to the shorthand
     * @param      p reference to the copy
     * @return     reference to the copy
     */

    /* The pointer to the last element in the list is kept in the suc
     * field of the first element, wich is returned and is passed along.
     * Cyclic and duplicated references are discarded so as not cause
     * problems to other algorithms, or produce extra error messages
     * (like e.g. DEADALT).
     * Note that empty nodes are discarded, which means that shorthands
     * whose definition is erroneous, and thus made only by one empty node,
     * are cloned into a null list.
     */

    private ParserNode cloneShort(ParserDic h, ParserNode p){
        if ((FL_X & this.trc) != 0){
            Trc.out.print("cloneShort " + h + " == ");
            if (h.def != null){
                h.def.trace_exp();
            }
            Trc.out.print(" on: ");
            if (p != null){
                ParserNode suc = p.suc;
                p.suc = null;
                p.trace_exp();
                p.suc = suc;
            }
            Trc.out.println();
        }
        h.status |= ParserNode.MRK;
        for (ParserNode a = h.def; a != null;       // scan all alternatives
            a = a.alt){
            ParserNode c = null;
            ParserDic d = a.def;
            if ((ParserNode.MRK & d.status) != 0){  // circular or already
                continue;                           // .. present
            }
            d.status |= ParserNode.MRK;
            switch (a.kind){
            case ParserNode.S_TER:
                if (d == this.dic_emp) continue;    // empty, discard
                c = (ParserNode)(a.clone());        // create a copy
                c.alt = null;
                break;
            case ParserNode.S_NT:
                if (d.def == null){                 // nonterminal or undef
                    c = (ParserNode)(a.clone());    // create a copy
                    c.alt = null;
                    c.def = d.org;                  // refer the grammar nt
                    break;
                } else {
                    p = cloneShort(d,p);
                    continue;
                }
            }
            if (p != null) p.suc.alt = c;           // link prev alternative
            else p = c;
            p.suc = c;
        }
        if ((FL_X & this.trc) != 0){
            Trc.out.print("cloned ");
            if (p != null){
                ParserNode suc = p.suc;
                p.suc = null;
                p.trace_exp();
                p.suc = suc;
            }
            Trc.out.println();
        }
        return p;
    }

    /** 
     * Check that special notations are not used in the grammar proper.
     * Visit all rules and report all the usages of special notations.
     * Note that it does not enter constraints since when they are
     * allowed, they can contain special notations, and when they
     * are not, they have already been reported.
     */

    private void ck_special(){
        int casein = ParserNode.CASEINSENS |
            ParserNode.CASEINSENS_FULL;
        for (ParserDic h = this.ntDic.head; h != null; h = h.suc){
            if (h.def == null) continue;
            for (ParserNode a = h.def; a != null; a = a.alt){
                for (ParserNode s = a; s != null; s = s.suc){
                    if ((ParserNode.GRAM & h.status) != 0){
                        if (((ParserNode.S_COMPL |
                            ParserNode.S_COMCL |
                            ParserNode.S_DIFF |
                            ParserNode.S_AND |
                            ParserNode.S_UPTO |
                            ParserNode.S_RNG) & s.oper) != 0){
                            this.lex.message(
                                ParserLexer.ERR_NACONS,"",s.point);
                        }
                        if (s.constr != null){
                            this.lex.message(
                                ParserLexer.ERR_NACONS,"",s.constr.point);
                            break;
                        }
                        if ((casein & s.status) != 0){
                            s.status &= ~casein;
                            this.lex.message(
                                ParserLexer.ERR_CASEIN,"",s.point);
                        }
                    }
                    ParserDic d = s.def;
                    if (d == null) continue;
                    if (d.repl != null){             // use redefinition
                        d = d.repl;
                    }
                    if (((ParserNode.GRAM & h.status) != 0) &&
                        ((ParserNode.LXS & h.status) == 0)){
                        if ((ParserNode.LEXEME &     // grammar rule: a lexeme
                            d.status) != 0) continue;
                    }
                    if (((ParserNode.LEX_STR_NOSTORE |
                        ParserNode.LEX_STR_STORE |
                        ParserNode.LEX_POINT_NOSTORE |
                        ParserNode.LEX_POINT_STORE) & s.attr) != 0){
                        this.lex.message(
                            ParserLexer.ERR_NACONS,"",s.point);
                        break;
                    }
                }
            }
        }
    }

    /** 
     * Mark as lexemes the nodes which are such in the rules of a nonterminal.
     * It is called to visit the syntax starting from the start symbol and
     * mark all reacheable terminals as LEXEME. It does not enter nonterminals
     * which are LEXEME.
     * Note that the LXS attribute in the terminal dictionary serves here only
     * to detect multiple definitions in LEXIS, not to tell which terminals
     * are lexemes, property that is determined by reaching terminals
     * from the starting symbol.
     * Note that it does not visit constraints because they are only in
     * the lexicon.
     * Terminals in lexis are first marked as LXS only. Later on they are
     * checked to be LEXEMES as well.
     */

    void vi_nt_gram(ParserDic h){
        if ((FL_X & this.trc) != 0){
            Trc.out.println("vi_nt_gram: " + h + " " +
                ((ParserNode.GRAM & h.status) != 0));
        }
        if (h.def == null) return;               // undefined
        if ((ParserNode.GRAM & h.status) != 0){  // visited
            return;
        }
        h.status |= ParserNode.GRAM;
        if ((FL_X & this.trc) != 0){
            Trc.out.println("visiting: " + h);
        }
        for (ParserNode a = h.def; a != null; a = a.alt){  // scan all alternatives
            for (ParserNode s = a; s != null; s = s.suc){  // scan all successors
                switch (s.kind){
                case ParserNode.S_TER:                     // terminal: mark it
                    if (s.def == this.dic_emp) break;
                    s.def.status |= ParserNode.LEXEME;     // mark element
                    if ((FL_X & this.trc) != 0){
                        Trc.out.println("terminal lexemes: " + s.def);
                    }
                    break;
                case ParserNode.S_NT:                      // nonterminal
                    if (s.def == null) break;
                    if ((ParserNode.LEXEME & s.def.status) != 0){
                        break;
                    }
                    if ((ParserNode.GRAM & s.def.status) == 0){ // not yet visited
                        vi_nt_gram(s.def);
                    }
                    break;
                }
            }
        }
    }

    /** 
     * Mark as LXS all the elements directly or indirectly referred to by
     * the specified element.
     *
     * @param      h reference to the element
     */

    /* Note that references to lexemes are not visited because it would
     * be a duplicate since all lexemes are visited anyway.
     * To mark down all the elements used in lexis without visiting several
     * times the same element (or even enter endless loops), the ones which
     * have been visited are marked as MRK.
     * Replacements are visited automatically since they are in the grammar.
     */

    private void vi_nt_lxsmrk(ParserDic h){
        if (h.def == null) return;              // undefined
        if ((ParserNode.MRK & h.status) != 0){  // visited
            return;
        }
        h.status |= ParserNode.MRK;
        if ((FL_X & this.trc) != 0){
            Trc.out.println("vi_nt_lxsmrk: " + h);
        }
        for (ParserNode a = h.def; a != null; a = a.alt){
            for (ParserNode s = a; s != null; s = s.suc){
                switch (s.kind){
                case ParserNode.S_TER:          // terminal: mark it
                    if (s.def == this.dic_emp) break;
                    s.def.status |= ParserNode.LXS;
                    // no need to visit replacements of lexemes
                    // since they are visited anyway
                case ParserNode.S_NT:           // nonterminal
                    if (s.def == null) break;
                    s.def.status |= ParserNode.LXS;
                    vi_nt_lxsmrk(s.def);
                    break;
                }
            }
        }
    }

    /** 
     * Visit a node and check recursively that all the terminals referred
     * to by it are lexemes. Visit shorthands in it.
     *
     * @param      h reference to the element
     */

    private void vi_terck(ParserNode a){
        if (a.def == this.dic_emp) return;
        for (; a != null; a = a.alt){               // scan all alternatives
            ParserDic h = a.def;
            switch (a.kind){
            case ParserNode.S_TER:
                if (h == this.dic_ter) break;       // TERMINALS
                if (h.repl != null) h = h.repl;
                if ((ParserNode.LEXEME &
                    h.status) == 0){                // not a lexeme
                    this.lex.message(
                        ParserLexer.ERR_NOLEX,"",a.point);
                }
                break;
            case ParserNode.S_NT:
                if (h.def == null) break;               // not a shorthand
                if ((ParserNode.MRK & h.status) == 0){  // not yet visited
                    h.status |= ParserNode.MRK;
                    vi_terck(h.def);                    // scan its definition
                }
            }
        }
    }

    /* Replacements
     *
     * Rationale:
     *
     * Autoreferences: occurrences of nonterminals (including shorthands)
     * in replacement rules (and thus in rules in general) do not denote
     * autoreferences. If they did, the rule: <SH> => a <SH> could be
     * interpreted both as <SH> => a <> or as <SH> => a {...}, where {...}
     * is the expansion of the shorthand.
     * Since in <SH1> => a <SH2>, <SH2> may only be interpreted as a shorthand,
     * it must be so also in the former case for uniformity.
     * In <R> => a <R>, where <R> is not a shorthand, <R> could be interpreted
     * as <>. This would lead to state that when <R> is a shorthand, it
     * should also be interpreted as <>, which contradicts what stated before.
     * Moreover, consider the rules: <SH> == <A>, and <SH> => x <A>.
     * The second rule since it does not contain an occurrence of the LHS
     * element (and neither contains <>) would be in error while effectively
     * is not since it contains a shorthand which, once expanded, makes the
     * rule correct. This means that the semantics ought to be that there must
     * be an autoreference in a rule once shorthands have been replaced in it. 
     * To make semantics clean and simple, a nonterminal denotes itself, and
     * only <> denotes an autoreference.
     * Note that there is a need to allow <> in groups anyway because otherwise
     * it would be quite obscure as well (<> it should be rejected in groups
     * so as not to make it denote the nonterminal which represents the group).
     * Disentangling then eliminates <>, which would be rather difficult to
     * keep when cloning and replacing rules.
     * To simplify checking, a rule which contains <> in its RHS (including
     * groups) is marked as SAME when the rule is parsed.
     *
     * It is not mandatory to have an autoreference in the RHS of a replacement.
     * I.e. replacements can also be used to define more precisely the spelling
     * of lexemes, like e.g.: of => {o|O}{f|F}.
     * When a terminal has a replacement, there is not a need to introduce
     * a terminal', and also when a nonterminal has a replacement which
     * does not contain an autoreference. However, for uniformity, new
     * elements are introduced. Note that when no autoreference is present,
     * the origin rule is "lost".  In order not to issue an error of
     * unreacheability, the origin rule is visited explicitly when performing
     * the ST marking.
     *
     * Implementation:
     *
     * Since only the replacements which are used are plugged in the grammar,
     * and checks are made only on the grammar, the unused replacements are
     * not checked. The semantic checks which are made on the grammar are:
     *
     *  - duplicated alternatives,
     *  - empty lexemes
     *  - unreacheable rules (on replacements an "undefined lexeme" is issued)
     *  - dead ends, and dead alternatives
     *
     * Duplicated alternatives may not be completely detected on replacements
     * which have a shorthand LHS because a <> denotes an element which is
     * known only when the actual rule is created.
     *
     * Since replacements are plugged into the grammar, and possibly cloned
     * several times, there is then a need for the errors which are detected
     * after plugging (because it was not possible to detect them before) to
     * report them only once. This is done by scanning the list of errors
     * and avoiding to insert duplicates.
     * A replacement with a shorthand LHS can have errors (e.g. it produces
     * no terminals).
     * If the error is caused by a redefined rule which produces no terminals,
     * the error is shown where that rule is written, and thus, showing it
     * on the replacement is irrelevant. When the error is due to the
     * replacement rule itself, an error would be reported for each lexeme
     * the shorthand denotes. This is confusing, even if the names of the
     * lexemes which are in error were displayed because they are known since
     * they are the lexemes denoted by the shorthand. Reporting the errors on
     * the origin rules is also confusing because there is in reality no error
     * on those rules. The solution is to report the error once only on the
     * replacement. A solution to do it is to have a way to go from ntDic
     * entries to the replacements that define them. This is not difficult
     * for normal replacements, for which it is possible to scan ntDic, and
     * for the entries which have .repl not null go to it and then take .org,
     * which points to the cloned rule.  But it is a bit harder for
     * replacements whose LHS is a shorthand, since the shorthand  should be
     * visited to reach them, and even harder for the ones which derive from
     * the expansion of TERMINALS. A soultion could be to make .repl of the
     * cloned rules refer to the replacement, and flag them somehow so as to
     * distinguish them from the origin ones.  The same kind of problem occurs
     * also when a rule is cloned to disentangle gram+lex rules and it does
     * not produce terminals.  The problem is even worse for DEADALT.
     * The easiest solution is to discard duplicates when enqueuing errors.
     *
     * If a replacement has a binding, then either it refers to a nonterminal
     * or a shorthand or a lexeme, and then there is no point in checking
     * that it is reacheable, otherwise it redefines no lexemes, and then
     * an error has already been issued.
     *
     * Binding:
     *
     * The defining occurrences of nonterminals and terminals in replacement
     * rules are stored in repDic, including internal and undefined names.
     * If replacements rules, when parsed, produced entries in ntDic, the
     * resulting dictionary would contain elements that might need be purged
     * (e.g. the ones of rules with a shorthand LHS). To avoid this,
     * replacements are kept separate and then plugged them into the grammar.
     * Terminals in replacement rules (LHSs and RHSs) are stored terDic also.
     * This is done because terDic collects all terminals. Note that also
     * terminals which are in RHSs of replacements go in terDic even if
     * they will not be used in the final grammar. This is no problem because
     * terDic is not used as such to generate parsing tables.
     * Since all occurrences of nonterminals in RHSs of replacements are put
     * in repDic, there is a need to bind them first (as done for shoDic).
     * All entries must be bound to ntDic entries or shoDic entries.
     *
     * Entries in dictionaries are bound as follows:
     *
     *    ntDic:  .repl -> replacement entry
     *    terDic: .repl -> replacement entry
     *
     *    repDic  .org  -> shoDic (terDic for terminals, ntDic when there
     *                     is no shoDic entry and when used only)
     *            .def  -> rule of the replacement
     *
     * repDic entries refer to shoDic entries so as to be able to expand.
     * Note that when processing definitions, .def is always set, otherwise
     * it would not be a definition. In case of error it is set to the empty.
     *
     * The .org of a repDic entry points to the shoDic entry, if any, otherwise
     * to the ntDic entry (which is the case for nonterminal names which are
     * in repDic, but undefined and also not present in shoDic)
     *
     * The .repl is set only when replacements are plugged into ntDic so as to
     * reject plugging on multiple definitions
     *
     * There are the following cases of binding of a replacement symbol R
     * when it occurs in the RHS of a replacement:
     *
     *        replacements       shorthands         grammar
     *   <R>   definition        definition         definition   error
     *             "     .org--->     "     .org--->occurrence
     *             "                  "                no
     *             "     .org--->occurrence .org--->definition
     *             "                  "             occurrence   error
     *             "                  "                no        error
     *             "                 no                any       error
     *         occurrence        definition         definition   error
     *             "     .org--->     "     .org--->occurrence
     *             "                  "                no
     *             "     .org--->occurrence .org--->definition
     *             "                  "             occurrence   error
     *             "                  "                no        error
     *             "     .org------- no ----------->definition
     *             "                 no                any       error
     *    R    definition.org--- occurrence  =====> occurrence (in terDic)
     *             "                  "                no        error
     *             "                 no                any       error for non lexemes
     *         occurrence ------ occurrence  =====> occurrence
     *             "                  "                no        error
     *             "                 no                any       error
     *
     * When cloning and plugging replacements in the grammar, there is a need
     * to bind nonterminals to entries in ntDic with the same name. Note that
     * when replacements are parsed, all nonterminal occurrences go in repDic,
     * but this does not mean that applied occurrences in RHSs are bound to
     * them. On the contrary, they must be bound to ntDic (non-replacement)
     * entries. When plugging, nodes denoting <> are bound as well to the
     * origin definitions.
     *
     * Plugging of replacements (cloning):
     *
     * There are two approaches to process replacements: 1. keep an internal
     * representation which parallels the input and work on it, and 2. have
     * one which the real grammar. The latter is easier to check since it
     * is simpler and it is the real grammar, while the former represents
     * the grammar in a rather complex way. Processing the real thing is
     * easier, but it makes reporting errors on the input harder. However,
     * the opposite is even more difficult since when checking there is a
     * need to figure out what the grammar would be should the replacement
     * have been done.
     * The same reasoning applies to disentangling of the grammar.
     * Cloning is also done because there are in practice not many cases in
     * which a same rule is used both in grammar and lexicon, and because
     * it confines the support of replacements into the methods which
     * implement them instead of making the other algorithms have to deal
     * with it.
     * Token rules are cloned instead of grammar rules since they are
     * usually less.
     *
     * Note that to generate the parser, the rules for the lexemes are not
     * needed; and to generate the lexer, it is sufficient to start from
     * lexemes. Parser and lexer generation could also be done with
     * replacements which are not plugged into the grammar.
     * The reason for doing it is to keep most algorithms simple.  
     * Obtaining a grammar with a simple internal representation allows to
     * keep simple the remaining part of the parser.
     *
     * Replacements are visited, copies of their rules are created by cloning
     * them, and are plugged into the grammar. In so doing, new entries are
     * added to ntDic.  This applies also to redefined terminals since they are
     * effectively rules, and as such they must be visited when the
     * nonterminals are visited by most algorithms. To make the internal
     * representation consistent, nodes which refer to redefined terminals
     * are changed in S_NT.  This relieves many algorithms to take into
     * account that S_TER nodes can have a rule behind and also that such
     * nodes are either terminals or lexemes.
     * Redefined terminals are represented by a dictionary entry whose kind
     * is PasrserDic.TER appended to the ntDic list. It is not simple to
     * introduce a NTER entry because there would be a need to avoid name
     * clashes and also to introduce a new naming rule which allows nonterminals
     * to be represented without angular brackets.
     * When cloning replacement rules, the implicit nonterminals (the ones
     * that represent groups) are cloned as well. It would also be possible
     * to assign internal names which are unique for ntDic and repDic from the
     * very beginning so as to move them instead of cloning, but for the
     * replacements which have a shorthand LHS there would still be a problem.
     * Replacements RHSs which have no groups could also be linked without
     * cloning. However, the majority of replacements have a LHS which is
     * a shorthand, and therefore this optimization would be of little use.
     * Note that replacement rules with a shorthand LHS are be cloned and
     * not simply referred to because otherwise they would lead to share
     * nodes, thus impairing most algorithms and the generation of the
     * parsing tables as well.
     *
     * To avoid clashes, either the replacements or the entries replaced must
     * change name. The simplest solution is to change that of the
     * replacements, but it would not be difficult to change the other ones
     * either. For terminals it is better to change that of replacements,
     * and make them become nonterminals. Replacement names never clash with
     * the empty string notation. To keep the original names, and at the
     * same time avoid clashes, the new names are stored as the original
     * ones with an attribute attached.
     *
     * Note that it is not possible to plug replacements into the final
     * place stright away: in gram+lxs rules the nodes into which the cloned
     * replacements should be plugged are not the ones present at that time;
     * storing the reference in the final place can be done only when such
     * rules have been disentangled. The right way to do this is to link
     * replacements into .repl of the origin rules, then evaluate the gram/lxs
     * attributes by following the replacements when visiting down the start,
     * and the origin rules when visiting the lexemes, and then disentangle.
     * Note that rules which have a replacement are never cloned since they
     * are lexemes rules.
     *
     * When plugging replacements, there a need to make the newly introduced
     * nonterminals have the proper gram/lxs attributes, and to mark them on
     * the other nonterminals by taking into account the newly introduced
     * rules.  There are two solutions: 1. plug the replacements and then mark,
     * and 2. mark and then plug the replacements. In the first one, the
     * marking must visit replacements, in the second the plugging must also
     * mark what is plugged.
     * When marking gram, lexemes are not entered, be either them redefined or
     * not, and therefore replacements are irrelevant for this.
     * Let's see the second one, and ask if the marking just done is correct
     * and if the marking would change if replacements were taken into account
     * from the beginning.  When marking lxs, nonterminals have their origin
     * binding, but replacements must be followed at first. Thus, there is
     * a need to run again the lxs marking on replacements. The first
     * solution is taken because it is simpler.
     * The LEXEME attribute is moved from the origin entries into the replaced
     * one when cloning.
     *
     * To make grammar rules refer to replacements and lexicon rules refer to
     * the origin rules, either the ntDic entries or the rules can be changed.
     * In the former case, also the point and the line should be changed so as
     * to let errors present in replacement rules be reported on the redefined
     * nonterminals. The second solution is done because rules are visited
     * anyway when disentangling the grammar.
     * The same does not hold for shorthands because no parallel definitions
     * are allowed: they must be defined in one dictionary only, and therefore
     * there is no choice: the origin definition is changed.
     *
     * Disentangling is done by scanning all nonterminals and cloning the ones
     * which are both gram and lxs. Then all rules are visited and the
     * references to nonterminals and terminals are adjusted to refer to the
     * appropriate ones. To cater for lxs rules which refers indirectly to
     * gram rules, the gram/lxs attributes are set by visiting down the
     * nonteminals recursively. In so doing, the rules which are used by
     * both are identified.
     * Note that redefined terminals (and lexemes in general) are not cloned
     * because they are lexemes only and never gram+lxs.
     *
     * Disentangling:
     *
     * The restriction that a token rule may not refer to other token rules
     * might be acceptable when there are replacements, but not if there are
     * no replacements.
     * The correct approach is to allow it by stating that once the grammar
     * has been partitioned, all the occurrences of token nonterminals in
     * the lexicon are bound to the original definitions, and all the ones
     * in the grammar proper are bound to the (possibly) replaced ones.
     * The semantics of a token rule R which refers directly or not to a token
     * rule T is that T in such a context does not act as a lexeme both
     * for binding and for attributes. E.g. in such a context it can
     * produce the empty string. Now, if T is referred to from rules which
     * are only GRAM or only LXS, that is no problem because it can be treated
     * as a lexeme or not depending on the context. The problem is when it is
     * referred to from rules which are used by both the grammar and the
     * lexicon because there would be a need to carry on parallel attributes.
     * Of course, in a GRAM rule, a lexeme has its lexeme meaning, while
     * in a LXS one it has not, and thus in the algorithms a lexeme is
     * recognized as such only if the containing rule is a GRAM one.
     * Note that GRAM nonterminals refer always (except when they generate the
     * empty string or when they are in error) to tokens or to rules that refer
     * to tokens.
     *
     * If rules shared by the grammar and the lexicon refer lexemes which are
     * terminals, there is no problem for the attributes because T, when
     * referred to from R (or a LXS rule) is a terminal (TR, non EM, etc.),
     * and when it is referred to from a GRAM rule is a lexeme which is also
     * TR, non EM, etc.
     * When they are redefined terminals, there is a need to follow the
     * original definition when referred to from the lexicon.
     * Note, however, that when a lexicon is defined, it is almost always the
     * case that terminals are redefined (to allow for comments).
     *
     * There are two alternatives to handle this semantics: 1. keep one copy
     * of the shared rules, or clone (disentangle them).
     *
     * The first leads to have more complex visit algorithms.
     * The second solution is to duplicate all shared rules so as to have
     * a copy of them which does not refer to the (possibly) replaced lexemes.
     * This makes most algorithms much more simple.
     *
     * Disentangling is done by first marking which rules are shared.
     * To convey the maximum information to the disentangle method, LXS is
     * marked on the nodes which are used by lexemes, but not on the lexemes
     * themselves, unless they are referred to from some rules of the lexicon.
     * The lexicon is thus made by all lexemes rules + all LXS rules.
     * Terminals are marked in the same way.
     * Disentangling then proceeds by cloning the shared rules and making the
     * newly introduced nonterminals have no GRAM mark and have the .repl
     * field null.
     * Lexemes rules are not cloned. In other words, only the portion of the
     * graph of rules which is common between the grammar and the lexicon
     * and has as a frontier token rules is cloned.
     * There are some cases in which this is more than what strictly needed:
     * this is when the shared rules refer to terminal lexemes.
     * However, this occurs seldom. On the other hand, it makes disentangling
     * easier.
     * Once the rules are disentangled, the LXS rules are bound to the cloned
     * ones, and the references to nonteminal lexemes to the origin definition
     * so as to have a clean grammar.
     * When cloning, new dictionary entries are generated. The handles to
     * them are stored in the .org of the origin entries so as to perform
     * binding later (references in token rules and in the cloned ones
     * are thereafter redirected to them).
     * The newly created entries are linked to the dictionary list anyway.
     * Disentangling makes GRAM rules use replacements when referring to
     * lexemes and LXS rules use the origin definitions.
     *
     * References between rules:
     *
     *    gram    gram ok
     *            lexis ok
     *            gram/lxs problem
     *    lexis   gram/xls problem
     *            lexis problem
     *            lxs ok
     *    lxs     gram/lxs problem
     *            lexis problem
     *            lxs ok
     *
     * replacements solve some problematic references: since they become the
     * lexemes, lexemes referencing directly lexemes would infact no more
     * reference lexemes, but LXS rules.
     */

    /** 
     * Check the conditions on the replacements and duplicate replacement
     * rules when their LHS denotes several rules.
     */

    private void ck_rep(){
        if ((FL_X & this.trc) != 0){
            Trc.out.println("binding replacements");
            long att = ParserNode.EXP_GRO | ParserNode.REP | ParserNode.SHO;
//            trace_dic(this.ntDic,att,att,Trc.out);
            trace_dic(this.ntDic,att,att);
//            trace_dic(this.terDic,att,att,Trc.out);
            trace_dic(this.terDic,att,att);
        }

        // check that replacement rules redefine lexemes only and bind them
        // To eliminate problems in using bindings and making them in the same
        // loop, two loops are used

        for (ParserDic h = this.repDic.head;
            h != null; h = h.suc){
            if ((FL_X & this.trc) != 0){
                Trc.out.println("bind " + h + " " + whichDic(h));
            }
            h.status |= ParserNode.REP;          // mark all entries as repl.
                                                 // .. needed for cloning
            if ((ParserNode.INTER & h.status) != 0){  // do not bind groups
                continue;
            }
            if (h.kind != ParserDic.NTER){       // TER, TER_SPE
                if (h.org != this.dic_ter){      // normal terminal
                    if ((ParserNode.LEXEME & h.org.status) == 0){
                        this.lex.message(
                            ParserLexer.ERR_UNLEX,"",h.point);
                        h.org = null;
                    }
                } else {                         // TERMINALS
                    bind_terminals(h);           // bind all terminal lexemes
                                                 // .. that are not declared in LEXIS
                }
            } else {                             // nonterminal or shorthand
                ParserDic hh = (ParserDic)
                    (this.shoDic.search(h));
                if (hh == null){                 // not a shorthand
                    h.org = null;
                    if (h.def != null){
                        this.lex.message(
                            ParserLexer.ERR_UNLEX,"",h.point);
                    } else {                     // present only in RHS of repl.
                        hh = (ParserDic)
                            (this.ntDic.search(h));
                        if (hh != null){         // reference to a grammar
                            h.org = hh;          // .. nonterminal
                        } else {
                            this.lex.message(
                                ParserLexer.ERR_UNDEF,"",h.point);
                        }
                    }
                } else {                         // shorthand (including the
                    h.org = hh;                  // .. ones which mirror
                                                 // .. grammar nonterminals
                }
            }
        }

        if ((FL_X & this.trc) != 0){
            Trc.out.println("checking replacements");
        }

        // clone/plug now replacements into the grammar

        for (ParserDic h = this.repDic.head;
            h != null; h = h.suc){
            if ((ParserNode.INTER & h.status) != 0){  // skip groups
                continue;
            }
            if ((FL_X & this.trc) != 0){
                Trc.out.println("plugging " + h);
            }
            if (h.def == null) continue;        // simple reference
            if (h.org == null) continue;        // in error
            if (h.kind != ParserDic.NTER){      // it replaces a terminal
                cl: if (h.org != this.dic_ter){ // normal terminal
                    if (h.org.repl != null){
                         break cl;              // multiple definition
                    }                           // error reported on lexis/shorhand
                    if ((FL_X & this.trc) != 0){
                        Trc.out.println("repsho term: " + h
                            + " " + whichDic(h));
                    }
                    this.defnt = h.org;
                    ParserDic hh = cloneRule(h.org,h,true);
                    h.org.repl = hh;            // in entry point to repl
                    hh.org = h.org;
                    h.org.status &= ~ParserNode.LEXEME;
                }
            } else {                            // nonterminal or shorthand
                ParserDic hh = h.org;           // entry in shoDic
                // when .def is not null, .org is not null
                // only if it is a shorthand
                vi_nt_repsho(hh,h);             // shorthand, possibly
                this.shoDic.unmark(false);      // .. nonterminal in lexis
            }
        }
        if ((FL_X & this.trc) != 0){
            Trc.out.println("plugged");
            long att = ParserNode.EXP_GRO | ParserNode.REP | ParserNode.SHO;
//            trace_dic(this.ntDic,att,att,Trc.out);
            trace_dic(this.ntDic,att,att);
//            trace_dic(this.terDic,att,att,Trc.out);
            trace_dic(this.terDic,att,att);
        }
    }

    /** 
     * Introduce a new entry in the replacement dictionary for each
     * lexeme denoted by TERMINALS.
     *
     * @param      r reference to the replacement
     */

    /* There may not be a multiple definition since all the replacements
     * whose LHS is TERMINALS and which occur after one with that LHS
     * are already rejected during parsing.
     */

    private void bind_terminals(ParserDic r){
        Str symb = new Str();
        for (ParserDic h = this.terDic.head;  // bind all terminal lexemes
            h != null; h = h.suc){            // .. that are not declared in LEXIS
            if (((ParserNode.LEXEME & h.status) != 0) &&
                ((ParserNode.LXS & h.status) == 0)){
                symb.assign(h.code);
                ParserDic p = addDic(this.repDic,symb,h.kind,
                    h.point,h.line);
                p.status = r.status;
                p.status &= ~(ParserNode.MRK | ParserNode.TR |
                    ParserNode.ST | ParserNode.EO | ParserNode.EM);
                p.def = r.def;
                p.point = r.point;
                p.line = r.line;
                p.org = h;
            }
        }
    }

    /** 
     * Visit an element and if it is a nonterminal or terminal create a
     * replacement, otherwise (it is a shorthand) scan its definition
     * and for all the elements denoted by it create a replacement.
     *
     * @param      h reference to the element
     * @param      r reference to the replacement
     */

    private void vi_nt_repsho(ParserDic h, ParserDic r){
        if ((FL_X & this.trc) != 0){
            Trc.out.println("vi_nt_repsho: " + h.toString(
                ParserNode.REP | ParserNode.SHO));
        }

        // entries in shoDic which are copies of grammar nonterminals
        // have .def null

        if (h.def != null){                          // shorthand defined
            if ((ParserNode.MRK & h.status) == 0){   // not yet visited
                h.status |= ParserNode.MRK;
                for (ParserNode a = h.def; a != null;
                    a = a.alt){                      // scan all alternatives
                    for (ParserNode s = a; s != null;
                        s = s.suc){  // scan all successors
                        if ((FL_X & this.trc) != 0){
                            Trc.out.println("vi_nt_repsho ele: " + s);
                        }
                        switch (s.kind){
                        case ParserNode.S_TER:
                            if (s.def == this.dic_emp) continue;
                            ParserDic d = s.def;
                            if ((FL_X & this.trc) != 0){
                                Trc.out.println("inner term " + d +
                                    " " + whichDic(d));
                            }
                            if (d.repl != null) break;  // multiple definition
                            this.defnt = d;
                            ParserDic hh = cloneRule(d,r,true);
                            d.repl = hh;             // in entry point to repl
                            hh.org = d;
                            d.status &= ~ParserNode.LEXEME;
                            break;
                        case ParserNode.S_NT:
                            vi_nt_repsho(s.def,r);   // visit it
                            break;
                        }
                    }
                }
            }
        } else {                                     // nonterminal or terminal
            if (h.org == null) return;               // undefined
            if (h.org.repl != null) return;          // multiple definition
                                                     // error reported on lexis
                                                     // .. or shorthand
            ParserDic d = h.org;
            if ((FL_X & this.trc) != 0){
                Trc.out.println("repsho: " + d + " " + whichDic(d));
            }
            this.defnt = d;
            ParserDic hh = cloneRule(d,r,true);      // d is the element to
                                                     // .. clone, r the rule
            d.repl = hh;                             // in entry point to repl
            hh.org = d;
            d.status &= ~ParserNode.LEXEME;
            if ((FL_X & this.trc) != 0){
                long att = ParserNode.REP | ParserNode.SHO;
                Trc.out.println("new: " + hh.toString(att,att));
            }
        }
    }

    /**
     * Link all lexemes into a list and enumerate them. The ordering is:
     * 1. all terminal lexemes that are not declared in LEXIS in the order
     * in which they occur in the grammar, 2. all the other lexemes in the
     * order in which they are (recursively) defined in LEXIS.
     * TERMINALS denotes the terminal lexemes that are not declared in
     * LEXIS, in the order in which they occur in the grammar.
     */

    /* To determine which lexemes are not declared in lexis, the list
     * of declared lexemes is build first, and they are marked with MRK.
     * This marking serves to avoid endless loops and to handle TERMINALS.
     * Then terDic and ntDic are visited so as to take all the terminals
     * redefined or otherwise which are lexemes.
     * To avoid to insert duplicated elements in the list, the tokNum
     * field is used: when it has a value different from the initial
     * one, the element is already in the list. Since the initial value
     * is 0, tokens are temporarily numbered from 1 upwards, and at the
     * end renumbered from 0 upwards.
     */

    private void make_lexlist(){
        this.lexseq = 1;                    // start with 1 to insert
        if ((FL_X & this.trc) != 0){        // .. elements only once (see above)
            Trc.out.println("make_lexlist");
        }
        vi_llist(this.lxi_list,0);          // make list of LEXIS
        ParserNode lt = this.lex_list;      // save list already built
        if (this.lex_list != null){
            this.lex_list.suc = null;
        }
        if ((FL_X & this.trc) != 0){
            Trc.out.println("implicit");
        }

        // the lexemes which are declared in lexis 
        // have MRK now

        this.lex_list = null;               // build a list with the terminal
        this.lexseq = 1;                    // .. lexemes not declared in LEXIS
        for (ParserDic hh = this.terDic.head;
            hh != null; hh = hh.suc){
            ParserDic h = hh;
            if (h.repl != null){            // use redefinition
                h = h.repl;
            }
            if ((ParserNode.LEXEME & h.status) == 0) continue;
            if ((ParserNode.MRK & h.status) != 0) continue;
            lexlink(h,this.dic_ter.attr);   // link in list
        }
        this.terDic.unmark(false);
        this.shoDic.unmark(false);
        this.ntDic.unmark(false);

        if (this.lex_list == null){         // concatenate the two lists
            this.lex_list = lt;             // first
        } else {
            this.lex_list.suc.alt = lt;     // append
        }
        if (this.lex_list != null){
            this.lex_list.suc = null;
        }
        this.lexseq = 0;                    // assign final token numbers
        for (ParserNode a = this.lex_list;
            a != null; a = a.alt){
            a.def.tokNum = this.lexseq++;   // reassign token numbers
        }
        if ((FL_X & this.trc) != 0){
            Trc.out.println("lex_list:");
            for (ParserNode a = this.lex_list; a != null;
                a = a.alt){
                Trc.out.println(a.def + " " + a.def.tokNum);
            }
        }
    }

    /** 
     * Visit a list and for each element, if it is a nonterminal, append it to
     * the lex_list, otherwise (it is a shorthand), scan its definition.
     * TERMINALS make all non-lxs lexemes to be appended to the list.
     * Propagates the storage attributes to the elements of shorthands.
     *
     * @param      a reference to the list
     * @param      sto storage attributes to propagate
     */

    /* MRK is used on shoDic entries to avoid to visit them twice and
     * to enter an endless loop when they are circular.
     * MRK on terDic and ntDic entries is used to mark the lexemes which
     * are defined in lexis so as to let TERMINALS denote the ones which
     * are not in it.
     */

    private void vi_llist(ParserNode a, int sto){
        if ((FL_X & this.trc) != 0){
            Trc.out.println("vi_llist: " + a +
                Integer.toHexString(sto));
        }
        for (; a != null; a = a.alt){            // scan all alternatives
            int newatt = storeAttr(sto,a.attr);
            switch (a.kind){
            case ParserNode.S_TER:
                if (a.def == this.dic_emp) break;
                ParserDic d = a.def;
                if (d != this.dic_ter){                    // not TERMINALS
                    if ((ParserNode.MRK & d.status) == 0){ // not linked
                        d.status |= ParserNode.MRK;
                        lexlink(d,newatt);                 // link in list
                    }
                }
                break;
            case ParserNode.S_NT:
                ParserDic h = a.def;                       // visit it
                if (h.def == null){                        // non terminal
                    if (h.org == null) break;              // unknown
                    if ((ParserNode.MRK & h.org.status) == 0){  // not linked
                        h.org.status |= ParserNode.MRK;
                        lexlink(h.org,newatt);             // link in list
                    }
                    break;
                }
                if ((ParserNode.MRK & h.status) != 0){     // visited
                    break;
                }
                h.status |= ParserNode.MRK;
                vi_llist(h.def,newatt);                    // visit shorthand
                break;
            }
        }
    }

    /** 
     * Link an element to the token list.
     *
     * @param      h reference to the element
     * @param      attr attributes to be stored in the dictionary entry of
     *             the element, and to be propagated to the element
     */

    private void lexlink(ParserDic h, int attr){
        if (h.repl != null){                 // use redefinition
            h = h.repl;
        }
        if (h.tokNum == 0){                  // not yet in the list
            ParserNode p = new ParserNode(
                ParserNode.S_TER,h.point,h);
            if (this.lex_list == null){
                this.lex_list = p;           // first
            } else {
                this.lex_list.suc.alt = p;   // append
            }
            this.lex_list.suc = p;
            h.tokNum = this.lexseq++;        // assign token number
            h.attr |= attr;                  // copy to dic
            p.attr |= attr;                  // propagate
        }
        if ((FL_X & this.trc) != 0){
            long att = ParserNode.REP | ParserNode.SHO;
            Trc.out.println("linking: " + h.toString(att));
        }
    }

    /** 
     * Determine the resultant storage attributes of the ones passed
     * as argument.
     *
     * @param      def default attributes
     * @param      spc specified attributes
     */

    int storeAttr(int def, int spc){
        int res = spc & (ParserNode.LEX_STR_NOSTORE |
            ParserNode.LEX_STR_STORE |
            ParserNode.LEX_POINT_NOSTORE |
            ParserNode.LEX_POINT_STORE);
        if (((ParserNode.LEX_STR_NOSTORE |
            ParserNode.LEX_STR_STORE) & spc) == 0){     // lex not specified
            res |= def & (ParserNode.LEX_STR_NOSTORE |
                ParserNode.LEX_STR_STORE);
        }
        if (((ParserNode.LEX_POINT_NOSTORE |
            ParserNode.LEX_POINT_STORE) & spc) == 0){
            res |= def & (ParserNode.LEX_POINT_NOSTORE |
                ParserNode.LEX_POINT_STORE);
        }
        return res;
    }

    /** The sequence number of tokens. */
    private int lexseq;

    /**
     * Visit a rule and deliver a copy if it. It can clone also the groups,
     * (which is what is needed for replacements).
     *
     * @param      h reference to the element to clone
     * @param      ru reference to the element whose definition is the rule
     *             to clone
     * @param      deep <code>true</code> to clone the groups
     * @return     reference to the cloned element
     */

    /* It redirects references present in rules from repDic to ntDic.
     * This is easy since replacements never refer to other replacements,
     * but only to origin rules, or shorthands, through the entries of
     * repdic.
     * When cloning rules which contain groups, with "deep" enabled,
     * to determine what nodes are groups it tests the element which is
     * present in the rule, and not the one which it eventually stores
     * in its .def. Node that a node which refers to a shorthand would
     * resemble eventually a group, but does not need to clone the shorthand,
     * which is like an ordinary reference.
     * Cloning rules in "deep" mode occurs when cloning replacements. In
     * such a case, the equivalent rules of groups need be visited and
     * clones as well, otherwise they would refer to the ones in repDic.
     *
     * It removes all the references to dictionary elements which belong
     * to shoDic and repDic. They are due to references to undefined
     * elements. They cannot stay there because all marking, visit,
     * unmarking, etc., algorithms take for granted that all nonterminals
     * are in ntDic.
     */

    private ParserDic cloneRule(ParserDic h, ParserDic ru, boolean deep){
        long att = ParserNode.REP | ParserNode.SHO;
        if ((FL_X & this.trc) != 0){
            Trc.out.println("cloneRule " + h.toString(att) + " rule: " +
                ru.toString(att,att | ParserNode.EXP_GRO) + " " + deep);
        }
        ParserDic hh = null;                         // clone element
        if ((ParserNode.INTER & h.status) != 0){     // internal element
            this.ntDic.append(null,ParserDic.NTER);
            hh = this.ntDic.lastAdded;
            hh.status = h.status;
        } else {                                     // normal one
            this.ntDic.append(Str.EMPTY,h.kind);
            hh = this.ntDic.lastAdded;
            hh.code = h.code;
            hh.status = h.status | ParserNode.APEX;
            hh.status &= ~(ParserNode.MRK | ParserNode.TR |
                ParserNode.ST | ParserNode.EO | ParserNode.EM);
        }
        hh.status &= ~ParserNode.REP;
        hh.attr = h.attr;
        if (!deep){                            // not a replacement rule
            hh.point = h.point;
            hh.line = h.line;
        } else {
            hh.point = ru.point;
            hh.line = ru.line;
        }
        hh.grKind = h.grKind;
        ParserNode p = null;
        ParserNode q = null;
        for (ParserNode a = ru.def; a != null;
            a = a.alt){
            ParserNode r = null;               // initiate alternative
            for (ParserNode s = a; s != null;
                s = s.suc){
                ParserNode c = (ParserNode)
                    (s.clone());               // create a copy
                c.alt = null;
                c.suc = null;
                if (p == null){                // first of the alternatives
                    p = q = r = c;
                } else {
                    if (r == null){            // first of the sequence
                        q.alt = c;
                        q = c;
                    } else {
                        r.suc = c;
                    }
                    r = c;
                }
                if ((FL_X & this.trc) != 0){
                    Trc.out.println("node: " + c.def.toString(att) +
                        whichDic(c.def) + " " +
                        ((ParserNode.SAME & s.status) != 0));
                }
                switch (s.kind){
                case ParserNode.S_NT:
                    // references are redirected to the origin definitions
                    // in ntDic and adjusted later
                    if ((ParserNode.SAME & s.status) != 0){ // <>
                        c.def = this.defnt;
                        if (c.def.kind == ParserDic.TER){
                            c.kind = ParserNode.S_TER;
                        }
                        break;
                    }
                    if ((ParserNode.REP & c.def.status) != 0){
                        if ((FL_X & this.trc) != 0){
                            Trc.out.println("red " + c.toString(att));
                        }
                        c.def = c.def.org;
                        if (c.def == null) break;      // undefined
                        if ((FL_X & this.trc) != 0){
                            Trc.out.println("repl: " + c.def.toString(att));
                        }
                        if ((ParserNode.SHO & c.def.status) != 0){
                            c.def = c.def.org;
                            if (c.def == null) break;  // undefined
                        }
                    }
                    if ((FL_X & this.trc) != 0){
                        Trc.out.println("done: " + c.def.toString(att));
                    }
                    if (!deep) break;                  // do not clone groups
                    if ((ParserNode.INTER &
                        s.def.status) == 0){           // not a group
                        break;
                    }
                    c.def = cloneRule(c.def,c.def,false);
                    if ((ParserNode.G_GRP & s.def.status) ==
                        ParserNode.G_RE0){
                        ParserNode n0rule = c.def.def;
                        if (c.def.grKind == ParserTables.RES){
                            if ((ParserNode.LEFT_RECUR & hh.status) == 0){   // right-recursive
                                ParserDic n1 = n0rule.alt.def;
                                n0rule.alt.def = cloneRule(n1,n1,false);     // clone &1
                                n0rule.alt.suc.def = c.def;                  // adjust &0
                            } else {                                         // left-recursive
                                ParserDic n1 = n0rule.alt.suc.def;
                                n0rule.alt.suc.def = cloneRule(n1,n1,false); // clone &1
                                n0rule.alt.def = c.def;                      // adjust &0
                            }
                        } else {
                            ParserDic n2 = n0rule.def;
                            ParserDic n1;
                            n1 = n2.def.alt.def;
                            n1 = cloneRule(n1,n1,false);              // clone &1
                            n0rule.def = cloneRule(n2,n2,false);      // clone &2
                            n0rule.def.def.alt.def = n1;              // adjust &1 in &2
                            for (ParserNode n = n0rule.suc;
                                n != null; n = n.suc){
                                n.def = n0rule.def;
                            }
                        }
                        break;
                    }
                    if ((ParserNode.G_GRP & s.def.status) ==
                        ParserNode.G_RE1){
                        ParserNode n0rule = c.def.def;
                        ParserDic n1 = null;
                        if ((c.def.grKind == ParserTables.REL) ||
                            (c.def.grKind == ParserTables.REP)){
                            if ((ParserNode.LEFT_RECUR & hh.status) == 0){ // right-recursive
                                n1 = n0rule.alt.def;
                                n1 = cloneRule(n1,n1,false);               // clone &1
                                n0rule.alt.def = n1;                       // adjust &1
                                n0rule.alt.suc.def = c.def;                // adjust &0
                            } else {                                       // left-recursive
                                n1 = n0rule.alt.suc.def;
                                n1 = cloneRule(n1,n1,false);               // clone &1
                                n0rule.alt.suc.def = n1;                   // adjust &1
                                n0rule.alt.def = c.def;                    // adjust &0
                            }
                            for (ParserNode n = n0rule;
                                n != null; n = n.suc){
                                n.def = n1;                           // adjust &1
                            }
                        } else {
                            n1 = n0rule.def;
                            n1 = cloneRule(n1,n1,false);              // clone &1
                            ParserDic n2 = null;
                            ParserDic first = n0rule.def;
                            for (ParserNode n = n0rule;
                                n != null; n = n.suc){
                                if (n.def == first){
                                    n.def = n1;                       // adjust &1
                                } else {
                                    if (n2 == null){
                                        n2 = cloneRule(n.def,n.def,false); // clone &2
                                        n2.def.alt.def = n1;                   // adjust &1
                                    }
                                    n.def = n2;
                                }
                            }
                        }
                        break;
                    }
                    if ((ParserNode.G_GRP & s.def.status) ==
                        ParserNode.G_OPT){
                        ParserNode n0rule = c.def.def;
                        ParserDic n1 = n0rule.def;
                        n1 = cloneRule(n1,n1,false);              // clone &1
                        n0rule.def = n1;
                        break;
                    }
                    break;
                }
            }
        } // l;
        hh.def = p;
        if ((FL_X & this.trc) != 0){
            Trc.out.println("cloneRule cloned: " +
                hh.toString(att,att | ParserNode.EXP_GRO));
        }
        return hh;
    }

    /**
     * Disentangle the grammar and the lexicon.
     */

    /* To clone a forest there is a need to make at least two passes since
     * there can be cyclic references: rules which refer other rules which
     * are not yet cloned. Therefore in the first pass the rules are cloned,
     * in the second the references are adjusted.
     */

    private void disentangle(){
        long att = ParserNode.GRAM | ParserNode.LXS |
            ParserNode.LEXEME | ParserNode.EXP_GRO;
        if ((FL_X & this.trc) != 0){
            Trc.out.println("disentangle");
//            trace_dic(this.ntDic,att,att,Trc.out);
            trace_dic(this.ntDic,att,att);
//            trace_dic(this.terDic,att,att,Trc.out);
            trace_dic(this.terDic,att,att);
        }
        for (ParserDic h = this.ntDic.head; h != null; h = h.suc){
            if ((ParserNode.GRAM & h.status) == 0) continue;
            if ((ParserNode.LXS & h.status) == 0) continue;
            this.defnt = h;
            ParserDic hh = cloneRule(h,h,false);
            h.org = hh;                          // keep it in .org, as
            hh.status &= ~ParserNode.GRAM;       // .. for replacements
        }

        // adjustment of references

        for (ParserDic h = this.ntDic.head; h != null; h = h.suc){
            boolean gram = (ParserNode.GRAM & h.status) != 0;
            for (ParserNode a = h.def; a != null; a = a.alt){
                for (ParserNode s = a; s != null; s = s.suc){
                    ParserDic d = s.def;
                    if (d == null) continue;     // undefined
                    adj: if (!gram){
                        if ((ParserNode.LXS & d.status) == 0){
                            break adj;           // lxs, lexeme
                        }
                        if (d.org == null){      // undefined
                            break adj;
                        }
                        s.def = d.org;
                        if ((FL_X & this.trc) != 0){
                            Trc.out.println("lex: " + h + " " + s
                                + " " + d.org);
                        }
                    } else {
                        if (d.repl == null){     // not lexeme. N.B LEXEME
                            break adj;           // .. is marked on .repl now
                        }
                        s.def = d.repl;
                        if ((FL_X & this.trc) != 0){
                            Trc.out.println("gram: " + h + " " + s
                                 + " " + d.repl);
                        }
                    }
                    s.status &= ~ParserNode.SAME;
                    if ((s.def != null) &&       // redefined terminals now S_NT
                        (s.kind == ParserNode.S_TER) &&
                        (s.def.def != null)){
                        s.kind = ParserNode.S_NT;
                        if ((FL_X & this.trc) != 0){
                            Trc.out.println("nt: " + h + " " + s);
                        }
                    }
                }
            }
        }
        // adjust lxi_list
        for (ParserNode s = this.lxi_list; s != null; s = s.suc){
            ParserDic d = s.def;
            if (d == null) continue;             // undefined
            if (d.repl == null) continue;
            s.def = d.repl;
        }
        for (ParserDic h = this.ntDic.head; h != null; h = h.suc){
            if (h.repl != null){                 // leave attr only on redefined
                h.attr &= ~(ParserNode.LEX_STR_NOSTORE |
                    ParserNode.LEX_STR_STORE |
                    ParserNode.LEX_POINT_NOSTORE |
                    ParserNode.LEX_POINT_STORE);
            }
            if ((ParserNode.GRAM & h.status) == 0) continue;
            if ((ParserNode.LXS & h.status) == 0) continue;
            h.status &= ~(ParserNode.LXS | ParserNode.LEXEME);
        }
        for (ParserDic h = this.terDic.head; h != null; h = h.suc){
            if (h.repl != null){                 // leave attr only on redefined
                h.attr &= ~(ParserNode.LEX_STR_NOSTORE |
                   ParserNode.LEX_STR_STORE |
                   ParserNode.LEX_POINT_NOSTORE |
                   ParserNode.LEX_POINT_STORE);
            }
        }

        if (this.start_sy.repl != null){         // start symbol with replacement
            this.start_sy = this.start_sy.repl;  // adjust it
        }

        if ((FL_X & this.trc) != 0){
            Trc.out.println("disentangle end");
//            trace_dic(this.ntDic,att,att,Trc.out);
            trace_dic(this.ntDic,att,att);
//            trace_dic(this.terDic,att,att,Trc.out);
            trace_dic(this.terDic,att,att);
//            trace_dic(this.shoDic,att,att,Trc.out);
            trace_dic(this.shoDic,att,att);
        }
    }
}
