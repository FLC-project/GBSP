/*
 * @(#)ParserNode.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;
import lbj.HashTbl.*;

/**
 * The <code>ParserNode</code> class provides a representation
 * for a consitituent of a syntax rule.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

/* The internal representation of a grammar is made by a graph of
 * nodes and dictionary entries, in which:
 *
 * - for each production there is a dictionary node that contains a
 *   pointer to the string of the nonterminal and to a graph which is
 *   its right hand side;
 * - an <expression> is represented by a list of nodes linked with an alt
 *   pointer stored in the first node of each sequence
 * - a <range> is represented as two alternatives, the first one marked
 *   as range
 * - a <subexpression> is represented as a sequence with the operator
 *   recorded in the first node of the element immediately following it
 * - a <sequence> is represented by a list of nodes linked with a suc pointer
 * - a <term> is represented by a node with the operator marked on it.
 *   A group is generated when there are several unary operators.
 * - a <factor> is represented by a node with the case clause marked on it.
 * - a <primary> is represented by a node which has a pointer to the dictionary
 *   entry which represents the terminal, nonterminal or group in it.
 * - groups are represented by implicitly introduced rules. This relieves
 *   from the burden of sewing the syb-graph (that has several alternative
 *   leaves and successor leaves) to node that represents the symbol that
 *   is after a group in the rule. E.g. in <A> := {b|c}* d both alternatives
 *   in the group should point to "d".  With this solution, "{b|c}*" is just
 *   a node that has the successor "d", with a unique graph, empty nodes
 *   should be added, which is quite difficult (try it).
 *
 * Nodes are marked with attributes telling if complement, difference,
 * intersection, upto, etc. are present because operators can occur in front
 * of any node.
 *
 * Entries which represent groups are marked with G_xxx.
 * Entries which are introduced implicitly and do not have a (true)
 * name are marked as INTER. The ones which are introduced implicitly
 * and have a true name are marked as APEX.
 * Groups are made by one entry which can be internal or not, and
 * possibly by another one which is internal to them and is not marked
 * as G_xxx.
 *
 * Dictionary entries are stored in hash tables so as to bind applied
 * occurrences in the RHS of rules to defining occurrences.
 */

class ParserNode implements Cloneable {

    /* These are the attributes which are stored in the status field
     * of ParserNode's and ParserDic's objects. Not all of them are
     * actually stored in both. However, they are declared here all
     * together because some are shared, and some others are passed to
     * trace methods of nodes which get them from dictionary entries.
     */

    /** The marked status. */
    static final int MRK = 1 << 0;

    /** Whether it produces a terminal string status. */
    static final int TR = 1 << 1;

    /** Whether it is derivable from the start symbol status. */
    static final int ST = 1 << 2;

    /** Whether it produces the empty string only status. */
    static final int EO = 1 << 3;

    /** Whether it produces the empty string status. */
    static final int EM = 1 << 4;

    /** Whether it is a lexeme status. */
    static final int LEXEME = 1 << 5;

    /** Whether it is a simple group status. */
    static final int G_GRO = 1 << 6;

    /** Whether it is an optional group. */
    static final int G_OPT = 1 << 7;

    /** Whether it is a group repeated 0..inf times status. */
    static final int G_RE0 = (1 << 6) | (1 << 7);

    /** Whether it is a group repeated 1..inf times status. */
    static final int G_RE1 = 1 << 8;

    /** Whether it is a group. */
    static final int G_GRP = (1 << 6) | (1 << 7) | (1 << 8);

    /** Attributes specific for ParserDic. */

    /** Whether it is a shorthand entry status. */
    static final int SHO = 1 << 10;

    /** Whether it is a replacement entry. */
    static final int REP = 1 << 11;

    /** Whether it is declared in LEXIS status. */
    static final int LXS = 1 << 12;

    /** Whether it belongs to the grammar (and not to the lexis) status. */
    static final int GRAM = 1 << 13;

    /** Whether it is autoinclusive status. */
    static final int AIN = 1 << 14;

    /** Whether it is cyclic status. */
    static final int CYC = 1 << 15;

    /** Whether it refers to itself in its rule status. */
    static final int SAME = 1 << 16;

    /** Whether it produces x <S> status. */
    static final int LEF = 1 << 17;

    /** Whether it produces <S> x status. */
    static final int RIG = 1 << 18;

    /** Whether it is type-2 element status. */
    static final int TY2 = 1 << 19;

    /** Whether it is a finite type-3 element status. */
    static final int TY3F = 1 << 20;

    /** Whether it is an entry with an internal name status. */
    static final int INTER = 1 << 21;

    /** Whether it is an entry with an apex name status. */
    static final int APEX = 1 << 22;

    /** Attributes peculiar for PerserNode. */

    /** Whether it is ASCII case insensitive. */
    static final int CASEINSENS = 1 << 23;

    /** Whether it is full case insensitive. */
    static final int CASEINSENS_FULL = 1 << 24;

    /** Attributes which represent trace modes. */

    /** The representation of the node only mode. */
    static final int REP_NODE = 1 << 26;

    /** The representation of the alternative only mode. */
    static final int REP_ALT = 1 << 27;

    /** The representation of the whole rule only mode. */
    static final int REP_RULE = 1 << 28;

    /** The expanded groups mode. */
    static final int EXP_GRO = 1 << 29;

    /** Group represented with left-recursive rule (instead of right-recursive). */
    static final int LEFT_RECUR = 1 << 30;

    /** Attributes which are inherited from ParserDic in tracing. */
    static final int COMMON = 0xffff;

    /** Attributes which are perculiar for alternatives. */
    static final int ALTERN = TR;

    /** The status. */
    int status;

    /** Whether it is LL(1) element. */
    static final int LL1 = 1 << 0;

    /** Whether it requires lexeme string storing. */
    static final int LEX_STR_STORE = 1 << 1;

    /** Whether it requires lexeme string non-storing. */
    static final int LEX_STR_NOSTORE = 1 << 2;

    /** Whether it requires lexeme point storing. */
    static final int LEX_POINT_STORE = 1 << 3;

    /** Whether it requires lexeme point storing. */
    static final int LEX_POINT_NOSTORE = 1 << 4;

    /** Whether it is a literal token. */
    static final int LIT_TOK = 1 << 5;

    /** Whether it has chain rules. */
//    static final int CHAIN = 1 << 6;

    /** Whether it denotes a token to be ignored. */
    static final int LEX_IGNORE = 1 << 7;

    /** The attributes. */
    int attr;

    /** The reference to the successor node. */
    ParserNode suc;

    /** The reference to the alternative node. */
    ParserNode alt;

    /** The kind of the node. */
    int kind;

    /** Terminal symbol kind. */
    static final int S_TER = 0;

    /** Non-terminal symbol kind. */
    static final int S_NT = 1;

    /** The constraint-not kind. */
    static final int C_NOT = 7;

    /** The constraint-equal kind. */
    static final int C_EQU = 8;

    /** The constraint-different kind. */
    static final int C_DIFF = 9;

    /** The constraint-succ kind. */
//????
    static final int C_SUCC = 10;

    /** The constraint-term kind. */
    static final int C_TERM = 11;

    /** The operator(s) in front of the node. */
    byte oper;

    /** Complement. */
    static final int S_COMPL = 1 << 0;

    /** Language complement. */
    static final int S_COMCL = 1 << 1;

    /** Difference. */
    static final int S_DIFF = 1 << 2;

    /** Intersection. */
    static final int S_AND = 1 << 3;

    /** Upto. */
    static final int S_UPTO = 1 << 4;

    /** Range. */
    static final int S_RNG = 1 << 5;

    /** The reference to the dictionary entry. */
    ParserDic def;

    /** The reference to the expression, if group. */
// then remove it: at the moment it seems used in constraints only
    ParserNode gnode;

    /** The list of constraints. */
    ParserNode constr;

    /** The position in the source. */
    long point;

    /** The priority of the alternative. */
    char prio;

    /**
     * Construct a new node. It initializes it to the empty symbol.
     *
     * @param      k kind of node
     */

    ParserNode(int k){
        this.kind = k;
    }

    /**
     * Construct a new node with a given kind, position and definition.
     *
     * @param      kind kind of node
     * @param      pos position of the node
     * @param      def definition
     */

    ParserNode (int kind, long pos, ParserDic def){
        this.kind = kind;
        this.point = pos;
        this.def = def;
    }


    /**
     * Clone this object.
     *
     * @return     a copy of the object
     */

    public Object clone(){
        ParserNode t = null;
        try {
            t = (ParserNode)super.clone();
        } catch (CloneNotSupportedException e){
        }
        return t;
    }

    /**
     * Allocate a constraint descriptor, initialize it and append
     * it to the constraint list of this object.
     *
     * @param      k kind of node
     * @param      n reference to the definition of the costraint
     * @param      pos position in the text
     */

    void add_constr(int k, ParserNode n, long pos){
        ParserNode p, pr, cu;
        p = new ParserNode(k);
        p.gnode = n;
        p.point = pos;
        pr = null;
        for (cu = this.constr; cu != null; cu = cu.suc){ // append
            pr = cu;
        }
        if (pr == null){                        // first element
            this.constr = p;
        } else {
            pr.suc = p;
        }
    }

    /**
     * Traverse the syntax graph and print an equivalent BNF
     * representation of this expression.
     */

    void trace_exp(){
        Str st = new Str();
        toString(st,REP_RULE);
        Trc.out.print(st);
    }

    /**
     * Deliver a string representation of this node or of this
     * node and its expression.
     *
     * @param   mode kind of representation
     * @return  string
     */

    String toString(long mode){
        Str st = new Str();
        toString(st,mode);
        return st.toString();
    }

    /**
     * Deliver a string representation of this node or of this node
     * and its expression. If some attributes are specified, it
     * inserts a mark on all nodes which have them and disregards
     * the mode parameter.
     *
     * @param   st string in which the representation is returned
     * @param   att selection of indications and attributes to be shown:
     *          status in lower word, attr in higher
     * @return  string
     */

    /* It decorates the nodes with the attributes inherited from the
     * dictionary entries which define nodes. This is useful in tracing
     * of algorithms to show how they proceed, and also in testing to
     * verify the attributes at the end.
     */

    void toString(Str st, long att){
        ParserNode a, s;
        boolean sp;
        boolean cl;
        char cc = ' ';
        int attg = REP_RULE;                 // mode for groups
        attg |= att & ~(REP_NODE | REP_ALT);
        boolean first = true;
                                             // scan all alternatives
        ParserNode prev = null;
        for (a = this; a != null; a = a.alt){
            if (!first){
                if ((S_RNG & prev.oper) != 0){
                    st.append(" |..| ");
                } else {
                    st.append(" | ");
                }
            }
            first = false;
            sp = false;
            cl = false;
            int altprio = 0;
            for (s = a; s != null; s = s.suc){  // scan all successors
                if (sp) st.append(' ');

                decorate(st,att,s.status & ALTERN); // the altern ones

//if ((SHO & s.def.status) != 0){
//st.append("s/");
//}
//if ((REP & s.def.status) != 0){
//st.append("r/");
//}

                if (s.prio > 0){
                    if (s == a){
                        altprio = s.prio;
                    } else {
                        st.append("(prio) ");
                    }
                }

                int kind = s.kind;
                if ((S_COMPL & s.oper) != 0){        // set complement
                    st.append("^");
                } else if ((S_COMCL & s.oper) != 0){ // complement
                    st.append("!");
                } else if ((S_UPTO & s.oper) != 0){  // upto
                    st.append("~");
                }
                el: switch (kind){
                case S_TER:
//                      if (cl) st.append(' ');
                    if (s.def != null){
                        s.def.toString(st);
                    }
                    break;
                case S_NT:
                    if (s.def == null) break;    // undefined
                    if ((EXP_GRO & att) == 0){
                        ParserNode body = s.def.body();
                        switch (G_GRP & s.def.status){
                        case G_GRO:
                            st.append('{');
                            body.toString(st,attg);
                            st.append('}');
                            break el;
                        case G_OPT:
                            st.append('[');
                            done: {
                                if ((body != null) &&
                                    (body.suc == null) &&
                                    (body.alt == null) &&
                                    (body.def.code.length == 0)){
                                    break done;       // []
                                }
                                body.toString(st,attg);
                            }
                            st.append(']');
                            break el;
                        case G_RE0:
                            st.append('{');
                            body.toString(st,attg);
                            if (s.def.grKind == ParserTables.RES){
                                st.append("}*");
                            } else {
                                st.append("}(:");
                                st.append(Integer.toString(s.def.hiBound()));
                                st.append(")");
                            }
                            break el;
                        case G_RE1:
                            st.append('{');
                            body.toString(st,attg);
                            if (s.def.grKind == ParserTables.REP){
                                st.append("}+");
                            } else if (s.def.grKind == ParserTables.REL){
                                st.append("}(");
                                st.append(Integer.toString(s.def.loBound()));
                                st.append(":)");
                            } else {
                                st.append("}(");
                                int lo = s.def.loBound();
                                int hi = s.def.hiBound();
                                st.append(Integer.toString(lo));
                                if (hi != lo){
                                    st.append(":");
                                    st.append(Integer.toString(hi));
                                }
                                st.append(")");
                            }
                            break el;
                        }
                    }
                    if ((SAME & s.status) != 0){   // <>
                        st.append("<>");
                    } else {
                        if (s.def != null){
                            s.def.toString(st);
                        }
                    }
                    break;
                default:
                    st.append('{');
                    s.gnode.toString(st,attg);
                }
                sp = false;
                switch (kind){
                case S_TER:
                case S_NT: sp = true; break;        // a nt has been printed
                }
                storeToString(st,s.attr);
                /*
                if (s.def != null &&
                    ((LEX_STR_STORE | LEX_POINT_STORE) & s.def.attr) != 0){
                    st.append("->");
                    storeToString(st,s.def.attr);
                }
                */
                if ((CASEINSENS & s.status) != 0){  // (i)
                    st.append("(i)");
                }

/*
                ParserNode csp;
                for (csp = s.constr; csp != null; csp = csp.suc){
                    switch (csp.kind){
                    case C_NOT: cc = '~'; break;
                    case C_EQU: cc = '='; break;
                    case C_DIFF: cc = '-'; break;
                    case C_SUCC: cc = ':'; break;
                    case C_TERM: cc = '#'; break;
                    }
                    st.append(' ');
                    st.append(cc);
                    st.append('{');
                    if ((csp.gnode.alt == null) &&
                        (csp.gnode.suc == null) &&
                        ((csp.gnode.kind == S_RE0) ||
                            (csp.gnode.kind == S_RE1))){
                        csp.gnode.gnode.toString(st,attg);
                        if (csp.gnode.kind == S_RE0){
                            st.append("}*");
                        } else {
                            st.append("}+");
                        }
                    } else {
                        csp.gnode.toString(st,attg);
                        st.append('}');
                    }
                    cl = true;
                }
*/
                if (att != 0){
                    int u = s.status & ~ALTERN;     // all but the altern ones
                    u &= ~COMMON;                   // inherit the common ones
                    if (s.def != null){
                        u |= s.def.status & COMMON;
                    }
                    decorate(st,att,u | ((long)s.attr << 32));
                }
                if ((S_DIFF & s.oper) != 0){       // difference
                    st.append(" -");
                } else if ((S_AND & s.oper) != 0){ // intersection
                    st.append(" &");
                }
                if ((REP_NODE & att) != 0) return;
            }
            if (altprio > 0){
                st.append(" (prio:" + Integer.toString(altprio) + ")");
            }
            if ((REP_ALT & att) != 0) return;
            prev = a;
        }
    }

    /**
     * Store in the specified string a representation of the lexeme
     * store directive.
     *
     * @parm    st string
     * @parm    att attribute mask
     */

    static void storeToString(Str st, int att){
        if (((LEX_STR_NOSTORE | LEX_STR_STORE |
            LEX_POINT_NOSTORE | LEX_POINT_STORE | LEX_IGNORE) & att) != 0){
            st.append('(');
            int startln = st.length;
            if ((LEX_STR_NOSTORE & att) != 0){ 
                st.append("-lex");
            }
            if ((LEX_STR_STORE & att) != 0){ 
                if (st.length > startln) st.append(',');
                st.append("lex");
            }
            if ((LEX_POINT_NOSTORE & att) != 0){ 
                if (st.length > startln) st.append(',');
                st.append("-point");
            }
            if ((LEX_POINT_STORE & att) != 0){ 
                if (st.length > startln) st.append(',');
                st.append("point");
            }
            if ((LEX_IGNORE & att) != 0){ 
                if (st.length > startln) st.append(',');
                st.append("ignore");
            }
            st.append(')');
        }
    }

    /**
     * Append superscripts to a string representing the attributes.
     * The attributes are compared against a mask: the ones which are
     * present in both are shown as a superscript which represents
     * the ordinal number of the attribute in the mask;
     *
     * @parm    st string
     * @parm    att attribute mask
     * @parm    u attributes
     */

    private static void decorate(Str st, long att, long u){
        att &= ~(REP_NODE | REP_ALT | REP_RULE | EXP_GRO | (1L << 31));
        if ((att & u) == 0) return;
        int n = 0;
        for (long m = att; m != 0; m = m>>>1){
            if ((m & 1) != 0){
                if ((u & 1) != 0){
                    char f =
                        "\u00b9\u00b2\u00b3\u00ba\u00aa\u00b0*".
                        charAt(n);
                    st.append(f);
                }
                if (n < 5) n++;
            }
            u = u>>>1;
        }
    }

    /**
     * Deliver a string representation of this node.
     *
     * @return  string
     */

    public String toString(){
        Str st = new Str();
        toString(st,REP_NODE);
        return st.toString();
    }

    /**
     * Trace this object.
     */

    void trcNode(){
        Trc.out.print("node: " + toString());
        Trc.out.print("  alt: " + this.alt);
        Trc.out.print("  suc: " + this.suc);
        Trc.out.println();
    }

    /**
     * Trace the references present in this object.
     */

    void trace(){
        Trc.out.println(".......");
        Trc.out.println("node:  " + System.identityHashCode(this));
        Trc.out.println("suc:   " + System.identityHashCode(this.suc));
        Trc.out.println("alt:   " + System.identityHashCode(this.alt));
        Trc.out.println("kind:  " + this.kind);
        Trc.out.println("status: " + Integer.toHexString(this.status));
        switch (this.kind){
        case S_TER:
            Trc.out.println("def:  " +
                System.identityHashCode(this.def) + " " + this.def);
            break;
        case S_NT:
            Trc.out.println("def:  " +
                System.identityHashCode(this.def) + " " + this.def);
            Trc.out.println("same:  " +
               ((SAME & this.status) != 0));
            break;
//        case S_GRO: case S_OPT: case S_RE0: case S_RE1:
//            if (this.gnode == null){
//                Trc.out.println("gnode: null");
//            } else {
//                Trc.out.println("gnode: " +
//                   System.identityHashCode(gnode));
//            }
//            break;
        }
        ParserNode csp;
        for (csp = this.constr; csp != null; csp = csp.suc){
            Trc.out.println(csp.kind + ":   " +
                System.identityHashCode(csp.gnode));
        }
        Trc.out.println("point: " + this.point);
        Trc.out.println("lex:   " + ((LEXEME & this.status) != 0));
    }

    /**
     * Trace the rule of this object.
     */

    void trace_rule(){
        ParserNode a, s;
        a = this;                      // scan all alternatives
        while (a != null){
            s = a;                     // scan all successors
            a = a.alt;
            while (s != null){
                s.trace();
                ParserNode csp;
                for (csp = s.constr; csp != null; csp = csp.suc){
                    csp.gnode.trace_rule();
                }
                s = s.suc;
            }
        }
    }

    /** 
     * Remove the marks in the nodes of this rule.
     */

    void unmark(){
        for (ParserNode a = this; a != null; a = a.alt){
            for (ParserNode s = a; s != null; s = s.suc){
                s.status &= ~MRK;
//                switch (s.kind){
//                case S_GRO: case S_OPT: case S_RE0: case S_RE1:
//                    s.gnode.unmark();
//                    break;
//                }
                for (ParserNode csp = s.constr;
                    csp != null; csp = csp.suc){
                    csp.gnode.unmark();
                }
            }
        }
    }

    /** 
     * Compare this alternative with a given one.
     *
     * @param   d alternative to be compared to
     * @return  <code>true</code> if they are equal
     */

    /* Case insensitiveness, priority and storage are not taken into account
     * since what matters here is that the alternatives define the same
     * language (which is difficult to tell with case insensitiveness.
     */

    boolean equalAlt(ParserNode d){
        ParserNode s = this;
        int msk = ParserNode.G_GRP;
        l: do {
            if (s.kind != d.kind) return false;
            if (s.oper != d.oper) return false;
            switch (s.kind){
            case S_TER:
            case S_NT:
                if ((s.def != null) && (d.def != null)){
                    if ((s.def.status & msk) != (d.def.status & msk)){
                        return false;
                    }
                    if ((s.def.status & msk) != 0){     // group
                        if (!s.def.body().equalRule(d.def.body())){
                            return false;
                        }
                        break;
                    }
                }
                if (s.def != d.def) return false;
                if ((ParserNode.S_RNG & s.oper) != 0){
                    s = s.alt;
                    d = d.alt;
                    if (s.kind != d.kind) return false;
                    if (s.oper != d.oper) return false;
                    if ((s.def != null) && (d.def != null)){
                        if ((s.def.status & msk) != (d.def.status & msk)){
                            return false;
                        }
                        if ((s.def.status & msk) != 0){     // group
                            if (!s.def.body().equalRule(d.def.body())){
                                return false;
                            }
                            break;
                        }
                    }
                    if (s.def != d.def) return false;
                    return true;
                }
                break;
            }
            d = d.suc;
            s = s.suc;
            if (d == null) break;
        } while ((s != null) && (d != null));
        return s == d;
    }

    /** 
     * Compare this rule with a given one.
     *
     * @param   d rule to be compared to
     * @return  <code>true</code> if they are equal
     */

    boolean equalRule(ParserNode d){
        ParserNode s = this;
        do {
            if (!s.equalAlt(d)) return false;
            if ((ParserNode.S_RNG & s.oper) != 0){
                s = s.alt;
            }
            if ((ParserNode.S_RNG & d.oper) != 0){
                d = d.alt;
            }
            d = d.alt;
            s = s.alt;
            if (d == null) break;
        } while ((s != null) && (d != null));
        return s == d;
    }

    /**
     * The <code>ParserDic/code> class provides a representation
     * for a dictionary entry for syntax symbols.
     */

    /* This class is kept in this file because it and ParserNode reference
     * each other. Keeping it in a separate file prevents for having a
     * clear compilation ordering.
     */

    static class ParserDic extends HashChars {

        /** The reference to the next element. */
        ParserDic suc;

        /** The position of its definition in the source. */
        long point;

        /** The line at which it is defined. */
        long line;

        /** The pointer to its definition. */
        ParserNode def;

        /** The pointer to the origin entry. */
        ParserDic org;

        /** The pointer to the replacement. */
        ParserDic repl;

        /** The kind of entry. */
        int kind;

        /** Nonterminal entry. */
        static final int NTER = 0;

        /** Terminal entry. */
        static final int TER = 1;

        /** Terminal special entry. */
        static final int TER_SPE = 2;

        /** The status. */
        int status;

        /** The attributes. */
        int attr;

        /** The detailed kind of group (see ParserTables). */
        byte grKind;

        /** The number of usages except <>. */
        int use;

        /** The token number. */
        int tokNum;

        /** The nonterminal sequence number. */
        int ntNum;

        /**
         * Construct a new dictionary entry.
         *
         * @param   k kind of entry
         * @param   s string of its name
         */

        ParserDic(int k, Str s){
            if (s == Str.EMPTY){
            this.code = Str.EMPTY_CHARS;
            } else {
                this.code = new char[s.length];
                System.arraycopy(s.buffer,0,this.code,0,s.length);
            }
            this.kind = k;
            this.org = this;             // by default, it is itself
            if (k != NTER){              // terminal
                this.status |= ParserNode.TR;
                if (s.length == 0){
                    this.status |= ParserNode.EM | EO;
                }
            }
        }

        /**
         * Determine if this object is equal to the specified Object.
         *
         * @param   other the object to compare
         * @return  true if equal
         */

        public boolean equals(Object other){
            if (this == other) return true;
            boolean eqk = this.kind == ((ParserDic)other).kind;
            return eqk && super.equals((HashChars)other);
        }

        /**
         * Compares lexicographically this object with the specified object.
         *
         * @param   other the object to compare
         * @return  &lt; = or &gt; 0 if this object precedes, is equal or
         *          follows the other.
         */

        public int compareTo(Object other){
            if (other == null) return 1;
            int cmp = this.kind - ((ParserDic)other).kind;
            if (cmp != 0) return cmp;
            else return super.compareTo(other);
        }

        /**
         * Deliver a string representation of this object.
         *
         * @return  string
         */

        public String toString(){
            Str st = new Str();
            toString(st);
            return st.toString();
        }

        /**
         * Deliver a string representation of this object.
         *
         * @param   st string in which it is appended
         */

        /* A terminal name which starts with "<" needs to be quoted since
         * it would otherwise be taken to be a nonterminal, and a name which
         * starts with a meta, key, etc, need also be quoted because
         * outherwise it would be parsed as meta, key, etc. followed by
         * something.
         * Moreover, terminals which contains spaces, newlines, etc. need
         * be quoted.
         */

        void toString(Str st){
            char[] name = this.code;
            boolean quote = true;
            switch (this.kind){
            case TER:
                int len = name.length;
                quo: if (len > 0){
                    if (name[0] == '<'){
                        break quo;
                    }
                    String str = String.valueOf(name);
                    String[] tab = ParserLexer.TERTABLE;
                    for (int i = 0; i < tab.length; i++){
                        if (str.startsWith(tab[i])) break quo;
                    }
                    tab = ParserLexer.KEYTABLE;
                    for (int i = 0; i < tab.length; i++){
                        if (str.startsWith(tab[i])) break quo;
                    }
                    tab = ParserLexer.METATABLE;
                    for (int i = 0; i < tab.length; i++){
                        if (str.startsWith(tab[i])) break quo;
                    }
                    quote = false;
                }
                appendLit(st,name,quote);
                break;
            case TER_SPE:
                st.append(name);
                break;
            case NTER: 
                quote = false;
                for (int i = 0; i < name.length; i++){
                    switch (name[i]){
                    case '(': case '>': case '\"':
                    case '\b': case '\n': case '\t':
                    case '\r': case '\f':
                        quote = true;
                    }
                }
                char opn = '<';
                char clo = '>';
                if ((INTER & this.status) != 0){
                    opn = '\u00ab';       // left double angle
                    clo = '\u00bb';       // right double angle
                }
                st.append(opn);
                if (quote) appendLit(st,name,quote);
                else st.append(name);
                st.append(clo);
                break;
            }
            if ((APEX & this.status) != 0){
                st.append('\'');
            }
        }

        /**
         * Literalize a name. Empty names, names which end in apex,
         * or that contain characters which are not allowed in a non-meta
         * symbol are literalized.
         *
         * @param   st string in which it is appended
         * @param   n name
         * @param   force <code>true</code> to force literalization anyway
         */

        private void appendLit(Str st, char[] n, boolean force){
            doit: if (n.length > 0){
                if ((n[n.length-1] == '\'') || force){
                    Str.strQuoted(n,0,n.length,st);
                    break doit;
                }
                for (int i = 0; i < n.length; i++){
                    char c = n[i];
                    if (c == '!') continue;           // all printables except "
                    if ((c < '#') || ('~' < c)){      // non allowed range
                        Str.strQuoted(n,0,n.length,st);
                        break doit;
                    }
                }
                st.append(n);
            } else {
                st.append("\"\"");
            }
        }

        /**
         * Deliver a string representation of this object with a mark
         * if it has the specified attribute.
         *
         * @param   st string
         * @param   att attribute
         */

        void toString(Str st, long att){
            toString(st);
//            if ((att & this.status) != 0){
                decorate(st,att,this.status | ((long)this.attr << 32));
//            }
        }

        /**
         * Deliver a string representation of this object with a mark
         * if it has the specified attribute.
         *
         * @param   att attribute
         * @return  string
         */

        String toString(long att){
            Str st = new Str();
            toString(st,att);
            return st.toString();
        }

        /**
         * Deliver a string representation of this object and its rule with
         * marks for the specified attributes.
         *
         * @param   attd attribute mask for the entry
         * @param   attn attribute mask for the rule
         * @return  string
         */

        String toString(long attd, long attn){
            Str st = new Str();
            toString(st,attd);
            st.append(" ");
            String del = "::=";
            if ((SHO & this.status) != 0){
                del = "==";
            } else if ((REP & this.status) != 0){
                del = "=>";
            }
            st.append(del);
            st.append(" ");
            if (this.def != null){
                this.def.toString(st,ParserNode.REP_RULE | attn);
            }
            return st.toString();
        }

        /**
         * Trace this object.
         */

        void trace(){
            Trc.out.println(System.identityHashCode(this));
            Trc.out.println("name   " + toString());
            String kin = "";
            switch (this.kind){
            case NTER: kin = "non-terminal"; break;
            case TER: kin = "terminal"; break;
            case TER_SPE: kin = "special"; break;
            }            
            Trc.out.println("kind   " + kin);
            Trc.out.println("suc    " + this.suc);
            Trc.out.println("lex    " + ((ParserNode.LEXEME & this.status) != 0));
            Trc.out.println("point  " + this.point);
            Trc.out.println("line   " + this.line);
            Trc.out.print("def    ");
            if (this.def == null){
                Trc.out.println("null");
            } else {
                this.def.trace_exp();
                Trc.out.println();
            }
            Trc.out.print("org    ");
            if ((this.org != null) && (this.org.def != null)){
                this.org.def.trace_exp();
                Trc.out.println();
            } else {
                Trc.out.println("null");
            }
            Trc.out.print("repl   ");
            if ((this.repl != null) && (this.repl.def != null)){
                this.repl.def.trace_exp();
                Trc.out.println();
            } else {
                Trc.out.println("null");
            }
// perhaps better have a common method
            Trc.out.println("mrk    " + ((ParserNode.MRK & this.status) != 0));
            Trc.out.println("st     " + ((ParserNode.ST & this.status) != 0));
            Trc.out.println("tr     " + ((ParserNode.TR & this.status) != 0));
            Trc.out.println("em     " + ((ParserNode.EM & this.status) != 0));
            Trc.out.println("eo     " + ((ParserNode.EO & this.status) != 0));
            Trc.out.println("lxs    " + ((LXS & this.status) != 0));
            Trc.out.println("same   " + ((SAME & this.status) != 0));
            Trc.out.println("lef    " + ((LEF & this.status) != 0));
            Trc.out.println("rig    " + ((RIG & this.status) != 0));
            Trc.out.println("ain    " + ((AIN & this.status) != 0));
            Trc.out.println("cyc    " + ((CYC & this.status) != 0));
            Trc.out.println("ty2    " + ((TY2 & this.status) != 0));
            Trc.out.println("gram   " + ((GRAM & this.status) != 0));
            Trc.out.println("inter  " + ((INTER & this.status) != 0));

            Trc.out.println("ll1    " + ((LL1 & this.attr) != 0));
//            Trc.out.println("chain  " + ((CHAIN & this.attr) != 0));
            Trc.out.println("use    " + this.use);
            Trc.out.println("tokNum " + this.tokNum);
//            Trc.out.println("lptr   " + this.lptr);
//                Trc.out.println("stini  " + this.stini);
//                Trc.out.println("stfin  " + this.stfin);
            Str lexpoint = new Str();
            storeToString(lexpoint,this.attr);
            Trc.out.println("lex/point  " + lexpoint.toString());
            if (this.def != null) this.def.trace_rule();
            Trc.out.println("--------");
        }

        /**
         * Deliver a reference to the body of this element, which represents
         * a group.
         *
         * @return     reference
         */

        ParserNode body(){
            switch (G_GRP & this.status){
            case G_GRO:
                return this.def;
            case G_OPT:
                return this.def.def.def;
            case G_RE0:
                if (this.grKind == ParserTables.REU){
                    return this.def.def.def.alt.def.def;
                } else {
                    if ((LEFT_RECUR & this.status) == 0){   // right-recursive
                        return this.def.alt.def.def;
                    } else {                                // left-recursive
                        return this.def.alt.suc.def.def;
                    }
                }
            case G_RE1:
                if ((this.grKind == ParserTables.RER) ||
                    (this.grKind == ParserTables.REF)){
                    return this.def.def.def;
                } else {
                    if ((LEFT_RECUR & this.status) == 0){   // right-recursive
                        return this.def.alt.def.def;
                    } else {                                // left-recursive
                        return this.def.alt.suc.def.def;
                    }
                }
            }
            return null;           
        }

        /**
         * Deliver a reference to the dictionary node of the body of this
         * element, which represents a group.
         *
         * @return     reference
         */

        ParserDic dicBody(){
            switch (G_GRP & this.status){
            case G_GRO:
                return this;
            case G_OPT:
                return this.def.def;
            case G_RE0:
                if (this.grKind == ParserTables.REU){
                    return this.def.def.def.alt.def;
                } else {
                    return this.def.alt.def;
                }
            case G_RE1:
                if ((this.grKind == ParserTables.RER) ||
                    (this.grKind == ParserTables.REF)){
                    return this.def.def;
                } else {
                    return this.def.alt.def;
                }
            }
            return null;           
        }

        /**
         * Deliver the lower bound of this dictionary node, if group.
         *
         * @parm    s reference to the node
         * @return  lower bound, -1 if undefined
         */

        int loBound(){
            int lo = -1;
            switch (G_GRP & this.status){
            case G_GRO:
                lo = 1;
                break;
            case G_OPT:
                lo = 0;
                break;
            case G_RE0:
                lo = 0;
                break;
            case G_RE1:
                if (this.grKind == ParserTables.REP){
                    lo = 1;
                } else if (this.grKind == ParserTables.REL){
                    lo = 0;
                    for (ParserNode n = this.def;
                        n != null; n = n.suc){
                        lo++;
                    }
                } else {
                    lo = 0;
                    for (ParserNode n = this.def;
                        n != null; n = n.suc){
                        if (n.def == this.def.def){
                            lo++;
                        } else {
                            break;
                        }
                    }
                }
                break;
            }
            return lo;
        }

        /**
         * Deliver the upper bound of this dictionary node, if group.
         *
         * @parm    s reference to the node
         * @return  upper bound, -1 if undefined
         */

        int hiBound(){
            int hi = -1;
            switch (G_GRP & this.status){
            case G_GRO:
                hi = 1;
                break;
            case G_OPT:
                hi = 1;
                break;
            case G_RE0:
                if (this.grKind == ParserTables.RES){
                    break;
                } else {
                    hi = 0;
                    for (ParserNode n = this.def;
                        n != null; n = n.suc){
                        hi++;
                    }
                }
                break;
            case G_RE1:
                if ((this.grKind == ParserTables.RER) ||
                    (this.grKind == ParserTables.REF)){
                    int lo = 0;
                    hi = 0;
                    for (ParserNode n = this.def;
                        n != null; n = n.suc){
                        if (n.def == this.def.def){
                            lo++;
                        } else {
                            hi++;
                        }
                    }
                    hi += lo;
                }
                break;
            }
            return hi;
        }
    }
}
