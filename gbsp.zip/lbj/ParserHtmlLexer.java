/*
 * @(#)ParserHtmlLexer.java       1.0 2004/03/04
 *
 * Copyright (c) 2003-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import lbj.Trc;
import lbj.Str;
import lbj.LexerStream;
import lbj.BufReader;
import lbj.Listing;
import lbj.Listing.*;
import lbj.HashTbl;
import lbj.HashTbl.*;

/**
 * The <code>ParserHtmlLexer</code> class provides the lexer library for the
 * html language.
 *
 * @author  Angelo Borsotti
 * @version 1.0 4 March 2004
 */

class ParserHtmlLexer extends LexerStream {

    /** The number of the current line. */
    public long lineNr;

    /** 
     * Construct a lexer object.
     *
     * @param      inp input stream
     */

    ParserHtmlLexer(Object inp){
        if (inp != null){
            this.stream = new BufReader(inp,2048);
        }
        this.mode |= SKIPWS | EXACT;
        this.lineNr = 1;
    }

    /** 
     * Construct a lexer object.
     *
     * @param      stream input stream
     */

    ParserHtmlLexer(BufReader stream){
        this.stream = stream;
        this.mode |= SKIPWS | EXACT;
        this.lineNr = 1;
    }

    /**
     * Trace a snapshot of the text which has not yet been scanned,
     * with the indication of the point.
     *
     * @param      s comment string
     */

    void trcBuffer(String s){
        Trc.out.println(s + ':');
        int len = this.end - this.cursor;
        if (len > 128) len = 128;
        Trc.out.println(this.lineNr + " " + "\u00a4" +
            String.valueOf(this.buffer,this.cursor,len));
    }

    /**
     * Deliver the position (index) in the source at which the last token
     * scanned starts. If it was recognized, it is its starting point,
     * it it was not recognized, it is the point at which recognizion
     * started.
     *
     * @return     absolute position
     */

    long getPoint(){
        return getPoint(this.start);
    }

    /**
     * Deliver the current position (index) in the source.
     *
     * @return     absolute position
     */

    long index(){
        return getPoint(this.cursor);
    }

    /**
     * Deliver the line of the position (index) in the source at which the
     * last token scanned starts, as delivered by <code>getPoint()</code>.
     *
     * @return     absolute position
     */

    long getLineNr(){
        return this.lineNr;
    }

    /**
     * Test if the input is at the end, skipping separators if any.
     *
     * @return     <code>true</code> if at eof
     */

    boolean eof(){
        gsep();
        if (this.cursor < this.end){
            return false;
        }
        return this.stream.eof();
    }

    /** 
     * Skip all separator spaces, including newlines. Make the lexer refer to
     * the first non separator character. Upon return, <code>cursor</code>
     * indicates the first non separator character.
     */

    public void gsep(){
        if ((FL_V & this.trc) != 0){
            trace("gsep start");
        }

        if ((SKIPWS & this.mode) == 0){
            this.start = this.cursor;
            return;
        }
        this.stream.markPos = this.cursor;
        char[] buffer = this.buffer;
        int cursor = this.cursor - 1;
        int end = this.end;

        int state = 0;
        char prev = 0;
        loop: do {
            if (++cursor == end){               // no data
                int ch = fill();
                if (ch < 0){
                    if (state == 1) cursor--;   // single slash at end
                    break loop;
                }
                end = this.end;
                buffer = this.buffer;
                cursor = this.cursor;
            }
            char c = buffer[cursor];
            switch (state){
            case 0:                             // normal
                switch (c){
                case '<':
                    state = 1;
                    break;
                case ' ': case '\t':
                    break;
                case '\r': case '\n': case '\f':
                    break;
                default:
                    state = -1;
                    break loop;
                }
                break;
            case 1:                             // < found
                switch (c){
                case '!':
                    state = 2;                  // comment
                    break;
                default:
                    cursor--;
                    state = -1;
                    break loop;
                }
                break;
            case 2:                             // <! found
                switch (c){
                case '-':
                    state = 3;
                    break;
                default:
                    state = 7;                  // comment <! ...
                }
                break;
            case 3:                             // <!- found
                switch (c){
                case '-':
                    state = 4;                  // comment <!--
                    break;
                }
                break;
            case 4:                             // <!-- found
                switch (c){
                case '-':
                    state = 5;                  // comment <!-- ... -
                    break;
                }
                break;
            case 5:                             // <!-- ... - found
                switch (c){
                case '-':
                    state = 6;                  // comment <!-- ... --
                    break;
                default:
                    state = 4;                  // back to comment
                }
                break;
            case 6:                             // <!-- ... -- found
                switch (c){
                case '>':
                    state = 0;                  // end of comment
                    break;
                case '-':
                    state = 6;                  // comment <!-- ... --
                    break;
                default:
                    state = 4;                  // back to comment
                }
                break;
            case 7:                             // <! ... found
                switch (c){
                case '>':
                    state = 0;                  // end of comment
                    break;
                }
                break;
            }
            switch (c){
            case '\n': case '\f':
                if (prev == '\r') break;
            case '\r':
                this.lineNr++;
            }
            prev = c;
        } while (true);
        this.cursor = cursor;
        this.start = cursor;                    // start of next token
        if (state > 1){                         // comment not closed
            this.cursor = this.start;           // backup
        } else {
            this.mode &= ~ERROR;                // no errors
            this.stream.markPos = this.cursor;
        }
        if ((FL_V & this.trc) != 0){
            trace("gsep return: " + this.cursor + " " + this.stream.markPos);
        }
        return;
    }

    /**
     * Get an attribute string. It has the syntax:
     * <p><blockquote><pre>
     *  &lt;string&gt;  ::= "\"" ~"\"" | "'" ~"'"
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned without the initial
     *             and final delimiters and with the html character entities
     *             reduced
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token, and <code>mode</code> contains <code>ERROR</code>
     *             if the string is not terminated by the delimiter
     */

    public boolean getStr(Str s){
        if ((FL_V & this.trc) != 0){
            trace("getStr start");
        }
        gsep();                                    // skip separators
        if ((CONCAT & this.mode) == 0)             // do not concatenate
            s.length = 0;
        boolean found = false;
        doit: {
            if (this.cursor >= this.end){
                if (append() < 0) break doit;      // end of data
            }
            char d = this.buffer[this.cursor];
            if ((d != '\"') && (d != '\'')){
                break doit;
            }
            this.cursor++;                         // skip delimiter
            scan: {
                do {
                    if (this.cursor >= this.end){
                        if (append() < 0) break;   // end of data
                    }
                    char c = this.buffer[this.cursor++];
                    if (c == d){
                        found = true;
                        break scan;
                    }
                    if (s.length == s.buffer.length){
                        s.extend();
                    }
                    s.buffer[s.length++] = c;      // append
                    switch (c){
                    case '\n': case '\f': case '\r':
                        this.lineNr++;
                    }
                } while (true);
                this.mode |= ERROR;                // error
            }
        }
        if (!found) restore();                        // back up
        if ((FL_V & this.trc) != 0){
            trace("getStr return",found);
        }
        return found;
    }

    /**
     * Get a namestring. It has the syntax:
     * <p><blockquote><pre>
     *     {"A"|..|"Z"|"a"|..|"z"}
     *         {"A"|..|"Z"|"a"|..|"z"|"0"|..|"9"|"-"|"_"|"."|":"}*
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean getNamestr(Str s){
        if ((FL_V & this.trc) != 0){
            trace("getNamestr start");
        }
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        if (this.cursor >= this.end){
            if (append() < 0) return false;   // end of data
        }
        boolean found = false;
        doit: {
            char c = this.buffer[this.cursor];
            first: {
                if (('A' <= c) && (c <= 'Z')) break first;
                if (('a' <= c) && (c <= 'z')) break first;
                break doit;
            }
            found = true;
            scan: for (;;){
                if (s.length == s.buffer.length){
                    s.extend();
                }
                s.buffer[s.length++] = c;         // append
                this.cursor++;                    // step to next
                if (this.cursor >= this.end){     // end of block
                    if (append() < 0) break;      // end of data
                }
                c = this.buffer[this.cursor];
                cont: {
                    if (('A' <= c) && (c <= 'Z')) break cont;
                    if (('a' <= c) && (c <= 'z')) break cont;
                    if (('0' <= c) && (c <= '9')) break cont;
                    if (c == '-') break cont;
                    if (c == '_') break cont;
                    if (c == '.') break cont;
                    if (c == ':') break cont;
                    break scan;
                }
            }
        }
        if ((FL_V & this.trc) != 0){
            trace("getNamestr return",found);
        }
        return found;
    }

    /**
     * Get a non-quoted string. It has the syntax:
     * <p><blockquote><pre>
     *     {"A"|..|"Z"|"a"|..|"z"|"0"|..|"9"|"-"|"_"|"."|":"}+
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean getNqStr(Str s){
        if ((FL_V & this.trc) != 0){
            trace("getNqStr start");
        }
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        if (this.cursor >= this.end){
            if (append() < 0) return false;   // end of data
        }
        scan: for (;;){
            char c = this.buffer[this.cursor];
            app: {
                if (((c >= '0') && (c <= '9')) ||
                    ((c >= 'A') && (c <= 'Z')) ||
                    ((c >= 'a') && (c <= 'z')) ||
                    (c == '-') ||
                    (c == '_') ||
                    (c == '.') ||
                    (c == ':'))
                    break app;
                break scan;
            }
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] =            // append
                this.buffer[this.cursor];
            this.cursor++;                    // step to next
            if (this.cursor >= this.end){
                if (append() < 0) break;      // end of data
            }
        }
        boolean found = this.cursor - this.start > 0;
        if ((FL_V & this.trc) != 0){
            trace("getNqStr return",found);
        }
        return found;
    }

    /**
     * Get a processing instruction. It has the syntax:
     * <p><blockquote><pre>
     *      "<?" ~">"
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean getProcInstr(Str s){
        if ((FL_V & this.trc) != 0){
            trace("getProcInstr start");
        }
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        if (this.cursor >= this.end){
            if (append() < 0) return false;   // end of data
        }
        boolean found = false;
        doit: {
            char c = this.buffer[this.cursor];
            if (c != '<') break doit;
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] = c;             // append
            this.cursor++;                        // step to next
            if (this.cursor >= this.end){         // end of block
                if (append() < 0) break doit;     // end of data
            }
            c = this.buffer[this.cursor];
            if (c != '?') break doit;
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] = c;         // append
            this.cursor++;                    // step to next
            if (this.cursor >= this.end){     // end of block
                if (append() < 0) break doit; // end of data
            }
            scan: for (;;){
                c = this.buffer[this.cursor];
                app: {
                    if (c != '>') break app;
                    found = true;
                    this.cursor++;                // step to next
                    break scan;
                }
                if (s.length == s.buffer.length){
                    s.extend();
                }
                s.buffer[s.length++] =            // append
                    this.buffer[this.cursor];
                switch (c){
                case '\n': case '\f': case '\r':
                    this.lineNr++;
                }
                this.cursor++;                    // step to next
                if (this.cursor >= this.end){
                    if (append() < 0) break;      // end of data
                }
            }
        }
        found = this.cursor - this.start > 2;
        if (!found) restore();                        // back up
        if ((FL_V & this.trc) != 0){
            trace("getProcInstr return",found);
        }
        return found;
    }

    /**
     * Get a tag name. It has the syntax:
     * <p><blockquote><pre>
     *     "<" ["/"]
     *         {"A"|..|"Z"|"a"|..|"z"|"0"|..|"9"}*
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean getTagName(Str s){
        if ((FL_V & this.trc) != 0){
            trace("getTagName start");
        }
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        if (this.cursor >= this.end){
            if (append() < 0) return false;   // end of data
        }
        int sla = 0;
        doit: {
            char c = this.buffer[this.cursor];
            if (c != '<') return false;
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] = c;             // append
            this.cursor++;                        // step to next
            if (this.cursor >= this.end){         // end of block
                if (append() < 0) break doit;     // end of data
            }
            c = this.buffer[this.cursor];
            if (c == '/'){
                if (s.length == s.buffer.length){
                    s.extend();
                }
                s.buffer[s.length++] = c;         // append
                this.cursor++;                    // step to next
                if (this.cursor >= this.end){     // end of block
                    if (append() < 0) break doit; // end of data
                }
                c = this.buffer[this.cursor];
                sla = 1;
            }
            scan: for (;;){
                if (s.length == s.buffer.length){
                    s.extend();
                }
                s.buffer[s.length++] = c;         // append
                this.cursor++;                    // step to next
                if (this.cursor >= this.end){     // end of block
                    if (append() < 0) break;      // end of data
                }
                c = this.buffer[this.cursor];
                cont: {
                    if (('A' <= c) && (c <= 'Z')) break cont;
                    if (('a' <= c) && (c <= 'z')) break cont;
                    if (('0' <= c) && (c <= '9')) break cont;
                    break scan;
                }
            }
        }
        boolean found = this.cursor - this.start > sla + 1;
        if (!found) restore();                        // back up
        if ((FL_V & this.trc) != 0){
            trace("getTagName return",found);
        }
        return true;
    }

    /**
     * Get up to and excluding a given string.
     *
     * @param      str string
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    boolean getUpNotTo(String str, Str s){
        if ((FL_V & this.trc) != 0){
            trace("getUpNotTo start");
        }
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        if (this.cursor >= this.end){
            if (append() < 0) return false;   // end of data
        }
        boolean found = true;
        int slen = str.length();
        int scur = 0;
        loop: do {
            char c = this.buffer[this.cursor];
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] = c;             // append
            this.cursor++;                        // step to next
            if (c == str.charAt(scur)){
                scur++;
                if (scur == slen){                // matched
                    this.cursor -= scur;
                    s.length -= scur;
                    break loop;
                }
            } else {
                this.cursor -= scur;              // restart from the next
                s.length = 0;;
                scur = 0;
            }
            if (this.cursor >= this.end){         // end of block
                if (append() < 0){
                    this.cursor = this.start;
                    break loop;                   // end of data
                }
            }
        } while (true);
        found = this.cursor - this.start > 0;
        if (!found) restore();                        // back up
        if (found){
            for (int i = this.start; i < this.cursor; i++){
                char c = this.buffer[i];
                switch (c){
                case '\n': case '\f': case '\r':
                    this.lineNr++;
                }
            }
        }
        if ((FL_V & this.trc) != 0){
            trace("getUpNotTo return: " + this.cursor + " " + found);
        }
        return found;
    }

    /**
     * Get up to and excluding a tag.
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    boolean getUpToTag(Str s){
        if ((FL_V & this.trc) != 0){
            trace("getUpToTag start");
        }
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        if (this.cursor >= this.end){
            if (append() < 0) return false;   // end of data
        }
        boolean found = true;
        int scur = 0;
        loop: do {
            char c = this.buffer[this.cursor];
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] = c;             // append
            this.cursor++;                        // step to next
            match: {
                switch (scur){
                case 0:
                    if (c == '<'){
                        scur++;
                        break match;
                    }
                    break;
                case 1:
                    if (c == '/'){
                        scur++;
                        break match;
                    } else if ((('a' <= c) && (c <= 'z')) ||
                        (('A' <= c) && (c <= 'Z'))){
                        scur++;                  // matched
                        this.cursor -= scur;
                        s.length -= scur;
                        break loop;
                    }
                    break;
                case 2:
                    if ((('a' <= c) && (c <= 'z')) ||
                        (('A' <= c) && (c <= 'Z'))){
                        scur++;                  // matched
                        this.cursor -= scur;
                        s.length -= scur;
                        break loop;
                    }
                    break;
                }
                this.cursor -= scur;          // restart from the next
                s.length = 0;;
                scur = 0;
            }
            if (this.cursor >= this.end){         // end of block
                if (append() < 0){
                    break loop;                   // end of data
                }
            }
        } while (true);
        found = this.cursor - this.start > 0;
        if (!found) restore();                        // back up
        if (found){
            for (int i = this.start; i < this.cursor; i++){
                char c = this.buffer[i];
                switch (c){
                case '\n': case '\f': case '\r':
                    this.lineNr++;
                }
            }
        }
        if ((FL_V & this.trc) != 0){
            trace("getUpToTag return: " + this.cursor + " " + found);
        }
        return found;
    }

    /**
     * Get up to and excluding a closing tag.
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    boolean getUpToCloseTag(Str s){
        if ((FL_V & this.trc) != 0){
            trace("getUpToCloseTag start");
        }
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        if (this.cursor >= this.end){
            if (append() < 0) return false;   // end of data
        }
        boolean found = true;
        int scur = 0;
        loop: do {
            char c = this.buffer[this.cursor];
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] = c;             // append
            this.cursor++;                        // step to next
            match: {
                switch (scur){
                case 0:
                    if (c == '<'){
                        scur++;
                        break match;
                    }
                    break;
                case 1:
                    if (c == '/'){
                        scur++;
                        break match;
                    }
                    break;
                case 2:
                    if ((('a' <= c) && (c <= 'z')) ||
                        (('A' <= c) && (c <= 'Z'))){
                        scur++;                  // matched
                        this.cursor -= scur;
                        s.length -= scur;
                        break loop;
                    }
                    break;
                }
                this.cursor -= scur;          // restart from the next
                s.length = 0;;
                scur = 0;
            }
            if (this.cursor >= this.end){         // end of block
                if (append() < 0){
                    break loop;                   // end of data
                }
            }
        } while (true);
        found = this.cursor - this.start > 0;
        if (!found) restore();                        // back up
        if (found){
            for (int i = this.start; i < this.cursor; i++){
                char c = this.buffer[i];
                switch (c){
                case '\n': case '\f': case '\r':
                    this.lineNr++;
                }
            }
        }
        if ((FL_V & this.trc) != 0){
            trace("getUpToCloseTag return: " + this.cursor + " " + found);
        }
        return found;
    }


    /**
     * Test if the given string is present in the input at the current position.
     *
     * @param      str string
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    boolean gdel(String str){
        if ((FL_V & this.trc) != 0){
            trace("gdel start");
        }
        gsep();                               // skip separators
        if (this.cursor >= this.end){
            if (append() < 0) return false;   // end of data
        }
        int slen = str.length();
        int scur = 0;
        loop: do {
            char c = this.buffer[this.cursor];
            this.cursor++;                        // step to next
            if (c == str.charAt(scur)){
                scur++;
                if (scur == slen){                // matched
                    break loop;
                }
            } else {
                this.cursor = this.start;
                break loop;
            }
            switch (c){
            case '\n': case '\f': case '\r':
                this.lineNr++;
            }
            if (this.cursor >= this.end){         // end of block
                if (append() < 0){
                    this.cursor = this.start;
                    break loop;                   // end of data
                }
            }
        } while (true);
        boolean found = this.cursor - this.start > 0;
        if (!found) restore();                        // back up
        if ((FL_V & this.trc) != 0){
            trace("gdel return: " + this.cursor + " " + found);
        }
        return found;
    }
}
