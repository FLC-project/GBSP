/*
 * @(#)ParserLex.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;
import lbj.IoStream;

/**
 * The <code>ParserLex</code> represents lexical analyzers.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

/*
ok- replacements and shorthands obtain a form of W-grammar (van Wijngaarden).

- support to ISO/IEC 14799: could be provided. It is a notation which is
  quite different from the ones in use, expecially the ones used in textbooks
  on formal languages.

- cd jtest
  java -cp JFlex/lib/JFlex.jar JFlex.Main example.flex

- backreferences: non-nested backreferences should not move the language
  out of the realm of the regular ones. Somebody said, talking about
  DFAs, that there are some that can handle them.

- a fast lexer generator is needed when the user code is written in
  the middle of the lexicon specification because the user has to change
  it several times during development. If they are separated, speed in
  generation is not that important.

- since the automa are generated dynamically, there is no need to
  provide a name for a lexer
  .. then remove LEXER

- java 1.4 has a powerful regexp feature which could allow to implement
  special lexer methods. It could be useful to allow a BufReader to
  implement the CharSequence interface so as to allow to use the
  matcher of the regexp. Note, however, that a CharSequence seems to
  represent a sequence of characters which are all available at once,
  or that at least have a known length. I do not know how it is possible
  to provide a random access to a stream.
  Some features of regular expressions are introduced because REs are
  used as a grammar specification. E.g. capturing groups provide what is
  provided by a parser when it delivers the parse tree.
  They require a complete, explicit, specification of the syntax of the
  strings to be matched. This is convenient when that is simple, but it is
  not when the string is made of pieces (like lexemes) which are separated
  by complex separators. I.e. they are convenient as patterns for non
  non-tokenised rules.
  I have the impression that it does not perform full case folding.  
  Why then it uses a Character.toLowerEM()?
  It handles decomposition forms, though.
... unicode escape seq? 2014?

- contextual lexer: I have the impression that the main problem in making
  an automaton as built as now recognise only a subset of lexemes which
  changes from call to call is that it can scan more characters than
  needed. When lexemes are not overlapping, we can simply discard a match
  which is not desired. E.g. if told to match an identifer, and it finds
  and match a number, we can backup and announce failure. However, if
  lexemes overlap, then we must match only the ones which are requested
  and not proceed further. An idea could be to test what lexemes are matched
  when a final state is reached, and record it only if they belong to
  the requested set. Possibly, we can test whether to proceed from a final
  state on if that pays off. I.e. if from that state it is possible to
  reach other final states which match the requested lexemes. We can keep
  a set which is the union of the matched lexemes of the reacheable
  states attached to any final state. I do not know if that pays off,
  though.
- contextual lexers:
  I do not know if it is possible to determine statically the sets of
  tokens that can occur in all item lists that can occur during the Earley
  parsing. It could even be possible that the item lists can be determined
  statically, i.e. that they are finite and less than all possible combinations
  of all rules with the dot in all places.
  I imagine that it could be computed by simulating the moves of an Earley
  parser. Starting from the initial item list, a finite number of lists
  can be drawn, one for each lexeme that can occur in some item of the
  initial list. Then the process can be repeated, avoiding to iterate it
  on lists which have already been found.
  But if that is possible, then perhaps item lists can be stored statically,
  and the sequence of the lists stored as references to them.
  I think that determining the lists is should be possible; the difference
  between a CGF and a LR(1) being that in the latter case the transition
  between two item lists is deterministic.
  Probably the difference is that here we must take into account all the
  possible inputs, which can be more than the ones in the LR(1) case.
  The set of lexemes that can occur in any place in a grammar can be determined
  easily: it is the normal follow set.
  Contextual lexers might not need a default initial state.
- Probably during the building of the LR tables, the subset of token rules
  which can occur in any contexts become known. Probably not in general:
  if it were like that, then the item sets of Earley could be computed
  statically.
- Probably the lexical states are a means to obtain a contextual lexer.
  But then, there should be a way to determine them from the grammar and
  relieve the user to declare them.

- N.B. the handwritten lexers for handwritten parsers are usually contextual.
  In any parsing context, several calls are made to the lexer requesting
  to deliver one of a the lexemes which can occur there.
- contextual: apart from using lexical states, when an accepting state
  has been reached, and taken to be final, all the lexemes recognized in
  it must be returned.



- ParserTst10: insert there tests with text which is not recognised

- Why not have the automata declared in ParserTst as "automa" generate the
  tables and test recognizion?  It can be done, probably without having
  lexemes attached.

- n.b. set the buffer length of the block reader to 8 in all tests,
  including the ones done in the parser, and leave the default for the
  real one.

- having a lexer with actions allowed to reduce lexemes to some compact
  internal form so as to spare carying along text in the other phases,
  like e.g. parsing.
  This could be done by subclassing ParserLex, perhaps, and returning
  some Object instead of a string to be stored in the lexemes pool.

- traditional lexer generators, which return the first rule matched,
  have the problem to report the rules that will never be matched.
  This cannot happen here because all matched rules are returned.

- REJECT is easy, you just keep track of which accepting states you
  entered at what point in the input, and back up to them every time
  REJECT is invoked.
  This means that a REJECT makes the engine return a lexeme which is
  shorter than the current (last returned) one.


- there should be a way to let the user implement an app which expands only
  what lexemes are recognised (or even what constructs) and copies the non
  reconised text as Flex, and probably Lex. To do it, there must be a way to
  pushback the last incomplete token, copy one character, and resume lexing
  past it. Probably the getting of a character can be done with a method,
  but probably it is not needed because interoperability is allowed.
  There should be a means to get a character anyway for error recovery
  (a parser should skip characters to resynch to the next lexeme).
- col: see if it must indicate the number of characters from the start
  of the line or the column, in which case HTs must be processed.
  Rex supports it with yytab() and yytab1(). What is the difference?
  Perhaps it is more costly to detect HTs if they are in the middle of
  rules with respect to when they are alone. Jflex does not support columns.
  Flex? Lex does not support them
- keep a line/columns absolute in the whole text, or relative to each file.
  Should the lexer do it, or leave it to applications? I guess that to do
  it in applications, a second scan of the text must be done (to rekon
  line breaks, tabs, etc.). But doing it in the lexer has probably the
  same cost since there is a need to test characters, or probably a cost
  which is not much different. Of course, if it can be done efficiently
  by applications is better because then they can decide whether to do it
  or not, absolute or relative.
- rex: it allows to disable the calculation of the position of token on
  a per-rule basis. Useful on rules for comments, for which there is no
  need to know the position, or on rules enabled in start states which are
  used to scan the internals of some lexemes, such as strings, for which
  only the first rule matched must calculate the start position.
- eof rules are important to handle include files. Howerver, it is possible
  to do without them since the caller has eof().


Classes

- the Parser classes which are internal to the parser must not be
  declared public

- lexers are objects. This allows to have several lexers in a same program.

It seems that here there are two objects: the encoded automaton and
the lex engine. In the case of the parser engine it is different since
there is one object only, which contains the encoded grammar and the
data needed during parsing as well.

- is it useful to have two objects, namely encoded automata and
  lexers? Would that allow to have a lexer representing a stream which
  is tokenised switch from an automaton to another one?
  Ideally, a lexer generator should generate an encoded automaton.
  Then, lexical analysis should be done by an engine which takes that
  automaton and does the work.
  It should be possible to change the automaton easily because on the
  same BlockReader distinct lexical methods can be called in sequence,
  and the automata engine is just a lexical method.
- why not have the engine as a method of ParserTables? Does it still
  allow to lex a same stream with different automa in sequence?
- probably there can be a need for having more automata objects when
  constraints are handled
- the usefulness of having two objects is that when there is a need
  to lex another text whith the same lexicon, it is easier to create
  another lexer than restarting an existing one
ok- This is not a subclass of BufReader because that could be done only to
  allow faster access to fields containing indexes and references (cursor,
  buffer, etc.). However, to cut down access time there is a need to load
  values into local variables, and fetching them from inherited fields or
  from those of another class does not make much difference since it is done
  only once per call.

ok- cyclic alternatives do no harm: they are treated as left autoreferences
  with an empty terminal to their right. Thus, they produce an empty edge
  from the internal ending state to itself. This gets discarded when the
  DFA is built.

---- from Lexer.java ------------

 * The API of lexer has a buffer, an offset, a length, plus a start,
 * cursor, end and point.
 * A lexer accesses those fields, scans characters, leaves the cursor past
 * the lexeme, and returns a value telling success or failure or what it
 * has got. If it needs to scan past the end of the buffer (the piece of
 * text which is available), it calls a load().
?? does it here? no, it calls a readBlock(), see below.
 * A buffered reader delivers a block of characters each time it is called,
 * and provides a reference to it and the start and end indexes in it.
 * Note that conceptually, lexical methods advance an index in the stream
 * when they succeed. That index has a similar meaning as that of the index
 * in streams: it is the position of the character which is accessed by the
 * next lexical method.
 *
 * There are the following needs in a lexer:
 *
 *  - to process streams in which the length of lines is not constrained,
 *    or even streams in which there is no notion of lines.
 *  - to have it scan only the text provided, or also get new text when it is
 *    exhausted. This is done by having lexical methods call a load()
 *    method (or some others built on it) which by default provides no text,
 *    while in subclasses it can deliver some more at each call.
...?? is it possible with ParserLex?
- it seems that with Lexer it is possible to subclass it to change the
  method which delivers the text. Is it useful here? If such a feature is
  provided, one can use it only when s/he nows what s/he is doig.
  E.g., it should know how positions are computed.
- constructor to wrap a slice of an array, and a string. When I want to
  lex a set of strings, I would need to construct a BufReader each time ...
  Well, not a char[] for which I can set buffer and end directly.
- if I allowed Lexer to support this, why I do not support it here?
  How Lexer worked on String's?
- the lexer must be able to work also on a string, directly, and not
  by means of a stream built on top of it. Well, takeover is supported
  by having a BufReader.

 *  - to get all characters of a lexeme and return them to the caller.
 *    Callers need to access the recognized lexemes to store them, create
 *    objects, search, etc..
 *  - to compute the length of a lexeme. It is mainly used to tell if
 *    some characters have been matched, which means that a lexeme has
 *    been recognised.  It can be computed ad the end as cursor - start
... useful ?
 *  - to backup to a previous position of the same lexeme. It can be done by
 *    setting: position = cursor - start, and to backup: cursor = start +
 *    position.
... done in a different way here ?
 *  - to call different lexers or the same with different arguments or some
 *    lexical methods at a same position to detect which lexeme is present.
... see interoperability
 *  - to allow to process the non-lexed characters with some other method.
 *    E.g. the user could need to skip a defined number of characters or lines.
 *  - to have a skip operation, to be used to recover lexical errors which
 *    occur when at the current position no lexeme can be recognised.
 *    The skip operation can be provided in subclasses.
 *    It should be similar to a gsep(), but skip up to some defined delimiter.
 *    When statements are fully contained in lines, it is sufficient to
 *    read the next line in case of errors and continue parsing. It is
 *    equivalent to skip up to a newline.
 *
 * Implementation details:
 *
 *  - references and indexes are kept in variables instead of accessing
 *    the ones in fields because they are used in loops which are executed
 *    several times. This is done only for the values which are accessed
 *    several times. Moreover, to speed up loading into variables, local
 *    copies of the automa fields are kept in ParserLex fields.
-- Reader fields also? No, gain is not much and there would be a need to
   update interoperation.
 *  - two basic techniques can be used to match characters with what is
 *    expected: ch = buffer[cursor++] and ch = buffer[cursor]. The first
 *    one requires to decrement the cursor when recognizion stops because
 *    an unmatched character is found (i.e. not when the text is exhausted).
 *    The second requires to advance the cursor when a character is matched.
 *  - it is possible to have a stream field and a BufReader object in this
 *    class, but it seems a nonsense: when a char[] is passed, the lexer is
 *    told to scan it, and therefore it is inefficient (and space consuming)
 *    to have a reader. The benefits to have a reader is to use the cursor
 *    and the mark which are in it, which are not much.
 *    Lexer performs lexing on a char[] array.
 *  - before a character can be got from the buffer, a test must be done
 *    that the buffer is not exhausted:
 *
 *              if (cursor >= end){
 *                  if (append() < 0) return ...
 *              }
 *              c = buffer[cursor];
 *
 *  - it is not possible to compare, subtract, etc. cursor values when a
 *    append() could have been executed in the meantime. It is with what is
 *    contained in cursor and start since they are transposed at append().
 *  - when scanning comments there is no need to keep the scanned characters.
 *    In so doing, the buffer is not enlarged when the lexer is built on
 *    a buffered reader. Methods like gsep() use load() to refill the buffer,
 *    The LexerStream implementation of load() removes the mark before
 *    reloading the buffer since the mark is usually set when it is called.
 *    When a load() is done which returns -1, cursor, start, etc., are not
 *    changed (i.e. local variables containing them are not updated since
 *    the assumption is that load() in such a case does not change the
 *    corresponding fields. This is so to keep simple the default load().
 *  - it is possible to support composite lexemes: when SKIPWS is not present,
 *    no whitespace is skipped, and when CONCAT is present the characters
 *    are appended to the existing ones in the return string. Note that
 *    SKIPWS must be set so as to disable the calling of gsep() which could
 *    remove the mark and loose the previous lexeme.
... this is what is done by calling yymore() perhaps
- Lex provides means to backup in actions and to access the recognised
  string, and to concatenate it with the next recognised one.

 *  - the mark is set by append() when a buffered reader is used and the
 *    current buffer is exhausted.
 *  - when the lexeme is not recognised, a restore() is done, which it removes
 *    the mark when a buffered reader is used.
 *  - to return the start index of lexemes, stream.marPos is used. This allows
 *    to retrieve the index also when the stream has been partly processed by
 *    other lexers or user methods.
 *  - indexes in a stream may in general not be mapped onto byte positions
 *    in files. Even if that was the case, it would be of little use in
 *    general because when the encoding used is a stateful one, a byte position
 *    does not allow to determine the offending charater by a random access.
 *    There is in general a need to rescan the input, which can be spared in
 *    some notable case, like e.g. all the fixed length encodings.
 *  - to allow other methods to take over processing, reposition() must be
 *    called before takeover. To resume processing with ParserLex, nothing
 *    needs be done since reposition() leaves cursor = end, which forces the
 *    engine to start over.
.. true?
 *    Subclasses may need some deeper actions, like e.g. updating a line
 *    number counter, resetting internal state fields, etc.
 *    This is necessary because Lexer provides basic lexical methods which
 *    work on a buffer with no stream. To make them work when characters are
 *    provided by a stream, calls have been inserted in methods to get
 *    characters, which are defined in subclasses.
 *    To perform some actions at the end there would be a need to insert a call
 *    to a completion method at the end of each, which is redefined in a
 *    wrapper subclass. E.g. a restore() could be called at the end of each
 *    method, which, e.g. resets cursor to start when the lexeme has not
 *    been matched, and in subclasses can reset the stream.
 *    However, it is not efficient to do it each time just in case a takeover 
 *    can occur.
 *  - in the engine there is no need to remember the last final state,
 *    but rather the last recognised set of lexemes (and the position).
 *  - it is faster to make a bit test on the attributes of the current state
 *    to tell the presence of an attribute (e.g. LOOPING) than testing that
 *    they are lower or equal than a constant.
 *
 * Returning lexemes strings
 *
 * To return lexemes to callers, ParserLex provides a method which copies them
 * from the internal buffer. Lexemes are not built inline because for many of
 * them there is no need to get the string (e.g. for keywords).
 *
 * In the input buffer a lexeme is identified by the start and end (last+1)
 * indexes. This is the normal way to identify a character slice and does
 * not cause problems even when the end index denotes a position which is
 * not in the buffer.
---------------------------------

 * Access to characters
 *
 * Perhaps the most basic issue when implementing a lexer is to decide
 * what part of the text can be accessed randomly. Lexers which are designed
 * for processing text line by line have a whole line accessible, which means
 * that for most lexical methods all the characters of the lexeme can be
 * addressed and there are few lexemes which can span several lines.
 * The most notable case of spanning are comments, for which there is little
 * need to access their characters randomly to scan them.
 * However, processing by lines places a restriction on the length of lines.
 * To overcome this restriction, text need be processed block by block, e.g.
 * reading it with a buffered reader. This allows to access randomly only
 * the characters already scanned, which means all the characters of a
 * lexeme upon return of a lexical method. This allows to implement lexical
 * methods which do not copy in a return string the lexeme, and which are
 * not so complex as they would be if no character was accessible but the
 * current one. E.g. it allows to backup to a previous position when a
 * lexeme is not recognised.
 * Lexical methods must take into account that after a load() the buffer
 * could have been resized, the reference to it changed, and the start and
 * cursor indexes in it have been traslated.
 * Lexers cannot be implemented efficiently without relying on the behaviour
 * of the input buffering.
 *
 * Input adapter
 *
 * In a lexer there is a need to access the characters of the current lexeme
 * even when they may not be got by a single read operation from the stream.
 * A BufferedReader can go back to the last marked position, but to deliver
 * again the characters when another read() operation is done on it.
 * That is what is useful in a lexer to copy a lexeme, but that is not efficient
 * for other operations which occur in lexing.
 * To match token rules, there is a need to access character after character,
 * one at a time, possibly without having to transfer characters into a user
 * buffer. It is faster to access directly them in the buffer into which
 * they have been transferred by the reader.
 * Then there is a need to access all the characters of the current lexeme,
 * e.g. to check if it is already present in a hash table, and that is faster
 * if done without moving them.
 *
 * There is a need to have an efficient implementation of the reading and
 * scanning process. One technique it to have a buffer which is filled first
 * with input characters, and scanned. When the end is reached, the
 * characters of the current incomplete lexeme are moved ad the beginning,
 * and the remainig space refilled again.
 * The drawback of this is that each time a read() of a number of characters
 * which is not a block is done, thus forcing the underlying reader to buffer,
 * which might not be the case if a block is read and the underlying reader
 * is smart enough.
 * A solution is to keep a buffer which has space for a token and a block,
 * and extend it when the free space in it is lower than a block.
 * In both cases there is a move of half a lexeme, which should not be a
 * problem in normal cases since lexemes are not very long.
 * However, if comments are included in tokens, that could be expensive
 * since it requires to extend the buffer several times.
 * Comments are in practice the only one case of long lexemes. Since comments
 * should be discarded in most cases, when the buffer needs be refilled, a
 * test can be done on an attribute of the current state which tells if
 * discardable text is being processed and in such a case remove the mark.
 * The attribute is set on states which belong to the automa of discardable
 * lexemes only (i.e. on states which are shared with other NFAs it is not set).
 *
 * Another technique is to allocate another buffer when there current one
 * is finished, and so on until a lexeme has been matched.
 * Buffers which are no longer used can be freed (but at least two are
 * kept), or can be kept adjusting the number of buffers to match the
 * average length of lexemes.
 * This requires to collect the characters of a token over several buffers.
 * That is not so bad since copying of text which spans several blocks is
 * not complex.
 * The problem with this reader is that it makes the access to the characters
 * of the current lexeme long since they may be split across blocks.
 * This makes complex the storing of them, e.g. into an hash table, since 
 * they must be scanned first to compute the hash value and then to compare
 * them with the strings in a chain, and possibly also to store them.
 * This can be more expensive than the moving of data that a buffered reader
 * can do to keep the characters contiguous. Of course it is possible to
 * move the characters into a temporary buffer before inserting them into
 * the hash table, but that means to have another array and also to move
 * the characters again, which was what the block reader aimed to avoid.
 * That can be done only when the lexemes crosses blocks, but it would not
 * make code simple anyway.
 *
 * Note that there is no technique which is perfect: none is able to deliver
 * a buffer in which the lexeme being recognised is contiguous and kept at
 * the same place. Keeping text in blocks makes lexemes cross blocks, keeping
 * it in a shuffled buffer makes it sliding and using double buffering makes
 * it broken in two.
 *
 * In order to allow applications to supply the reader with the text as they
 * like, the reader should comply to a minimal interface. Currently, a Reader,
 * IoStream, String and char[] are supported.
 * Note that the handling of text by a BufReader does not introduce any
 * penalty when the text to analyse is contained in a char[], which makes
 * the lexer fast when no i/o is involved.

- how can an application provide its own reader? Probably by letting the
  BufReader take the Reader provided by the application. This should be an
  argument in the constructor. But inside parserengine a lexer is created,
  and thus perhaps there is a need to have this as a parameter to the
  constructor of the engine too.
  Well, it seems that a constructor of ParserLex allows to pass an object
  on which a BufReader is built, and that object can also be a reader.
- The user can redefine the input routine to read a piece of the input file,
  and rely on the backup facilities of the lexer, that stores in memory
  the input when backup is needed. If this is not wanted, then the user
  can redefine the read-with-repositioning and repositioning routines,
  e.g. to routines that perform a true io repositioning.

- nested input: treatment of the include files.
  Note that there is a need to tell somewhere in the BNF that there is such
  a directive, at least in the resulting BNF.
  An include should have a similar meaning as a sort of comment in the sense
  that it causes the referred text to be included there and replace itself
  which has otherwise no significance in itself.

  From one side it would be appropriate to see that done at the input adapter
  level. A solution is to provide a reader which intercepts include directives
  and delivers characters traversing the nested input. The same reader should
  be passed to Listing, but there there is also a need to treat some /list
  directive so as to control what gets listed.
  Note that when registering errors, the absolute position in the input is
  recorded, and thus there is a need to have Listing count character in the
  same way.
  This requires to test all characters in the input, which is not done if
  include directives are intercepted by the lexer.
  Having the reader treat the include directive, the directive can appear
  anywhere, even in the middle of lexemes. One common solution to avoid
  it occur in the middle is to force it to be at the beginning of a line.
  It never occurs in the middle if there are no lexemes which can span
  lines. It can occur in the middle of a multiline comment, but that is
  not much of a problem.
  A problem is that an include directive which occurs in a comment would
  take effect, but that is probably what we want.
  It is not clear how C treats include directives: it seems that they
  are not recognised inside comments.
  Note that a preprocessor like the C one is similar to having a reader
  treat the include directive, but it requires it to know C tokens as well.

  Another solution is to make the lexer recognize it. This could be done
  by using user-defined lexical methods, which can do it, probably by means
  of a Lexer API.
  The problem here is that an include directive is just not a lexeme,
  but a construct. Well, since it has a simple structure, it can as well
  be processed by the lexer, or by a lexical method. It is not possible
  to handle it by default inside ParserLex since applications can have their
  own way to locate the files to include (path, default filetype, etc.).
  An app calling lex() can check if it matched an include directive and
  then do it.
  There could be no need for a user defined lexical method. The parsing
  engine can call that middleware that then calls the lexer, and that
  can cope with it. Perhaps I can allow to subclass that middleware so as
  to let the user implement it. The only one problem is to make the parser
  engine create an instance of the subclassed one.
  Dedicated listing directives can be introduced to direct Listing to
  make an inclusion. An include /nolist would simply need a directive which
  tells the size of the (possibly nested) included file(s) so as to skip
  them or to enter them if some messages are present on them.
  This is probably the only viable solution to avoid to recognise include
  directives both in the lexer and in Listing or in a reader.
  It is necessary to either create a new lexer or to make the current one
  switch the reader.
  It is not possible to throw away the non-scanned part of the current buffer
  because it is not possible to reread it in all cases. E.g. interactive input
  would then be lost.
  Have a method to change the stream. It should plug the new one and return
  the old.
- check circularity of include files
- check how the C preprocessor works: does it read an #include in a single
  line? What if in that line there are other characters? Is an include allowed
  in a comment?
- allow to have the name of include files as a logical name defined fully
  in the command line

- another problem is when an html file contains information on the encoding
  in the header. Perhaps I can solve it since IoStream allows mixed
  byte/char operations and allows also to change the encoding.

 * A lexer at the beginning of the recognizion of a lexeme makes a mark(),
 * then calls a readBlock() when the buffer is empty, and proceeds with the
 * recognizion, making other readBlock()'s when all the characters got have
 * been scanned. Strictly speacking, there is no need to make a mark() at the
 * beginning of lexing a lexeme, but only when a new readBlock() is done, i.e.
 * when crossing blocks. A hand written lexer can do that. This one uses the
 * markPos field as start cursor, which effectively sets the mark in a fast way.
 *
 * Takeover
 *
 * There is a need for a buffered reader object to allow another lexer or
 * user defined symbol to take over processing.
 *
 * To allow to continue processing the input with another lexer or user
 * method, it is better to reset the stream to the first non-lexed character,
 * which allows the other one to read the characters which are in the buffer
 * and not yet processed by this lexer.
 * Since the cursor in the reader is set to the first non lexed character,
 * the other lexer could take it. However, takeover is easier if the other
 * lexer can just make a read() or readBlock() instead of knowing that there
 * are data in the buffer at the cursor.
 *
 * In a BufReader, the repostioning is strictly connected with the marking.
 * It is the same as in BufferedReader, in which mark() serves to mark a
 * place to reset to. The whole purpose of the mark is to ensure that the data
 * after the mark are in the buffer so as to be able to reposition.
 * However, when a readBlock() is done, the buffer contains data, which are
 * all considered as delivered, and then it is possible to reposition in it.
 * A method reposition() is provided in ParserLex, which sets the mark, then
 * resets and then unmarks.
 * There is in general a need to reset a lexer also before calling it again
 * when in the meantime read() has been called. However, for ParserLex this
 * is not needed since reposition() resets the cursor and the end, which makes
 * the next call remap the beffer.
!!!!There is also a need to update lineNr
  before calling the lexer again. This when linenumbers will be kept.

Support of user-defined lexers:

- Try then to write a user-defined lexical method to see what
  API it has. To do it, when a token is handled by a user-defined method,
  the method is called.
  It must behave as a normal lexical method: access the characters
  after cursor, leave it refer to the next non-scanned character,
  reposition if not recognised, etc.
  This is more efficient than forcing the method to make a readBlock(),
  and forcing lex() to do it also when resuming. This is appropriate since
  these methods are meant to be called frequently.
  The method would get the characters more or less as this one
  does: it has a need to test if there are characters, and if there
  are not, load another buffer.
  To use Lexer methods there is a need to load the lexer object with
  the cursor, end and buffer first. This is perhaps the only wrapping
  needed.
  - try one, better if a Lexer one
  - make Lexer methods viable as user lexical methods for lex(). It seems
    it is possible as long as a subclass is done which redefines load()
    to get data from the same stream
- they can be defined in some user class, which can even be a subclass
  of this one
- there is a need to provide a mechanism to activate them. One solution
  could be to declare them in the grammar, which should anyway be done
  in order to exclude them from the automaton. During initialization,
  the lexer engine creates the appropriate method handles to call them.
  Another solution could be to call some predefined method dispatcher,
  which is redefined by the user to call the user-defined methods.
  Note that with user-defined methods, the lexer can only call them
  in sequence until it finds a match.
- the type 3 automata recognize all lexemes in parallel. If there is one
  which is not in the automaton, it must be called explicitely. To avoid
  to call it each time lex() is called, there is a need to pass the
  set of desired lexemes to lex().
- Since the scan wrapper computes the length, when it is zero, it can
  announce failure.

- user-defined lexical methods should be dynamically linked using
  the reflection API at init time. A simple way could be to have just one
  such method, which would cater for all token whose rule is not defined.
  Like stating that a <nt> ::= which is a user-defined (or better, a
  user-processed) token is defined by a user method. Or one can have
  several, but the result is that same: the lexer has to call that method
  or all such methods, and probably detect which one among them and among
  the automaton recognised the longest lexeme, and then return it.
  Note that if there are several such methods, the lexer would call all
  of them in sequence, pretty the same as having one which then tries
  to match several lexemes. Note that this could be a problem because
  the method either should not do any semantic actions before knowing
  that it matched a longest lexeme, or should be called again once it it
  sure that the lexeme matched is the one matched by it.
  In simple cases one knows that the lexeme matched is unique, i.e. that
  there could not be longer ones. E.g. an #include, once matche is final,
  there are no other lexemes with that prefix longer than it.
  To get free from this problem, it would be better to have the method
  attached to the token rule, but that means that it becomes a sort of
  callback, which I wanted to remove. Moreover, callbacks do not allow
  to scan strange lexemes. Do not force to have one method with a fixed
  name because apps can have several lexers. At least one for lexer.

- allow to plug a hand-written lexer. There is a need to define precisely
  the interface between the parser and the lexer. There is a need to
  state in the grammar definition that lexemes are not defined there,
  but by a method which is the lexer. Parse enumerates the tokens and
  provides a definition of the numbers.

ok  ... the user instantiates the lexer and passes the tables to it:
             Mylexer l = new Mylexer(p.getTables());
             p.setLexer(l);
    Note that if the user instantiates his lexer class, s/he must get the tables, so,
    s/he must first insantiate the grammar analyzer, or the engine.
    It could be possible to have a constructor for the engine that has as argument
    a user lexer, but it is more complex because the engine then should call a method
    to initialize the lexer, e.g. to get the token numbers.
    The current solution is to call a setLexer() with the lexer specified as a string
    or as an object.
    The user whould first create a parser, then create a lexer passing the parser to it,
    and when parse(text) with a text is called, parse() sets the text in the lexer.
    Moreover, the trace flags can be obtained from within the lexer reading the ones of
    the engine.
    Since the tokenizer must access the stream, the stream must be part of all lexers,
    and the simplest way to do that is to make the user lexers subclsss ParserLex.
    The stream is needed so as to allow the lexers to deliver an access to the strings
    of the lexemes.
    ParserFactory has the method getParser() that allows to specify the input. This serves
    only when the standard lexer is used. When there is a user defined one, it muse be
    called with a null input.
    It calls setParserData(), which when there is an input it creates the standard
    lexer. This relieves from creating it in the places (many) where it is called.
    Of course, the standard lexer can also be created directly, and this is what
    ParserScope does.
    A lexer must return an integer which is the index of an element in tokLists, which
    is a vector of token numbers, the numbers of the tokens that can derive the lexeme
    encountered.

 * Backup
 *
 * A lexer may need to backup to a previous position, which may occur because
 * it attempts to recognize the longest token. This occurs when several lexemes
 * have a same prefix.
 * E.g.: <a> ::= a b | a . With the input a c, in two blocks, the lexer has
 * to read both to determine if the first alternative applies, and then to go
 * back when that is not the case.
 * Note that it is difficult to reread the characters because the input can
 * come from several files, and the lexer would have to record the names of the
 * opened files (hoping they did ot change in the meantime) and thus repeat the
 * same openings.
 * The lexer uses a buffered reader to be able to backup.
 *
 * If the lexer is not required to backup when it does not recognize the
 * lexemes(s), then the only case in which backup is needed is when the last
 * character of the current block has been processed, but the state reached is
 * not final, and at least a final state has been found.
 * However, since there should be a means for the user (in the application that
 * calls the lexer) to access the symbols of lexemes, the characters from the
 * beginning to the end of it must be saved.
 * Note that when processing lines, a line is like a buffer in which backup
 * can be done easily. If there are no lexemes which can span lines, then a
 * lexer could spare the effort to save the current line, allocate space for
 * a new one, etc., and simply overwrite it. With a BufReader, only one
 * buffer is kept, and the only effort spent is when a lexeme spans a block.
 * Thus, time is spent only when needed and that is detected dynamically.
 *
 * Another case of backup occurs when the lexer is called in applications in
 * which it is requested to get a specific lexeme.  The lexer can reposition
 * the input if it does not recognize the lexeme.  In this way the user can
 * call the lexer again and attempt to get other lexemes. In this case it is
 * better not to include comments in lexemes, but to consider them as
 * discardable lexemes, otherwise the lexer buffers comments and thus rereads
 * them all times it is called, which could mean that long comments are
 * scanned several times.

-- it means also that the lexer could stay where it is when it does not
   recognise any lexeme. This should perhaps be the case when it is called
   to deliver any lexeme and the error recovery technique is to skip to
   some known character (e.g. the next whitespace).
   But it seems that it does not make any difference since the lexer must
   save the characters of the current (supposed) lexeme.
   Well, to resynch to some delimiter at which lexing can restart, it should
   be better lex() stays where it blocks.
   Perhaps if it stays in place, then it is possible for the caller to
   reset it to the start, while if it resets it is not possible for the
   caller to reposition it to the place where it stopped.

 * A lexer which would like to scan very long lexemes and report an error on
 * them, and continue scanning after them would need to set a limit on
 * the buffered reader (so as not to cause an OutOfMemoryError).
 * The tradeoff is between rejecting lexemes which are larger than an
 * arbitrary limit and continue scanning, and rejecting the ones which cause
 * an OutOfMemoryError and stopping. The first sets a limit which is arbitrary
 * and that may be difficult to manage.
 * In the second case there is no limit, and the lexer stops when it
 * scans an input which is a completely wrong file, for which continuing
 * scanning is not meaningful.
 * In the lexer engine, no limit is set on the BufReader, thich throws a
 * failure when an OutOfMemoryError occurs. Setting a limit makes impossible
 * to backup when there is a lookahead.

Further information (e.g. the input file name or the line number) could be kept
only if needed by the user.

The problems with buffers (blocks) with respect to the ones I used
before, which contained lines, is that it is more difficult to simulate
BOS, etc. since here the positions seems more glued. I.e. the position
of the last of a line and the first of the subsequent one are too close.

Is there a way to keep int indexes instead of long? Lexemes must anyway
be no longer than that. It seems so with the buffered reader. See the
compression done in the hash table for the list of lexemes.

ok... ParserLex reset() is not the right one to reposition the stream at the beginning
    of the current token, i.e. to the mark. BufReader.reset() allows a subsequent read()
    to get data from the marked position, here we read blocks, and reset() in this case
    is not the right thing to do for lex.index() to deliver the index, which is to reposition
    the cursor to the marked position.
    It would be the right one if lex.index() delivered the stream.index.

 * Position of symbols
 *
 * With a Block reader the positions are as follows:
 *
 *       p = inp.index();
 *       read(row)
 *
 *       .....tttttttttttttttttt............
 *       |    |                 |           |
 *       0    off               off+len     buf.length
 *       p    p+off             p+off+len


Oh, line breaks!

The detection of line breaks should perhaps be done by the input methods
supporting these cases:

  - the application is not concerned with the representation of line
    breaks, be them charcounters or characters: virtual lines are processed.
    This allows an application to parse files whose lines are represented
    in the native way for the platform, and be portable.
    This is like stating that the lexer engine recognizes line breaks
    in any form they appear. However, since the file systems used nowadays
    attach no attributes to files to tell which representation they use,
    there is a need to determine it with some other means.
  - the application is aware of the specific representation of line breaks.
    It recognizes as line breaks only those specific representations.
  - line breaks are irrelevant.

In all cases there should be no limit on line lenghts. An idea could
be to normalize the representation of lines.
It is not efficient to hide the detection of the representation in some
layer in the lexer or in the reader since that is very costly.
To keep efficiency, the input characters should be scaned the minimum number
of times possible.
E.g. not to make a pass only to break the input in lines. When newlines are
characters, they can be scanned normally, but when they are not characters,
e.g. in charcount formats they need be detected and skipped.

- how to select the representation?  If BOS, etc., are mentioned the
  virtual line boxing can be selected, if NL is mentioned the virtual
  newlines, otherwise no virtual lines. What happens if in a lexis
  BOS it mentioned: must BOL, etc., be scanned (and thus appear in some
  rule e.g. for whitespace)? It would be better not, but in such a case
  the special characters are not symbols, but conditions (i.e. properties
  of the symbols or the place). Well, like breaks are significant in
  most cases, and therefore they should be mentioned in some lexical
  rule to be scanned. If they are not, the lexer returns an error when
  it scans them.
- the treatment of line breaks must be done even if there are no BOL,
  etc.
- a charcount file must be treated properly: the charcounts skipped,
  otherwise they would be parsed as characters, and the line breaks denoted
  by a special NL symbol, because a character could match one which is
  actually in the file

- a line is ended by the end of the file or by any representation of
  the newline. What about the last line? If it must be ended by a line
  break, then a last line which is not must be treated anyway as ended.
  If it must not be ended, then a last line which has a newline means
  an empty line at the end. Perhaps that is not really important: a
  EOL can match a newline or also an EOF.
  Most applications would be lenient about this, but some few others not.

A technique to handle newlines is to let the user define in a rule what
characters they are, e.g. <newline> ::= \r [\n] | \n.
This needs no special treatment by the engine. This, however accepts
newlines which are not the ones for a platform. E.g. \r is normally not a
newline in a Unix file. To have this, there is a need for a special symbol
NL which is predefined to be the one for the uderlying platform (or the
one for the file-format selected). When a state has an outgoing transition
for NL it is marked as special, and the engine upon entering it tries
to match the newline and returns the appropriate category, i.e. it
performs a special match. This allows also to have rules which contain
\n and \r, which would be matched normally.
For charcount files there is a need to intercept the end of lines and
to transform them into NL's irrespectively on states with an outgoing NL.
For these files, a line break may not be matched by any other character,
and may not be fed through the normal processing.
A technique is to set the end index to the end of the line if that is in
the current block, and make a test when the cursor strikes the end.
This can be done without scanning the characters, and consumes time only
once per line.
However, it is common to accept any representation. I expect that the cases
in which an application must take the native representation only and also
be portable are rare. Such an application would need to select the automaton
at startup time, and the programmer define a lexis for all platforms.
Otherwise there is a need for such a special treatment. It it costly?
Can I use it always?
Moreover, in Unicode there are many more characters which denote line
breaks, which makes not convenient for the user to write the rule.

What characters should be transferred when a lexeme spans over several
lines? \n, or \r\n or even better something which allows to have \n
in the lexeme?
This is a big problem. Files which have a representation of newlines which
is not made by characters have effectively a VT which is an extension of
the character set. They can be represented by a sequence of lines, or by
a sequence of characters in which some special one denote the line breaks.
Whatever the representation chosen, there is a need to have something extra
with respect to VT.
Strings containig extended characters can be represented in several ways,
expanded or compressed. E.g. if EOF is represented as a 32 bits value -1,
it can be stored in strings in which each character takes 32 bits, or in
UTF-8 with some extensions. But the question here is why there is a need
of such a thing when Unicode supports many dedicated values for this purpose?
In other words, a file with charcount lines allows to have any Unicode
character in a line. When we had ASCII characters only, we could wish to
have a \n in the middle of a line. Now we have extended the character set
and have included in it many new values, some of which are dedicated to
the representation of lines. Why would we then include such values in the
middle of a line? We can think to a character set as a set of values some
of which represent characters, and some others the structuring of the text.
If we need to include the new newlines in the middle of lines we can define
a 32 bits Unicode, and then the story would repeat all over again.
The issue is that a file with charcount lines has anyway a representation
of lines which is something that may not be included in the middle of lines,
and even worse, it cannot be stored easily in strings.
A technique to store it is to use the same representation is strings: a
charcount which tells how many characters of the string are in the current
line, followed by charcount segments.
Note that it is by chance that there is no problem in having source files
with charcounts since most of the times line breaks behave as lexemes
separators only, and are otherwise discarded. Seldom they have to be
stored. E.g. a prettyprinter program must treat them and probably store
them.
A solution could be to convert on the fly charcount line breaks in
Unicode NLs. This if there are no VMS Unicode charcount files, but only
ASCII.
What is misleading is to think that a format effector used to delimit
lines introduces a device dependence. This was so many years ago. As a matter
of fact, \r\n in Windows has been inherited from DOS, and there it was
what was needed to move the carriage to a new line when printing on a
teletype. Nowadays we can think to those characters (and to the Unix \n
or the Mac \r) as just characters which represent line breaks.

My opinion is that the charcount format is not the appropriate way to
represent lines. Since line breaks are syntactic entities which need be
scanned, matched, stored, etc., the most appropriate way is to represent
them as characters. An out-band representation complicates processing since
it needs either to process text line by line, or to convert them in some
characters. As a matter of fact, most codesets have characters to represent
them. Charcount formats are a good means to represent files made by variable
length records. Having that, and having lines a length which varies, they
have been used to represent text with lines. In such a case it is better to
specify how they are represented as characters.
-- make a test with ftp from a Unix machine and a VMS one or from a NT and
   a VMS one. I guess that the native convention is used.

- does in VMS ever a read() return the charcounts, or are they converted
  by the VM? Is it possible to read such a file in blocks?

- how costly is to translate charcounts into NLs?
- take into account that there is a transformation of input files from
  their encoding into Unicode. This could be the place to translate
  native newlines into standard ones. This can be done if we are sure that
  a file contains text, which is not necessarily the case since what a
  parser processes is a sequence of characters, whose meaning is left
  to applications.

- newlines as \n, \r\n and \r are in Listing. To support charcount newlines
  there is a need to change it.

- since now we read in blocks, there is a need to scan also the \n, \r
  and charcounts. Note that in Lexer there is no getline().
  Perhaps it is possible to replace the charcounts with something U+2028
  Line Separator, adding one also at the end (there are blocks here).
  There is also a Unicode category Character.LINE_SEPARATOR.
  This can be done when files are converted into Unicode because charcounts
  are two bytes, perhaps word aligned, or after, in which case it is
  even worse.
  It could be interesting to see what java does on VMS because Readers
  decode there the byte streams and thus should treat somehow the charcounts:
  it is unlikely that they convert them as if they were characters.
- what does Java in VMS? Does it treat charcount files?

- letting the user bother about this is not entirely satisfactory.
  The most common case is that of files which have line breaks whose
  representation is not relevant.

- suppose I have a program which reads a file in which there are lexemes
  containing newlines and writes a file in which they are copied, and
  wants to do that in accordance with the platform, i.e. accept any
  representation in input and produce the native one in output.
  If the translation of newlines is confined in the input adapter and
  in somehow in the output one, that is easy, otherwise the program has
  to call some method which peforms the translation.


Files and lines borders

Lexemes can have line of file boundaries as lookahead or lookbehind
contexts. This occurs with queer languages in which there are constructs
that are deemed to be at the beginning of lines (presumably to allow to
use the same character sequences in other places with other meanings).
Probably that is the case of Unix nroff.

The idea was that the input was considered to have the special characters
in place only if they occurred in the grammar so as to avoid to mention
them in grammars in which they were of no use.

BOS serves when in the syntax there are constructs that are recognised as
such if they are at the beginning. If there are no such constructs there is
no need to declare it. Thus, the input can be considered to have a BOS at the
beginning if it is present in VT.
EOS serves when there is a need to guarantee that all the input has been
parsed and that guarantee is done by scanning it instead of a special
check in the parser.
Moreover, it serves when there are tokens which have it as lookahead.
If there is no need for that, e.g. if the user wants to recognise a phrase
in the input, and then process the remaining input with other means,
EOS can be omitted from the syntax.

BOL is similar to BOS. The input is considered to have it if it is present
in VT.
EOL serves to attach a meaning to line breaks. The input is considered to
have it if it is in VT.
Thus, a syntax that does not declare it considers all the input as a
sequence of characters regardless of line breaks. A file subdivided in lines
or blocks is taken as a single string. A syntax that declares it considers
line breaks where they are present: where they are passed by the input routine.

Probably the idea came from the need to write clear rules for the matching
of lexemes which started at the beginning of files, lines, etc.
E.g. the first line in a file has no character in front of it, and therefore
it is difficult to write a rule which has a lookbehind context.
Introducing extra (special) symbols for beginning/end of files and lines
allowed to do this and also made matching simple since it was nothing
different from the normal one. E.g. there was no point in advancing or
not over the special symbols, which was a problem if they were not symbols.
Now, the simulation of these special symbols is costly, and thus it is
appropriate to see if they are really needed.
A reader which delivers characters and reserves indexes for BOS, etc.,
effectively makes a pass on the input since it has to test all characters
to detect lines and also to simulate the presence of BOS, BOL, etc.
Note that it must assign indexes to them because they can have errors on
them, and have some sequencing engine to advance the indexes properly.

A drawback in having them is that they need be parsed. E.g. once BOL has
been mentioned in a token rule which must have it as lookbehind, it must
also be mentioned in a comment rule which allows newlines.
Another drawback is that they would be part of lexemes (in the string which
is stored and handed to an application).

Probably it is possible to test several times a EOF conditions, but not
as a symbol, which would require that there were an endless number of them
at the end of the text.

Having BOL, etc. as symbols allowed to use the normal automa to treat
them, while with conditions there is a need to have some special automa
extension.
EOS as symbol allows to scan comments at the end of the text by defining it
as a lexeme which has comments in front of it and by mentioning it at the
end of the main rule(s) of the grammar.
However, it requires to declare it in the grammar, to work with an extended
character set, etc.
Note that there is a means to specify that comments are allowed at the end.
Informally, language specs state that they are allowed before and after any
lexeme. It is possible to specify them in such a way in the lexicon, but
it seems odd.

BOS, etc. as conditions

BOS, EOS, etc., if supported as symbols would be quite strange since they
need not be matched mandatorily. Ordinary symbols, if present in rules,
must also be present in the text  to match. If they are not present in
rules, they must not be present in the text. Here either we consider the
text as made of BOS ... EOS, in which case we must mention them in grammars,
or we can state that they are present in the text if they are mentioned
somewhere in the rules, or if some option is specified. Quite peculiar.
Note that in JFlex there is an EOF rule, which is there only for the sake
of allowing to write all the code in the file containing the lexer
specification. An application can also perform those eof actions when
returning from the lexer (testing also that the position in the input it
at the eof). It could be more useful with nested include files perhaps.
This means that it is not exactly treated as a symbol: you cannot mention
it in rules, but you have a special rule for it.

BOS and EOS can only be mentioned at the beginnig or end of a lexeme.
BOL and EOL the same because when a newline is in the middle
of a lexeme it is mentioned as NL and it is something real to scan.
Well, to avoid to introduce extra notations, BOL can be represented
as:

    <newline> ::= \r [\n] | \n
    <BOL> ::= BOS | <newline>
    <A> ::= <BOL> / alpha

This means that there is a need to cater for them only at the beginning
of lex() and at the end. This means also that perhaps there is a need
to reject them as errors when they appear in the middle, or to treat
them as NL (including when they are mentioned in a rule which is referred
to from a token rule).
BOL could be mentioned in a rule which is used by two token rules: one
refers to it in the middle and the other one at the beginning. This makes
difficult to reject it. The use of a context, i.e. a condition or a
production which does not skip characters in the middle of another one
works only if the other one produces the same head or tail. E.g.:

    <A> ::= a <B> de
    <B> ::= b / def

Supposing that "/" denotes a right context, these rules work because
<B> is followed by a string "de" which does not contradict its context,
otherwise <B> could never be applied. Perhaps it is possible to detect
and signal this.
Note that in:

    <A> ::= a <B> \n
    <B> ::= b / EOL

there is a need to match EOL with \n, which means that EOL would match
a \n. If BOL and EOL are declared in the lexis there is no such problem:
they match what their rules do.
There is a need to study this better. It is also possible to allow
contexts only in token rules, and disallow them in inner rules.
I saw sometimes ago something about lookaheads and the conditions under
which they worked.
It is anyway possible to detect BOS as index == 0, EOS as atEof, BOL
as cursor == 0 || buffer[cursor-1] == \n, etc. Note that upon entey
in lex() cursor is 0 only at the beginning of the text, and it points
to the end of the last lexeme otherwise. Thus, it is always possible to
check the previous character. If it is a \n, then we are at BOL, if
it is \r also, but in such a case it must not be followed by a \n
because it would mean that the token starts at the middle of a sequence
which is a newline.

Note that in the previous rules BOS is mentioned in inner rules. There
is a need to see how this is brought at the lexeme lever and represented
in its automaton so as not to enter an endless loop when it appears in
rules such as {BOS}*.

For jflex, ^ and $ are more conditions than symbols since they are not eaten
(which means at least that they are conditions). Moreover, ^ matches also the
beginning of the text, which means that it is a condition since there is no \n
at the beginning.
- then study better my previous implementation
- in jflex there are two different starting states for it, or
  better, when a BOL is detected, the state+1 is taken in the starting
  state table. This means that there should be a starting state for the
  lexemes which have ^ in front of it, and another for the ones which
  do not have it. Note that this applies only to starting states, and
  that the detection of the BOL is done before the recognizion loop and
  inside the one which recognizes lexemes.

It generates a different lexer when a ^ occurs in the token definitions.
It has a table of states in which each lexeme has a state to recognize
it when at beginning of line and when not. In the recognizion loop,
a test is done to detect BOL. This is done each at character!
What is strange is that it swithces automatically from a normal initial
state into the ^ one when the stream is at BOL. I expect then that in
the normal state is does not recognize a lexeme if it is defined with
^ in front of it, and no definition without ^ is present.


In some parsing algorithms it seems good to introduce an ending symbol
which is not in VT. This allows to have algorithms which deal only with
symbols and not with two kinds of things.  This seems to be a general
case. Suppose there is a need to scan a file.  This is the algorithm
if the input method returns a value which denotes the eof:

     while ((c = in.read()) != -1){
         process data
     }

And this is the one when the eof condition is represented in a different way:

     do {
         c = getchar();
         if (eof()) break;
         process data
     } while (true);

They are not much different, and the difference is not a problem when
writing a program. But it can be a problem for a parsing algorithm which
deals only with characters.
Note that the eof condition can only be tested after reading.

I have the impression that it is not difficult to convert the eof condition
into a symbol (it is what many reader classes do), and to pass it.
To pass it, another symbol or condition must be tested.
I.e. a rule <S> ::= bla bla EOF must match an EOF only, and after that
there should be nothing, which is always the case. But this could also
mean that the EOF must be matched only once (remember the triple ^D
problem). In other words, should we consider the input as followed by
an endless number of EOFs?

- how do I detect here that a lexeme is at the beginning/end of a line
  or file? Test it. For the end that is simple because in the case of
  line terminators, a test is made if they are there, and if they are,
  the stream is repositioned back (this can be implemented efficiently
  by moving back the cursor if it is in the same block). In the case
  of charcount files, either the Line Separator is tested as in the
  previous case, or the index is tested against that of the first position
  after the last character of the line.
  For the beginning, there is a need to test what is before the token.
  This is not so difficult; it should be done before setting the mark
  (because after it all the characters before the mark could become
  unaccessible).

- how to treat the eof? the problem is that if it is a condition, then
  it must be treated without exiting from the loop. Eof is not necessarily
  a lexeme by itself (I have the impression that in jflex it is like that).

- what is the purpose of having index = Long.MAX_VALUE when the eof is
  detected? For Listing?. If it must be so, then when eof() would return
  true if called, then at that time also point should be equal to
  Long.MAX_VALUE. Well, for Listing any value which is greater than that
  of the last character is good.


Lookahead and lookbehind

- lookaheads -> trailing contexts

> In JFlex, as in most other packages which support lookahead,
> r1 / r2 is specified to match the longest text that matches r1 r2,
> and then to return r1.
> Do you have any example showing that this is the proper semantics,
> i.e. the one that is most useful in practice vs, e.g. having the
> semantics of matching the longest text for r1 and then the longest
> for r2 and returning the former?

No, I've no such example. I picked this semantics because it's widely used 
(so many users will expect it) and beause it's relatively easy to implement 
(when you use the standard algorithm and ignore its problems). I don't think 
that it's The Way To Do It though. Your proposition also seems very 
reasonable. From user perspective I think the requirements are that r1 is 
really followed by r2. Most would probably also expect that no instances of 
r1r2 are missed completely (eager matching of r1 and then r2 might fail when 
the r1 match already contains a r1r2 instance, but after the eager r1 match 
there is no r2 instance. But I suspect that in these cases the standard 
algorithm will also fail).

The choice seems to be between:

   1. longest match of r1r2,
   2. longest r1 + longest r2, and
   3. longest r1 such that r2 matches after the text matched by r1

The difference seems to be that when the RE of r1 is such that
is generates strings that can also be generated by r1r2,
alternative 1 would deliver a match, and alternative 2 not.
E.g. r1 = a|ab, r2 = b, text = ab. Alternative 2 delivers no match
since it takes the longest r1, which is the whole text there,
and then it has no text left to match r2.
This might be not much intuitive since the text does contain a
string that is a r1 followed by a r2.
This could be a rationale for stating that alternative 1 is
counter-intuitive.
Alternative 3 finds the longest prefix `u' of the text `w = uv' so
that `w' matches r1, and `v' matches r2.  The advantage over
alternative 1 is that the text matched by r1 is unambiguous.  This
kind of a system is, by the way, easy to implement using tags.
As for the second one, the length of the text matched by r2 is irrelevant:
what is important there is the presence of an instance of r2.

    RE       text             alt. 3                alt. 1
  "a* / b*"   "aaabbb"     "aaa" or "aaab" or     "aaabbb"
                           "aaabb" or "aaabbb"  

With alternative 3, the length of text matched by r2 is not specified,
so the overall text matched can be ambiguous.  An optimal implementation
would match the longest text for r1 and the shortest for r2, to avoid
unnecessary processing of the text.
I guess that an optimal implementation would match the shortest for
r2 when possible since when r2 is a tail of r1 that might be impossible.
To match the shortest it is sufficient to cut the edges outgoing from the
final states.

The only one problem with alternative 3 is that it can lead do match
more lexemes than other. E.g. in the previous example, a lexeme which
is a* /b and another which is a* /b+ would both match the example text,
while with alternative 1 only the second one would match.
I am wandering if the alternative 3 could be rephrased as:

   3'. longest r1 such that longest r2 matches after the text matched by r1

It could perhaps be even more intuitive since when we think of an expression
matching we have in mind the longest, and therefore having two RE like e.g.
a* /b and a* /b+ and text aaabbb it looks intuitive that the second expression
is the one which matches.
Another alternative could be to let the user specify the greediness of the
expressions and match the longest r2 taking that into account. E.g., if
r2 is r21*? r22 (which should be equivalent to (r21-r22)* r22), a non-greedy
match is done.

- Find the rules when they are symbols, and then when they are conditions.

  concatenation:  l1 alpha l2 beta ...
  alternation:    l1 alpha | l2 beta ...

- having BOS as condition it is possible to write a lookbehind which
  means BOL: {BOS | \n | \r | \r\n}
  It is also possible to have one for "beginning of page".

- perhaps it is possible to mark the states from which there are outgoing
  edges with conditions and then determine them only in such a case

- one of the problems with conditions is:

     { BOL }*

  enters and endless loop unless the lexer reduces it to [ BOL ].
  Well, {""}* does not enter an endless loop, I guess. Probably the
  transformation into a DFA folds it by removing it. Here something
  similar should be done: there is a need to take it out of the
  loop.

- the anchor ^ is in effect a lookbehind

- The difficult part seems to represent lookaheads, backreferences, etc.,
  with a DFA. E.g. a nested lookahead could be handled by keeping a stack
  with the starting points, but probably also by coding it into a DFA.
  A lookahead followed by a regexp can probably be represented as a normal
  piece of DFA, in which the state in which the lookahead begins is marked
  to record the point, and the one in which it ends is marked to either
  go back or discard the point (if recognizion proceeds).

- jflex includes the lookaheads in the length of the matched string to
  select the longest match. This means that a short lexeme with a long
  lookahead takes precedence over a longer lexeme, but with a much shorter
  lookahead. I am not sure if this is correct. The longest match rule is
  used to solve an ambiguity: it states to take the longest because that
  is more specific. Is a short lexeme with a long lookahead more specific
  than a longer one?
  Howerver, I have the impression that including the lookahead in the
  longest match is the only possible solution since it reduces to sumbatch
  addressing inside the rule, which is otherwise treated as all the other
  ones for what concerns the longest match.

- For arbitrary lookahead (also called trailing context) the expression
  is matched only when followed by input that matches the trailing
  context. Unfortunately the lookahead expression is not really
  arbitrary: In a rule r1 / r2, either the text matched by r1 must have
  a fixed length (e.g. if r1 is a string) or the beginning of the
  trailing context r2 must not match the end of r1. So for example "abc"
  / "a"|"b" is ok because "abc" has a fixed length, "a"|"ab" / "x"* is
  ok because no prefix of "x"* matches a postfix of "a"|"ab", but
  "x"|"xy" / "yx" is not possible, because the postfix "y" of "x"|"xy"
  is also a prefix of "yx". JFlex will report such cases at generation
  time. The algorithm JFlex currently uses for matching trailing context
  expressions is the one described in [1] (leading to the deficiencies
  mentioned above).  The trailing context algorithm described in [1] and
  used in JFlex is incorrect. It does not work, when a postfix of the
  regular expression matches a prefix of the trailing context and the
  length of the text matched by the expression does not have a fixed
  size. JFlex will report these cases as errors at generation time.

- in regexp, java, there should be some algorithm to parse lookaheads
  that has not the problem of jflex.
  Does Lex have the same problem?

- how is lookbehind handled?

tagged automata:

- perhaps it is possible to use the TFA method internally, probably optimizing
  it for the lookahead only. Perhaps it is also possible to accept lookaheads
  in internal rules, and not only in the outermost one.
  There is also a need to understand how this method can be combined with
  tunnelling and necklacing, otherwise it is difficult to use.
  Obviously, methods which transform a DFA need be adapted if the FA gets
  augmented by adding something, and compression mechanisms in general,
  unless they are plain matrix manipulations.
  Adding actions to states increases the complexity of this. Perhaps tags
  are simple actions for which this is not so complex.

  Another difficult example: ab * / bc*

- include the difficult examples from Ville that I have sent to SUN.

- obviously, if it solves ambiguity with priorities it does not need to
  record all values each tag was assigned to, but only a few. Note, however,
  that priorities are used to decide which path to take, and from this
  follows the recording of positions.
- the idea to penalize only lookaheads and not the whole engine is good
- the relevant position can be the first, an intermediate one, or the last:

     (a|ab)/ba         aba     first
                       abba    last
     (a|ab|abc)/bca    abca    first
                       abbca   second
                       abcbca  last

- each variable is in effect the container for the final value, which is
  backed up by an array, probably long at most as the number of edges
  which have that tag on them, or the number of states.
- tags: a tag has more than a variable: it has a vector

- TNFA -> TDFA the map values are handed over from state to state

- probably I did not understand well, but it seems that a map of the values
  of tags is computed at each transition by storing the position if the
  tag is attached to the edge. Probably then we can decide whether to
  keep all such maps or not.

- when the next state is computed for the TDFA, all TNFA states reached
  by a same symbol are collected, and then the e-closure made. When doing
  that, tags could become assigned. Then, when the next states from it are
  determined, probably the e-edges must not be taken into account, otherwise
  tags on them are assigned twice.
  It seems not so, at least by looking at the example. This seems strange.
  Well, probably not since the first all moves are determined for a same
  symbol, and then the e-closure made. This means that we keep in the TDFA
  state a same state, one from which we compute an e-closure if and only if
  a symbol other than epsilon has put it.
- in the example probably it assigns the final value to the tag by taking
  what is carried over by the TNFA final state in it. I.e. since we have
  there 2 {m00} in the state, and 2 is final, we take m00 as final value
  for t0. The tricky part is very obscure: we are interested in tag values
  (otherwise we would not take the pain to keep tags). Why should we throw
  away those values? Probably because what is carried over are only two
  values of t0 in two transitions, and all previous values are forgotten.

- in order to make a state equal to another with reordering commands,
  the items to be reordered must be distinguishable. Are the upper indexes
  the distinguishers?

- storing positions and reordering maps: it seems done by the engine.
  Is it faster than backtracking.
  Why it is not O(t)?

- would be better to store in maps the tag values in the slot which
  corresponds to the state instead of the first free one?

- it seems that there are some tools that handle them, but they do not
  say how. Also Tflex does, but it is not clear if it backtracks or not.
  It makes two passes, though, which is rather strange.
  Have a look at the technique to store all states encountered and then
  to derive a parse tree out of that.
- have a better look to Icon.

- minimization should probably take into account the actions on the
  edges.

- what seems at the moment uncertain is the possibility to unify states:
  Ville says that it is always possible since a substitution can always
  be found.

- tag values are attached to states, or even better to configurations.
- when simulating a TNFA, each state reached in one move can carry along
  its tag(s) value(s). When deriving a TDFA that is not practicable.
  To record all the things that the TNFA did, we can store along with
  states, the tag assignments. However, I do not know then how to equate
  TDFA states then. Of course, if I record all the configurations reached,
  I can then visit them when a match is found and execute those assignments
  and compute the final value of tags.
- a NFA can be simulated by remembering all states reaced at each move.
  The actions done by a NFA upon a move is to reach a state, i.e. assign
  a new value to a state variable. Such an action can be simulated by
  remembering the assignment or even by doing it straight away.
  This is a simple case. But when the action is more complex, I do not
  know how it can be simuated, i.e. if there is a need to remember the
  action or to execute it in some way.

- TNFA with map, which then makes TDFA easier to understand why it
  has maps and not tag values

- now, it seems that in a TNFA there is only one function, when the TDNA
  is in a state, i.e. one vector of tag values. In a TDFA there is one for
  each of the TNFA states which are represented by a TDFA state. This seems
  what Ville says in the last mail.

- see is / implemented in jdk 1.4, and if it works properly (if it does,
  then a working algorithm that can be considered exists)
- see if / implemented in libtre

- there is no problem in lexing a lexeme after another, but
  there is in lexing r1/r2. This is probably so because we define
  recognizion as the longest sequence of characters that matches r1 r2
  and then want to take r1. With two lexemes, we take the longest text
  that matches the first, and then that for the second. We do not shorten
  the text matching the first because in so doing we march an overall
  longer one.

- I think I had some thought on the use of lookaheads in groups (or
  nonterminals) which are not at the end of lexemes. It was perhaps possible,
  albeit with questionable meaning.

- complement, diff, etc. with lookaheads: probably it is possible since
  a DFA can be complemented even if it has tags, but meaningless

- there is an intrinsic complexity in treating lookaheads. When r2 does
  not overlap the tail of r1, keeping track of the last r1 state is
  sufficient. When it overlaps, we do not know how to split the matched
  text until the automa stops. This means that we must keep all the possible
  splits (e.g. all the end states of r1, or even all the passages on them),
  and decide the right one at the end. Alternatively, we can parse again
  backwards. I am not sure, but perhaps it is possible to mark all the
  start states of r2 (they should be the same as the end states of r1),
  and then associate to each r2 state the set R of start states from which it
  can be reached. When reaching a start state, it is added to the set S of
  start states reached, when reaching a r2 state, S is intersected with R
  so as to remove all the start states which do not belong to the instance
  of r2 being recognized.
  I do not know how this handles the various cases of longest + longest, etc.
  I do not know if this is sufficient, or if there is a need to attach R
  to transitions. In other words, is the reaching of a state sufficient to
  tell which instance of r2 is being recognised?
  This is more complex than it seems. Consider the expression {a}+ / aa
  The FAs are:
                     ,-a-.
                     v  /
       NFA:  (0)--a-->(1)--a-->(2)--a-->((3))

                                            ,-a-.
                                            v   |
       DFA:  (0)--a-->(1)--a-->(1,2)--a-->((1,2,3))

  When reaching the final state, other transitions make the automaton remain
  in that state, but there is a need to remember that the move that makes
  the r2 recognized is the last-but-one, which shifts one ahead each time.
  This means that it is not simply the reaching of a state since a same
  state can be reached several times.
  The storing of the position in the maps in TDFA achieves exaclty that.

  I have the impression that with tagged automa there is a need to do something
  on transitions. Either we represent a TDFA state as a set of TNFA states,
  each of which with possibly an assignment attached, or we attach the place
  in which the assignment stores the value. In the latter case we have to
  move out of the state representation the commands that make such an
  assignment, and attach them as an action to the transition that reaches such
  a state. The same should be done if we reorder the map to make a state
  equal to another. Having then commands on transitions, it is not longer
  clear how minimization works, which is now based on states only.

- having tags on states is the same as having them on the edges because
  an edge can go to a state which has a tag and an e-edge to another state,
  thus obtaining the same. E.g. with tags on edges it is possible to have
  from a state two edges to a same state for a same symbol, one with a
  tag and another one without (or with a different tag). Having tags on
  state does not eliminate this since we can add two states to the two
  edges and obtain the same.

- lookahead: I do not think that recognizing r2 backwords it works.
  r1 / r2: recognizing r1 r2 should recognize the longest of r1 and the
  longest of r2 since that is what is done on all the repeated groups.
  How can I know how long is r2? After recognizing r1 r2, how can I know
  what is the r2 among the maky that could be there which is the correct
  one? I should record all the lengths at which an r1 ends, and then
  start recognizion of an r2 until the smallest is found which starts
  at one of such points. And how can I be sure that I should not make
  many attempts? Probably because it should be possible to build a DFA
  for the reflected r2.
  If I remember all states encountered, that is costly since it is done
  on all lexemes. It would be better to do something only when lookaheads
  occur. TDFAs probably require a test in all states. Probably not bad.
  If we are lucky we mark sone states in which there is a need to make
  some assignments. But in the first paper of Ville I remember that there
  were actions on transactions.
  The method of Aho can anyway be applied when there is no ambiguity since
  it is cheap.

- a lookahead which is EOF is not !<char> since !<char> means 0, 2, ... chars,
  which matches when several characters are present, but even more because
  it would slurp all the remaining text just to tell that there is some.
  It is not either !{<char>}+, which is the empty string, because an empty
  string is always present in the text.
  The problem is that complemented automata recognize the strings which are
  the ones that belong to V* and are not the ones generated by the grammar.
  A grammar which is {<char>}+ generates all the strings with at least one
  character. The complement is the empty string. When we work on a bounded
  text which has to be recognised entirely, the complement automaton when
  applied to a text that is longer than zero characters would return no
  match since it would not scan all the text. However, when lexing, we do
  not pretend to scan all input, and take instead the longest piece that
  matches. With this, matching a string which is in the complement language
  and testing that there is no string of a language is no longer the same:
  in the previous example, an empty string is present, but also a (longer)
  string in the (non-complemented) language.
  This is the reason for having negative lookaheads.

  This problem occurs in other cases also in which the condition is
  that there should not be a given string. E.g. if the condition is that
  there should not be two a's, then the complement is made by all strings
  which are not "aa". However, "aaa" is one of such strings, and thus
  when "aaa" follows, the lookahead matches.
  A solution is to match it as if it were a positive one, and then if one
  ending state of r1 has been reached, but none of r2, decrete match.
  Or, if r1 r2 has been matched, decrete match if no r2 is there.
  It seems that the problem boils down to recognizing the positive one.
  Probably it can be stated by the lookahead:  !{aa {<char>}*}, which,
  however, slurps all the input when it does not start with "a".

  It seems that the traditional definition of automaton does not allow to
  build one which tells "yes" if there are no characters, and "no" otherwise.
  An automaton which is able to do it is:

       ((0))--char--->((1))

  It has two final states, one which announces "yes" and another "no".
  It is as if automata with refusing (final) states were more powerful
  than the traditional ones.
  Note that this is the same as using the traditional automaton, and report
  "no" when it reaches a final state and "no" otherwise.
  I.e. the opposite of the normal ones. Such automata could not be easily
  merged into the other ones, but that is not needed.

  There are other cases, like e.g. an automaton which tells "yes" if the
  input does not start with "a" and "no" otherwise, for which the traditional
  automaton is inefficient. In this example the traditional one would
  recognize all strings that do not start with "a", i.e. it would slurp all
  the text in most cases.
  An automaton like the one above would simply have an edge for "a" leading
  to a refusing state.
  Note that a lookahead which is: the RE must not be followed by "a"
  is not !a, which would allow "", "aa", "aaa", ..., but is V* - a {<char>}*.

  We can also think to the automaton that recognizes the EOF as one
  that recognizes a condition, and thus needs to be more powerful.
  Representing EOF as a special symbol simplifies this since it reduces
  it to the recognizion of a symbol.
  We can also think that instead of having an automaton that tells "yes"
  if there are no characters, and "no" otherwise, we can have an automaton
  that tells "yes" if there is one character and in such a case, since the
  lookahead is negative, we announce failure. I.e. we revert back to the
  normal automata and handle negation outside.
  After all, we are dealing with the length of the remaining text, which
  could be seen as something out of the pure realm of languages.

  Is this perhaps one of the reasons to have the special character EOF?

  The complement is another thing. To state that there should not be
  even one character, the normal automaton for one character must be used,
  and when it matches, the condition is satisfied. To put it in another
  way, we need simply take the automaton and state that the final states
  are the ones to reject, which is different from building the complement.
  What perhaps we want, to avoid to use a negative lookahead here, is
  an automaton which is able to recognize the empty string in another way,
  i.e. to reject a character. Perhaps it is something like a stricter match.
  Since lexemes cannot be empty strings, we can state that the recognizion
  of the empty strings is successful when no characters are present.
  A lookahead such as {a | ""} should then match if there is an "a", or
  if there are no characters at all. I guess that to do it there is a need
  to introduce rejecting states. This makes the whole treatment of automa
  more complex. It does not pay off also because negative lookaheads are
  useful in general, and solve the problem.

  How to implement lookbehind? Recognizion is not difficult since we have
  to match the reverse string. There are no problems of ambiguity since
  we know where the lexeme starts, and thus the split is known (which is
  not the case with lookaheads). However, we need to read the text backwards,
  which can immply reloading blocks!
  It is quite expensive to check the presence of a lookbehind when scanning
  forward the input since it can start at any position.
  How jflex did for the anchor? Probably it checked it before entering the
  recognizion loop, making sure that a couple of characters were available.
  This test is done for all lexemes, but it is fast. It can be done like
  this because it is the only one lookbehind.
  In general, the normal recognizion can be done, and when a lexeme has
  been recognized which has a lookbehind, a check made that it is present.
  The other solution is to enter the recognizion of that lexeme only when
  the lookahead is present. This means to have an automa which recognizes
  all lexemes (to be used when the lookbehind is there), and one which
  recognizes all but that lexeme. Well, better to use the one which recognizes
  all and descart the recording of the final states when the undesired
  lexeme is the only one recognized.
  There is a need to cater for longest also here since there could be
  several lexemes which are the same except for the lookbehind, e.g.
  aaa \ r1  and aa \ r1, and when "aaa" is present, the first must be
  chosen.
  Here, and in the case of lookahead, the engine need go beyond the first
  final state it encounters of the lookbehind only if there are several
  which have a common prefix. When building the automa, if there are no
  several like that (and in the case of lookaheads if the edges do not
  lead to states that belong to r1), the edges outgoing from such a final
  state can be removed.

- a lookahead can also be a mix (set of alternatives) of positive and
  negative lookaheads so as to allow to define $ as \r | \n | \r\n | not <char>.
  How can this be implemented? The inclusion of the positive ones in the
  automa makes it recognise them, and the inclusion of the negative ones
  followed by a test that none have been detected makes the rest. Of course,
  if both a positive and a negative ones are recognized, that is an error,
  and can be reported at generation time.
- with negative lookaheads, the automa must also recognize r1, not only r1 r2,
  otherwise it is able to tell when it is not there.

- lookahead: longest r1 + longest r2 perhaps means that {a|ab} / {b|ba}
  does not match ab. This seems strange.
- lookahead: when r1 r2 has been recognized, we are sure that an r1 followed
  by an r2 is there. The only problem is to find the split.
  A drastic mechanism is to go back at the beginning of r1 r2, and then to
  recognize again r1. When a final state of r1 is found at a position P,
  an attempt is made to recognise r2. If it is recognized and its end position
  is the end of r1 r2, then P is remembered. The process continues until
  the cursor reaches the end position of r1 r2. At that point the last P
  is the good one. To improve a bit, this process can start at the first
  position at which an r1 ended and recognize there an r2, and end at the
  last position an r1 ended.

- the problem with TDFAs is that they have actions on the edges. This
  means that it could be difficult to compress tables. But if tags are
  used in few places, that could still be possible. A way to store those
  actions is to number them and add to each edge the number assigned to
  its actions. This means doubling the tables. Could it be possible to
  compress the two tables separately? The actions table could be small.
  Anyway, at each transition done there would be a need to test for actions,
  which slows down the engine. Better to mark as special the states which
  have incoming edges like that so as to skip the test in most cases.
  The difference with respect to Kearn's method is that Ville's throws
  away redundant data while making transitions, while Kearn's collects
  them and processes them afterwards. For few tags (one per lookahead?)
  which is best? Is there probably no need for several tags? If lexemes
  do not overlap, there should not. Probably not simple to figure out.
  Another possibility is to build a DFA for lexemes with r1 r2 in place
  of r1 / r2 and when a lexeme has been matched which has a lookahead
  in its rule, use then a second FA do split it. Probably it could do
  the processing needed after the first state of the DFA which can belong
  to r2. Remember that the problem is to find the split, which is in one
  of the positions at which a r1 ends and a r2 begins. These positions
  are a set of positions somewhere in the middle of the string.

- when the lookahead has a known, finite length and does not overlap
  with the tail of r1, it could be possible to simply subtract that
  length to the cursor.
- I can store the ambiguous pieces of DFA as a TDFA, with lists of edges
  instead of tables, somehow slow, but small.
- the problem is the detection of the end of r1 so as to set the cursor
  to it, not the matching of a lexeme. This is why it could be possible to
  do something at the end instead of during matching.

- it is possible to record the positions of the ends of r1 as an arrays of
  bits, and match back r2 stopping at the first accepting state of r2 which
  is an end position of r1. Note that proceeding from both ends inwards does
  not avail since the fence it not necessarily in the middle: it can be the
  first or the last of such positions.

- tagged trasitions: probably the position stored in tags is the one after
  the symbol on the edge has been read.
- can a same tag occur in several edges?

- simplify |=M : it must be defined in terms delta, etc., instead of
  sequences of configurations. It seems defined in terms of the final
  result, but in so doing it leaves dead ends. See the example in Ville's
  thesis: there are configurations linked in |=M which have in them the
  initial state, but then there is only one which leads to the final
  one. This means that the second is a dead end. Probably it can be removed.

- what is important now is to understand what can be precomputed in the
  simulation of the TNFA.
  Remember that when simulating all moves of a NFA, the assignment to
  the state variable can be recorded as actions instead of recording the
  value assigned. In this case the sets of assigned values are finite,
  and therefore they can be enumerated and that number used as state
  of the DFA. Remember also that "state" means the set of values of all
  entities whose value can have been changed as a result of making a
  transition.
  With TNFAs we can be lucky and see that they can be enumerated as well.
  However, recording actions in them does not make the result of those
  actions known. Well, that is not a problem since after recognizion the
  actions could be visited and executed. Alternatively, they can be done
  while making the transitions.

- negative lookaheads with empty string.

- let's suppose that a TDFA can be built. I guess that it is a lot slower
  than a DFA, unless it is possible to perform the extra actions only on
  some states. The states which have even one transition with a tag should
  be marked, and the transition performed by handling also the tags.
  Of course, since a NFA performs a number of actions for all transitions,
  the extra one to handle the tags in it could introduce an acceptable
  penalty.
- there are several tags with lookaheads (albeit one per rule, or alternative)
  because two lexemes can have the same rule, but with the lookahead operator
  in different places.
- I think that an algorithm which takes space which is proportional to the
  length of lexemes, but fast, could be acceptable since lexemes are not
  long. The longest ones are comments (but on them there is very seldom a
  need for a lookahead). Probably there is only a need to store some positions
  marks in a bit array, or a sequence of integers for the relevant ones.
- the Ville's NFA construction seems to lead to more states than the
  Thompson's one. Each terminal has a state and then (a|b|c) has three
  (plus perhaps an ending one). But then there is a list of start states.
  I think that to make the ast_to_efree_nfa work, every alternative has
  a catenation, but was seems strange is that regexp_comp creates a
  catenation with right = null, which is not handled by ast_compute_nfl.
- the e-free NFA has already computed in it the e-closure. I guess the
  tagged unambiguous one.
- get the papers of Ville's thesis 40, 14, 4, 11
- Ville: tell him to explain emptymatch for | because there is a priority
  there
  ... how this relates to |- M and |= M ?
      I guess is should be |= M, but check.
- how is it possible in a state to make a choice of transitions (and thus
  tags) without knowing which one among the many that are possible in it
  will lead to a match? The definition of |= seems to trace backwards from
  the last moves down.
- Ville uses the dragon book algorithm to construct directly a DFA for
  a regular expression stopping when it builds an e-free NFA.

- I have the impression that the whole point in the TDFA building is that
  states can be equated when they have the same TNFA states in them and
  the same amount of values for each tag because it is possible to make
  them equal by executing reordering commands. Note that an automa has no
  other information than the state where it is. There is no need to carry
  along any information regarding the transitions done. Therefore, two
  states that can become equal by reordering tags, are indeed equal.
  Each TNFA state occurs at most once in a TDFA state (priority rules
  do this), and I guess that each TNFA state has attached to it at most
  one value for each tag. Since tags have an initial value, we can say
  that each state has attached one value for each tag, and that it is
  possible to reorder them. The problem is that it is slow. Ville says
  that without this the states increases a lot. When? Perhaps when there
  is ambiguity? What will be if I do not do it? Unfortunately, there is
  at least the storing of the position, but probably that can be attached
  to the state instead of to the transitions.
  Now, a TDFA has a way of solving the ambiguity, but my lexer accepts it.
  I.e. there can be two lexemes which are the same except for the position
  of the lookahead operator. I do not want to loose this. Thus, check if
  a TDFA handles it. However, the lexera must have only one point to go
  back to. This means that it will take the longest r1 among the ones that
  match. Teke this into account in the discussion about longest r1 +
  longest r2.
  -- how behaves libtre on example 3.1? Probably try it on ((a)b) | ((a)b).
  -- when building the TNFA, libtre applies some of the disambiguation
     rules. E.g. the RE: (a)*|(b)* is ambiguous because it can match the
     empty string with both alternatives.
- there is a need to understand better the disambiguation, and also the
  basics of the TNFA first (like, e.g. the fact that a same tag can occur
  on several edges). This should lead to a matcher which simulates a TNFA,
  which is not the one in libtre because that is a POSIX matcher for REs,
  and not a generic one for automa.
- then there is a need to understand how all this can be applied to lexing.

Kearnes

- The Kearnes algorithm allows context to occur in any expression, not
  only the ones at the top level. It claims that without it one cannot
  define a pattern for e.g. number and use it in other patterns.
  But why one should put a context in a number? And why should need it
  when a number is in another pattern. I share the idea that there is
  a need for delimiting the patterns in a way other than the use of
  the longest match rule, i.e. that it is better to specify in rules
  what are the characters that belong to a lexeme. I am not sure that it
  is altogether possible to get rid completely of the longest match rule.
  I am not sure that there is a need for having contexts in subexpressions
  (to reuse a pattern, they could be allowed and be irrelevant).
- Brozozowsky for the AND and MINUS.
- Kearnes says that in his thesis he shows an algorithm for REs with
  AND and MINUS, but that the result is a slow, complex DFA.
  I guess that it could be the combination and AND and MINUS which causes
  the difficulty.
  The algorithm in the paper seems not to build a DFA, well the one that
  builds the parse seems not, because the recognizer builds a NFA.
- Kearnes allows arbitrary left contexts and one-character right contexts.
  Interesting, but limited. The interesting part is the one which builds
  the FA from the expression, and the parse because it can be used to
  implement arbitrary right contexts.
- the TNFA of Ville, the matcher libtre, included in all positions the
  start states. A similar technique can be used to put all the start
  states of lookbehind to as to recognize them? I think so. When a
  state has been reached which is a final state of a lookbehind, we are
  sure that at such point in the text, a suffix of the text before that
  point contains an instance of a lookbehind. Notably, we do not know
  where that instance started.
- an interesting idea is that a DFA is built by precomputing all the moves
  that a NFA does: even if the NFA has more complex states, such as AND
  and NOT states, it is possible to do it. Simply note the states that it
  reaches when an input is processed.
- probably Kearnes works because it knows that there can be only one
  character lookahead, and thus it implements edges to match a chararacter
  as e>{char}, any. Otherwise what reason there could be?
  Constant lookaheads are not difficult to support.
  Probably here, by having the automa always one character ahead, it
  is possible to represent directly in the NFA the context.
- it seems it has found an algorithm to build the DFA without the NFA,
  but simpler than computing nullable, etc?
- probably it is possible to use Kearnes to implement lookaheads by using
  the parse extraction but then contexts cannot be used in inner REs.
- it seems it addresses greediness in parsing, but not in the DFA, which
  I do not understand.
- one of the problems of Kearnes' and Ville's and other algorithms is that
  they address the matching of a RE in any position in the text. This could
  be good for searching text, but not for lexing.
- Kearnes idea of scanning backwards the text is not practicable.
- to match a RE with a lookbehind in a string, i.e. find the first occurrence
  of it, is easy (as long as one is not interested in knowing where the
  non-lookahead part of the RE starts, perhaps). But a lexer advances in
  the input, and thus after a match it returns, and the next time it is
  called it must return another match at that position, matching the
  lookbehind (if specified in the RE). This means that it must remember the
  previous state not to loose the information of what lookbehinds it has
  already matched.
  The issue is that when processing from left to right, it is possible to
  make all the calculations necessary to detect what lookbehind is present.
  What is impossible is to know that a lookahead is present (unless we
  actually ooked ahead). Not knowing it, we cannot move to a state that
  signifies recognizion of a (sub) RE. Probably that is possible at
  the top level. Kearnes infact allows a lookahead of one character only
  (even at the topmost).
  However, when allowing lookaheads, and lexing, it seems also not so easy
  beacause one thing is to find the first occurrence of r1 r2 in a string
  and another is to determine what could be matched at the position after
  r2 taking into account what lies before (which is in r1 r2). I.e.:

                             i             current lexing position
       text  ................|....
                |  r1 |  r2  |             previous match
                        | r1 | r2 |        next match, good
                       | r1 | r2 |         next match, not good

  at position i, a r1 r2 with r1 ending at position i (and r2 starting
  there) is good, but not one in which r1 does not end at position i.
  So, when getting the next lexeme, we need to know where the r2 starts
  so as to accept only the one(s) which are placed there, and otherwise let
  the lexer go on until it recognizes one like that, or it passes beyond
  the point, and thus deems failure.
  Kearnes' method for lookaheads cannot be applied to interactive input
  when applied to support arbitrary lookaheads since it processes input
  from the end.

- parse extraction and contexts are related, but are not the same.
  Keanes' does parse extraction. Having parse extraction allows (it should)
  top-level contexts, but not subexpression contexts.
  A way of allowing lookaheads in subexpressions could be to have two
  FAs: one that runs ahead of the other. The first is run to match lookaheads
  only. When is stops, the second is run starting at the lexing position.
  When the second advances, so does the first. At any position the second
  can know what lies ahead. Can I use it for top-level lookaheads?
  Can turn it into a DFA? A problem is that it must recognize only the
  lookaheads which can occur at that position, and not run away searching
  beyond that.
- clearly, for lookbehinds, we know when in r1 r2, r2 starts. It is
  difficult to tell the split in a r1 r2 in general, but it is simple
  to tell in a place if there is a r1 before and a r2 after.

- examples: (a|ab) / ba

  this shows that if we remember the first state at which r1 is recognised,
  then with text abba it would parse it as a / bba, which is wrong.
  And if we remember the last, then with text aba, it would parse it
  as ab / a, which is wrong.

- there are cases in which it is possible to build an automaton which
  ends in different states for different splits, i.e. it can have attached
  some information to end states to tell what the split is. The (a|ab) / ba
  is an RE for which this is possible:


        (0)--a-->(1)---b-->(2)--a--((3)) <1>
                            |
                            `---b-->(4)--a-->((5)) <2>

  when an end state of r1 is reaches, its position is remembered, and
  when the recognizion ends, we take as split the position of the state
  which corresponds to the one associated to the data associated to such
  end state. By introducing the associated data in the minimization
  (as we do with lexemes) we avoid to unify states which should not be.
  However, the RE: a+ / aa shows that this is not possible in general.

                 ,-a-
                 v  /
        (0)--a-->(1)---a-->(2)--a--((3))

  Probably the two-automata can work.
  If I can recognise a r2 by reverting the string, then at each r1 r2
  position I could recognise backwards a r2, and find (perhaps) the match.
  Or perhaps, I need to recognize backwards r1 r2. Is there a way of
  combining these recognizions forwards and backwards to do it?

- perhaps its construction of the DFA is similar to that of the Dragon
  Book with nullpos, firstpos, apart that the latter is optimized?
  Perhaps nullpos, etc., allow a faster construction since precomputes
  properties which are then used several times?
  It seems that the Thomphson's construction leads to have pieces
  of NFAs which are 1:1 with the syntax three, in which the start and
  end states correspond to the positions before and after in the syntax
  tree. What I do not understand yet is the p.mid position of Kearns.
  The algorithm of Kearns seems related, but slightly different: it uses
  the three as a representation of the NFA. The function next() acts on
  the three and computes the states reached.
- probably it is possible for a lookahead operator to extract only what
  parse tree is strictly needed, or even better, just the positions.
- probably Kearns parse() wrorks backwards because he knows where the
  match ends, but not where it starts. If he knew where it started,
  parse() could work forwards. Note that parse() works backwards because
  of the way it handles concatenation probably. Note also that even in a lexer,
  in which REs are matched knowing where they start, the subexpressions
  are matched, but we do not know where they start.
  Probably it is able to build the parse because it has the states,
  while in the string there are only the characters, and them are not
  sufficient. E.g. lookahead: once matched r1 / r2, i.e. r1 r2, we know a
  number of places in which a r1 ended (and can record them). We have to
  select one of such places for which the remaining string is also a r2.
  Probably parse() walks backwards and finds it. How?
  Well, parsing backwards allows to know where a r2 started, and then,
  knowing also where a r1 ended, we have it done. Having the states is
  even better since there is no need to carry along all the nondeterminism
  of a NFA, which works on characters.
  But then, I can also match r2 reflexed and stop at its first match where
  a r1 also matches. The matches of r1 can be kept in a bit vector.
  This parsing back is not much different from what Earley does: the parse
  is built from the items lists backwards. Note also that probably this
  is not introduced to handle ambiguity.
  I guess that the disambiguation of parse() takes anyway into account
  to let the rest of the RE match.
- working backwards, how does it handle greediness?
- Ville's method allow to record less data because it records only what
  is needed for locating tagged subexpressions, while Kearns keeps all.
  However, Ville's makes all its calculations during matching.
  Is it possible to record less in Kearns?
  Kearns is good for parse extraction, but if I have only to locate the
  lookahead, then it is even cheaper to match the r2 backwards.
- I think that in Ville's, it is only on transitions which have a tag
  that there is a need to do an action on transitions. Yes, but since
  it does nothing when reaching states, this means that it does everything
  on transitions.
  Unfortunately, Ville's cannot be reduced to work with actions on the states
  because there can be cases such as t0 a t1 | b which are:

             ,-------------b------------>
            ()-e/t0->()--a-->()--e/t1-->()

  that lead to an e-free NFA ... run the libtre and see it. It should
  have at least an edge with a tag comimg from going to the same state
  as another edge without tags.
  This means that it is not possible to set the tag (and make all other
  reorderings) in the arrival state because not all edges have that tag
  or a tag altogether. Even the case r1 / r2, which are connected
  by a e/t0 edge, could lead to a NFA in which that property (i.e. all
  incoming edges in a same state have the same tags) or not?
- lookbehind: it should be possible to add all the starting states
  of lookbehind to all states so as to know that a lookbehind is present
  as a suffix of a recognised lexeme. Note that a lookbehind is a suffix
  of the previously matched lexeme.
  How is the effect on transition tables? Do they become larger or denser?
  Treating the positive and the negative ones seems simple.
- how to handle negative lookaheads? By checking that they are not there.

- using a DFA with Kearns, the origin NFA states must be kept.
- implement a Kearns parse() and see how it works.
- making parse() work forward can allow to support contexts in subexpressions?
  (e.g. have states in which the special action to parse is called ...
  perhaps that is not right)?

- is Kearns algorithm correct with respect to earliest-longest, greediness,
  etc?
- is the possibility to have contexts in subexpressions useful? Why not
  to provide it, even in the restricted form of Kearns?
  When the right context is one character only, they can be supported
  easily.
- if it is possible to do it with one character lookahead, it should be
  possible to do with more


- another, perhaps bare algorithm could be to match r2 each time a r1
  has been matched, and remember the split position. Then proceed to
  match a longer r1 and a r2, and update the split if matched.
  At the end, the last split is the good one.
  I have the impression that it is not possible to match r2 by adding
  all its start states at the end of r1 since when we would reach an
  end state of r2 we would not be sure that a r2 started at the split:
  it could have started earler, overlapping r1.

 
 * Comments
 *
 * What lies between lexemes is not a particular thing: it is intrinsic
 * in the notion of having text in which aggregates of characters make
 * up lexemes. It is like a background, the support on which lexemes lie.
 * This role is played mainly by whitespace. Comments can also be used
 * with the same purpose. In the following, they will be collectively
 * referred to as comments.
 *
 * Comments are not lexemes, but anyway language entities: they could be very
 * important for the information they convey.
 * They are not lexemes. Lexemes are words, numbers, etc., the elements of
 * the language. They are the basic constituents of the syntactic rules.
 * Comments are not like that. They are statements of another language,
 * often the natural one, which are eclosed in dedicated delimiters to allow
 * a lexer to isolate them so as not to mix them with lexemes. The fact that
 * they can be detected by a lexer does not make them lexemes, not it does
 * the fact that they need be formatted or transformed when a language
 * translation need be done. It is not surprising that sometimes a regular
 * grammar is not sufficient to generate comments.
 * Semantically, comments can carry information relative to the following
 * lexeme, like e.g. the ones which document a method.
 * There are cases, however, in which they carry information on the preceding
 * lexeme, like e.g. when a statement has a line-end comment, and cases in
 * which they are in the middle of a statement (like e.g. line-end comments
 * in long statements). In many cases they convey information for a whole
 * phrase.
 *
 * Comments can be bracketed comments, which in some languages are nested
 * (and thus require a CFG), and line-end comments.
 *
 * There could be languages in which there are tokens with differing comment
 * syntaxes. I.e. tokens which have some comments and tokens which have others
 * in a same language. E.g. when a language includes pieces of text of
 * another one. A grammar could allow to have pieces of several programming
 * languages in a same text, having thus multiple comment syntaxes, say, a
 * Pascal module followed by a Java class, the former followed by a Pascal
 * comment and the latter preceded by a Java comment.
 * A lexeme would be matched only if it occurs with that comment or none,
 * but not with another kind of comment. E.g. in a grammar for Java+Pascal,
 * a "class" preceded by a Pascal comment would not be recognised as a Java
 * class. More precisely, matching is what is defined by the complete BNF.
 * When a lexer can match pairs of (comment,lexeme), then it returns a match
 * only when both are matched.
 *
 * Between two lexemes there can be two comments: one following the first
 * and another preceding the second. In a lexicon which has only one kind
 * of comments they would look as one, but not in a lexicon which has several.
 * Note that even supporting several kinds of comments (e.g. Java and Pascal),
 * this could be insufficient to support several languages at once unless
 * lexing be contextual. E.g. suppose the first language has identifiers which
 * are alphabetical only, and numbers, and the second language has identifiers
 * which are alphanumerical, then a sequence of letters followed by digits
 * would always be interpreted as an identifier of the second, and never as
 * one of the first followed by a number.
 *
 * Normally, text is made by comments followed by lexemes separated by
 * comments, and ended by comments. All comments are optional unless when
 * lexemes need be separated so as not to collapse.
 * In principle there could be cases in which comments are not optional.

- there are cases in which special comments need be parsed, like e.g.
  the case of javadoc. In javadoc, special comments are placed before some
  declarations.
  To specify them in the grammar there is a need to state that they
  can have whitespace and ordinary comments in front of them, as all
  other lexemes, but ordinary comments may not start with the special
  comment / ** delimiter.
  This could be done by having a dedicated rule for them, and mention it
  in front of method declarations, field and class declarations.
  This would be one case in which a comment has something in common with
  another element. I.e. special comments would also match the rule of
  the ordinary ones (unless something is done there to make an ordinary
  one not to start with / **).
  There is also a need to process the @param, etc. clauses in them.
  This means that there is a need to know the internal structure of them,
  which cannot be done if they are lexemes. In these cases it is better
  to take them as lexemes, and then to parse them with a second parser
  with a dedicated grammar for comments.
  - javadoc: ambiguity between / ** and / *.

 * The first need thus is to specify where comments can be placed and which
 * comment is allowed in any place. BNF is the best candidate for it.
 * Having a complete BNF, one which defines entirely a language (including
 * the lexicon) is a way of defining completely and unambiguously a language.
 * This does not mean that a complete BNF must be written straight away.
 * Normally it would be quite lengthy and difficult to read.
 * It would mention comments around any lexeme in the grammar. E.g.:
 *
 *      <class> ::= [<comment> public] [<comment> static] <comment> class ...
 *                  [<comment>]
 *
 * The main point with comments is that they are elements which are present
 * around all lexemes, which creates a need to have some implicit declaration
 * to avoid mentioning all them explicitly. All such elements can be
 * productions of a same rule, or they can even be productions of several
 * rules. What is important is that comments are the elements which are
 * implicitly present around lexemes in a BNF (and also the ones which are
 * mentioned explicitly and that replace the implicit ones, see below).
 * If it is allowed to mention comments in the grammar, what distinguishes an
 * element which is a comment from one which is not is that the former
 * replaces the implicit comment which would otherwise be matched before the
 * following lexeme, while the latter would imply a comment in front of it.
 * Normal comments would instead be mentioned in the lexicon, and what
 * distiguishes them from lexemes is that they are implicitly present around
 * lexemes.
 * An additional difference between comments and the other lexemes is that
 * normally comments are discardable elements, i.e. not recorded in the parse
 * tree by the parser, unless told to do otherwise.
 *
 * This is an example of a complete BNF with comments:
 *
 *      <S> ::= <L1> [ <L2> ]                 becomes
 *      <S> ::= <C> <L1> [ <C> <L2> ] <C>
 *
 * However, if the trailing comment of <L1> is different from that of <L2>,
 * something different must be put at the end:
 *
 *      <S> ::= <C> <L1> <C1> [ <C> <L2> <C> ]
 *
 * The easiest is to state that each lexeme is replaced by <C> lexeme <C>
 * and that when the sequence: <C> lexeme <C>(1) <C>(2) lexeme <C> occurs,
 * the ambiguity is solved by matching a comment with (2) and an empty one
 * with (1).
 * When a parser is told to record comments, it records only the ones
 * which are present. If two comments are recorded between two lexemes,
 * then the first is the production of (1) and the second of (2); if
 * only one has been recorded, (1) matches the empty string and (2) the
 * second, and both match the empty string otherwise.
 * It is also conceivable to have some comments in some places which are
 * recorded and some in others which are not. This allows an application
 * to have the parser save only the comments which are relevant.

- Settle better the issue of having two comments between lexemes:
  of course, <comm> <lexeme> <comm> is a pattern that can be repeated at
  length allowing comments at the beginning and end. However, is makes
  two <comm> between lexemes, which is not the most intuitive, and it
  takes space in the parse tree also. Why not have it only on some lexemes,
  the ones which can have a comment after them which might not be the
  one in front of the following lexeme. This occurs only when there are
  several languages together, or when there are "regions" of the language
  with different comment notations.

- Can an implied or specific comment be something which is not repeated?
  Yes, it can be anything. Well, the question is whether comments are declared
  with the repetition in them, or if that is implied. One alternative is
  to define the default comments as <comment> and imply {<comment>}*
  between lexemes. Another is to define them as {...}* and imply <comment>.
  I have the impression that the latter is more general. The rule can be
  that whatever is defined as comment is placed in the complete BNF.
  This allows the user to define comments as, e.g.
  {<bracketed> | <line-end> | <whitespace>}* and have it virtually appear
  between lexemes, or define it as <comment> and have <comment> before
  lexemes. Then a rule would define
  <comment> ::= {<bracketed> | <line-end> | <whitespace>}*.
  A specific comment which is repeated should then be declared with a {}*
  around it.
  Well, this should work also if there is no default comment facility.
  In a sense, a lexeme like e.g. <L> ::= a {b | c} d, is stored as a single
  string. Well, this does not mean that the same must be done with comments.
  <L> ::= {<bracketed> | <line-end> | <whitespace>}*C <> ...
  could have its comments stored as a single string or as several.
  Is there a means to have them stored as several strings?
  How do we distinguish a comment like the previous one which is made of
  a sequence of comments which can be considered as lexemes, from one
  like e.g. {" "}* which defines directly the inner structure of the
  comment, or from one which is a mixture of both?
  We can state that if a {...}C is made of a group which contains only
  elements which are declared in lexis, then it can only be a sequence of
  1, 0:1, 0:, 1: such elements, and then they are stored as separate strings,
  otherwise they are stored as a single string.
  This is going to be too complex. Better take the simple solution to store
  them as a single string.
  Check the implementation.

- suppose a language has # as a lexeme, but that in a construct it has
  a # followed by no comment followed by a number.
  Two lexemes can be defined, one with comments after it and one without.
  E.g.:

        <hash1> ::= # {}C
        <hash2> ::= #

  Then the lexer should match the first or the second on the basis of
  what follows. This is not a problem since the automaton does it.
  The problem is that here there is a specific comment for a specific place.
  I.e. in a grammar a lexeme can occur in several places, and each one place
  can require a specific comment. If that is supported, then "no comment"
  must be seen as no comments including the trailing one, or better,
  <L1> {<comment>}C <L2> should mean that the lexer does not attempt when
  matching {<comment>}C <L2> to match the trailing comment of <L1>.
  Well, if a lexeme is defined in its rule as something which has
  a trailing comment, then it must be matched only if that comment is
  present, which means that either the lexer checks it after matching the
  something, or maked that check the next time.
  This unless the comment is optional. It is meaningful not to have it
  optional? Well, if it is not optional, the lexer tries to match it.
  Then it has to remember that it matched such a comment.

- An additional feature thus is to allow to mentioned explicitly comments
  in the grammar. There could be some restrictions:

      <comment> { {<nt>}* ...}

  how can we make sure that the comment gets in front of a lexeme, and
  not of another comment? Well, perhaps it can be. It could even be at
  the end. Well, if it has a reasonable semantics it can be. Say, that
  such an element is a comment, and that the lexer disables the normal
  comment matching until told to get a lexeme. If the semantics is that
  comments are matched as normal elements, and when they are directly in
  front of a lexeme, the comment of that lexeme is not placed in the BNF,
  and are not recorded unless otherwise stated, and do not appear explicilty
  in the parse tree, then there should be no problem. The only problem is
  that when several comments appear before a lexeme and some are optional,
  the association between comment as syntactic elements and comments in
  the sentence could be ambiguous.
  I can study better what is the meaning of an explicit comment in the
  grammar when it is not directly in front or after a lexeme. What is
  important it to define whether that is allowed and what is the resulting
  BNF. Once the resulting BNF is specified, there is no more questioning
  since what it there is what has to be mathced.
  E.g. when a comment is in front of another one, both are matched.
  Note that the same problem occurs when comments are declared in tokens
  because when they are not optional, they need be present.
  When there are several explicit comments there is a need to call the
  lexer in some special way. This could be difficult, and if that is the
  case, then probably comments should be allowed only directly in front
  or after a lexeme. Note that there is a need to tell the lexer what
  comments it must match, and if that depends on the place, that need
  be stored in the encoded form of the grammar, and thus taken into
  account when parsing and when building the parse tree.

 * One solution is to state that when there is a lexer, all lexemes (which
 * have no explicit comment specified in their rule) can be separated by
 * comments, i.e. any lexeme which is flagged as such. This is the traditional
 * approach, in which comments are lexer-wide.
 * This would not allow to specify languages which have several comment
 * notations, unless something is done to tell it.
 * This can be obtained by allowing to declare the comments in the lexis list:
 * the nonterminals which are in the lexis list, but are not in the syntax
 * represent lexemes which appear between lexemes. An alternative is to have
 * a clause to declare comments.
 *
 * Another solution can be to define several grammars and switch between them.
 * This can be done if the parser returns the position at which matching
 * stops instead of telling that there is no match because there are extra
 * characters at the end of the sentence. Also the lexer must be implemented
 * in such a way as to hand its buffers, etc. to another one, and probably to
 * simulate the end of text (eof) when the text of the second language begins.
 * This, however, requires to have several parsers as well and to call them.
 *
 * Another is to declare several lexers inside a same grammar and specify
 * which one applies at any point. This could solve also the problem of
 * contextual lexing by placing a scope on lexers.
 * There is a need to give a unique number to tokens among all lexis, and
 * also a need to manage several lexis lists.
 * There is also a need in the parser to call the appropriate lexer, which
 * could be a problem with the Earley parser because the advancing of the
 * cursor must be unique there, which is not guaranteed if the matching
 * of several rules in parallel requires to call more than one lexer at
 * some points. This solution seems not simple.
 *
 * Another solution is to specify in the grammar which comment syntax applies
 * to the lexemes generated by a nonterminal. The implied BNF is the origin
 * one in which each lexeme is preceded by a comment and one is also present
 * at the end. In order to define more easily the BNF, each lexeme is replaced
 * by a comment + the lexeme + a comment.
 * A dedicated notation would specify the comment rule that has to be applied
 * from then on, or to all lexemes which occur as production of a nonterminal,
 * and have a parameter which controls the recording or not of comments in the
 * lexemes list.
 * This does not prevent to specify comments for special tokens. E.g. if a
 * comment has been specified in a rule in front of a lexeme, it supersedes
 * the general one (see below).
 * Commonly, the comment would be something like e.g.
 * {<bracketed> | <line-end> | <whitespace>}*C.
 * The implementation, however, is not so straightforward because there is a
 * need to tell the lexer which comment to accept and for a lexer to declare a
 * match when a lexeme is preceded by the appropriate comment, and to backup
 * otherwise. Note that this is not much different from that needed to support
 * the next solution.
 * In a Java+Pascal grammar, when the end of a class has been scanned, and
 * possibly a Java comment after it, if the lexer finds a Java comment, then
 * it must match a "class", otherwise backup and match a "module".
 * Note that this solution is the only one which avoids to give several names
 * to a same token. If comments are in a lexer, there is no way (this it not
 * a very big problem, though).
 * This solution, however, is less powerful than the following one, and forces
 * to have a no-commment notation, and also it forces to indicate comments in
 * grammars (and to change the original ones since comments are never
 * indicated in the grammars present in specifications and standards).
 * Moreover, this needs be done in any grammar, not only in the ones like e.g.
 * the Java+Pascal grammar.
 *
 * Another solution is to tell in the lexer section which comments are in front
 * of what lexemes. E.g.:
 *
 *    <identifier> ::= {<comment>}*C <alpha> {<ahpha> | <digit>}+ {<comment>}*C 
 *
 * Replacements are useful to specify the placement of comments without
 * changing the rules present in a grammar, which could be very valuable
 * when the grammar is taken from some source, like e.g. a standard or a
 * language specification, and it changes frequently.
 * Replacements act as metarules that make occurrences of elements in the
 * grammar be virtually replaced by their definition. E.g.:
 *
 *    <identifier> => {<comment>}*C <> {<comment>}*C  -- is equivalent to:
 *    <identifier> ::= {<comment>}*C <identifier'> {<comment>}*C 
 *    <identifier'> ::= ...
 *
 * This should be done for all lexemes. It can be simplified by stating that
 * when the LHS is a shorthand, then one such rule is generated for all the
 * nonterminals that shorthand stands for. E.g.
 *
 *    <token> == <id> | ...
 *    <token> => {<comment>}*C <> {<comment>}*C 
 *

  It means that all <token>s have a comment around them. This feature
  would not be strictly needed if a notation for default comments is provided
  and a rule that states that each token rule which has no comments in it is
  replaced by one which has the default one (which would mean two replacements
  for token rules which have a replacement that does not contain comments).
  However, the feature is there for other reasons as well. Thus, there should
  not be a need for a notation for a default comment.

       <token> => {<comment>}*C <> {<comment>}*C

  Minimization of automa!? no problem, they are taken out. Well, the one
  in front of them, but not the one at the end. This was perhaps what was
  at the basis of the idea of tail minimization: to fold the tails, for which
  there was a need to record the set of lexemes recognised before the common
  tail. I guess that it could be possible to examine the rules and compare
  the last elements to detect the common tail.
  But probably it is possible to factor this out by excluding it from
  the automa, and the one in front as well, and using instead something
  specific, like e.g. to remember what comments have been declared and
  make a dedicated match by calling the lexer again or recycling in it.

  If there is no default, there is probably no need for an empty comment.
  Check that a shorthand LHS replacement generates replacements for the
  ones which are not present.
  If a token has no comment in front of it, then it would match if the
  previous one has no trailing comment ... well, if the BNF is that
  <C> <L1> <C> <L2> ..., then a comment would be allowed before <L2>.
  But then how to represent a token which must not have comments in
  front of it? There would be a need to define also <L1> without comments,
  or alternatively to state that in the grammar (see below).
  The latter is the last resort and it allows to represent any possible
  special case of comments.

- shorthands are macros. But when they appear in a RHS in grammar (not lexicon)
  what is the meaning?
  If they are macros, would it be better they are general rules, not only
  alternatives, and not defined in lexis.

- The need for replacements stems from the need to place comments.
  There is another reason, that to specify constraints, like e.g.
  <keywords> => <id> ={<>}, unless I support something like e.g.
  {alpha}+ => <id> ={<>}, which is a way to spare shorthands, but there
  is a need for shorthands anyway for <id> ::= {alpha}+ ~{<keyword>}.

- Note that this solution makes the case of the two languages more complex
  to declare since there will be a need to have two token rules for a same
  token which occurs in both languages, while there would be only one if
  we have a notation to specify which comments are in force.
- It would be convenient to tell only once that lexemes can be preceded
  and followed by comments, and to specify only the exceptions (e.g. BOS is
  not preceded).
  A comment at the end is allowed by having comments after lexemes.

- Comments can only be at beginning or end of replacements, and not in groups.
  E.g.

        LEXIS a | b ...
        COMMENTS <bracketed> | <line-end> | <whitespace>    -- default
        <L1> => {<comment>}C <>                             -- specific
        <L1> => {}C <>                                      -- no comment

  What is the semantics when a token rule has two alternatives, one with
  one comment, and another with another one? There would be a need to
  match an alternative only when its comment is present. This is not simple
  to implement. It is thus disallowed.

  Suppose comments are declared in token rules, then what would be the
  meaning of that when the lexer is told not to discard comments?
  It would seem strange. This in favor of the thesis that they should not
  be declared in token rules. Howerver, it is true that the lexer recognizes
  comments when it is told to deliver lexemes. What could be somehow strange
  is the behaviour of a lex() which scans comments implicitly before lexemes
  when it is told to save them.

- is it possible to solve two problems separately: the implicit declaration
  of elements to make them present around lexemes, and the declaration of
  discardable elements. Well when they must not be discarded, why do not
  we treat them as normal elements, which are then stored as part of the
  parse tree instead of recording them in special elements of the lexemes
  list? To do it, there is a need to use replacements in a different way:
  here the bodies of replacements are placed in the grammar, so that
  a <comm> is not part of the lexeme, which is instead the case for all
  other elements of a replacement. Well, but replacement had not been
  introduced to allow to declare comments (among other things)? Having
  them defined to introduce a new <lexeme>' which replaces the element
  occurring in the grammar works only when comments are discarded.
  To keep this semantics and keep the comments, I had to introduce the
  idea to save them in the lexemes list. Why not investigate the idea to
  have a second kind of replacements, or have the elements marked as
  comments bubble in the grammar and not be part of the rule which
  defines the (replacement) element?
  The problem is that now the lexemes, as seen by the grammar are
  the replacements, which include comments. This means the effectively
  the resulting BNF has comments in token rules and not at their
  occurrences. Check that the treatment of lexemes for ST, EM, ...
  does not prevent to handle properly comments.
  It is perhaps possible to extend shorthands to make them work as macros,
  i.e. elements which are effectively replaced by their definition in
  applied occurrences? They could be used to define lexemes having them
  be replaced by <comm> <lexeme> ... or whatever the definition is.


- in all solutions there is a need to flag the elements which are comments
  when comments are declared in token rules and explicitly in the grammar.
  1. because lexemes which do not have one in their rules have the
  default one (i.e. {c1|c2...}*), 2. because they are the ones which when
  saved, are kept separate from lexemes. They have a meaning which it not
  that of a piece of lexeme.

- strictly speaking, there is no need to have a EOF lexeme to allow for
  comments at the end: they can be attached before and after lexemes.
  We can state that lexemes which do not have an explicit comment in their
  rule or in front of them in the gramar have the default one in front
  and after. This settles the BNF, but then there is a need to make a
  call at the end if the lexer processes normally comments before and not
  after.

- comments as lexemes also cannot be empty, they are only optional

ok- comments could not be specified as lookahead zero-width elements in
  token rules because there is a need to advance the cursor.

- normally there is a need not to keep memory of comments in lexemes.
  In few cases there is. Obviously that can be done by storing comments
  in lexemes, which allows applications to retrieve them, but it requires
  also to discard them when converting lexemes in whatever form is needed.
  When comments need be discarded, this is extra work.
  This is needed, e.g. to translate a Pascal program into a Java one:
  comments must not be lost. For such an application, a dedicated grammar
  can be provided in which comments are not declared as discardable
  items.
  A solution is to tell the parser to record or not the comments, and
  probably even to specify which comment to record.
  Better to specify it in the grammar.
  The parser can record comments in the lexemes list. This allows
  to get the lexeme (including comments) which precedes or which
  follows a given one. This allows to implement the action to get the
  previous or following comment(s) (if any).

- is it better, when the parser is told to save comments, to store a
  string for {<comment>}*C or several strings? Note that when transforming,
  e.g. a pascal comment into a java one, there is a need to scan it
  again to change a * / in it in something else. If it is stored as
  several strings, then most comments would need several entries in
  the lexemes list because they are preceded and followed by whitespace
  most of the times (which would be stored also).
  It is as if we recorded a lexeme which is [<comments>]. Or probably an
  optional one which is <comments>. But when there is
  a need to record comments it is because then they need be processed, and
  thus it can be better to store them individually. A solution can be to let
  the user define it.
  I.e. if it defines <comments> ::= {...}+ and in replacements
  [<comments>]C <>, then only one string is stored, otherwise if they
  are: {<comments>}*C <>, then several are stored.
  However, take into account that there is a need to analyse how comments
  are specified: as group, optional, repetition, etc. to do that.

  How to specify that comments are discarded, or otherwise.
  E.g. a general clause on comment declaration and/or an operator
  in comment occurrences. E.g. {<comment>}C~.

- how to treat the case in which whitespace is not interesting, but comments
  are because they contain some directives?

- it seems that there is a need for a way of specifying exactly what needs
  be kept and what not, and what rules define it. If we have only an
  intra-lexeme element, which can be comments and whitespace, how can we
  tell what to keep, or process its pieces according to what they are?
  The best would be to have a small number of construct that allow to
  specify all the variations of the ways comments need be handled.

- in hand-written lexical methods, they are scanned at the beginning of
  every method so as to relieve callers to do it.
- the reason a lexer processes comments before a lexeme (and not after it)
  is that in so doing it allows callers to access the lexeme.
- when lex() is called in an application other than the parsing engine
  it scans only the comments before the current lexeme, not the ones
  after. It would require to save the text containing the lexeme and the
  trailing comment.

- there is perhaps a need to factor out comments internally from replacements
  so as to know it and avoid to rescan it. And there is also the need
  to store separately the comment when it must not be discarded.
  Suppose there are several comment syntaxes, and that the lexer has to
  match each token it is told to in sequence. At the first one which
  allows a comment it has to remember the end-comment position, and
  to start from it when matching the next token which allows the same
  kind of comment. This is not a problem with type-3, Lex-type of lexers
  (the ones which impose a grammar-independent tokenization) since such
  a lexer recognizes at once all lexemes.
  Is it inefficient to match token rules in sequence since the comments
  would be scanned several times? I do not know if it is possible to detect
  that common factor. Well, it is. Minimization does it.

- if the automaton is built from replacements, then it must treat comments
  in some special way and not include them in the automaton as such,
  otherwise it will scan them as part of lexemes.

- do not mark and save characters when scanning comments, but at least
  do a backup at the last final state as for the other lexemes. Perhaps
  there is a need to disable saving only when the automaton is such that
  there is no such backup to be done. To backup there is a need to save.
  ... this should be done only for comments which are specified to be
      discarded. It should be known from some attribute in the node.
  ... the test is done in the if statement that is entered when reading a new
      block because when the comment is in the current one nothing special
      should be done.
  ... states which belong to discardable elements only are marked.
  The start index for lexemes should be computed at the beginning and saved
  because is is not possible to determine the length as for the other lexemes,
  unless the length is computed in a different way (e.g. by rolling up the
  lengths of pieces). This in order to have the index to report errors,
  unless we state that there is no index, no length(), no toString() being
  comments discardable items, and thus no errors reported on them. But there
  is at least one error: comments not closed.
  Why it should not be possible to know the index? It should. Returning
  a string is a different matter since it requires to save text, but returning
  an index for error reporting it should be much cheaper.

- Even if the lexis declares lexemes with a comment in front of them, the start
  index of a lexeme is that of the first character of the lexeme, not of that
  of the comment.

- a lex() which skips comments is good when the parser is told not to save
  comments and when there is only one lexis. At the end the parser can call
  once again lex() and check eof(). This should be good anyway since eof()
  can be called only after a lex(). This call should scan trailing comments.
- when there are multiple lexers there is a need upon a lexer switch
  to call once again the former, check that it did not recognize any lexeme,
  then call the new one. Can this be done automatically by lex()?
  Well, if I specify the comment syntax at <nonterminal> level, then the
  lexer cannot figure out.
  If there are several lexers, then a same token must have several names,
  e.g. <id-java> and <id-pascal>. The idea to have one name only applies
  when the comments are at the <nonterminal> level with one lexer only.
  The fact that comments are specified in a lexer and even in token rules
  does not mean that comments are part of lexemes. E.g. we can have several
  lexers, each one with a default comment and with specific comments in some
  token rules. This would have the meaning that each occurrence of one
  of its tokens nonterminals in the grammar is replaced by a comment
  (default or specific) followed by the token. When a token is followed by
  another one with a different comment, it is also followed by its comment,
  and also when it is at the end.
  This would obtain the great goal to relegate into the lexer the handling
  of comments and not to place onto the parser the burden to switch lexer.
  Note how important it to tell what the complete BNF is in order to obtain
  a precise definition.
  Note also that a token can have specific comments before it and after it.
  Perhaps, if no trailing one is specified, the leading one can be taken
  to be also the trailing one.
  Well, I am using a lexis also as a means to factor out comments and also
  to obtain some sort of contextual lexing. Would not be better to decouple
  the two? When I will find a way to specify precisely tokens with constraits
  and contextualize lex(), I would use one lexis only!
  Note that my lexer is a bit better than Lex since in Lex there is a need
  to declare keywords before identifiers since it returns the lowest token
  number matched, and not the set of matched lexemes as mine does.
  Mine is thus more contextual than Lex.
  Having lex() treat comments in front of lexemes, it effectively matches
  two lexemes at once. This can be implemented in a single automaton,
  which recognizes the sequences: <comment> <token> or as two calls to
  the lexer with a check on the sequence. The former can be treated by
  generating automata from replacements before generating the automa.

- when the parser is told to save comments, it should call lex() telling it
  not to skip comments. One call before each lexeme (checking that it returns
  comments, in which case it saves them and then it makes another call),
  and one at the end (checking for comments again).

- a lexer which scan comments and lexemes in a single call for the notable,
  common case of discardable comments in front of lexemes is faster than the
  general one. E.g. if lex() does not return, but stays inside, loading of
  fields into local variables can be spared.
  For more complicated cases, lex() can be called to deliver comments alone.

- how can I avoid to forget to define comments in front of lexemes?
  By telling that there is a default. Lexemes which must have no comments
  must be declared with an empty one in them. But then the previous one
  can have trailing one. Perhaps, when an empty comment is specified, a
  test must be made that there is no trailing one from the previous lexeme.

  It is not yet entirely clear how a lexer with a combined automaton can
  recognize trailing comments. E.g.:

      class {...} / * ... * / { ... } module

  Note that here there can be a problem to distinguish the body of a Java
  class from a Pascal comment ... When they are not separated by a Java
  comment, as above, it seems difficult to say that { ... } is the body of
  a class or a comment for the module, at least difficult for the lexer.
  This shows that lexemes must be distinguisheable. When that is not the
  case, there is a need to have several lexers, or a contextual one.

- One which has an automaton that recognizes comments separetely can do the
  following:

     - once a lexeme has been matched, remember which trailing comment it
       supports,
     - when told to get a lexeme, run the automaton:

           1. if it gets a comment equal to the trailing one of the former,
              run again the automaton, then:
                 - if it gets an eof, return
                 - if it gets a lexeme which is not a comment, then return
                   else goto 3
           2. if it gets a lexeme which is not a comment, then return
           3. - if it gets a comment different from the trailing one,
                run again the automaton: { if it gets a comment, or eof,
                error,
              - if it gets a lexeme which does not support that comment}
                if it gets an eof, return
           4. if it gets an eof, return

  This can also be enclosed in a method that is in between the parser and
  the lexer.
  It can be possible to have one middleware method to be called when the
  grammar has several kinds of comments, and a simplified one to be called
  when the grammar has only implicit comments.

- I can record the supported comment rules into the dic entries of tokens,
  and eventually in some table of the parser or the automaton (perhaps
  better the first?)

- it is important to allow to specify syntaxes in which there are no
  comments, or there is no general comment so that the exact, complete
  form has to be indicated.

- comments, or better, discardable text, can be used to scan text in which
  lexemes are in the middle of other text which is irrelevant. To scan it,
  specify discardable text in front of the lexemes.

- if the comment in front of a lexeme has a prefix which it the same as
  that of the lexeme, it might not be simple to discard it: probably there
  is a need to buffer text until a state is reached which tells that for
  sure a comment is scanned. It is simple: if and when a state is reached
  that belongs only to comments, then discarding will be done.
  This is the case of javadoc comments.
- in such a case, there could a need for having a mechanism similar to
  Laurikari tagging to tell where the comment ends, otherwise it is not
  simple or possible to condition the recognizion of a token to that
  of the comment in front of it. No, it is not a combined longest match,
  but two longest.

- a solution to have parser+lexers which deliver comments without eating
  them vs ones which eat them is to indicate them in a different way in
  the grammar

- jflex and the others: the engine probably delivers the text of the
  last expression matched, which means that:
     - when no return is done, the engine recycles and restarts the
       building of the text (useful for descarding comments)
     - when a lexeme is made of several REs there is a need to collect
       in actions the text which the engine delivers for each of them.

- for a direct use of the lexer it is sufficient to support discarding
  and/or to support skipping of comments in front of lexemes. Well,
  if lexemes can have dedicated comments, this could be the same as the
  whole support ... perhaps except for the storing of comments.
  Having a notation for discarding (d) could allow to keep comments in
  the automata, let minimization reduce them, and a special state at
  the end of comments discard what has not yet been.

- there is a need to indicate comments if they are declared in replacements
  so as to let the engine store them not as part of lexemes if told to
  keep them.

ok- a solution could be that there is a special section in which one can
  declare comments, which controls what does that tokenizer which lies
  between the lexer and the parser. However, this might not allow to treat
  those cases in which there are several languages in a same text, and
  lexemes which are such only if they are preceded by nothing or by a
  specific kind of comments. When predeced by other kinds of comments
  they are something else.

ok... there is also a need to find a place in the grammar to refer to delimiters, telling what
  the tokenizer must discard, and that is simple, but there is also a need to tell that
  it is not referred directly or indirectly by the axiom.
  LEXIS <delimiter>(ignore)  ... but there would be a need to check that it is not
  used more than once, but this declares delimiter as a lexeme, which is good.
  IGNORE <delimiter> perhaps
  There would be a need to consider this as a declaration so as to avoid to signal
  that it is not derived from the axiom. Moreover, replacements such as
  <token> => [<delimiter>] <> can mention it. The first solution is perhaps better.
  Moreover, delimiters should not occur in any tokens sets except their own.
  Another solution could be to use replacements. I think I introduced replacements
  to tell that tokens can be prededed/followed by them, e.g. <token> => [<delimiter>] <>.
  If delimiters were declared to be ignored, then perhaps replacements could do that
  (but there should be a delimiter also at the end, before the eof).
  But perhaps later I found that it was simpler to make the tokenizer discard them.
  Actually, replacements serve to keep memory of comments, not to discard them, and
  thus I made the tokenizer discard them instead of using replacements.
    - ignore must be marked in the entries in parserdic, or perhaps in an_lexis,
      when finding an ignore we must set ST in it
    - it seems that storage is allowed in many places, such as replacements, where it
      should be not, and it is used in the grammar proper .. well, I think that ignore
      has nothing to do with storage, so perhaps it should be allowed only in the lexis list,
      which in lexis would become <storage> | <ignore>
    - it seems that in dictionary entries in the attr there is room for a new flag
    - in html there is a tokens set with pcdata and delimiter, which is rather wierd,
      but I guess that the check that this does not occur should be done only when
      -tokensSet is not specified


- probably the actual part of a token is that denoted by <>. All the rest
  should be discarded. To avoid confusion, all the lexemes that may occur
  in a context should have the same discarded part.
  There is a need to keep an internal position which is that currently
  reached after recognixing a lexeme, which is different from tok_end.
  The lexer should reposition to that if it is called with a different
  position? or should the user?

- I wonder if considering comments as part of tokens is the best
  approach. A comment before a routine belongs to the routine,
  an inline comment in the middle of an "if" statement belongs to it,
  an inline after an assignment belongs to the assignment.


- unique notation in the grammar for directives such as priority, case
  insensitive, etc. Java regex and Perl use (?...) which seems to be
  not intuitive. What is needed is something which allows for arguments,
  which means that names alone are not enough. A unique notation would
  relieve from clashes between names and terminals. E.g. ((prio = 4)),
  or #prio = 4#, or ::prio=4::, or **prio = 4**, or <:prio = 4:>, or
  (:prio = 4:), or <<prio = 4>>, or (-prio = 4-), or (* prio = 4 *).
  Proabaly there is a need for a notation which encompasses also elements,
  to be used in comments and in case insensitiveness. In this case a group
  can be used. Well, a notation which is bracketed but is not a group
  can perhaps solve the problem of the storing of comments as single
  or multiple strings. E.g. (: <bracketed>|<line-end>|<whitespace> :)C
  would mean that all the elements contained are comments and are stored
  separately, while (: <comment> :) would mean that they are stored
  together.
  But why use (:, and not simply ( as parentheses?, or
  #( <comment> )#C, or #+ <comment> +#, or (<comment>)c.
  Well, we already have {} to group, which have an indicator character
  attached to the closing brace, so we can also have another one.
  E.g. { <comment> }C.
  However, it is also true that this is not a group, but it indicates
  some property over a part of a rule, and thus it should not be
  confused with grouping. An advantage of using braces it that it would
  have a consistent nesting at no effort.
  It is important that the interpretation be not deceiptive. E.g.
  a { b | c }C d  would intuitively be interpreted as a {{ b | c }C} d,
  and less lilely as a {b}C | {c}C d.
  This is perhaps a reason to study a better solution. Enclosing parts
  of rules in parentheses leads to consider them as groups even when
  the parentheses have a different shape. It would be better not to use
  parentheses. E.g. a # b | c #C d. But then what could be the meaning
  of stating that a piece of the first factor and another of the second
  are comments? Insofar I have used {...}C as if it were a group.

  In java rexexp the (...) form is used to enclose the parts on which
  some special treatment is required.
  To have a common notation, however, we should have uses of a group such as:
  {<>}I for case-insensitivity.
  Well, we are not forced to use the same kind of notation everywhere,
  expecially if it is not appropriate.

ok - now (i) as ( i ): no longer a meta

- regexp notation: it is possible to use them. When a token rule has them,
  it is lexed apart. Well, there would be a need to use a regexp package which
  allows to scan a stream.



Handling of lexical errors

- when the engine finds no match, something should be done to proceed
  with parsing.
- errors: what the lexer does when no accepting state is found.
  Have some means to support localized and customized error messages.
- there seem not to be techniques applicable to detect lexical errors,
  like e.g. not closed strings. If and when any technique will be available
  it may be put in the lexer. For example, if the lexer advances for more
  than, say, 3 characters and then stops, the lexeme is considered to be
  recognised, and an error message produced.
- error recovery in parser


API

- describe well the interface between the lexer and the parser because
  the lexer can be supplied by the user.
  This could be particularly useful here because here there are no actions,
  which I have the impression were much used in Lex to overcome the
  deficiencies of Lex

Lex stores the characters of the lexeme in a string yytext and its length
in yyleng. A routine yymore directs Lex to concatenate the next lexeme
with the one present in yyext (instead of nulling yytext). A routine yyless(n)
restores the last n characters of the current lexeme back to be read again.
This serves when there is a need for lookahead, i.e. when there are
lexemes that are recognised only if followed by some given character, which
are not part of the lexeme, and thus must be reanalysed.
-- what jflex does for this?

The following methods are provided:

      lex():            recognize the next lexeme
      close():          close the input and terminate the lexer
      toString():       deliver the recognized lexeme as a String
      toChars():        same, as array
      length():         lenght of last lexeme
      index():          index in the stream of the beginning of the lexeme
      eof():            whether the lexer is at the eof

jflex:

- jflex makes a lot of mess about what lex() returns and also what it
  returns and does when an EOF is encountered

- both the constructor and the lexer throw ioexceptions of various kinds.
- the lexer can be tested for eof.
- the lexer has an endless loop which is exited only upon a user action
  which makes a return. This allows to stay in the loop to eat comments.
- it has then an inner loop which is exited when an eof is detected, or
  when there are no transitions with the current symbol to be done or
  when a state is found which has a nolook attribute (which seems to be
  attached to the states which have no transitions)
- the following indexes are kept in the input buffer:

      yy_markedpos:  set each time a lexeme is matched to the end of
                     it, and thus used as start index the next time
                     the lexer is called

      yy_currentPos:
      yy_startRead:  the index of the start of the token

  The following is defined as default action:

          if (yy_input == YYEOF && yy_startRead == yy_currentPos) {
            yy_atEOF = true;

  Why there is a need to announce an eof only when
  yy_startRead == yy_currentPos? Perhaps because YYEOF can be read but
  kept there in the buffer, and delivered outside obly when it is processed?
  The following methods are provided:

      yylex():            recognize the next lexeme
      yylength():         length of the matched lexeme
      yytext():           String of the matched lexeme
      yystate():          current yy_lexical_state;
      yybegin(newState):  force a lew start state
      yyclose():          to close explicitly the input (which is not done
                          by jflex)
      yy_advance():       private, it delivers the next extended character
      yypushback(int n):  private, it pushes back n characters to be reread

  I do not know how many of these can be called by applications.
  Jflex inserts some extra code when there are lookaheads to make the
  necessary pushbacks. Basically, it goes back to the position it had
  at the beginning of the matching of the lookahead.

  It provides also the current line and column, but at an extra cost.


- what yylex() returns? There is a default that the user can supersede.

- how jflex handles errors? How a caller can force it to skip characters
  so as to resynch?

- how does count lines and columns? Probably that is done with a
  clause in the token definition so as to spare counting them when that is
  not requested.

- make a comparison of what variabeles jflex has and what I have.

- Lurikari seems to add also priorities, thus introducing something similar
  to greediness perhaps, and thus obtaining more flexibility in what it
  matches. It does not say, though how it specifies it. It introduces a
  notation that matches all characters, which seems the same as jflex [^].

  - a regexp such as *b*c, a.k.a any* b any* c has an automaton which is:

        ^b             ^c  .---------------any
        ( )            ( )v                   )
        (0)-----b----->(1)-------c------->((2))

    it finds the longest one which matches. Note that after having
    encountered the first b, it does not care any more for b. Thus,
    a ...b....b...c is processed going in state 1 after the first b
    and eating there anything up to the last c. It does a bit of
    backup when it finds something which does not end in c since it
    keeps track of the latest match point and backups to it.
    -- put this in the section of backup.

  - a lexer, when at the end of the text, has the same problem of
    recognizing text as a regexp package, i.e. to have a complete string
    to match. Well, no. Even if it has a limited amount of text, it
    has to match the longest. Even if at the end there are few characters,
    it does not have to match all, but as many as possible. I had the
    impression that a regexp had to make any attempt to match all, but
    it would in effect match as much as it could anyway, like a lexer.

- scanning binaries: it is not true that the encoding gets in the way
  in lexer spec. It is always Unicode, and thus it does not depend on
  the platform.

- error in intset in jflex, and another error also somewhere

- jflex has these kinds of states. Perhaps I can use a nolook also,
  it seems they are the states with no edges. When one is encountered,
  the loop is exited immediately. Is it convenient?

  static final private int FINAL = 1;
  static final private int PUSHBACK = 2;
  static final private int LOOKEND = 4;
  static final private int NOLOOK = 8;

- no need to have a large input buffer: above 2048 there is no gain
  - put it in the section of the input adapter

- lex:
     yymore    concatenation of the lexeme with the previous content
               of the return buffer
     yyless    pushback of part of the matched lexeme in the input
               buffer to be rescanned
     REJECT    reject this match and make Lex proceed with the next
               one (when there can be several matches for the same lexeme,
               I guess)
     yywrap    called by Lex at eof

... see better jflex because it has states which seem to have an attribute
    telling that they have no successors, which makes the loop be exited
    without making an idle next iteration (there is no need to advance the
    character ???)
    Note that there are states which have no next only for some symbols,
    and therefore there is a need to keep there the test that the next
    be defined.


Constraints

- constraints: the <id> ::= <alpha>+ ~{<key>} is the same as <alpha>+ -<key>
  The generated automa is the same that would be by removing <id> from the
  final states of keywords, if keywords are also lexemes.
  If keywords are not lexemes, the automa is the same, but the states which
  recognise <key> are not final: they have edges to the ones that accept
  other id's characters.
  The ={} constraint very likely cannot be handled like an operation on
  languages.
- constraint - should be the same as difference, optimised when the
  elements to remove are other lexemes.
- I thought that having a lexer that returns the set of recognised lexemes
  the problem of contextual lexing is partly solved.
- It seems that there remanins the problems of constraints. A constrains
  such as: identifier which is not a keyword should be expressable by
  by removing from the sets of recognised lexemes identifiers when there
  are also keywords. In lexicons in which there is this rule there should
  be no need to state anything about keys: what would be the purpose of
  stating that a key is not followed by alpha+. It could be useful, biH.
  It is needed when there are not identifiers, and they must not be
  followed by alpha+.

Why not treat ={DO} by putting it in the hash table of lexemes instead
than in the atomaton? In general, lexemes which are terminal strings
could be put in the hash table and a reference kept in an array or
lexemes references indexed by the token number so as to return the
reference instead of the string, or better to avoid searching the hash
table to return it.  Note that a case insensitive literal is not a literal
because it is expensive to store all the upper/lower forms.
When a case insensitive literal is matched, its actual string can be put
in the hash table and returned.
However, it is possible to search the table in a case insensitive way,
which could make this technique interesting since it leads to a considerable
reduction in the automata.
Having literals in the hash table instead of in the automaton makes
recognizion slower because there is a need of a search which in the secong
case there is not.

It is also possible to make some tests to see what is more efficient.

A solution could be to allow to specify only lexemes in constraints so
as to handle constraints by manipulating the sets of lexemes recognised
in the final states and not adding extra automa.

... how much the tables can be reduced by defining keywords as constraints?


 * Basic engine
 *
 * The basic recognizion algorithm is:
 *
 *    state = initial;
 *    do {
 *        if state is final, remember state and position
 *        symbol = get_symbol();
 *        if no symbol break lex;
 *        state = move(state,symbol);
 *    } while (state is defined);
 *    if there is a state stored {       // a final state has been found
 *        backup to position
 *        return lexeme corresponding to state
 *    } else {
 *        return failure
 *    }
 *
 * Note that the test on the kind of the state is at the beginning of the loop,
 * not at the end of it. Apart from allowing to match the empty string (which
 * is not used in a lexer), it allows also to perform special actions for
 * special states. E.g. states which have special lookbehind.
 * When the state is final, the position must be remembered, and the state,
 * or the recognised set of lexemes.
 *
 * The empty string and the empty language
 *
 * The engine is not required to recognize the empty language or string
 * because lexemens cannot be like that.
 * However, this engine recognizes lexemes which contain the empty strins.
 * If the current position is at the end of the text, eof() returns also the
 * eof. I.e. the engine does not make an attempt to read nothing knowing that
 * it should match an empty string.
 * Since it does not advance the cursor, the callers risk to enter an
 * endless loop because the subsequent calls to lex() return exactly the
 * same result, and not even an eof when there is some text.
 *
 * Read-ahead
 *
 * The lexing engine makes always an attempt to read the next character,
 * even when that would not be strictly necessary. E.g. when a lexeme is
 * a unique, known sequence of characters, there would no need to read
 * a character past it. Some lexers allow to disable this behaviour, which
 * is not appropriate when a lexer is applied to process directly characters
 * obtained from an interactive device. E.g. to match a newline, another
 * character would be read, which is not obtained until another line is
 * introduced. However, plugging directly a lexer to an interactive device
 * is quite an uncommon use of it, and thus a character is always read
 * after a lexeme. This makes the engine somehow faster.

- interactive: interactive input in java seems anyway be done line by line.
  Check what happens when a BufReader is built on stdin. Lexers reading
  from such a reader could have problems either because of buffering (i.e.
  the buffered reader does not return one character at a time) or
  because it tries to match more characters than the ones strictly needed.
  I do not know if java allows to get at character as soon as it is keyed.
  Flex -I matches a character only if absolutely needed. E.g. with constant
  tokens there is no need to read a character past the last.
  The problem is not to match each character as soon as it is entered,
  but not to require to read an additional character when a token ends
  in newline because in such a case the lexing engine does not return
  until another like has been introduced.

 * 
 *
 * Transition tables, categories
 *
 * The most simple lexer is a pure automaton with a transition matrix with
 * the symbols in the columns and the states in the rows. This, however, is
 * memory consuming.
 * The matrix can be replaced by state tables in which each state has a table
 * of pairs (symbol,nextstate) which are scanned to find the next state.
 * However, this is time consuming.
 * To reduce the table, the same rows in the transition matrix can be shared.
 * A category table that maps characters to the indexes of the new table is
 * useful to represent sets of characters in state tables. Taken all character
 * sets, a category table can be built which maps characters into subset
 * numbers, being the subsets the elements of a partition of the alphabet
 * (i.e. the largest disjoint subsets which can make up all the sets).
 * Each character then can be tested to verify if it belongs to a set of
 * subsets. This is efficient expecially if the lexer generates programs
 * because it may generate the appropriate instruction to test sets or
 * elements according to the grammar (in a table driven one there is only
 * one kind of test to select the next state). In programs it is more
 * efficient to use for the categories not numbers, but sets (intersection
 * is more fast).
 * Categories have another essential benefit, which is to compact symbol
 * values so as to reduce transition tables size. E.g. a state which has
 * an edge for `a' and another for `z' would have a transition table at least
 * large enough for all the intermediate character should transition tables
 * be indexed by characters. A category table can map `a' to 0 and `z' to 1.
 * Categories are useful also to describe special characters (BOS, etc.) that
 * have no code, but that may have a category.
 * Categories allow also to represent a set made by all characters except some
 * given ones (and also complements) since that can also be represented by
 * a small number of large subsets.
 * Categories can be computed on the sets of characters specified on the
 * input (most lexer generators do it), or on the sets of characters which
 * occur in automa. In the former case compression might not be optimal
 * since there could still be characters which behave the same in all states
 * and that do not belong to sets specified in the input.
 * Instead here the character categories are build at the end. The NFA and DFA
 * can be built by working on the symbols, and so it is. Building categories at
 * the end gives a better chance for optimization, i.e. have fewer categories,
 * which means fewer transitions.
 * To build the category table, all states are visited. A list of categories
 * is kept that contains sets of symbols, which cointains initially the
 * complete set of symbols.
 * In a state, a symbol set S is built with all edges that lead to a same next
 * state, and compared with the elements of the category list. If a non empty
 * intersection is found (and S is neither equal not a superset), the element
 * is broken and the set is deprived of the intersection. The remaining edges
 * are visited and the same process done on them. There is no need to take
 * exceptions and constraints into account because they are associated to
 * states.
 * At the end the list contains all the categories. Then, all states are
 * visited again. A transition table is built indexed by categories.
 * For each set S (built as above), the category list is scanned. For all
 * the non null intersections the corresponding entry in the transition table
 * is set to the next state to which S leads. The remaining ones are set to
 * a unique stop state.
 * Note that categories can perform even better in programs and in tables with
 * sequential access than in tables with random access because programs
 * and sequential tables may contain sets of categories. E.g.:
 *
 *          if (((cattab[buffer[cursor]] & (c1|c2|...)) != 0) ...
 *
 * which is not possible with random access. The category table must be
 * generated only at the end, when an optimised DFA has been produced because
 * only at that point the alternatives are really known. The alternatives:
 *
 *          t1 | t2 | ... | tn
 *
 * correspond to edges from a same state if they are terminals or nonterminals
 * that produce a single character. Note that in:
 *
 *          t1 | t2 | <n1> | tn
 *          <n1> ::= t3 | t4.
 *
 * all terminals belong to the same alternative.
 * Categories must be assigned to special characters only if they are present
 * in the terminal alphabet, otherwise all transition tables are unduly
 * lenghtened.
 *
 * Categories are kept in a char[][] table, made of pages of categories
 * for character blocks.
 * When there are no characters > U+00ff, the category table directory is
 * not stored and the empty pages as well, but only the first page.
 * A reference is kept to the first page. There is no need to remember the
 * category of all the other characters since the category of the characters
 * which are not mentioned in the lexis iz zero. If all characters are
 * mentioned, then the table is full and that default value is never used.
 *
 * Transition tables can be stored as a single vector in which the sub-tables
 * for the states are stored one after another. A technique is to represent
 * states with the offset at which their sub-table start. To have the next
 * state for category cat, the table is accessed at table[state + cat].
 * This implies that there is no sharing of sub-tables among states because
 * when a transition is made there is a need to know the attributes of the
 * next state such as the set of recognised lexemes, which can be different
 * among states that have the same subtable.
 * E.g. suppose that in state S1, for symbol C1 the next state is S10,
 * and that in state S2, for symbol C2 the next state is S20, and that
 * S10 and S20 have identical subtables. If we store in the subtable of
 * S1 the offset of the N1's subtable, and the same in that of S2, we have
 * effectively equated S10 and S20, and are then not able to get the attributes
 * of each.
 * Suppose also that S1 has a transition table: S10,S20,S30, and that S20
 * and S30 have the same transition table. 
 * There is a need to keep the values of states S20 and S30 distinct because if
 * they denote final states, and the automaton has to return them, their value
 * is what tells which token has been recognized.
 *
 * State attributes can be stored as the first entry in their sub-table.
 * State sequence numbers can also be stored in their sub-table. This is
 * faster than dividing state indexes by the sub-table size.
 * State sequence numbers are needed to determine the sets of lexemes which
 * have been matched, which can be stored in a vector indexed by state
 * sequence numbers.
 * Another technique is to represent states as their sequence number, and
 * to keep the index at which their sub-table starts in a separate table,
 * say stateBase. To get the next state, the table is accessed as
 * table[stateBase[state] + cat]. This allows to share the subtables among
 * the states which have the same subtable.
 * In this solution it is easy to retrieve attributes and sets of matched
 * lexemes since the states are always represented as sequence numbers here.
 * Another technique is to store next states as states sequence numbers in
 * a matrix, e.g. char[][]. This is a viable choice since it allows faily
 * large lexers. State number 0 is reserved as no-state, and no table is
 * allocated to it (transTable[0] is null).
 *
 * Just to make a real example, the tables for the lexer for the Pascal
 * language are 13Kbytes long considering transition tables in which each
 * value takes two bytes (i.e. 64K states at most).
 * With this tables, the reduction in Pascal because of transition sub-tables
 * sharing is 18%. Now, the problem is to see if 18% more memory is worth
 * the reduction in time.
 * Measurements show that the first solution, the one in which the next state
 * is table[state + cat] is faster than the last one, the one in which the next
 * state is table[state][cat] by a factor 2%. The added complexity of storing
 * state attributes and sequence numbers and the disadvantage of not sharing
 * sub-tables do not pay off this small speed reduction.
 * The third solution needs two array accesses as the third one, but is less
 * intuitive.
 *
 * To avoid an array access to get the attributes, which is done at each
 * cycle, the attributes can be stored together with the next states (and
 * the ones of the initial state in it). This, however, enlarges transition
 * tables.
 *
 * Some data: a Pascal lexer has 47 categories: all letters, etc., and state
 * tables large 12Kbytes. This is not much a problem for the category table
 * which becomes almost useless (if it were not for the characters in comments).
 * The problem is that it does not provide its benefits of reducing the
 * transition tables.  Now, in the state table there are 2605 edges and 2819
 * no-edges. A comb-vector table which makes the maximum compaction would
 * need at least 10420 bytes, which is not much less than the 11508 which are
 * occupied by the origin tables. This is due to the fact that the base-check
 * tables need an additional array which doubles their size and makes them
 * convenient only when the origin ones are very sparse.
 * The traditional comb-vector method for storing the tables as described in
 * the Dragon book can be made faster by merging the state tables into a unique
 * array in which they are delved into the holes of one another.
 * First, the number of the edges for each state are determined. Then, starting
 * with the ones which have more, they are placed at the first position which
 * allows to host them. This means that there is no need for a loop.
 * This, however, does not reduce much the table size.
 * This technique achieves reduction only if similarities between states
 * are exploited (i.e. common tails of tables are shared). However, this can
 * be done only by using an array (the "default" array) which contains the
 * index of the table which a state shares with another. I.e. when a state
 * has a table which is made of a specific part followed by another which
 * is equal to that of another state, it can have its table stored as the
 * specific part, supplemented with the index of that of the other state.
 *
 * Transition tables when compressed can be stored in a unique vector in which
 * nextstates can be represented in a way that speeds up transition time:
 * relocated transitions (see below).
 *
 *
 * Case insensitivity
 *
 * Some languages have lexemes which are case insensitive. This occurs
 * for keywords or some names, or even for user identifiers.
 * In order to define case insensitive matching, the following terminology
 * is used:
 *
 *  - case-insensitive:  irrespectively on case
 *  - case-folding:      transforming a string in a form convenient for
 *                       case-insensitive comparison
 *  - case-variant:      a character for which there exists other characters
 *                       that are considered case variants of it
 *  - case-fixed:        a character which is not case-variant
 *
 * Any case-insensitive relation is a relation on characters.
 * Two characters a and b are case-insensitive if they are linked in that
 * relation (aRb). Any such relation must be reflexive: aRa and symmetrical:
 * aRb <=> bRa. A relation is built on top of the lowercase (L) and uppercase
 * (U) translations. Of course, if aLb, then aRb, and if aUb, then aRb.
 * These two relations link many characters to one.
 * E.g. kelvin-sign L lowercase-k, and uppercase-k L lowercase-k.
 * And also: micro-sign U uppercase-mu, and lowercase-mu L uppercase-mu.
 * In these cases we have aRb and cRb, and thus also bRc. Howerver, this
 * does not mean that the relation is, or must be, transitive. This is,
 * however, intuitive. Suppose that a keyword is specified in its uppercase
 * form and contains a lowercase-k. Then a lexeme which is its uppercase
 * form and one which is the same, but for that k being replaced by a
 * kelvin, are both case-insensitively equal to it. Of course, if the keyword
 * is specified in the uppercase form, it would not be matched by the one which
 * contains the kelvin. To restrict the case-variants we have to specify that
 * kappa letter in uppercase, and other letters in uppercase. This is difficult
 * to remember. It is then much easier to state that the relation is
 * transitive. To obtain the full relation there is a need to make the
 * transitive closure on it.
 * One such relation is obtained by making the transitive closure of the
 * uppercase and lowercase translations. This, howerver, leads to have
 * all i's, dotted and dotless case-insensitively equal. Removing them leads
 * to a relation which is rather queer, though. The problem of this
 * relation is that it is something in the middle, which is not right for
 * the barest Western words, and not right either for the other languages.
 * The full Unicode casefolding is much better, albeit more complex.
 *
 * The problem of defining a good case-insensitive relation is rather complex
 * if locales, legatures, etc. need be taken into account.
 * What is important is that strings and rules match in a reasonable way.
 * E.g. if a rule contains a dotless-i, probably a string containing
 * a dotted-i should not match, while one containing a capital-dotless-I
 * should. The case folding rules of Unicode make a string with a dotted-i
 * case-insensitively equal to another which has the same characters but
 * for that `i' which is dotless. Moreover, it makes a string containing a
 * `SS' match the same with sharp-s, but also a string containing `ss',
 * which is not correct.
 * The casefolding defined in Unicode is rather lenient: sharp-s is mapped to
 * ss, and since the representatives of equivalence classes taken are the
 * lowercase forms, s and S are mapped to s, and then words containing ss are
 * equated to the same containing sharp-s.
 * If sharp-s were mapped onto SS, such words were not equated, which is more
 * correct.
 * This is the only character mapped to a sequences which has that problem.
 * Moreover, building equivalence classes by transitivity leads to equate
 * characters which are not case variants. E.g. `i' and `I' are case variants.
 * `I' and dotless-i are case variants. Then `i' and dotless-i are equated as
 * if they were case variants, which is not true. This leads to a definition
 * of case-folding which is more lenient than case rules. In the latter example
 * it would equate words regardless on dots above i's. This could be a problem
 * if there were Turkish words with the same spelling as Western ones apart
 * from those dots.
 * All other equivalence classes contain only characters which are really case
 * variants.
 * Note, however, that there are also other characters (e.g. accented letters)
 * which would require more complex and language-dependent rules.
 * A perfect relation would not be simple and would also depend on language.
 * Therefore, the actual one (though not perfect) is a good compromise.
 *
 * Supporting the full one only makes common keywords have undesired
 * case-variants, such as "if", which in the full one allows also dotless i's.
 * This is not the case-insentitivity which is allowed in many formal
 * languages. Two relations are thus provided: one which is the ASCII
 * case-insensitivity and and another which is the full Unicode one.
 * Note that the first one is not Latin-1 because it does not casefold
 * accented letters, which have also a language-dependent casefolding.
 * When something more specific for a keyword is needed, it must be defined
 * with a replacement which specifies exactly the casevariant forms.
 *
 * A first method to support case-insensitivity is to represent all case
 * variants in automa. Automa can recognize any case-variants since they
 * are devices which implement grammars and all case-variants can be
 * represented in grammars. E.g. the keyword "else" can be represented as
 * {e|E}{l|L}{s|S}{e|E} and that can be done whatever the forms are, including
 * the ones which map single characters into many. This is done by taking
 * the simple upper/lower-case translations or the case-folding map of Unicode.
 * There is a need to take case-insensitive terminals (which can have
 * characters in any form), and generate a group for each of its characters
 * with all the ones that are in the equivalence class with it. This applies
 * also to the ones which are in a class with character sequences, expecially
 * because such strings can be in the origin keyword. E.g. in KORPERGROSSE,
 * the SS must be in a group with a sharp-s.
 * This means that when a substring is found which is in a case-folding
 * equivalence class, an alternative should be generated at that point,
 * e.g. {k|K}...{o|O}{{s|S}{s|S}{e|E} | sharp-s {e|E}}.
 * This must work when the string is originally in lowercase and when it
 * is in uppercase or even in mixed case.
 * There is a need to casefold the string before generating the casevariants
 * because otherwise when a character is encountered which has an equivalence
 * class that contains mappings longer than one character, there would be
 * a need to pushback the characters after the first one into the input.
 * E.g. "sharp-s s" has casevariants sharp-s s | s sharp-s | sss ...
 * The casefolded does not contain characters which have a one-to-string
 * mapping because that long mappings are already there in the string.
 * The generation of the case-variants is based on the notion of casefolding
 * equivalence classes of a character or a sequence of characters.
 * The casefolding map maps characters to a representative of equivalence
 * classes, except for the characters which map onto themselves, of the ones
 * which map to their lowercase translation. The equivalence class of a
 * character c is the set containing
 *
 *      - the character
 *      - its mapping in the casefolding map (or its toLowerCase() if
 *        not mapped)
 *      - all characters which have a mapping equal to its mapping
 *      - all characters which have a toLowerCase() that is equal to it:
 *        and which might not in the map: toUpperCase(c).
 *        E.g. `a' is not in the map because it maps to itself and there
 *        are no other characters which map to it. `A' must be added to
 *        the set because its toLowerCase() is `a'.
 *        Special mappings do add elements to equivalence classes, and do
 *        not replace the normal ones which are obtained by applying
 *        repearedly all case translations.
 *        Characters which are titlecases have a mapping which is the
 *        same as other characters, and thus are already in the map.
 *
 * To generate the case-variants there is a need to scan the string, and
 * at each position:
 *
 *  - create an edge for the character at that position
 *  - create an edge for its toUpperCase() and one for its toLowerCase()
 *  - create an edge for all the characters whose mapping is equal
 *    to it.
 *  - if in the string starting at that position a character sequence is
 *    present which is equal to a mapping present in the table, create
 *    an edge for the corresponding character, advance past the sequence and
 *    apply the same algorithm to the remaining part of the string.
 *    The latter generates a trie of states for it.
 *
 * When creating edges, duplicates are not created.
 * The creation of the case-variants is done directly when building the NFA.
 *
 * To specify that an element is case-insensitive, some indicators (clauses)
 * can be used. However, there is a need to take into account that most of
 * the times that applies to keywords which are written without any
 * decorations in a grammar.  The notation should be usable in the lexicon,
 * in replacement rules.  Thus, a quoting notation like e.g. '...' is not
 * a solution.  It is better to have something that can be appended to
 * elements, including the autoreference <>, like e.g. <>%ci, or <>%I%, or
 * <>#I#, or <>(i), or a bracketed construct such as {...}I.
 * A bracketed construct would be more appropriate when a token is made of
 * a fixed part with something variable in the middle, and some pieces of
 * the fixed part are case-insensitive. This, however, is more common when
 * a lexer is used in place of a parser. When it is used to define the
 * structure of lexemes, there is little need in it to state that some
 * elements in a rule are case-insensitive. It is much more common to specify
 * keywords, or individual characters as case-insensitive. Moreover, the
 * handling of bracketed constructs is more expensive since they must be
 * treated as special groups, which need be distinguished from the normal
 * ones all the times group are processed.
 * The chosen notation is "(i)" for ASCII case-insensitiviry, and "(f)" for
 * full case-insensitivity.
 *
 * Some lexers support case insensitivity only globally for the entire
 * lexicon. To be flexible, this should be specifiable on a per lexeme
 * or terminal string basis.
 * The elements which can be marked as case-insensitive are the terminals
 * (including terminal strings), the autoreference <> and nonterminals.
 * A terminal (string) which has such a clause appended to it is equivalent
 * to a rule that generates all the case variants of that terminal.
 * Such a clause specified on a nonterminal is equivalent to specifying it
 * on all terminals which are inside it taken individually, except on ranges.
 * Note that this does not apply to the characters generated by a nonterminal
 * as a whole. E.g. <nt>(f) where <nt> ::= {s}{s} is not equivalent to
 * <nt> ::= {s|S}{s|S} | "\u00df" (i.e. sharp-s).
 * Ranges denote exactly the ranges of characters within the specified bounds.
 * Case-folding them produces a result which is difficult to understand.
 * Moreover, it should have no effect when one or both bounds are not
 * case-variant or have a one-to-string mapping.
 * When a nonterminal is referred to from another one which is caseinsensitive
 * and another one which is not it inherits the case-insensitivity.
 * I.e. if a <nt1>(i) contains in its rule a <nt2>(f), inside the <nt2> (f)
 * applies. If <nt1>(f) contains <nt2>(i), in <nt2> (i) applies.
 * Note that it is possible to have in a same grammar a lexeme which is
 * casefixed and another which is the same, but casevariant.
 * E.g. <L1> ::= "aaa" and <L2> ::= "aaa"(i). The terminal string in them
 * is stored as one dictionary entry, and an attribute in the node
 * tells if it is caseinsensitive or not.
 * If we allowed to mention (i) in the grammar, then the lexis would have
 * no knowledge about that. This is why (i) occurs only in the lexis.
 * The lexer, when scanning a text which matches both returns both lexemes.
 * There is no notation for specifing casefixed characters or strings.
 * This is so because it seems unlikely that in contexts in which
 * all elements are caseinsensitive there could be a need to force some
 * not to be. In the rare cases in which that would be needed, ranges can
 * be used.
 * The case-insensitive clauses can be specified only on elements in the
 * rules of lexemes or nonterminals which are used in the lexicon.
 * They are disallowed in the grammar proper. This applies also to rules
 * which belong to both the grammar and the lexicon. Grammars refer to lexemes
 * which are defined in a lexicon; they do not specify the details of the
 * form of lexemes.  As a matter of fact, it is up to a lexer to generate
 * the case-variants. This is similar to the case of lexemes which have a
 * structure that is more complex than a simple terminal string: they are
 * defined by a rule or a set of rules which belong to the lexicon, and
 * are referred to from a grammar by their nonterminal name.
 * If no lexicon is defined, the casevariants must be specified explicitly
 * in the grammar.
 *
 * Note that case insensitivity is on what characters are matched by the lexer
 * only. If, e.g. identifiers are case insensitive, this need be handled
 * by the application, which are given the lexemes as they appear in the text,
 * and then decide how to treat them, casefolding them in such a case.
 *
 * This implementation complies with Unicode 3.0 casefolding only on jdk
 * 1.4 because toLower() there complies with it. It complies also with
 * 3.1 for the simple case-insensitiveness except for the characters
 * U+03f4 and U+03f5 (which are not defined in 3.0, but are in 3.1).
 * It complies with 3.1 for the full case-insensitiveness.
 *
 * With terminal strings (e.g. keywords) represented as part of automa
 * (vs having them represented as dedicated tables, or with hashing),
 * the size of automa do not increase much when they are caseinsensitive.
 * Only the characters which have a one-to string casefolding mapping
 * increment it. For the majority of characters there is only a different
 * mapping in the category table.
 * The result is a category table in which lowercase characters have the same
 * symbol value as their corresponding uppercase ones.
 *
 * Case-insensitive tables
 *
 * One of the technique to compress tables is to store all the literal
 * lexemes in a table. However, when a lexicon has case-insensitive
 * lexemes, that table needs a special ordering and searching. It is
 * described here since it deals with properties which are specific to
 * the handling of case-insensitiveness.
 *
 * A solution is to take the first character to be matched as it is
 * and look up in a table of casefixed strings, and then to take the
 * first character of its caseless mapping and look up into a table of
 * casefolded strings. E.g. a lexicon can have a casefixed lexeme "abc"
 * and a caseless "abcd". What is expensive here is that there is a need for
 * two vectors, to do two lookups and to take the longest one, which is
 * what could be avoided with one single table. Another case is a casefixed
 * lexeme which starts in sharp-s and a caseless one which starts in SS.
 * When the first character to be scanned is a sharp-s there is a need to
 * scan both tables.
 *
 * The table of literal lexemes cannot simply be ordered in descending
 * length of lexemes so as to have the longest ones first. This, does
 * avail when there are casefixed lexemes, but it is not sufficient
 * when there are case-insensitive ones if there are literals which have
 * been enlarged because of casefolding.
 * E.g. suppose a lexicon has two keys: one which is a caseless SSSS,
 * and the other a casefixed sharp-s sharp-s s. Then the input sharp-s
 * sharp-s s matched against the first is recognised for the first two
 * characters, while if matched against the second is matched for three
 * characters, i.e. a longer piece. Note that the first string in the table
 * is longer than the second one.
 *
 * It is possible to keep a unique table with the casefolded and the fixed
 * ones, with all the ones which have the same casefolded initial character
 * grouped together separated by a null string.
 * The first character is taken from the input, and its casefolding mapping
 * got. Its first character it then used to access the group of strings
 * with begin with that character.
 * To keep this efficient when a lexicon does not have caseinsensitive
 * lexemes it is possible to exit at the first match in the table instead
 * of visiting all the lexemes in the same group since the longest ones come
 * first. A table can hold the references (or base offsets) of the groups
 * whose first character is lower than 128, and a binary search can be done
 * for the others, providing that it finds the first in groups and in
 * case-insensitive way. E.g. in the table aa, Ab, ac, ad, Ae, Af, ba, Bb,
 * bc, when searching the group of "b|B" starters it must find "ba".
 * When there are lexemes which are case-insensitive, the table contains
 * strings which start with uppercase or lowercase letters, and thus the
 * slot must be visited entirely, independently on whether the single one
 * be case insensitve or not. There is a need for a sentinel or a test on
 * the first character done in a case-insensitive way to detect that a group
 * of lexemes which might match is ended, and the search can stop.
 *
 * What is important in a group of literals with the casefolded same initial
 * character is that the literals which are prefixes of others come after.
 * It is not important that literals are otherwise ordered.
 * A solution is to create an automaton with all literals in a group and
 * generate the table by putting first the ones which have a final state with
 * no outgoing edges. The ones whose state has some edges are prefixes
 * of others. When making the automaton the caseless literals must be expanded
 * into their rule which produces all casevariants. The problem is when in a
 * same state more than one literal is recognised. This occurs when a lexicon
 * has casevariant forms, e.g. a casefixed "aaa" and a caseless "AAA".
 * This is equivalent to declaring the latter as {a|A}{a|A}{a|A}.
 * Note that such lexemes are different in that in the rules where a "AAA"
 * occurs in the grammar, a "aAa" matches it, but not in the ones where an
 * "aaa" occurs.
 * A basic automaton for that lexis has a final state in which both are
 * recognised, and one in which only "AAA" is recognised.
 * There is then a need to put first in the table "aaa", with attached
 * the set of both literals recognised, and then the "AAA".
 * Note that "AAA" matches lexems which are prefixes of "aaa" but not viceversa.
 * All these states recognise (input) strings of a same length. It is possible
 * to order the final states by placing the ones with more lexemes first.
 * E.g. if the table is built as casefixed "aaa", casevariant "AAA", then an
 * input "aaa" matches the first, and the set of both lexemes is returned.
 * An input "aAa" matches the second, and a set with it is returned.
 * If the table is reversed, "aaa" matches the first, but this is not correct
 * since only the first is returned. This is why the lexemes with more matches
 * should come first.
 * It is always possible to order lexemes in such a way. Each lexeme (or
 * better, token rule for the caseless ones) defines a language.
 * E.g. with lexicon: token 1: ab{c|C}, token 2: {a|A}bc, a string "abc"
 * matches both. There is either a need to match both and to take the union
 * of the recognised lexemes set, or to break down the strings putting
 * "abc" (1,2), abC (2), Abc (2). This means that it is not possible to put
 * in the literal tokens table the lexemes as they are.
 * This, however, does not occur with lexemes which are either casefixed
 * or casevariant, but not a mixture of the two. Those token rules do not
 * represent literals which are caseless, and not even casefixed.
 * They would not go in the table, but in the automaton.
 * In a lexicon, there can be a number of lexemes which are equal except
 * for case, some of which are casefixed and some caseless. E.g. casefixed
 * aAa. casefixed aaA, caseless aaa, caseless AAA. The latter two are
 * recorded as two distinct lexemes since we do not know that they denote
 * the same strings until the lexis is processed.
 * Suppose the table is made in such a way to have in a group first the
 * casefixed ones and then one which represents all the caseless ones.
 * The casefixed ones have attached a set with the same lexeme and all the
 * caseless ones, the latter has a set with all the caseless ones.
 * Now, to demonstrate that this works, an input text is matched against
 * the casefixed ones first, and there it can match only one, and if no
 * match is found it is matched against the caseless one. There can be no
 * cycles because any casefixed one is a match at most for itself and for
 * the caseless one.
 * The table should be ordered by placing first the ones whose casefolded
 * string is longer, casefolding all the lexemes, including the ones which
 * are casefixed. Remember that the problem is only when there are lexemes
 * which are prefixes of others. If casefixed L1 is a prefix of casefixed L2,
 * then also their casefolded forms are.
 * At most it could happen that the casefolded form of L1 becomes also a
 * prefix of another one L3, but this is no problem since the input is matched
 * against the origin lexemes, not the casefolded ones, and if L1 is originally
 * not a prefix of L3, then it can come before or after L3.
 * Consider now a casefixed L1 which is a prefix of a caseless L2. Then
 * its casefolded form is a prefix of the casefolded L2. Casefolding both
 * is a convenient way to discover this. Then L2 is placed before L1.
 * If L2 is a prefix of L1, then it is placed before.
 * Another way of proving this is to consider that a literal token L1 defines
 * a set of strings, and also literals L2 and L3. If L1 and L2 are casefixed,
 * either one is a prefix of the other, or viceversa, or none, but not both.
 * Note that we are considering the literal tokens which are produced by
 * token rules, and not the token rules as such. E.g. a token rule can
 * contain alternatives which generate distinct literal tokens, and as a
 * rule generate some which are prefixes of those generated by anoter
 * token rule and viceversa (e.g. <L1> ::= a | bb  <L2> ::= b | aa).
 * When L1 is casefixed and L2 is caseless, either the automaton of L1
 * is contained in that of L2 (in which case it is a prefix) or not, but
 * not both. When L1 and L2 are caseless, either the automaton of L1 is
 * identical to a head of that of L2 or not, but not both since the two
 * contain sequence of casefolding equivalence classes which are disjoint
 * (and thus they are the same or they are completely different).
 * Moreover, if L1 is a prefix of L2, which is also a prefix of L3, then
 * L1 is also a prefix of L3 and the set is ordered.
 *
 * Lexicon:                               table
 *
 *    L1: casefixed sharp-s             casefixed sharp-s            L1, L2
 *    L2: caseless  SS                  caseless  SS                 L2
 *
 *    L1: casefixed sharp-s s           casefixed sharp-s s          L1
 *    L2: caseless  SS                  caseless  SS                 L2
 *
 *    L1: casefixed sharp-s s           casefixed sharp-s s          L1, L2
 *    L2: caseless  SSS                 caseless  SSS                L2
 *  
 *    L1: casefixed sharp-s             caseless  SSS                L2
 *    L2: caseless  SSS                 casefixed sharp-s            L1
 *
 *    L1: casefixed sharp-s sharp-s s   casefixed sharp-s sharp-s s  L1
 *    L2: caseless  SSSS                caseless  SSSS               L2
 *
 * Suppose that two lexemes, casefixed L1 and caseless L2, have the same
 * casefolded string. Then, an input text which starts with L1 matches
 * the first and also the second. Having L1 before L2 in the table, a set
 * with both lexemes is returned. A text that does not start with L1 has
 * no problems. If L1 and L2 have two different casefolded strings and
 * none is a prefix of the other, then a text which matches one does not
 * match the other and thus they can be in any order in the table
 * If L1 has a casefolded string which is a prefix of L2, then L2 must
 * come first since a text which starts with L1 could matches L2, which is
 * longer. If L1 has a casefolded string which has L2 as a prefix, it
 * must come first for the same reason. The ordering is thus determined
 * by the lengths of the casefolded strings, and thus there is only one
 * such ordering except for that of the strings which have the same lenght,
 * which are ordered always with the casefixed first and the caseless
 * after.
 *
 * The algorithm is thus to casefold all strings (casefixed and otherwise)
 * and order the groups for the longest first, and then among the ones which
 * have the same casefolded string to place the casefixed ones first and only
 * one caseless after, the first ones with a set with themselves and all the
 * caseless ones, and the caseless one with a set with all the caseless ones.
 *
 *
 * Start states (start conditions)
 *

- lexical states: to make the DFA there is a need to have transitions
  from such states with the initial symbols of the lexemes recognised
  in such states. The transitions go to the states that proceed with
  the recognizion of such lexemes (and only of them).

  When a NFA is transformed into a DFA, different initial states should
  not go in the same partition. In so doing, the states reacheable from
  different initial states should not collapse. E.g. if "abc" is accepted
  in initial state S1 and "abc", "abcd" in S2, such strings will have different
  DFA states so as not to make S1 recognise also "abcd".
  Several initial states serve first to factor the definitions. I.e. in jflex
  a rule can be preceded by a list of states; if several lexers had to
  be specified instead, that rule should be repeated in each one of them.
  This could be overcome by mentioning only the nonterminal, but there is
  then a need to specify somewhere the replacement if there is one.
  I do not know if it is a good idea to get rid of start states since that
  is a way of obtaining a contextual lexer.
  Is there any benefit in having them instead of having several lexers?
  A lexeme which is matched in several states should perhaps share a
  piece of the automaton. In fact, it does. However, when the same piece
  of automaton recognizes also a prefix of some other lexeme which is not
  recognized in all the start states leading to it, it gets duplicated.
  Thus, it factors out what is possible to factor out.
  Mainly, token rules which do not share states with other token rules
  are stored only once. This is convenient when in a construct there are
  lexemes which are not present outside it in addition to the other, basic ones.
  Having separate lexers means to duplicate the basic ones in the second lexer.
- start states seems similar to gema domains
- start states are also called left context
- why not then have something like:

         LEXIS ...
             shorthands, replacements, rules
         LEXIS name: list
             ...
  a grammar which does not start with GRAMMAR or with a rule defines a
  lexicon only, and only a lexer is produced.
  Rules can also be put below LEXIS (then check the use of in_grammar).
  When a name: is specified in front of the list, another lexicon is
  defined (this is similar to the start states).
  There is no point here in having inclusive or exclusive states since
  rules are not prefixed with states, but states are defined with the
  exact contents. A same lexeme can occur in two lists. When many lexemes
  need belong to several lexers, a shorthand can be used.
- the current way to specify the lexemes is good when the lexer is used
  together with a parser since lexical elements are usually not many,
  and the user can easily list the non-literal ones in LEXIS, having the
  terminals mentioned in the grammar declared as lexemes implicitly.
  Lex-like tools allows to specify what elements are lexemes at the same
  time their form is specified since they are the (top) REs, and have
  states, state groups, etc. to specify, so to speak, several lexers at
  once. There is a tradeoff there because if most lexical elements are simple,
  i.e. can each be defined by a single rule, stating directly the rules and
  having some few extra rules specified aside ("definitions" in Lex) is a
  good solution. Forcing to give a nonterminal name to each lexeme,
  and mentioning it in a LEXIS list would be cumbersome.
  If token rules are not simple, having a unique set of rules (i.e, no
  distinction between REs and definitions) is instead better.
  I have the impression that Lex-lile lexers are too much oriented to
  pattern-matching substitution, i.e. straightforward translation skema, where
  what is important is to make evident the association between patterns and
  actions (substitions, semantcs).
- yymore() serves in conjunction with sub-rules in start states to collect
  pieces of lexemes.  
- with start states it is possible to recognise nested comments.
  But CFGs contain autoinclusions. Is this technique to count occurrences
  applicable to CFGs in general? How can it be used automatically to
  allow autoinclusions? If there are several nonterminals which are
  mutually autoinclusive, there is a need for a stack of counters representing
  the nestings of one nonterminal inside another one, and not all the
  total nestings. Probably this can be applied to a restricted set of CFGs,
  probably the deterministic ones. An idea is to see which it the minimum set
  of CFGs which allow to represent nested comments. Perhaps this can be
  implemented by augmenting the automa with counters without slowing it down.
  Take into account that token rules are normally not large rules.
  With so simple rules it would be a pity not to be able to support some
  simple form of nesting.
- I am wandering if start states are mainly useful with lexers which can
  stay in the engine until a rule is matched which has a retuns as action.
  If this is not possible, then the engine returns a token each time it
  matches a rule. But then, how can I have, say, a start comment rule,
  comment body rule, and end comment rule, and have the lexer return all
  this as a single token?
  Well, the difference is probably not much in this because the switch
  statement which is generated in those lexers can be written by the caller
  with my lex(), and the caller can collect all the pieces recognised
  by the sequence of calls into a single token. The difference is more
  in what it represents: a token rule is meant to represent a token, not
  pieces of tokens. Why it should not be possible to define a lexeme with
  a rule, and need instead an engine which enters a state in which it
  recognises sub-rules which together build-up a lexeme?
  In gema domains one writes all the things which can occur in them.
  Here it is similar: one defines in a state all the REs which can occur
  in it. But this is the same as defining in a token rule all the elements
  which can occur in it.
  Start states have also a different use: the one of defining several
  lexers which share a number of lexemes, saving memory to represent them.
  Could it be useful to allow to specify states in the middle of rules
  (gema does), or on rules which are referred to from some token rule?
  One of the uses of sub-rule is to make some computations in the middle,
  like e.g. reducing escape sequences in strings, or counting autoinclusions.

- start states can be useful to implement constraints for which there is
  probably a need to run the automa a second time to recognize them,
  and factoring out there can be convenient

- many LEXER can play the same role as the lexical states, which can be
  useful if the lexer is used alone, without the parser.
  In a lexical state, a number of lexemes are recognised. This can be
  represented by having a state with e-transitions to the start state
  of the lexemes. Probably the transformation into a DFA is such that
  it keeps things right, i.e. it keeps the lexemes recognised in a lexical
  state the same and no more.
  Improve the syntax so as not to require to declare a grammar in such
  a case.

- start states should not need a special treatment in fallback+comb
  (but they neede one in tunnelling): why there should not be problems
  here and instead be in tunnel? What is present here that is not there
  and that makes such problems disappear? I guess that it is that the
  building of automa takes care of that.

- are they also a means to implement subgraphs? E.g., when something has
  been matched in the default start states, a specific start state is
  entered, something more it matched (and possibly dedicated actions are
  performed there), and the same is possibly done in other lexemes (i.e.
  reusing the same submatch. They could even be a means for submatching.

- jflex:
  %%

  %class Subst
  %standalone

  %state S1, S2

  %%

  "abcd" { return 2; }

  <YYINITIAL, S2> {   "abc" { return 1; } }


  I inserted a state S1 because it numbers the declared states from
  0 onwards, and then S1 is 0, the same as YYINITIAL.

  %class Subst
  %standalone

  %state S1, S2

  %%

  "abcd" { return 2; }

  <YYINITIAL, S2> {   "def" { return 1; } }

  This seems not to work since state S2 has an edge for "a" to the
  piece of automaton which recognizes "abcd".

-- see the reply mail form Gerwin


--- what is strange is that the necklace loop, which is never entered
    when there are no necklaces make the engine loose speed so much

- does yacc read all the text and returne the parse tree at the end,
  or during parsing?
- debug, or trace option that allows to report how matching is done


- minimal perfect hashing: have a look. I discarded the use of constant
  lexemes tables because they featured more or less the same time and
  memory as the fallback+comb, but were less general.
  A constant lexemes table can be used when there is no case insensitivity,
  or when there is, but restricted to the 1:1 mapping.
  I can test the times in the case of ASCII or Latin-1 because in such
  a case the computation of the hash function and the comparison of the
  strings can be done in a fast way lowercasing on the fly with a table.
  In the case of full Unicode that would require a call to
  Character.lowercase() which I guess it would slow down considerably.
  When there are lexemes which are the same except for case, they are
  kept as they are in the table. Lexemes which are case-insensitive are
  stored in the lowercased form. When there is at least one case-insensitive
  lexeme, lexemes must be searched in the table as they are written and
  then also in the lowercased form. Now, suppose that a lexeme "abc" is
  present, and that the string "ABC" has to be searched in the table.
  The first, direct, search does not find it, but the case-insensitive
  one does. A test must then be made that the strings are identical.
  When there are no case-insensitive lexemes, only one search should be
  done.
  To remove the constant lexemes from the lexicon, they must be taken
  (probably only the ones which are longer than 2..3 characters), and
  a rule {<char>}+ introduced with <char> denoting the set of all
  characters that occur in them.
  I remember that there was a problem in delimiting lexemes: if I introduce
  such a rule, I would take the text "abcd" as a string to be looked for
  in the table, which contains only "abc", and conclude that there is no
  such lexeme, which is incorrect. This would work fine when there is
  another token rule, like e.g. that of identifiers, but not when there
  is none. I remember I had also to run the automa engine because there
  can be non-constant token rules which recognize a same string, and to
  record the longest positions.
  I still have the impression that this technique can be applied only
  in some, albeit notable, cases.
  The comparison made by the paper on gperf is not fair: comparing different
  tools is not the same as comparing different techniques since the way
  tools are implemented gets in the way. Tools are usually implemented with
  quite different degrees of optimization, which can completely spoil the
  comparison.
- the lexer I have implemented is for limited lexicons. E.g. it is not
  suited for natural language.


Ranges, and character sets

ok- if there are no lexical rules, there is no alphabet. Or better,
  there is an implicit alphabet which is made by all terminal characters
  present in the grammar
- if no lexis is declared, one is built which contains all terminals,
  characters or strings present in the grammar, and a ParserTables
  is built for it. The Earley engine works with it.
  Note that a parse tree is not returned for terminal strings.
  When there is a need to consider as terminals the characters, no
  terminal string must be used, and the characters mentioned as distinct
  elements in the grammar.
  This use of the tool is more for studying grammars than for
  something practical. There would always be an alphabet, albeit full
  Unicode. Probably if I want to declare one, I can write LEXIS ALPHABET xxx.
  Admittedly, it looks a bit strange.

- what happens if I call ParserLex.lex() and it is already at eof?
  When reading a stream just opened that is not known, but when reading
  a stream that it has been taken over, that can occur.

- takeover from ParserLexer to a ParserLex in Parser is not a problem.
  ParselLexer also has backup, and keeps two lexemes in the buffer.
  However, Parser reads an EXAMPLES and a newline before takeover,
  which means that there should not be a lexeme in the ParserLexer buffer,
  and takeover should be simple.
  ... well check it because to allow backing up, the previous lexeme
      is always in the buffer. In such a buffer how takeover works?
      I just restore the cursor in the stream.cursor. Is this correct?

... there is a need to solve the problem of tracing ParserLex.lex().
  Probably with a simple engine with tracing in it.

- if BOS ... disappear, remove TER_SPE, and all its related stuff
- in pascal.bnf temporarily placed the [<delimiter>] in front of tokens
  and also at the end of the top rule to allow a final one.

- Then see if the compressor is still good: automa might have different
  personality after that, and the compressor be no longer good.

- if (ever) type-2 or some restricted form of nesting will be allowed
  in lexemes, then there would be a need to review the use of operators,
  or perhaps to disallow them in the rules which are not type-3.

ok-The parser (?) generator works also without knowing TR, EM, TY2, etc.;
  it does not enter endless loops but it might generate useless results
  when the input is erroneous.


- update then ParserLexer for the metatable, tertable, keytable, which now
  contain extra entries.

- the S_NT and S_TER can then become attributes, and the kind in
  nodes disappear, and probably something similar in ParserDic.
  Wait until the other operators, constraints, etc. have been introduced.
  If they go in status, check because there are cases in which it is
  copied, cleared, etc.

- have a look at the firstpos, nullable, etc. algorithm


Greediness:

Quantifiers make expressions which produce several instances of the
strings they denote. From a language point of view, greedy or thrifty
quantifiers are the same: the set of strings produced is the same.
However, when in the text at the current position there are several
of such strings (possibly with differing lengths), they make a difference
regarding which string is matched:

- a greedy quantifier matches as many times as possible (while still
  allowing the rest of the rule to match). If two strings are present,
  the one in which there are more repetitions of the quantified part
  is taken.
  Each greedy quantifier in a rule is greedy at the expense of those that
  follow it.

      RE: "e {<char>}* e"  text: "exasperate",  {<char>}* matches "xasperat"

- a thrifty quantifier matches as few times as possible (while still
  allowing the rest of the rule to match). If two strings are present,
  the one which contains the fewest repetitions of the quantified part
  is taken.

      RE: "e {<char>}*? e"  text: "exasperate",  {<char>}*? matches "xasp"

  This means that the quantified expression is matched over and over until
  the rest matches.
  See the section on "The Little Engine that /Could(n't)?/" in the Camel
  book, Ed. 3.
.... how can I get it?

  There are two ways to defeat the leftmost leanings of the pattern matcher.
  First, you can use an earlier greedy quantifier (typically {<char>}*) to
  try to slurp earlier parts of the string. In searching for a match for a
  greedy quantifier, it tries the longest match first, which effectively
  searches the rest of the string right-to-left:

      RE: "{<char>}* e {<char>}*? e"  text: "exasperate",
      {<char>}*? matches "rat"

  But be careful with that, since the overall match now includes the entire
  string up to that point.

- the rule: "e {<char>}* e" applied to "exasperatexx" matches "exasperate".
  If we need to match the text from the first "e" to the second one, we
  must use the rule: "e {^e}* e". This has the same effect here,
  but it is not exactly the same as a thrifty quantifier since the latter
  repeats a rule, not only any character.

- (l:u)? thrifty form of (l:u) quantifier, *?, and +?
ok- why not have a special notation for {<char>}*?, like e.g. * ?
  Because extreme conciseness is not important here, while readability is.

- how the Early engine can treat thrifty quantifiers? Probably it cannot,
  which means that they are for lexis only.

- when the text is bounded, and all of it must be recognized, there is
  no greediness since an appropriate number of the quantified parts (if any)
  must be taken. Greediness comes into play when the text is not bounded
  since it can make a difference. Of course, when there is only one string
  that matches (e.g. because its tail is fixed), there is no game for
  greediness.
  Greadiness comes also into play when submatch addressing is required.
  E.g. {a}*?{a}* repeats the first group only one time in "aaa".
  However, in lexers in which there is no submatch addressing, this is
  irrelevant.

- thrifty, a.k.a lazy, by Larry Wall, or also minimal quantifiers
- greedy, aka maximal
- Str.java A*B*B matches ABBB

- I saw many times, when using quantifiers, that the result was not what
  was expected. I think that the problem is present in REs in which
  some parts are specified as {<char>}*, delimited by some fixed sequence
  of characters. I.e. instead of specifying exactly the composition of
  those parts, we simply say that they are whatever is between
  some fixed sequence. This is a sort of weak specification because the
  engine tries to make an overall match, and in doing it, the parts
  which specify exactly the characters allowed match stronger to well
  identified pieces, while the parts such as {<char>}* have a more
  instable match since they can match more or less characters, and thus
  are stretched by the engine in order to have an overall match.
  Often they match more text (or less text) than expected.
  The right approach is to state exactly the composition of each part
  instead of having it delimited in such a soft way.
  In order to mend wrong matches, we used thrifty quantifiers, obtaining
  at times again unexpected results.
  The question then is: are they useful, are there any good cases which
  show that they are, or are they a poor solution?
  When there is a mixture of greedy and not greedy it is complex.
  Probably a solution is to state that the longest match apply: the
  greedy ones win.

- bumping along: advancing in text trying to find a match for a rule

- how can these behaviours be expressed with BNF?
  Starting from a point in the text, the engine proceeds matching a greedy
  quantified part and the rest, marking the position and then proceeding
  until no more transitions can be made, and then backing up to the position
  of the last match.
  Thrift, instead, would make the engine stop at the first match of the
  quantified part which is followed by a match of the remaining one.
  I.e. the engine works as before, but stops at the first overall match.
  A lexer never is told to match the entire text, but the longest text
  that is a production of a rule.
  Well, since a FA is equivalent to a rule, if there is a FA for a thrifty
  quantifier, there is also a rule. Well, I guess that the structure of
  the rule is always something like {<expr> - <follows>}* <follows>.
  If <expr> may not contain <follows> it is even simpler. This is so, i.e.
  the stopper for the quantifier part is built into it, because the engine
  has no way of counting repetitions and stopping at the first one.
  What is a pity is that in REs this is simply specified by a quantifier,
  while here there is a need for a more complex quantified expression.
  Well, why cannot we specify that {r1}*? r2 is equivalent to {r1-r2}* r2?
  It could be a solution, albeit more complex, and that needs to state
  also that a *? at the end is the lower bound of repetitions.
  Moreover, consider the example: {a}+? [ab]: the rule above would produce
  {a}+ [ab], which is not what we want. With text "aa" it matches "aa"
  instead of "a".
  The example above should be represented by a [{a}+ b].
  A conventional engine haa no way to count cycles, it runs all the
  way as much as it can, and the only way to make it stop before is to
  restrict what it can match.
  However, when a thrifty quantifier is inside an inner group, we should
  exclude from it all the text which can be generated by what follows
  in the overall rule, and do that also when it is inside a nonterminal
  which is used.
  If a thrifty occurs at the end, it must be matched only once.
  If it occurs before an expression which cannot generate the same strings
  as it does, it is the same as a greedy one.
- consider {a}+? [ab]: after a number of a's, the automaton must procede
  matching b, and if it does not, it should backup after the first a.
  This means that it is no longer sufficient to remember the last accepting
  state: when that state is one that belongs to a thrifty only, then
  the first must be remembered.
  Take also into account that minimization merges common tails, which in
  cases like e.g. a {c}+ | b {c}+ merges the {c}+ tails. If one is greedy
  and the other is not, this is a problem. Therefore, it is likely that
  the things to do on the automa must be done on the non-minimized ones,
  and thereafter minimization must take into account that states which
  have different "greediness" must not be merged.
- the question is: is there a conventional DFA which recognizes thrifty?
  The problem of the conventional ones is that when a thrifty is at the
  end, they do not stop, and when thrifty are in the middle, but end in a
  final state, they backup to the wrong position.
  Vaguely, a thrifty quantified group should be broken in two: one
  group representing the lower bound, and another the remaining part.
  When at the end, the remaining part is descarted, and when in the middle,
  but final, the final state is the one between the two parts.
- It seems not easy to understand what thrift is in terms of DFAs.
  The problem is that it relates to the behaviour of the engine, and not
  to the grammar. I.e. a rule containing a greedy quantifier defines the
  same language as the same rule with that quantifier changed in thrifty.
  The difference is that in the first case the engine takes the longest
  portion of the text starting at the current position for which there is
  a string in the language. In the second case, it takes the longest portion
  for which there is a shortest derivation of the quantified part.
  The language is the same, what changes is which string is taken when
  there are many which start at the current position in the text.
  I have the impression that it should be something like having the
  engine not follow edges which come out of final states and belong only
  to thrifty quantifiers (and do not belong to a greedy one or other
  expressions).
  Now, suppose that a final state has been reached, and that it has one
  outgoing edge to another state, from which one edge exits to proceed
  the recognizion of another instance of a thrifty, and one edge for something
  which is not. The engine should proceed from the final state. It seems
  not so simple to stop, or to cut the graph, also because the edges can
  go to states which are back in the graph.
  I guess, however, that if there are no states dedicated solely to
  a thrifty quantifier, then there are expressions in the rule which
  generate the same strings as that quantifier, and are not thrifty.

- in most cases, in lexemes which allow characters up to some delimiter,
  the inner part behaves like a thrifty one. E.g. in strings, all
  characters are allowed up to a double quote. Of course, this can also
  be specified stating that the longest sequence of the set made by all
  characters except the double quote is allowed.

- gema allowed to have *aaa meaning a string which ended in aaa
  (with * thrifty), i.e. matching any sequence of characters while
  allowing the rest of the template to match, and also a <u>, which
  seems to be a possessive one. It seems that it has no greedy one.
  Effectively, the difference is not clear since pattern a*b*c, with
  text axxxbyyyczzzc, the first * matches xxx and the second yyy.
  If the second were a thrifty, it should match yyyczzzc. Perhaps not.
  Gema states that when in a pattern there are two * they match the
  text needed to match the entire pattern. I remember my implementation
  of str_match ... see. See also my example on possessive quantifiers,
  sent to Ingrid.

  I am not quite sure, since in *aaa the * does not mean all strings
  except aaa. In a string ending in aaa, * refrains from slurping all the text
  only because in such a way an overall match is found, and not because of
  its meaning is {<char>}* - aaa.
  This construct means difference between VT* and a string, followed by
  that string. Without it, comment rules are ugly:

      <comment> ::= "/" "*" {^"*"}* {"*"}+ { {^{"/"|"*"}} {^"*"}* {"*"}+ }* "/"
... check it with ParserLexer
  Some Lex-like tools support this. I think that it is possible
  to build an automa which recognizes the following part and has an edge
  to the starting state from all states labelled with the symbols which
  are not accepted in them (except when there is no such symbol, in which
  case there is no edge).
  This seems exactly the upto.
- I think that instead of having the upto operator, which is a particular
  case of thrifty quantifier, it is better to have them because it is
  more general. Upto, e.g. ~r1 is the same as {<char>}*? r1.
  Or the other way around.
- A thrifty quantifier is not like an upto: {a}*? matches only "".

- find any example which shows that thrift can do something which
  may not be done with greediness. Perhaps the expression for comments:
  it shows that it can be done, but it is much more complex.
  The expression becomes a bit simpler having complement, but not much.
  I have the impression that most of the times we want to match a
  string up to the first occurrence of something, which can be done also
  without thrift.
  Is it true that having difference, thrifty quantifiers are less needed?

- {<char>}*? ab, with *? non greedy should be the same as upto ab.
  It means to stop at the first occurrence of ab, and match also ab.
  I.e. any character sequence which ends in ab. But ...ab...ab
  stops also in ab. So we want the smallest which ends in ab.
  Probably to have the longest we should say {~ab}+.
  ~ab can be represented with a normal, but more cumbersome rule:
 
        {{^a}* {a}+}* {{^b {{^a}* {a}+}*}* b

...test it: why it is so different from the comment one?
  or !{{<char>}* ab {<char>}*} ab.

- to support thrifty means making the difference between the group which
  has the thrifty quantifier and all the expressions that follow (i.e. not
  only the first expression). Is then not simpler to remove the edges that
  come out from the end of the graph back to the state at which the group
  with the thrifty quantifier begins? A r1*? r2 should have a graph which
  has a back-edge. It should occur when r1 can also produce r2.
  E.g.  {<char>}+ b
                                  v-------char------.
       v--char---.                v--char-b-.       |
     >()--char-->()---b--->()   >()--char-->()--b-->()

  To cut the loop means recognise {r1-r2}+ r2. Let's then hope that to
  construct an automa for {r1-r2}+ r2 ends up into one which is the
  same as that with the loop cut.
  I am not quite sure since a thrifty does not mean that the re occurs
  only once: it occurs the minimum number of times to make the remaining
  text match, and thus perhaps there is a need for the loop.
  The problem is to understand how the fact that it must be iterated
  that minimum can be represented in a FA.

- an engine which implements the shortest match rule stops at the first
  accepting state. Thrifty quantifiers are like that. The engine should
  remember the first encountering of states which accept only thrifty
  quantifiers. When such states are at the end of the graph, all outgoing
  edges which relate only to thrifty quantifiers must be cut so as to
  avoid to scan characters which are then always backed up.
  I must remember that a DFA performs all the moves of a NFA. If a
  move of a DFA represents only moves related to the matching of thrifty
  groups, then I can simplify it; if is represents moves not only belonging
  to thrifty groups, then it means that there are also other derivations
  which apply. The question is: when there is a thrifty and a greedy one,
  which prevails? E.g. { {a}*? | {a}* } with text "aaa" matches "a" or
  the whole text?

- jdk 1.4 has also possessive quantifiers, which are so greedy as to
  force a match in which their submatch takes priority over the longest
  overall match. E.g. "a*+(b|abb)" with text: "aaabb" matches "aaab", and
  not "aaabb" as the greedy one.
  I have no idea how this can be represented in BNF.
  Note also that a RE: "a*+a" does not match a string "aaa". I do not
  know if this is of any use, but it is a kind of match anyway
- perhaps it is possible to support possessive quantifiers by representing
  the r*+ with a loop onto itself which takes precedence over the other
  edges that come out of it. E.g. a*+ (b|abb):

         v-a,
        >()'--b-->()
          `--a-->()--b-->()--b-->()

  The branch at the bottom is never taken. But then this quantifier is of
  little use because when there is a r2 that starts with a character which
  if the same as one that are on the back edge, that r2 is never taken, and
  therefore it can also be removed. But then, once such an expression has been
  removed, it works as the greedy quantifier.
  The problem is that I did not find any example which shows that possessive
  quantifiers are of any use: on texts that match, they behave the same as
  the greedy ones, and on texts that do not match they behave differently,
  but what matters there?


-- it seems that TOUPPER does not work in CLI in Win.
-- propagate the tolower in check_command in the other apps, and test
   Parser

 *
 * Buffer exhaustion
 *
 * The detection of the exhaustion of characters of the current block can be
 * done in three ways:
 *
 *    1. a test is done on the index
 *          while (cursor < end){
 *              ...
 *          }
 *
 *    2. a character is appended to the block (e.g. a 0xffff) and a test is
 *       done when such a character occurs in order to detect when the
 *       character is the terminating one or not:
 * 
 *          loop: for (;;){
 *              ...
 *              if (ch == 0xffff){
 *                  if (cursor == end) break loop;
 *              }
 *              ...
 *          }
 * 
 *       Note that there is a need to introduce that test only when a lexeme
 *       may contain the terminator. In the case of transition tables:
 * 
 *          if (cursor == end){
 *              readBlock();        
 *          }
 *          loop: for (;;){
 *              state = table[buffer[cursor]];
 *              ex: {
 *                  if (state is sentinel){
 *                      if (cursor == end){
 *                          refill block
 *                          if (text ended) break loop
 *                          state == old[state];
 *                          continue loop;         // undo the transition
 *                      } else {
 *                          state = next;
 *                      }
 *                  }
 *                  cursor++;
 *              } // ex
 *          } // loop;
 *
 *       A state Sx which has an edge for the terminator character to a
 *       state Sy has that edge replaced by one to a (save) state S,
 *       in which a test is done on the exhaustion of the buffer to tell
 *       if the terminator character got belongs to the text or is a
 *       sentinel. In the former case, a transition is made to Sy without
 *       reading any other character, and in the latter, the buffer is
 *       refilled, and the Sx restored so as to redo the transition.
 *       The terminator character (sentinel) leads to a state which is a
 *       save state and which has associated the state id of the origin state.
 *       This is needed in order to avoid to save the value of the state
 *       before performing the transition, operation that would take a time
 *       similar to that of performing the test.
 *       It is possible to store the next state as in the location reserved
 *       for fallback since a sentinel state has no fallback. The origin
 *       state can be stored as edge for the category of the sentinel.
 *       It it better to choose U+0000 or U+00ff as sentinel so as not to
 *       require the larger category table.
 *       If looping states are introduced, then they should not be used if
 *       the characters to scan contain the terminator.
 *       In all lexemes which have edges for the terminator character, those
 *       edges lead to a special save state.
 *       This technique shortens the processing of normal characters at the
 *       cost of lengthening that of the sentinel, which is less frequent than
 *       the others.
 *
 *    3. as 2., but no additional states are introduced. A double loop
 *       is used instead:
 *
 *        loop: for(;;){
 *            while (ch == 0xffff){
 *                ...
 *            }
 *            if (cursor == end) break loop;
 *        } // loop
 *
 *        This, however, keeps a test in the loop as solution 1 does.
 *
 * In handwritten lexers, a test on the current character is present
 * anyway, often in a switch statement. If the terminator chosen is a
 * character which occurs seldom in lexemes, then in most lexical methods
 * there would be no need to make any extra test since the terminator will
 * be catched by some test that already exists. Recognizion then terminates
 * because a character which does not belong to the lexeme is encountered.
 * For lexemes which can have it, there is a need to make a dedicated test.
 *
 * However, measurements show that this brings a small gain: 1%..2%, which
 * does not pay off the extra complexity of the lexer.
 *
 *
 * Termination
 *
 * Since there can be lexemes which are a prefix of others, when the final
 * state of one of them has been reached, there is a need to proceed until no
 * more transitions can be done, and then to backup to the last final
 * (accepting) state.
 * Termination occurs when a state is reached from which there are no
 * transitions for the input symbol or there are no more input symbols (eof
 * encountered).
 * This means that for fixed lexemes which are not prefixes of any other lexeme,
 * a character is scanned after them even if that is not necessary.
 * This leads, as side-effect when the lexeme is at the very end of a block,
 * to read another block. However, this is not a problem.
 * There are tokens whose recognizion stops when the last expected character
 * has been read (these are the tokens that generate finite strings); there
 * are others (the infinite or the overlapping ones) whose recognizion may stop
 * only when a charater that does not belong to them has been read.
 * E.g. in cases like {b}*, the state is reentered several times: the
 * recognizion of the element is completed only when the state is left.
 * Note that the difference is that in the first case a state is reached in
 * which there are no outgoing edges, and thus there is no need to read a
 * character and to see if there are transitions for it, while in the second
 * one the state has transitions.
 * This means that in general, at the end a character must be read, but not
 * scanned. The lexers gets always one character after a lexeme so as to stop
 * always at the next character.
 *
 * There are several solutions to detect termination:
 *
 *    1. introduce a predefined "stop" state, a state that does not exist
 *       (and has no attributes): a negative number or a null pointer. Final
 *       states have then a transition table in which some or all entries lead
 *       to such a stop state. Since all lexemes would be terminated by a
 *       transition with a symbol that does not belong to them, the end
 *       cursor is always not advanced on such ending states.
 *       However, a test should be made in the loop after all transitions
 *       to stop lexing without attempting a new transition (because the
 *       stop state has no descriptor).
 *       This is not needed if transition tables are scanned sequentially
 *       because a test on the end of the table or on an empty table is already
 *       needed there.
 *    2. terminate all lexemes with a state which is entered when a character
 *       that does not belong to them is found. This applies both to those
 *       that are finite and to the ones that are infinite. This is similar
 *       to the previous one, but the state exist and is special, and
 *       therefore there is no need for a dedicated test: the test is made
 *       inside the if statement that handles the special state, and an exit
 *       done before advancing the position (i.e. processing the next symbol).
 *    3. use a state attribute to detect the reaching of end states.
 *       This flags the states that have no transitions. However, this needs
 *       a test before performing transitions, which means always, and there
 *       is anyway a need to treat states that have no transition for some
 *       symbols. Moreover, there is a need to advance the cursor anyway.
 *
 * For finite lexemes, in their transition tables the final state has all
 * entries set to the stop state. This means that there are several (final)
 * states which have all outgoing edges to it. However, they all point to a
 * same transition table, and thus do not waste space. So to speak, since the
 * final state has a place in the table, it can be accessed to see that the
 * next state is the stop one.
 * It is as if all states had edges anyway.
 * For the other lexemes, the final state has some outgoing edges which
 * lead to a defined state, and some others which lead to a stop state.
 *
 * The difference between 1 and 2 is that there is no need in 2 to test that
 * the state is the stop one in the loop because in 2 the state exists and is
 * special. This can be exploited by having a while(true) at the end of the
 * loop.
 * The second solution seems the fastest one. It attempts to keep the loop
 * as short as possible. However, measurements show that it is slower than 1
 * by 5%. The exit from the loop occurs after 1 because it goes a bit further.
 * The extra instructions done overweight the saving of the test on the state.
 *
 * The need to remember the position reached when a state was entered occurs
 * only when from a final state there are transitions to non final states.
 * An attribute can tell it. This would eliminate the need to save the
 * position in all final states. However, since the state should be saved in
 * final states, a test on final states must be present, and thus an
 * additional test on these states would take the same time as the saving of
 * the position.
 *
 * The termination tests and the execution of the move depend on how the
 * automata is represented. There are several ways to represent automata:
 *
 *     1.  transition tables: each state has a transition table associated
 *         that is accessed randomly.
 *     2.  transition sequences: each state has associated a sequence of
 *         edges that is examined sequentially to determine which transition
 *         apply. This saves space, but it is rather slow.
 *
 * The lexer returns the position of the initial character and that of the
 * character following the lexeme.
 *
 *
 * Return
 *
 * To test that a token has been recognised by the lexer there is a need
 * to test if its token number is in the set of the ones returned by the
 * lexer.
 * The final state can be returned, which can then be used to access the state
 * lexeme table and obtain the set of recognised lexemes. This would relieve
 * from returning a set. However, this is not correct since the notion of
 * states is internal to the lexing engine. A reference to the set of tokens
 * could be returned instead having them represented as arrays of booleans.
 * In any state there are not many lexemes recognized, though. For most states
 * only one or two, and thus these sets would be very sparse. To save memory,
 * the arrays could be compressed into byte[] arrays. This allows in typical
 * lexers to save 4..5 Kbytes.
 * Since there can be many states which match the same set of tokens, sets
 * could be shared: the entries in the lexSet table for such states refer to
 * the same set object.
 * However, also these arrays are space consuming, expecially for the lexicons
 * which are not ambiguous. Moreover, with ambiguous lexicons ofthen the first
 * declared lexeme is used by applications, which means that such memory is
 * really wasted.
 * Additionally, there is a need to allow callers to write a switch statement
 * after a call to lex(): if the caller knows that there is no ambiguity, in
 * the case alternatives it treats a lexeme, otherwise it can apply whatever
 * means to disambiguate it or to treat all the recognised lexemes.
 * To allow that, an integer value is returned which identifies uniquely the
 * set of the recognised lexemes. Note that it does not denote states, but
 * sets of lexemes.
 * Note that several final states can recognize the same sets of lexemes.
 * They cannot be merged because what follows may be not the same. E.g.
 * all the intermediate states of keywords can recognize also identifiers.
 * To do it, all sets are given a unique value which is recorded in the
 * higher 16 bits of the state attributes. Code zero is reserved to denote
 * no recognizion.
 * A table, indexed by sets codes, contains the sets represented as arrays
 * of token numbers, in increasing token number.
 * In the cases in which the caller needs to make a fast test to determine
 * if a given lexeme has been recognized, a compact lexemes set map can be
 * generated instead of the lexemes lists by setting the LEXEMES_MAP in
 * ParserLexGen. In occupies roughly half the space as the lists.
 * The map is stored as a comb-vector, and the base index in it where the
 * map of the recognized lexemes is stored is returned.
 * The caller then can test the map at the index: code + token number.
 * If it contains the same code, then that lexeme has been recognized.
 * A section in the listing reports the association between integer codes
 * and sets of lexemes so that the user can check if there is ambiguity.

Generate also a file containing the constants.
The user can have Parser print the list, extract it and edit it adding
names to each set and then feeding back such a list into the source.
Parser will then produce the definitions of those names adding to them
the appropriate constant. E.g.:

    private static FOR_IDENT = for <identifier>

in the input would e.g. produce:

    private static FOR_IDENT = 123;

Include in it also the constants for the start states.


todo

- use jpre here to generate the versions with/without tracing
- document better what is returned .. it seems an int representing the classes of
  lexemes or sets of lexemes, which I do not remember they are defined.
  It seems that it returns an int: 0 = no token got, > 0 = index in tokLists, at which
  entry there is an array of token numbers (0..numOfToks being the last the EOF, indexes
  in tokOrder, at which entries there are the indexes in tokStrings with the types (names) of
  tokens. The toString() method delivers a string with the chars of the last lexeme delivered.

- nested lexemes

  Riglr as a recognizer could be useful to implement lexers: it could be faster (besides
  supporting all CFGs) than a LR lexer. For lexers only recognizion is needed.
  It should allow fast, regular recognizion for regular lexemes, and LR for the non-regular
  ones (but there is a need to see how to support differences, complementation, etc.) in it.
  My lexer builds a DFA and uses regular recognizion, but it is not able to accept lexemes
  with a nested structure like, e.g. nested comments.

     - in a lexer I could solve ambiguity in some standard way (I do so for the REs in it),
       and so keep only one state and one stack for self-embedding (i.e. have only one process
       descriptor).
     - we can reject a lexis that contains hiddend left recursive plus selfembedding nts (as
       we could reject the ones that contain conflicts) if they are a problem.
       Note that my lexer supports hidden left recursion (but not self-embedding).
       Have a look if the recognizer performs endlessly push actions in such a case, and if
       it is not possible to label push actions with terminals, thus removing the ones that
       would consume no input. A lexer should be fast, and avoid to make transitions that
       consume no input. If that is not possible, to support hidden-left, selfembedding nts,
       it should not add a new stack node if the current one has the same state 
     - when the lexer has to treat a selfembedding nt, it pushes a node to predict it
       and when it has recognised it, it makes a pop to the return node it has saved in the stack.
     - I think that the construction of the fa should be similar to that of the normal lr(0)
       fa, but with nonterminals multiplied out, and selfembedded nts terminalized, reductions
       transformed to edges to the goto states, edges labelled with nts removed, and probably
       with some cycles for recursion
*/



public class ParserLex {

    /** The reference to the automaton. */
    protected ParserTables aut;

    /** The reference to the input object. */
    protected Object inp;

    /** The reference to the input stream. */
    protected BufReader stream;

    /** The default block size for reading input. */
    protected static final int BLOCK_SIZE = 2048;

    // Vaues kept here to speed up lex()

    /* The category map of the automa. */
    char[][] catMap;

    /* The category map of the first 256 characters of the automa. */
    char[] catMap0;

    /* The transition table of the automa. */
    char[][] transTable;

    /* The comb-vector transition table of the automa. */
    int[] tabMerged;

    /* The state attributes of the automa. */
    int[] stateAttrs;

    /* The initial state of the automa. */
    char initialState;


//    int err;          // error code
// these are io errors, or internal repositioning errors, or
// calls to lex() when the eof is a symbol and has been already scanned

    private static final int  lex_end_err = 1;  // terminated input
    private static final int  lex_rep_err = 2;  // reposition error
    private static final int  lex_ios_err = 3;  // io error


    /** The trace flags. */
    protected int trc;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    a   input operations trace
     *    b   input operations detail
     * </pre></blockquote><p>
     */

    static final int FL_A = 1 << ('a'-0x60);
    static final int FL_B = 1 << ('b'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Construct a lexing engine.
     */

    public ParserLex(){
    }

    /**
     * Construct a lexing engine.
     *
     * @param      au automaton
//     * @param      stream input stream
     */

//    public ParserLex(ParserTables au, BufReader stream){
    public ParserLex(ParserTables au){
        this.aut = au;
//        this.stream = stream;
        this.catMap = this.aut.catMap;
        this.catMap0 = this.aut.catMap0;
        this.transTable = this.aut.transTable;
        this.tabMerged = this.aut.tabMerged;
        this.stateAttrs = this.aut.stateAttrs;
        this.initialState = this.aut.initialState;
    }

    /**
     * Construct a lexing engine.
     *
     * @param      au automaton
     * @param      inp input object
     * @param      size size of the input buffer
     */

    public ParserLex(ParserTables au, Object inp, int size){
        this(au,new BufReader(inp,size));
    }

    /**
     * Construct a lexing engine.
     *
     * @param      au automaton
     * @param      inp input object
     */

    public ParserLex(ParserTables au, Object inp){
//        this(au,new BufReader(inp,BLOCK_SIZE));
        this(au);
        if (inp != null){
            if (inp instanceof BufReader){
                this.stream = (BufReader)inp;
            } else {
                this.stream = new BufReader(inp,BLOCK_SIZE);
            }
        }
    }

    /**
     * Set the text in this lexer.
     *
     * @param      inp input object
     */

    public void setText(Object inp){
        if (inp != null){
            if (inp instanceof BufReader){
                this.stream = (BufReader)inp;
            } else {
                this.stream = new BufReader(inp,BLOCK_SIZE);
            }
        }
    }

    /** 
     * Trace the state of this lexer.
     */

    void trace(){
        Trc.out.println("index: " + index());
    }

    /**
     * The number of bits to shift a character to obtain the block
     * number in the category table.
     */
    protected static final int CAT_SHIFT = ParserTables.CAT_BLK_BITS;

    /**
     * The mask to obtain the offset in the block of the category table
     * for a character.
     */
    protected static final int CAT_MASK = (1 << CAT_SHIFT) - 1;

    /**
     * Deliver the next lexeme.
     *
//...
     * @param      ???????????? kind of lexeme, set of lexemes ....
     * @return     code of the set of the lexemes recognised, 0 if none
     *             recognized
     */

    /*
     * The cursor runs a couple of characters ahead because when the last
     * character of a lexeme is scanned, the cursor is autoincremented, which
     * means that it refers to the character after the last. Then, since
     * scanning continues until no more transitions are possible, the next
     * character is taken (the one which does not belong to the lexeme), and
     * the cursor autoincremented. However, since the cursor is recorded at
     * every final state, it is taken back to its correct position.
     * This in order to spare a statement which increments it after.
     *
     * The test on the state made at the beginning of the loop allows to
     * recognize also the empty string, which is not strictly necessary, but
     * makes it more complete. Moreover, it allows to spare a while (true) at
     * the end of the loop.
     *
     * When a ParserLex is built, the BufReader is built as well. The
     * initial values of cursor and end are known to be zero. Therefore,
     * the initial index can be computed, and the mark set as well.
     * However, when scanning is resumed after some other method took
     * over processing, cursor is equal to end, but not known. Thus, to
     * set the mark (which is used here as start index as well), a mark()
     * is done, which sets the mark to the first unscanned character whatever
     * its position is.
     *
     * The index of the first character of the lexeme is:
     *
     *     this.stream.index - end + cursor;
     *
     * computed when cursor denoted the first character. Likewise, it
     * is the index of the end of the lexeme if computed at the end.
     */

// then keep only one here

// comment out tracing in lex(), or call a lex1() in
// it with the tracing on

// this is O.K. with respect to the old one. It does not treat
// constraints and subgraphs, which were drafted in the old one.

// if an eof is encountered at the beginning what state is returned?
// -1 now, but if EOF is a lexeme, then something must be done
// if I test if (at eof) ... then I can decide to return the same
// EOF lexeme several times of one time only.
// What if EOF is a lookahead?


/*    public int lex(){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("lex start");
        }

        char[][] catMap = this.aut.catMap;       // place references into
        char[] catMap0 = catMap[0];              // .. variables to speed up
        char[][] transTable = this.aut.transTable;
        int[] stateAttrs = this.aut.stateAttrs;
        char[] buffer = this.stream.buffer;
        int cursor = this.stream.cursor;
        int end = this.stream.end;

        int acceptAttrs = 0;                     // last recongnized lexemes
        char state = this.aut.initialState;      // initial state
        int lastPos = 0;                         // last position matched

        if (cursor == end){
            this.stream.mark();
        } else {
            this.stream.markPos = cursor;        // mark start of lexeme
        }

        loop: do {
            char ch;
            char cat;
            int attrs;
            if ((attrs = stateAttrs[state]) != 0){           // special
                boolean finalState = (attrs &                // final
                    ParserTables.FINAL) != 0;
                if ((attrs & ParserTables.LOOPING) != 0){    // looping
                    char[] ttable = transTable[state];
                    char loopstate = state;
                    do {
                        if (cursor == end){                  // get symbol, no data
                            int n = this.stream.readBlock(); // get next block
                            cursor = this.stream.cursor;     // reload indexes
                            end = this.stream.end;
                            buffer = this.stream.buffer;
                            if (n < 0){                      // no symbol, eof
                                if (finalState){             // remember it
                                    lastPos = cursor - this.stream.markPos;
                                    acceptAttrs = attrs;
                                }
                                cursor++;        // cater for cursor-- below
                                break loop;      // no more characters
                            }
                        }
                        ch = buffer[cursor++];   // get symbol and advance
                        cat = (ch <= 0xff) ? catMap0[ch] :
                            catMap[ch >> CAT_SHIFT][ch & CAT_MASK];
                        //Trc.out.println("loop ch: |" + ch + "| cat: " + cat + " looping");
                    } while ((state = ttable[cat]) == loopstate);
                    if (finalState){             // final
                        lastPos = cursor - this.stream.markPos - 1;
                        acceptAttrs = attrs;
                    }
                    if (state == 0) break loop;
                    continue;
                }
                if (finalState){                 // final, remember it
                    lastPos = cursor - this.stream.markPos;
                    acceptAttrs = attrs;
                }
            }
            if (cursor == end){                  // get symbol, no data
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("next block");
                }
                int n = this.stream.readBlock(); // get next block
                cursor = this.stream.cursor;     // reload indexes
                end = this.stream.end;
                buffer = this.stream.buffer;
                if (n < 0){                      // no symbol, eof
                    cursor++;                    // cater for cursor-- below
                    break;                       // no more characters
                }
            }
            ch = buffer[cursor++];               // get symbol and advance
            if ((FL_B & this.trc) != 0){
                Trc.out.println("char: " + ch);
            }
            cat = (ch <= 0xff) ? catMap0[ch] :
                catMap[ch >> CAT_SHIFT][ch & CAT_MASK];
            state = transTable[state][cat];      // move(state,symbol)
            if ((FL_B & this.trc) != 0){
                Trc.out.println("cat: " + cat + " next: " + (int)state);
            }
        } while (state > 0);
        acceptAttrs &= ParserTables.FINAL;
        if ((FL_B & this.trc) != 0){
            Trc.out.println("cursor: " + cursor +
                " markPos: " + this.stream.markPos +
                " acceptAttrs: " + acceptAttrs +
                " lastPos: " + lastPos);
        }

        if (acceptAttrs > 0){                    // recognized
            cursor = lastPos + this.stream.markPos;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("lexeme at: " +
                    (this.stream.index - end + this.stream.markPos) + " " +
                    String.valueOf(this.stream.buffer,
                       this.stream.markPos,
                       cursor - this.stream.markPos));
            }
        } else {                                 // no match, back to wrong char
            cursor--;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("no match at: " + cursor);
            }
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("end loop: index " +
                this.stream.index + " pend: " + this.stream.pendPos +
                " cursor: " + cursor + " end: " + end);
        }
        if ((FL_A & this.trc) != 0){
            Trc.out.println("lex return: " +
                (acceptAttrs > 0) + " at: " +
                (this.stream.index - end + this.stream.markPos) + ":" +
                (this.stream.index - end + cursor));
        }
        this.stream.cursor = cursor;    // store back new indexes
        return acceptAttrs >>> ParserTables.TOKCODE_SHIFT;
    }
*/

    /*
    // lex() basic without tracing and no comb tables

    public int lex(){
        char[][] catMap = this.catMap;           // place references into
        char[] catMap0 = this.catMap0;           // .. variables to speed up
        char[][] transTable = this.transTable;
        int[] stateAttrs = this.stateAttrs;
        char[] buffer = this.stream.buffer;
        int cursor = this.stream.cursor;
        int end = this.stream.end;

        int acceptAttrs = 0;                     // last recongnized lexemes
        char state = this.initialState;          // initial state
        int lastPos = 0;                         // last position matched
        if (cursor == end){
            this.stream.mark();
        } else {
            this.stream.markPos = cursor;        // mark start of lexeme
        }
        char ch;
        char cat;
        do {
            int attrs;
            if ((attrs = stateAttrs[state]) != 0){  // special
                if ((attrs &                     // final
                    ParserTables.FINAL) != 0){   // remember it
                    lastPos = cursor - this.stream.markPos;
                    acceptAttrs = attrs;
                }
            }
            if (cursor == end){                  // get symbol, no data
                int n = this.stream.readBlock(); // get next block
                cursor = this.stream.cursor;     // reload indexes
                end = this.stream.end;
                buffer = this.stream.buffer;
                if (n < 0){                      // no symbol, eof
                    cursor++;                    // cater for cursor-- below
                    break;                       // no more characters
                }
            }
            ch = buffer[cursor++];               // get symbol and advance
            cat =
                (ch <= 0xff) ? catMap0[ch] :
                ((catMap == null) ? 0 : catMap[ch >> CAT_SHIFT][ch & CAT_MASK]);
            //Trc.out.println("ch: |" + ch + "| cat: " + (int)cat + " nextstate: " + (int)transTable[state][cat]);
            state = transTable[state][cat];      // move(state,symbol)
        } while (state > 0);
        acceptAttrs &= ParserTables.FINAL;
        //Trc.out.println("acceptAttrs: " + acceptAttrs);
        if (acceptAttrs > 0){                    // recognized
            cursor = lastPos + this.stream.markPos;
        } else {                                 // no match, back to wrong char
            cursor--;
        }
        this.stream.cursor = cursor;    // store back new indexes
        return acceptAttrs >>> ParserTables.TOKCODE_SHIFT;
    }
    */


    // lex with pruned + merged tables + looping

    public int lex(){
        char[][] catMap = this.catMap;           // place references into
        char[] catMap0 = this.catMap0;           // .. variables to speed up
        int[] tabMerged = this.tabMerged;

        char[] buffer = this.stream.buffer;
        int cursor = this.stream.cursor;
        int end = this.stream.end;

        int acceptAttrs = 0;                     // last recongnized lexemes
        char state = this.initialState;          // initial state
        int lastPos = 0;                         // last position matched
        if (cursor == end){
            this.stream.mark();
        } else {
            this.stream.markPos = cursor;        // mark start of lexeme
        }
        int elem;
        loop: do {
            char ch;
            char cat;
            int attrs;
            if ((attrs = tabMerged[state-2]) < 0){           // special
                if ((attrs & ParserTables.LOOPING) != 0){    // looping
                    if ((attrs &= ParserTables.FINAL) != 0){
                        acceptAttrs = attrs;
                    }
                    char loopstate = state;
                    do {
                        if (cursor == end){                  // get symbol, no data
                            int n = this.stream.readBlock(); // get next block
                            cursor = this.stream.cursor;     // reload indexes
                            end = this.stream.end;
                            buffer = this.stream.buffer;
                            if (n < 0){                      // no symbol, eof
                                if (attrs != 0){             // remember it
                                    lastPos = cursor - this.stream.markPos;
                                }
                                cursor++;                    // cater for cursor-- below
                                break loop;                  // no more characters
                            }
                        }
                        ch = buffer[cursor++];               // get symbol and advance
                        cat =
                            (ch <= 0xff) ? catMap0[ch] :
                            ((catMap == null) ? 0 : catMap[ch >> CAT_SHIFT][ch & CAT_MASK]);
                        if ((char)(elem = tabMerged[state+cat]) != state){
//                            state = (char)(tabMerged[state-1] >> 16);
                            state = (char)(tabMerged[state-1] >> ParserTables.NSHIFT);
                            if ((char)(elem = tabMerged[state+cat]) != state){
                                if (attrs != 0){             // remember it
                                    lastPos = cursor - this.stream.markPos - 1;
                                }
                                break loop;
                            }
                        }
                    } while ((state = (char)(elem >> ParserTables.NSHIFT)) == loopstate);
                    if (attrs != 0){             // remember it
                        lastPos = cursor - this.stream.markPos - 1;
                    }
                    continue loop;
                }
                if ((attrs &= ParserTables.FINAL) != 0){     // remember it
                    lastPos = cursor - this.stream.markPos;
                    acceptAttrs = attrs;
                }
            }
            if (cursor == end){                  // get symbol, no data
                int n = this.stream.readBlock(); // get next block
                cursor = this.stream.cursor;     // reload indexes
                end = this.stream.end;
                buffer = this.stream.buffer;
                if (n < 0){                      // no symbol, eof
                    cursor++;                    // cater for cursor-- below
                    break;                       // no more characters
                }
            }
            ch = buffer[cursor++];               // get symbol and advance
            cat =
                (ch <= 0xff) ? catMap0[ch] :
                ((catMap == null) ? 0 : catMap[ch >> CAT_SHIFT][ch & CAT_MASK]);
            if ((char)(elem = tabMerged[state+cat]) != state){
                state = (char)(tabMerged[state-1] >> 16);
                if ((char)(elem = tabMerged[state+cat]) != state) break;
            }
        } while ((state = (char)(elem >> ParserTables.NSHIFT)) > 0);
        if (acceptAttrs > 0){                    // recognized
            this.stream.cursor = lastPos + this.stream.markPos;
        } else {                                 // no match, back to wrong char
            this.stream.cursor = --cursor;
        }
        return acceptAttrs >> ParserTables.TOKCODE_SHIFT;
    }

    /** 
     * Deliver the string of the lexeme delivered by the last lexing operation.
     * It delivers no string if the last lexing operation delivered no lexeme.
     *
     * @return     string
     */

    public String toString(){
        if (this.stream.cursor == this.stream.markPos){
            return "";
        }
        return String.valueOf(this.stream.buffer,this.stream.markPos,
            this.stream.cursor - this.stream.markPos);
    }

    /** 
     * Store the string of the lexeme delivered by the last lexing operation
     * in the specified array.  It stores no string if the last lexing
     * operation delivered no lexeme.
     *
     * @param      buf buffer
     * @param      off index of the element at which the string is stored
     * @return     length of the string
     */

    public int toChars(char[] buf, int off){
        int len = this.stream.cursor - this.stream.markPos;
        System.arraycopy(this.stream.buffer,this.stream.markPos,
            buf,off,len);
        return len;
    }

    /** 
     * Deliver the length of the lexeme delivered by the last lexing
     * operation. It delivers zero if the last lexing operation delivered
     * no lexeme.
     *
     * @return     length
     */

    public int length(){
        return this.stream.cursor - this.stream.markPos;
    }

    /** 
     * Deliver the index in the stream of the current lexing position
     * (which is the index of the first character past the last delivered
     * lexeme).
     *
     * @return     index
     */

    public long index(){
        return this.stream.index - this.stream.end + this.stream.cursor;
    }

    /** 
     * Reposition the stream to allow other methods to take over scanning.
     */

    public void reposition(){
        this.stream.markPos = this.stream.cursor;
        this.stream.cursor = this.stream.end = 0;
        this.stream.reset(0);
        this.stream.markPos = -1;
    }

    /** 
     * Tell if the last lexing operation occurred at end of file.
     *
     * @return     <code>true</code> if it is at the eof
     */

    /* Note that this does not tell whether the lexer is at the eof,
     * which can occur when a lexeme has been delivered and the lexer had
     * to go past it an in doing that it stuck the eof. It is the same
     * as any read operations, which can deliver data and reach the end
     * of the file. The correct condition returned is that an operation
     * delivered no data, but the eof.
     */

// jflex allowed to call it also at the beginning. Since atEof was
// initialized to false, while ( !scanner.yy_atEOF ) scanner.yylex()
// worked. I think that this is wrong. The correct thing is to call
// first lex().
// Moreover, atEof was used to retract the cursor when a BOL had
// to be tested and a \n was found. A character was taken: since it
// is there a lookbehind, when that characters existed (i.e. read()
// did not deliver an eof), it was unread. The test there is wrong
// though.

    public boolean eof(){
        int len = this.stream.cursor - this.stream.markPos;
        return (len == 0) && this.stream.eof();
    }

    /** 
     * Terminate lexing and close the stream.
     */

    /* The stream can be closed separately, and then the lexer terminated.
     * This spares to know it.
     */

    public void close() throws IOException {
        this.aut = null;                  // release memory
        this.stream.close();
        this.stream = null;
    }
}
