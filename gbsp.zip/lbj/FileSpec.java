/*
 * @(#)FileSpec.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;
import java.io.*;
import java.util.*;

/**
 * The <code>FileSpec</code> class provides manipulation of strings
 * which denote files, either as local files or as URIs.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

/**
 * <b>Filespecs and Operating Systems</b>
 * <p>
 * Operating Systems have a native way to treat filespecs, i.e. strings
 * which denote files in commands, scripts, etc., which ultimately are
 * passed as arguments to system calls or system library calls to operate
 * on the file systems. Some OSs support several shells. However, they
 * always have a native way to treat filespecs (filestrings), which is
 * described in the following.
 * <p>
 * Unix:
 * <ol>
 * <li>devices are denoted by /dev/xxx
 * <li>the directory separator is one or more `/'.
 * <li>a path is absolute if it starts with `/', otherwise it is relative.
 * <li>there are no standard names for stdin, stdout and stderr. Some
 *   Unixes use /dev/stdin, etc..
 * <li>a directory path can also end with `/'. i.e. "/dev" and "/dev/",
 *   where "dev" is a directory, are equivalent for many applications.
 *   However, in general that is not guaranteed.
 * <li>the current directory is ".", the upper level "..". Directories
 *   are files whose filename is a normal filename.
 * <li>there is no standard on how file-types are indicated, but the usual
 *   convention is that it is the portion of a filespec from the last
 *   "." that is not part of a directory up to the end. Since it is part
 *   of the filespec, a filespec ending in "." is different from one
 *   that has not it. Note that since "." and ".." are reserved filanames,
 *   they are not files with a "." filetype.
 *   Although there is no standard, files whose name is empty, and that have
 *   a non-empty filetype are hidden, like e.g. ".profile". For them, the
 *   part after "." can be considered as a filetype or not since there is
 *   nothing that depends on this.
 * <li>filenames are made of at least one character which is not a NUL or
 *   a `/'. They are case sensitive.
 * </ol>
 * Note that it is not possible to refer to the home directory as "~"
 * because "~" is resolved by shells.
 * <p>
 * Windows:
 * <ol>
 * <li>devices are denoted by dev: (where dev is a drive name).
 * <li>the directory separator is one or more `\'.
 * <li>a path is absolute if it starts with `\', possibly preceded by a device
 *    name.
 * <li>same.
 * <li>same, with `\'.
 * <li>same.
 * <li>file-types are separated from the filename by `.'. A filespec ending
 *   in `.' denotes the same file as if it had it not.
 * <li>filenames (including extensions) are made of up to 255 characters,
 *   excluding: "?", "&quot;", "/", "\", "&lt;", "&gt;", "*", "|", ":"
 *   and control characters.
 *   They are case insensitive. Either the filename or the extension must
 *   be present; they cannot be both absent.
 * </ol>
 * VMS (DCL):
 * <ol>
 * <li>the directory separator is one `.'. The whole directory is enclosed
 *   in `[]'.
 * <li>a path is relative if it starts with an optional device name and
 *   an optional directory that is "[]" or "[.xxx...]".
 * <li>the standard names are sys$input:, etc..
 * <li>[xxx.yyy] and [xxx]yyy.dir are different, although they refer to
 *    the same object.
 * <li>the current directory is "[]" the upper level "[-]", upper ones "[--]".
 *    Directories are filenames with a ".dir" filetype
 * <li>same as Windows.
 * <li>the characters which can be part of a filename are uppercase letters,
 *   numbers, and `$'.
 *   They are case insensitive.
 * </ol>
 * In VMS there is a notation for a relative directory, e.g.: "[xxx.]",
 * which is used only when a logical name is translated and the directory in
 * it is merged with the one that follows. E.g.: "[aaa.][xxx]" is merged
 * into "[aaa.xxx]". In commands, like e.g. "dev:[dir]file1,[.xxx]file2" the
 * second directory is relative to the current one, not the one of the
 * previous file. "[-.-]" is the same as "[--]".
 * <p>
 * A filestring has the general syntax:
 * <p><font size=-1><pre>
 *    [device :] [directory] [filename] [. filetype] [; version]
 * </pre></font><p>
 * The <code>device</code> field does not include the ":".
 * The directory is delimited in a way which is OS dependent (as defined
 * above).
 * As a special case, a filename which is "." or ".." denotes a directory
 * when the OS is Unix or Windows (Dos, NT, etc.).
 * Note that there can be a difference between a filetype which is not
 * present (i.e. there is no `.'), and one which is empty (i.e. filespec
 * ending in `.').
 * The filetype is the tail of the filestring (up to the version, if any)
 * from the last `.' onwards (except when filename.filetype is "." or ".."
 * which are considered to be filename). Note also that "...xxx" is
 * parsed into a filename ".." and a filetype ".xxx". This is coherent
 * with the assumption that ".." is a file as any other.
 * The directory, filename and filetype are collectively called "path".
 * The <code>filetype</code> field includes the ".".
 * Paths can contain also "." and "..", e.g. "dev:/a/b/c/../d/./f".
 * They are not reduced, but kept as they are (e.g. the latter is not changed
 * into "dev:/a/b/d/f").
 * The version is present only in VMS; the <code>version</code> field does not
 * include the ";".
 * <p>
 * File parsing detects filespecs which denote standard files. These are
 * the specs which are detected:
 * <p><font size=-1><pre>
 *                           Unix            NT    VMS
 *    standard input         /dev/stdin, -   con   sys$input:
 *    standard output        /dev/stdout     con   sys$output:
 *    standard error         /dev/stderr     con   sys$error:
 *    controlling terminal   /dev/tty        con   tt:
 *    null device            /dev/null       nul   nl:
 * </pre></font><p>
 * Constant strings are provided as platform-independent denotations for
 * standard files. When <code>parseFile()</code> or <code>resolveFile()</code>
 * receive it as parameter, they record in the FileSpec object the
 * corresponding file; when they receive a reference to a filespec string
 * which is not one of these, they record the set of standard files which
 * match with that string.
 * <p>
 * The parsing of a filespec that denotes a directory file (e.g. /usr in
 * unix) delivers a directory, not a filename.
 * <p>
 * <b>Uniform Resource Identifiers</b>
 * <p>
 * With Internet, it is possible to access files which reside on other
 * machines. Even when they are not actually files (i.e. when they are
 * presented on the fly as such), they can be seen as files which are
 * identified by a specific notation.
 * <p>
 * A URI, as defined in RFC 2396 has the general syntax:
 * <p><font size=-1><pre>
 *    [scheme :] [// authority] [path] [? query] [# fragment]
 * </pre></font><p>
 * <p>
 * <b>Parsing</b>
 * <p>
 * Parsing strings into filestrins and URIs is the breaking of such strings
 * into their components. The abovementioned syntaxes are such that each
 * component is made of all the characters which may not be the starting
 * delimiter of the following ones except for the filetype, which is the
 * shortest tail that starts with `.'.
 * Note that this holds also when the `.' is in the first position
 * because otherwise it would not be possible to resolve filestrings which
 * consist solely by a filetype angainst a filespec which could contain
 * a filename. Applications which need to treat Unix hidden files should
 * take the path as such without making any breaking into filename and
 * filetype.
 * This allows to break a filestring into components leaving them to more
 * specific methods to chech the contents of them.
 * When parsing a filestring, the path is also delivered, and when parsing
 * a URI, the directory, filename and filetype are also delivered so as
 * to unify them as much as possible.
 * This simplifies some operations, like e.g. resolution of relative URIs
 * (for which there is a need to further parse the path).
 * <p>
 * <b>Resolution</b>
 * <p>
 * Resolution (or propagation) takes place when an application chooses
 * to let the user abbreviate filestrings by omitting compontents which
 * have been specified previously, like e.g. in a sequence of files in
 * a command, or URIs in a document. Applications can have a "defaults"
 * for missing components (like e.g. the current directory) which are
 * used as a last resort when they are nowhere specified.
 * With propagation there are two aspects to take into account:
 * <ol>
 * <li>what components should be propagated and when.
 * <li>how to denote the willingness to use defaults. E.g. how to denote the
 *   current directory. This is OS dependent.
 * </ol>
 * <p>
 * <b>Resolution of relative filestrings</b>
 * <p>
 * A filestring is resolved towards a base one by building the resultant
 * one as follows:
 * <ul>
 * <li>if it has no device in it, the device is the base's one. If none
 *   is present, it is the current working device,
 * <li>if it has no directory in it, the directory is the base's one,
 * <li>it it has an absolute directory, the directory is that one, otherwise
 *   it is resolved as relative directory with respect to the base's one,
 *   except when it is the current directory explicit denotation.
 *   If eventually no directory is present, the directory is the current
 *   working directory.
 * <li>if it has no filename in it, the filename is the base's one,
 * <li>the filetype is propagated if a default one is provided (possibly
 *   an empty string),
 * <li>the version is the current's one,
 * <li>if it is a standard device, the filestring is the resultant one,
 * <li>otherwise if the base is a standard device, the base is the resultant
 *   one,
 * <li>if the resulting filespec denotes a Unix device, the whole filespec
 *   is represented as a device with all other attributes empty.
 * </ul>
 * Note that a directory is propagated if a relative one is present in the
 * filespec.
 * Note also that when propagation is in effect, an empty filespec is not an
 * empty filename, but a partial filespec which is resolved against the
 * base one.
 * To disable the filetype propagation, the default filetype should be set
 * to <code>null</code>.
 * <p>
 * <b>Resolution of relative URIs</b>
 * <p>
 * Resolution is provided as defined in RFC 2396 for validating parsers:
 * by terming a URI as relative if it has no scheme in it. Moreover,
 * sequences of '/' are reduced to one '/'. A current URI
 * is resolved towards a base URI as follows:
 * <ul>
 * <li>if there is no base URI, or the base is relative, or the current
 *   is absolute, the resultant is the current with the filetype propagated,
 * <li>if the current has only the fragment (i.e. it refers to the same
 *   "document" as the base one, the resultant is the base one up to the
 *   query and the fragment of the current one,
 * <li>if the current one has no authority, the resultant is the base
 *   scheme and authority, its directory plus the currant's path (reduced)
 *   plus the filetype propagated and the current's query and fragment,
 * <li>otherwise the resultant is the base's scheme and the rest from
 *   the current, with the filetype propagated.
 * </ul>
 * For URIs the resolution algorithm merges the paths. This means that
 * a URI resolves its path, if relative, to the base one. E.g. in a
 * command a URI resolves to the previous one.
 * This means that the directory becomes the current one for the following
 * one. This means to use an absolute path when the path is not relative
 * to the previous one, and a relative one otherwise.
 * It is not strange that there is a different rule since there is no default
 * directory for URIs.
 * <p>
 * <b>Jar URIs</b>
 * <p>
 * Jar URIs are treated as defined in Java.
 * <p>
 * <b>Propagation of filetypes</b>
 * <p>
 * There are applications which apply defaults to file types.
 * The propagation (and defaulting) of filetypes is made with the assumption
 * that the specs which have a tail starting with dot, have a filetype, except
 * when the dot is the first character of the spec. E.g. in "xxx.tar.gz"
 * ".gz" is the filetype, in ".profile" there is no filetype.
 * In other words there are specs which have a dot in them, but they
 * have always a filetype. E.g. "aaa.bbb" as a spec in which there is
 * no filetype does not exist. I.e. there are no filenames with a dot in them.
 * <p>
 * A solution could be to apply always the default, except when the filename
 * ends with a dot.
 * Let's try to make a summary of the cases that would occur then:
 * <p><font size=-1><pre>
 * name      filetype         example      notation      resultant  propagates
 *
 * 1 no dot, impl. filetype   aaa.def      aaa           aaa.def      ".def"
 * 2 no dot, filetype         aaa.fty      aaa.fty.      aaa.fty      ".fty"
 * 3 no dot, filetype empty   aaa          aaa.          aaa          ""
 * 4 no dot, filetype blank   aaa.         aaa..         aaa.         "."
 *
 * 5 dot,    impl. filetype,  aaa.bbb.def  aaa.bbb       aaa.bbb.def  ".def"
 * 6 dot,    filetype,        aaa.bbb.fty  aaa.bbb.fty.  aaa.bbb.fty  ".fty"
 * 7 dot,    filetype blank   aaa.bbb.     aaa.bbb..     aaa.bbb.     "."
 * </pre></font><p>
 * In VMS a filespec either has a filetype in it, possibly blank, or not.
 * The previous solution attempts to be close to the VMS one, in which to
 * denote a file which has a blank filetype in a list of filespecs with
 * propagation there is a need to put a dot at the end. This is so because
 * "file" and "file." are there the same. Here, however, there is also a
 * "file." which is not the same as a "file". By far "file." is seldom used,
 * and thus its notation can be more complex of the other one.
 * The other strange thing is the need to put a dot after a spec with
 * a filetype to disable propagation.
 * The rule seems simple: if the spec ends with a dot, remove it and do not
 * append the default, otherwise append the default.
 * To remove the strangeness for case 2 and 6, the rule can be changed by
 * stating that if the spec has a filetype, no propagation is done. This
 * means that in case 5, the user has to write aaa.bbb.def. This seems
 * acceptable because the cases in which that occurs are less than the
 * ones in which it does not.
 * <p><font size=-1><pre>
 * name      filetype         example      notation      resultant  propagates
 *
 * 1 no dot, impl. filetype   aaa.def      aaa           aaa.def      ".def"
 * 2 no dot, filetype         aaa.fty      aaa.fty       aaa.fty      ".fty"
 * 3 no dot, filetype empty   aaa          aaa.          aaa          ""
 * 4 no dot, filetype blank   aaa.         aaa..         aaa.         "."
 *
 * 5 dot,    impl. filetype,  aaa.bbb.def  aaa.bbb.def   aaa.bbb.def  ".def"
 * 6 dot,    filetype,        aaa.bbb.fty  aaa.bbb.fty   aaa.bbb.fty  ".fty"
 * 7 dot,    filetype blank   aaa.bbb.     aaa.bbb..     aaa.bbb.     "."
 * </pre></font><p>
 * When file-type propagation or defaulting is requested, a file-type is
 * appended when one is not present (not even an empty one), being that
 * an empty one denote an explicit blank filetype: a ending `.' is
 * removed and no filetype is appended. To denote a filetype which is `.',
 * two `..' are needed. An empty filetype propagates onto a following
 * filestring in which the filetype is not specified by taking the latter
 * unchanged.
 * <p>
 * <b>Propagation of filestrings and URIs</b>
 * <p>
 * Propagation is also defined in general on filespecs as follows:
 * <ul>
 * <li>if the current one contains a scheme longer than one character,
 *   which is not "file:" (case insensitive), and is followed by at least
 *   one other character, it is taken as a URI,
 *   otherwise "file:" (if present) is removed and the rest is taken as a
 *   filestring (i.e. a filespec which matches a filestring is taken as
 *   that, not as a relative URI);
 * <li>if the current one is a filestring, it is resolved against a
 *   base one which is a filestring, or against no base one;
 * <li>otherwise it is resolved against a base one if that is also a
 *   URI (i.e. a URI is not used as a base for a filestring and viceversa),
 *   or against no base one;
 * <li>a filespec (after resolution) usually becomes the base for the
 *   following one.
 * </ul>
 * <b>Internal representation</b>
 * <p>
 * Filespecs are represented internally with a char[] which allows fast
 * parsing and manipulation, and with indexes to it to denote the components.
 * The buffer is reused. The only exception is when the filetype's length
 * is 1: the filetype index does not necessarily indicate a position in
 * the buffer because the `.' could have been removed.
 * <p>
 * <b>Logical names</b>
 * <p>
 * Logical names provide a means to simplify filespecs by replacing parts
 * of them, typically lengthy directories or URIs, by names which are
 * expanded at the time the program connects to the external object.
 * I.e. they are not expanded by shells.
 * In filespecs logical names are represented by a name followed by a colon.
 * <p>
 * FileSpec allows to denote the home directory as "HOME:", the current
 * working directory as "PWD:", and the path from which the main class
 * has been loaded as "LOAD:".
 */

/* The effect of logical names in Unix can be obtained by using directories
 * which are symbolic, and are replaced by something else. E.g.:
 * "/log/dir/pippo", having defined "log" as "ftp:", would become
 * "ftp:/dir/pippo". They would act as links, except that they are not
 * permanent.
 * However, that notation would work for VMS. For NT it ought to be the first
 * directory, and with no device. E.g. substitution would be done only if
 * the symbolic directory occurs at the very beginning.
 * A logical name can expand also in a relative directory. If it is denoted
 * as a directory, that means that it can clash with real directories, i.e.
 * be seen as a subdirectory of any directory when it is written as the
 * first name in a path. Being denoted as a device, it can clash with devices,
 * which occurs very seldom because devices are top-level objects.
 * The rule could be that they are top level directories. E.g. "/pwd/pippo"
 * expanding to "/usr/.../pippo". Or in NT: "\pwd\pippo" expanding to
 * "d:\tmp\...\pippo". But in VMS that is difficult.
 * An alternative could be to delimit a logical name occurrence in a way
 * which is system dependent. However, that would not overcome the weakness
 * of clashes if logical names are denoted as directories. E.g. since "PWD"
 * is a logical name, it is not possible to have a real directory which
 * is "/PWD/xxx", and that holds for all logical names. When a new one is
 * introduced in the environment, all subdirectories of the root ones become
 * inaccessible.
 *
 * A logical name is used for the load directory because the it is a real path,
 * and logicals are the tool for that (unlike standard files which have no
 * path, or need very special handling).
 * To get a file which is not a resource, but it is in the same directory
 * as the main file class (including a jar), the "LOAD:" logical names
 * delivers the URI of the load directory.
 *
 * The directory propagation is done by applying a common rule between
 * filed and URIs because logical names can be used to factor out a part
 * of specs, which can contain a directory or a URI. If there were two
 * different rules, then the user would be forced either to know the contents
 * of logical names, or to use always absolute directories.
 * This rules keeps the possibility to name the current directory when there
 * is a need to do so, by using "PWD:". ./ denotes the directory of the
 * base filespec.
 *
 * Devices in Unix need to be treated in a special way, and standard
 * devices (or files) need that also in Windows. The reason is that their
 * filesystems do not accept directories, filetypes, etc. attached to
 * (standard) devices. E.g. /dev/null/f is not allowed, and a:null is
 * also not allowed.
 * Another reason to treat such devices in a special way is that the
 * structuring of filespecs in fields allows to compose filespecs in an
 * easy way. E.g. suppose a program builds a filespec by taking the one of
 * a file and concatenating a suffix, or by changing the filetype, as it
 * is the case when an output file is passed to it, and the program needs
 * to create an additional one. When the former is the null device, we want
 * that also the second to be the null device. This is simpler if we store
 * the null device as a device instead of a directory and a filename.
 * In the latter case, the program would append a suffix to the name, making
 * it no longer a null device.
 * Note, however, that in unix there are no cases in which we can specify a
 * device and a directory. E.g. /dev/disk/dir/file. Note also that when a
 * filespec starts with /dev, the whole filespec denotes a device.
 * For these reasons, filespecs which denote devices are recognised and
 * stored as devices even if they do not terminate with a colon.
 * This means that when a list of files is processed, a correct result
 * is obtained. E.g. in /dev/null,f, f results in /dev/null, but in
 * /dev/null,/dev/tty the latter stays as it is.
 * There should then be a need to denote the "current" device so as to allow
 * in a list to specify a file after a null device. However, this is not so
 * important, and thus is not provided so as not to complicate the model.
 */

public class FileSpec implements Cloneable {

    /** The kind of filespec: 0: none, 1: file, 2: URI. */
    private int    status;

    /** The default filetype. */
    public  String fty;

    /** The OS kind. */
    private int    os;

    /** Whether the device does not end with a :. */
    private boolean unixDev;

    /* Fields which are specific for files. */

    /** The index of the device. */
    private int    device = -1;

    /** The length of the device. */
    private int    deviceLen;

    /* Fields which are common to files and URIs. */

    /** The index of the directory. */
    private int    directory = -1;

    /** The length of thedirectory. */
    private int    directoryLen;

    /** The index of the filename. */
    private int    filename = -1;

    /** The length of the filename. */
    private int    filenameLen;

    /** The index of the filetype. */
    private int    filetype = -1;

    /** The length of the filetype. */
    private int    filetypeLen;

    /** The index of the version. */
    private int    version = -1;

    /** The length of the version. */
    private int    versionLen;

    /** The mask of standard files. */
    private int    std;

    /* Fields which are specific for URIs. */

    /** The index of the scheme. */
    private int    scheme;

    /** The length of the scheme. */
    private int    schemeLen = -1;

    /** The index of the authority. */
    private int    authority;

    /** The length of the authority. */
    private int    authorityLen = -1;

    /** The index of the path. This is present for files also and denotes
     * the whole filespec except for the device. */
    private int    path;

    /** The length of the path. */
    private int    pathLen = -1;

    /** The index of the query. */
    private int    query;

    /** The length of the query. */
    private int    queryLen = -1;

    /** The index of the fragment. */
    private int    fragment;

    /** The length of the fragment. */
    private int    fragmentLen = -1;

    /** The internal buffer. */
    private char[] buffer;

    /** The trace flags. */
    private int trc;

    /**
     * Construct a FileSpec with a default file-type. If it is null,
     * no propagation is done.
     *
     * @param      str default file-type.
     */

    public FileSpec(String t){
        init();
        this.fty = t;
    }

    /**
     * Re-initialize a FileSpec object.
     */

    public void init(){
        this.status = 0;

        this.device = -1;
        this.deviceLen = 0;
        this.unixDev = false;
        this.directory = -1;
        this.directoryLen = 0;
        this.filename = -1;
        this.filenameLen = 0;
        this.filetype = -1;
        this.filetypeLen = 0;
        this.version = -1;
        this.versionLen = 0;
        this.std = 0;

        this.scheme = -1;
        this.schemeLen = 0;
        this.authority = -1;
        this.authorityLen = 0;
        this.path = -1;
        this.pathLen = 0;
        this.query = -1;
        this.queryLen = 0;
        this.fragment = -1;
        this.fragmentLen = 0;
    }

    /**
     * Trace a FileSpec object.
     */

    public void trace(){
        switch (this.status){
        case 1:
            Trc.out.println(this.device + "+" + this.deviceLen + ":" +
                this.directory + "+" + this.directoryLen + " " +
                this.filename + "+" + this.filenameLen + "." +
                this.filetype + "+" + this.filetypeLen + ";" +
                this.version + "+" + this.versionLen +
                " " + this.path + "+" + this.pathLen +
                " " + this.buffer + " " + this.status + " " + this.unixDev);
            for (int i = 0; i < STD_NAMES.length; i++){
                if (((1<<i) & this.std) != 0)
                    Trc.out.print(STD_NAMES[i] + " ");
            }
            if (this.std != 0) Trc.out.println();
            return;
        case 2:
            Trc.out.println(this.scheme + "+" + this.schemeLen + "://" +
                this.authority + "+" + this.authorityLen + " " +
                this.path + "+" + this.pathLen +
                "?" + this.query + "+" + this.queryLen +
                "#" + this.fragment + "+" + this.fragmentLen +
                " " + this.buffer + " " +
                this.directory + "+" + this.directoryLen + "/" +
                this.filename + "+" + this.filenameLen + "." +
                this.filetype + "+" + this.filetypeLen + " " + this.status);
            return;
        }
        Trc.out.println("status: 0");
    }

    /* Trace */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    a   basic operations
     *    b   detailed trace
     * </pre></blockquote><p>
     */

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    a   basic operations
     *    b   internal operations
     * </pre></blockquote><p>
     */

    private static final int FL_A = 1 << ('a'-0x60);
    private static final int FL_B = 1 << ('b'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Return a String representation of a FileSpec object.
     */

    public String toString(){
        int len = 0;
        switch (this.status){
        case 1:
            int start = 0;
            if (this.device >= 0){
                len += this.deviceLen;
                if (!this.unixDev) len++;
                start = this.device;
            } else {
                start = this.path;
            }
            len += this.pathLen;
            return String.valueOf(this.buffer,start,len);
        case 2:
            if(this.scheme >= 0) len += this.schemeLen + 1;
            if(this.authority >= 0) len += this.authorityLen + 2;
            len += this.pathLen;
            if(this.query >= 0) len += this.queryLen + 1;
            if(this.fragment >= 0) len += this.fragmentLen + 1;
            return String.valueOf(this.buffer,0,len);
        }
        return "";
    }

    /**
     * Return the device.
     */

    public String getDevice(){
        if (this.device >= 0){
            if (this.deviceLen == 0){
                return "";
            }
            return String.valueOf(this.buffer,this.device,this.deviceLen);
        }
        return null;
    }

    /**
     * Return the directory.
     */

    public String getDirectory(){
        if (this.directory >= 0){
            if (this.directoryLen == 0){
                return "";
            }
            return String.valueOf(this.buffer,this.directory,
               this.directoryLen);
        }
        return null;
    }

    /**
     * Return the filename.
     */

    public String getFilename(){
        if (this.filename >= 0){
            if (this.filenameLen == 0){
                return "";
            }
            return String.valueOf(this.buffer,this.filename,this.filenameLen);
        }
        return null;
    }

    /**
     * Return the filetype.
     */

    public String getFiletype(){
        if (this.filetypeLen == 1){
            return String.valueOf('.');
        } else if (this.filetype >= 0){
            if (this.filetypeLen == 0){
                return "";
            }
            return String.valueOf(this.buffer,this.filetype,this.filetypeLen);
        }
        return null;
    }

    /**
     * Return the version.
     */

    public String getVersion(){
        if (this.version >= 0){
            if (this.versionLen == 0){
                return "";
            }
            return String.valueOf(this.buffer,this.version,this.versionLen);
        }
        return null;
    }

    /**
     * Return the container directory.
     */

    public String getContainer(){
        if (this.status != 1) return null;
        int start = 0;
        int len = 0;
        if (this.deviceLen > 0){
            start = this.device;
            len = start + this.deviceLen + 1;
        }
        if (this.directoryLen > 0){
            start = this.directory;
            len = start + this.directoryLen;
        }
        if (len > 0){
            return String.valueOf(this.buffer,start,len);
        }
        return null;
    }

    /**
     * Return the scheme.
     */

    public String getScheme(){
        if (this.scheme >= 0){
            if (this.schemeLen == 0){
                return "";
            }
            return String.valueOf(this.buffer,this.scheme,this.schemeLen);
        }
        return null;
    }

    /**
     * Return the authority.
     */

    public String getAuthority(){
        if (this.authority >= 0){
            if (this.authorityLen == 0){
                return "";
            }
            return String.valueOf(this.buffer,this.authority,
                this.authorityLen);
        }
        return null;
    }

    /**
     * Return the path.
     */

    public String getPath(){
        if (this.path >= 0){
            if (this.pathLen == 0){
                return "";
            }
            return String.valueOf(this.buffer,this.path,this.pathLen);
        }
        return null;
    }

    /**
     * Return the query.
     */

    public String getQuery(){
        if (this.query >= 0){
            if (this.queryLen == 0){
                return "";
            }
            return String.valueOf(this.buffer,this.query,this.queryLen);
        }
        return null;
    }

    /**
     * Return the fragment.
     */

    public String getFragment(){
        if (this.fragment >= 0){
            if (this.fragmentLen == 0){
                return "";
            }
            return String.valueOf(this.buffer,this.fragment,this.fragmentLen);
        }
        return null;
    }

    /**
     * Determine if the object contains a file.
     */

    public boolean isFile(){
        return this.status == 1;
    }

    /**
     * Determine if the object contains a URI.
     */

    public boolean isURI(){
        return this.status == 2;
    }

    /** The standard input file spec. */
    public static String STDIN   = "/dev/stdin";

    /** The standard output file spec. */
    public static String STDOUT  = "/dev/stdout";

    /** The standard error file spec. */
    public static String STDERR  = "/dev/stderr";

    /** The standard console device spec. */
    public static String STDTTY  = "/dev/tty";

    /** The standard null file spec. */
    public static String STDNULL = "/dev/null";

    /** The specs of the standard files. */
    private static String[] STD_NAMES = new String[] {
        STDIN,STDOUT,STDERR,STDTTY,STDNULL};

    /** The specs of the standard files for Win. */
    private static String[] WIN_STD_NAMES = new String[] {
        "con","con","con","con","nul"};

    /** The specs of the standard for VMS. */
    private static String[] VMS_STD_NAMES = new String[] {
        "sys$input","sys$output","sys$error","tt","nl"};

    /**
     * Tell if this filespec denotes the standard file passed as argument.
     *
     * @param      str string of the standard file
     * @return     true if it denotes it
     */

    public boolean isStandard(String std){
        for (int i = 0; i < STD_NAMES.length; i++){
            if (std == STD_NAMES[i]){
                return ((1<<i) & this.std) != 0;
            }
        }
        return false;
    }

    /**
     * Tell if this filespec denotes a standard file.
     *
     * @return     true if it denotes it
     */

    public boolean isStandard(){
        return this.std != 0;
    }

    /**
     * Determine which standard files are denoted by this filespec.
     *
     * @param      os kind of operating system
     */

    private void setStdFile(int os){
        if ((FL_B & this.trc) != 0){
            Trc.out.println("setStdFile " + os);
            trace();
        }
        this.std = 0;
        switch (os){
        case Prg.UNIX:
            int ln = 0;
            if (this.device >= 0){
                ln += this.deviceLen;
                if (!this.unixDev) ln++;
            }
            ln += this.pathLen;
            if ((ln == 1) && (this.buffer[0] == '-')){
                this.std |= 1;
                break;
            }
            if (!this.unixDev) break;
            for (int i = 0; i < STD_NAMES.length; i++){
                String std = STD_NAMES[i];
                int len = std.length();
                if (Str.compareSlices(this.buffer,this.buffer.length,
                    this.device,this.deviceLen,
                    std,len,0,len,false,false) == 0){
                    this.std |= 1<<i;
                    continue;
                }
            }
        case Prg.WIN:
            if ((this.deviceLen <= 0) &&
                (this.filenameLen <= 0)) break;
            for (int i = 0; i < WIN_STD_NAMES.length; i++){
                String std = WIN_STD_NAMES[i];
                int len = std.length();
                if (this.filenameLen > 0){
                    if (Str.compareSlices(this.buffer,this.buffer.length,
                        this.filename,this.filenameLen,std,len,0,len,
                        true,false) == 0){
                        this.std |= 1<<i;
                        continue;
                    }
                } else if (this.deviceLen > 0){
                    if (Str.compareSlices(this.buffer,this.buffer.length,
                        this.device,this.deviceLen,std,len,0,len,
                        true,false) == 0){
                        this.std |= 1<<i;
                        continue;
                    }
                }
            }
            if ((this.std != 0) && (this.deviceLen == 0)){
                this.device = this.filename;
                this.deviceLen = this.filenameLen;
                this.directory = -1;
                this.directoryLen = 0;
                this.filename = 0;
                this.filenameLen = 0;
                this.version = -1;
                this.versionLen = 0;
                this.unixDev = true;
                this.path = -1;
                this.pathLen = 0;
            }
            break;
        case Prg.VMS:
            if (this.deviceLen <= 0) break;
            for (int i = 0; i < VMS_STD_NAMES.length; i++){
                String std = VMS_STD_NAMES[i];
                int len = std.length();
                if (Str.compareSlices(this.buffer,this.buffer.length,
                    this.device,this.deviceLen,std,len,0,len,
                    true,false) == 0){
                    this.std |= 1<<i;
                    continue;
                }
            }
            break;
        default:
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("setStdFile: " + this.std);
        }
    }

    /**
     * Parse a filestring into its components according to the syntax of
     * the current operating system.
     *
     * @param      str string of the FileSpec
     * @param      os kind of operating system
     */

    public void parseFile(String str){
        parseFile(str,Prg.os);
    }

    /**
     * Parse a filestring into its components.
     *
     * @param      str string of the FileSpec
     * @param      os kind of operating system
     */

    public void parseFile(String str, int os){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("parseFile " + str + " " + os);
        }
        int std = 0;
        for (int i = 0; i < STD_NAMES.length; i++){
            if (str == STD_NAMES[i]){
                std |= 1<<i;
                switch (os){
                case Prg.WIN:
                    str = "\\\\.\\" +
                        WIN_STD_NAMES[i]; break;   // Dos, Windows, NT
                case Prg.VMS:
                    str = VMS_STD_NAMES[i]; break; // Vms
                default: break;                    // Unix
                }
            }
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("parseFile " + str + " " + os);
        }
        int max = str.length();
        if ((this.buffer == null) ||               // reuse buffer
            (this.buffer.length < max)){
            this.buffer = str.toCharArray();
        } else {                                   // allocate a new one
            str.getChars(0,max,this.buffer,0);
        }
        parseFile(max,os);                         // n.b. clears this.std
        if (std == 0) setStdFile(os);
        else this.std = std;
        if ((FL_B & this.trc) != 0){
            Trc.out.println("parseFile " +
                Integer.toOctalString(this.std));
        }
    }

    /**
     * Parse the string contained in this object into its components.
     *
     * @param      max length of the string
     * @param      os kind of operating system
     */

    private void parseFile(int max, int os){
        if ((FL_B & this.trc) != 0){
            Trc.out.println("parsefile: " + max + " " + os);
        }
        this.os = os;
        char ddel;
        switch (os){
        case Prg.WIN: ddel = '\\'; break;          // Dos, Windows, NT
        case Prg.VMS: ddel = '[';  break;          // Vms
        default:      ddel = '/';  break;          // Unix
        }
        char[] u = this.buffer;
        init();
        this.status = 1;

        int i = 0;
        int s = 0;
        dev: for (; i < max; i++){                 // recognize device
            char ch = u[i];
            if ((ch == ':') || (ch == ddel) || (ch == '.')){
                break dev;
            }
        }
        if ((i - s >= 1) && (i < max) &&           // previous token present
            (u[i] == ':')){
            this.device = s;
            this.deviceLen = i - s;
            i++;
        } else {
            i = s;                                 // go back
        }
        s = i;                                     // recognise directory
        this.path = s;
        this.pathLen = max - s;
        doit: if (os == Prg.VMS){
            dir: if ((i < max) && (u[i] == '[')){
                s = ++i;
                for (; i < max; i++){
                    switch (u[i]){
                    case ']':
                        this.directory = s-1;
                        this.directoryLen = i-s+2;
                        i++;
                        break dir;
                    }
                }
                i = s;                             // go back
            }
            s = i;                                 // recognise name
            nam: for (; i < max; i++){
                switch (u[i]){
                case '.': case ';': break nam;
                }
            }
            this.filename = s;
            this.filenameLen = i - s;
            if ((i < max) && (u[i] == '.')){       // recognise filetype
                s = ++i;
                fty: for (; i < max; i++){
                    switch (u[i]){
                    case ';': break fty;
                    }
                }
                this.filetype = s-1;
                this.filetypeLen = i-s+1;
                s = i;
            }
            if ((i < max) && (u[i] == ';')){       // recognise version
                s = ++i;
                this.version = s;
                this.versionLen = max-s;
            }
        } else {
            parse_path(s,max,u,ddel);              // parse standard path
        }
        if ((os == Prg.UNIX) && (max >= 6) && (this.deviceLen <= 0)){
            unixDevice(u,max);
        }
        if ((FL_B & this.trc) != 0){
            trace();
            Trc.out.println("parsefile: " + toString());
        }
    }

    /**
     * Test whether the filespec is a unix device, and if it is set
     * the fields to denote it.
     *
     * @param      u string of the filespec
     * @param      max end index in the filespec
     */

    private void unixDevice(char[] u, int max){
        if ((u[0] == '/') && (u[1] == 'd') &&
            (u[2] == 'e') && (u[3] == 'v') && (u[4] == '/')){
            int status = this.status;
            init();
            this.status = status;
            this.device = 0;
            this.deviceLen = max;
            this.unixDev = true;
            this.filename = 0;
            this.filenameLen = 0;
        }
    }

    /**
     * Parse the path part in a string and set the indexes in it.
     *
     * @param      s start index from which the parsing begins
     * @param      max end index at which the parsing ends
     * @param      u string
     * @param      ddel directory end delimiter
     */

    private void parse_path(int s, int max, char[] u, char ddel){
        int i;
        for (i = max-1; i >= s; i--){
            if (u[i] == ddel) break;
        }
        if ((max - i == 2) && (u[i+1] == '.')){
            this.directory = s;
            this.directoryLen = i + 1 - s;
            this.filename = i + 1;
            this.filenameLen = 1;                  // current directory
            return;
        } else if ((max - i == 3) &&
            (u[i+1] == '.') && (u[i+2] == '.')){
            this.directory = s;
            this.directoryLen = i + 1 - s;
            this.filename = i + 1;
            this.filenameLen = 2;                  // current directory
            return;
        } else if (i >= s){
            i++;
            this.directory = s;
            this.directoryLen = i - s;
        }
        s = (i >= s) ? i : s;                      // possible start of name
        for (i = max-1; i >= s; i--){
            if (u[i] == '.') break;
        }
        fty: {
            nofty: if (i >= s){
                this.filetype = i;
                this.filetypeLen = max - i;
                break fty;
            }
            i = max;
        }
        this.filename = s;
        this.filenameLen = i - s;
        if (this.status != 2){             // not a URI
            checkDirectory(max,u);
        }
    }

    /**
     * Determine if the current filespec denotes a directory in the
     * filesystem, and if it is, it moves it in the directory field.
     *
     * @param      max end index in the filespec
     * @param      u string
     */

    private void checkDirectory(int max, char[] u){
        if (max == 0) return;
        char ddel;
        switch (this.os){
        case Prg.WIN: ddel = '\\'; break;            // Dos, Windows, NT
        default:      ddel = '/';  break;            // Unix
        }
        if (((this.filenameLen > 0) ||
            (this.filetypeLen > 0)) &&               // a file present, that ..
            (u[max-1] != ddel)){                     // .. does not end with a dir delim
            File f = new File(String.valueOf(u,0,max));
            if (f.isDirectory()){                    // it is a directory
                if ((FL_A & this.trc) != 0){
                    trace();
                }
                if (this.buffer.length < max + 1){
                    char[] old = this.buffer;
                    this.buffer = new char[max+1];   // enlarge
                    System.arraycopy(old,0,this.buffer,0,max);
                }
                this.buffer[max] = ddel;             // add the missing delim
                max++;
                if (this.directoryLen == 0){         // no other level
                    this.directory = this.filename;
                }
                this.directoryLen = max - this.directory;
                this.filenameLen = 0;
                this.filename = max;
                this.filetype = -1;
                this.filetypeLen = -1;
                if ((FL_A & this.trc) != 0){
                    Trc.out.println("directory " + toString());
                    trace();
                }
            }
        }
    }

    /**
     * Store in this object the FileSpec resulting from a base one and
     * from a relative filestring passed as argument according to the
     * syntax of the current operating system.
     *
     * @param      base base FileSpec
     * @param      s string of the relative or absolute filestring
     */

    public void resolveFile(FileSpec base, String s){
        resolveFile(base,s,Prg.os);
    }

    /**
     * Stores in this object the FileSpec resulting from a base one and
     * from a relative filestring passed as argument.
     * The device and directory are propagated. The filespec is propagated
     * if enabled.
     *
     * @param      base base FileSpec
     * @param      s string of the relative or absolute filestring
     * @param      os kind of OS for the filename syntax
     */

    public void resolveFile(FileSpec base, String s, int os){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("resolveFile " + s + " " + base);
            if (base != null) base.trace();
        }
        int cur = 0;
        int ftylen = 0;
        if (this.fty != null){
            if ((base != null) &&
                (base.filetype >= 0)){          // present in base
                ftylen = base.filetypeLen;
            } else {
                ftylen = this.fty.length();
            }
        }
        if ((base != null) && (base == this)){
            try {
                base = (FileSpec)clone();
                if (base.buffer != null)
                    base.buffer = (char[])(base.buffer.clone());
            } catch (CloneNotSupportedException e){
            }
        }
        parseFile(s,os);
        if (os == Prg.VMS){
            reducePath(os);                     // merge [dir.][subdir]
        }
        if (this.std == 0){                     // not a standard file
            if ((base != null) && (base.std != 0)){ // standard file
                if (base != this){
                    init();
                    this.status = base.status;
                    this.std = base.std;
                    this.os = base.os;
                    this.device = base.device;
                    this.deviceLen = base.deviceLen;
                    this.unixDev = base.unixDev;
                    this.buffer = (char[])(base.buffer.clone());
                    this.filename = 0;
                    this.filenameLen = 0;
                }
            }
        }
        if ((os == Prg.UNIX) && (this.unixDev)){
            if (this.deviceLen > 0){            // device specified
                this.directory = -1;
                this.directoryLen = 0;
                this.filename = 0;
                this.filenameLen = 0;
                this.filetype = -1;
                this.filetypeLen = 0;
                this.version = -1;
                this.versionLen = 0;
                this.path = -1;
                this.pathLen = 0;
            }
        }
        if (this.std != 0){                     // standard file
            if ((FL_A & this.trc) != 0){
                Trc.out.println("resolveFile standard " + toString());
                trace();
            }
            return;
        }

        if (this.filetype >= 0){                // filetype specified
            ftylen = this.filetypeLen;
        }
        if (base == null){
            if (this.fty == null) return;       // no propagation
            if (this.filetype >= 0){            // present
                if (this.filetypeLen == 1){     // . alone, remove it
                    System.arraycopy(this.buffer,
                        this.filetype,this.buffer,
                        this.filetype+1,
                        this.versionLen);
                    this.pathLen--;
                    this.version--;
                }
                if ((FL_A & this.trc) != 0){
                    Trc.out.println("resolveFile return " + toString());
                    trace();
                }
                return;                         // N.B. filetype unchanged
            }

            // the filespec has no filetype, and one must be
            // placed between the name and the version

            char[] old = this.buffer;
            int l1 = this.pathLen + this.path;  // up to the end of path
            int l2 = this.versionLen;
            l1 -= l2;
            if (this.buffer.length < l1 + l2 + ftylen){
                this.buffer = new char[l1+l2+ftylen];     // enlarge
            }
            System.arraycopy(old,0,this.buffer,0,l1);
            cur += l1;
            this.filetypeLen = ftylen;          // N.B. the original one
            this.filetype = cur;
            this.pathLen += ftylen;             // move first the tail
            if (this.version >= 0) this.version += ftylen;
            System.arraycopy(old,l1,this.buffer,cur+ftylen,l2);
            this.fty.getChars(0,ftylen,this.buffer,cur);
            if ((FL_A & this.trc) != 0){
                Trc.out.println("resolveFile return " + toString());
                trace();
            }
            if (os != Prg.VMS){
                checkDirectory(l1+l2+ftylen,this.buffer);
            }
            return;
        }
        char[] old = this.buffer;
        int len = 0;
        if (this.device < 0){
            if (base.device >= 0){
                len += base.deviceLen;
                if (!base.unixDev) len++;
            }
        } else {
            len += this.deviceLen;
            if (!this.unixDev) len++;
        }
        boolean absolute = false;
        boolean current = false;
        if (this.directory < 0){
            if (base.directory >= 0){
                len += base.directoryLen;
            }
        } else {                                // determine if absolute
            switch (os){
            case Prg.WIN:                       // Dos, Windows, NT
                absolute = this.buffer[this.directory] == '\\';
                if ((this.directoryLen <= 3) &&
                    (this.buffer[this.directory] == '.')){
                    if ((this.directoryLen == 2) ||
                        (this.buffer[this.directory+1] == '.')){
                        current = true;
                    }
                }
                break;
            case Prg.VMS:                       // Vms
                absolute = this.buffer[this.directory+1] == '.';
                if ((this.directoryLen == 2) &&
                    (this.buffer[this.directory] == '[') &&
                    (this.buffer[this.directory+1] == ']')){
                    current = true;
                }
                break;
            default:                            // Unix
                absolute = this.buffer[this.directory] == '/';
                if ((this.directoryLen <= 3) &&
                    (this.buffer[this.directory] == '.')){
                    if ((this.directoryLen == 2) ||
                        (this.buffer[this.directory+1] == '.')){
                        current = true;
                    }
                }
                break;
            }
            if (!absolute && ! current){
                len += base.directoryLen;
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("resolveFile abs/cur " +
                    absolute + " " + current);
            }
            len += this.directoryLen;
        }
        if (this.filenameLen == 0){
            if (base.filename >= 0) len += base.filenameLen;
        } else {
            len += this.filenameLen;
        }
        len += ftylen;
        if (this.version >= 0){
            len += this.versionLen;
        }
        this.buffer = new char[len];

        if ((FL_B & this.trc) != 0){
            Trc.out.println("resolveFile copy");
            if (base != null) base.trace();
            trace();
        }
        if (this.device < 0){                   // device not specified
            if (base.device >= 0){              // .. take from base
                this.deviceLen = base.deviceLen;
                int ldev = base.deviceLen;
                if (!base.unixDev) ldev++;
                System.arraycopy(base.buffer,base.device,
                    this.buffer,cur,ldev);
                this.device = cur;
                cur += ldev;
            }
        } else {
            int ldev = this.deviceLen;
            if (!this.unixDev) ldev++;
            System.arraycopy(old,this.device,
                this.buffer,cur,ldev);
            this.device = cur;
            cur += ldev;
        }
        this.path = cur;
        if (this.directory < 0){                // directory not specified
            if (base.directory >= 0){           // .. take from base
                this.directoryLen = base.directoryLen;
                System.arraycopy(base.buffer,base.directory,
                    this.buffer,cur,base.directoryLen);
                this.directory = cur;
                cur += base.directoryLen;
            }
        } else {
            int dir = cur;
            if (!absolute && (base.directory >= 0) &&
                !current){                                   // use base to
                System.arraycopy(base.buffer,base.directory, // resolve
                    this.buffer,cur,base.directoryLen);
                cur += base.directoryLen;
            }
            System.arraycopy(old,this.directory,
                this.buffer,cur,this.directoryLen);
            this.directory = dir;
            cur += this.directoryLen;
        }
        if (this.filenameLen == 0){             // filename not specified
            if (base.filename >= 0){            // .. take from base
                this.filenameLen = base.filenameLen;
                System.arraycopy(base.buffer,base.filename,
                    this.buffer,cur,base.filenameLen);
                this.filename = cur;
                cur += base.filenameLen;
            }
        } else {
            System.arraycopy(old,this.filename,
                this.buffer,cur,this.filenameLen);
            this.filename = cur;
            cur += this.filenameLen;
        }
        if (this.filetype >= 0){
            System.arraycopy(old,this.filetype,        // copy filename and
                this.buffer,cur,this.filetypeLen);     // .. filetype
            cur += this.filetypeLen;
        }
        this.pathLen = cur - this.path;
        if (this.filetype >= 0){                       // transpose filetype
            this.filetype = this.path + this.pathLen -
                this.filetypeLen;
        }
        if (this.directory >= 0){
            this.directoryLen = this.filename - this.path;
        }
        if (!this.unixDev){
            cur = fty_propagate(ftylen,cur,base,       // propagate filetype
                this.buffer);
        }
        if (this.version >= 0){
            System.arraycopy(old,this.version,       // copy version
                this.buffer,cur,this.versionLen);
            this.version = cur;
            cur += this.versionLen;
        }
        if (os == Prg.VMS){
            reducePath(os);                          // merge [dir.][subdir]
        }
        if ((os == Prg.UNIX) && (cur >= 6) && (this.deviceLen <= 0)){
            unixDevice(this.buffer,cur);
        }
        standard: {
            setStdFile(os);
        }
        if (os != Prg.VMS){
            checkDirectory(cur,this.buffer);         // check if directory
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("resolveFile " +
                Integer.toOctalString(this.std) + " " +  toString());
            trace();
        }
    }

    /**
     * Propagate the filetype.
     *
     * @param      ftylen length of the filetype
     * @param      cur current index into the FileSpec buffer
     * @param      base base FileSpec
     * @param      buf buffer in which the filetype in inserted
     */

    private int fty_propagate(int ftylen, int cur, FileSpec base,
        char[] buf){
        if (this.fty != null){                      // filetype propagation on
            if (this.filetype >= 0){                // present
                if (this.filetypeLen == 1){         // . alone, remove it
                    ftylen = -1;
                } else {
                    ftylen = 0;
                }
            } else {
                this.filetypeLen = ftylen;
                this.filetype = cur;
                if ((base == null) || (base.filetype < 0)){
                    this.fty.getChars(0,ftylen,buf,cur);
                } else if (ftylen > 1){
                    System.arraycopy(base.buffer,base.filetype,
                        buf,cur,ftylen);
                } else {
                    ftylen = 0;
                }
            }
            cur += ftylen;
            this.pathLen += ftylen;
        }
        return cur;
    }


    /**
     * Parse a URI into these components.
     *
     * @param      str string of the URI
     */

    public void parseURI(String str){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("parseURI " + str);
        }
        int max = str.length();
        if ((this.buffer == null) ||               // not present or short
            (this.buffer.length < max)){
            this.buffer = str.toCharArray();
        } else {
            str.getChars(0,max,this.buffer,0);
        }
        char[] u = this.buffer;
        init();
        this.status = 2;

        int i = 0;
        int s = 0;
        sch: for (; i < max; i++){                 // recognize scheme
            switch(u[i]){
            case ':': case '/': case '?': case '#':
                break sch;
            }
        }
        if ((i - s >= 1) && (i < max) &&           // previous token present
            (u[i] == ':')){
            this.scheme = s;
            this.schemeLen = i - s;
            i++;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("scheme " +
                    String.valueOf(u,this.scheme,this.schemeLen));
            }
            if ((this.schemeLen == 3) &&           // jar:
                ((u[i-4] == 'j') || (u[i-4] == 'J')) &&
                ((u[i-3] == 'a') || (u[i-3] == 'A')) &&
                ((u[i-2] == 'r') || (u[i-2] == 'R'))){
                s = i;
                ssch: for (; i < max; i++){        // recognize second scheme
                    switch(u[i]){
                    case ':': case '/': case '?': case '#':
                        break ssch;
                    }
                }
                if ((i - s >= 1) && (i < max) &&   // previous token present
                    (u[i] == ':')){
                    this.schemeLen += i - s + 1;
                    i++;
                }
            }
        } else {
            i = s;                                 // go back
        }
        if ((i < max) && (u[i] == '/') &&          // recognise authority
           (i+1 < max) && (u[i+1] == '/')){
            i += 2;
            s = i;
            auth: for (; i < max; i++){
                switch (u[i]){
                case '/': case '?': case '#': break auth;
                }
            }
            this.authority = s;
            this.authorityLen = i - s;
        }
        s = i;                                     // recognise path
        pat: for (; i < max; i++){
            switch (u[i]){
            case '?': case '#': break pat;
            }
        }
        this.path = s;
        this.pathLen = i - s;
        if ((i < max) && (u[i] == '?')){           // recognise query
            s = ++i;
            que: for (; i < max; i++){
                switch (u[i]){
                case '#': break que;
                }
            }
            this.query = s;
            this.queryLen = i - s;
        }
        if ((i < max) && (u[i] == '#')){           // recognise fragment
            s = ++i;
            this.fragment = s;
            this.fragmentLen = max - s;
        }

        if (this.path < 0) return;
        s = this.path;                             // recognize filetype
        max = s + this.pathLen;
        parse_path(s,max,u,'/');                   // parse now path
        if ((FL_B & this.trc) != 0){
            trace();
        }
    }

    /**
     * Store in this object the URI resulting from a base one and
     * from a relative one passed as argument.
     *
     * @param      base base URI
     * @param      s string of the relative URI
     */

    /* The merging of a base parent path and a relative one is done
     * as follows:
     *
     * 1. the base (n.b. only the directory) concatenated with the
     *    relative path are taken,
     * 2. all ./ are removed
     * 3. a final . is removed
     * 4. all segment/../ where segment is not .. are removed
     * 5. a final segment/.. where segment is not .. is removed
     */

    public void resolveURI(FileSpec base, String s){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("resolveURI " + s + " " + base);
        }
        int cur = 0;
        int ftylen = 0;
        if (this.fty != null){
            if ((base != null) &&
                (base.filetype >= 0)){          // present in base
                ftylen = base.filetypeLen;
            } else {
                ftylen = this.fty.length();
            }
        }
        if ((base != null) && (base == this)){
            try {
                base = (FileSpec)clone();
                if (base.buffer != null)
                    base.buffer = (char[])(base.buffer.clone());
            } catch (CloneNotSupportedException e){
            }
        }
        parseURI(s);
        if (this.filetype >= 0)                 // filetype specified
            ftylen = this.filetypeLen;
        boolean jar = false;
        if (base != null){
            char[] u = base.buffer;
            int i = base.scheme;
            jar = ((base.schemeLen >= 3) &&     // jar:
                ((u[i] == 'j') || (u[i] == 'J')) &&
                ((u[i+1] == 'a') || (u[i+1] == 'A')) &&
                ((u[i+2] == 'r') || (u[i+2] == 'R')));
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("jar: " + jar);
        }
        boolean curautho = false;
        if ((base == null) ||                   // base not present
            (base.scheme < 0) ||                // base itself relative
            (this.scheme >= 0)){                // absolute
            if ((FL_B & this.trc) != 0){
                Trc.out.println("base weak");
            }
            curautho = true;
        }
        boolean samedoc = false;
        if ((this.scheme < 0) &&                // same document: take
            (this.authority < 0) &&             // .. scheme up to query
            (this.pathLen == 0) &&              // .. from base
            (this.query < 0)){
            if ((FL_B & this.trc) != 0){
                Trc.out.println("same document");
            }
            samedoc = true;
        }

        int len = 0;
        FileSpec fs = null;
        if (this.scheme >= 0){                  // scheme present
            fs = this;
        } else if ((base != null) &&            // take that of scheme
            (base.scheme >= 0)){
            fs = base;
        }
        if (fs != null) len += fs.schemeLen + 1;
        boolean basepath = false;
        FileSpec fa = null;
        if (this.authority >= 0) {              // authority specified
            fa = this;
        } else if (!curautho){                  // take authority from base
            if (base != null){
                if (base.authority >= 0){
                    fa = base;
                }
                if ((this.pathLen == 0) ||      // relative path not specified
                    (this.buffer[this.path]     // .. or not absolute: merge
                    != '/')){
                    basepath = true;
                } else if (jar){                // take always ... ! part
                    basepath = true;
                }
            }
        }
        if (fa != null) len += fa.authorityLen + 2;
        int lb = 0;
        if ((base == null) || (base.directory < 0)
            || !basepath){                      // no base parent path
            len += this.pathLen;                // .. take only relative
        } else {                                // take base parent path
            if (samedoc){                       // .. and also relative
                lb = base.pathLen;
            } else {
                if (!jar){
                    lb = base.directoryLen;
                } else {                        // determine ...!/ length
                    int b = base.directory;
                    int max = b + base.directoryLen;
                    int j = 0;
                    for (j = max-1; j >= b; j--){
                        if (base.buffer[j] == '!') break;
                    }
                    if (j >= b){
                        lb = j + 2 - b;
                    } else {
                        lb = base.directoryLen;
                    }
                    if (base.buffer[base.path+base.pathLen-1] == '/'){
                        lb = base.pathLen;      // base ending with /, take all
                    }
                }
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("lb: " + lb);
            }
            len += lb;
            len += this.pathLen;
        }
        len += ftylen;
        FileSpec fq = null;
        if ((samedoc) && (base != null) && (base.query >= 0)){
            fq = base;
        } else if (this.query >= 0){            // take query
            fq = this;
        }
        if (fq != null) len += fq.queryLen + 1;

        if (this.fragment >= 0){                // take fragment
            len += this.fragmentLen + 1;
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("len: " + len);
        }

        char[] res = new char[len];

        if (fs != null){                        // copy scheme
            System.arraycopy(fs.buffer,fs.scheme,
               res,cur,fs.schemeLen+1);
            this.scheme = cur;
            this.schemeLen = fs.schemeLen;
            cur += this.schemeLen + 1;
        }

        if (fa != null){                        // copy authority
            System.arraycopy(fa.buffer,fa.authority-2,
                res,cur,fa.authorityLen+2);
            this.authority = cur + 2;
            this.authorityLen = fa.authorityLen;
            cur += this.authorityLen + 2;
        }

        int lt;
        char[] buf = res;                           // merge with base parent path
        if ((base == null) || (base.directory < 0)
            || !basepath){                          // no base parent path
            System.arraycopy(this.buffer,this.path, // .. take only relative
                buf,cur,this.pathLen);
            lt = cur + this.pathLen;
        } else {                                    // take base parent + relative
            lb += base.directory;                   // .. and also relative
            System.arraycopy(base.buffer,base.path,
                buf,cur,lb - base.path);
            System.arraycopy(this.buffer,this.path,
                buf,(cur + lb) - base.path,this.pathLen);
            lt = ((cur + lb) - base.path) + this.pathLen;
        }

        int dst = cur;                       // now reduce
        int src = cur;
        int ini = cur;
        pack: while(src < lt){
            int start = src;
            for(; src < lt; src++){          // locate segment
                if (buf[src] == '/') break;
            }
            if ((src - start == 0) &&        // two /
                (dst > ini)){                // discard one
                src++;
                continue;
            }
            if ((src - start == 1) &&        // ./ or .[end]
                (buf[start] == '.')){        // discard
                if (src < lt) src++;
                continue;
            }
            if ((src - start == 2) &&        // ..
                (buf[start] == '.') &&
                (buf[start + 1] == '.') &&
                (dst > ini) &&               // not at beginning
                (dst >= cur + 2) &&          // segment present
                (buf[dst - 1] == '/')){      // .. preceded by /
                int j;
                for (j = dst - 2; j >= cur; j--){
                    if (buf[j] == '/'){
                        j++;                 // locate start of segment
                        break;
                    }
                }
                if (j < cur) j++;
                if ((dst - j >= 1) &&        // segment/..
                    ((dst - j != 3) ||       // segment is not ..
                    (buf[j] != '.') ||
                    (buf[j+1] != '.'))){
                    dst = j;                 // discard segment/..
                    src++;
                    continue;
                }
            }
            if (src < lt) src++;             // skip /
            System.arraycopy(buf,start,      // copy segment/
                buf,dst,src-start);
            dst += src - start;
        }
        this.path = cur;                     // bind indexes
        this.pathLen = dst - cur;
        cur = dst;
        if ((FL_B & this.trc) != 0){
            Trc.out.println("merged " + String.valueOf(res,0,cur) +
               " " + cur + " " + this.path + " " + this.pathLen);
        }

        /* Because a reduction might have removed the last . or ..,
         * there is a need to keep into account that the filename could
         * have disappeared. Moreover, the directory might have been
         * completely changed.
         * To update the indexes in a simple way, the path is rescanned.
         */

        this.directory = -1;
        this.directoryLen = 0;
        this.filename = -1;
        this.filenameLen = 0;
        this.filetype = -1;
        this.filetypeLen = 0;
        parse_path(this.path,this.path+this.pathLen,
            res,'/');                         // parse now path
        if ((FL_B & this.trc) != 0){
            trace();
            Trc.out.println("cur: " + cur);
        }
        cur = fty_propagate(ftylen,cur,base,res);    // propagate filetype
        if ((FL_B & this.trc) != 0){
            Trc.out.println("completed ");
            trace();
        }
        if (fq != null){                             // copy query
            System.arraycopy(fq.buffer,fq.query-1,
                res,cur,fq.queryLen+1);
            this.query = cur;
            this.queryLen = fq.queryLen;
            cur += this.queryLen + 1;
        }

        if (this.fragment >= 0){                     // take fragment
            System.arraycopy(this.buffer,this.fragment-1,
                res,cur,this.fragmentLen+1);
            this.fragment = cur;
            cur += this.fragmentLen + 1;
        }
        this.buffer = res;
    }


    /**
     * Deliver the resultant filespec.
     *
     * @see        #resultant(String,int)
     */

    public void resultant(String s) throws IOException {
        resultant(s,Prg.os);
    }

    /**
     * Deliver the resultant filespec. It takes this object as a base
     * FileSpec and updates it with the FileSpec resulting from it and
     * from a (possibly relative) filespec passed as argument, which
     * can be either a filestring or a URI, and can contain also a logical
     * name. Logical names translation is performed before deriving the
     * filespec, and thus a logical name which has the same name as a
     * protocol or a device hides the latter. They can contain any part up
     * to the directory a filespec.
     * URI included.
     *
     * @param      s string of the relative or absolute FileSpec
     * @param      os kind of OS for the filename syntax
     * @exception  IOException, see <code>{@link #getEnvironment()}</code>
     *             and <code>{@link #translateLogical(String,int)}</code>.
     */

    public void resultant(String s, int os) throws IOException {
        if ((FL_A & this.trc) != 0){
            Trc.out.println("resultant " + this);
        }
        s = replaceLogical(s,os);                 // replace a logical, if any
        String fn = s;
        int start, end;
        int explicit = 0;

        start = 0;
        end = s.indexOf(':',start);
        scheme: if (end >= 0){
            if (end == s.length() - 1)            // dev:
                break scheme;
            int end1 = s.indexOf('/',start);
            int end2 = s.indexOf('\\',start);
            if ((end2 >= 0) && (end2 < end1))
                end1 = end2;
            if ((end1 >= 0) &&                    // ddd/dd
                (end1 < end)) break scheme;       // ddd/dd:
            if (end-start <= 1){                  // d:
                explicit = 1;
                break scheme;
            } else {
                String st = s.substring(start,end+1);     // protocol
                if (st.equalsIgnoreCase("file:")){        // file:
                    fn = s.substring(end+1);
                    explicit = 1;
                    break scheme;
                }
            }
            explicit = 2;
        }
        if (((explicit == 0) &&                   // not present
            ((this.status == 1) ||
            (this.status == 0)))                  // prev: file or none
            || (explicit == 1)){                  // file:
            if (this.status != 1){                // no previous file
                init();
            }
            resolveFile(this,fn,os);              // also the first time to
        } else {                                  // .. propagate filetype
            if (this.status != 2){                // no previous URI
                init();
            }
            resolveURI(this,fn);                  // as above
        }
    }


    /** The reference to the environment. */
    private static Properties environ;

    /**
     * Deliver a reference to the environment. It loads the
     * environment, if that has not yet been done. Then it parses
     * it according to its native syntax. Note that native notations
     * are not the one that Java requires for files holding properties
     * (e.g. in NT backslashes are present with a meaning which is
     * different).
     *
     * @return     reference to the environment
     * @exception  IOException if the reading of the environment
     *             has caused an io error. Its message is "E:n" when
     *             the return status of the exec which reads the environment
     *             is a value <code>n</code> which is not zero
     */

    public synchronized Properties getEnvironment()
        throws IOException {
        if (environ != null) return environ;
        String envcmd;
        switch (Prg.os){
        case Prg.WIN: envcmd = "cmd.exe /c set"; break; // Dos, Windows, NT
        case Prg.VMS: envcmd = "show log"; break;       // Vms
        default:      envcmd = "/bin/env"; break;       // Unix
        }
        if (Prg.host == Prg.LINUX) envcmd = "/usr/bin/env";
        Process p = Runtime.getRuntime().exec(envcmd);
        InputStreamReader isr;
        isr = new InputStreamReader(p.getInputStream());
        environ = new Properties();
        BufferedReader file = new BufferedReader(isr);
        do {
            String line = file.readLine();              // read line by
            if (line == null) break;                    // .. line and
            int eq = line.indexOf('=');                 // .. parse it
            if (eq < 0) continue;                       // not a name=value line
            String key;
            String value;
            if (Prg.os == Prg.VMS){
                int kini = line.indexOf('\"');
                int kend = line.indexOf('\"',kini);
                key = line.substring(kini+1,kend);
                int vini = line.indexOf('\"',eq);
                int vend = line.length();
                value = line.substring(vini+1,vend);
            } else {
                key = line.substring(0,eq);
                value = line.substring(eq+1,line.length());
            }
            environ.setProperty(key,value);
        } while (true);
        try {
            p.waitFor();
            int status = p.exitValue();
            if (status != 0){
                throw new IOException("E:" + Integer.toString(status));
            }
        } catch (InterruptedException e){
        }
        environ.setProperty("HOME",System.getProperty("user.home"));
        environ.setProperty("PWD",System.getProperty("user.dir"));
        String mc = Prg.getMainClass();
        if ((FL_B & this.trc) != 0){
            Trc.out.println("getenv: " + mc);
        }
        if (mc == null){
            throw new IOException("E:0");
        }
        int n = mc.lastIndexOf(".");
        if (n > 0) n = mc.length() - n - 1;            // length of name
        String run = ClassLoader.getSystemResource(
            mc.replace('.', '/') + ".class").toString();
        run = run.substring(0,run.length() - n - 6);   // parent URL
        environ.setProperty("LOAD",run);
        if ((FL_B & this.trc) != 0){
            Trc.out.println("getenv: " + run);
        }
        return environ;
    }

    /**
     * Deliver the translation of a logical name, repeating the process
     * until no logical name is present. When it joins a translation with
     * what has already been collected, it removes or adds a directory
     * separator so as to have ony one to separate the translation from
     * the remaining part. It detects circularity.
     * A logical name is made of letters, digits, "$", "." and "_" characters.
     * It is separated from the following by a ":".
     * If <code>log</code> contains solely a logical name, not followed by
     * ":", it replaces it, otherwise it replaces it and the ":" and it
     * appends the remaining part to the string returned. If there is no
     * environment variable with the name of a logical name, the translation
     * stops and the name it returned.
     *
     * @param      log string containing the logical name at the beginning
     * @param      os kind of OS for the filename syntax
     * @return     translated string
     * @exception  IOException if the reading of the environment
     *             has caused an io error. Its message is "C" if a circular
     *             definition has been found.
     */

    /* When there is no directory separator between the translation and
     * the remaining part, one is included. Since in NT a file may not
     * contain a "/", a test is made to check that "/" does not occur
     * at the end of the translation or at the beginning of the remaining
     * part in addition to testing the platform-dependent directory
     * separator.
     */

    public String translateLogical(String log, int os)
        throws IOException {
        if ((FL_B & this.trc) != 0){
            Trc.out.println("trans: " + log);
        }
        char ddel;
        switch (os){
        case Prg.WIN: ddel = '\\'; break;          // Dos, Windows, NT
        case Prg.VMS: ddel = '[';  break;          // Vms
        default:      ddel = '/';  break;          // Unix
        }
        Str trans = new Str(log);
        Properties env = null;
        List<String> visited = new LinkedList<String>();
        tra: do {
            int i = 0;
            for (i = 0; i < trans.length; i++){     // check if a logical
                char c = trans.buffer[i];           // .. name is present
                if (c == ':') break;
                if (c == '$') continue;
                if (c == '.') continue;
                if (c == '_') continue;
                if (Character.isLetterOrDigit(c)) continue;
                break tra;
            }
            if ((i == 0) || (i == trans.length)) break tra;
            int colon = i;

            log = trans.substring(0,colon).toString();
            if (visited.contains(log)){
                throw new IOException("C");
            }
            if (env == null) env = getEnvironment();   // get only when needed
            String t = env.getProperty(log);
            if (t == null) break;
            visited.add(log);                       // add to the list of
            int tlen = t.length();                  // .. visited names
            boolean del = false;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("trans: " + t + " "
                    + trans.toString() + " " + colon);
            }
            colon++;
            if ((tlen > 0) &&                       // no directory sep.
                (t.charAt(tlen-1) != '/') &&        // .. nor / of URI
                (t.charAt(tlen-1) != ddel)){        // .. add it
                if ((colon >= trans.length) ||
                    ((trans.buffer[colon] != '/') &&
                    (trans.buffer[colon] != ddel))){
                    colon--;
                    del = true;
                }
            } else if ((tlen > 0) &&                // two directory sep
                ((t.charAt(tlen-1) == '/') ||       // .. or / of URI
                (t.charAt(tlen-1) == ddel))){       // .. remove one
                if ((colon < trans.length) &&
                    ((trans.buffer[colon] == '/') ||
                    (trans.buffer[colon] == ddel))){
                    colon++;
                }
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("trans: " + colon + " " + tlen);
            }
            trans.cutInsert(0,colon,t,tlen,0,tlen);
            if (del){
                trans.enlarge(tlen+1);
                trans.buffer[tlen] = ddel;
            }
        } while (true);
        if ((FL_B & this.trc) != 0){
            Trc.out.println("trans: " + trans.toString());
        }
        return trans.toString();
    }

    /**
     * Replace a logical name which is present at the beginning
     * of a string with its translation. If no logical name followed
     * by ":" is present, it returns the string unchanged.
     *
     * @param      str string possibly containing the logical name at
     *             the beginning
     * @param      os kind of OS for the filename syntax
     * @return     translated string; <code>str</code> if no logical name
     *             is present.
     * @exception  IOException, see <code>{@link #getEnvironment()}</code>
     *             and <code>{@link #translateLogical(String,int)}</code>.
     */

    public String replaceLogical(String str, int os)
        throws IOException {
        int i = 0;
        int len = str.length();
        for (i = 0; i < len; i++){            // check if a logical
            char c = str.charAt(i);           // .. name is present
            if (c == ':') break;
            if (c == '$') continue;
            if (c == '.') continue;
            if (c == '_') continue;
            if (Character.isLetterOrDigit(c)) continue;
            return str;
        }
        if (i == 0) return str;
        String log = null;
        return translateLogical(str,os);
    }

    /**
     * Reduce the path contained in this object by removing redundant
     * directory levels.
     *
     * @param      os kind of OS for the filename syntax
     */

    /* The reduction of a path is done follows for the notations in which
     * paths are names separated by a separator (shown as / here):
     *
     * 1. all "./" and a final "." are removed
     * 2. all "segment/../" and a final "segment/.." where segment is not
     *    ".." are removed
     * 3. the previous two steps are repeated as much as possible.
     *
     * For VMS:
     *
     * 1. all "]"[ are removed
     * 2. when a segment is a sequence of "-", for each of them the previous
     *    segment, if any and if not itself "-", is removed
     */

    public void reducePath(int os){
        char ddel;
        switch (os){
        case Prg.WIN: ddel = '\\'; break;          // Dos, Windows, NT
        case Prg.VMS: ddel = '[';  break;          // Vms
        default:      ddel = '/';  break;          // Unix
        }

        int cur = this.path;
        int lt;
        char[] buf = this.buffer;
        lt = cur + this.pathLen;

        int dst = cur;                       // now reduce
        int src = cur;
        int ini = cur;
        if (os == Prg.VMS){
            while(src < lt){                 // remove ][
                if (buf[src] == ']'){
                    if ((src+1 < lt) &&
                        (buf[src+1] == '[')){
                        src += 2;
                        continue;
                    }
                }
                buf[dst++] = buf[src++];
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("join: " +
                    String.valueOf(buf,cur,dst-cur));
            }
            lt = dst;
            src = cur;
            dst = cur;
            pack: while(src < lt){
                if (buf[src] == '['){
                    buf[dst++] = buf[src++];
                    continue;
                }
                int start = src;
                for(; src < lt; src++){          // locate segment
                    if (buf[src] == '.') break;
                    if (buf[src] == ']') break;
                }
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("segment: " +
                         String.valueOf(buf,start,src-start));
                }
                cut: if (src - start > 0){       // non empty segment
                    if (buf[start] != '-'){      // not up higher level
                        break cut;
                    }
                    if (dst == ini) break cut;       // at beginning
                    if (dst < cur + 2) break cut;    // segment not present
                    int j;
                    for (j = dst - 2; j >= cur; j--){
                        if ((buf[j] == '.') ||
                            (buf[j] == '[')){
                            j++;                 // locate start of segment
                            break;
                        }
                    }
                    if (j < cur) j++;
                    if ((dst - j >= 1) &&        // segment.
                        (buf[j] != '-')){        // segment not -
                        if ((FL_B & this.trc) != 0){
                            Trc.out.println("segment cut: " +
                                String.valueOf(buf,j,dst-j));
                        }
                        dst = j;                 // cut
                    } else {
                        break cut;
                    }
                    if (src < lt){
                        if (buf[src] == '.') src++;
                    }
                    continue;
                }
                if (src < lt){
                    if ((buf[src] == ']') &&     // remove a . before ]
                        (src - start == 0)){
                        if (buf[dst-1] == '.'){  // if not ...
                            if ((dst > 2) &&
                                (buf[dst-2] != '.')){
                                dst--;
                            }
                        }
                    }
                    src++;
                }
                System.arraycopy(buf,start,      // copy segment.
                    buf,dst,src-start);
                dst += src - start;
            }
            parseFile(dst,os);
        } else {
            pack: while(src < lt){
                int start = src;
                for(; src < lt; src++){          // locate segment
                    if (buf[src] == ddel) break;
                }
                if ((src - start == 0) &&        // two /
                    (dst > ini)){                // discard one
                    src++;
                    continue;
                }
                if ((src - start == 1) &&        // ./ or .[end]
                    (buf[start] == '.')){        // discard
                    if (src < lt) src++;
                    continue;
                }
                if ((src - start == 2) &&        // ..
                    (buf[start] == '.') &&
                    (buf[start + 1] == '.') &&
                    (dst > ini) &&               // not at beginning
                    (dst >= cur + 2) &&          // segment present
                    (buf[dst - 1] == ddel)){     // .. preceded by /
                    int j;
                    for (j = dst - 2; j >= cur; j--){
                        if (buf[j] == ddel){
                            j++;                 // locate start of segment
                            break;
                        }
                    }
                    if (j < cur) j++;
                    if ((dst - j >= 1) &&        // segment/..
                        ((dst - j != 3) ||       // segment is not ..
                        (buf[j] != '.') ||
                        (buf[j+1] != '.'))){
                        dst = j;                 // discard segment/..
                        src++;
                        continue;
                    }
                }
                if (src < lt) src++;             // skip /
                System.arraycopy(buf,start,      // copy segment/
                    buf,dst,src-start);
                dst += src - start;
            }
            this.pathLen = dst - cur;            // update indexes
            parse_path(this.path,this.pathLen,   // parse standard path
                buf,ddel);
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("merged " + toString());
        }
    }
}
