/*
 * @(#)ShellStream.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.net.*;
import lbj.IoStream.*;

/**
 * The <code>ShellStream</code> class provides a means for reading
 * streams of lines that contain continuation characters.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

/** File loader */

public class ShellStream{

    /** The input stream. */
    public IoStream inp;

    /** The path to the file. */
    public String path;

    /** The encoding of the file. */
    public String enc;

    /** The size of each read, if different from default. */
    public int frsize;

    /** The final size, with continuations and cr removed. */
    public int length;

    /** The reference to load area. */
    public char[] load;

    /** The continuation character. */
    public char cch;

    /** The prompt string. */
    public String prompt;

    /** The prompt format. */
    public String pform;

    /** The report stream. */
    public Object report;

    /** Whether nul terminate the load area. */
    public boolean nulterm;

    /** Whether to force sequential read. */
    public boolean sequential;

    /** Interactive mode. */
    public boolean inter;

    /** To stop when no continuation lines. */
    public boolean noextra;

    /** Eof encountered. */
    public boolean eof;

    /** To remove last line terminator anyway. */
    public boolean cutcrlf;

    /** The trace flags. */
    public int trc;

    /** The exception found. */
    public Throwable exc;

    /** The result of last operation. */
    public int res;

    /** The default block size for read operations. */
    private static final int READ_SIZE = 1024;

    /*
     * Internal constants for trace flags
     */

    private static final int FL_F = 1 << ('f'-0x60);
    private static final int FL_L = 1 << ('l'-0x60);
    private static final int FL_M = 1 << ('m'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Test if the trace flag passed as argument is set.
     *
     * @param      f flag
     * @return     true if flag on
     */

    boolean isTrcOn(char f){
        return ((1 << (f - 0x60)) & this.trc) != 0;
    }

    /**
     * Load a file by sewing continuation lines, which are denoted by the
     * presence of a character specified in the load object at the end of
     * lines which need continue on the next one.
     * <ul>
     * <li>`<code>\</code> LF and `<code>\</code>' CR LF and the last CR LF
     *   are removed. CR LF are reduced to LF.
     * <li>this class is suited for reading command lines and option files
     *   which can have a limited amount of extra lines after the first
     *   one and its continuations.
     * <li>it can optionally nul-terminate the load area (its returned size
     *   does not rekon it). This is useful when the load file has to be
     *   processed by string methods for text files.
     * </ul>
     * If the path is null, then the file is the standard input. In this
     * case a prompt can be specified. That prompt is printed before the
     * fist line is read. On continuation lines, a shorter prompt ">" is
     * printed.
     * If the report file is a Formatter, then a prompt format must be
     * specified. The prompt string is formatted with the prompt format.
     * Otherwise the prompt string as such is printed on the report if
     * specified, otherwise on System.err.
     */

    /* To load a file, its size is determined (to do it with files on
     * sequential devices, the file is read in memory blocks first), and then
     * the load area is allocated and loaded. Another solution could be to
     * reallocate the area at each line, or better to reallocate it in large
     * chunks and at the end to reduce it. The first solution leaves a large
     * hole in the heap. The second one is better because it enlarges a memory
     * area which is not moved each time because there are no other
     * allocations between two subsequent extensions (except for the first one
     * because the read would allocate a file block). This simplifies the
     * recognizion of the continuation string, which would no longer be split
     * into different blocks.
     * <ul>
     * <li>The transfer is done in one single read for block-files and
     *   in subsequent reads for the others in an area which is extenxed
     *   when exhausted.
     * <li>For regular files the load area is allocated immediately after file
     *   open because it is possible to know the file size, which is a bit
     *   larger than the area needed because of the continuation character
     *   and the cr's. For the other files, for which it is not possible
     *   to know the size in advance, the area is re-allocated at need.
     *   Apart from the first re-allocation, the subsequent ones do not
     *   move the area, and simply extend it (the first time the area
     *   is probably moved because after it some memory is allocated to
     *   hold some io buffer).
     * </ul>
     * The read method does not limit the lenght of lines: when a read has
     * been done that does not read the \n, another one (without a prompt
     * is done).
     * <p>
     * The file loader is not a general purpose tool because it sews
     * continuation lines and does not keep memory of the original structuring
     * of files in lines.
     * <p>
     * The formatting of a prompt is provided by using a Formatter which
     * is registered in the object. This relieves callers which already
     * use a Formatter for printing to use a second one to format the
     * prompt. The printing of a prompt is done here because on continuation
     * lines it should be done anyway.
     */

    public void read(){
        Reader    fil;
        int       nc;
        int       fsize;
        int       cur, start, end, tail;
        boolean   regular;
        String    pform = this.pform;
        String    prompt = this.prompt;

        this.exc = null;
        this.res = 0;
        this.length = 0;
        this.load = null;
        if (this.frsize == 0)
            this.frsize = READ_SIZE;      // not specified, take default
        if ((FL_L & this.trc) != 0)
            Trc.out.println("read file: " +
                ((this.path == null) ? "stdin" : this.path));
        fil = null;
        doit: try {
            inp.setOnErr(IoStream.ERR_THROW);
            inp.open(this.path,enc,IoStream.READ | IoStream.CHARS);
            regular = ((inp.getStatus() & IoStream.SPECIAL) == 0) &&
                !this.sequential;
            if (regular){                             // regular file
                long len = inp.length();
                if (len > Integer.MAX_VALUE){
                    this.res = IOError.ERR_ILLFILE;
                    this.exc = this.inp.newError(
                        IOError.ERR_ILLFILE,null);
                    break doit;
                }
                fsize = (int)len;                     // more than needed
                if (this.nulterm) fsize++;
                ensureLoad(fsize);                    // alloc. whole load area
                if ((FL_M & this.trc) != 0)
                    Trc.out.println("allocated load " + fsize);
                inp.read(this.load,0,(int)len);       // read the whole file
                cur = (int)len;
                end = (int)len;
                if ((FL_L & this.trc) != 0){
                    trc_piece("whole load",this.load,(int)len);
                    Trc.out.println("read: " + this.load);
                }
                tail = compact(0,end);
                if (this.res > 0) break doit;
                this.res = 0;
                cur = tail;
            } else {
                fsize = this.frsize;
                ensureLoad(fsize);                // allocate initial block
                if ((FL_M & this.trc) != 0){
                    Trc.out.println("allocated load " + fsize);
                }
                cur = 0;                          // index to the free part
                end = fsize;                      // index to the end
                this.eof = false;
                boolean prompting = false;
                if (((inp.getStatus() & IoStream.SPECIAL) != 0) &&
                    (this.inter)){
                    prompting = true;             // interactive stdin
                }
                boolean prompts = prompting;
                tail = 0;
                loop: do {
                    if ((FL_L & this.trc) != 0){
                        Trc.out.println("cur: " + cur +
                           " end: " + end + " frsize: " + this.frsize);
                    }
                    if (end - cur < this.frsize){     // extend block
                        fsize += this.frsize;
                        ensureLoad(fsize);
                        if ((FL_M & this.trc) != 0)
                            Trc.out.println("allocated load " + fsize);
                        end = fsize;                  // index to end
                    }
                    if (prompts){
                        if (this.report instanceof Formatter){
                            Formatter frm = (Formatter)this.report;
                            if ((FL_F & this.trc) != 0){
                                frm.settrc("bcd");
                            }
                            frm.f(pform).v(prompt).write();
                            if ((FL_L & this.trc) != 0){
                                Trc.out.println("prompt: " +
                                    prompt + " " + pform);
                            }
                        } else if (this.report instanceof PrintStream){
                            PrintStream pst = (PrintStream)this.report;
                            pst.print(this.prompt);
                        } else {
                            System.err.print(this.prompt);
                        }
                        pform = "%s%/p";
                        prompt = ">";
                    }
                    nc = inp.read(this.load,cur,this.frsize);
                    if (inp.eof()){
                        this.eof = true;
                        cur = tail;
                        break loop;
                    } else {
                        if (nc > 0){
                            if (this.load[cur+nc-1] != '\n'){
                                prompts = false;       // not a line
                            } else {
                                prompts = prompting;   // a line read, restore
                            }                          // .. prompting
                        }
                        if (cur+nc < 0){
                            this.res = IOError.ERR_OUTLIMIT;
                            this.exc = this.inp.newError(
                                IOError.ERR_OUTLIMIT,null);
                            break doit;
                        }
                    }
                    start = tail;
                    if (tail > 0){
                        if (this.load[tail-1] == this.cch){
                            start--;
                        } else if (this.load[tail-1] == '\r'){
                            start--;
                            if ((tail > 1) &&
                                (this.load[tail-2] == this.cch)){
                            start--;
                            }
                        }
                    }
                    tail = compact(start,cur+nc);
                    if (this.res > 0) break doit;
                    if (this.res < 0){
                        this.res = 0;
                        cur = tail;
                        break loop;
                    }
                    if ((FL_L & this.trc) != 0){
                        Trc.out.println("eof: " + this.eof + " nc: " + nc +
                            " cur: " + cur + " tail: " + tail);
                        trc_piece("pre-load",this.load,0,tail);
                    }
                    cur = tail;
                } while (!this.eof);
                end = cur;                            // index to end of load
                tail = cur;
                if (this.nulterm){                    // space for nul
                    if (end == tail){                 // extend block
                        ensureLoad(end+1);
                        if ((FL_M & this.trc) != 0)
                            Trc.out.println("allocated load 1\n");
                        fsize++;
                    }
                }
            }
            if ((FL_L & this.trc) != 0){
                Trc.out.println("size: " + tail);
                trc_piece("file:",this.load,tail);
            }
            cutlast: if (this.cutcrlf){               // remove last [cr] lf
                if (tail < 1) break cutlast;
                if (this.load[tail-1] != '\n') break cutlast;
                tail--;
                if (tail < 1) break cutlast;
                if (this.load[tail-1] != '\r') break cutlast;
                tail--;
            }

            this.length = tail;
            if (this.nulterm) this.load[tail++] = '\0';
            if (fsize > (tail + tail/5)){               // more than 20%
                if ((FL_L & this.trc) != 0){            // .. wasted
                    Trc.out.println("reallocated to shorten: " +
                        fsize + " to " + tail + " chars");
                }
                char[] p = new char[tail];
                System.arraycopy(this.load,0,p,0,tail);
                this.load = p;
            }
            inp.close();
        } catch (IOError e){
            this.res = IOError.ERR_IOERR;
            this.exc = e;
        } catch (OutOfMemoryError e){
            this.res = IOError.ERR_NOCORE;
            this.exc = this.inp.newError(
                IOError.ERR_NOCORE,e);
        }
        if ((FL_L & this.trc) != 0){
            Trc.out.println("end read: " + this.res);
            trc_piece("read",this.load,this.length);
        }
    }

    /**
     * Compact a slice of the load area.
     *
     * @param      cur start index
     * @param      end end index
     * @return     index to the end of the compacted part, < 0 if
     *             continuation line(s) terminated in the slice
     */

    private int compact(int ini, int end){
        int cur = ini;                          // end of processed part
        int tail = cur;                         // end of part packed
        int start = cur;                        // init of part not yet packed
        int nc;
        if ((FL_L & this.trc) != 0){
            trc_piece("compact",this.load,ini,end-ini);
            Trc.out.println("ini: " + ini + " end: " + end);
        }
        doit: {
            pack: while (cur < end){
                ccseq:
                if (this.load[cur] == this.cch){    // test if followed
                    nc = 0;                         // .. by [cr] lf
                    if (end - cur <= 1) break ccseq;
                    if (this.load[cur+1] == '\n'){
                        nc = 2;                     // cch lf
                    } else if ((this.load[cur+1] == '\r') &&
                        (end - cur > 2) &&
                        (this.load[cur+2] == '\n')){
                        nc = 3;                     // cch cr lf
                    }
                    if (nc == 0) break ccseq;       // not found
                    if (start != tail){
                        if ((FL_L & this.trc) != 0){
                            trc_piece("reduce",this.load,cur,nc);
                            Trc.out.println("move " +
                                (cur-start) + " chars");
                        }
                        System.arraycopy(this.load,start,
                            this.load,tail,cur-start);
                    }
                    if (cur+nc < 0){
                        this.res = IOError.ERR_OUTLIMIT;
                        this.exc = this.inp.newError(
                            IOError.ERR_OUTLIMIT,null);
                        break doit;
                    }
                    tail += cur-start;
                    start = cur + nc;
                    cur += nc-1;
                } else if ((this.load[cur] == '\r') &&     // cr lf
                    (cur+1 < end) &&                       // reduce to lf
                    (this.load[cur+1] == '\n')){
                    if (start != tail){
                        if ((FL_L & this.trc) != 0){
                            Trc.out.println("move " +
                                (cur-start) + " chars");
                        }
                        System.arraycopy(this.load,start,
                            this.load,tail,cur-start);
                    }
                    tail += cur-start;
                    start = cur + 1;
                    if (noextra){                          // signal end
                        this.res = -1;
                        cur += 2;
                        break pack;
                    }
                } else if (this.load[cur] == '\n'){
                    if (noextra){                          // signal end
                        this.res = -1;
                        cur++;
                        break pack;
                    }
                }
                cur++;
            } // pack
            if (cur > start){                              // last piece
                if (start != tail){
                    if ((FL_L & this.trc) != 0){
                        trc_piece("reduce",this.load,start,cur-start);
                        Trc.out.println("last move " +
                            (cur-start) + " chars");
                    }
                    System.arraycopy(this.load,start,
                        this.load,tail,cur-start);
                }
                tail += cur-start;
            }
        } //doit
        if ((FL_L & this.trc) != 0){
            trc_piece("compacted",this.load,ini,tail-ini);
            Trc.out.println("res: " + this.res);
        }
        return tail;
    }

    /**
     * Ensure that the load area is large enough.
     *
     * @param      n desired length
     */

    private void ensureLoad(int n){
        if (n < 0) throw new OutOfMemoryError();
        char[] cur = this.load;
        int curLen = (cur == null) ? 0 : cur.length;
        if (curLen < n){
            char[] p = new char[n];
            if (cur != null)
                System.arraycopy(cur,0,p,0,curLen);
            this.load = p;
        }
    }

    /**
     * Trace a string that can possibly contain control characters.
     *
     * @param      lab comment string
     * @param      s string
     * @param      len its length
     */

    static void trc_piece(String lab, char[] s, int len){
        Formatter fpk = new Formatter();
        Trc.out.println(fpk.f("%s;: %sU").v(lab).v(s,len).doString());
    }

    /**
     * Trace a string that can possibly contain control characters.
     *
     * @param      lab comment string
     * @param      s string
     * @param      off start offset
     * @param      len its length
     */

    static void trc_piece(String lab, char[] s, int off, int len){
        Formatter fpk = new Formatter();
        Trc.out.println(fpk.f("%s;: %sU").v(lab).v(s,off,off+len)
            .doString());
    }
}
