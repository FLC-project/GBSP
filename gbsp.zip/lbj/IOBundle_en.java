/*
 * @(#)IOBundle_en.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

/**
 * The <code>IOBundle_en</code> class provides the English locale for
 * the <code>IOError</code> class.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

public class IOBundle_en extends IOBundle {
}
