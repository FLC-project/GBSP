/*
 * @(#)Listing.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;
import lbj.IoStream.*;

/**
 * The <code>Listing</code> class provides a means for producing a listing
 * of a sequence of text (source) files showing error messages at their
 * registered position.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

/**
 * A source stream (or sequence of source files) is seen as a sequence of
 * lines, in which each character, and some entity which are not characters,
 * has a position. The convention is:
 * <p><pre>
 *    xxxxxx   NL      xxxxxx   NL      ...  eof
 *    0        len     +1       +len         max
 * </pre><p>
 * The position of the start of lines is the index (in the file) of the
 * first character, and that of the end is the index of the character past
 * the last. Note that since lines are separated, the end of one line
 * is never equal to the start of the next one.
 * Note that this is how this class sees files, not the actual representation
 * of them, e.g. on disks. Lines in files can be made by sequences of characters
 * preceded by character counts, or preceded and followed by separators.
 * Moreover, characters can be made by one or more bytes.
 * Listing can be directed also to use real indexes in the source stream.
 * This is always the case when Listing is told to read the source stream in
 * blocks (method <code>printListing()</code>.
 * <p>
 * The <code>Listing</code> class allows to record messages relative to any
 * position in the source, and then to print it. Messages are (subclasses of)
 * <code>ListMgs</code>. They are a means to record faults and to report them
 * for a same application. There is no concept of passing them and testing
 * them. Thus, applications need not necessarily subclass <code>ListMgs</code>.
 * <code>ListMgs</code> is a subclass of <code>Failure</code>: it adds to it
 * the capability to refer to source text.
 * <p>
 * The printing of a stream can be intermingled with message registration or
 * can be done all at the end, after all messages have been registered.
 * Since messages are kept ordered, it is better not to store a very high
 * number of messages.
 * There are two techniques to produce a listing:
 * <ol>
 * <li>immediate: the application processes a stream in a loop, detects
 *   errors, files the text and the errors into the listing:
 *   <pre>
 *      do {
 *          inp.readln(...);            -- or read(...)
 *          ... analysis
 *          if (error) lst.register(...);
 *          if ((inp.getStatus() & IoStream.DATA_BREAK) != 0){
 *              lst.lineNum = 0;
 *          }
 *          if (inp.eof()) len = -1;
 *          lst.println(...len);        -- or print()
 *      } while (!inp.eof());
 *   </pre>
 *   This skeme applies when it is possible to detect all the errors in
 *   the line and then to print them.
 *   Listing keeps a line number counter updated. The caller sets it when it
 *   skips over text without printing it.
 *   Note that lineNum is reset when there is a data break, which means that
 *   a file is ended. Restarting line numbering at each file is not mandatory,
 *   but it is advisable since it lets the user locate easily the text in
 *   files. That is also what <code>printListing()</code> does.
 *   Listing keeps an absolute index in the whole stream updated. The caller
 *   sets it when it skips over text without printing it.
 *   The caller has also to compute the index (or use the Listing one)
 *   to determine the positions of messages. When reading a stream in lines,
 *   it should reserve a position for an imaginary \n between lines.
 *   This is the same convention used by <code>printnl()</code>.
 *   Note also that <code>print()</code> or <code>println()</code> are called
 *   with a length of -1 at eof to print messages which can be present on it
 *   and flush any pending text.
 *   <p>
 *   When the input has a free format for what concerns lines, the inline
 *   skeme would be:
 *   <pre>
 *      do {
 *          lex.xxx();
 *          if (error) lst.register();
 *      } while (!inp.eof);
 *      lst.print(...-1);
 *
 *      and inside lex.xxx():
 *
 *      while (...){
 *          if (cursor == end){
 *              lst.print(...);      // print the part which is not saved
 *              inp.readBlock(...);
 *          }
 *          ...
 *      }
 *   </pre>
 *   Note that this allows to report errors only on the lexeme which has
 *   just been parsed. Moreover, it does not allow to support input on
 *   a sequence of files since buffered readers concatenate files and thus
 *   it is not possible to reset the line counter between them.
 * <li>deferred: the stream is processed, errors detected, and at the end
 *   the stream is reread and the listing produced:
 *   <pre>
 *      while (...){
 *          inp.readln();
 *          ... analysis
 *          if (error) lst.register();
 *      }
 *      ...
 *      lst.printListing();       // read sources and print listing
 *   </pre>
 * </ol>
 * The deferred skeme allows to overcome the restrictions of the inline
 * one since it allows to register messages at any position.
 * <p>
 * <b>Error handling</b>
 * <p>
 * Programs can handle errors as follows:
 * <ul>
 * <li>a program that has no listing should report errors on the stderr.
 *   This can be done by subclassing Listing and redefining msgPrint().
 * <li>a program that has a listing should report only fatals on stderr
 *   unless the listing is not specified, or it is the standard error.
 * <li>make sure that when an error occurs that does not allow to continue
 *   (e.g. a fatal one), the method that detects it terminates and the
 *   callers also, possibly after having cleaned up what has to be cleaned
 *   (e.g. locks on resources released). If errors are reported by filing
 *   messages to the listing, they are rekoned automatically, and the check
 *   that there are no errors or fatals after methods can be easily done.
 * <li>errors are found either by checking explicitly some condition,
 *   by implicitit checks (such as stack overflow) and as a result of
 *   throwing runtime errors from within called methods (such as io errors).
 *   In the first case an error message should be filed when the check is
 *   done, and in the other two cases by using a try block and filing
 *   error messages from within catch clauses. The try block should be
 *   put around actions that allow to circumstantiate the errors.
 *   E.g. when processing some input, a try block can be put around the
 *   actions that do it, reporting the file name and position in the
 *   error messages. Do not enclose in the try block heterogeneous actions,
 *   unless there is a way of keeping track of what is being done and mention
 *   it in the error messages.
 *   If the errors are fatals, then they should be printed on stderr
 *   (unless they are filed to a listing that is redirected on stderr).
 *   For this reason, the data that allow to circumstantiate the errors
 *   must all be in the errors themselves (for listing messages the source
 *   file name is not put in them since it is in some heading).
 * <li>a good reason to use ListMsg for all errors was to have a unique
 *   means to report errors from within an app (except for the few ones on
 *   the command, etc., detected in main).
 * </li>
 * <p>
 * <b>Format of listing</b>
 * <p>
 * The listing produced has the following format:
 * <p><pre>
 *     prefix appName  date time Page  n
 *     header
 *
 *     000001    source line
 *     ...
 * </pre><p>
 * where "prefix" is a string, and "appName" is the application name, both
 * specified when the listing has been created, and "header" is the localised
 * text corresponding to the key specified in the <code>section</code> field.
 * Page numbers are made of one number which is updated automatically.
 * An additional page number is printed in front of it if the contents of
 * the <code>pagns</code> fiels is greater or equal to zero.
 * Messages on source lines are reported by printing the source lines on the
 * listing or report prefixed with the line number and the flags string (if
 * any), and followed by a line indicating the positions of the text to which
 * the messages are referred to (a letter for each message) followed by the
 * messages. Line numbers are represented on 6 digits, which should be farily
 * enough.
 * <p>
 * In source lines, characters are represented as follows:
 * <ul>
 * <li>HT: is expanded with the appropriate number of spaces considering
 *   a tab present each 8 columns.
 * <li>FF: if present at the beginning of a line and has no messages on
 *   it, it produces a new page in the listing. This allows to control
 *   paging in the source. A FF terminates the current line.
 * <li>newlines: they are represented as \n, \r, or \r\n.
 * <li>printable characters: themselves. Each one occupies one column.
 *   They are all Unicode characters with an assigned value which are not
 *   control or format effectors.
 * <li>others: represented as '?'.
 * </pre></blockquote><p>
 * The position is determined keeping into account the expansion of HTs.
 * Messages that refer to a HT are attached to the first blank space of the
 * expansion of the HT.
 * <p>
 * Flags are reported on all lines starting from the one on which they have
 * been set until the one on which they are changed. Flags can also be set
 * by listing directives which have a non-null attached text and a zero
 * <code>last</code> field.
 * <p>
 * The format of messages which are printed in a listing is:
 * <p><pre>
 *    %APP-E-ERROR (A): MULDEF, Multiple definition XXX see line 100
 * </pre>
 * and that of messages which are not printed in a listing is:
 * <p><pre><p>
 *    %APP-E-NOFILE, No such file
 * </pre><p>
 * where:
 * <ul>
 * <li><code>APP</code> is the name of the application or subsystem issuing
 *   the message, reduced to four characters if longer,
 * <li><code>E</code> stands for I(informational), W(arning), E(rror) or
 *   F(atal),
 * <li><code>ERROR</code> is the localized gravity of the message,
 * <li><code>(A)</code> is the letter printed below the character in the
 *   source line at which the error occurred, if any,
 * <li><code>MULDEF</code>, <code>MULDEF</code> is a language idependent
 *   achronym which allows to find errors in listings and also in the
 *   documentation,
 * <li><code>Multiple ...</code> is the text of the message,
 * <li><code>XXX</code> is the token in error, if any,
 * <li><code>see ...</code> is optional additional information, which can
 *   vary in each message.
 * </ul>
 * Messages in a listing can refer to other messages linked to them, coming
 * from other subsystems, and describing in more detail the reason of the
 * failure. There are cases in which a source text is not only "parsed", but
 * also "executed", which can produce error messages like e.g. io errors.
 * Applications then register messages related to source positions, which in
 * turn refers to the inner failures. The first format is used by all top
 * messages, while the latter for all the other ones.
 * Note that such other messages need be "wrapped" by a ListMsg message
 * since it is not possible to create a ListMsg and copy in it the
 * data from them (because they can have additional fields, and also a
 * dedicated method to obtain the string).
 * <p>
 * Source lines are printed with the line number in front of them, followed
 * by 4 spaces and the text (in which tabs are expanded). To cope with the
 * cases in which between the line number and the source line some flags
 * must occur, a flag string can be passed to <code>println()</code>.
 * <p>
 * Lines which are longer than the listing line are printed in subsequent
 * lines separated by `\'. When only the source lines in error are printed,
 * the line numbers are printed also on continuation lines (otherwise there
 * would be no numbers at all).
 * <p>
 * To localize messages, callers should provide bundles containing message
 * tables (with the standard key <code>MSGTAB</code>) and the header which
 * is printed in the page heading (its key is kept in the <code>section</code>
 * field).
 * <p>
 * Applications subclassing this class can redefine:
 * <ol>
 * <li>a method <code>ListMsg.getMessage()</code> to deliver the
 *   text of messages (this allows to have a method which uses a switch
 *   instead of a message table when the message codes are sparse).
 *   To localize messages, the method can access a bundle, e.g. by
 *   using keys.
 * <li>a method <code>page_cbk()</code> to print the listing heading.
 * <li>a method <code>msgPrint()</code> to print a message.
 * </ol>
 * When subclassing <code>ListMsg</code>, <code>Listing</code> must be
 * subclassed as well, and the method <code>create()</code> redefined.
 * <p>
 * <b>Listing directives/b>
 * <p>
 * One semantics of listing directives is defined for streams which are
 * read and printed line by line and another for streams which are read
 * and printed in blocks.
 * The effect of listing directives is to change <code>listcnt</code>,
 * which controls the printing of text.
 * When processing lines, listing directives appear in the source on
 * lines alone, possibly with comments and whitespace. When a line is build,
 * decrements in <code>listcnt</code> take effect before printing so as not to
 * print a line which contains, e.g. a NLIST, while increments take effect
 * after, so as not to print a line which contains, e.g. a LIST.
 * This is so because it is not so simple for the caller to determine the
 * start or end of a line and register the directives on them.
 * When processing blocks, there is little notion of lines. Listing directives
 * should be registered at the position in which they are. E.g. a NLIST
 * at its first character and a LIST at the one after it.
 * E.g.: "aaa bbb NLIST ccc ddd LIST eee" would be printed as:
 * "aaa bbb  eee". It is also possible to register LIST directives one
 * character after them when followed by a space.
 * When the obscured text is on a same line, it is simply removed (unless
 * there are messages on it). When it spans several lines, it makes the
 * first character which is not obscured to be moved at the beginning of
 * the listing line. E.g. the text:
 * <p><pre>
 *         aaa bbb NLIST ccc
 *         ddd LIST eee
 * </pre><p>
 * is printed as:
 * <p><pre>
 *         aaa bbb
 *         eee
 * </pre><p>
 * Note that all the text which is obscured is effectively removed from
 * the listing and that the characters of the first line after it are
 * shfted at the beginning. It would be unlikely that such text had to be
 * placed in its line as it was in the source so as to keep some definite
 * placement with respect to the surrounding lines (the ones above are not
 * printed).
 * <p>
 * <b>Sectioned listings/b>
 * <p>
 * Listings can contain the image of several sources, and in general the
 * report of the problems found in the processing of files, databases,
 * streams, etc. In such a case, there is a need to make clear in the listing
 * the identity of the object that contains the faulty data. This can be
 * done either by forcing a new page in the listing with an appropriate
 * header, or by printing a line with the identity of the object, or by
 * registering a message and printing it immediately (by using
 * <code>print()</code>). In the latter case, it it suggested to use an
 * informational message, registered with the highest position possible.
 * Note that the printing of the identity of the object should take into
 * account the policy of replicating messages on the report (console), which
 * by default is to copy no messages (but an application could decide to
 * copy fatals, in which case it should copy the object identities too).
 * When a subclass with a changed <code>msgPrint()</code> is used, it is
 * suggested to register an informational and print it immediately before
 * printing the messages. If fatals are copied, <code>msgPrint()</code>
 * must print the informational when fatals are present in the message list.
 * Note that it is not possible to print an automatic object identification
 * header in <code>msgPrint()</code> since it is invoked after having printed
 * the source line in error.
 * Furthermore, listings can contain data other than the reporting of sources.
 * Such data are printed by using the normal formatter methods.
 * <p>
 * <b>HTML listings</b>
 * <p>
 * The listings produced by this class are the ones meant for old 132 columns printers.
 * However, nowadays the more common way of displaying files is with a web browser.
 * But a web browser displays easily these listings. HTML listings could be produced,
 * but they need to use tables to position line numbers, text, error messages, etc.,
 * quite a complex markup. Alternatively, the listings produced here can contain a
 * preformatted HTML element with the current contents, which is the same as producing
 * the listings as done here now.
 */

/* Recording of messages
 *
 * Messages are kept in a list that is processed by the <code>println()</code>,
 * <code>prints()</code> and <code>printMessages()</code> methods.
 * The list is kept ordered by the position of messages in the source.
 * Several messages can refer to the same position: they are kept in arrival
 * order. In order to speed up the insertion of messages, which is mostly done
 * in increasing positions, the list is kept in inverse position ordering,
 * and reversed at the time of printing. This allows to make the insertion
 * fast without a need to keep a tail pointer.
 *
 * Unique bundle
 *
 * A message with a blank mark does not have the -ERROR in it so as to let
 * applications use this class also for the messages which are not related to
 * source text. This class has the advantage that allows the user to redefine
 * the method to deliver the message text only while Failure forces to redefine
 * the whole getMessages(). Suppose there is a need to have a different way to
 * get the message text. ListMsg must be subclassed, and getMessage() redefined.
 * But then ordinary messages, not related to the listing would force to have
 * an ordinary bundle. To avoid it, messages with a blank mark can be used,
 * and printed by the usual Failure methods.
 * Note that these user-defined messages need be registered by using insert()
 * and not register().
 *
 * Subclassing
 *
 * Since ListMsg is a factory class, closely related to Listing, it would
 * be possible to provide an optimised method to print messages, faster than
 * getMessages(). Many messages related to text, like e.g. the ones which have
 * a lexeme in them can only be printed when there is a listing (which has a
 * reference to a source line). This, however, is not used because applications
 * which need to subclass ListMsg would need to subclass Listing too.
 *
 * There can be messages of different subsystems, each one with its own coding
 * and formatting. The ones returned by inner subsystems normally do not
 * carry in them a position. E.g. io errors. This is supported by having each
 * subsystem create Failures of its own subclass.
 * Subsystems which need report messages in a listing (e.g. a library which
 * parses some standard parts of the text), but not return failures can also
 * create ListMsgs with their own bundle.
 * 
 * Errors in Listing class
 *
 * Errors which occur in Listing methods are not wrapped. They are clear
 * enough. They are mainly io errors. They are not reported automatically
 * in the listing because it is pointless to write on a file on which there
 * are errors.
 * Moreover, the generation of a listing requires other operations to be
 * done by callers, such as opening the input and listing files, which
 * can produce errors as well. Thus, the normal skeme is to enclose all
 * of them in a try block, and stack an applicative error on top of the
 * catched ones.
 * Because of the convention to number positions in source files, a source
 * file (or a sequence of then) could be so large as to make the position
 * overflow. When it occurs, an io error is thrown.
 * When the header or flags string makes the text record overflow, an
 * io error relative to the output file is returned.
 * 
 * Unicode
 *
 * The Lising class represents printable Unicode characters as they are, and
 * the remaining Unicode ones as '?'. It does not combine characters in
 * glyphs. To render them there is a need to figure out the number of
 * columns which are occupied by one character. This is not a simple task
 * because there is a need to take into account also the encoding which is
 * used. E.g. suppose that the encoding is ISO8859_1, and that the text
 * contains a vowel followed by a non-spacing accent. There is a need to
 * know if the encoder translates those two characters into one or if it
 * replaces the second one by '?'. Moreover, if there is no encoder,
 * there is a need to know if the underlying driver prints them in one
 * column or not. For example, in HP-UX the utf8 locale does not handle
 * combining marks.
 * There would be a need not to produce listings which are printed as such,
 * i.e. to produce listings which would be printed in a known, controlled
 * way. In other words, to free from encodings. E.g. a PostScript file
 * containing all the glyphs which does not depend on any encoding.
 * For this implementation, all printable characters are printed as such.
 *
 * Format effectors
 *
 * LF is the line separator as CR, and are thus never present in text, VT
 * has no defined interpretation, BS is no longer really used to obtain
 * bold text. Thus all these format effectors are handled as control
 * characters, i.e. replaced by '?'.
 * Any representation of newlines is accepted in input. Currently \n, \r
 * and \r\n. In a stream any line can be terminated by one af them.
 * In output all the representation supported by Formatter are accepted.
 *
 * As a rule, when a stream is made by a sequence of files, lines do not
 * cross files.  I.e. if a file does not end with a newline, the last line
 * is terminated anyway. This is consistent with what IoStream.readln()
 * does, and what IoSteam.read() does with the ENDING_NL mode.
 * Operations which need be done when moving from a file to the next, like
 * e.g. updating the line counter, are triggered by testing the DATA_BREAK
 * status.
 * Another techique to represent the ending of a file and the start of the
 * next is to let IoStream insert a character which acts as an end-of-file.
 * This would make simpler the updating of the line counter, but it
 * forces to process it when parsing the input.
 *
 * Memory overflow
 *
 * The place in which several new()'s are done is the creation of messages.
 * A memory overflow can occur only when there is no limit in the number of
 * messages. When it occurs, Listing frees all messages but the first 100,
 * and then creates the Failure and throws it.
 * The caller can then report it and complete the listing (e.g. close it).
 *
 * Message classes
 *
 * Listing keeps a row to the input buffer which it is requested to be print
 * so as to make it available to the printing methods of the message classes.
 */

public class Listing extends Formatter {

    /** The reference to the listing file. */
    private IoStream lst;

    /** The reference to the text. */
    protected CharsRow text;

    /** The listing level, >= 0 means listing active. */
    public int listcnt;

    /** The head of the message list. */
    protected ListMsg msghdr;

    /** The maximum number of messages kept. */
    public int maxmsg = 30;

    /** The number of informationals. */
    public int infcnt;

    /** The number of warnings. */
    public int warcnt;

    /** The number of errors. */
    public int errcnt;

    /** The number of fatals. */
    public int fatcnt;

    /** The ordering of the list: true if reversed. */
    protected boolean msgrev;

    /** The application name. */
    public String appName;

    /** The prefix string. */
    public String prefix;

    /** The page section header. */
    public String section;

    /** The current date. */
    public Date time;

    /** Whether the listing file is open. */
    private boolean lstOpen;

    /** The name of the message bundle. */
    public String bundle;

    /** The locale. */
    public Locale locale;

    /** The instrinsic bundle. */
    public static String listBundle = IOBundle.class.getName();

    /** The message code of the "too many" message. */
    private static final int ERR_TOOMANY = 48;

    /** The message code of the " errors detected" message. */
    public static final int ERR_ERRDET = 49;

    /** The string to expand source lines. */
    private Str expText;

    /** The markers line. */
    private Str mrkLine;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    s   actions
     * </pre></blockquote><p>
     */

    private static final int FL_S = 1 << ('s'-0x60);

    /**
     * Trace the list of messages.
     */

    void msg_trace(){
        ListMsg p = this.msghdr;
        while (p != null){
            Trc.out.println(
                "post: " + p.post + " last: " + p.last +
                " code: " + p.code + " " + p.bundle +
                " mark: " + p.mark + " txta: " +
                ((p.txta == null) ? "" : String.valueOf(p.txta)));
            p = p.next;
        }
    }

    /**
     * Deliver a string representing the list of messages. The
     * directives are represented by '+' and '-', the "too many"
     * message as '*', and the other ones by their text.
     *
     * @return     string
     */

    String msgList(){
        ListMsg p;
        int     sp = 0;

        p = this.msghdr;             // determine nr of messages
        while (p != null){
            sp++;
            p = p.next;
        }
        char[] s = new char[sp];
        p = this.msghdr;
        while (p != null){           // build the string
            if (p.code < 0){
                if (p.last < 0){     // listing directive
                    s[--sp] = '-';
                } else {
                    s[--sp] = '+';
                }
            } else {
                if ((p.code == ERR_TOOMANY) &&
                    (p.bundle == listBundle)){
                    s[--sp] = '*';
                } else {
                    for (int i = 0; i < p.txta.length; i++){
                        s[--sp] = p.txta[i];
                    }
                }
            }
            p = p.next;
        }
        return String.valueOf(s,sp,s.length-sp);
    }

    /**
     * Deliver a reference to the head of the list of messages.
     *
     * @return     reference
     */

    public ListMsg head(){
        return this.msghdr;
    }

    /**
     * Removes all registered messages;
     */

    public void clear(){
        this.msghdr = null;
        this.infcnt = 0;
        this.warcnt = 0;
        this.errcnt = 0;
        this.fatcnt = 0;;
    }

    /**
     * Construct a new <code>Listing</code>. It sets the page size to
     * 132 x 60, the maximum number of messages to 30 and the report to
     * System.err.
     *
     * @see        #Listing(IoStream,Object,int,int,Locale,String)
     */

    public Listing(IoStream lst, Locale loc, String bun){
        this(lst,FileSpec.STDERR,60,132,loc,bun);
    }

    /**
     * Construct a new <code>Listing</code>.
     * It initialises the handling of diagnostic messages. The default
     * maximum number of messages is 30.
     * The whole listing is generated in the locale which is specified,
     * and which may not be changed later.
     *
     * @param      lst listing file
     * @param      rep report file
     * @param      height net number of lines in pages
     * @param      width net number of columns in pages
     * @param      loc locale
     * @param      bun name of the bundle
     */

    public Listing(IoStream lst, Object rep, int height, int width,
        Locale loc, String bun){
        this.lst = lst;
        this.text = new CharsRow();
        this.time = new Date();
        int maxln = height;
        int maxco = width;
        int h = 0;
        Object stream = lst;
        if ((lst == null) ||                                // none
            ((IoStream.IS_OPEN & lst.getStatus()) == 0)){   // not open
            stream = rep;
        } else {
            lstOpen = true;
            h = maxln;
        }
        this.bundle = bun;
        if (loc == null) loc = Locale.getDefault();
        f("%a%mp*%mls1%mms0%mms1").v(stream).v(maxco).v(h)
            .v(loc).v(IOBundle.class.getName())
            .v(bun).write();
        ResourceBundle b = getBundle(1);
        this.locale = loc;
        this.expText = new Str(this.length);      // expanded text
        this.mrkLine = new Str(this.length);      // markers line
        this.pagns = -1;                          // single page number
    }

    /**
     * A message. It indicates the violation of a condition which can be
     * related to a position in the source text, or that need be reported
     * in the listing.
     */

    public static class ListMsg extends Failure {

        /**
         * The reference to the next object.
         *
         * @serial
         */
        public ListMsg next;

        /**
         * The position of the message.
         *
         * @serial
         */
        public long post;

        /**
         * The position where the token in error ends.
         *
         * @serial
         */
        protected long last;

        /**
         * The marker for the message.
         *
         * @serial
         */
        protected char mark = ' ';

        /**
         * The additional text.
         *
         * @serial
         */
        protected char[] txta;

        /**
         * The reference to the listing object.
         *
         * @serial
         */
        protected Listing lst;

        /**
         * Construct a ListMsg.
         *
         * @param      c message code (-1 = listing directive)
         * @param      k message kind: 'I', 'W', 'E' or 'F'
         * @param      n subsystem name
         * @param      x exception
         * @param      b name of the bundle
         * @param      s message position
         * @param      e end of token position (last character +1) /
         *             lstcnt update
         * @param      t string of additional text (lines separated
         *             by \n)
         * @param      l reference to the listing object
         */

        public ListMsg(int c, char k, String n, Throwable x,
            String b, long s, long e, String t, Listing l){
            super(c,k,n,x,"",b,null);
            if (c == -1) this.code = c;   // masked by Failure
            this.next = null;
            this.post = s;
            this.last = e;
            this.mark = ' ';
            if (t != null) this.txta = t.toCharArray();
            this.lst = l;
        }

        /**
         * Deliver the standard heading of an error message. The -ERROR
         * (-FATAL, etc.) part is included only if the mark is not blank,
         * and the mark is included if it is also not zero.
         *
         * @param      loc locale, null if no locale
         * @return     string
         */

        /* The subsystem name is reduced to 4 characters so as to let
         * applications use the same string as a listing header and as
         * a message header.
         */

        public String heading(Locale loc){
            String subs = this.subSystem;
            if (this.subSystem == null){
                subs = "";
            }
            if (subs.length() > 4){
                int end = 4;                    // cut trailing spaces
                for (int i = 3; i >= 1; i--){
                    if (subs.charAt(i) != ' ') break;
                    end--;
                }
                subs = subs.substring(0,end);
            }
            Locale l = loc;
            if (loc == null) l = Locale.getDefault();
            ResourceBundle bun =
                ResourceBundle.getBundle(
                   Listing.listBundle,l);
            String mh = "";
            String mrk = "";
            if (this.mark != ' '){
                switch (this.kind){
                case 'I': mh = "INFO"; break;
                case 'W': mh = "WARNING"; break;
                case 'E': mh = "ERROR"; break;
                case 'F': mh = "FATAL"; break;
                }
                if (mh != ""){
                    mh = bun.getString(mh) + " ";
                    if (this.mark != 0){
                        mrk = "(" + this.mark + "): ";
                    }
                }
            }
            return Failure.header(subs,this.kind) + mh + mrk;
        }

        /**
         * Deliver the text of the message. This method can be redefined
         * by subclasses.
         *
         * @return     string
         */

        public String getMessage(){
            Locale loc = ((this.lst != null) && (this.lst.locale != null)) ?
                this.lst.locale : Locale.getDefault();
            Str s = new Str();
            String[] sl = getMessages(loc);
            for (String i : sl){
                if (s.length > 0) s.append('\n');
                s.append(i);
            }
            return s.toString();
        }

        /**
         * Deliver the text of the message. This method can be redefined
         * by subclasses.
         *
         * @param      loc locale, null if no locale
         * @return     string
         */

        public String getMessage(Locale loc){
            Listing lst = this.lst;
            if ((lst != null) && ((FL_S & lst.trc) != 0)){
                Trc.out.printf("getMessage: %s%n",this.bundle);
            }
            ResourceBundle bun =
                ResourceBundle.getBundle(this.bundle,loc);
            String[] msgtab = 
                ((String[])(bun.getObject("MSGTAB")));
            String mt = null;
            if (this.code < msgtab.length){
                mt = msgtab[this.code];
            }
            if (mt == null){
                mt = Integer.toString(this.code);
            }
            return mt;
        }

        /**
         * Deliver the strings representing the failure. This method can be
         * redefined by subclasses.
         *
         * @param      loc locale, null if no locale
         * @return     strings
         */

        public String[] getMessages(Locale loc){
            int nlines = 0;
            if ((this.txta != null) && (this.txta.length > 0)){
                for (int i = 0; i < this.txta.length; i++){
                    if (i < this.txta.length-1){
                        if (this.txta[i] == '\n') nlines++;
                    }
                }
            }
            if (nlines + 1 < 0) nlines--;
            String[] res = new String[nlines + 1];

            if (loc == null) loc = Locale.getDefault();
            res[0] = heading(loc) + getMessage(loc);

            Listing lst = this.lst;
            if ((lst != null) && ((FL_S & lst.trc) != 0)){
                Trc.out.println("getMessages: " + this.last + " " +
                    this.post + " " + lst.point + " " + lst.length);
            }
            if ((this.last > this.post) &&
                (this.post >= lst.point) &&
                (this.last - 1 - lst.point < lst.length) &&
                    (this.last > 0)){             // copy additional text
                res[0] += " " +
                    String.valueOf(lst.text.buffer,
                    (int)(this.post-lst.point) + lst.text.offset,
                    (int)(this.last-this.post));
            }
            nlines = 0;
            txt: if ((this.txta != null) && (this.txta.length > 0)){
                int start = 0;
                int i = 0;
                for (i = 0; i < this.txta.length; i++){
                    if (this.txta[i] == '\n'){
                        if (nlines < 0) break txt;    // overflow
                        if (res[nlines] == null){
                            res[nlines++] = String.valueOf(this.txta,
                                start,i-start);
                        } else {
                            res[nlines++] += " " + String.valueOf(this.txta,
                                start,i-start);
                        }
                        start = i + 1;
                    }
                }
                if (i > start){
                    if (nlines < 0) break txt;        // overflow
                    if (res[nlines] == null){
                        res[nlines++] = String.valueOf(this.txta,
                            start,i-start);
                    } else {
                        res[nlines++] += " " + String.valueOf(this.txta,
                            start,i-start);
                    }
                }
            }
            return res;
        }

        /**
         * Deliver the string of the additional text.
         *
         * @return     string
         */

        public String getText(){
            if (this.txta == null) return "";
            return String.valueOf(this.txta);
        }
    }

    /**
     * Remove the first message in the message list.
     *
     * @param      lst listing file
     */

    protected void msg_dea(){
        ListMsg p = this.msghdr;
        if (this.msghdr != null){
            this.msghdr = p.next;         // remove from the head
        }
    }

    /**
     * Create a new message and register it.
     *
     * @see        Listing.ListMsg#Listing.ListMsg(
     *             int,char,String,Throwable,String,long,long,String,Listing)
     */

    public ListMsg register(int c, char k, String n, Throwable x,
        String b, long s, long e, String t){
        ListMsg p = null;
        try {
            p = new ListMsg(c,k,n,x,b,s,e,t,this);
            insert(p, (n == null) ? this.appName : n);
        } catch (OutOfMemoryError exc){
            p = this.msghdr;
            if (p != null){
                for (int i = 0; i < 100; i++){    // keep 100 only
                    if (p.next == null) break;
                    p = p.next;
                }
                p.next = null;
            }
            throw this.lst.newError(IOError.ERR_NOCORE,exc);
        }
        return p;
    }

    /**
     * Create a new message for the bundle of the listing and register it.
     *
     * @see        Listing.ListMsg#Listing.ListMsg(
     *             int,char,String,Throwable,String,long,long,String,Listing)
     */

    public ListMsg register(int c, char k, long s, long e, String t){
        return register(c,k,null,null,this.bundle,s,e,t);
    }

    /**
     * Create a new message.
     *
     * @see        #register(int,char,long,long,String)
     * @return     reference to the created object
     */

    public ListMsg create(int c, char k, long s, long e, String t){
        return new ListMsg(c,k,null,null,this.bundle,s,e,t,this);
    }

    /**
     * Create a new message.
     *
     * @see        Listing.ListMsg#Listing.ListMsg(
     *             int,char,String,Throwable,String,long,long,String,Listing)
     * @return     reference to the created object
     */

    public ListMsg create(int c, char k, String n, Throwable x,
        String b, long s, long e, String t){
        ListMsg p = new ListMsg(c,k,n,x,b,s,e,t,this);
        p.subSystem = (n == null) ? this.appName : n;
        p.mark = 0;                        // force -ERROR format
        return p;
    }

    /**
     * Register a new message which refers to a given point in the text.
     * The application name is used as subsystem.
     *
     * @see        #insert(ListMsg, String)
     * @param      p reference to the message to be registered
     */

    public void insert(ListMsg p){
        insert(p,this.appName);            // relieve the user do it
    }

    /**
     * Register a new message which refers to a given point in the text.
     * The message is inserted in the appropriate position in the list.
     * If the maximum number of messages has been reached, only fatals
     * are enqueued, and a warning TOOMANY is enqueued at the end.
     * Messages which are listing control directives are always put before
     * the other ones relative to the same line.
     * A possibly present message TOOMANY is always moved at the end.
     *
     * @param      p reference to the message to be registered
     * @param      subs subsystem
     */

    public void insert(ListMsg p, String subs){
        ListMsg   pr, c, too;
        boolean   fatal;

        if ((FL_S & this.trc) != 0){
            Trc.out.println("insert: " + p.code +
                " at " + p.post + " " + subs);
        }
        p.subSystem = subs;
        p.mark = 0;                        // force -ERROR format
        reg: {
            if (p.code >= 0){              // not a listing directive
                fatal = (p.kind == 'F');
                if (!fatal){
                    long tot = this.infcnt + this.warcnt +
                        this.errcnt + this.fatcnt;
                    if (tot == this.maxmsg){              // too many
                        if ((FL_S & this.trc) != 0){
                            Trc.out.println("insert too many");
                        }
                        p = new ListMsg(ERR_TOOMANY,'W',
                            p.subSystem,null,listBundle,0,0,null,this);
                        p.mark = 0;
                        if ((FL_S & this.trc) != 0){
                            Trc.out.println("insert toomany");
                        }
                    } else if (tot > this.maxmsg){        // discard it
                        break reg;
                    }
                }
            }
            if ((FL_S & this.trc) != 0){
                Trc.out.println("insert done " + p.code +
                    " " + p.bundle);
            }

            ins: {                             // insert in ordered list
                pr = null;                     // ptr to previous
                c = this.msghdr;               // ptr to current
                too = null;
                if ((p.code == ERR_TOOMANY) &&
                    (p.bundle == listBundle)){
                    too = p;
                    if (c == null) break ins;
                    if ((c.code == ERR_TOOMANY) && // already present
                        (c.bundle == listBundle)){
                        break reg;
                    }
                    break ins;
                }
                if (c != null){
                    if ((c.code == ERR_TOOMANY) && // remove it from list
                        (c.bundle == listBundle)){
                        too = c;
                        c = c.next;
                        this.msghdr = c;
                    }
                }
                while (c != null){             // seek insertion point
                    if (c.post <= p.post)      // point found
                        break;
                    pr = c;                    // ptr to previous
                    c = c.next;                // step to next
                }
                if (pr == null){               // insert at beginning
                    p.next = this.msghdr;
                    this.msghdr = p;
                } else {                       // insert in the middle
                    p.next = c;
                    pr.next = p;
                }                              // end insertion
                pr = p;
                if ((FL_S & this.trc) != 0){
                    Trc.out.println("insert inserted");
                }
            } //ins
            if (too != null){                  // insert warning too many errors
                if ((FL_S & this.trc) != 0){
                    Trc.out.println("insert too " + too.code +
                        " " + too.bundle);
                }
                too.next = this.msghdr;        // insert at beginning
                this.msghdr = too;
            }
            if (p.code < 0) return;
        } //reg
        updateCounters(p);                     // update error counters
        if ((FL_S & this.trc) != 0){
            Trc.out.println("insert i = " + this.infcnt +
                " w = " + this.warcnt +
                " e = " + this.errcnt + " f = " + this.fatcnt);
            msg_trace();
            Trc.out.println("end-list");
        }
    }

    /**
     * Update the message counters rekoning the specified message.
     *
     * @param      p reference to the message descriptor
     */

    private void updateCounters(ListMsg p){
        switch (p.kind){
        case 'I': this.infcnt += 1;
            if (this.infcnt < 0) this.infcnt--; break;
        case 'W': this.warcnt += 1;
            if (this.warcnt < 0) this.warcnt--; break;
        case 'E': this.errcnt += 1;
            if (this.errcnt < 0) this.errcnt--; break;
        case 'F': this.fatcnt += 1;
            if (this.fatcnt < 0) this.fatcnt--; break;
        }
    }

    /**
     * Reverse the list of messages. It is then ready to be scanned
     * to print messages.
     */

    protected void msg_reverse(){
        ListMsg curr, next, prev;

        if ((FL_S & this.trc) != 0){
            Trc.out.println("msg-reverse");
            msg_trace();
            Trc.out.println("end-list");
        }
        curr = this.msghdr;                 // pointer to first element
        if (curr != null){
            prev = null;
            while (curr != null){
                next = curr.next;           // save next to step on
                curr.next = prev;           // reverse the link
                prev = curr;
                curr = next;
            }
            this.msghdr = prev;             // store the head link
        }
        if ((FL_S & this.trc) != 0){
            Trc.out.println("msg-reverse done");
            msg_trace();
            Trc.out.println("end-list");
        }
    }

    /**
     * Print a source line and the line of markers, if any.
     * The flags string is inserted between the line number and the text.
     *
     * @param      fl flags string
     * @param      isLine <code>true<code> if the referred text is a line
     * @param      flush <code>true<code> to flush the stream
     * @param      buf reference to the text
     * @param      off offset in it
     * @param      len length
     */

    /* This method can print a line or a slice of text. When it prints
     * a slice, it takes it together with the one processed previously,
     * it prints all the text in it which makes up complete listing lines,
     * and it keeps the remainder for the next call.
     * A println() simulates a newline at the end of files which do not
     * have it.
     * To know that some text makes up complete lines, text must be expanded
     * first. Moreover, there is a need to keep the text of an incomplete
     * line (in any form) so as to complete and print a line next time.
     * To do it, the expanded text which makes an incomplete line is kept
     * (vs keeping the origin text). The markers are also kept. 
     * This is simpler than storing the expanded text in the formatter's
     * buffer and set tabs for marks.
     *
     * Moreover, only the messages of complete lines are printed in one
     * execution of print() (but the marks computed).
     * To determine whether there are messages on a line (or a sub-line, of
     * a long line) all the messages which lay at a position lower or equal
     * to the end of the slice end are taken. The messages which belong to the
     * line which is being built are kept in a separate list so as to
     * process them when eventually the line is printed, otherwise the next
     * time they would be processed again.
     *
     * This is where messages are placed with respect to the input.
     * When the input is a line, its tail (which is printed on a line)
     * has an extra position at which messages placed at an imaginary newline
     * are printed. When it is a slice, the newline is present, but not
     * handed to the formatter, and an extra position reserved for it.
     * When it is an eof, no line is present, and an extra position reserved
     * (which is at the beginning of the listing line).
     * When an empty line is passed (including the case when there is a message
     * at eof), no loop is done to scan the input, and thus there should be
     * at least a separate loop for messages.
     * There is a case when a message is present at a position which is one
     * after the last in a file, and the last print() is done.
     * Messages which lay before the first position in the block are marked
     * as if they were placed at the first position. Messages at the end of
     * the line (i.e. one character after the last of the line, which is not
     * the newline) are marked one position after the last.
     * The slice of source text whey refer to, if any, it not printed.
     * This is the case of messages which are placed after the last character
     * of the stream and that gets printed at eof.
     * Note that when a piece is processed, all the messages whose position
     * is equal or lower to that of the last character of the piece are
     * processed. This allows to issue messages which are placed at the end
     * of the text when the eof is processed (their position could be lower
     * than that of the eof).
     * The method print() detects when it is called with a length lower
     * than zero because that means eof and in such a case it performs first
     * a flush printing the line and the messages at the current position and
     * then it prints the line, marks and messages at eof. Note that calling
     * src_print with len < 0 or with flush is not the same.
     *
     * When a line is processed with the println mode, a message which is
     * positioned one character after the last of the line belongs to
     * that line. When it is processed with the print mode, that problem does
     * not exist because messages which are placed after the last character
     * of a line are placed on the newline character(s), which belong
     * automatically to the line. However, when processing in println mode
     * and a line is broken because it is too long, the placement of messages
     * is the normal one. This is the reason to have two tests to determine
     * if a message belongs to a line.
     *
     * A state is kept to remember what an incomplete line is so as to print
     * it in the proper way. A slice which terminates in \n, completes a line.
     * One which terminates in \r completes a line, and it makes a \n
     * appearing at the beginning of the next one be discarded.
     * When there is an incomplete line at the end of the buffer, it is not
     * printed, and kept instead in the line buffer so as to be completed at a
     * next call. In this case there is a need to remember if what is in the
     * line buffer started at a source line start (in which case the line
     * number must be printed). This is remembered by state 3. A special
     * case is when there is an incomplete line, but it fits exactly into a
     * listing line. In this case the listing line is printed, and the state
     * 2 is set.
     * There is a need to know when the start of a line is printed so
     * as to print the line number. A println() forces it before and
     * after to allow a print() then to know it. A print() forces it only
     * when it detects a newline.
     * An extra call should be done at the end of the stream to flush
     * the text in case it is not terminated by a newline.
     *
     * Long lines are broken into pieces. If the break is done in the middle
     * of the expansion of a tab (but not at the first space), the expansion
     * is truncated and the line printed. This allows to start afresh with
     * the next piece, i.e. not to hand over the remaining part of expansion.
     * In order to place a marker at the end of lines (i.e. one column after
     * it), the last column is not used to print source characters.
     * Lines or pieces thereof without messages could make use of that column,
     * but since to determine if there are messages into pieces, pieces must
     * be first expanded, that would force to recalculate pieces should a
     * message fall to that position.
     *
     * The generation of the markers line is not done together with the
     * expansion of source lines in order not to make less efficient the
     * printing of the lines that do not have messages attached (most frequent
     * case). 
     *
     * To implement listing directives in print() mode, when marks are
     * collected and a directive is processed which makes listcnt become
     * negative, the corresponding position in the expanded text is recorded,
     * then if a message is found, no text is cut, and else if a directive
     * which makes listcnt become nonnegative, the text is cut.
     *  
     * The indexes are as follows:
     *
     *         |<--offset-->|<-----length-------->|
     *    buf  .............xxxxxxxxxxxxxxxxxxxxxx.....   buffer
     *                      |          |
     *                      point      post
     *
     * The current implementation is driven by the reading of blocks, and
     * to cater for this has to keep a status info so as to know the next
     * time if is has to fill a partial line, print messages, etc.
     * It is conceivable to make it driven by lines instead, e.g.:
     *
     *      while (true){
     *          get a line, or what fits in a listing line
     *          if no messages on it and no listing, continue
     *          print line
     *          print marks,
     *      }
     *
     * However, this is not viable, since to determine what fits a listing
     * line, the input must be processed expanding the tabs, which is the
     * same that is done in src_lst.
     */

    private void src_print(String fl, boolean isLine, boolean flush,
        char[] buf, int off, int len){
        this.text.buffer = buf;
        this.text.offset = off;
        this.text.length = len;
        if (len < 0){
            this.text.offset = 0;
            this.text.length = 0;
            this.point = Long.MAX_VALUE;
        }
        long bufPoint = this.point;
        if ((FL_S & this.trc) != 0){
            Trc.out.println("src_print " + bufPoint +
                " " + (bufPoint+this.text.length) + " state: " + this.state);
            Trc.out.print("lineNum: " + this.lineNum + " |");
            Trc.literalize(buf,this.text.offset,this.text.length);
            Trc.out.println("| " + this.text.length + " " + this.listcnt);
        }

        ListMsg tptr = this.msghdr;
        int j = this.text.offset;
        int flen = 4;
        if (fl != null){                          // flag string specified
            this.flags = fl.toCharArray();
        }
        if ((this.text.length > 0) &&             // \r at end of last
            (buf[j] == '\n') &&                   // .. piece and \n at
            (this.state == 1)){                   // .. start of this
            j++;
            this.state = 0;
        }

        char mrk = 'A' - 1;
        Str m = this.mrkLine;                     // markers line
        for (int z = m.length-1; z >= 0; z--){
            if (m.buffer[z] != ' '){
                mrk = m.buffer[z];                // last mark
                break;
            }
        }
        int startState = this.state;
        if (startState == 3) startState = 0;
        loop: do {
            if (isLine){                          // line
                boolean messages = false;
                if (tptr != null){                // no messages present
                    if (tptr.post - bufPoint <=   // .. in this input line
                        this.text.length){        // .. or before it
                        messages = true;
                    }
                }
                if (!messages){
                    if ((this.listcnt < 0) ||     // do not print the line
                        !lstOpen){                // .. at all
                        this.lineNum++;
                        break loop;
                    }
                }
            }

            if ((FL_S & this.trc) != 0){
                Trc.out.println("src_print loop: " + bufPoint +
                    " " + j + " " + this.text.offset);
            }
            boolean ff = false;
            int jff = -1;
            if (startState <= 1){                 // line start, no leftover ..
                if ((this.text.length > 0) &&     // .. messages
                    (buf[j] == '\f')){            // FF
                    jff = j;
                    if ((tptr == null) ||
                        ((tptr.post - bufPoint) >
                        (j - this.text.offset))){ // no messages on it
                        ff = true;
                        j++;
                    }
                }
            }

            int newState = 2;
            Str s = this.expText;                 // expanded text
            int start = j;
            int d = this.expText.length;
            int old = d;
            int max = this.end - flen - 6 - 1;
            int endj = this.text.offset + this.text.length;
            exp: while (j < endj){
                if (d == max) break exp;
                char ch = buf[j++];
                if (ch == '\t'){                  // HT
                    do {
                        if (d == max) break exp;
                        s.buffer[d++] = ' ';      // expand with spaces
                    } while (d % 8 != 0);
                } else {
                    if (!isLine){
                        if (ch == '\r'){
                            if (j >= endj){
                                newState = 1;
                                break exp;
                            }
                            ch = buf[j++];
                            if (ch == '\n'){
                                newState = 0;
                                break exp;
                            } else {
                                j--;
                                newState = 0;
                                break exp;
                            }
                        } else if (ch == '\n'){
                            newState = 0;
                            break exp;
                        } else if (ch == '\f'){
                            if (j-1 != jff){
                                j--;
                                newState = 0;
                                break exp;
                            }
                        }
                    }
                    if (ch < 0x100){
                        if ((ch <= 0x1f) ||       // NUL .. US
                            ((0x7f <= ch) &&
                                (ch <= 0x9f)) ||  // DEL .. 9f
                            (0xff < ch)) ch = '?';
                    } else {
                        int t = Character.getType(ch);
                        switch (t){
                        case Character.UNASSIGNED:
                        case Character.LINE_SEPARATOR:
                        case Character.PARAGRAPH_SEPARATOR:
                        case Character.CONTROL:
                        case Character.FORMAT:
                        case Character.PRIVATE_USE:
                            ch = '?';
                        }
                    }
                    s.buffer[d++] = ch;
                }
            }
            s.length = d;
            if (isLine){
                if (j == endj) newState = 0;
            } else {
                if (flush) newState = 0;
            }
            boolean done = (d == max) || (newState <= 1) || (len < 0);
            if (done && (newState == 2)) s.buffer[s.length++] = '\\';
            if ((FL_S & this.trc) != 0){
                Trc.out.print("exp piece: |");
                    Trc.literalize(s.buffer,0,s.length);
                Trc.out.println("| " + start + " " + j +
                    " done: " + done + " newState: " + newState +
                    " state: " + this.state + " startState: " + startState);
            }

            int pieceLen = j - this.text.offset;
            if ((isLine && (newState <= 1)) ||
                (len < 0) || flush){
                pieceLen++;                       // simulate a trailing \n
            }
            char c = 'A' - 1;
            if (m.length > 0){
                for (int z = m.length-1; z >= 0; z--){
                    if (m.buffer[z] != ' '){
                        c = m.buffer[z];          // last mark
                        break;
                     }
                }
            }

            // cut is -1 = keep the text or 0 = discard it, or > 0 =
            // discard the part that must not be printed because of
            // a listing directive

            int cut = -1;                         // start of part to discard
            if (this.listcnt < 0) cut = old;
            if ((FL_S & this.trc) != 0){
                Trc.out.println("src_print cut: " +
                    cut + " " + this.listcnt);
            }
            d = old;
            long prev = -1L;                      // previous message position
            ml: while (tptr != null){             // scan all msg of this
                if ((FL_S & this.trc) != 0){      // .. (piece of) line
                    Trc.out.println("mark post " +
                        tptr.post + " point " +
                        (bufPoint+pieceLen) +
                        " " + m.length);
                }
                if (tptr.post - bufPoint >=       // not in this line piece
                    pieceLen){
                    break;
                }
                long rpos =                       // relative position in buffer
                    tptr.post - bufPoint;
                if (rpos < 0) rpos = 0;           // before the first
                if (rpos > prev){                 // new position
                    // determine the nr of characters
                    // needed to arrive at the one in
                    // error
                    while (start - this.text.offset <
                        rpos){                    // expand source line from
                        if (start <= j){          // .. prev marker included
                            char ch =             // .. up to curr excluded
                                buf[start];
                            if (ch == '\t'){      // HT
                                d += 8 - (d % 8);
                            } else {
                                d++;
                            }
                        }
                        start++;
                    }
                }
                if (!isLine){
                    // the messages that have been moved to the
                    // leftover list have been already processed
                    // and possibily cut some text
                    if (tptr.code < 0){           // listing directive
                        if ((tptr.last == 0) &&   // flags
                            (tptr.txta != null)){
                            this.flags = tptr.txta;
                            tptr = tptr.next;
                            continue ml;
                        }
                        this.listcnt += tptr.last;
                        tptr = tptr.next;
                        if (this.listcnt < 0){
                            if (cut < 0) cut = d;
                        } else {
                            if (cut >= 0){
                                s.cutInsert(cut,d-cut,(char[])null,0,0,0);
                            }
                            cut = -1;
                        }
                        continue ml;
                     } else {
                        cut = -1;
                     }
                }
                if (rpos > prev){                 // new position
                    if (c == 'Z') c = 'A';
                    else c++;
                    int k = m.length;
                    for (; k <= d-1; k++){        // the marker point
                        m.buffer[m.length++] = ' ';
                    }
                    m.buffer[m.length++] = c;
                    prev = rpos;
                }
                tptr.mark = c;                    // register mark in msg
                tptr = tptr.next;
            }
            if (!isLine){
                if (this.leftMsgs != null){       // messages left over
                    ListMsg p = this.leftMsgs;
                    while (p != null){
                        if (p.code >= 0){         // not a listing directive
                            cut = -1;             // do not cut
                            break;
                        }
                        p = p.next;
                    }
                }
                if (cut >= 0){
                    s.cutInsert(cut,s.length-cut,(char[])null,0,0,0);
                }
            }
            if ((FL_S & this.trc) != 0){
                Trc.out.println("mark line: |" +
                    m.toString() + "|" + m.length);
            }
            if (done){
                if (startState <= 1){             // line start
                    this.lineNum++;
                }
            }
            wl: if ((s.length > 0) || ((s.length == 0) && (cut < 0)) ||
                (m.length > 0)){
                if (!lstOpen && (m.length == 0)) break wl;
                if (ff){                          // new page
                    f("%/e").writeln();
                } else if (m.length > 0){
                    f("%mp>2").writeln();         // ensure room for 2 lines
                }
                if (done){
                    if (len < 0){                 // input file closed
                        if (m.length > 0){
                            f("[%mm0%sm;]").v("EOF").writeln();
                        }
                    } else if ((startState > 1) &&   // piece of line
                        (this.listcnt >= 0)){        // source printed with line nrs, ..
                        if (this.flags == null){     // .. otherwise print them
                            f("%x*%s").v(6+flen).v(s).writeln();
                        } else {
                            f("%x6%s-4%s").v(this.flags).v(s).writeln();
                        }
                    } else if (this.flags == null){
                        f("%ip06%x*%s").v(this.lineNum).v(flen).v(s).writeln();
                    } else {
                        f("%ip06%s-4%s").v(this.lineNum).v(this.flags).v(s).writeln();
                    }
                    this.expText.length = 0;
                    if (m.length > 0){
                        f("%x*%s").v(6+flen).v(m).writeln();
                    }
                    this.mrkLine.length = 0;
                }
            }

            ListMsg last = null;                      // find last leftover message
            for (ListMsg x = this.leftMsgs; x != null;
                x = x.next){
                last = x;
            }
            ListMsg newlast = null;                   // find new last message
            for (ListMsg x = this.msghdr; x != null;
                x = x.next){
                if (x.post - bufPoint >= pieceLen){   // not in this input line
                    break;
                }
                newlast = x;
            }
            if (newlast != null){
                if (last != null){                    // leftover list nonempty
                    last.next = this.msghdr;
                } else {
                    this.leftMsgs = this.msghdr;
                }
                this.msghdr = newlast.next;
                newlast.next = null;
            }
            if (done){
                while (this.leftMsgs != null){        // emit messages text
                    if (this.leftMsgs.code >= 0){     // not a listing directive
                        msgPrint(this.leftMsgs);
                    }
                    this.leftMsgs = this.leftMsgs.next;
                }
                this.expText.length = 0;
                this.mrkLine.length = 0;
            }
            this.state = newState;
            if (newState == 2){
                if ((startState <= 1) && !done){      // current piece of line ..
                    this.state = 3;                   // .. starts at source line ..
                }                                     // .. and has not been output
            }
            startState = newState;
        } while (j < this.text.offset + this.text.length);
        upd: {
            this.point += this.text.length;
            if (this.point >= 0){
                if (isLine && (this.point != Long.MAX_VALUE)){
                    if (this.truePos){
                        this.point += this.nl.length();
                    } else {
                        this.point += 1;
                    }
                    if (this.point >= 0) break upd;
                } else {
                    break upd;
                }
            }
            throw new IOError(IOError.ERR_OUTLIMIT,null,
                this.lst.getPath(),this.point - this.text.length,this);
        }
        if ((FL_S & this.trc) != 0){
            Trc.out.println("src_print end point: " +
                this.point + " " +
                ((this.flags != null) ? String.valueOf(this.flags) : "null") +
                " state: " + this.state);
        }
    }

    /** Whether true (real) positions are used in the input. */
    private boolean truePos;

    /**
     * Tell this Listing if the positions in messages denote real positions
     * in the input.
     *
     * @param      b <code>true</code> to denote real positions, </code>false</code> otherwise.
     */

    public void setTruePos(boolean b){
        this.truePos = b;
    }

    /**
     * Tell this listing the line separators that follow the line that will be printed
     * in this Listing with the <code>println()</code> method.
     *
     * @param      nl string of the line separator, empty if there are none
     */

    public void setLineSep(String nl){
        this.nl = nl;
    }

    /** The line separator of the current line. */
    private String nl;

    /** The flags string. */
    private char[] flags;

    /** The number of the next source line which will be printed. */
    public long lineNum;

    /** The index of the first character of the next source piece. */
    public long point;

    /**
     * The state of the last line printed as of the end of the line:
     * 0: line break, 1: line break ended in \r, 2: no break, 3: no
     * break and line starts at source line break.
     */
    private int state;

    /** The head of the list of messeges left over from an incomplete line. */
    private ListMsg leftMsgs;

    /**
     * Emit a slice of text in the listing file, if opened.
     *
     * @param      buf reference to the text
     * @param      off offset in it
     * @param      len length
     */

    public void print(char[] buf, int off, int len){
        if (!this.msgrev) msg_reverse();         // reverse the list: now right
        if (len < 0){
            if (this.expText.length > 0){
                src_print(null,false,true,buf,0,0);
            }
        }
        src_print(null,false,false,buf,off,len);
        if (!this.msgrev) msg_reverse();         // reverse again the list
    }

    /**
     * Emit a source line in the listing file, if opened.
     *
     * @see        #println(String)
     */

    public void println(char[] buf, int off, int len){
        println(null,buf,off,len);
    }

    /**
     * Emit a source line in the listing file, if opened. If there are
     * messages attached, it emits the source line (on the listing, if
     * opened, otherwise on the report) followed by a markers line indicating
     * the positions of messages by means of the letter A..Z (after Z it
     * restarts from A). The line is followed by message lines. If the
     * listing is not opened and there are no messages, no lines are printed.
     * Messages are printed by position.  Messages descriptors are
     * deallocated after printing.  When the length of an input line is
     * longer than the space in the listing, the line is broken and the
     * pieces after the first one are printed without line number.
     * The markers and messages appear after each piece. When there is a
     * message on the eof, a line with (a localised version of) "[eof]" as
     * line number is printed.
     * The source line and the markers line are put in the same page of the
     * listing. A line number of 0 is not printed.
     * Listing directives decrements take effect before printing the line
     * to which they refer to (so as not to print e.g. a .NLIST source line),
     * increments take place after (so as not to print a .LIST line preceded
     * by a .NLIST line).
     * If a flags string is specified, it is printed in place of the spaces
     * which are printed between the line number and the source text.
     *
     * @param      f flags string
     * @param      buf reference to the text
     * @param      off offset in it
     * @param      len length
     */

    /* If the routine is called before calling msg_rev (i.e. it finds
     * a reversed list), it reverses it temporarily, it extracts the
     * relevant messages, and then it makes it reversed again.
     * This allows to call register() repeatedly, and then println()
     * without having to reverse the list.
     */

    public void println(String f, char[] buf, int off, int len){
        int pend = 0;                            // pending lstcnt update
        if (!this.msgrev) msg_reverse();         // reverse the list: now right
        while (this.msghdr != null){             // process the listing directives
            ListMsg m = this.msghdr;             // .. which are in this line
            if (m.post - this.point >            // not in this input line
                this.text.length) break;
            if (m.code < 0){                     // listing directive
                if (m.last < 0){
                    this.listcnt += m.last;
                } else {
                    pend += (int)(m.last);
                }
                msg_dea();                       // deallocate descriptor
            } else {
                break;
            }
        }
        this.state = 0;
        src_print(f,true,false,buf,off,len);     // print line and markers
        if ((FL_S & this.trc) != 0){
            Trc.out.println("println");
            msg_trace();
            Trc.out.println("end-list");
        }
        this.listcnt += pend;
        if (!this.msgrev) msg_reverse();         // reverse again the list
    }

    /**
     * Print the page heading.
     */

    protected void page_cbk(){
        f("%s;%? %s  %mm1%ddD   %mm0%sm  ")
            .v(this.prefix).v(this.prefix != null)
            .v(this.appName)                  // first heading
            .v(this.time)                     // date and time
            .v("PAGE")
            .write();
        if (this.pagns >= 0){                 // double number
            f("%i;.").v(this.pagns).write();
        }
        if (this.section == null){
            f("%i%/%mm1%2/").v(this.pagnr)
                .write();                     // section header
        } else {
            f("%i%/%mm1%sm%2/").v(this.pagnr)
                .v(this.section).write();     // section header
        }
    }

    /**
     * Emit the message on the top of the list.
     *
     * @param      p reference to the message descriptor
     */

    public void print(){
        msgPrint(this.msghdr);
        msg_dea();                // deallocate descriptor
    }

    /**
     * Emit the specified message.
     *
     * @param      p reference to the message descriptor
     */

    public void print(ListMsg p){
        updateCounters(p);        // update error counters
        msgPrint(p);
    }

    /**
     * Print a diagnostic message. It can be redefined by subclasses,
     * e.g. to print the message both on a listing and on the report.
     *
     * @param      p reference to the message descriptor
     */

    protected void msgPrint(ListMsg p){
        Throwable exc = p;
        do {
            String[] msgs;
            if (exc instanceof Failure){
                Failure ex = (Failure)exc;
                msgs = ex.getMessages(this.locale);
                exc = ex.exc;
            } else {
                msgs = new String[] {
                    Failure.header("JRE",'F') + exc.toString()};
                exc = null;
            }
            for (int i = 0; i < msgs.length; i++){
                if (i > 0) f("  ").write();
                int len = msgs[i].length();
                int off = 0;
                int end;
                do {
                    end = len;
                    if (end - off > this.length){
                        end = off + this.length;
                    }
                    f("%s").v(msgs[i],off,end).writeln();
                    off = end;
                } while (off < len);
            }
        } while (exc != null);
    }

    /**
     * Emit all registered messages. Printing is done on the listing,
     * if opened, otherwise on the report. Messages descriptors are
     * deallocated after printing. Upon return, the list of messages
     * is empty.
     *
     * @param      buf reference to the text
     * @param      off offset in it
     * @param      len length
     */

    public void printMessages(char[] buf, int off, int len){
        this.text.buffer = buf;
        this.text.offset = off;
        this.text.length = len;
        if (len < 0){
            this.text.offset = 0;
            this.text.length = 0;
            this.point = Long.MAX_VALUE;
        }
        msg_reverse();
        ListMsg tptr = this.msghdr;
        while (tptr != null){         // emit messages text
            msgPrint(tptr);
            msg_dea();                // deallocate descriptor
            tptr = this.msghdr;       // step to next
        }
    }

    /**
     * Read the stream line by line and print a listing with diagnostic
     * messages. Upon return the list of messages is empty.
     * The stream must have been opened with <code>ENDING_NL</code> mode.
     * This method can be used when messages have been registered at the
     * positions of characters in the stream obtained by giving newlines
     * one position only.
     *
     * @param      inp stream
     */

    public void printnlListing(IoStream inp){
        boolean rev;

        if ((this.msghdr == null) &&
            (this.listcnt < 0)) return;
        msg_reverse();                         // reverse the list
        rev = this.msgrev;                     // save it
        this.msgrev = true;
        this.point = 0;
        this.text.length = 0;
        this.state = 0;
        this.leftMsgs = null;
        int len = 0;
        do {
            inp.readln(this.text);             // read line
            if ((inp.getStatus() & IoStream.DATA_BREAK) != 0){
                this.lineNum = 0;              // file change
            }
            if (inp.eof()) this.text.length = -1;
            this.nl = inp.lineSeparator;       // remember line separator
            println(this.text.buffer,          // print line and messages
                this.text.offset,this.text.length);
        } while (!inp.eof());
        this.msgrev = rev;
    }

    /**
     * Read the stream and print a listing with diagnostic messages.
     * Upon return the list of messages is empty.
     * The stream must have been opened with <code>ENDING_NL</code> mode.
     * This method can be used when messages have been registered at the
     * real positions of characters in the stream, i.e. by enumerating
     * the characters which represent newines as they really are in the
     * stream.
     *
     * @param      inp stream
     */

    public void printListing(IoStream inp){
        boolean rev;

        if ((this.msghdr == null) &&
            (this.listcnt < 0)) return;
        msg_reverse();                         // reverse the list
        rev = this.msgrev;                     // save it
        this.msgrev = true;
        this.point = 0;
        this.text.length = 0;
        this.state = 0;
        this.leftMsgs = null;
        int len = 0;
        do {
            inp.read(this.text,1024);          // read block
            char[] buf = this.text.buffer;
            int off = this.text.offset;
            len = this.text.length;
            if ((inp.getStatus() & IoStream.DATA_BREAK) != 0){
                this.lineNum = 0;              // file change
            }
            if (inp.eof()) len = -1;
            print(buf,off,len);                // print block and messages
        } while (len >= 0);
        this.msgrev = rev;
    }

    /**
     * Print a command string. It breaks it at a delimiter if it exceeds
     * the length of the listing line.
     *
     * @param      com command string
     * @param      cc continuation character
     */

    public void wrtcml(String com, char cc){
        int i;                                  // current index in c
        int start;                              // start of substring
        int ln;

        ln = com.length();
        if (ln == 0) return;                    // empty command
        i = 0;                                  // index of line start
        start = i;
        for (;;){
            i += this.length;                   // max index of substring
            if (i >= ln){
                f("%s").v(com,start,com.length()).writeln();
                return;
            } else {
                i -= 1;                         // space for the -
                                                // search a break
                do {
                    char ch = com.charAt(--i);
                    if (ch == ',') break;
                    if (ch == '/') break;
                    if (ch == '=') break;
                    if (ch == ':') break;
                    if (ch == ' ') break;
                } while (i > start);
                if (i == start){                // no separator present
                    i += this.length-1;         // break at line end
                } else {
                    i += 1;                     // break at delimiter included
                }
                f("%s%c").v(com,start,i).v(cc).writeln();
                start = i;
            }
        }
    }

    /**
     * Print the "Errors detected" message on the listing, and on the
     * report if there are errors or fatals.
     */

    public void errdet(){
        errDetected();
        long errnum = this.errcnt +         // errors and fatals
            this.fatcnt;
        if ((this.fatcnt > 0) ||            // errors or fatals
            (this.errcnt > 0)){
            ListMsg fl = new ListMsg(ERR_ERRDET,'I',this.appName,
                null,this.listBundle,0,0,Long.toString(errnum),this);
            System.err.println();
            fl.print(System.err,this.locale,false);
            System.err.println();
        }
    }

    /**
     * Print the "Errors detected" message on the listing.
     */

    public void errDetected(){
        long errnum = this.errcnt +         // errors and fatals
            this.fatcnt;
        f("%/;%mm0%sm;  %i")
            .v("ERRDET").v(errnum).write();
        if (errnum + this.warcnt > 0){
            f("  (").write();
            f("%sm;: %i%@, ");
            if (this.warcnt > 0){
                v("WARNINGS").v(this.warcnt).write();
            }
            if (this.errcnt > 0){
                v("ERRORS").v(this.errcnt).write();
            }
            if (this.fatcnt > 0){
                v("FATALS").v(this.fatcnt).write();
            }
            f("%@;)").write();
        }
        f("").writeln();
    }
}
