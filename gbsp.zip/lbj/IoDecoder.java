/*
 * @(#)IoDecoder.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;

/**
 * The <code>IoDecoder</code> class provides a means for decoding byte
 * sequences.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

/**
 * This class provides methods for splitting byte sequences into
 * characters without performing the transcoding.
 * <p>
 * <b>General note on decoders.</b>
 * <p>
 * Decoders take an array of bytes and determine the number of
 * characters which are present, according with a given encoding.
 * They are concerned with the structure of the byte sequences,
 * i.e. with the grouping of byte sequences into character, and not
 * with the mapping of codepoints from one charset onto another.
 * The only one case in which they detect specific codepoints is
 * in the detection of line terminators.
 * They deliver the number of characters and the index in the byte
 * array at which decoding stopped. Decoding stops when either the
 * bytes are exhausted or a sequence is found which may not form a
 * character.
 * <p>
 * All of them are supposed to be called with offsets and lenghts
 * which denote existing array elements, or one just after the last.
 * <p>
 * The general convention followed is to scan the bytes, and when one
 * is found which starts a sequence, an appropriate number of bytes
 * following it is examined, if existent, and if they form a valid
 * sequence, the index into the buffer is advanced. The index is never
 * advanced during the matching of a sequences, except when a finite
 * state automaton is used. In such a case, if termination occurs in
 * a state which is not final, the index is repositioned to the beginning
 * of the last recognised sequence. Termination can occur either because
 * no transition is defined for the next byte for the current state or
 * because no more bytes are available. In the latter case the index is
 * set to the first byte position after the last in the byte buffer
 * when the loop terminates, and then repositioned by the statements
 * immediately following it.
 * <p>
 * To detect the end-of-line, when the encoder is created, the bytes for
 * CR and LF are determined and then used. There are codes in which several
 * codesets are present. This is the case of JIS0208 for which the
 * line terminators are recognised also in the shifted out codeset.
 * <p>
 * Encoding and decoding is not a reversible process: a character string
 * can be encoded in several valid byte sequences of a same encoding.
 * They can differ, e.g. in the number of escape or control sequences
 * present in them. Moreover, since unmapped characters are encoded in
 * some galley character, decoding an encoded sequence would deliver
 * a string in which the unmapped characters are changed.
 * <p>
 * For shift-lock encodings, the matching of escape sequences is such that
 * valid escape sequences are recognized and handled, while incomplete or
 * invalid escape sequence, i.e. the ones which after an ESC do not
 * have one of the allowed sequences, are rejected.
 * This so because sun.io decoders reject them as malformed sequences, and
 * thus also here they are rejected, and because international standards
 * such as RFC 1468.
 * Note that these decoders never identify a portion of the byte buffer
 * which make sun.io decoders throw a MalformedInputException.
 * <p>
 * Decoders can be instructed to decode a given number of characters,
 * or all the characters up to the line terminator, but not both.
 * In the latter case, supply a number of characters which is negative.
 * <p>
 * When characters are encoded by using a encoder, the encoder can be told
 * to generate a sequence of bytes which ends with the appropriate escape
 * sequences that in lock-shift encodings bring the current charset back
 * to ASCII. To decode such sequences, and in general byte sequences which
 * are characters followed by byte sequences which are lock-shifts, there
 * is a need to detect the bytes which make up the lock-shifts that bring
 * back the initial charset. A solution could be to ask the decoder to stop
 * when the requested number of characters have been scanned and also the
 * shift status is the initial one. However, when a byte buffer is passed
 * which contains one sequence that is a character followed by many
 * lock-shifts, none of which shifts to the initial state, the decoder would
 * report that no character has been decoded. The caller then should
 * enlarge the buffer and provide the previous bytes and some more bytes
 * to the decoder, continuing like this until the end of the file has been
 * reached, or the initial state reached, or a malformed sequence reached.
 * This is not practical.
 * Decoders, instead, when the number of characters requested is zero,
 * match the lock-shifts that bring to the unshifted state.
 * Note that in methods for lock-shift encodings there are two tests on the
 * reaching of the requested number of characters. The first one serves to
 * exit when zero characters are requested, and a sequence has been found
 * which is a character, the second serves to exit without appending
 * lock-shifts to the requested characters.
 */


public class IoDecoder {

    /** The current shift state for shift-lock encodings. */
    public int shiftState = 0;

    /** The index at which decoding stops. */
    public int byteIndex;

    /** Whether the last decoding stopped because of a malformed sequence. */
    public boolean malformed;

    /** Whether the last decoding stopped because of an incomplete sequence. */
    public boolean incomplete;

    /** The byte ordering for Unicode encodings. */
    public int endian = 0;

    /** The CR line terminator. */
    public int cr;

    /** The LF line terminator. */
    public int lf;

    /** The kind of encoding. */
    private static int kind;

    /** The map between encodings and their kind. */
    private static final String DECODERS =
        "ASCII s," +
        "ISO8859_1 s,ISO8859_2 s,ISO8859_3 s,ISO8859_4 s,ISO8859_5 s," +
        "ISO8859_6 s,ISO8859_7 s,ISO8859_8 s,ISO8859_9 s," +
        "Cp037 s,Cp1006 s,Cp1025 s,Cp1026 s,Cp1046 s,Cp1097 s,Cp1098 s," +
        "Cp1112 s,Cp1122 s,Cp1123 s,Cp1124 s,Cp1250 s,Cp1251 s,Cp1252 s," +
        "Cp1253 s,Cp1254 s,Cp1255 s,Cp1256 s,Cp1257 s,Cp1258 s,Cp273 s," +
        "Cp277 s,Cp278 s,Cp280 s,Cp284 s,Cp285 s,Cp297 s,Cp420 s,Cp424 s," +
        "Cp437 s,Cp500 s,Cp737 s,Cp775 s,Cp838 s,Cp850 s,Cp852 s,Cp855 s," +
        "Cp857 s,Cp860 s,Cp861 s,Cp862 s,Cp863 s,Cp864 s,Cp865 s,Cp866 s," +
        "Cp868 s,Cp869 s,Cp870 s,Cp871 s,Cp874 s,Cp875 s,Cp918 s,Cp921 s," +
        "Cp922 s,JIS0201 s,KOI8_R s,MS874 s,MacArabic s,MacCentralEurope s," +
        "MacCroatian s,MacCyrillic s,MacDingbat s,MacGreek s,MacHebrew s," +
        "MacIceland s,MacRoman s,MacRomania s,MacSymbol s,MacThai s," +
        "MacTurkish s,MacUkraine s," +
        "Big5 0,EUC_CN 0,EUC_KR 0,GBK 0,JIS0208 0,JIS0212 0," +
        "Cp1381 1,Cp942 2,Cp948 3,Cp949 4,Cp950 5," +
        "Cp1383 6,Cp970 6," +
        "Cp930 7,Cp933 7,Cp935 7,Cp937 7,Cp939 7," +
        "Cp33722 8," +
        "Cp964 9," +
        "EUC_JP A," +
        "EUC_TW B," +
        "ISO2022CN C," +
        "ISO2022JP D," +
        "ISO2022KR E," +
        "SJIS F," +
        "UTF8 G,UTF-8 G" +
        "Unicode H," +
        "UnicodeLittle I," +
        "UnicodeBig J,UTF-16 J";

    /**
     * Create a decoder.
     *
     * @param      enc name of encoding
     * @exception  UnsupportedEncodingException if <code>enc</code> is
     *             not null and does not denote a supported encoding
     */

    public IoDecoder(String enc) throws UnsupportedEncodingException {
        if (enc == null) return;
        int ind = DECODERS.indexOf(enc + " ");
        if (ind >= 0){
            this.kind = DECODERS.charAt(ind + enc.length() + 1);
        } else {
            throw new UnsupportedEncodingException(enc);
        }
        if ((this.kind < 'H') || ('J' < this.kind)){  // not Unicode
            byte[] crlf = String.valueOf("\r\n").getBytes(enc);
            this.cr = crlf[0] & 0xff;
            this.lf = crlf[1] & 0xff;
        }
    }

    /**
     * Decode a sequence of bytes. The sequence is a slice in a byte
     * array. Decoding terminates when:
     * <ul>
     * <li>the byte sequence is exhaused, or
     * <li>the number or characters decoded equals the one passed as
     *   argument, or
     * <li>a line terminator, if specified, has been encountered.
     * </ul>
     * 
     * @param      bb byte array
     * @param      off start index of the sequence
     * @param      len length of the sequence
     * @param      max maximum number of characters to be decoded
     * @return     number of characters decoded
     */

    public int decode(byte[] bb, int off, int len, int max){
        this.malformed = false;
        this.incomplete = false;
        int nch = 0;
        switch (this.kind){
        case 's':
            nch = decodeOneByte(bb,off,len,max);
            break;
        case '0':
            nch = decodeDoubleByte(bb,off,len,max);
            break;
        case '1':
            nch = decodeDBCS_ASCII(bb,off,len,lead1381,max);
            break;
        case '2':
            nch = decodeDBCS_ASCII(bb,off,len,lead942,max);
            break;
        case '3':
            nch = decodeDBCS_ASCII(bb,off,len,lead948,max);
            break;
        case '4':
            nch = decodeDBCS_ASCII(bb,off,len,lead949,max);
            break;
        case '5':
            nch = decodeDBCS_ASCII(bb,off,len,lead950,max);
            break;
        case '6':
            nch = decodeEUC(bb,off,len,max);
            break;
        case '7':
            nch = decodeDBCS_EBCDIC(bb,off,len,max);
            break;
        case '8':
            nch = decodeCp33722(bb,off,len,max);
            break;
        case '9':
            nch = decodeCp964(bb,off,len,max);
            break;
        case 'A':
            nch = decodeEUC_JP(bb,off,len,max);
            break;
        case 'B':
            nch = decodeEUC_TW(bb,off,len,max);
            break;
        case 'C':
            nch = decodeISO2022CN(bb,off,len,max);
            break;
        case 'D':
            nch = decodeISO2022JP(bb,off,len,max);
            break;
        case 'E':
            nch = decodeISO2022KR(bb,off,len,max);
            break;
        case 'F':
            nch = decodeSJIS(bb,off,len,max);
            break;
        case 'G':
            nch = decodeUTF8(bb,off,len,max);
            break;
        case 'H':
            nch = decodeUnicode(bb,off,len,'\u0000',max);
            break;
        case 'I':
            nch = decodeUnicode(bb,off,len,'\uFFFE',max);
            break;
        case 'J':
            nch = decodeUnicode(bb,off,len,'\uFEFF',max);
            break;
        }
        return nch;
    }

    /** Shift-out. */
    private static final int SO = 14;

    /** Shift-in. */
    private static final int SI = 15;

    /** Escape. */
    private static final int ESC = 27;

    /** S2 shift control character. */
    private static final int S2 = 142;

    /** S3 shift control character. */
    private static final int S3 = 143;

    /** GR (Graphic Right plane) lower value . */
    private static final int GRL = 160;

    /** GR (Graphic Right plane) upper value . */
    private static final int GRH = 255;

    /**
     * Reset the decoder.
     */

    public void reset(){
        this.shiftState = 0;
        this.byteIndex = 0;
    }

    /**
     * Decode fixed one byte encodings.
     * It delivers the number of bytes that encode a number of characters.
     * Decoding stops always at a byte sequence boundary. If there are
     * not enough bytes, a lower number of sequences is decoded.
     * Decoding stops at a line terminator, if specified.
     *
     * @param      bb byte buffer
     * @param      off start index in byte buffer
     * @param      len number of bytes
     * @param      nchar number of characters to decode, &lt; 0 to
     *             stop at line terminators
     * @return     number of decoded characters
     */

    private int decodeOneByte(byte[] bb, int off, int len, int nchar){
        int nch = 0;
        boolean crlf = false;
        if (nchar < 0){          // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int ln = len;
        if (nchar < len) ln = nchar;
        int i;
        if (!crlf){
            i = off + ln;
            nch = ln;
        } else {
            scan: for (i = off; i < off+ln; i++){
                int b = bb[i] & 0xff;
                if (b == lf){            // detect end-of-line
                    i++;
                    break scan;
                } else if (b == cr){
                    i++;
                    if (i >= off+len) break scan;
                    b = bb[i] & 0xff;
                    if (b == lf) i++;
                    break scan;
                }
            }
            nch = i - off;
        }
        this.byteIndex = i;
        return nch;
    }

    /**
     * Decode EUC with two codesets encodings.
     * Sequences are made of single bytes in 0x00..0x7f range, otherwise
     * by two bytes.
     *
     * @see        #decodeOneByte(byte[],int,int,int,byte[])
     */

    private int decodeDoubleByte(byte[] bb, int off, int len, int nchar){
        int nch = 0;
        boolean crlf = false;
        if (nchar < 0){          // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int i;
        scan: for (i = off; i < off+len; i++){
            int b = bb[i] & 0xff;
            if (b <= 127){                     // one byte
                if (crlf){
                    if (b == lf){              // detect end-of-line
                        i++;
                        nch++;
                        break scan;
                    } else if (b == cr){
                        i++;
                        nch++;
                        if (i >= off+len) break scan;
                        b = bb[i] & 0xff;
                        if (b == lf){
                            i++;
                            nch++;
                        }
                        break scan;
                    }
                }
            } else {                           // two bytes
                if (i+1 >= off+len){           // no second byte
                    this.incomplete = true;
                    break;
                }
                i++;
            }
            if (++nch >= nchar){
                i++;
                break scan;
            }
        }
        this.byteIndex = i;
        return nch;
    }

    /**
     * Decode EUC with two codesets 0 and 1 encodings.
     *
     * @see        #decodeOneByte(byte[],int,int,int,byte[])
     */

    private int decodeEUC(byte[] bb, int off, int len, int nchar){
        int nch = 0;
        boolean crlf = false;
        if (nchar < 0){          // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int state = 0;
        int i;
        scan: for (i = off; i < off+len; i++){
            int b = bb[i] & 0xff;
            switch (state){
            case 0:
                if (b == S2 || b == S3){                // S2, S3
                    this.malformed = true;
                    break scan;
                }
                if (b <= 159){
                    if (crlf){
                        if (b == lf){                   // detect end-of-line
                            i++;
                            nch++;
                            break scan;
                        } else if (b == cr){
                            i++;
                            nch++;
                            if (i >= off+len) break scan;
                            b = bb[i] & 0xff;
                            if (b == lf){
                                i++;
                                nch++;
                            }
                            break scan;
                        }
                    }
                    break;                              // codeset 0
                }
                if (b == GRL || b == GRH){              // SP, DEL in codeset 1
                    this.malformed = true;
                    break scan;
                }
                state = 1;
                break;
            case 1:
                if (b <= GRL || GRH <= b){              // not SP..DEL
                    i--;
                    this.malformed = true;
                    break scan;
                }
                state = 0;
                break;
            }
            if (state == 0){
                if (++nch >= nchar){
                    i++;
                    break scan;
                }
            }
        }
        if (i >= off+len){
            if (state == 1){
                i--;
                this.incomplete = true;
            }
        }
        this.byteIndex = i;
        return nch;
    }

    /**
     * Decode DBCS EBCDIC encodings.
     *
     * @see        #decodeOneByte(byte[],int,int,int,byte[])
     */

    private int decodeDBCS_EBCDIC(byte[] bb, int off, int len, int nchar){
        int nch = 0;
        boolean crlf = false;
        if (nchar < 0){          // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int i;
        scan: for (i = off; i < off+len; i++){
            int b = bb[i] & 0xff;
            if (b == SO){                   // SO
                if (this.shiftState == 1){
//                    this.malformed = true;
//                    break scan;
                }
                this.shiftState = 1;
                continue;
            } else if (b == SI){            // SI
                if (this.shiftState == 0){
//                    this.malformed = true;
//                    break scan;
                }
                this.shiftState = 0;
                if (nch >= nchar){          // lock-shift delivery
                    i++;
                    break scan;
                }
                continue;
            }
            if (nch >= nchar) break scan;   // zero char requested
            if (this.shiftState == 0){
                if (crlf){
                    if (b == lf){           // detect end-of-line
                        i++;
                        nch++;
                        break scan;
                    } else if (b == cr){
                        i++;
                        nch++;
                        if (i >= off+len) break scan;
                        b = bb[i] & 0xff;
                        if (b == lf){
                            i++;
                            nch++;
                        }
                        break scan;
                    }
                }
            } else {
                if (b < 64 || 254 < b){
//                    this.malformed = true;
//                    break scan;
                }
                if (i+1 >= off+len){        // no second byte
                    this.incomplete = true;
                    break scan;
                }
                int b2 = bb[++i] & 0xff;
                if ((b != 64 || b2 != 64) && (b2 < 65 || b2 > 254)){
//                    i--;
//                    this.malformed = true;
//                    break scan;
                }
            }
            if (++nch >= nchar){
                i++;
                break scan;
            }
        }
        this.byteIndex = i;
        return nch;
    }

    /**
     * Decode DBCS ASCII encodings.
     *
     * @see        #decodeOneByte(byte[],int,int,int,byte[])
     * @param      lead bit array that tells if a byte is a lead one
     */

    private int decodeDBCS_ASCII(byte[] bb, int off, int len, byte[] lead,
        int nchar){
        int nch = 0;
        boolean crlf = false;
        if (nchar < 0){          // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int i;
        scan: for (i = off; i < off+len; i++){
            int b = bb[i] & 0xff;
            if (b < 128){                   // one byte
                if (crlf){
                    if (b == lf){           // detect end-of-line
                        i++;
                        nch++;
                        break scan;
                    } else if (b == cr){
                        i++;
                        nch++;
                        if (i >= off+len) break scan;
                        b = bb[i] & 0xff;
                        if (b == lf){
                            i++;
                            nch++;
                        }
                        break scan;
                    }
                }
            } else {
                b -= 128;
                if ((lead[b >>> 3] &
                    (1 << (b & 0x7))) != 0){         // two bytes
                    if (i >= off+len-1){             // no second byte
                        this.incomplete = true;
                        break scan;
                    }
                    i++;
                }
            }
            if (++nch >= nchar){
                i++;
                break scan;
            }
        }
        this.byteIndex = i;
        return nch;
    }

    /** Flag table of lead bytes for Cp1381. */
    private static byte[] lead1381 = new byte[] {
        0x0,       (byte)0xf0,(byte)0xff,(byte)0xff,
        (byte)0xff,(byte)0x03,(byte)0xff,(byte)0xff,
        (byte)0xff,(byte)0xff,(byte)0xff,(byte)0xff,
        (byte)0xff,(byte)0xff,(byte)0xff,0x0
    };

    /** Flag table of lead bytes for Cp942. */
    private static byte[] lead942 = new byte[] {
        (byte)0x1e,(byte)0xff,(byte)0xff,(byte)0xff,
        0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
        (byte)0xff,(byte)0x7,(byte)0xff,(byte)0x1f
    };

    /** Flag table of lead bytes for Cp948. */
    private static byte[] lead948 = new byte[] {
        (byte)0xde,(byte)0xff,(byte)0xff,(byte)0xff,
        (byte)0xff,(byte)0xff,(byte)0xff,(byte)0xff,
        (byte)0xff,(byte)0xff,(byte)0x03,(byte)0xf8,
        (byte)0xff,(byte)0xff,(byte)0xff,(byte)0xf
    };

    /** Flag table of lead bytes for Cp949. */
    private static byte[] lead949 = new byte[] {
        0x0,(byte)0x80,(byte)0xff,(byte)0xff,
        (byte)0xff,(byte)0x1f,(byte)0xff,(byte)0xff,
        (byte)0xff,(byte)0xff,(byte)0xff,(byte)0xff,
        (byte)0xff,(byte)0xff,(byte)0xff,(byte)0x7f
    };

    /** Flag table of lead bytes for Cp950. */
    private static byte[] lead950 = new byte[] {
        (byte)0xfe,(byte)0xff,(byte)0xff,(byte)0xff,
        (byte)0xff,(byte)0xff,(byte)0xff,(byte)0xff,
        (byte)0xff,(byte)0xff,(byte)0xff,(byte)0xff,
        (byte)0xff,(byte)0xff,(byte)0xff,(byte)0x7f
    };

    /**
     * Decode Cp33722 encoding.
     *
     * @see        #decodeOneByte(byte[],int,int,int,byte[])
     */

    private int decodeCp33722(byte[] bb, int off, int len, int nchar){
        int nch = 0;
        boolean crlf = false;
        if (nchar < 0){          // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int state = 0;
        int i;
        scan: for (i = off; i < off+len; i++){
            int b = bb[i] & 0xff;
            switch (state){
            case 0:
                if (b == S2){               // S2
                    state = 2;
                } else if (b == S3){        // S3
                    state = 3;
                } else if (b <= 159){
                    if (crlf){
                        if (b == lf){       // detect end-of-line
                            i++;
                            nch++;
                            break scan;
                        } else if (b == cr){
                            i++;
                            nch++;
                            if (i >= off+len) break scan;
                            b = bb[i] & 0xff;
                            if (b == lf){
                                i++;
                                nch++;
                            }
                            break scan;
                        }
                    }
                    break;
                } else if ((b == GRL) || (GRH <= b)){
                    this.malformed = true;
                    break scan;
                } else {
                    state = 1;
                }
                break;
            case 1: case 2:
                if (b <= GRL || GRH <= b){
                    i--;
                    this.malformed = true;
                    break scan;
                }
                state = 0;
                break;
            case 3:
                if (b <= GRL || GRH <= b){
                    i--;
                    this.malformed = true;
                    break scan;
                }
                state = 4;
                break;
            case 4:
                if (b <= GRL || GRH <= b){
                    i -= 2;
                    this.malformed = true;
                    break scan;
                }
                state = 0;
                break;
            }
            if (state == 0){
                if (++nch >= nchar){
                    i++;
                    break scan;
                }
            }
        }
        if (i >= off+len){
            switch (state){
            case 1: case 2: case 3: i--; break;
            case 4: i -= 2; break;
            }
            if (state != 0) this.incomplete = true;
        }
        this.byteIndex = i;
        return nch;
    }

    /**
     * Decode Cp964 encoding.
     *
     * @see        #decodeOneByte(byte[],int,int,int,byte[])
     */

    private int decodeCp964(byte[] bb, int off, int len, int nchar){
        int nch = 0;
        boolean crlf = false;
        if (nchar < 0){          // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int state = 0;
        int i;
        scan: for (i = off; i < off+len; i++){
            int b = bb[i] & 0xff;
            switch (state){
            case 0:
                if (b == S2){               // S2
                    state = 2;
                } else if (b == S3){        // S3
                    this.malformed = true;
                    break scan;
                } else if (b <= 159){
                    if (crlf){
                        if (b == lf){       // detect end-of-line
                            i++;
                            nch++;
                            break scan;
                        } else if (b == cr){
                            i++;
                            nch++;
                            if (i >= off+len) break scan;
                            b = bb[i] & 0xff;
                            if (b == lf){
                                i++;
                                nch++;
                            }
                            break scan;
                        }
                    }
                    break;
                } else if ((b == GRL) || (b >= GRH)){
                    this.malformed = true;
                    break scan;
                } else {
                    state = 1;
                }
                break;
            case 1:
                if (b <= GRL || GRH <= b){
                    i--;
                    this.malformed = true;
                    break scan;
                }
                state = 0;
                break;
            case 2:
                if (b == 162 || b == 172 || b == 173){
                    state = 3;
                    break;
                }
                i--;
                this.malformed = true;
                break scan;
            case 3:
                if (b <= GRL || GRH <= b){
                    i -= 2;
                    this.malformed = true;
                    break scan;
                }
                state = 4;
                break;
            case 4:
                if (b <= GRL || GRH <= b){
                    i -= 3;
                    this.malformed = true;
                    break scan;
                }
                state = 0;
                break;
            }
            if (state == 0){
                if (++nch >= nchar){
                    i++;
                    break scan;
                }
            }
        }
        if (i >= off+len){
            switch (state){
            case 1: case 2: i--; break;
            case 3: i -= 2; break;
            case 4: i -= 3; break;
            }
            if (state != 0) this.incomplete = true;
        }
        this.byteIndex = i;
        return nch;
    }

    /**
     * Decode EUC-JP encoding.
     *
     * @see        #decodeOneByte(byte[],int,int,int,byte[])
     */

    private int decodeEUC_JP(byte[] bb, int off, int len, int nchar){
        int nch = 0;
        boolean crlf = false;
        if (nchar < 0){          // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int i;
        scan: for (i = off; i < off+len; i++){
            int b = bb[i] & 0xff;
            if (b <= 127){
                if (crlf){
                    if (b == lf){           // detect end-of-line
                        i++;
                        nch++;
                        break scan;
                    } else if (b == cr){
                        i++;
                        nch++;
                        if (i >= off+len) break scan;
                        b = bb[i] & 0xff;
                        if (b == lf){
                            i++;
                            nch++;
                        }
                        break scan;
                    }
                }
            } else {
                if (b == S3){
                    if (i+2 >= off+len){         // no second and third bytes    
                        this.incomplete = true;
                        break scan;
                    }
                    i += 2;
                } else {
                    if (i+1 >= off+len){         // no second and third bytes
                        this.incomplete = true;
                        break scan;
                    }
                    i++;
                }
            }
            if (++nch >= nchar){
                i++;
                break scan;
            }
        }
        this.byteIndex = i;
        return nch;
    }

    /**
     * Decode EUC-TW encoding.
     *
     * @see        #decodeOneByte(byte[],int,int,int,byte[])
     */

    private int decodeEUC_TW(byte[] bb, int off, int len, int nchar){
        int nch = 0;
        boolean crlf = false;
        if (nchar < 0){          // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int state = 0;
        int i;
        scan: for (i = off; i < off+len; i++){
            int b = bb[i] & 0xff;
            switch (state){
            case 0:
                if (b == 0) continue;
                if (b <= 127){
                    if (crlf){
                        if (b == lf){           // detect end-of-line
                            i++;
                            nch++;
                            break scan;
                        } else if (b == cr){
                            i++;
                            nch++;
                            if (i >= off+len) break scan;
                            b = bb[i] & 0xff;
                            if (b == lf){
                                i++;
                                nch++;
                            }
                            break scan;
                        }
                    }
                    break;
                }
                if (b == S2){
                    state = 2;
                } else {
                    state = 1;
                }
                break;
            case 1:                    // CNS 11643, plane 1
                if (b <= 127){
                    i--;
                    this.malformed = true;
                    break scan;
                }
                state = 0;
                break;
            case 2:                    // CNS 11643, planes 1..16
                if (b == 162){
                    state = 3;
                } else if (b == 163){
                    state = 4;
                } else {
                    i--;
                    this.malformed = true;
                    break scan;
                }
                break;
            case 3:
                if (b > 127){
                    state = 5;
                } else {
                    i -= 2;
                    this.malformed = true;
                    break scan;
                }
                break;
            case 4:
                if (b > 127){
                    state = 6;
                } else {
                    i -= 2;
                    this.malformed = true;
                    break scan;
                }
                break;
            case 5:
                if (b <= 127){
                    i -= 3;
                    this.malformed = true;
                    break scan;
                }
                state = 0;
                break;
            case 6:
                if (b <= 127){
                    i -= 3;
                    this.malformed = true;
                    break scan;
                }
                state = 0;
                break;
            }
            if (state == 0){
                if (++nch >= nchar){
                    i++;
                    break scan;
                }
            }
        }
        if (i >= off+len){
            switch (state){
            case 1: case 2: i--; break;
            case 3: case 4: i -= 2; break;
            case 5: case 6: i -= 3; break;
            }
            if (state != 0) this.incomplete = true;
        }
        this.byteIndex = i;
        return nch;
    }

    /**
     * Decode ISO2022-CN encoding.
     *
     * @see        #decodeOneByte(byte[],int,int,int,byte[])
     */

    private int decodeISO2022CN(byte[] bb, int off, int len, int nchar){
        int nch = 0;
        boolean crlf = false;
        if (nchar < 0){          // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int i;
        scan: for (i = off; i < off+len; i++){
            int b = bb[i] & 0xff;
            switch (b){
            case SO:                         // SO
                this.shiftState = 1;
                continue;
            case SI:                         // SI
                this.shiftState = 0;
                if (nch >= nchar){           // lock-shift delivery
                    i++;
                     break scan;
                }
                continue;
            case ESC:                        // ESC
                if (i+2 >= off+len){         // no second and third bytes
                    this.incomplete = true;
                    break scan;
                }
                b = bb[i+1] & 0xff;
                switch (b){
                case '$':
                    b = bb[i+2] & 0xff;
                    switch (b){
                    case 'A':                    // S0des
                        i += 2;
                        continue;
                    case ')':
                        if (i+3 >= off+len){
                            this.incomplete = true;
                            break scan;
                        }
                        b = bb[i+3] & 0xff;
                        if (b == 'A'){           // S0 designator
                            i += 3;
                            continue;
                        } else if (b == 'G'){    // S0 designator
                            i += 3;
                            continue;
                        }
                        this.malformed = true;
                        break scan;
                    case '*':
                        if (i+3 >= off+len){
                            this.incomplete = true;
                            break scan;
                        }
                        b = bb[i+3] & 0xff;
                        if (b == 'H'){           // SS2 designator
                            i += 3;
                            continue;
                        }
                        this.malformed = true;
                        break scan;
                    case '+':
                        if (i+3 >= off+len){
                            this.incomplete = true;
                            break scan;
                        }
                        b = bb[i+3] & 0xff;
                        if (b == 'I'){           // SS3 designator
                            i += 3;
                            continue;
                        }
                        this.malformed = true;
                        break scan;
                    }
                    this.malformed = true;
                    break;
                case 78: case 79:            // SS2, SS3: ESC N, ESC O
                    if (i+3 >= off+len){
                        this.incomplete = true;
                        break scan;
                    }
                    i += 3;
                    if (++nch >= nchar){
                        i++;
                        break scan;
                    }
                    continue;
                }
                this.malformed = true;
                break scan;
            }
            if (nch >= nchar) break scan;    // zero char requested
            if (this.shiftState == 0){       // ASCII
                if (crlf){
                    if (b == lf){            // detect end-of-line
                        i++;
                        nch++;
                        break scan;
                    } else if (b == cr){
                        i++;
                        nch++;
                        if (i >= off+len) break scan;
                        b = bb[i] & 0xff;
                        if (b == lf){
                            i++;
                            nch++;
                        }
                        break scan;
                    }
                }
                if (++nch >= nchar){
                    i++;
                    break scan;
                }
            } else {                         // GB, CNS
                if (i+1 >= off+len){
                    this.incomplete = true;
                    break scan;
                }
                i++;
                if (++nch >= nchar){
                    i++;
                    break scan;
                }
            }
        }
        this.byteIndex = i;
        return nch;
    }


    /**
     * Decode ISO2022-JP encoding.
     *
     * @see        #decodeOneByte(byte[],int,int,int,byte[])
     */

    private int decodeISO2022JP(byte[] bb, int off, int len, int nchar){
        int nch = 0;
        boolean crlf = false;
        if (nchar < 0){          // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int save = 0;
        int i;
        /*
        Trc.out.println("deco: start " + this.shiftState + " " +
            off + " " + len + " " + nchar);
            for (int j = 0; j < bb.length; j++){
                Trc.out.print(" 0x" +
                    Integer.toHexString(bb[j] & 0xff));
            }
            Trc.out.println();
        */
        scan: for (i = off; i < off+len; i++){
            int b = bb[i] & 0xff;
            /*
            Trc.out.println("deco: " + this.shiftState + " " + i +
                " " + Integer.toHexString(b));
            */
            if (b > 127){
                this.malformed = true;
                break scan;
            }
            seq: switch (b){
            case ESC:                                // ESC
                if (i+2 >= off+len){
                    this.incomplete = true;
                    break scan;
                }
                b = bb[i+1] & 0xff;
                if (b > 127){
                    this.malformed = true;
                    break scan;
                }
                if (b == 40){                        // (
                    b = bb[i+2] & 0xff;
                    switch (b){
                    case 66: this.shiftState = 0; break;  // B
                    case 73: this.shiftState = 4; break;  // I
                    case 74: this.shiftState = 1; break;  // J
                    default:
                        this.malformed = true;
                        break scan;
                    }
                    i += 2;
                } else if (b == 36){                      // $
                    b = bb[i+2] & 0xff;
                    if (b > 127){
                        this.malformed = true;
                        break scan;
                    }
                    switch (b){
                    case 64: this.shiftState = 2; break;  // @
                    case 66: this.shiftState = 3; break;  // B
                    default:
                        this.malformed = true;
                        break scan;
                    }
                    i += 2;
                } else {
                    this.malformed = true;
                    break scan;
                }
                if (this.shiftState == 0){      // lock-shift delivery
                    if (nch >= nchar){
                        i++;
                        break scan;
                    }
                }
                continue;
            case SO:                            // SO
                save = this.shiftState;
                this.shiftState = 5;
                continue;
            case SI:                            // SI
                this.shiftState = save;
                if (this.shiftState == 0){      // lock-shift delivery
                    if (nch >= nchar){
                        i++;
                        break scan;
                    }
                }
                continue;
            }
            if (nch >= nchar) break scan;       // zero char requested
            switch (this.shiftState){
            case 0:                             // ASCII
            case 1:                             // JIS 201
                if (crlf){
                    if (b == lf){               // detect end-of-line
                        i++;
                        nch++;
                        break scan;
                    } else if (b == cr){
                        i++;
                        nch++;
                        if (i >= off+len) break scan;
                        b = bb[i] & 0xff;
                        if (b == lf){
                            i++;
                            nch++;
                        }
                        break scan;
                    }
                }
                break;
            case 2: case 3:                     // JIS 208
                if (i+1 >= off+len){
                    this.incomplete = true;
                    break scan;
                }
                b = bb[i+1] & 0xff;
                if (b > 127){
                    this.malformed = true;
                    break scan;
                }
                i++;
                break;
            case 4: case 5:                     // JIS 212
                if (b > 96){
                    this.malformed = true;
                    break scan;
                }
                break;
            }
            if (++nch >= nchar){
                i++;
                break scan;
            }
        }
        this.byteIndex = i;
        /*
        Trc.out.println("deco: end " + this.shiftState + " " + i);
        */
        return nch;
    }

    /**
     * Decode ISO2022-KR encoding.
     *
     * @see        #decodeOneByte(byte[],int,int,int,byte[])
     */

    private int decodeISO2022KR(byte[] bb, int off, int len, int nchar){
        int nch = 0;
        boolean crlf = false;
        if (nchar < 0){          // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int i;
        scan: for (i = off; i < off+len; i++){
            int b = bb[i] & 0xff;
            switch (b){
            case SO:                        // SO
                this.shiftState = 1;
                continue;
            case SI:                        // SI
                this.shiftState = 0;
                continue;
            case ESC:                       // ESC
                if (i+3 >= off+len){
                    this.incomplete = true;
                    break scan;  // no next three bytes
                }
                b = bb[i+1] & 0xff;
                if (b != '$'){
                    this.malformed = true;
                    break scan;
                }
                b = bb[i+2] & 0xff;
                if (b != ')'){
                    this.malformed = true;
                    break scan;
                }
                b = bb[i+3] & 0xff;
                if (b == 'C'){              // S0 designator
                    i += 3;
                    continue;
                }
                this.malformed = true;
                break scan;
            }
            if (this.shiftState == 0){      // ASCII
                if (crlf){
                    if (b == lf){           // detect end-of-line
                        i++;
                        nch++;
                        break scan;
                    } else if (b == cr){
                        i++;
                        nch++;
                        if (i >= off+len) break scan;
                        b = bb[i] & 0xff;
                        if (b == lf){
                            i++;
                            nch++;
                        }
                        break scan;
                    }
                }
                if (++nch >= nchar){
                    i++;
                    break scan;
                }
            } else {                        // GB, CNS
                if (i+1 >= off+len){
                    this.incomplete = true;
                    break scan;
                }
                i++;
                if (++nch >= nchar){
                    i++;
                    break scan;
                }
            }
        }
        this.byteIndex = i;
        return nch;
    }

    /**
     * Decode Shift-Jis encoding.
     *
     * @see        #decodeOneByte(byte[],int,int,int,byte[])
     */

    private int decodeSJIS(byte[] bb, int off, int len, int nchar){
        int nch = 0;
        boolean crlf = false;
        if (nchar < 0){          // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int i;
        scan: for (i = off; i < off+len; i++){
            int b = bb[i] & 0xff;
            if ((0x81 <= b && b <= 0x9F) ||
                (0xE0 <= b && b <= 0xEF)){
                if (i+1 >= off+len){           // no second byte
                    this.malformed = true;
                    break;
                }
                i++;
            } else {                           // two bytes
                if (crlf){
                    if (b == lf){              // detect end-of-line
                        i++;
                        nch++;
                        break scan;
                    } else if (b == cr){
                        i++;
                        nch++;
                        if (i >= off+len) break scan;
                        b = bb[i] & 0xff;
                        if (b == lf){
                            i++;
                            nch++;
                        }
                        break scan;
                    }
                }
            }
            if (++nch >= nchar){
                i++;
                break scan;
            }
        }
        this.byteIndex = i;
        return nch;
    }

    /**
     * Decode UTF-8 encoding. Since characters are represented in Java
     * in UCS-2, the length of UTF-8 sequences is limited to 3.
     * FSS_UTF is also decoded.
     * 
     *
     * @see        #decodeOneByte(byte[],int,int,int,byte[])
     */

    private int decodeUTF8(byte[] bb, int off, int len, int nchar){
        int nch = 0;
        boolean crlf = false;
        if (nchar < 0){                       // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int i;
        scan: for (i = off; i < off+len; i++){
            int b = bb[i] & 0xff;
            if ((b & 0x80) == 0){             // one byte
                if (crlf){
                    if (b == lf){             // detect end-of-line
                        i++;
                        nch++;
                        break scan;
                    } else if (b == cr){
                        i++;
                        nch++;
                        if (i >= off+len) break scan;
                        b = bb[i] & 0xff;
                        if (b == lf){
                            i++;
                            nch++;
                        }
                        break scan;
                    }
                }
            } else if ((b & 0xe0) == 0xc0){   // two bytes
                if (i+1 >= off+len){          // not enough available
                    this.incomplete = true;
                    break;
                }
                b = bb[i+1] & 0xff;
                if ((b & 0xc0) != 0x80){
                    this.malformed = true;
                    break scan;
                }
                i++;
            } else if ((b & 0xf0) == 0xe0){   // three bytes
                if (i+2 >= off+len){
                    this.incomplete = true;
                    break;    // not enough available
                }
                b = bb[i+1] & 0xff;
                if ((b & 0xc0) != 0x80){
                    this.malformed = true;
                    break scan;
                }
                b = bb[i+2] & 0xff;
                if ((b & 0xc0) != 0x80){
                    this.malformed = true;
                    break scan;
                }
                i += 2;
            } else {
                break scan;
            }
            if (++nch >= nchar){
                i++;
                break scan;
            }
        }
        this.byteIndex = i;
        return nch;
    }

    /**
     * Decode UCS-2 encoding. In the case of autodetect, the first two
     * bytes decoded from the time this decoder was created must be a
     * byte order mark. Otherwise they must either be equal to the
     * requested byte ordering, or be different from a byte order mark.
     * The field <code>endian</code> represents the byte ordering.
     * 
     * @see        #decodeOneByte(byte[],int,int,int,byte[])
     * @param      order byte order mark: 0 autodetect, FEFF big, FFFE little
     */

    private int decodeUnicode(byte[] bb, int off, int len,
        char order, int nchar){
        boolean crlf = false;
        if (nchar < 0){          // stop at line terminators
            nchar = Integer.MAX_VALUE;
            crlf = true;
        }
        int nch = 0;
        int i = off;
        if (this.endian == 0){                      // conversion not yet started
            if (i+1 >= off+len){
                this.incomplete = true;
                return 0;
            }
            char fileOrder =
                (char)((bb[i] & 0xff) << 8 | (bb[i+1] & 0xff));
            if ((fileOrder != '\uFEFF') &&
                (fileOrder != '\uFFFE')){
                fileOrder = '\u0000';
            }
            if (order == 0){                        // no ordering requested
                if (fileOrder == 0){                // none specified
                    this.malformed = true;
                    return 0;
                }
                i += 2;
                order = fileOrder;
            } else if (fileOrder != '\u0000'){      // mark present in file
                if (fileOrder != order){            // different
                    this.malformed = true;
                    return 0;
                }
                i += 2;
            }
            this.endian = order;
        }
        scan: for (; i < off+len; i++){
            int b = bb[i] & 0xff;
            if (i+1 >= off+len){
                this.incomplete = true;
                break scan;
            }
            int c = bb[i+1] & 0xff;
            char ch;
            if (this.endian == '\uFEFF'){           // higher first
                ch = (char)(b << 8 | c);
            } else {
                ch = (char)(c << 8 | b);
            }
            if (ch == '\uFFFE'){
                // this.malformed = true;           // no longer considered malformed
                // break scan;                      // byte order mark
            }
            if (crlf){
                if (ch == '\n'){                    // detect end-of-line
                    i += 2;
                    nch++;
                    break scan;
                } else if (ch == '\r'){
                    i += 2;
                    nch++;
                    if (i+1 >= off+len){
                        this.incomplete = true;
                        break scan;
                    }
                    b = bb[i] & 0xff;
                    c = bb[i+1] & 0xff;
                    if (this.endian == '\uFEFF'){   // higher first
                        ch = (char)(b << 8 | c);
                    } else {
                        ch = (char)(c << 8 | b);
                    }
                    if (ch == '\n'){
                        i += 2;
                        nch++;
                    }
                    break scan;
                }
            }
            i++;
            if (++nch >= nchar){
                i++;
                break scan;
            }
        }
        this.byteIndex = i;
        return nch;
    }
}
