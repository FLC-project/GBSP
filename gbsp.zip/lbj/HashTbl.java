/*
 * @(#)HashTbl.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;
import java.text.*;
import java.io.*;
import java.lang.reflect.*;
import java.lang.ref.*;
import lbj.Str;

/**
 * The <code>HashTbl</code> class provides hash tables with embedded
 * character string keys.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

/**
 * This class provides:
 * <ul>
 * <li>the same features as <code>HashBag</code>,
 * <li>specialization for <code>char[]</code> keys, for which it is
 *   two times faster in insertion, and five times faster in sorting
 *   than <code>HashMap</code>.
 * <li>a further specialization for <code>char[]</code> keys, handled
 *   in a case-insensitive way.
 * </ul>
 * The class can be further specialized, e.g. to support multiple keys.
 * Together with this class, a class <code>HashChars</code> is provided,
 * which is meant to be the superclass of elements, to be extended by
 * the classes using hash tables.
 * <code>HashChars</code> objects can also be used in other collections,
 * in particular in the ordered ones, and also in the ones which can
 * be ordered by <code>Collections</code> and <code>Arrays</code> methods.
 * The natural ordering for them is: null, the empty array, etc.
 */

/*
 * There is no method to create an hash table with the contents of a
 * collection because that can be obtained with Collection.addAll().
 *
 * A specialized version of search() and remove() is provided which takes
 * a code as argument. This makes HashTbl similar to HashMap.
 * To support it when HashChars is redefined and equals() is also
 * redefined, there is a need to keep a reference to an element which
 * can be used as vehicle to call the (possibly redefined) methods.
 * When the table is empty, then search deliver false, and no such element
 * is needed.
 */

public class HashTbl extends HashBag implements Serializable {

    /** SUID form JDK 1.2 */
    private static final long serialVersionUID = 6698633173975556219L;;

    /**
     * Construct a new <code>HashTbl</code> with a directory of a
     * default capacity.
     */

    public HashTbl(){
        super();
    }

    /**
     * Construct a new <code>HashTbl</code> with a directory of a
     * given capacity.
     *
     * @param   c capacity
     */

    public HashTbl(int c){
        super(c);
    }

    /**
     * Construct a new <code>HashTbl</code> with a directory of a
     * given capacity and a specified load factor.
     *
     * @param   c capacity
     * @param   l load factor
     */

    public HashTbl(int c, float l){
        super(c,l);
    }

    /**
     * The prototype of hash table elements.
     */

    public static class HashChars extends HashNode
        implements Serializable, Comparable {

        /** SUID form JDK 1.2 */
        private static final long serialVersionUID = -3511967837143981100L;

        /**
         * The code. It holds the name string associated to the node.
         *
         * @serial
         */
        public char[] code;

        /**
         * Construct an object with a null code.
         */

        public HashChars(){
            this.code = null;
        }

        /**
         * Construct an object with the specified code.
         *
         * @param   c code
         */

        public HashChars(char[] c){
            this.code = c;
        }

        /**
         * Deliver a String representation of this object.
         *
         * @return  string
         */

        public String toString(){
            return String.valueOf(this.code);
        }

        /**
         * Deliver the lenght of the String representation of this object.
         *
         * @return  length
         */

        public int toStringLength(){
            if (this.code == null) return 0;
            return this.code.length;
        }

        /**
         * Determine if this object is equal to the specified object.
         * It delivers <code>true</code> when the argument is not
         * <code>null</code> and is a <code>HashChars</code> object that
         * contains the same characters.
         *
         * @param   other the object to compare
         * @return  true if equal
         */

        public boolean equals(Object other){
            if (this == other) return true;
            if (other == null) return false;
            if (!(other instanceof HashChars)) return false;
            HashChars s = (HashChars)other;
            if (this.code == s.code) return true;
            if ((this.code == null) || (s.code == null)) return false;
            if (this.code.length != s.code.length) return false;
            for (int i = 0; i < this.code.length; i++){
                if (this.code[i] != s.code[i]){
                    return false;
                }
            }
            return true;
        }

        /**
         * Determine if this object is equal to the specified slice of
         * string. No checks are done on the arguments, which must denote
         * an existing slice.
         *
         * @param   buf string
         * @param   off offset
         * @param   len lenght
         */

        public boolean equals(char[] buf, int off, int len){
            char[] t = this.code;
            cmp: {
                if (buf == t){
                    if (buf == null) return true;
                    if ((off == 0) && (len == buf.length)){
                        return true;             // same object
                    }
                }
                if ((buf == null) || (t == null)) break cmp;
                int lt = t.length;
                if (lt != len) break cmp;
                int i = off+len;
                while (--lt >= 0){
                    if (t[lt] != buf[--i]) break cmp;
                }
                return true;                      // same code: found
            }
            return false;
        }

        /**
         * Return the hashcode for this object.
         *
         * @return  hash code value
         */

        /* The hash function used uses all the values of the string
         * because for large tables taking less values lead to long
         * chains even if the directory is large enough.
         */

        public int hashCode(){
            if (this.code == null) return 0;
            int h = 0;
            char[] buf = this.code;
            int len = buf.length;
            if (len > 0){
                //h = buf[0] + buf[len >> 1] +  // simplified hash
                //  buf[len - 1] + len;
                for (int i = 0; i < len; i++){  // String hash
                    h = 31*h + buf[i];
                }
            }
            return h;
        }

        /**
         * Return the hash value for a string. No checks are done on the
         * arguments, which must denote an existing slice.
         *
         * @param   buf string
         * @param   off start offset in it
         * @param   len string length
         * @return  hash code value
         */

        public int hashCode(char[] buf, int off, int len){
            if (buf == null) return 0;
            int h = 0;
            if (len > 0){
                //h = buf[off] + buf[off + (len >> 1)] + // simplified hash
                //   buf[off + len - 1] + len;
                for (int i = off; i < off+len; i++){     // String hash
                    h = 31*h + buf[i];
                }
            }
            return h;
        }

        /**
         * Compare lexicographically this object with the specified object.
         *
         * @param   other the object to compare
         * @return  &lt; = or &gt; 0 if this object precedes, is equal or
         *          follows the other.
         */

        public int compareTo(Object other){
            if (other == null) return 1;
            char[] s = ((HashChars)other).code;
            int ls = (s == null) ? 0 : s.length;
            char[] t = this.code;
            int lt = (t == null) ? 0 : t.length;
            int n = (ls > lt) ? lt : ls;
            int i = 0;
            int j = 0;
            while (n-- > 0) {
                char c1 = t[i++];
                char c2 = s[j++];
                if (c1 != c2) return c1 - c2;
            }
            return lt - ls;
        }
    }

    public static class HashNoCaseChars extends HashChars {

        /** SUID form JDK 1.2 */
        private static final long serialVersionUID = -393058719666816164L;

        /**
         * Construct an object with a null code.
         */

        public HashNoCaseChars(){
            this.code = null;
        }

        /**
         * Construct an object with the specified code.
         *
         * @param   c code
         */

        public HashNoCaseChars(char[] c){
            this.code = c;
        }

        /**
         * Determine if this object is equal to the specified object.
         * Characters are compared in a case-insensitive way.
         *
         *
         * @param   other the object to compare
         * @return  true if equal
         */

        public boolean equals(Object other){
            if (this == other) return true;
            if (other == null) return false;
            if (!(other instanceof HashChars)) return false;
            HashChars s = (HashChars)other;
            if (this.code == s.code) return true;
            if ((this.code == null) || (s.code == null)) return false;
            if (this.code.length != s.code.length) return false;
            for (int i = 0; i < this.code.length; i++){
                char c1 = this.code[i];
                char c2 = s.code[i];
                if (c1 == c2) continue;
                c1 = (c1 < 128) ? Str.UPPER[c1] :
                    Character.toUpperCase(c1);
                c2 = (c2 < 128) ? Str.UPPER[c2] :
                    Character.toUpperCase(c2);
                if (c1 == c2) continue;
                c1 = (c1 < 128) ? Str.LOWER[c1] :
                    Character.toLowerCase(c1);
                c2 = (c2 < 128) ? Str.LOWER[c2] :
                    Character.toLowerCase(c2);
                if (c1 != c2) return false;      // for Georgian
            }
            return true;
        }

        /**
         * Determine if this object is equal to the specified slice of
         * string. No checks are done on the arguments, which must denote
         * an existing slice.
         * Characters are compared in a case-insensitive way.
         *
         * @param   buf string
         * @param   off offset
         * @param   len lenght
         */

        public boolean equals(char[] buf, int off, int len){
            char[] t = this.code;
            cmp: {
                if (buf == t){
                    if (buf == null) return true;
                    if ((off == 0) && (len == buf.length)){
                        return true;              // same object
                    }
                }
                if ((buf == null) || (t == null)) break cmp;
                int lt = t.length;
                if (lt != len) break cmp;
                int i = off + lt;
                while (--lt >= 0){
                    char c1 = t[lt];
                    char c2 = buf[--i];
                    if (c1 == c2) continue;
                    c1 = (c1 < 128) ? Str.UPPER[c1] :
                        Character.toUpperCase(c1);
                    c2 = (c2 < 128) ? Str.UPPER[c2] :
                        Character.toUpperCase(c2);
                    if (c1 == c2) continue;
                    c1 = (c1 < 128) ? Str.LOWER[c1] :
                        Character.toLowerCase(c1);
                    c2 = (c2 < 128) ? Str.LOWER[c2] :
                        Character.toLowerCase(c2);
                    if (c1 != c2) break cmp;      // for Georgian
                }
                return true;                      // same code: found
            }
            return false;
        }

        /**
         * Return the hashcode for this string.
         *
         * @return  hash code value
         */

        public int hashCode(){
            char[] buf = this.code;
            if (buf == null) return 0;
            int h = 0;
            //for (int i = 0; i < this.code.length; i++){
            //    char c = buf[i];
            //    c = (c < 128) ? Str.UPPER[c] :
            //        Character.toUpperCase(c);
            //    c = (c < 128) ? Str.LOWER[c] :
            //        Character.toLowerCase(c);
            //    h = 31*h + c;
            //}
            int len = this.code.length;                // simplified hash
            if (len > 0){
                char c1 = buf[0];
                c1 = (c1 < 128) ? Str.UPPER[c1] :
                    Character.toUpperCase(c1);
                c1 = (c1 < 128) ? Str.LOWER[c1] :
                    Character.toLowerCase(c1);
                char c2 = buf[len >> 1];
                c2 = (c2 < 128) ? Str.UPPER[c2] :
                    Character.toUpperCase(c2);
                c2 = (c2 < 128) ? Str.LOWER[c2] :
                    Character.toLowerCase(c2);
                char c3 = buf[len - 1];
                c3 = (c3 < 128) ? Str.UPPER[c3] :
                    Character.toUpperCase(c3);
                c3 = (c3 < 128) ? Str.LOWER[c3] :
                    Character.toLowerCase(c3);
                h = c1 + c2 + c3 + len;
            }
            return h;
        }

        /**
         * Return the hash value for a string. No checks are done on the
         * arguments, which must denote an existing slice.
         *
         * @param   buf string
         * @param   off start offset in it
         * @param   len string length
         * @return  hash code value
         */

        public int hashCode(char[] buf, int off, int len){
            if (buf == null) return 0;
            int h = 0;
            //for (int i = off; i < off+len; i++){
            //    char c = buf[i];
            //    c = (c < 128) ? Str.UPPER[c] :
            //        Character.toUpperCase(c);
            //    h = 31*h + c;
            //}
            if (len > 0){
                char c1 = buf[off];
                c1 = (c1 < 128) ? Str.UPPER[c1] :
                    Character.toUpperCase(c1);
                c1 = (c1 < 128) ? Str.LOWER[c1] :
                    Character.toLowerCase(c1);
                char c2 = buf[off + (len >> 1)];
                c2 = (c2 < 128) ? Str.UPPER[c2] :
                    Character.toUpperCase(c2);
                c2 = (c2 < 128) ? Str.LOWER[c2] :
                    Character.toLowerCase(c2);
                char c3 = buf[off + len - 1];
                c3 = (c3 < 128) ? Str.UPPER[c3] :
                    Character.toUpperCase(c3);
                c3 = (c3 < 128) ? Str.LOWER[c3] :
                    Character.toLowerCase(c3);
                h = c1 + c2 + c3 + len;
            }
            return h;
        }
    }

    /**
     * Search an element with a given code. No checks are done on the
     * arguments, which must denote an existing slice.
     *
     * @param   buf string
     * @param   off start offset in it
     * @param   len string length
     * @return  reference to the element, <code>null</code> if not found
     */

    public HashChars search(char[] buf, int off, int len){
        if (this.elemNr == 0) return null;
        int hvalue = (((HashChars)this.elementNode)
            .hashCode(buf,off,len) & 0x7FFFFFFF)
            % this.hdir.length;
        HashNode pr = null;
        HashNode e = null;
        sea: for (e = this.hdir[hvalue];
            e != null; e = e.hlink){              // scan the chain
            if (((HashChars)e).equals(buf,off,len)) break sea;
            pr = e;
        }
        this.lastList = pr;
        this.lastChain = hvalue;
        return (HashChars)e;
    }

    /**
     * Determine the index of the hash chain for a given code.
     * It serves to simplify the specialization of the <code>seach()</code>
     * method.
     *
     * @param   buf string
     * @param   off start offset in it
     * @param   len string length
     * @return  index
     */

    public int hashValue(char[] buf, int off, int len){
        return (((HashChars)this.elementNode)
            .hashCode(buf,off,len) & 0x7FFFFFFF)
            % this.hdir.length;
    }

    /**
     * Complete the specialization of a <code>seach()</code> method.
     *
     * @param   pr reference to the element which is previous to the one found
     * @param   hvalue index of hash chain
     */

    public void hashLast(HashNode pr, int hvalue){
        this.lastList = pr;
        this.lastChain = hvalue;
    }

    /**
     * Search an element with a given code.
     *
     * @param   s code
     * @return  reference to the element, <code>null</code> if not found
     */

    public HashChars search(char[] s){
        return search(s,0,(s == null) ? 0 : s.length);
    }

    /**
     * Remove an element with a given code. No checks are done on the
     * arguments, which must denote an existing slice.
     *
     * @param   buf string
     * @param   off start offset in it
     * @param   len string length
     * @return  <code>true</code> if the element was present
     */

    public boolean remove(char[] buf, int off, int len){
        HashNode e = search(buf,off,len);
        if (e == null){                         // not present
            return false;
        } else {
            if (this.lastList == null){
                this.hdir[this.lastChain] = e.hlink;
            } else {
                this.lastList.hlink = e.hlink;
            }
        }
        this.elemNr--;
        updateModCount();                       // table changed
        return true;
    }

    /**
     * Remove an element with a given code.
     *
     * @param   s code
     * @return  <code>true</code> if the element was present
     */

    public boolean remove(char[] s){
        HashNode e = search(s);
        if (e == null){                         // not present
            return false;
        } else {
            if (this.lastList == null){
                this.hdir[this.lastChain] = e.hlink;
            } else {
                this.lastList.hlink = e.hlink;
            }
        }
        this.elemNr--;
        updateModCount();                       // table changed
        return true;
    }

    /**
     * Sort the specified list of elements.
     * 
     * @param   el list
     * @param   num number of elements to sort
     */

    protected HashNode mergeSort(HashNode el, int num){
        if (num <= 7){                         // short list
            if ((FL_C & this.trc) != 0){
                Trc.out.println("mergesort: short " + num);
            }
            HashNode head = null;              // destination list
            this.lastList = null;
            HashNode cptr = el;
            while (num-- > 0){
                char[] s = ((HashChars)cptr).code;
                int slen = (s == null) ? 0 : s.length;
                this.nextList = cptr.hlink;    // save pointer to next
                                               // insert
                HashNode l = null;             // pointer to previous
                HashNode p = head;             // pointer to current
                seek: while (p != null){       // search insertion place
                    char[] ps = ((HashChars)p).code;
                    int plen = (ps == null) ? 0 : ps.length;
                    int n = (plen > slen) ? slen : plen;
                    cmp: {
                        int i = 0;
                        int j = 0;
                        while (n-- != 0) {
                            char c1 = ps[i++];
                            char c2 = s[j++];
                            if (c1 != c2){
                                if (c1 > c2) break seek;
                                else break cmp;
                            }
                        }
                        if (plen > slen) break seek;
                    }
                    l = p;                     // pointer to previous
                    p = p.hlink;               // step to next
                }
                if (l == null){                // insert on top
                    cptr.hlink = head;
                    head = cptr;
                } else {                       // insert in the middle
                    cptr.hlink = p;
                    l.hlink = cptr;
                }
                if (cptr.hlink == null){       // last in the list
                    this.lastList = cptr;
                }
                cptr = this.nextList;          // step to next
            }
            return head;
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("mergesort: " + num);
        }
        int mid = num / 2;
        HashNode up = mergeSort(el,mid);       // sort first half
        HashNode last = this.lastList;         // last in sorted list
        el = this.nextList;                    // head of unsorted list
        int high = num - mid;
        HashNode down = mergeSort(el,high);    // sort second half
        mrg: {
            char[] s = ((HashChars)down).code;   // compare elements
            int ls = (s == null) ? 0 : s.length;
            char[] t = ((HashChars)last).code;
            int lt = (t == null) ? 0 : t.length;
            int n = (ls > lt) ? lt : ls;
            cmp: {
                int i = 0;
                int j = 0;
                while (n-- != 0) {
                    char c1 = t[i++];
                    char c2 = s[j++];
                    if (c1 != c2){
                        if (c1 > c2) break mrg;    // last > down
                        else break cmp;
                    }
                }
                if (lt > ls) break mrg;
            }
            last.hlink = down;
            if ((FL_C & this.trc) != 0){
               Trc.out.println("mergesort: no merge");
            }
            return up;
        }
        if ((FL_C & this.trc) != 0){
           Trc.out.println("mergesort: merge");
        }
        HashNode head = null;                  // merge the two sorted
        HashNode cur = null;                   // .. halves
        for (int k = 0; k < num; k++){
            boolean first = (down == null);    // no more elements down
            tst: if (!first){                  // some elements down
                if (up == null) break tst;     // no elements up
                char[] s = ((HashChars)down).code;   // compare elements
                int ls = (s == null) ? 0 : s.length;
                char[] t = ((HashChars)up).code;
                int lt = (t == null) ? 0 : t.length;
                int n = (ls > lt) ? lt : ls;
                cmp: {
                    int i = 0;
                    int j = 0;
                    while (n-- != 0) {
                        char c1 = t[i++];
                        char c2 = s[j++];
                        if (c1 != c2){
                            if (c1 > c2) break tst;
                            else break cmp;
                        }
                    }
                    if (lt > ls) break tst;
                }
                first = true;                  // take from first half
            }
            if (first){
                if (cur == null) head = up;
                else cur.hlink = up;
                cur = up;
                up = up.hlink;
            } else {                           // take from second half
                if (cur == null) head = down;
                else cur.hlink = down;
                cur = down;
                down = down.hlink;
            }
        }
        this.lastList = cur;
        cur.hlink = null;
        return head;
    }

    /**
     * Sort this table with a Collator. The table is then left empty.
     * 
     * @param   coll the collator
     * @return  a reference to the sorted list
     */

    /*
     * To make sorting reasonably fast, collating keys are generated,
     * and then sorted. As they are provided in java.text, they work
     * only on Strings and allow only to retrieve a reference to the
     * origin String. This is useless to sort objects in general.
     * Thus, wrapper objects are used that hold the keys and references
     * to the hash table elements.
     */

    public HashChars sort(Collator coll){
        KeyRef[] keys = new KeyRef[this.elemNr];
        int k = 0;
        int max = 0;                             // initialize max length
        HashNode head = null;
        HashNode cur = null;
        int len = this.hdir.length;
        for (int row = 0; row < len; row++){     // scan all chains
            for (HashNode e = this.hdir[row];
                e != null; e = e.hlink){         // scan the chain
                if (cur == null){                // first enqueued
                    cur = e;
                    head = e;
                } else {                         // append
                    cur.hlink = e;
                }
                cur = e;                         // new last
                int slen = e.toStringLength();
                if (max < slen) max = slen;
                HashChars h = (HashChars)e;
                KeyRef kr = new KeyRef();
                String cod = "";
                if (h.code != null) cod = String.valueOf(h.code);
                kr.key = coll.getCollationKey(cod);
                kr.node = e;
                keys[k++] = kr;
            }
            this.hdir[row] = null;               // clear directory
        }
        this.maxcode = max;
        Arrays.sort(keys);
        head = null;
        for (int i = keys.length; --i >= 0;){
            keys[i].node.hlink = head;
            head = keys[i].node;
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("sorted:");
            traceList(head);
        }
        this.elemNr = 0;
        updateModCount();                        // table changed
        return (HashChars)head;
    }

    /** Wrapper objects to hold collating keys. */

    private static class KeyRef implements Comparable {

        /** The collating key. */
        private CollationKey key;

        /** The reference to the origin element. */
        private HashNode node;

        /**
         * Compare the collating key of this object with that of
         * the specified one.
         * 
         * @param   other other object
         */

        public int compareTo(Object other){
            return this.key.compareTo(((KeyRef)other).key);
        }
    }
}
