/*
 * @(#)Str.java       1.0 98/11/04
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;

/**
 * The <code>Str</code> class provides efficient strings.
 *
 * @author  Angelo Borsotti
 * @version 1.0   04 Nov 1998
 */

/**
 * For an array (and a string), a start index denotes its start character,
 * an end index could denote either its last character, or the last+1
 * character:
 * <ol>
 * <li>last: this solution allows to have strings whose length is the
 *   whole span of integers. On the other hand, to denote an empty string
 *   there is a need to have an end index which is lower than the start
 *   index. Moerover, lenght = end - last + 1.
 * <li>last + 1: this allows to compute lenght as end - start, and to denote
 *   empty strings with end = start. It is more uniform even if it allows
 *   to have strings long only 2**n-1. This, however, is not much of a
 *   problem because the range of integers is so large not to cause
 *   restrictions in all practical cases. Moreover, in Java it is not
 *   possible to create a char[] or a String whose size is 2**n because
 *   an integer value must be passed, which is at most 2**n-1.
 * </ol>
 * The latter is used in this class when end indexes are needed.
 * When using indexes, both the arithmetic and the allocation must be checked:
 * an array length is at max Integer.MAX_VALUE (let it be M).
 * An index also. However, a[M] would denote an element of an array
 * long M+1, which may not be created. Thus, the M-th element may not
 * exist, which means that the last possible element has index M-1, but also
 * that it is possible to use the whole span of positive integers to
 * denote indexes, including the last+1 and thus to perform arithmetic.
 * If it were possible to have arrays of length M, the last+1 index would
 * not be representable by an integer, which makes arithmetic of indexes
 * difficult.
 * <p>
 * A class for managing strings is difficult to fit all needs.
 * E.g. there are cases in which the buffer and a current index is already
 * there, and needs be manipulated. In such cases it is difficult to
 * allocate a new object to mirror it so as to manipulate it.
 * Thus this class contains static methods to operate on arrays of characters
 * in general, as well as the specialised versions to operate on its objects.
 * <p>
 * The class gives access to the internal fields so as to allow to
 * read/write elements efficiently, and to implement efficiently extra
 * methods not contained here.
 * <p>
 * The methods accept in general String, char[], and Str arguments.
 * <p>
 * The convention to denote slices is that defined for <code>substring()</code>.
 * <p>
 * Str can be used as superclass for other classes which can add
 * a current index (cursor) and a maximum cursor.
 * It contains a <code>length</code> field which denotes the length
 * of the significant part, which can be smaller than the space present
 * in the buffer.
 * <p>
 * Note that not all possible combinations of assignment, append, cut,
 * etc. are provided. They are special cases of <code>cutInsert()</code>.
 * <p>
 * Note also that a common problem for all classes which implement strings
 * apart from the predefined Java String is that there are no literals
 * for constant values. I.e. objects which are created automatically
 * before execution by statements inserted by the compiler, and for which
 * the uniqueness of the pointer is guaranteed so as to use "=" to
 * compare them efficiently. Note that <code>new Str("xxx")</code> is no
 * replacement for a literal since it creates a string each time it
 * is executed.
 */

public class Str implements Serializable, Cloneable, Comparable<Object> {

    /**
     * The length of the string.
     *
     * @serial
     */
    public int length;

    /**
     * The buffer to hold the characters.
     *
     * @serial
     */
    public char[] buffer;

    /** SUID form JDK 1.2 */
    private static final long serialVersionUID = -2558971311066768355L;

    /** The empty character array constant. */
    public static final char[] EMPTY_CHARS = new char[0];

    /** The empty string constant. */
    public static final Str EMPTY = new Str();

    /**
     * Construct a new <code>Str</code> with an empty string in it.
     */

    public Str(){
        this.buffer = EMPTY_CHARS;
    }

    /**
     * Construct a new <code>Str</code> with an empty string in it
     * and with the given initial capacity.
     *
     * @param      c capacity
     */

    public Str(int c){
        this.buffer = new char[c];
    }

    /**
     * Construct a new <code>Str</code> with a string in it.
     *
     * @param      t string
     */

    public Str(String t){
        if (t != null){
            int l = t.length();
            this.buffer = new char[l];
            t.getChars(0,l,this.buffer,0);
            this.length = l;
        } else {
            this.buffer = EMPTY_CHARS;
        }
    }

    /**
     * Clone this object.
     *
     * @return     a copy of the object
     */

    public Object clone(){
        Str t = null;
        try {
            t = (Str)super.clone();
            t.buffer = (char[])this.buffer.clone();
        } catch (CloneNotSupportedException e){
        }
        return t;
    }

    /**
     * Determine if this string is equal to the specified object.
     * It delivers <code>true</code> when the argument is not
     * <code>null</code> and is a <code>Str</code> object that contains
     * the same characters.
     *
     * @param   other the object to compare
     * @return  true if equal
     */

    public boolean equals(Object other){
        if (this == other) return true;
        if (other == null) return false;
        if (!(other instanceof Str)) return false;
        Str s = (Str)other;
        if (this.length != s.length) return false;
        for (int i = 0; i < this.length; i++){
            if (this.buffer[i] != s.buffer[i]){
                return false;
            }
        }
        return true;
    }

    /**
     * Determine if this string is equal to the specified string.
     * It delivers <code>true</code> when the argument is not 
     * <code>null</code> and is a <code>Str</code> object that contains
     * the same characters.
     *
     * @param   t2 the string to compare
     * @return  true if equal
     */

    public boolean equals(Str t2){
        if (this == t2) return true;
        if (t2 == null) return false;
        if (this.length != t2.length) return false;
        for (int i = 0; i < this.length; i++){
            if (this.buffer[i] != t2.buffer[i]){
                return false;
            }
        }
        return true;
    }

    /**
     * Determine if this string is equal to the specified string.
     * It delivers <code>true</code> when the argument is not 
     * <code>null</code> and is a <code>String</code> object that contains
     * the same characters.
     *
     * @param   t2 the string to compare
     * @return  true if equal
     */

    public boolean equals(String t2){
        if (t2 == null) return false;
        if (this.length != t2.length()) return false;
        for (int i = 0; i < this.length; i++){
            if (this.buffer[i] != t2.charAt(i)){
                return false;
            }
        }
        return true;
    }

    /**
     * Compare lexicographically this string with the specified object.
     *
     * @param   other the object to compare
     * @return  &lt; = or &gt; 0 if this string precedes, is equal or
     *          follows the other
     */

    public int compareTo(Object other){
        if (other == null) return 1;
        Str s = (Str)other;
        int n = this.length;
        if (s.length < n) n = s.length;
        char[] t1 = this.buffer;
        char[] t2 = s.buffer;
        int i = 0;
        int j = 0;
        while (n-- != 0){
            char c1 = t1[i++];
            char c2 = t2[j++];
            if (c1 != c2) return c1 - c2;
        }
        return this.length - s.length;
    }

    /**
     * Return the hashcode for this string. It delivers the same value
     * as that for Strings.
     *
     * @return     hash code value
     */

    public int hashCode(){
        int h = 0;
        //for (int i = 0; i < this.length; i++){      // String hash
        //    h = 31*h + this.buffer[i];
        //}
        int len = this.length;                        // simplified hash
        if (len > 0){
            h = this.buffer[0] + this.buffer[len >> 1] +
                this.buffer[len - 1] + len;
        }
        return h;
    }

    /**
     * Extend the buffer reaching the given capacity.
     *
     * @param      cap capacity
     */

    public void enlarge(int cap){
        if (cap < 0)
            throw new StringIndexOutOfBoundsException(cap);
        char[] cur = this.buffer;
        int curLen = (this.buffer == null) ? 0 : cur.length;
        if (curLen < cap){
            char[] p = new char[cap];
            if (cur != null)
                System.arraycopy(cur,0,p,0,curLen);
            this.buffer = p;
        }
    }

    /**
     * Extend the buffer by a default amount. The default amount
     * is 10 characters.
     */

    public void extend(){
        char[] cur = this.buffer;
        int curLen = (this.buffer == null) ? 0 : cur.length;
        int newlen = cur.length + 10;
        enlarge(newlen);
    }

    /**
     * Extend the buffer by a given amount.
     *
     * @param      extra amount
     */

    public void extend(int extra){
        char[] cur = this.buffer;
        int curLen = (this.buffer == null) ? 0 : cur.length;
        int newlen = cur.length + extra;
        enlarge(newlen);
    }

    /**
     * Deliver a String for the string contained in this object.
     *
     * @return     string
     */

    public String toString(){
        return String.valueOf(this.buffer,0,this.length);
    }

    /**
     * Deliver a char[] for the string contained in this object.
     *
     * @return     array
     */

    public char[] toCharArray(){
        char[] arr = new char[this.length];
        System.arraycopy(this.buffer,0,arr,0,this.length);
        return arr;
    }

    /**
     * Assign a string to this string.
     *
     * @param      t string
     * @return     this
     */

    public Str assign(String t){
        this.length = 0;
        return append(t);
    }

    /**
     * Assign a string to this string.
     *
     * @param      t string
     * @return     this
     */

    public Str assign(Str t){
        this.length = 0;
        return append(t);
    }

    /**
     * Assign a char[] to this string.
     *
     * @param      t char array
     * @return     this
     */

    public Str assign(char[] t){
        this.length = 0;
        return append(t);
    }

    /**
     * Append a character at the end of this string.
     *
     * @param      c character
     * @return     this
     */

    public Str append(char c){
        if (this.length == this.buffer.length){
            this.extend();
        }
        this.buffer[this.length++] = c;
        return this;
    }

    /**
     * Append a string at the end of this string.
     *
     * @param      t string
     * @return     this
     */

    public Str append(String t){
        if (t == null) return this;
        int l = t.length();
        int newlen = this.length + l;
        if (newlen < 0)
            throw new StringIndexOutOfBoundsException(newlen);
        if (newlen > this.buffer.length){
            this.enlarge(newlen);
        }
        t.getChars(0,l,this.buffer,this.length);
        this.length = newlen;
        return this;
    }

    /**
     * Append the specified slice of a string at the end of this string.
     *
     * @param      t string
     * @param      off offset in it
     * @param      len length
     * @return     this
     */

    public Str append(String t, int off, int len){
        if (t == null) return this;
        int l = t.length();
        if (len > l){
            throw new StringIndexOutOfBoundsException(len);
        }
        int newlen = this.length + len;
        if (newlen < 0)
            throw new StringIndexOutOfBoundsException(newlen);
        if (newlen > this.buffer.length){
            this.enlarge(newlen);
        }
        t.getChars(off,off+len,this.buffer,this.length);
        this.length = newlen;
        return this;
    }

    /**
     * Append a string at the end of this string.
     *
     * @param      t string
     * @return     this
     */

    public Str append(Str t){
        if (t == null) return this;
        int l = t.length;
        if (l == 0) return this;
        int newlen = this.length + l;
        if (newlen < 0)
            throw new StringIndexOutOfBoundsException(newlen);
        if (newlen > this.buffer.length){
            this.enlarge(newlen);
        }
        System.arraycopy(t.buffer,0,this.buffer,this.length,l);
        this.length = newlen;
        return this;
    }

    /**
     * Append a char[] at the end of this string.
     *
     * @param      t char array
     * @return     this
     */

    public Str append(char[] t){
        if (t == null) return this;
        int l = t.length;
        if (l == 0) return this;
        int newlen = this.length + l;
        if (newlen < 0)
            throw new StringIndexOutOfBoundsException(newlen);
        if (newlen > this.buffer.length){
            this.enlarge(newlen);
        }
        System.arraycopy(t,0,this.buffer,this.length,l);
        this.length = newlen;
        return this;
    }

    /**
     * Append a slice of a char[] at the end of this string.
     *
     * @param      t char array
     * @param      off offset in it
     * @param      len length
     * @return     this
     */

    public Str append(char[] t, int off, int len){
        if (t == null) return this;
        if (len == 0) return this;
        int newlen = this.length + len;
        if (newlen < 0)
            throw new StringIndexOutOfBoundsException(newlen);
        if (newlen > this.buffer.length){
            this.enlarge(newlen);
        }
        System.arraycopy(t,off,this.buffer,this.length,len);
        this.length = newlen;
        return this;
    }

    /**
     * Replace a substring in this string.
     *
     * @param      s1 start index of slice in t1
     * @param      l1 length of slice
     * @param      t2 second string
     * @param      e2 end of it
     * @param      s2 start index of slice in t2
     * @param      l2 length of slice
     * @return     this
     */

    public Str cutInsert(int s1, int l1, char[] t2, int e2, int s2, int l2){
        int e1 = this.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0; else if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        else if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;

        if (t2 == null) e2 = 0;
        else if (e2 > t2.length) e2 = t2.length;
        if (e2 < 0) e2 = 0;
        if (s2 < 0) s2 = 0; else if (s2 > e2) s2 = e2;
        if (l2 < 0) l2 = 0;
        if ((s2 + l2 < 0) || (s2 + l2 > e2)) l2 = e2 - s2;

        int newlen = l2 - l1 + this.length;
        if (newlen < 0)
            throw new StringIndexOutOfBoundsException(newlen);
        if (newlen > this.buffer.length){      // too small, allocate
            char[] cur = this.buffer;
            int curLen = (this.buffer == null) ? 0 : cur.length;
            char[] p = new char[newlen];
            if ((cur != null) && (s1 > 0)){    // optimized copy
                System.arraycopy(cur,0,p,0,s1);
            }
            if (s1 + l1 != e1){
                System.arraycopy(cur,s1+l1,
                    p,s1+l2,e1-s1-l1);
            }
            this.buffer = p;
        } else {
            if ((s1 + l1 != e1) && (l1 != l2)){
                System.arraycopy(this.buffer,s1+l1,
                    this.buffer,s1+l2,e1-s1-l1);
            }
        }
        this.length = newlen;
        if (l2 > 0){
            System.arraycopy(t2,s2,this.buffer,s1,l2);
        }
        return this;
    }

    /**
     * Replace a substring in this string.
     *
     * @see        #cutInsert(int,int,char[],int,int,int)
     */

    public Str cutInsert(int s1, int l1, String t2, int e2, int s2, int l2){
        int e1 = this.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0; else if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        else if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;

        if (t2 == null) e2 = 0;
        else if (e2 > t2.length()) e2 = t2.length();
        if (e2 < 0) e2 = 0;
        if (s2 < 0) s2 = 0; else if (s2 > e2) s2 = e2;
        if (l2 < 0) l2 = 0;
        if ((s2 + l2 < 0) || (s2 + l2 > e2)) l2 = e2 - s2;

        int newlen = l2 - l1 + this.length;
        if (newlen < 0)
            throw new StringIndexOutOfBoundsException(newlen);
        if (newlen > this.buffer.length){
            char[] cur = this.buffer;
            int curLen = (this.buffer == null) ? 0 : cur.length;
            char[] p = new char[newlen];
            if ((cur != null) && (s1 > 0)){    // optimized copy
                System.arraycopy(cur,0,p,0,s1);
            }
            if (s1 + l1 != e1){
                System.arraycopy(cur,s1+l1,
                    p,s1+l2,e1-s1-l1);
            }
            this.buffer = p;
        } else {
            if ((s1 + l1 != e1) && (l1 != l2)){
                System.arraycopy(this.buffer,s1+l1,
                    this.buffer,s1+l2,e1-s1-l1);
            }
        }
        this.length = newlen;
        if (l2 > 0){
            t2.getChars(s2,s2+l2,this.buffer,s1);
        }
        return this;
    }

    /**
     * Replace a substring in this string.
     *
     * @see        #cutInsert(int,int,char[],int,int,int)
     */

    public Str cutInsert(int s1, int l1, Str t2, int s2, int l2){
        return cutInsert(s1,l1,t2.buffer,t2.length,s2,l2);
    }

    /**
     * Truncate the string. The length is coerced as for slices.
     *
     * @param      len new length
     */

    public void trunc(int len){
        if (len < 0) len = 0;
        if (len > this.length) len = this.length;
        this.length = len;
    }

    /** The lowercase translation for ASCII. */

    public static char[] LOWER = {        // lowercase folding
        0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,
        20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,
        40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,
        60,61,62,63,64,'a','b','c','d','e','f','g','h','i','j','k',
        'l','m','n','o','p','q','r','s','t','u','v','w','x','y',
        'z',91,92,93,94,95,96,'a','b','c','d','e','f','g','h','i','j','k',
        'l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
        123,124,125,126,127};

    /** The uppercase translation for ASCII. */

    public static char[] UPPER = {        // uppercase folding
        0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,
        20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,
        40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,
        60,61,62,63,64,'A','B','C','D','E','F','G','H','I','J','K',
        'L','M','N','O','P','Q','R','S','T','U','V','W','X','Y',
        'Z',91,92,93,94,95,96,'A','B','C','D','E','F','G','H','I','J','K',
        'L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
        123,124,125,126,127};

    /**
     * Convert this string in uppercase starting at a given index.
     *
     * @see        #toUpper(char[],int,int,int)
     */

    public Str toUpper(int s1, int l1){
        toUpper(this.buffer,this.length,s1,l1);
        return this;
    }

    /**
     * Convert a string in uppercase starting at a given index.
     *
     * @param      t1 string
     * @param      e1 end of it
     * @param      s1 start index of slice
     * @param      l1 length of slice
     */

    public static void toUpper(char[] t1, int e1, int s1, int l1){
        if (t1 == null) e1 = 0;
        else if (e1 > t1.length) e1 = t1.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0; else if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        else if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;
        for (int i = s1; i < s1 + l1; i++){         // scan string
            char c = t1[i];
            t1[i] = (c < 128) ? Str.UPPER[c] :
                Character.toUpperCase(c);
        }
    }

    /**
     * Convert this string in lowercase starting at a given index.
     *
     * @see        #toLower(char[],int,int,int)
     */

    public Str toLower(int s1, int l1){
        toLower(this.buffer,this.length,s1,l1);
        return this;
    }

    /**
     * Convert a string in lowercase starting at a given index.
     *
     * @param      t1 string
     * @param      e1 end of it
     * @param      s1 start index of slice
     * @param      l1 length of slice
     */

    public static void toLower(char[] t1, int e1, int s1, int l1){
        if (t1 == null) e1 = 0;
        else if (e1 > t1.length) e1 = t1.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0; else if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        else if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;
        for (int i = s1; i < s1 + l1; i++){         // scan string
            char c = t1[i];
            t1[i] = (c < 128) ? Str.LOWER[c] :
                Character.toLowerCase(c);
        }
    }

    /**
     * Determine if two characters are equal apart from the case.
     *
     * @param      c1 first character
     * @param      c2 second character
     * @return     an integer &gt;, = or &lt; 0 if c1 predeces, is equal or
     *             follows c2 in the ordering
     */

    public static int compareIgnoreCase(char c1, char c2){
        if (c1 == c2) return 0;
        c1 = (c1 < 128) ? UPPER[c1] :
            Character.toUpperCase(c1);
        c2 = (c2 < 128) ? UPPER[c2] :
            Character.toUpperCase(c2);
        if (c1 == c2) return 0;
        c1 = (c1 < 128) ? LOWER[c1] :
            Character.toLowerCase(c1);
        c2 = (c2 < 128) ? LOWER[c2] :
            Character.toLowerCase(c2);
        if (c1 != c2) return c1 - c2;      // for Georgian
        return 0;
    }


    /**
     * Compare a slice of a string with a slice of another string
     * lexicographically.
     *
     * @param      t1 first string
     * @param      e1 end of it
     * @param      s1 start index of slice in t1
     * @param      l1 length of slice
     * @param      t2 second string
     * @param      e2 end of it
     * @param      s2 start index of slice in t2
     * @param      l2 length of slice
     * @param      ignoreCase true if case insensitive
     * @param      upp true to compare t1 with upper(t2)
     * @return     an integer &gt;, = or &lt; 0 if t1 follows, is equal or
     *             precedes t2 in the ordering
     */

    public static int compareSlices(char[] t1, int e1, int s1, int l1,
        String t2, int e2, int s2, int l2, boolean ignoreCase, boolean upp){
        if (t1 == null) e1 = 0;
        else if (e1 > t1.length) e1 = t1.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0;
        if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;

        if (t2 == null) e2 = 0;
        else if (e2 > t2.length()) e2 = t2.length();
        if (e2 < 0) e2 = 0;
        if (s2 < 0) s2 = 0;
        if (s2 > e2) s2 = e2;
        if (l2 < 0) l2 = 0;
        if ((s2 + l2 < 0) || (s2 + l2 > e2)) l2 = e2 - s2;

        if (upp){                                   // t1 ? upper(t2)
            for (int i1 = s1, i2 = s2;
                i1 < s1+l1 && i2 < s2+l2; i1++, i2++){
                char c1 = t1[i1];
                char c2 = t2.charAt(i2);
                c2 = (c2 < 128) ? UPPER[c2] :
                    Character.toUpperCase(c2);
                if (c1 == c2) continue;
                return c1 - c2;
            }
        } else {                                    // t1 ? t2
            for (int i1 = s1, i2 = s2;
                i1 < s1+l1 && i2 < s2+l2; i1++, i2++){
                char c1 = t1[i1];
                char c2 = t2.charAt(i2);
                if (c1 == c2) continue;
                if (!ignoreCase) return c1 - c2;
                c1 = (c1 < 128) ? UPPER[c1] :
                    Character.toUpperCase(c1);
                c2 = (c2 < 128) ? UPPER[c2] :
                    Character.toUpperCase(c2);
                if (c1 == c2) continue;
                c1 = (c1 < 128) ? LOWER[c1] :
                    Character.toLowerCase(c1);
                c2 = (c2 < 128) ? LOWER[c2] :
                    Character.toLowerCase(c2);
                if (c1 != c2) return c1 - c2;      // for Georgian
            }
        }
        return l1 - l2;
    }

    /**
     * Compare a slice of a string with a slice of another string
     * lexicographically.
     *
     * @see        #compareSlices(char[],int,int,int,
     *             String,int,int,int,boolean,boolean)
     */

    public static int compareSlices(String t1, int e1, int s1, int l1,
        String t2, int e2, int s2, int l2, boolean ignoreCase, boolean upp){
        if (t1 == null) e1 = 0;
        else if (e1 > t1.length()) e1 = t1.length();
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0;
        if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;

        if (t2 == null) e2 = 0;
        else if (e2 > t2.length()) e2 = t2.length();
        if (e2 < 0) e2 = 0;
        if (s2 < 0) s2 = 0;
        if (s2 > e2) s2 = e2;
        if (l2 < 0) l2 = 0;
        if ((s2 + l2 < 0) || (s2 + l2 > e2)) l2 = e2 - s2;

        if (upp){                                   // t1 ? upper(t2)
            for (int i1 = s1, i2 = s2;
                i1 < s1+l1 && i2 < s2+l2; i1++, i2++){
                char c1 = t1.charAt(i1);
                char c2 = t2.charAt(i2);
                c2 = (c2 < 128) ? UPPER[c2] :
                    Character.toUpperCase(c2);
                if (c1 == c2) continue;
                return c1 - c2;
            }
        } else {                                    // t1 ? t2
            for (int i1 = s1, i2 = s2;
                i1 < s1+l1 && i2 < s2+l2; i1++, i2++){
                char c1 = t1.charAt(i1);
                char c2 = t2.charAt(i2);
                if (c1 == c2) continue;
                if (!ignoreCase) return c1 - c2;
                c1 = (c1 < 128) ? UPPER[c1] :
                    Character.toUpperCase(c1);
                c2 = (c2 < 128) ? UPPER[c2] :
                    Character.toUpperCase(c2);
                if (c1 == c2) continue;
                c1 = (c1 < 128) ? LOWER[c1] :
                    Character.toLowerCase(c1);
                c2 = (c2 < 128) ? LOWER[c2] :
                    Character.toLowerCase(c2);
                if (c1 != c2) return c1 - c2;      // for Georgian
            }
        }
        return l1 - l2;
    }


    /**
     * Compare a slice of a string with a slice of another string
     * lexicographically.
     *
     * @see        #compareSlices(char[],int,int,int,
     *             String,int,int,int,boolean,boolean)
     */

    public static int compareSlices(char[] t1, int e1, int s1, int l1,
        char[] t2, int e2, int s2, int l2, boolean ignoreCase, boolean upp){
        if (t1 == null) e1 = 0;
        else if (e1 > t1.length) e1 = t1.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0;
        if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;

        if (t2 == null) e2 = 0;
        else if (e2 > t2.length) e2 = t2.length;
        if (e2 < 0) e2 = 0;
        if (s2 < 0) s2 = 0;
        if (s2 > e2) s2 = e2;
        if (l2 < 0) l2 = 0;
        if ((s2 + l2 < 0) || (s2 + l2 > e2)) l2 = e2 - s2;

        if (upp){                                   // t1 ? upper(t2)
            for (int i1 = s1, i2 = s2;
                i1 < s1+l1 && i2 < s2+l2; i1++, i2++){
                char c1 = t1[i1];
                char c2 = t2[i2];
                c2 = (c2 < 128) ? UPPER[c2] :
                    Character.toUpperCase(c2);
                if (c1 == c2) continue;
                return c1 - c2;
            }
        } else {                                    // t1 ? t2
            for (int i1 = s1, i2 = s2;
                i1 < s1+l1 && i2 < s2+l2; i1++, i2++){
                char c1 = t1[i1];
                char c2 = t2[i2];
                if (c1 == c2) continue;
                if (!ignoreCase) return c1 - c2;
                c1 = (c1 < 128) ? UPPER[c1] :
                    Character.toUpperCase(c1);
                c2 = (c2 < 128) ? UPPER[c2] :
                    Character.toUpperCase(c2);
                if (c1 == c2) continue;
                c1 = (c1 < 128) ? LOWER[c1] :
                    Character.toLowerCase(c1);
                c2 = (c2 < 128) ? LOWER[c2] :
                    Character.toLowerCase(c2);
                if (c1 != c2) return c1 - c2;      // for Georgian
            }
        }
        return l1 - l2;
    }

    /**
     * Compare a slice of this string with a slice of another string
     * lexicographically.
     *
     * @param      s1 start index of slice in this string
     * @param      l1 length of slice in it
     * @param      t2 second string
     * @param      s2 start index of slice in t2
     * @param      l2 length of slice
     * @param      ignoreCase true if case insensitive
     * @return     an integer &gt;, = or &lt; 0 if this predeces, is equal or
     *             follows t2 in the ordering
     */

    public int compareSlices(int s1, int l1,
        String t2, int s2, int l2, boolean ignoreCase){
        return compareSlices(this.buffer,this.length,s1,l1,
            t2,t2.length(),s2,l2,ignoreCase,false);
    }

    /**
     * Compare a slice of this string with a slice of another string
     * lexicographically.
     *
     * @param      s1 start index of slice in this string
     * @param      l1 length of slice in it
     * @param      t2 second string
     * @param      s2 start index of slice in t2
     * @param      l2 length of slice
     * @param      ignoreCase true if case insensitive
     * @return     an integer &gt;, = or &lt; 0 if this predeces, is equal or
     *             follows t2 in the ordering
     */

    public int compareSlices(int s1, int l1,
        Str t2, int s2, int l2, boolean ignoreCase){
        return compareSlices(this.buffer,this.length,s1,l1,
            t2.buffer,t2.length,s2,l2,ignoreCase,false);
    }


    /* Search methods. */

    /*
     * String search is not implemented with the Boyer-Moore algorithm
     * because it may not be implemented in Java in such a way to be faster
     * than the brute force one. Instead, an improved brute force is used.
     * With a completely random text, there is little chance that a suffix
     * of the pattern appears somewhere in the text. Thus, all the
     * time spent in calculating it and using its shift is wortless.
     * Without it, the algorithm performs 2 times better than bruteforce
     * for patters 15 characters long on average. This when the allocation of
     * the bad character table is not done at each call.
     * Even with a natural text, there is little advantage in calculating
     * the suffix table because the time spent in doing it and in using it
     * does not pay off.
     */

    /**
     * Search the first occurrence of a substring of <code>t2</code> in
     * a substring of <code>t1</code>.
     * Note that an empty string is considered to occur at the beginning
     * of the substring of <code>t1</code>. This is the only one case in
     * which an index which is equal to the length can be returned.
     *
     * @param      t1 first string
     * @param      e1 end of it
     * @param      s1 start index of slice in t1
     * @param      l1 length of slice
     * @param      t2 second string
     * @param      e2 end of it
     * @param      s2 start index of slice in t2
     * @param      l2 length of slice
     * @param      ignoreCase true if case insensitive
     * @return     index at which <code>t2</code> occurs, -1 if nowhere
     */

    public static int indexOf(char[] t1, int e1, int s1, int l1,
        char[] t2, int e2, int s2, int l2, boolean ignoreCase){
        if (t1 == null) e1 = 0;
        else if (e1 > t1.length) e1 = t1.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0;
        if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;

        if (t2 == null) e2 = 0;
        else if (e2 > t2.length) e2 = t2.length;
        if (e2 < 0) e2 = 0;
        if (s2 < 0) s2 = 0;
        if (s2 > e2) s2 = e2;
        if (l2 < 0) l2 = 0;
        if ((s2 + l2 < 0) || (s2 + l2 > e2)) l2 = e2 - s2;

        if (l1 < l2) return -1;
        int max = s1 + l1 - l2;
        if (l2 == 0) return s1;
        int i = s1;
        char first = t2[s2];
        if (!ignoreCase){
            matchfirst: while (true){
                while (i <= max && t1[i] != first){  // search first character
                    i++;
                    if (i > max) break;
                    if (t1[i] == first) break;
                    i++;
                }
                if (i > max) return -1;
                int j = i + 1;                         // match the rest
                int end = j + l2 - 1;
                int k = s2 + 1;
                while (j < end){
                    if (t1[j++] != t2[k++]){
                        i++;
                        continue matchfirst;
                    }
                    if (j >= end) break;
                    if (t1[j++] != t2[k++]){
                        i++;
                        continue matchfirst;
                    }
                }
                return i;
            }
        } else {
            char firstu = (first < 128) ? UPPER[first] :
                Character.toUpperCase(first);
            char firstl = (firstu < 128) ? UPPER[firstu] :
                Character.toUpperCase(firstu);
            char c;
            matchfirst: while (true){
                while (i <= max){                      // search first character
                    c = t1[i];
                    if (c == first) break;
                    c = (c < 128) ? UPPER[c] :
                        Character.toUpperCase(c);
                    if (c == firstu) break;
                    c = (c < 128) ? LOWER[c] :
                        Character.toLowerCase(c);
                    if (c == firstl) break;
                    i++;
                }
                if (i > max) return -1;
                int j = i + 1;                         // match the rest
                int end = j + l2 - 1;
                int k = s2 + 1;
                matchrest: while (j < end){
                    char c1 = t1[j++];
                    char c2 = t2[k++];
                    if (c1 == c2) continue matchrest;
                    c1 = (c1 < 128) ? UPPER[c1] :
                        Character.toUpperCase(c1);
                    c2 = (c2 < 128) ? UPPER[c2] :
                        Character.toUpperCase(c2);
                    if (c1 == c2) continue matchrest;
                    c1 = (c1 < 128) ? LOWER[c1] :
                        Character.toLowerCase(c1);
                    c2 = (c2 < 128) ? LOWER[c2] :
                        Character.toLowerCase(c2);
                    if (c1 != c2) continue matchfirst;
                }
                return i;
            }
        }
    }

    /**
     * Search the first occurrence of of a substring of <code>t2</code> in
     * a substring of <code>t1</code>.
     *
     * @see        #indexOf(char[],int,int,int,char[],int,int,int,boolean)
     */

    public static int indexOf(char[] t1, int e1, int s1, int l1,
        String t2, int e2, int s2, int l2, boolean ignoreCase){
        if (t1 == null) e1 = 0;
        else if (e1 > t1.length) e1 = t1.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0;
        if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;

        if (t2 == null) e2 = 0;
        else if (e2 > t2.length()) e2 = t2.length();
        if (e2 < 0) e2 = 0;
        if (s2 < 0) s2 = 0;
        if (s2 > e2) s2 = e2;
        if (l2 < 0) l2 = 0;
        if ((s2 + l2 < 0) || (s2 + l2 > e2)) l2 = e2 - s2;

        if (l1 < l2) return -1;
        int max = s1 + l1 - l2;
        if (l2 == 0) return s1;
        int i = s1;
        char first = t2.charAt(s2);
        if (!ignoreCase){
            matchfirst: while (true){
                while (i <= max && t1[i] != first){  // search first character
                    i++;
                    if (i > max) break;
                    if (t1[i] == first) break;
                    i++;
                }
                if (i > max) return -1;
                int j = i + 1;                         // match the rest
                int end = j + l2 - 1;
                int k = s2 + 1;
                while (j < end){
                    if (t1[j++] != t2.charAt(k++)){
                        i++;
                        continue matchfirst;
                    }
                    if (j >= end) break;
                    if (t1[j++] != t2.charAt(k++)){
                        i++;
                        continue matchfirst;
                    }
                }
                return i;
            }
        } else {
            char firstu = (first < 128) ? UPPER[first] :
                Character.toUpperCase(first);
            char firstl = (firstu < 128) ? UPPER[firstu] :
                Character.toUpperCase(firstu);
            char c;
            matchfirst: while (true){
                while (i <= max){                      // search first character
                    c = t1[i];
                    if (c == first) break;
                    c = (c < 128) ? UPPER[c] :
                        Character.toUpperCase(c);
                    if (c == firstu) break;
                    c = (c < 128) ? LOWER[c] :
                        Character.toLowerCase(c);
                    if (c == firstl) break;
                    i++;
                }
                if (i > max) return -1;
                int j = i + 1;                         // match the rest
                int end = j + l2 - 1;
                int k = s2 + 1;
                matchrest: while (j < end){
                    char c1 = t1[j++];
                    char c2 = t2.charAt(k++);
                    if (c1 == c2) continue matchrest;
                    c1 = (c1 < 128) ? UPPER[c1] :
                        Character.toUpperCase(c1);
                    c2 = (c2 < 128) ? UPPER[c2] :
                        Character.toUpperCase(c2);
                    if (c1 == c2) continue matchrest;
                    c1 = (c1 < 128) ? LOWER[c1] :
                        Character.toLowerCase(c1);
                    c2 = (c2 < 128) ? LOWER[c2] :
                        Character.toLowerCase(c2);
                    if (c1 != c2) continue matchfirst;
                }
                return i;
            }
        }
    }

    /**
     * Search the first occurrence of <code>patt</code> in this
     * string starting at the given <code>from</code> index.
     *
     * @see        #indexOf(char[],int,int,int,char[],int,int,int,boolean)
     */

    public int indexOf(Str patt, int from, boolean ignoreCase){
        return indexOf(this.buffer,this.length,from,this.length-from,
            patt.buffer,patt.length,0,patt.length,ignoreCase);
    }

    /**
     * Search the first occurrence of <code>patt</code> in this
     * string starting at the given <code>from</code> index.
     *
     * @see        #indexOf(char[],int,int,int,char[],int,int,int,boolean)
     */

    public int indexOf(String patt, int from, boolean ignoreCase){
        return indexOf(this.buffer,this.length,from,this.length-from,
            patt,patt.length(),0,patt.length(),ignoreCase);
    }

    /**
     * Search the first occurrence of a character in a substring
     * of <code>t1</code>.
     *
     * @see        #indexOf(char[],int,int,int,char[],int,int,int,boolean)
     */

    public static int indexOf(char[] t1, int e1, int s1, int l1,
        char patt, boolean ignoreCase){
        if (t1 == null) e1 = 0;
        else if (e1 > t1.length) e1 = t1.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0;
        if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;
        if (l1 == 0) return -1;
        int max = l1 - 1;
        int i = s1;
        if (!ignoreCase){
            while (i <= max){                // search character
                if (t1[i] == patt) return i;
                i++;
                if (i > max) break;
                if (t1[i] == patt) return i;
                i++;
            }
            return -1;
        } else {
            char firstu = (patt < 128) ? UPPER[patt] :
                Character.toUpperCase(patt);
            char firstl = (firstu < 128) ? UPPER[firstu] :
                Character.toUpperCase(firstu);
            char c;
            while (i <= max){                      // search first character
                c = t1[i];
                if (c == patt) return i;
                c = (c < 128) ? UPPER[c] :
                    Character.toUpperCase(c);
                if (c == firstu) return i;
                c = (c < 128) ? LOWER[c] :
                    Character.toLowerCase(c);
                if (c == firstl) return i;
                i++;
            }
            return -1;
        }
    }

    /**
     * Search the first occurrence of a character in this
     * string starting at the given <code>from</code> index.
     *
     * @see        #indexOf(Str,int,boolean)
     */

    public int indexOf(char patt, int from, boolean ignoreCase){
        return indexOf(this.buffer,this.length,from,this.length-from,
            patt,ignoreCase);
    }

    /**
     * Search the last occurrence of a substring of <code>t2</code> in
     * a substring of <code>t</code>.
     * Note that an empty string is considered to occur after the last
     * character of <code>t1</code>. Thus, when an empty string is
     * searched, the index of the first character after the slice is
     * returned (0 if <code>t1</code> is itself empty).
     * This is the only one case in which an index which is equal
     * to the length can be returned.
     *
     * @param      t1 first string
     * @param      e1 end of it
     * @param      s1 start index of slice in t1
     * @param      l1 length of slice
     * @param      t2 second string
     * @param      e2 end of it
     * @param      s2 start index of slice in t2
     * @param      l2 length of slice
     * @param      ignoreCase true if case insensitive
     * @return     index at which <code>t2</code> occurs, -1 if nowhere
     */

    public static int lastIndexOf(char[] t1, int e1, int s1, int l1,
        char[] t2, int e2, int s2, int l2, boolean ignoreCase){
        if (t1 == null) e1 = 0;
        else if (e1 > t1.length) e1 = t1.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0;
        if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;

        if (t2 == null) e2 = 0;
        else if (e2 > t2.length) e2 = t2.length;
        if (e2 < 0) e2 = 0;
        if (s2 < 0) s2 = 0;
        if (s2 > e2) s2 = e2;
        if (l2 < 0) l2 = 0;
        if ((s2 + l2 < 0) || (s2 + l2 > e2)) l2 = e2 - s2;

        if (l1 < l2) return -1;
        if (l2 == 0) return s1 + l1;
        int min = s1 + l2 - 1;
        int i = s1 + l1 - 1;
        char last = t2[s2+l2-1];
        if (!ignoreCase){
            matchlast: while (true){
                while (i >= min && t1[i] != last){   // search last character
                    i--;
                    if (i < min) break;
                    if (t1[i] == last) break;
                    i--;
                }
                if (i < min) return -1;
                int j = i - 1;                         // match the rest
                int start = j - l2 + 1;
                int k = s2 + l2 - 2;
                while (j > start){
                    if (t1[j--] != t2[k--]){
                        i--;
                        continue matchlast;
                    }
                    if (j <= start) break;
                    if (t1[j--] != t2[k--]){
                        i--;
                        continue matchlast;
                    }
                }
                return start + 1;
            }
        } else {
            char lastu = (last < 128) ? UPPER[last] :
                Character.toUpperCase(last);
            char lastl = (lastu < 128) ? UPPER[lastu] :
                Character.toUpperCase(lastu);
            char c;
            matchlast: while (true){
                while (i >= min){                      // search first character
                    c = t1[i];
                    if (c == last) break;
                    c = (c < 128) ? UPPER[c] :
                        Character.toUpperCase(c);
                    if (c == lastu) break;
                    c = (c < 128) ? LOWER[c] :
                        Character.toLowerCase(c);
                    if (c == lastl) break;
                    i--;
                }
                if (i < min) return -1;
                int j = i - 1;                         // match the rest
                int start = j - l2 + 1;
                int k = s2 + l2 - 2;
                matchrest: while (j > start){
                    char c1 = t1[j--];
                    char c2 = t2[k--];
                    if (c1 == c2) continue matchrest;
                    c1 = (c1 < 128) ? UPPER[c1] :
                        Character.toUpperCase(c1);
                    c2 = (c2 < 128) ? UPPER[c2] :
                        Character.toUpperCase(c2);
                    if (c1 == c2) continue matchrest;
                    c1 = (c1 < 128) ? LOWER[c1] :
                        Character.toLowerCase(c1);
                    c2 = (c2 < 128) ? LOWER[c2] :
                        Character.toLowerCase(c2);
                    if (c1 != c2) continue matchlast;
                }
                return start + 1;
            }
        }
    }

    /**
     * Search the last occurrence of <code>patt</code> in
     * <code>text</code> starting at the given <code>from</code> index.
     *
     * @see        #lastIndexOf(char[],int,int,int,char[],int,int,int,boolean)
     */

    public static int lastIndexOf(char[] t1, int e1, int s1, int l1,
        String t2, int e2, int s2, int l2, boolean ignoreCase){
        if (t1 == null) e1 = 0;
        else if (e1 > t1.length) e1 = t1.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0;
        if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;

        if (t2 == null) e2 = 0;
        else if (e2 > t2.length()) e2 = t2.length();
        if (e2 < 0) e2 = 0;
        if (s2 < 0) s2 = 0;
        if (s2 > e2) s2 = e2;
        if (l2 < 0) l2 = 0;
        if ((s2 + l2 < 0) || (s2 + l2 > e2)) l2 = e2 - s2;

        if (l1 < l2) return -1;
        if (l2 == 0) return s1 + l1;
        int min = s1 + l2 - 1;
        int i = s1 + l1 - 1;
        char last = t2.charAt(s2+l2-1);
        if (!ignoreCase){
            matchlast: while (true){
                while (i >= min && t1[i] != last){   // search last character
                    i--;
                    if (i < min) break;
                    if (t1[i] == last) break;
                    i--;
                }
                if (i < min) return -1;
                int j = i - 1;                         // match the rest
                int start = j - l2 + 1;
                int k = s2 + l2 - 2;
                while (j > start){
                    if (t1[j--] != t2.charAt(k--)){
                        i--;
                        continue matchlast;
                    }
                    if (j <= start) break;
                    if (t1[j--] != t2.charAt(k--)){
                        i--;
                        continue matchlast;
                    }
                }
                return start + 1;
            }
        } else {
            char lastu = (last < 128) ? UPPER[last] :
                Character.toUpperCase(last);
            char lastl = (lastu < 128) ? UPPER[lastu] :
                Character.toUpperCase(lastu);
            char c;
            matchlast: while (true){
                while (i >= min){                      // search first character
                    c = t1[i];
                    if (c == last) break;
                    c = (c < 128) ? UPPER[c] :
                        Character.toUpperCase(c);
                    if (c == lastu) break;
                    c = (c < 128) ? LOWER[c] :
                        Character.toLowerCase(c);
                    if (c == lastl) break;
                    i--;
                }
                if (i < min) return -1;
                int j = i - 1;                         // match the rest
                int start = j - l2 + 1;
                int k = s2 + l2 - 2;
                matchrest: while (j > start){
                    char c1 = t1[j--];
                    char c2 = t2.charAt(k--);
                    if (c1 == c2) continue matchrest;
                    c1 = (c1 < 128) ? UPPER[c1] :
                        Character.toUpperCase(c1);
                    c2 = (c2 < 128) ? UPPER[c2] :
                        Character.toUpperCase(c2);
                    if (c1 == c2) continue matchrest;
                    c1 = (c1 < 128) ? LOWER[c1] :
                        Character.toLowerCase(c1);
                    c2 = (c2 < 128) ? LOWER[c2] :
                        Character.toLowerCase(c2);
                    if (c1 != c2) continue matchlast;
                }
                return start + 1;
            }
        }
    }

    /**
     * Search the last occurrence of <code>patt</code> in this
     * string starting at the given <code>from</code> index.
     *
     * @see        #lastIndexOf(char[],int,int,int,char[],int,int,int,boolean)
     */

    public int lastIndexOf(Str patt, int from, boolean ignoreCase){
        return lastIndexOf(this.buffer,this.length,0,from+1,
            patt.buffer,patt.length,0,patt.length,ignoreCase);
    }

    /**
     * Search the last occurrence of <code>patt</code> in this
     * string starting at the given <code>from</code> index.
     *
     * @see        #lastIndexOf(char[],int,int,int,char[],int,int,int,boolean)
     */

    public int lastIndexOf(String patt, int from, boolean ignoreCase){
        return lastIndexOf(this.buffer,this.length,0,from+1,
            patt,patt.length(),0,patt.length(),ignoreCase);
    }

    /**
     * Search the last occurrence of a character in <code>text</code>
     * string starting at the given <code>from</code> index.
     *
     * @see        #lastIndexOf(char[],int,int,int,char[],int,int,int,boolean)
     */

    public static int lastIndexOf(char[] t1, int e1, int s1, int l1,
        char patt, boolean ignoreCase){
        if (t1 == null) e1 = 0;
        else if (e1 > t1.length) e1 = t1.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0;
        if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;
        if (l1 == 0) return -1;

        int min = 1;
        int i = s1 + l1 - 1;
        if (!ignoreCase){
            while (i >= min){                      // search character
                if (t1[i] == patt) return i;
                i--;
                if (i > min) break;
                if (t1[i] == patt) return i;
                i--;
            }
            return -1;
        } else {
            char lastu = (patt < 128) ? UPPER[patt] :
                Character.toUpperCase(patt);
            char lastl = (lastu < 128) ? UPPER[lastu] :
                Character.toUpperCase(lastu);
            char c;
            while (i >= min){                      // search last character
                c = t1[i];
                if (c == patt) return i;
                c = (c < 128) ? UPPER[c] :
                    Character.toUpperCase(c);
                if (c == lastu) return i;
                c = (c < 128) ? LOWER[c] :
                    Character.toLowerCase(c);
                if (c == lastl) return i;
                i--;
            }
            return -1;
        }
    }

    /**
     * Search the last occurrence of a character in this
     * string starting at the given <code>from</code> index.
     *
     * @see        #lastIndexOf(Str,int,boolean)
     */

    public int lastIndexOf(char patt, int from, boolean ignoreCase){
        return lastIndexOf(this.buffer,this.length,0,from+1,
            patt,ignoreCase);
    }

    /**
     * Return a new string which is a substring of the one passed as argument.
     * The substring contains the characters from <code>start</code>
     * up to a number of <code>len</code> characters.
     * A null string is considered as an empty one.
     * A <code>start</code> index lower than 0 is considered as 0; one
     * greater than the length is reduced to that length;
     * A <code>length</code> lower than 0 is considered as 0; one
     * greater than that of the tail of the string that begins at
     * <code>start</code> is reduced to it.
     * An <code>end</code> length lower than 0 is considered as 0; one
     * greater than the actual string length is reduced to it.
     *
     * @param      t1 string
     * @param      e1 end of it
     * @param      s1 start index of slice
     * @param      l1 length of slice
     * @return     new string containing the substring
     */

    public static char[] substring(char[] t1, int e1, int s1, int l1){
        if (t1 == null) e1 = 0;
        else if (e1 > t1.length) e1 = t1.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0; else if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        else if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;
        if (l1 == 0) return EMPTY_CHARS;
        char[] s = new char[l1];
        System.arraycopy(t1,s1,s,0,l1);
        return s;
    }

    /**
     * Return a string which is a substring of this string.
     *
     * @see        #substring(char[],int,int,int)
     */

    public Str substring(int s1, int l1){
        int e1 = this.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0; else if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        else if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;
        if (l1 == 0) return EMPTY;
        Str s = new Str(l1);
        s.length = l1;
        System.arraycopy(this.buffer,s1,s.buffer,0,l1);
        return s;
    }

    /**
     * Replace all occurrences of a character in a string with the one
     * passed as argument.
     *
     * @param      t string
     * @param      len its length
     * @param      c character to be replaced
     * @param      r replacement
     */

    public void replaceAll(char[] t, int len, char c, char r){
        for (int i = 0; i < len; i++){
            if (t[i] == c) t[i] = r;
        }
    }
     
    /**
     * Replace all occurrences of a character in this string with the one
     * passed as argument.
     *
     * @param      c character to be replaced
     * @param      r replacement
     * @return     this
     */

    public Str replaceAll(char c, char r){
        char[] s = this.buffer;
        for (int i = 0; i < this.length; i++){
            if (s[i] == c) s[i] = r;
        }
        return this;
    }

    /**
     * Determine if a text string <code>t1</code> matches a pattern string
     * <code>t2</code>. In the pattern, <code>any</code> characters denote
     * any (possibly empty) sequence of characters, and <code>one</code>
     * any one character.
     * Matching attempts to match the entire string. E.g. A*B*B matches ABBB.
     *
     * @param      t1 first string
     * @param      e1 end of it
     * @param      s1 start index of slice in t1
     * @param      l1 length of slice
     * @param      t2 second string
     * @param      e2 end of it
     * @param      s2 start index of slice in t2
     * @param      l2 length of slice
     * @param      any character which represent any number of characters
     * @param      one character which represent any one character
     * @return     true if they match
     */

    public static boolean matchPattern(char[] t1, int e1, int s1, int l1,
        char[] t2, int e2, int s2, int l2, char any, char one){
        if (t1 == null) e1 = 0;
        else if (e1 > t1.length) e1 = t1.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0;
        if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;

        if (t2 == null) e2 = 0;
        else if (e2 > t2.length) e2 = t2.length;
        if (e2 < 0) e2 = 0;
        if (s2 < 0) s2 = 0;
        if (s2 > e2) s2 = e2;
        if (l2 < 0) l2 = 0;
        if ((s2 + l2 < 0) || (s2 + l2 > e2)) l2 = e2 - s2;

        int t_i = s1;
        int t_l = l1;
        int p_i = s2;
        int p_l = l2;
        int st_i = 0, st_l = 0;
        int sp_i = 0, sp_l = 0;
        char cc;                               // current character of text
        char cp;                               // same of pattern
        ll: while (true){
            nomatch: {
                p_l--;
                if (p_l < 0){                  // pattern exausted
                    if (t_l != 0)              // try again
                        break nomatch;
                    break ll;                  // also can exausted, ok
                }
                cp = t2[p_i];                  // character of pattern
                p_i++;
                if (cp == any){                // 0..n characters
                    if (p_l == 0) break ll;    // * final, ok
                    st_i = t_i;                // save descriptors
                    st_l = t_l;                // save descriptors
                    sp_i = p_i;
                    sp_l = p_l;
                    continue;
                }
                t_l = t_l - 1;
                if (t_l < 0) return false;     // character of text  missing
                cc = t1[t_i];                  // character of text
                t_i++;
                if (cp == cc) continue;        // equal characters
                if (cp == one) continue;       // any one character
                else break nomatch;
            }
                                               // unsuccessful match, try again
            st_l--;
            if (st_l < 0) return false;        // no character saved
            st_i++;                            // step on
            t_i = st_i;                        // restore descriptors
            t_l = st_l;
            p_i = sp_i;
            p_l = sp_l;
        }
        return true;
    }

    /**
     * Determine if a text string <code>t1</code> matches a pattern string
     * <code>t2</code>.
     *
     * @see        #matchPattern(char[],int,int,int,
     *              char[],int,int,int,char,char)
     */

    public boolean matchPattern(int s1, int l1,
        Str t2, int s2, int l2, char any, char one){
        return matchPattern(this.buffer,this.length,s1,l1,
            t2.buffer,t2.length,s2,l2,any,one);
    }

    /**
     * Determine if a text string <code>t1</code> matches a pattern string
     * <code>t2</code>.
     *
     * @see        #matchPattern(char[],int,int,int,
     *              char[],int,int,int,char,char)
     */

    public static boolean matchPattern(char[] t1, int e1, int s1, int l1,
        String t2, int e2, int s2, int l2, char any, char one){
        if (t1 == null) e1 = 0;
        else if (e1 > t1.length) e1 = t1.length;
        if (e1 < 0) e1 = 0;
        if (s1 < 0) s1 = 0;
        if (s1 > e1) s1 = e1;
        if (l1 < 0) l1 = 0;
        if ((s1 + l1 < 0) || (s1 + l1 > e1)) l1 = e1 - s1;

        if (t2 == null) e2 = 0;
        else if (e2 > t2.length()) e2 = t2.length();
        if (e2 < 0) e2 = 0;
        if (s2 < 0) s2 = 0;
        if (s2 > e2) s2 = e2;
        if (l2 < 0) l2 = 0;
        if ((s2 + l2 < 0) || (s2 + l2 > e2)) l2 = e2 - s2;

        int t_i = s1;
        int t_l = l1;
        int p_i = s2;
        int p_l = l2;
        int st_i = 0, st_l = 0;
        int sp_i = 0, sp_l = 0;
        char cc;                               // current character of text
        char cp;                               // same of pattern
        ll: while (true){
            nomatch: {
                p_l--;
                if (p_l < 0){                  // pattern exausted
                    if (t_l != 0)              // try again
                        break nomatch;
                    break ll;                  // also can exausted, ok
                }
                cp = t2.charAt(p_i);           // character of pattern
                p_i++;
                if (cp == any){                // 0..n characters
                    if (p_l == 0) break ll;    // * final, ok
                    st_i = t_i;                // save descriptors
                    st_l = t_l;                // save descriptors
                    sp_i = p_i;
                    sp_l = p_l;
                    continue;
                }
                t_l = t_l - 1;
                if (t_l < 0) return false;     // character of text  missing
                cc = t1[t_i];                  // character of text
                t_i++;
                if (cp == cc) continue;        // equal characters
                if (cp == one) continue;       // any one character
                else break nomatch;
            }
                                               // unsuccessful match, try again
            st_l--;
            if (st_l < 0) return false;        // no character saved
            st_i++;                            // step on
            t_i = st_i;                        // restore descriptors
            t_l = st_l;
            p_i = sp_i;
            p_l = sp_l;
        }
        return true;
    }

    /**
     * Determine if a text string <code>t1</code> matches a pattern string
     * <code>t2</code>.
     *
     * @see        #matchPattern(char[],int,int,int,
     *              char[],int,int,int,char,char)
     */

    public boolean matchPattern(int s1, int l1,
        String t2, int s2, int l2, char any, char one){
        return matchPattern(this.buffer,this.length,s1,l1,
            t2,t2.length(),s2,l2,any,one);
    }

    /**
     * Shrink this string to the given length. The shrinked string is
     * <i>aaa...bbb</i>, where <i>aaa</i> and <i>bbb</i> are the head
     * and tail of the string.
     *
     * @param      len shrinked length
     */

    public void shrink(int len){
        if (len > this.length) return;
        if (this.length == 0) return;
        if (len == 0){
            this.length = 0;
            return;
        }
        int n = len / 3;
        int l2 = n;                   // middle part: ...
        if (l2 > 3) l2 = 3;           // at most 3 ...
        n = (len - l2) / 2;           // head, tail
        int l3 = n;
        int l1 = len - l2 - l3;
        System.arraycopy(this.buffer,this.length-l3,
            this.buffer,l1+l2,l3);
        for (int i = l1; i < l1+l2; i++){
            this.buffer[i] = '.';
        }
        this.length = len;
    }

    /**
     * Deliver a string shrinked to the given length.
     *
     * @param      str string
     * @param      len shrinked length
     * @return     shrinked string
     */

    public static String shrink(String str, int len){
        if (len > str.length()) return str;
        if (str.length() == 0) return str;
        if (len == 0) return "";
        int n = len / 3;
        int l2 = n;                   // middle part: ...
        if (l2 > 3) l2 = 3;           // at most 3 ...
        n = (len - l2) / 2;           // head, tail
        int l3 = n;
        int l1 = len - l2 - l3;
        return str.substring(0,l1) +
            "...".substring(0,l2) +
            str.substring(str.length()-l3);
    }

    /**
     * Deliver a string which is the literalized form of the string
     * passed as argument. The delivered string is surrounded by
     * double quotes if there are nonprintable or escaped characters
     * in it. Nonprintable and escaped characters are represented
     * as in Java literals.
     *
     * @param      buf array containing the string
     * @param      off offset
     * @param      len length
     * @param      dst literalized string
     */

    public static void strLit(char[] buf, int off, int len, Str dst){
        char c;
        String st = "";
        if (buf == null) return;
        boolean quote = false;
        boolean first = true;
        int start = dst.length;
        for (int i = off; i < off+len; i++){
            c = buf[i];
            switch (c){
            case '\b': st = "\\b"; break;
            case '\t': st = "\\t"; break;
            case '\n': st = "\\n"; break;
            case '\f': st = "\\f"; break;
            case '\r': st = "\\r"; break;
            case '\\': st = "\\\\"; break;
            case '\'': st = "\\\'"; break;
            case '\"': st = "\\\""; break;
            default:
                if ((c < ' ') || (c > '~')){  // others non printable
                    if (first){
                        dst.cutInsert(start,0,"\"",1,0,1);
                        first = false;
                    }
                    quote = true;
                    dst.append("\\u");
                    int rem;
                    for (int j = 0; j < 4; j++){
                        rem = (c>>>((4-j-1)*4)) & 0xf;
                        dst.append(
                            (char)(rem + ((rem <= 9) ? '0' : 'a' - 10)));
                    }
                    continue;
                }
                dst.append(c);
                continue;
            }
            if (first){
                dst.cutInsert(start,0,"\"",1,0,1);
                first = false;
            }
            quote = true;
            dst.append(st);
        }
        if (len == 0){
            quote = true;
            dst.cutInsert(start,0,"\"",1,0,1);
        }
        if (quote) dst.append("\"");
    }

    /**
     * Deliver a string which is the quoted form of the string
     * passed as argument. The delivered string is surrounded by
     * double quotes and nonprintable and escaped characters in it
     * are represented as in Java literals.
     *
     * @param      buf array containing the string
     * @param      off offset
     * @param      len length
     * @return     dst literalized string
     */

    public static void strQuoted(char[] buf, int off, int len, Str dst){
        char c;
        String st = "";
        dst.append('\"');
        for (int i = off; i < off+len; i++){
            c = buf[i];
            switch (c){
            case '\b': st = "\\b"; break;
            case '\t': st = "\\t"; break;
            case '\n': st = "\\n"; break;
            case '\f': st = "\\f"; break;
            case '\r': st = "\\r"; break;
            case '\\': st = "\\\\"; break;
            case '\'': st = "\\\'"; break;
            case '\"': st = "\\\""; break;
            default:
                if ((c < ' ') || (c > '~')){  // others non printable
                    dst.append("\\u");
                    int rem;
                    for (int j = 0; j < 4; j++){
                        rem = (c>>>((4-j-1)*4)) & 0xf;
                        dst.append(
                            (char)(rem + ((rem <= 9) ? '0' : 'a' - 10)));
                    }
                    continue;
                }
                dst.append(c);
                continue;
            }
            dst.append(st);
        }
        dst.append('\"');
    }

    /**
     * Deliver a string which is the quoted form of the string
     * passed as argument. The delivered string is surrounded by
     * double quotes and nonprintable and escaped characters in it
     * are represented as in Java literals.
     *
     * @param      str string
     * @param      dst literalized string
     */

    public static void strQuoted(String str, Str dst){
        int off = 0;
        int len = str.length();
        char c;
        String st = "";
        dst.append('\"');
        for (int i = off; i < off+len; i++){
            c = str.charAt(i);
            switch (c){
            case '\b': st = "\\b"; break;
            case '\t': st = "\\t"; break;
            case '\n': st = "\\n"; break;
            case '\f': st = "\\f"; break;
            case '\r': st = "\\r"; break;
            case '\\': st = "\\\\"; break;
            case '\'': st = "\\\'"; break;
            case '\"': st = "\\\""; break;
            default:
                if ((c < ' ') || (c > '~')){  // others non printable
                    dst.append("\\u");
                    int rem;
                    for (int j = 0; j < 4; j++){
                        rem = (c>>>((4-j-1)*4)) & 0xf;
                        dst.append(
                            (char)(rem + ((rem <= 9) ? '0' : 'a' - 10)));
                    }
                    continue;
                }
                dst.append(c);
                continue;
            }
            dst.append(st);
        }
        dst.append('\"');
    }

    /**
     * Deliver a string which is the quoted form of the string
     * passed as argument. The delivered string is surrounded by
     * double quotes and nonprintable and escaped characters in it
     * are represented as in Java literals.
     *
     * @param      str string
     * @return     literalized string
     */

    public static String strQuoted(String str){
        Str sq = new Str(str.length());
        strQuoted(str,sq);
        return sq.toString();
    }

    /**
     * Deliver a string which is the html representation of the specified
     * string.
     *
     * @param      str string
     * @return     literalized string
     */

    public static String toHtml(String s){
        Str st = new Str();
        for (int i = 0; i < s.length(); i++){
            char c = s.charAt(i);
            switch (c){
            case '<': st.append("&lt;"); break;
            case '>': st.append("&gt;"); break;
            case '&': st.append("&amp;"); break;
            case '\"': st.append("&quot;"); break;
            default: st.append(c); break;
            }
        }
        return st.toString();
    }

    /**
     * A Reader that gets its data from this object. It does not throw IOExceptions.
     */

    public class StrReader extends Reader {

        /** The index of the data read. */
        private int cursor;

        /** The mark for repositioning. */
        private int mark;

        /**
         * Read one character.
         *
         * @see        Reader.read()
         */

        public int read(){
            if (this.cursor >= Str.this.length){
                return -1;
            }
            return Str.this.buffer[this.cursor++];
        }

        /**
         * Read the specified number of character in the specified buffer.
         *
         * @see        Reader.read(char[],int,int)
         */

        public int read(char cbuf[], int off, int len){
            if (this.cursor >= Str.this.length){
                return -1;
            }
            if (len > Str.this.length-this.cursor){
                len = Str.this.length-this.cursor;
            }
            System.arraycopy(Str.this.buffer,this.cursor,cbuf,off,len);
            this.cursor += len;
            return len;
        }

        /**
         * Read a line and deliver a string.
         *
         * @see        BufferedReader.readLine()
         */

        public String readLine(){
            if (this.cursor >= Str.this.length){
                return null;
            }
            int start = this.cursor;
            int end = this.cursor;
            ln: for (; this.cursor < Str.this.length; this.cursor++){ // search line terminator
                end = this.cursor;
                char c = Str.this.buffer[this.cursor];
                switch (c){
                case '\r':
                   this.cursor++;
                   if ((this.cursor < Str.this.length) &&
                       (Str.this.buffer[this.cursor] == '\n')){
                       this.cursor++;
                   }
                   break ln;
                case '\n':
                   this.cursor++;
                   break ln;
                }
            }
            return String.valueOf(Str.this.buffer,start,end-start);
        }

        /**
         * Skip ahead the specified number of characters.
         *
         * @see        Reader.skip(long)
         */

        public long skip(long ns){
            if (this.cursor >= Str.this.length){
                return 0;
            }
            if (ns > Str.this.length-this.cursor){
                ns = Str.this.length-this.cursor;
            }
            this.cursor += ns;
            return ns;
        }

        /**
         * Tells whether the stream is ready to deliver data, which it is.
         *
         * @see        Reader.ready()
         */

        public boolean ready(){
            return true;
        }

        /**
         * Tells whether the stream can be repositioned, which it is.
         *
         * @see        Reader.markSupported()
         */

        public boolean markSupported(){
            return true;
        }

        /**
         * Sets the mark point to the current index.
         *
         * @see        Reader.mark()
         */

        public void mark(int readAheadLimit){
            if (readAheadLimit < 0){
                throw new IllegalArgumentException();
            }
            this.mark = this.cursor;
        }

        /**
         * Reposition the strem to the previous mark point.
         *
         * @see        Reader.reset()
         */

        public void reset(){
            this.cursor = this.mark;
        }

        /**
         * Close the stream.
         *
         * @see        Reader.close()
         */

        public void close(){
        }
    }

    /**
     * Deliver a Reader for this string.
     *
     * @return     reader
     */

    public StrReader getReader(){
        return new StrReader();
    }

    /**
     * Deliver a PrintWriter for this string.
     *
     * @return     writer
     */

    public PrintWriter getWriter(){
        return new PrintWriter(new Writer(){
            public void write(int c){
                Str.this.append((char)c);
            }
            public void write(char cbuf[], int off, int len){
                if (len == 0) return;
                Str.this.append(cbuf,off,len);
            }
            public void write(String str){
                Str.this.append(str);
            }
            public void write(String str, int off, int len){
                Str.this.append(str,off,len);
            }
            public Writer append(CharSequence csq){
                if (csq == null){
                    write("null");
                } else {
                    write(csq.toString());
                }
                return this;
            }
            public Writer append(CharSequence csq, int start, int end){
                CharSequence cs = (csq == null ? "null" : csq);
                write(cs.subSequence(start,end).toString());
                return this;
            }
            public Writer append(char c){
                write(c);
                return this;
            }
            public String toString(){
                return Str.this.toString();
            }
            public void flush(){ 
            }
            public void close() throws IOException {
            }
        });
    }
}
