/*
 * @(#)IOError.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;
import lbj.Failure;

/**
 * An io error. It indicates the violation of a condition which
 * has been encountered during the execution of a method due either
 * to some external cause or to a programming error.
 */

public class IOError extends Failure {

    /**
     * The file path.
     *
     * @serial
     */
    public String path;

    /**
     * The position.
     *
     * @serial
     */
    public long index;

    /** Successful operation. */
    public static final int SUCCESS =  0;

    /** An io error has been found. */
    public static final int ERR_IOERR = 1;

    /** An illegal file (path) has been found. */
    public static final int ERR_ILLFILE = 2;

    /** A value out of the allowed limits has been found. */
    public static final int ERR_OUTLIMIT = 3;

    /** Too much memory has been used. */
    public static final int ERR_NOCORE = 4;

    /** The file is not open. */
    public static final int ERR_NOTOPEN = 5;

    /** The file has been changed underneath. */
    public static final int ERR_MISMATCH = 6;

    /** The file rename has failed. */
    public static final int ERR_RENAME = 7;

    /** The file is open. */
    public static final int ERR_ISOPEN = 8;

    /** The file has not been located. */
    public static final int ERR_NOLOC = 9;

    /** An exec failed. */
    public static final int ERR_EXECERR = 10;

    /** Circular definition of logical names. */
    public static final int ERR_CIRCDEF = 11;

    /** Invalid operation. */
    public static final int ERR_INVOP = 12;

    /** The file does not exist. */
    public static final int ERR_NOFILE = 13;

    /** The value is illegal. */
    public static final int ERR_VALUE = 38;

    /** An exception has occurred on a PrintStream. */
    public static final int ERR_PRINTERR = 40;

    /** It was not possible to find the main class file. */
    public static final int ERR_NOTMAIN = 41;

    /** The file could not be created (e.g. missing directory). */
    public static final int ERR_NOCREA = 42;

    /** An illegal class has been passed. */
    public static final int ERR_ILLCLASS = 43;

    /** A security violation has been detected. */
    public static final int ERR_SECURITY = 44;

    /** The time of the file could not have been changed. */
    public static final int ERR_SETTIME = 45;

    /** The line exceeds the maximum configured length. */
    public static final int ERR_LONGLINE = 46;

    /** The eof has been found. */
    public static final int ENDOFFILE = 47;

    /** The deletion of the file failed. */
    public static final int ERR_DELFAIL = 50;

    /**
     * Create an IOError.
     *
     * @param      c error code
     * @param      e associated exception (if any);
     * @param      p path
     * @param      i index
     * @param      o stream on which it occurs
     */

    IOError(int c, Throwable e, String p, long i, Object o){
        super(c,'F',null,null,message(c),null,o);
        this.path = p;
        this.exc = e;
        this.index = i;
    }

    /**
     * Deliver the locale neutral message which corresponds to a given
     * error code.
     *
     * @param      c error code
     */

    private static String message(int c){
        String[] msgtab = IOBundle.MSGTAB;
        if (msgtab == null) return Integer.toString(c);
        else if (c >= 0) return msgtab[c];
        else return Integer.toString(c);
    }

    /**
     * Deliver the strings representing the failure.
     *
     * @param      loc locale, null if no locale
     * @return     strings
     */

    public String[] getMessages(Locale loc){
        int n = 1;
        if (this.path != null) n++;
        if (this.index >= 0) n++;
        String[] res = new String[n];
        Locale l = loc;
        if (loc == null) l = Locale.getDefault();
        ResourceBundle bun =
            ResourceBundle.getBundle(
                IOBundle.class.getName(),l);
        res[0] = header("IOS",'F') +
            ((String[])(bun.getObject("MSGTAB")))[this.code];
        n = 1;
        if (this.path != null){
            res[n++] = bun.getString("ONFILE") + ": " + this.path;
        }
        if (this.index >= 0){
            res[n++] = bun.getString("POSITION") + ": " + this.index;
        }
        return res;
    }
}

