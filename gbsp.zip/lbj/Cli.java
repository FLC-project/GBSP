/*
 * @(#)Command.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.text.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.lang.reflect.*;
import lbj.Formatter.*;

/**
 * The <code>Cli</code> class provides reading and parsing of commands
 * for program activation.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

/**
 * Cli objects allow definition and parsing of commands.
 * <p>
 * Commands are made of a command name (verb) followed by qualifiers and
 * parameters. Qualifiers have a name and can appear in commands in any
 * order. Parameters are positional. Qualifiers can have a value, which
 * can also be a list of elements. Parameter values can also be lists of
 * elements, and the latter can have local qualifiers in them.
 * The actual syntax can be chosen to suit the one of the most commonly
 * used shells.
 * <p>
 * <b>Syntax</b>
 * <p>
 * This is the syntax of commands accepted by Cli. When commands are read
 * by a shell, they and processed by it before a program is called which
 * then can pass them to Cli. Shells usually perform a number of transformations
 * on commands, such as variable substitution, escape reduction, breaking into
 * arguments, etc. The following one is the syntax which commands must obey
 * after the shell processing has been done.
 * <p><pre>
 *   &lt;command&gt;    ::= &lt;verb&gt; {&lt;global qualifier&gt; | &lt;parameter&gt; }*
 *   &lt;verb&gt;       ::= &lt;name&gt;
 *   &lt;global qualifier&gt; ::= &lt;qualifier&gt; { &lt;local qualifier&gt; }*
 *   &lt;qualifier&gt;  ::= &lt;qualifier indicator&gt; {
 *                      { &lt;name&gt; | &lt;short name&gt; }
 *                      [ &lt;qualifier value separator&gt; &lt;qualifier value&gt; ]
 *                    | &lt;neg-name&gt;
 *                    | {&lt;short name&gt;}+                         (QMASK)
 *                    | @&lt;element&gt;
 *                    }
 *   &lt;qualifier indicator&gt; ::= /                                (QUALSL)
 *                    | -- | - | +                              (otherwise)
 *                    | &lt;empty&gt;                                 (QUALNVP)
 *   &lt;name&gt;       ::= { &lt;letter&gt; | _ | $ }
 *                    { &lt;letter&gt; | &lt;digit&gt; | _ | $ | . | - }*
 *   &lt;short name&gt; ::= &lt;letter&gt; | _ | $
 *   &lt;neg-name&gt;   ::= &lt;no&gt; &lt;name&gt;
 *   &lt;qualifier value separator&gt; ::=  =                         (QVALEQ)
 *                    | :                                       (QVALCO)
 *                    | empty                                   (otherwise)
 *   &lt;qualifier value&gt; ::= &lt;element&gt; | &lt;qualifier value list&gt;
 *   &lt;qualifier value list&gt; :: = ( &lt;element&gt; {, &lt;element&gt; }* )  (DCLLSEP)
 *                    | &lt;element&gt; {: &lt;element&gt; }*               (otherwise)
 *   &lt;element&gt;    ::= &lt;element argv-unix&gt;                       (otherwise)
 *                    | &lt;element argv-unix-list&gt;                (otherwise)
 *                    | &lt;element argv-dcl/win&gt;                  (QUALSL & DCLLSEP)
 *                    | &lt;element-unix&gt;                          (otherwise)
 *                    | &lt;element unix-list&gt;                     (otherwise)
 *                    | &lt;element dcl/win&gt;                       (QUALSL & DCLLSEP)
 *                    | &lt;element argv-n=v pairs&gt;                (QUALNVP)
 *                    | &lt;element n=v pairs&gt;                     (QUALNVP)
 *   &lt;element argv-unix&gt; ::= &lt;empty&gt;
 *                    | &lt;any except {+|-|@|&lt;edigit&gt;}&gt; {&lt;any&gt;}*
 *                    | -
 *   &lt;element argv-unix-list&gt; ::= &lt;empty&gt;
 *                    | &lt;any except {+|-|@|&lt;edigit&gt;|&gt; {&lt;any except :&gt;}*
 *                    | -
 *   &lt;element argv-dcl/win&gt; ::= &lt;empty&gt;
 *                    | &lt;any except @&gt; {&lt;any except {+|,|)|/}&gt;}*
 *   &lt;element unix&gt; ::= &lt;any except {+|-|@|&lt;edigit&gt;|&gt;
 *                       {&lt;any except {SP|CR|LF|HT}&gt; | &lt;string&gt; }*
 *                    | -
 *   &lt;element unix-list&gt; ::= &lt;any except {+|-|@|&lt;edigit&gt;}&gt;
 *                       {&lt;any except : {SP|CR|LF|HT}&gt; | &lt;string&gt; }*
 *                    | -
 *   &lt;element dcl/win&gt; ::= {&lt;any except {+|,|@|)|/|SP|CR|LF|HT}&gt; |
 *                       &lt;string&gt; }*
 *   &lt;element argv-n=v pairs&gt; ::=  &lt;empty&gt;
 *                    | &lt;any except @&gt; {&lt;any&gt;}*
 *   &lt;element n=v pairs&gt; ::= {&lt;any except {SP|CR|LF|HT|@}&gt; |
 *                       &lt;string&gt; }*
 *   &lt;string&gt;     ::= " {"" | &lt;any except "&gt;}* "                  (otherwise)
 *                    | " {&lt;any except "&gt;}* "                           (HTMLVALUE)
 *                    | ' {&lt;any except '&gt;}* '                           (HTMLVALUE)
 *   &lt;parameter&gt;  ::= &lt;parameter element&gt; | &lt;parameter value list&gt;
 *   &lt;parameter value list&gt; ::= &lt;parameter element&gt; { { , | + } (DCLLSEP)
 *                      &lt;parameter element&gt; }*
 *                    | { &lt;parameter element&gt; }+                (otherwise)
 *   &lt;parameter element&gt; ::= &lt;element&gt; { &lt;local qualifier&gt; }*
 *                    | &lt;prefix qualifier&gt;                      (not DCLLSEP)
 *   &lt;prefix qualifier&gt; ::=  &lt;qualifier indicator&gt; { &lt;name&gt;
 *                      | {&lt;short name&gt;}+ }                     (QMASK)
 *                      &lt;element&gt; { &lt;local qualifier&gt; }*
 *   &lt;local qualifier&gt; ::= &lt;qualifier&gt;
 * </pre><p>
 *
 * <b>Lexical rules:</b>
 * <p>
 *   &lt;letter&gt; is an Unicode letter, &lt;digit&gt; is an Unicode digit,
 *   &lt;edigit&gt; is a &lt;digit&gt; or &#92;u221E (infinity).
 *   &lt;name&gt;, &lt;short name&gt;, &lt;neg-name&gt;, &lt;string&gt;,
 *   &lt;qualifier indicator&gt; and the following &lt;name&gt;,
 *   &lt;short name&gt; or &lt;neg-name&gt;, &lt;element&gt; and
 *   "<code>,</code>", "<code>+</code>", "<code>=</code>" and
 *   "<code>:</code>" are lexical elements.
 *   White space (Unicode Zs characters and HT) can occur around them.
 *   If <code>WHITESPACE</code> is selected, also LF, VT, FF and CR
 *   are considered whitespace. This is needed to parse files in which the
 *   breaking into lines is free (e.g. environments of value-name pairs
 *   or html tags). It should not be selected when LF separates commands
 *   from some text which is processed by the aplication.
 *   When commands are passed by shells, shells break commands into segments
 *   made of contiguous characters which are not SP and HT (unless quoted).
 *   Commands are written in a single line which can be continued over the next.
 *   If <code>CONHY</code> is selected, the continuation character is
 *   "<code>-</code>"; if <code>CONCARET</code> is selected, it is
 *   "^<code>"</code>, otherwise it is "<code>\</code>".
 *   <code>CONHY</code> takes percedence over <code>CONCARET</code>.
 *   An &lt;element&gt; which is made solely by "<code>-</code>" must be
 *   separated from the next lexical element by whitespace.
 *   This allows to consider a <code>-</code>" followed by a non-whitespace
 *   character as a qualifier, and to reject it if what follows the
 *   "<code>-</code>" is not a name.
 *   &lt;no&gt; is the possibly localized version of "no".<br>
 *   The "argv" elements are the ones which are in effect when commands
 *   are passed as vectors of strings (command segments).
 *   If neither <code>QUALSL</code> nor <code>QUALNVP</code> are specified,
 *   a "<code>--</code>" followed by whitespace makes any further argument
 *   (including a "<code>--</code>") be considered as an element even when
 *   it begins with "<code>-</code>", i.e., as a parameter.
 * <p>
 * <b>Syntax preferences:</b>
 * <p>
 *   If <code>QUALSL</code> is selected, qualifiers are indicated by a
 *   slash followed by a name; if <code>QUALNVP</code> is selected, qualifiers
 *   are indicated by a name; otherwise they are indicated by a dash.<br>
 *   <code>QUALSL</code> takes precedence over <code>QUALNVP</code>.
 *   If nor <code>QVALEQ</code> nor <code>QVALCO</code> are selected and the
 *   qualifier allows a value and is followed by an element, that element is
 *   taken as its value.<br> Otherwise, the qualifier value, if any, must
 *   be separated by one of such separator if <code>QSREQ</code> is selected,
 *   and otherwise that separator is optional. In the latter case, if
 *   <code>NONSEP</code> is specified, the value can be written immediately
 *   after the qualifier name, without whitespaces.
 *   A qualifier which allows no value, or a negated qualifier must always
 *   be terminated by a terminator or whitespace.
 *   <p>
 *   For qualifiers, if <code>AR_VALREQ</code> is specified, a
 *   &lt;qualifier value&gt; must be specified. Otherwise, the value can be
 *   omitted, e.g. <code>"-q, -q="</code>.
 *   An &lt;element&gt; in a &lt;qualifier value list&gt; can be omitted only
 *   if <code>AR_EMPTY</code> is specified and <code>AR_VALREQ</code> is not
 *   specified.
 *   E.g. in such a case, "<code>/qual=()</code>", "<code>/qual=(a,,)</code>"
 *   and "<code>val,,val</code>" (the latter two only if <code>AR_LIST</code>
 *   is specified) are allowed.
 *   Note that <code>""</code> is not a missing value, but one which is an
 *   empty string.
 *   <p>
 *   For parameters which allow a list, &lt;parameter element&gt;s must be
 *   specified unless <code>AR_EMPTY</code> is specified.
 *   In them, if <code>AR_VALREQ</code> is apecified, an &lt;element&gt; must
 *   be present (i.e. it is not allowed to have local qualifiers only).
 *   <p>
 *   Lists of values are allowed only when <code>AR_LIST</code> is specified.
 *   The syntax of qalifiers depends on <code>LNAME</code>, <code>QSEP</code
 *   and <code>QMASK</code> as defined below.
 *   Matching of names is case sensitive unless <code>CASEINS</code> is set.
 *   <p>
 *   The various forms of elements are in effect according on whether Cli is
 *   processing argvs or not, according on the OS and on whether it is
 *   the element of a qualifier list or not. Indirect files are always processed
 *   as if the non-argv mode were in effect.
 *   In the syntax, `@' is to be considered only if the default indirect argument
 *   is in effect. Note that `@' behaves as a qualifier indicator (e.g. it
 *   terminates a list parameter). Note also that elements may not start with
 *   `@' (unless the default indirect argument is disabled).<br>
 *   If <code>DCLLSEP</code> is not specified, local qualifiers which do not
 *   allow a value can be written in front of a parameter value element,
 *   separated by "<code>:</code>" from it. This is allowed also with a set
 *   of qualifiers.
 *   <p>
 *   By default, the syntax preferences are set up according to the current
 *   shell:
 *   <p><pre>
 *      Unix:    ABBREV, QVALEQ, QVALCO, LNAME, NONSEP, QMASK
 *      Window:  CASEINS, ABBREV, QVALEQ, QVALCO, TOUPPER, QUALSL,
 *               CONCARET, QSREQ, DCLLSEP
 *      DCL:     CASEINS, ABBREV, QVALEQ, QVALCO, TOUPPER,
 *               QUALSL, CONHY, QSREQ, DCLLSEP
 *   </pre><p>
 *
 * <b>Examples:</b>
 *   <p><pre>
 *      -x | --name    qualifier
 *      /x             qualifier
 *      -x val         qualifier with value
 *      -x=val -x:val  qualifier with value
 *      -x=(val,...)   qualifier with list of values
 *      par            parameter
 *      par/q,par+...  parameter with list of values with qualifiers
 *   </pre><p>
 *
 * <b>Qualifier names</b>
 *   <p>
 *   Some commands allow short qualifiers to be specified all together, and
 *   some others allow qualifiers with long names to be specified with one
 *   dash only, e.g. "<code>-longname</code>" qualifiers instead of
 *   "<code>--longname</code>".
 *   The name matching is as follows:
 *   <p>
 *   <ul>
 *   <li>when <code>QUALSL</code> is enabled:
 *      <ol>
 *      <li>if a name of one character is found, a short name is matched;
 *         otherwise
 *      <li>a long name is matched
 *      </ol>
 *   <li>otherwise:
 *      <ol>
 *      <li>when a "<code>--</code>" is found, then a longname is matched;
 *      <li>when a "<code>-</code>" is found, then a sequence of characters
 *        is taken and:
 *        <ol>
 *        <li>if <code>LNAME</code>, a match is attempted first with a longname.
 *        <li>if <code>NONSEP</code>, and the first character matches a short
 *          qualifier that allows a value, the characters after it are taken
 *          to be the value even if not separated by white space
 *        <li>if <code>QMASK</code>, a combination of short names is matched
 *          (which allows to have several occurrences of it).
 *        </ol>
 *      <li>when a "<code>+</code>" is found, then the second and third steps
 *        above are taken.
 *      </ol>
 *      Note that the "<code>+</code>" form can be used only when
 *      <code>QUALSL</code> and <code>QUALNVP</code> are not enabled;
 *      otherwise, the long forms should be used.
 *      <p>
 *      The negated forms with one dash, e.g. "<code>-noxxx</code>" are
 *      accepted if <code>LNAME</code> is selected.
 *   </ul>
 *   Longnames are matched always against global qualifier, and after parameters
 *   also local qualifiers to detect ambiguities and to let qualifier names
 *   take precedence over combination of short names. In this way a global
 *   qualifier always ends a parameter even if it could resemble a combination.
 *   <p>
 *   The matching of one character provides the equivalent of Unix short names
 *   in the Dcl syntax. It is as a standard abbreviation that do not need be
 *   enabled. This imposes a maximum on the number of qualifiers both on UniX
 *   and Dcl syntax. This means that abbreviating a qualifier to one character
 *   works only if the short name is the first character of the long one.
 *   <p>
 *   Longnames must be longer than 1 character. If one-character longnames
 *   were allowed, with <code>LNAME</code> there would be a need to check that there
 *   are not clashes between long and short names, otherwise a one-character
 *   longname could hide forever a shortname.
 *   If a longname is one character long it should be defined as short.
 *   <p>
 *   Qualifier names can contain "<code>-</code>", but not at the beginning
 *   so as not to confuse long and short names
 *   <p>
 *   Qualifiers which can have a value and allow it to be attached to
 *   the qualifier name, e.g. "<code>-qval</code>", are interpreted as
 *   "<code>-q val</code>", not as a set of qualifiers. This is done by
 *   attempting to recognize it first in the former way. Moreover, qualifiers
 *   which allow a value can not be specified in a combination.
 *   All the qualifiers in a combination must be either local or all global.
 *   Note that a combination may never be confused with a qualifier followed
 *   by a value because the former is allowed only for valueless qualifiers.
 *   <p>
 *   When <code>LNAME</code> and <code>NONSEP</code> are enabled (as it
 *   is normally the case in Unix syntax), a qualifier short name which
 *   immediately followed by letters and digits is interpreted by taking
 *   those letters and digits as its value. It would resemble the name of
 *   an unknown qualifier.
 *   <p>
 * <b>Negated forms</b>
 *   <p>
 *   Qualifier names for qualifiers which allow a negated form can start with
 *   a (possibly localised) "<code>no</code>".
 *   <p>
 *   Qualifiers which are negatable accept the negated form. In Unix commands
 *   that have no negatable qualifiers, the negated form automatically is
 *   disallowed.
 *   <p>
 *   A null string is not a valid abbreviation for a qualifier name, and
 *   therefore "<code>no</code>" as such is not a valid qualifier negation.
 *   Note that if there is a "<code>nonono</code>" negatable qualifier,
 *   "<code>nono</code>" matches both the normal and negated form, and thus
 *   is ambiguous.
 *   <p>
 *   Since most names in Unix are in lowercase, then the normal negation
 *   for them is a lowercase "<code>no</code>". The case of the negation is
 *   the same as that of the first character of the qualifier's name.
 *   More precisely, negation is specified by prefixing qualifier names with
 *   "<code>NO</code>" if they start with an uppercase letter, and with
 *   "<code>no</code>" otherwise.
 *   The negations can be specified in upper and lower case in case insensitive
 *   mode.
 *   <p>
 *   When the negation is allowed on a qualifier, no value can be specified
 *   when the qualifer has the negated form even when AR_VALREQ is specified.
 *   E.g. if "<code>/output</code>" has a required value,
 *   "<code>/outp=xxx</code>" and /noout are allowed, but not
 *   "<code>/outp</code>". This is so because the negated form is an explicit
 *   means to indicate that there is no value specified.
 *   <p>
 *   The negated form can also be specified on valueless qualifiers.
 *   <p>
 * <b>Qualifier values</b>
 *   <p>
 *   Qualifier values in DCL/WIN which are lists are enclosed in parens in order
 *   to allow to continue after the list with a comma and another value for the
 *   parameter to which they are appended.
 *   E.g. "<code>f1/qual=(a,b),f2...</code>".
 *   <p>
 *   In DCL a qualifier value can be enclosed in parenthese, e.g.:
 *   "<code>-out=(a)</code>", even if it is not a list. Note that
 *   "<code>-out=()</code>" has no value, not an empty one, while
 *   "<code>-out=(,)</code>" has two empty values.
 *   <p>
 *   An empty list is accepted as qualifier's value: "<code>()</code>".
 *   <p>
 *   Note that if QVALEQ or QVALCO are not selected, there is no secure way to
 *   omit the value of a qualifier which has an optional value.
 *   <p>
 * <b>Qualifiers</b>
 *   <p>
 *   Global qualifiers whose value is not a value list can have local
 *   qualifiers.
 *   <p>
 *   In DCL/WIN, qualifiers can be written without spaces, e.g.:
 *   "<code>/a=1/b/c=2</code>". In Unix there is a need to separate them, e.g.:
 *   "<code>-a=1 -b -c=2</code>".
 *   <p>
 *   Repetition of qualifiers is not allowed, except for the default indirect
 *   file argument. Repetition of parameters is meaningless anyway (since they
 *   are positional).
 *   <p>
 *   Local and global mandatory qualifiers are allowed, including the valueless
 *   ones.
 *   <p>
 *   A set of alternative qualifiers is made of all adjacent qualifiers which
 *   have AL_ALT specified in them. In a command definition there can exist
 *   several sets of alternative qualifiers. Only one of the qualifiers in a
 *   set is allowed in a command. All the qualifiers in a same set must
 *   either have AR_REQ specified in them or have it not. If it is specified,
 *   then one of the qualifiers must be present in a command.
 *   <p>
 *   <p>If <code>LENIENT</code> mode is enabled, unknown qualifiers are
 *   discarded. They are treated as qualifiers which allow a list of values.
 *   Unknown qualifiers are always considered global, and thus terminate
 *   a value list of a parameter if one has been specified before.
 * <b>Parameters</b>
 *   <p>
 *   To keep the syntax of parameter values as permissive as possible, the
 *   qualifier value separators ("<code>=</code>" and "<code>:</code>")
 *   can be specified in parameter values.
 *   As a result, in the following case: "<code>/noqual=value</code>" the
 *   "<code>=value</code>" is considered to be the next parameter, and in
 *   "<code>/qual=value</code>" "<code>=value</code>" is considered the
 *   qualifier's value. If there is a need to make it become the next
 *   parameter instead, quoted strings must be used, e.g.:
 *   "<code>/qual"=value"</code>".
 *   <p>
 *   Many parameters are filenames. Qualifiers start with a "<code>-</code>"
 *   because it is seldom used in filenames; "<code>/</code>" is, however
 *   used a lot, and thus in Unix it would be a bad choice as qualifier
 *   indicator.
 *   <p>
 *   A parameter value is ended also when a global qual is found. I.e. a
 *   an element can be followed by any number of local qualifiers; the first
 *   occurrence of another element ends the previous one, and the parameter
 *   if it does not allow a list, and the occurrence of a global qualifier
 *   ends the parameter anyway.
 *   A set of qualifiers after a parameter value must contain qualifiers which
 *   are all local or all global.
 *   The reason of this is both to make commands readable, which would not
 *   much be the case if local and global qualifiers were intermixed, while
 *   keeping the possibility to introduce global qualifiers after parameters
 *   (which is important when introducing commands interactively, when the
 *   user finds at the end that some global qualifier need be introduced).
 *   <p>
 *   When a parameter's value is a list, all local qualifiers can be
 *   specified after each element, e.g.:
 *   "<code>file1/qual,file2/qual....</code>".
 *   In Unix it would be: "<code>file1 -qual file2 -qual...</code>".
 *   <p>
 *   In Unix, valueless qualifiers can be written in front of parameter
 *   elements, separated by `<code>:</code>' from the value, e.g.:
 *   "<code>-l:f1</code>".
 *   <p>
 *   Variable number of parameters: There could be commands in which there
 *   is a need to pass several values. They can only be a sequence of a
 *   variable numer of values of the same type. Thus, they can be represented
 *   as the value of a list parameter.
 *   <p>
 * <b>Elements</b>
 *   <p>
 *   The characters that terminate a parameter value are not the same as
 *   the ones that terminate a qualifier value, and are different from Dcl
 *   and Unix. For DCL:
 *   <p><pre>
 *     parameter: + , SP HT CR LF /
 *     qualifier: + , SP HT CR LF ) /
 *   </pre><p>
 *   In DCL, since there is no much difference, they are taken to be the
 *   qualifier ones. Note that since file names, which are quite common
 *   argument values in Unix can contain "<code>-</code>", then
 *   "<code>-</code>" is allowed in values. Local qualifiers must be separated
 *   by white space. However, in Unix "<code>-</code>" may not be used as the
 *   first character of elements (unless quoted) because it makes the token
 *   be interpreted as a qualifier.
 *   <p>
 *   "<code>-</code>" not followed by "<code>-</code>" nor by a name is taken
 *   as an element when QUALSL or QUALNVP are not specified.
 *   <p>
 *   The arguments which have been declared with an integer class have the
 *   following syntax:
 *   <p><pre>
 *       [&lt;sign&gt;] &lt;base&gt; {&lt;digits&gt;}+ &lt;unit&gt; [&lt;sign&gt;]
 *   </pre><p>
 *   <dl><dd>
 *       Only one sign is allowed, both prefix or postfix independently from
 *       the current locale.
 *       The base is the Java one: "<code>0x</code>", "<code>0X</code>"
 *       for hexadecimal, "<code>0</code>" for octal.
 *       If no base is present in the argument definition, decimal is taken.
 *       A base in the value overrides that of the argument.
 *       The digits can be separated by the locale grouping separators, which
 *       can also be space when the locale allows U+00a0.
 *       The digits must be the ones of the current locale.
 *   </dl>
 *   <p>
 *   The arguments which have been declared with a floating point class have the
 *   following syntax:
 *   <p><pre>
 *       [&lt;sign&gt;] {&lt;digits&gt;}*&lt;decimal separator&gt;{&lt;digits&gt;}* [&lt;sign&gt;]
 *       [ &lt;exponent symbol&gt; [&lt;sign&gt;] {&lt;digits&gt;}+ [&lt;sign&gt;] ]
 *   </pre><p>
 *   <dl><dd>
 *       Shortly: <code>[+|-]i.fe[+|-]xx, [+|-]i.fE[+|-]xx, [+|-]i.f</code>
 *       Either the integral (i) or fractional (f) parts are optional (not both
 *       if a decimal separator is present).
 *       The sign, digits and grouping are as for integers.
 *       Inf and NaN are accepted as well as the locale one (always &#92;u221E
 *       and &#92;uFFFD).
 *       To specify negative infinity use -&#92;u221E.
 *       The decimal separator and the exponent symbol are the ones of the
 *       current locale.
 *       The arguments which have AR_MON denote monetary values. The scientific
 *       notation is not allowed in their values. An international currency
 *       symbol (See ISO 4217), or the local one (of the current locale) must be
 *       present. Surrounding parentheses can be used to denote negative
 *       numbers.
 *       The following forms are allowed, in which `$' denotes the currency
 *       symbol, `-' the localised minus sign, and sp whitespace:
 *       <p>
 *       ([$[sp]] nnn [[sp]$]) | [$[sp]] [-] nnn [-] [[sp]$] | - [$[sp]] nnn
 *       <p>
 *       Only one currency symbol and only one sign are allowed.
 *       <p>
 *       International monetary values have a currency symbol in them which
 *       allows to tell their currency, and thus to interpret them
 *       independently from the current locale. For the local ones, they can
 *       be interpreted only in the current locale because the local currencly
 *       symbols are not unique.
 *       The decimal separators which have to be used are those of the current
 *       locale. E.g. if the current locale is, say, Italian, then 1000 USD is
 *       expected to be written as 1.000 USD and not 1,000 USD.
 *       The numeric code of the currency is obtained by calling an integral
 *       <i>type</i><code>Value()</code>.
 *   </dl>
 *   <p>
 *   The arguments which have been declared with the char class allow one
 *   single character. If AR_UNI is present, one Unicode escape is allowed:
 *   backslash u followed by four hexadecimal digits.
 *   <p>
 *   The arguments which have been declared with the String class allow a
 *   string. If AR_UNI is present, the string can contain Unicode escapes.
 *   <p>
 *   The arguments which have been declared with the boolean class allow one
 *   boolean value, which can be the localized version of:
 *   <code>0, 1, off, on, false, true</code>.
 *   <p>
 *   The arguments which have been declared with the Date class allow a
 *   date according to the <code>DataFormat.parse()</code> syntax.
 *   <p>
 *   The arguments which have been declared with an object (which must be
 *   an array) allow a value that must comply to the syntax of the element
 *   type of the array, and must be one of the values present in that array.
 *   The index is accessed with an integral <i>type</i><code>Value()</code>.
 *   <p>
 *   <code>strValue()</code> can be used to get the string of values of
 *   all types.
 * <b>Default qualifiers</b>
 *   <p>
 *   Default qualifiers are implicitly present in all commands unless disabled.
 *   They allow to use indirect files (see below) or to request assistance.
 *   They are somehow special because they produce some effect on the
 *   other arguments.
 *   It is allowed to repeat them, but for the ones which produce some
 *   assistance, only the first one takes effect.  
 *   Moreover, parsing does not continue after a default qualifier because
 *   otherwise it could catch missing required arguments. Parsing stops, and
 *   the caller is notified about that so that is can stop or process another
 *   command by returning <code>NULL_COMMAND</code>.
 *   The caller is informed because the command has not been parsed
 *   successfully, and thus it must not be executed, and <code>parse()</code>
 *   or <code>getCommand()</code> have no way to get by themselves another
 *   command.  
 *   <p>
 *   To disable usage qualifiers, pass <code>NOUSAGE</code> to
 *   <code>init()</code>, to disable of all default qualifiers, pass
 *   <code>NODEFLT</code>.
 *   <p>
 *   Command definitions can contain qualifiers whose names are the same as
 *   the ones of default qualifiers. In such a case abbreviations may not
 *   be used. In this case, names in commands match the non-default qualifiers.
 *   When a qualifier in a command has a short or long name that is the same
 *   as that of a default qualifer, the latter is considered not to be present
 *   for that command.
 *   <p>
 *   The default qualifiers are:
 *   <ul>
 *   <li><code>@</code> (no short name): followed by a file name.
 *     The contents of the specified file replaces (virtually) the
 *     occurrence of the qualifier in the command.
 *   <li><code>arg-display</code>: the arguments present in the command
 *     are displayed together their values.
 *   <li><code>help</code>: a help message is displayed.
 *   <li><code>usage</code>: a (default) usage message is displayed.
 *   <li><code>usage-brief</code>: a short usage message is displayed.
 *   <li><code>usage-verbose</code>: a verbose  usage message is displayed.
 *   <li><code>usage-all</code>: all  usage messages are displayed.
 *   <li><code>version</code>: the version is displayed.
 *   </ul>
 *   Display occurs only if the application is running in interactive mode.
 * <p>
 * <b>Compliance with standards</b>
 *   <p>
 *   The POSIX conventions are summarized here: 
 *   <ol>
 *   <li>Arguments are options if they begin with a hyphen delimiter
 *     ("<code>-</code>"). 
 *   <li>An option is a hyphen followed by a single alphanumeric character
 *     (as for isalnum). E.g.: "<code>-o</code>". 
 *   <li>An option may require a value (which can appear immediately
 *     after the option or be separated with whitespace); for example,
 *     "<code>-o </code><i>value</i>"  or "<code>-o</code><i>value</i>". 
 *   <li>Options that do not require values can be grouped in a single
 *     token after a hyphen, so, for example, "<code>-lst</code>" is
 *     equivalent to "<code>-t -l -s</code>".
 *   <li>Options can appear in any order (whether grouped or not); thus
 *     e.g.: "<code>-lst</code>" is equivalent to "<code>-tls</code>". 
 *   <li>Options can appear multiple times. 
 *   <li>Options precede other nonoption arguments: "<code>-lst</code>
 *     nonoption. 
 *   <li>"<code>--</code>" terminates all options. All the following
 *     arguments are treated as non-option arguments, even if they begin with
 *     a hyphen. 
 *   <li>The token consisting of a single hyphen character ("<code>-</code>")
 *     is interpreted as an ordinary non-option argument. It is typically used
 *     to represent one of the standard input streams.
 *   </ol>
 *   Extensions:
 *   <ol>
 *   <li>long options consist of "<code>--</code>" followed by a name made of
 *     alphanumeric characters and dashes. Option names are typically one to
 *     three words long, with hyphens to separate words. Users can abbreviate
 *     the option names as long as the abbreviations are unique. 
 *     To specify a value for a long option, write
 *     "<code>--name=</code><i>value</i>".
 *     This syntax enables a long option to accept a value that is itself
 *     optional. 
 *   </ol>
 *   Cli complies with the Posix rules, and it implements also the Extensions.
 *   Moreover, it allows to write options and non-options in any order.
 *   Repetition of options is allowed in parameter elements.
 * <p>
 * <p>Indirect command files
 * <p>
 * Indirect command files (indirect files for short) are files containing
 * arguments (parameters and command qualifiers, not local qualifiers) which
 * can be (virtually) included in commands.
 * They are a means to overcome the restrictions that a shell imposes on the
 * length of commands, and also a means to avoid the explicit repetition of
 * arguments which are the same for several commands.
 * When Cli encounters an indirect file qualifier, i.e. one which has the
 * <code>AR_IND</code> attribute (indirect argument for short), it parses the
 * contents of the referred file.<br>
 * The omitted parts of the file spec are taken from the previous indirect
 * file parsed, being at the beginning the current host, disk, directory
 * and file-type ".com".<br>
 * In the file the arguments can be written on separate lines, ended by a
 * continuation character, which is the one used by the underlying shell
 * or set by the syntax preferences.<br>
 * Indirect files can contain occurrences of arguments which are themselves
 * indirect files arguments. Cli enters them recursively, and detects circular
 * recursion.
 * If the <code>AR_USER</code> attribute is specified in an indirect file
 * argument, the files referred to by it can contain a user defined part at
 * the end (i.e. after the last line). That part can be accessed by
 * <code>strValue(<i>n</i>)</code>, where <i>n</i> is the number of the
 * argument. To test the presence, <code>present()</code> can be called on
 * command-specific indirect file arguments.
 * The default indirect file argument does neither allow a user part nor
 * a <code>present()</code> call. Moreover, unlike the other qualifiers,
 * it can occur several times in a command.
 * <p>
 * <b>Commands, parameters and qualifiers (arguments) definition</b>
 * <p>
 * Commands are defined by creating objects of Command, Parameter and
 * Qualifier classes which declare the properties of them. A typical
 * command looks like:
 *   <p><pre>
 *   Command cmd = new Command
 *       ("name",..., new Argument[] {         // command
 *       new Qualifier(...),                   // global qualifier
 *       new Parameter(..., new Qualifier[] {  // parameter
 *           new Qualifier(...)}),             // local qualifier
 *   });
 *   </pre><p>
 * The following conditions must hold in command definitions:
 * <ul>
 * <li>argument names may not be empty. They must be longer than one character.
 * <li>types must be in the set of the supported ones.
 * <li>names of arguments must be unique: parameters and global qualifiers,
 *   local qualifiers of a parameter and global qualifiers, I.e. the
 *   only repetition allowed is between local qualifiers of different
 *   parameters. Short names with the same <code>AR_PLUS</code> specification
 *   follow the same rule (i.e. a +x clashes with another +x, and likewise
 *   for a -x).
 * <li>negation is not allowed on parameters.
 * <li>indirect file arguments must be global qualifiers with a string value
 *  and no attributes other than <code>AR_USER</code> and <code>AR_VALREQ</code>
 *  (the latter is mandatory for indirect file arguments). They can have at
 *  most one local qualifier, which must be the (possibly localised) predefined
 *  encoding qualifier.
 * <li>an optional parameter may not be followed by a mandatory one.
 * <li><code>AR_VALREQ</code> may not be specified on valueless qualifiers.
 * <li><code>AR_PLUS</code> may only be specified on qualifiers.
 * <li>only one of <code>AR_BIN</code>, <code>AR_OCT</code>,
 * <code>AR_HEX</code> and <code>AR_ROM</code> can be specified. The
 *  attributes that are relative to formatting must be among the ones which
 *  are defined for the class of the argument.
 * </ul>
 * <p>
 * Cli supports the declaration of sets of commands. E.g.:
 *   <p><pre>
 *   Command cmdset = new Command[] = {
 *       new Command(),
 *       new Command(),
 *       ...
 *   };
 *   </pre><p>
 * <p>
 * When a commands is parsed and a set of definitions is provided, the verb
 * is searched in the set and the matching definition taken. The sequence
 * number of the command matched (starting at 0) can be retrieved by an
 * integral <i>type</i><code>Value()</code>.
 * <p>
 * <b>Internationalization</b>
 * <p>
 * The following localization levels are provided:
 * <ol>
 * <li>nothing localized: messages, values, argument names belong to a fixed
 *   language. The default locale does not influence it. This is obtained
 *   by initializing Cli with no bundle.
 * <li>messages and values (numbers, dates, etc.) depend on the current
 *   locale, while argument names are taken from a fixed one. The default
 *   arguments are in that language, the user arguments are provided by
 *   the command definitions. This is obtained by initializing with an
 *   empty bundle, or with a bundle from which no command definition is
 *   taken.
 * <li>all is localized. This is obtained by initializing with a bundle
 *   in which the command definitions are taken. In them all the strings
 *   which depend on the locale should be present, I.e. help messages,
 *   mnemonics for usage messages, arrays of object values. Note that to
 *   access arguments, the definitions of the constants representing their
 *   indexes can be kept in the application since it is not dependent on
 *   localization.
 * </ol>
 * It is allowed to make references to definitions of arguments present
 * in another classes (e.g. "libraries" of argument definitions).
 * To determine the bundle that contains their translations, the bundle
 * can be mentioned in the definitions. When a bundle is defined in an
 * argument, it applies implicitly to its local arguments.
 *
 * The default locale can change between subsequent parses of commands.
 * However, when a command has been parsed, its data maintain the locale
 * in which they were introduced. I.e. changes in the default locale become
 * effective between commands, not in the middle of them.
 * The default locale can be forced to be a given one by using
 * <code>Cli.setDefault(<i>locale</i>)</code>. Once it has been forced,
 * it can be changed, but it may not be reverted to follow be the VM-wide
 * default.
 * <p>
 * <b>Command lines</b>
 * <p>
 * Cli is able to parse commands which are contained in a single String
 * or char[], or in an array thereof.
 * There are no predefined limits to the length of command lines.
 * <p>
 * <b>Accessing command data</b>
 * <p>
 * After a command has been parsed (by using <code>parse()</code> or
 * <code>getCommand()</code>), the data contained in is can be accessed.
 * This is made by using <code>present()</code> and
 * <i>type</i><code>Value</code> which allow to know the presence,
 * negation status and value of each argument (including the verb).
 * Arguments are denoted by their number, starting at 0 (be either arguments
 * of commands or local qualifiers); the verb is denoted by
 * <code>VERB</code>.
 * <p>
 * Values of non-list arguments can be obtained by calling as many times
 * as needed the methods above. For list arguments, each call delivers the
 * next value. If there is a need to restart from the beginning the
 * scanning of all arguments or a given one, <code>restart()</code> must
 * be called.
 * <p>
 * The presence and values of local qualifiers can be determined in the
 * same way for non-list parameters. For list parameters the
 * <i>type</i><code>value()</code> on the parameter must be called first.
 * The subsequent calls on local qualifiers deliver the data of the
 * local qualifiers which are specified after the last parameter list
 * element obtained.
 * <p>
 * To access qualifiers which allow negation, test the presence first.
 * Then, if it is neither <code>ABSENT</code> nor <code>NEGATED</code>,
 * the values can be accessed.<br>
 * <i>type</i><code>Value()</code> applied to qualifiers which do not allow
 * a value delivers <code>ABSENT</code>, as it does for qualifiers which
 * have no value (e.g. the negated form).
 * <p>
 * <code>strValue(Cli.VERB)</code> delivers the verb which is specified
 * in the command. For the command which activated the application,
 * delivered by <code>getCommand()</code>, it is the name specified in the
 * command definition. The URI of the .class file which has been run
 * is delivered by <code>getMainFile()</code>. The fully qualified name
 * of the class which has been run is delivered by <code>getMainClass()</code>,
 * its name by <code>getMainName()</code>, and its
 * version by <code>getMainVersion()</code>.
 * <p>
 * <b>Programming</b>
 * <p>
 * To parse and access commands there is a need to provide command
 * definitions, and then to create and initialize a Cli object. If the
 * command that has to be parsed is the one that activated the application,
 * <code>getCommand()</code> should be called, otherwise <code>parse()</code>.
 * After that the data contained in the command can be accessed.
 * Cli rejects calls which are not made in this sequence.
 * <p> 
 * This is a typical usage of Cli to parse the activation command:
 * <p><pre>
 *    Command cmd = new Command(...);
 *    Cli cmdpk = new Cli();
 *    cmdpk.getCommand(cmd,args,0,"V1.1");
 * </pre><p>
 * This is a typical usage of Cli to parse a generic command:
 * <p><pre>
 *    Command cmd = new Command(...);
 *    Cli cmdpk = new Cli();
 *    cmdpk.init();
 *    cmdpk.parse(cmd,line);
 * </pre><p>
 * and after that:
 * <p><pre>
 *    cmdpk.present() ...
 *    cmdpk.<i>type</i>Value() ...
 *    cmdpk.restart();                        // to rescan the values
 *    cmdpk.present() ...
 *    cmdpk.<i>type</i>Value() ...
 *    cmdpk.terminate()                       // optional
 *    if (cmdpk.present(x) == Cli.PRESENT){   // to get the values in a list
 *        do {
 *            cmdpk.strValue(x)...
 *        } while (cmdpk.status == Cli.CONT);
 *    }
 * </pre><p>
 * <p>
 * Command definitions can be stored in files and afterwards retrieved.
 * This speeds up applications which have several commands because the
 * check on the correctness of definitions would be done only once before
 * storing them.
 * This is how to do it:
 * <p><pre>
 *    // command definition and storage
 *
 *    Cli cmdpk = new Cli();
 *    cmdpk.init();
 *    cmdpk.check(<i>command-definition</i>);
 *    cmdpk.storeCommand(<i>filename</i>,<i>command-definition</i>);
 *
 *    // command retrieval
 *
 *    Command cmd = (Command)cmdpk.retrieveCommand(<i>filename</i>);
 * </pre><p>
 * Cli can report error by throwing exceptions, returning a status code,
 * or aborting the application. These are typical skemes:
 * <p><pre>
 *    // with return status
 *
 *    Cli cmdpk = new Cli(Cli.RET_STATUS);
 *    cmdpk.init();
 *
 *    // Case: single command
 *
 *        cmdpk.parse(cmd,line);
 *        if (cmdpk.res > 0){
 *            cmdpk.excObj.print(System.err);
 *        } else {
 *            // execute command
 *        }
 *
 *    // Case: loop of commands
 *
 *        do {
 *            // get next line
 *            cmdpk.parse(cmd,line);
 *            if (cmdpk.res < 0) continue;
 *            if (cmdpk.res > 0){
 *                cmdpk.excObj.print(System.err);
 *                continue;
 *            }
 *            // execute command
 *        } while();
 *
 *    // with exceptions
 *
 *    Cli cmdpk = new Cli();
 *    cmdpk.init();
 *
 *    // Case: single command
 *
 *        try {
 *            cmdpk.parse(cmd);
 *            // execute command
 *        } catch (CliError exc){
 *            cmdpk.excObj.print(System.err);
 *        }
 *
 *    // Case: loop of commands
 *
 *        do {
 *            // get next line
 *            try {
 *                cmdpk.parse(cmd,line);
 *                // execute command
 *            } catch (CliError exc){
 *                cmdpk.excObj.print(System.err);
 *                continue;
 *            }
 *        } while(true);
 *
 *    // with abort
 *
 *    Cli cmdpk = new Cli(Cli.ERR_ABORT);
 *    cmdpk.init();
 *
 *    // Case: single command
 *
 *        cmdpk.parse(cmd,line);
 *        // execute command
 *
 *    // Case: loop of commands
 *
 *        do {
 *            // get next line
 *            cmdpk.parse(cmd,line);
 *            // execute command
 *        } while(true);
 * </pre><p>
 * The skemes for single commands apply also to the parsing of the
 * activation command by removing the <code>init()</code> calls and
 * by indicating the error handling policy in the <code>getCommand()</code>
 * calls which sould be used instead of <code>parse()</code>.
 * <p>
 * There are different kinds of errors:
 * <ol>
 * <li>errors which are present in the command. The caller should
 *   print an error message as shown above.
 * <li>system errors, like e.g. missing resources, or io errors.
 *   They also need be reported to the caller.
 * <li>programming errors, which cause Cli to report an error.
 *   E.g. the ones in present() and value().
 *   They may even not be catched, thus letting the program to abort,
 *   or better, they can be catched also.
 * </ol>
 * A check is made that the API methods are called only when the Cli object
 * has been initialised and also, that it is in the approprate state.
 * When a method is called and the object is not in the appropriate state,
 * <code>ERR_SEQUENCE</code> is returned.
 * <p>
 * Errors are reported on a report stream, which is by default System.err.
 * This is useful when Cli is used to interpret a file of commands for which
 * there can is a need to collect the errors on a listing.
 * <p>
 * It is possible to instruct Cli to call a method when a command is
 * parsed successfully. This is obtained by specifying a callback in
 * the command definition.
 * That callback can be:
 * <ul>
 * <li>an instance of a class which implements the <code>CliCbk</code>
 *   interface: the <code>cliExec</code> method in it is called on
 *   the instance specified in <code>init()</code>. E.g.:
 *   <p><pre>
 *       new CliCbk(){public void cliExec(Cli c, Object o)
 *          {<i>user_exe</i>(c);}}
 *   </pre><p>
 *   where <i>user_exe</i> is a method of the class in which the definition
 *   lays.
 * <li>a string, which is the name of a callback of the class which is
 *   specified together with it, or the class of the <code>main()</code>
 *   if not specified. In this case the class is loaded only when
 *   needed.
 * </ul>
 * Alternatively, Cli can return an integer code for the matched command,
 * which is the code specified in the command definition. After a command
 * has been parsed, the <code>commandCode()</code> delivers the code.
 * <p>
 * <b>Packaging and running Java programs</b>
 * <p>
 * A Java program, run as an ordinary one would be invoked with:
 * <p><pre>
 *    program args ...
 * </pre><p>
 * There is a need to provide a script which contains:
 * <p><pre>
 *    java -classpath path class "$@"
 * </pre><p>
 * <code>java</code> is the command that activates the Java VM interpreter.
 * If there is a need for a specific one, include the path. There is a need
 * also to set some environment variables to make it locate the basic
 * classes if one which is not installed is called.
 * <p>
 * <code>path</code> is the path which is needed to reach the package root
 * for the class file. If the script is placed in the root of the class file,
 * then path is: <code>${0%[^/]*}/..</code>.
 * This avoids the lack of precision in locating a program when the
 * lookup is made by the VM with a path, and there are several programs
 * with the same name reacheable from the path.
 * <p>
 * Note that the script should be such as to run without changes when
 * it and the tree of directories up to the one which contains the class
 * is moved to another root.
 * <p>
 * The main class has its logical place in the root directory of a package.
 * This is aimed to disclose as little as possible the package structure
 * to the user. The package structure should remain an implementation choice
 * which has no impact on the user.
 * <p>
 * Jar files are quite different from JDK 1.1 to 1.2:
 * <p>
 * <ul>
 * <li>1.1: the jar can be created in the directory where the
 *   <code>main.class</code> is, and then run by calling jre. E.g.:
 *   <p><pre>
 *         jre -cp cli.jar lbj.CliTest
 *   </pre><p>
 * <li>1.2 the jar can only be created from within the parent directory
 *   of the package, so as to have in it a subdirectory with the class. E.g.:
 *   <code>lbj/CliTest.class</code>.
 *   Moreover, there is a need to create a file with filetype .txt
 *   containing:
 *   <p><pre>
 *         Main-Class: lbj.CliTest
 *         Sealed: true
 *
 *         jar cmf lbj/climanifest.txt lbj/cli.jar lbj/*.class
 *   </pre><p>
 *   and then call it:
 *   <p><pre>
 *         java -jar cli.jar
 *   </pre><p>
 *   However, it can also be called as:
 *   <p><pre>
 *         java -classpath lbj/cli.jar lbj.CliTest
 *   </pre><p>
 *   This seems better because it does not require to create a manifest
 *   update file.
 *   The tecnnique which works in both cases is:
 *   <p><pre>
 *         java -classpath cli.jar lbj.CliTest
 *   </pre><p>
 *   With cli.jar containing all the classes.
 * </ul>
 * The shell first identifies the pieces surrounded by double quotes,
 * then replaces the parameters occurring in them. Thus the "$@" allows
 * to pass exactly all what is contained in the original arguments.
 * <p>
 * An alternative, and faster way is to define an alias:
 * <p><pre>
 *     alias clitest='java -classpath /users/borsotti/ lbj.Clitest'
 * </pre><p>
 * In Unix and Win shells, a command which includes redirections of standard
 * streams is passed to a program stripped of them. E.g.:
 * "<code>prog &gt;tmp arg</code>" is passed as "<code>prog arg</code>".
 * In Unix, to redirect to the current command stream the standard input
 * there is a need to write: "<code>&lt;&lt;EOF\n .... \nEOF\n</code>".
 * <p>
 * To force the syntax preferences (which by default are taken from
 * the current platform), include: "<code>-Dshell=<i>x</i></code>", where
 * <i>x</i> is <code>UNIX</code>, <code>WIN</code>, or <code>DCL</code>.
 * <p>
 * To force the width of the text of messages issued by Cli, use the
 * <code>-DCOLUMNS=<i>n</i></code>, where <i>n</i> is the number of
 * columns (typically <code>$COLUMNS</code>).
 * <p>
 * To define the version, use the manifest addition:
 * <p><pre>
 *     Implementation-Title: "application"
 *     Implementation-Version: "version"
 *
 *     jar cmf manifest-addition jar-file input-file(s)
 * </pre><p>
 * <p>
 * <b>Name-value pairs</b>
 * Cli can be used to parse commands which are made by pairs of names
 * and values separated by the equal sign, such as tags in html files,
 * or environment variables, or property files. This is obtained by
 * the <code>QVALNVP</code>. When it is enabled, parameters in command
 * definitions are irrelevant (i.e. only the qualifiers are considered).
 * <p>
 * In html, entity names (command names) and attribute names (qualifier names)
 * are case-insensitive. Attribute names may have values which can be quoted
 * both with `<code>"</code>' and `<code>'</code>'. A string with one kind
 * of quotes can contain occurrences of the other. Quotation is optional
 * for values which contain alphanumerics, dashes and dot.
 * Values can contain numeric character references and character entities,
 * whose notation is: `<code>&#</code><i>d</i><code>;</code>'
 * or `<code>&#x</code><i>h</i><code>;</code>'
 * or `<code>&#X</code><i>h</i><code>;</code>', where <i>d</i> is a decimal
 * number and <i>h</i> and hexacedimal number denoting the Unicode
 * value of the character. The character entities are the ones defined
 * in the html recommendation (like, e.g. `<code>&lt;</code>').
 * To parse html tags, use the mode: <code>HTML</code>.
 */


/*
 * Design of syntax
 *
 * Commands which are read by shells are first parsed by them. Shells
 * provide a basic means to quote characters, which must be used when
 * introducing characters which are special for shells. For Unix shells:
 *
 *     # \ ;  ' " `  &   (   )   |   <   >   new-line   space   tab
 *
 * Within "...", '\' quotes only \ ` " and $.  To introduce a " within "...",
 * there is a need to quote it, not to double it (which has no effect, it
 * is simply irrelevant).
 * Moreover, outside "...", '\' quotes any character, while inside it is taken
 * as such if not followed by one of the characters mentioned above.
 * An argument which is "" is considered as an empty argument (i.e. it is
 * not discarded).
 * There is a difference between Unix and Windows shells for the treatment
 * of arguments: the Win shell makes no argument breaking and no quoting:
 * each command can do what it likes. Thus, the treatment of arguments
 * that will be referred to Windows here is the one that JRE does.
 * For Windows, the special characters are: & | ^ > < (and at times , and ;).
 * Apparently JRE performs the same argument lexical processing as MS Visual
 * C++ does: first Win replaces the parameters (delimited by %, e.g. %p1%),
 * then it reduces the escape sequences made by ^ followed by one character
 * by removing the ^, and asking "More?" if it is at the end of the line,
 * then it passes the line to JRE which breaks it into arguments, blank
 * or tab separated, having "..." as quotation. Backslash can be used as
 * escape only when a sequence of backslashes is followed by `"': in that
 * context \ acts as escape for \ and ". A non-closed quotation is taken as
 * closed. A sequence of three ", i.e., """ stands for a ". More precisely:
 *
 *     1. a command line is broken in arguments, which are the sequences of
 *        characters delimited by space, tabs or the end of line, unless
 *        enclosed in double quotes.
 *     2. the shell special characters (& | ^ < > space tab) need be enclosed
 *        in double quotes to become part of arguments. Alternatively, the
 *        escape character ^ can be used to quote the next character, which
 *        can be any character other than \, ", space and tab. When it precedes
 *        a \, ", space or tab, a ^ is discarded and the following character
 *        keeps its special meaning. The quoted characters become part of the
 *        arguments with quotation and escaping removed. However, an argument
 *        consisting solely by two " (i.e. "") it is considered an empty
 *        argument.
 *     3. a sequence of \ characters followed by a " represents a \ for each
 *        couple of \. If the number of \ is even, the following " keeps its
 *        special meaning, otherwise the last \ quotes it.
 *     4. a ^ at the end of the line allows to continue a command on the
 *        following line.
 *     5. a non-closed quotation (" without an ending ") is considered to be
 *        closed.
 *     6. a sequence of three " represents one ".
 *
 * There is a need to provide a mechanism to quote characters which are special
 * for Cli also. There is a need to find appropriate lexical rules for commands.
 * The quoting mechanism in Cli is provided to allow to introduce special
 * characters in qualifier and parameter values. Shells also provide a
 * quoting/escaping mechanism, but allow to use it anywhere.
 *
 * The goal is to avoid to use two mechanisms to quote special characters.
 * The quoting is used to introduce special characters, and that holds for
 * shells and Cli. Consider these examples:
 *
 *     command -x = " a b" -y    (1)
 *     command "-x = a b -y"     (2)
 *
 * Cli should consider the argument " a b" as quoted so as to let the space
 * be part of the value in (1). In fact, if a space is present in an argument,
 * it is there because it has been quoted. But since in shells, quoting can
 * be used everywhere, in (2) the quoted argument could be considered as a
 * parameter value, or as a qualifier, or as an error.
 * Ideally, a command introduced in a shell should be the same as when
 * passed directly to Cli. The above example shows that such is not entirely
 * the case. However, there is a need to get close to that as much as possible.
 *
 * If an argument contains special shell characters, then it has been quoted,
 * if it does not, it might have been quoted or not. Thus, it is not possible
 * to tell if quoting has been used in the first place. This means that arguments
 * which do contain special characters ought to be considered only as <elements>,
 * while for the others Cli makes a choice. Since it may not consider them
 * as quoted because otherwise it would never match qualifier names, it must
 * consider them as unquoted.
 * Case (2) is debatable: it could be considered as a parameter on the ground
 * that it is quoted, and not preceded by a qualifier name. However, that
 * seems strange. It could also be considered as a qualifier on the ground that
 * there is no general way to introduce parameters which start with the
 * qualifier indicator (- or /). E.g. since "-x" must be considered
 * as -x, then it seems pointless to allow a parameter to start with - only
 * when it contains special characters, e.g. "-x ". That means that all arguments
 * are scanned to determine if they are parameters or qualifiers, and parameters
 * may not start with the qualifier indicator. When commands are read by Cli
 * quotation can be used in a more sharp way: "-x" would denote an element
 * and not a qualifier. I.e. quoted elements can contain also terminators.
 * If an argument starts with a qualifier, then parsing proceeds in it.
 * Spaces in it are not special characters (if they are there, they
 * have been quoted). If the qualifier allows a value and allows it to be
 * immediately attached to it, then a value (or a value list) is matched,
 * otherwise an error is reported. If the value is a list, it is broken in
 * colon delimited elements, otherwise all the rest of that argv is taken
 * as its value.
 * When parsing argvs, embedded (i.e. quoted) spaces are always normal
 * characters.
 * If the user wants spaces to have their delimiting effect, then it should
 * not quote them. Qualifiers which allow a value separated by : or = will
 * have the rest of the argument be that value: "-x=a b -y" is as -x= "a b -y",
 * "-x = a b": is as -x " = a b".
 * Parameter values (including value list elements) and qualifier elements are
 * essentially shell arguments. The only one case in which this is not true
 * occurs when qualifier names are attached to values, like e.g. "-a= b", in
 * which they are the part of shell arguments which follows immediately the =.
 *
 * Qualifiers which allow no separator have the rest of the argument as their
 * value: "-xa b -y" is as -x "a b -y", qualifiers which require a separator
 * would not match the above example; they sould be written as: -x "a b -y".
 * I.e. when NONSEP is set, the value is the part after the qualifier
 * name, including a space, if present. E.g. "-x aa", value: " aa".
 * If NONSEP is not present, an error occcurs because the space there is
 * not matched as a space, and -x "aa" must be written instead.
 *
 * In DCL mode, terminator characters (, / etc.) may not be part of elements,
 * not even quoted (as for qualifier elements).  In Unix mode, and only when
 * QUALSL is selected, / may not be part of elements.
 * Arguments which are not lists of values can contain any character, while in
 * all other cases they may not contain terminators.
 * E.g. in  -x= "a :b" the first value is "a ".
 *
 * When Cli parses arguments it is as if it literalized the arguments, i.e.
 * surrounds with " the ones which contain unquoted spaces, tabs or ",
 * or lowercase characters for shells which make a case difference.
 * This quoting of the argvs received from shells by Cli (when needed) is done
 * virtually: the argvs are kept as they are, and the parser takes into account
 * that they should be considered as quoted. Skipws would not skip whitespace
 * in argvs.
 * Empty argvs must be quoted because shells consider "" as a void argv.
 *
 * Another alternative is to detect that is starts with a qualifier name, and
 * then to consider the spaces in it as spaces, i.e. to consider it as unquoted.
 * This, however, seems to negate the reality that the quotes are present.
 *
 * Let's then consider the passing of characters which are special for Cli.
 * When commands are introduced through a shell, quotation is needed to
 * introduce some characters when they need occur with their special meaning
 * and also when they need occur in elements.
 * E.g. consider a ) to be introduced in a value, and also used as a value
 * list terminator. If we write:
 *
 *    command -x = \(a,b\)
 *
 * (a,b) is passed as argument, and interpreted as a value list, but
 * then to pass `)' as part of an element there is a need to write something
 * different, and to compare it with what would be written if it were to be
 * passed directly to cli, like e.g.:
 *
 *    command -x = (a,"b)b")
 *
 * which works for Cli, but not through a shell because (a,b)b) is passed.
 * The idea to let elements which have special characters be introduced as
 * distinct arguments, does not avail either. E.g. in:
 *
 *    command -x = \(a , b\)b \)     or
 *    command -x = \(a , "b)b" \)
 *
 *    or, in Win:
 *
 *    command -x = (a , b)b )
 *
 * ( and ) are also arguments, and thus they may not be distinguished from the
 * ones which are inside elements.
 * Moreover, this would have the unfortunate consequence to make commands queer
 * in terms of spaces: the intuitive rule that whitespace need be written only
 * when necessary to separate lexemes is no longer valid here since there
 * is a need to put a space before the ) that closes the list.
 * The problem is that in this rule any element must be terminated by
 * a space, otherwise any character which follows it is part of it.
 * On the other hand, a Unix user is accustomed to such strangenesses.
 * In conclusion, it is not possible to write in a shell the same command
 * that would be passed to Cli because:
 *
 *    command -x = \(a,"b)"\)
 *
 * would mean (a,b)) or "(a,b))" for Cli. The problem is that the double
 * quotes are treated by shells, and are not passed to Cli, which could
 * have used them to distinguish the usage.
 *
 * Another solution is to use the double quotes for Cli quoting and let
 * the user pass them to commands. E.g.
 *
 *    command -x = \(a,b\\\)b\) or \(a,b\"\)\"b\) or "(a,\"b)b\")"
 *    or -x = '(a,"b)b")'
 *
 * This would leave the user free use of whitespace. It would need, however,
 * to have two quotation mechanisms to introduce special characters, as
 * shown in the example. In this solution, to rebuid a command there is only
 * a need to separate arguments with spaces.
 *
 * Another alternative is to adapt the Cli syntax to the shells' ones. The only
 * characters which cause problems are the ones which are special for shells and
 * also for Cli, e.g. ( ) which are used in Cli to enclose a list of qualifier
 * values.
 *
 * Let's see what syntax is commonly used in Unix and Windows. In Windows,
 * commands use / as qualifier indicator.
 * In Unix, it is not common to have value lists for parameters which are
 * separated by , or +. It is more common to have them separated by spaces:
 * the list terminates when a command qualifier occurs.
 * This means that a command which accepts a list of input files and an
 * output file would look as: command f1 f2 ... fn -o outfile
 * Value lists for qualifiers are at times separated by , (e.g. -Wx of cc)
 * or by : (e.g. for paths) or by repeating the qualifier (e.g. -y of ld).
 * Local qualifiers are represented simply by qualifiers which are positional,
 * like e.g. the -l:file of ld. That option could correspond to a value element
 * (file) in which the local qualifier is written before the value, or to an
 * empty value element in which the local qualifier and its value (file)
 * is written after the empty element. If this is the only one syntax of
 * local qualifiers, there is no problem, otherwise there is a need to
 * flag the ones which are written before, so as to parse -l:f1 -l:f2
 * as two separate value elements (and not reject it as a duplication).
 * Note that -l:f1 -l:f2 lets you use any character for file f1, while
 * -l:f1:f2 requires quoting f1 if it contains a :. The posifix form would
 * be f1 -l f2 -l. The former is accepted as equivalent to the second
 * one by stating that valueless qualifiers can be written in front of
 * elements as well as after them. If a valueless qualifier is followed
 * by :, it is considered to be appended to the next element. If it
 * is not followed by it, it is appended to the previous one.
 * In Unix, it seems not at all common to have local qualifiers and even the
 * less to have them appended to arguments (the latter may be due to the fact
 * that it would restrict the characters which may be part of filenames.
 * E.g. in -o file any character can be used for file, while in file-o the
 * - may not, unless it is separated from the file by a space, wich makes a
 * bit unclear that such options is attached to the argument).
 * To tell the whole story, in Unix it is not generally possible to pass
 * filenames which start with - (they need be passed as ./-file).
 * What seems not common in Unix is to have value elements with attached
 * local qualifiers with a value (i.e. the three things together).
 * Note that there is still a need to quote characters which may not be
 * part of elements in qualifiers. E.g. if they are separated by :, then :
 * may not be part of elements, and to pass it, quotation may not be used,
 * (e.g.: -a=\"xx:xx\":y or -a="xx:xx") because quotation acts at the shell
 * level, and disappears when commands are passed to Cli (when Cli parses argv
 * commands it disables quotation processing since it would be a second
 * quotation in addition to the one already done, which makes quotation
 * difficult to understand).
 * The chosen solution is to disallow elements in value lists to contain :,
 * and let elements not in value lists to contain it. This is important since
 * many qualifiers have as value filenames. This allows to write value lists
 * without spaces in the middle, which is common in Unix.
 *
 * Note that if elements in value lists of parameters are separated by spaces,
 * then spaces may not be used to separate elements in qualifier values
 * (otherwise after a local qualifier name which allows a list, there is no way
 * to terminate that list and continue with another parameter element), and
 * another charactre must be used, like e.g. colon.
 *
 * An element terminates a preceding element in a parameter, and a global
 * qualifier terminates a preceding parameter value list.
 * After parameters, only local qualifiers are matched. When a qualifier
 * is found, but it is not a local one, the parsing of a parameter ends.
 *
 * A qualifier list terminates when an element is not followed by the separator.
 * Empty elements are "", e.g. -a= "" :b. The spaces are necessary for the
 * shell, not when a command is read directly by Cli.
 *
 * Qualifier values may not start with the qualifier separator, otherwise
 * it is not possible to omit a value. E.g. in -a -b, the latter -b would be
 * taken as the value of -a. This is uniform with the values of parameters
 * which may not start with - because qualifiers are matched first.
 * Allowing - in qualifier values makes no longer possible to write them
 * one after the other /a=x/b=y -> -a=x -b=y. This is quite common in Unix.
 *
 * In prefix qualifiers, like e.g.:  -l:f1 -l:f2 the second -l initiates
 * a new element, and thus it is not matched when parsing the postfix
 * qualifiers of the current element. It is matched instead at the beginning
 * of the parsing of elements.
 *
 * To handle empty (i.e. "") argvs, skipws does not skip them. When it finds
 * one, it delivers a buffer which contains a NUL so as to make easier the
 * scanning. This works because a NUL may appear in a command only in elements,
 * and before parsing them, a test is made to match an empty argv, which allows
 * to have elements start with NUL without being confused by empty argvs.
 * To match an empty argv the getEmptyArgv() method is provided.
 *
 * Miscellaneous syntax issues:
 *
 * When - and + start qualifiers, to let signed numbers as values, the
 * syntax allows elements which start with +|- followed by a (Unicode) digit.
 * This, alas, does not allow to pass negative hexadecimal numbers without
 * a base.  Digits in any language are accepted to make syntax simple.
 *
 * To introduce the string delimiter in strings, there are two choices:
 * 1. to double it, i.e.: "", or to quote it, i.e.: \". In the second
 * case there is a need to write \\ to introduce \, i.e. there are two
 * characters which are special, while in the first case there is only one,
 * and there is also a need to decide if \ escapes any character or only
 * \ and ". The first alternative is simpler, and thus it is used.
 *
 * The problem with the numeric base is that the Java notation for octal
 * numbers is faulty: in many cases a number can be preceded by a 0 without
 * meaning that it is octal. It would be better to use another notation.
 * However, there is no one which is broadly used.
 *
 * Named parameters
 *
 * It could be possible to introduce named parameters, i.e. parameters which
 * are indicated by a name in front of them. They would be declared as
 * parameters, but with a name. In the main parse_args loop, when searching
 * qualifiers, they would be searched also, and after having parsed the name,
 * parsing would continues as for parameters.
 * They are not exactly the same as qualifiers because value lists in
 * parameters are different from the ones in qualifiers. This would introduce
 * a new syntactical element whose expressive power would be very similar to
 * that of qualifiers. Instead of this, (global) qualifiers have been
 * enpowered by allowing local qualifiers in their elements (which are not
 * value lists).
 *
 * Alternatives
 *
 * There are commands in which a (tag) qualifier determines what other arguments
 * are allowed. The first technique is to parse the arguments, and if they are
 * not recognised, then another try is done with another set of argument
 * definitions. There is a need to avoid rereading an indirect file which has
 * already been read in a previous try.
 * Another solution is to indicate in the command definition the alternative
 * arguments. Each alternative in a set could start with a command qualifier
 * and proceed with parameters and qualifiers. It is hard to recognize
 * alternatives just only on parameters.
 * Note that it is different to have a choice among a set of qualifiers and
 * among a set of parameters because for qualifiers it is easy to detect which
 * qualifies are present and then to test if the condition is satisfied.
 * For parameters, when one is being parsed, and the alternative in which it
 * is defined is already the one taken (because at least a qualifier in
 * it has been parsed), it is easy to match it. When instead no one altenative
 * has been taken, then the parser can only match it to the first one which
 * has a parameter in it. However, if later on a qualifier is encountered
 * which belongs to another alternative with a parameter in it, the parameter
 * need be matched to that one. If the parameter is not a list and all its
 * local qualifiers are not lists, and its value type is string without
 * attributes, then this can be done without reparsing it. In general, however,
 * there is a need to reparse it.
 * To complicate things, there are commands which allow several variants,
 * having also some qualifiers present in more than one. In this case Cli
 * has to determine which of the alternatives is the one present. But then
 * it can also detect which parameters are present looking at their type.
 * Currently, a parameter can be specified only if the preceding ones
 * have been specified also. However, there could be a possibility to
 * omit some of them on the basis of their type, and also to specify them
 * in a different order. E.g. if a command has a string and an integer
 * parameter, since it is possible to tell one from the other, it would also
 * be possible to write them in any order. However, this is beyond the
 * target of Cli.
 * This seems to complicate Cli too much.
 * 
 * Some Unix commands display the alternate forms: several rows indicating
 * the same command with alternate sets of arguments. This is not supported.
 *
 *
 * Default arguments
 *
 * The presence of them depends on the application, and apply normally
 * to all its commands (if more than one). Thus, disabling is not done
 * on a per command basis, but with a mode.
 *
 * Processing is done by testing in parse_args after the processing of global
 * qualifiers if one such qualifier has been matched. In such a case
 * it is processed, and then parsing stops with a return of NULL_COMMAND.
 * The processing of these qualifiers scans them, and stops at the first
 * which has been found. Note that they do not have a short name so
 * as to prevent to use qualifier combinations.
 *
 * When a parameter has a qualifier whose name is the same as that of a
 * default qualifier, the default one is hidden after a parameter, but not
 * before it since there it has the normal meaning (and there parsing stops
 * also). This is misleading because in some places they can be used and in
 * some others not. Therefore, when a default qualifier has a name (or a
 * short name, even if it is not the case with the current ones) which
 * clashes with a global or local qualifier, that default qualifier is
 * disabled.
 * When printing usage messages, the disabled qualifiers are not printed.
 *
 *
 * Command definition
 *
 * Arguments have two names: a physical name to be specified in commands,
 * and a logical one to be passed to access methods. It is useful to have
 * since the logical one is a reference to be used in programs, that could
 * be different from the physical name e.g. to avoid name clashes since
 * local qualifiers can have equal names, and in general in a program there
 * could be names that clash with argument names, and when commands are
 * localised.
 *
 * A clear way for defining commands is that in which the statements that define
 * commands enclose the ones which define the arguments.
 * There are two alternatives: to define an array of commands, or a list
 * of commands. However, lists need be defined in reverse order, and each
 * element need be declared.
 * A list has the advantage that a single command has the same type as a list
 * of commands.
 *
 *   private static final Command cmd =
 *      new Command(name...,new Argument[] {
 *      new Argument(...),
 *      new Argument(...),
 *      }
 *   );
 *
 *   list:
 *
 *   private static final Command cmdlist = new Command(name...,cmd2);
 *   private static final Command cmd2 = new Command(name...,cmd3);
 *
 *   array:
 *
 *   private static final Command[] cmds = {
 *       new Command(name...),
 *       new Command(name...),
 *   }
 *
 * It is possible to write:
 *
 *   CMD_XXX = new Qualifier (...)
 *
 * CMD_XXX must be declared before, and thus there is anyway a need for a
 * separate place to declare it. Nonetheless, it simplifies maintenace.
 * Note that there is still a need to indicate the parameter and the
 * qualifier in method calls such as value() because a same set of qualifiers
 * can be specified for more than one parameter. Moreover, a same argument
 * can be referred to from different commands.
 * Internally, since it is not possible to store sequence numbers into
 * arguments (because of sharing), to determine the sequence number of an
 * argument from its reference, a sequential search is done on the tree
 * of arguments. Since commands do not have many arguments, that is not slow.
 * However, THIS DOES NOT WORK WITH LOCALISED COMMANDS, and thus the indexes
 * are used instead.
 *
 * Checks on the definitions
 *
 * A cli object is created and initialized with its case sensitiveness, then a
 * commad checked, and then the object might be reinitialized with the opposite
 * case sensitiveness. This could make the already checked command illegal.
 * E.g. a command which is case sensitive can have two "aaa" and "AAA"
 * arguments, while one which is not sensitive must not have them. The same
 * holds for the negated form.  To detect it, the case selection is registered
 * in the commands when they are checked. When an already checked command is
 * used, the check is redone if the case constraint is different from the one
 * in force when the previous check was done.
 * parse() calls def_check that marks its attribute field as checked to skip
 * the check the next time it is called. This serves also to handle multiple
 * commands.
 *
 *
 * Internal form
 *
 * To represent internally the data of an actual command, a solution is to keep
 * a list of descriptors, in arrival ordering, to store the data of the
 * parameters and their qualifiers. This makes access to values slow because
 * there is a need to scan them. That is contrary to what an internal
 * representation is: the internal representation usually is independent on
 * the syntactic details and on the ordering in which the elements are
 * specified (unless significant, which is not the case here, on the contrary,
 * qualifers are named to allow to specify them in any order).
 * Another alternative is to keep an array, ordered in the same way as
 * the argument table. This makes access fast, expecially if done with
 * an index. Of course the latter does not allow repetition.
 * Descriptors could be allocated only for the specified arguments so
 * as not to waste space when a command has several arguments defined,
 * but only some specified. However, since descriptors are small, they
 * are allocated all together,
 * The problem with the internal form is that each value in a list of
 * a parameter can have local qualifiers.
 *
 * If multiple occurrences of a same qualifier were accepted, and only
 * one of them kept, the preallocated array of descriptors is sufficient.
 * If multiple occurrences were allowed and all of them significant,
 * then there would be a need to allocate descriptors dynamically.
 *
 * There is a need to record in elements enough data to allow access
 * methods to rescan the text of the elements. Some are located in
 * command segments, some in load areas.
 * A possibility is to keep a reference to the (begining of) the piece.
 * This, however, does not allow to move from one element to the
 * next one when a parameter's or qualifier's value is a list and the
 * value elements are in different command segments.
 * A solution is to keep the argument number instead. This, however,
 * does not work for load areas since they have no argn numbers associated.
 * This is a pity because the space for an argument number must be reserved
 * anyway in elements, and for load areas there is no need to keep an argn
 * (since arguments in them may not continue on a next segment); there
 * is, however, a need for a reference.
 * Convention:
 *
 *    ini     index of first character
 *    argn    argn of buffer, -1 if main command, -2, etc. if in load area
 *    cursor  current index
 *    argc    argn of cursor, as above
 *    end     end index of the element. It serves to determine that
 *            all the values have been delivered out of a value list.
 *    arge    argn of end, as above
 *
 * The end field in elements serves to deliver correctly a last empty
 * element in value lists. I.e. in a value list which allows empty elements,
 * like e.g.: "a,b,,c," (note the last comma), when the "c" element is
 * delivered, the cursor is moved past the comma, and then there is
 * a need next time to deliver an empty value, and only once. To do so,
 * the cursor has to be different after the delivery so as to know the
 * second time that the list has been completed. This is possible if the
 * end cursor of the list is known.
 *
 * Load areas are stored in an array of load descriptors.
 * N.B. elements are not used to store load areas references because
 * it is better to leave them for expansion for repeated parameters.
 *
 * Skipws is restarted by putting these values in the corresponding
 * ones of the Cli object.
 *
 * For parameters, the ini field in the element descriptor points to the
 * start of the value, for qualifiers that never allow a value it points
 * to the start of the name, for qualifiers that do not have a value
 * specified (e.g. when the negated form is present or when no value
 * of an optional qualifier is specified), the ini field points to the
 * end of the piece in which the argument lays, and the end as well; for the
 * others it points the the start of the first value.
 * There is a special handling of argvs which are empty: the ini
 * and argni fields refer to an empty string; however, they are also
 * equal to the end fields (note that when Cli is not in argv processing
 * that is not the case since an empty value is "" there, 2 characters, not
 * an empty string). The first time a cur field which is equal to the
 * end one is accepted and advanced so as to reject it the next time.
 *
 * Arguments are numbered sequentially so as to have a unique index to denote
 * them to index the elements table. The difficulty is that the parameters
 * can also be shared among commands. This means that it is not possible to
 * store in them a sequence number. A map argSeq is build when initializing
 * a command, which holds the sequence number of top-level arguments.
 * Sequence numbers start at 0 for the command, 1 the first argument, etc.
 * For the default qualifiers, the convention is that they are numbered
 * from -2 downwards in methods. This allows to keep them independent
 * from commands.
 *
 * Currently, default qualifiers have no data attached, except for the
 * indirect file. They are stored in the element table after the data for
 * the arguments so as to allow to test them for presence, etc.
 *
 *
 * Parsing
 *
 * There is a basic choice in parsing: a solution is to make a fast syntax
 * check, and record little information in the internal form.
 * E.g. all values in a list and their qualifiers are kept all together as
 * a string. As a result, access needs to scan again the values to extract
 * data regarding the qualifies. Alternatively, a list could be kept for
 * the elments in which each element has a table for its qualifiers.
 * The first alternative is chosen because the time spent in parsing is not
 * big, and on the other hand representing these data in the internal form
 * is rather complex. The first solution allows also to save memory with
 * respect to the second one: to represent completely a long command
 * there is a need for a considerable amount of memory to store descriptors
 * for all its arguments, their values and qualifiers.
 * There is thus a method that makes a check on the command definition,
 * which is run only once to detect errors and prepare the internal form,
 * and some access methods that can be called at will to extract the data.
 * The latter does a second parsing to access the data.
 *
 * The information recorded when parsing is done allows to access more
 * easily, and randomly the information present in the command. E.g. it
 * is possible to test if an argument is present. Access to parameters
 * and global qualifiers can be done randomly becuase the references to
 * the beginning of them is kept. Access to local qualifiers, when
 * specified on value list elements needs to access the value first,
 * which reloads the references to the local qualifiers.
 *
 * Qualifiers and parameters are scanned in a loop. When no parameters have
 * been encoutered, qualifiers are global; after a parameter they can be
 * either global or local. There are no problems with ambiguity between global
 * and local qualifiers: a solution is to let the local ones take precedence,
 * anoter to rejected ambiguity. The latter is chosen because it is more clean.
 *
 * Matching of qualifier names: there are two solutions: 1. a max lenght for
 * names is fixed (e.g. only the first 32 characters are significant), or the
 * lenght is determined and then a string allocated, a qualifier name copied
 * and converted in a known case (upper or lower) and matching done.
 * 2. have a method that makes a case insensitive match. The second is chosen
 * because neither limits the length nor requires dynamic memory.
 *
 * Parsing and matching of negated forms: there are two solutions.
 * 1. have a method that gets a qualifier name, which is told to return
 * the name trimmed by the "no" or to return the whole name (when the qualifier
 * is not negatable and has a case-sensitive name for which it is important
 * to have the "no" as written to make a correct match). 2. to have the
 * method return the name as such, and let the matching method to discard
 * it or not according with the attributes of each qualifier. The second is
 * chosen because it makes a better separation of concerns between scanning
 * and matching. When matching, a qualifier is considered to have two names
 * when it allows negation: one natural and another with "no" in front of it.
 * There are then two alternatives: a) to scan all the qualifiers first
 * for an exact match between the defined names and the one to match, and
 * then again when the one to match starts with "no", with the "no" removed.
 * This requires to visit the global and local ones and then again.
 * b) to scan the global and the local ones, and for each qualifier make
 * first an exact match and then the negated one.
 * Clearly, the two alternatives give a different match if a "none" and a
 * "ne" negatable qualifiers are present. In order to make the meaning of
 * commands clear, ambiguity is disallowed. The conditions on two names
 * n1 and n2 are:
 *
 *    1.  n1 != n2, and
 *    2.  if n1 is negatable, then NOn1 != n2, and
 *    3.  if n2 is negatable, then n1 != NOn2, and
 *    4.  if both are negatable, then NOn1 != NOn2
 *
 * The case of the NO of course is determined as usual. These conditions
 * take into account that names can start with "no" as they are specified
 * in a qualifier definition.
 *
 * There is a mode in which abbreviated forms of qualifier names are accepted.
 * A match on qualifier names is done when there are enough characters to make
 * it non ambiguous. More precisely, if there is a qualifier with that exact
 * name, it matches. If there is one that has that name as head, that one
 * matches. If there are more than one, an error is returned.
 *
 * The matching when abbreviated forms are allowed and at the same time
 * negation is enabled is done in the usual way: all the relevant argument
 * names are taken in sequence, each one with its normal and negated form,
 * stopping if an exact match is found (in which case the checks on the
 * command definition guarantee that there is only one such exact match),
 * are counting otherwise the number of partial matches up to the end
 * of the arguments to check that there is at most one such match.
 * This makes possible to have two qualifiers, one of which has a name
 * that is a head of the second one, like e.g. "now" and "nowhere",
 * and have "now" match "now" only.
 * Abbreviations are more costly to treat because when a weak match is
 * found there is still a need to continue in order to find if there is
 * an exact one (which takes precedence) or another weak one (which is
 * an error).
 *
 * In elements, the cur field is initialised by parse() for the top level
 * arguments and by par_element() for the local qualifiers. It is kept
 * then running by value().
 *
 * The detection of a last empty element in a list of qualifier value
 * elements is not easy because when the previous element is parsed, also
 * the list delimiter following it is scanned, and then the cusor points
 * to the end of the parameter. There is thus a need to distinguish this
 * condition, in which a value() must return PRESENT, from the one which
 * holds after that call so as to make a subsequent call return ABSENT.
 * The current technique is to store -2 in ele.cursor as a special value to
 * denote this state.
 *
 * When parsing parameters and qualifiers, a temporary element is used to keep
 * the data, which are written back into the element table upon successful
 * matching, so as not to store in the element table elements which are not
 * consistent, which can occur when an error is found.
 *
 * It is not difficult to treat prefix qualifiers in value() because
 * in par_element the transfer of characters to the value() is enabled
 * only for the parameter element, not when parsing qualifiers, which can
 * then occur before or after the parameter element.
 *
 * Parse_args scans the argvs which contain lists of values instead of
 * letting this be done when value() is called because there is a need to
 * detect errors in elements.
 *
 * Parse() is incremental. This makes possible to avoid to reparse the
 * whole command when missing required arguments are requested.
 *
 * A field curpar is needed to keep the number of the last parameter parsed
 * so as to know which is the parameter descriptor to be used when a new
 * one is encountered in the command. This is different from the current
 * argument, which reflects the last argument, and thus changes when a
 * global qualifier is parsed after a parameter.
 *
 * When a qualifier with AR_ALT is matched, a check is done that no one
 * else in the same alternative is present.
 * When checking for mandatory qualifiers, in a same alternative all
 * qualifiers are checked and one must be found present.
 *
 *
 * Access methods
 *
 * There is one parsing method and several methods to extract the data from
 * the parsed command so as not to disclose the internal structure used for
 * parsing.
 *
 * Commands are parsed first to make a syntax check and to get the indexes
 * to the start of their global qualifiers and parameters. Then with
 * present() it is possible to test the presence of these arguments,
 * and with value() to get their values. Subsequent calls deliver values
 * of the arguments which allow a list of value. Once a value() has
 * been executed on a parameter, it it possible to test the presence and get
 * the values of its local qualifiers. Each subsequent call to value()
 * delivers the next in a list and allows access to its local qualifiers.
 * Note that present() does not deliver the same status as value()
 * because it reports the presence of an argument as a whole, while value()
 * reports the presence of its value(s).
 * For arguments which are not lists, value() can be called several times to
 * fetch the value.
 * value() applied to qualifiers which do not allow a value delivers
 * ABSENT, as it does for qualifiers which have no value (e.g. -no form).
 *
 * Status of the elements for local qualifiers after the first pass: it would
 * be nice to have them denote the first value element specified, so as to
 * allow direct access to it. It is, however simpler to reset them so as not
 * to make a difference in the way the first value element is obtained with
 * respect to the other ones: value() need be called on parameters before
 * calling it on local qualifiers.
 *
 * The same methods are used to get the values and to parse them, and the
 * same for the qualifiers. During parsing the indexes of the start of
 * arguments are set, during access these indexes are taken to become the
 * ones to start with. It is possible to copy the current one in them before
 * and after. During access there is a need to copy the strings of the vaules.
 *
 * It is possible to make an application which has a command definition in
 * it call methods of a library which needs to access a known argument by
 * passing the index to the argument to the library.
 *
 * It might be useful to call a cmd parser that does all the work and
 * returns the internal representation of values in locations. This,
 * however, does not treat presence, repetition of elements and lists
 * of values. To support lists of values there are two alternatives:
 * 1. a list, or an array with the values is returned, but this does
 * not allow to return local qualifiers, and 2. to make value()
 * return the representation in the location each time it is called.
 *
 * A command has the following semantic structure:
 *
 *   command
 *      |-- global qualifier
 *      |       |--- element
 *      |       |       |--- local qualifier
 *      |       |       |       |--- element
 *      |       |       |---... |--- ...
 *      |       |--- ...
 *      |       |--- element
 *      |-- parameter
 *      |       |--- element
 *      |       |       |--- local qualifier
 *      |       |       |       |--- element
 *      |       |       |       |--- ...
 *      |       |       |       |--- element
 *      |       |       |--- ...
 *      |       |       |--- local qualifier
 *      |       |--- ...
 *      |       |--- element
 *      |-- global qualifier
 *      |-- ...
 *      |-- parameter
 *      |-- ...
 *
 * Of course, to give an internal representation of this it is also possible
 * to provide:
 *
 *    command:     element[]
 *    qualifier:   element[]
 *    parameter:   element[] in which each element can have an element[]
 *
 * I.e. if in the Element there is an Element[] field, then it is possible
 * to represent the whole tree.
 *
 * Ideally, a command could be represented by a class: a class has fields
 * which have a name and a type. Fields can represent arguments. However,
 * there is no notion of short name, optionality, use message, etc.
 * Moreover an argument name is localised, while a field name must not.
 * All this information regarding arguments is "class data", which could
 * be represented as static fields. Each argument could be represented
 * by two fields: an instance one and a class one that are related by
 * a name convention. There could be an efficiency problem when scanning
 * these fields because the reflection classes must be used.
 * Alternatively, an array of argument descriptors can be used, which,
 * however, brings the definitions of the instance field and that of its
 * associated class one apart.
 * An instance of such a class would be the internal representation of a
 * command.
 * A set of commands would be represented as an array of classes. When
 * a command is matched there would be a need to allocate an instance of
 * its corresponding class. With the current technique there is no such
 * a need (unless locations where to store the arguments values are defined).
 * An alternative solution is to define the arguments separately from the
 * class that originates the fields to store their values.
 * Fields and argument descriptors would be linked by the field names.
 *
 *
 * The verb
 *
 * A program has an (intrinsic) name, which might have been replaced in
 * scripts by an alias, or by the name of the executable file. The intrinsic
 * name is the one that is used in general to refer to the program.
 *
 * In Unix programs, argv[0] contains the path of the executable, including the
 * directory, if specified. Moreover, when an alias has been used, the actual
 * verb is the replacement string for the alias. With a symbolic link, it is
 * the symbolic link. With a PATH it is the name of the executable with no path
 * in it.
 *
 * The name (intrinsic or actual) is automatically included in the command
 * so as to have it printed when a command is copied in a listing or report
 * file. The intrinsic or actual names can be retrieved by a program at will:
 * the intrinsic one is pointed to by the name field of the command descriptors,
 * the actual one is mainFile. The issue is then which name should go in the
 * command. Usually, the verb ought to be the intrinsic one. The actual verb
 * used to activate a command could only convey the information regarding the
 * version of the program, i.e. the place where a command was when activated.
 * This information could be useful for the program to report, or to test
 * the version, which ought to be present in the program. It is not useful
 * to read some accompanying file present in the directory from which the
 * executable has been activated because it does not always convey the
 * directory path. To retrieve the actual directory of the executable there
 * is a need to use some other system primitive.
 * The purpose to insert the intrinsic one could be to print it in a report
 * showing the true name of the program and not the actual, which could have
 * been changed to meet particular installation requirements. On the other
 * hand, it is true that if the executable has been copied and its name changed,
 * that is perhaps an information useful to print.
 * As a matter of fact, a Java class file may not be run if it has been renamed.
 * Thus, the name of its Class is the one which has been used in the java
 * command that run the program.
 * The usefulness of having the whole path in manFile is not to access
 * files which accompany a program, but to document the real program which has
 * been run. To access such files use getResource():
 * URL u = ClassLoader.getSystemResource("filepath"), where filepath is
 * the path relative to one of the paths in classpath of the file.
 *
 * The intrinsic one is stored in argv[0] so as to make it included in the
 * string delivered by toString().
 *
 * There is a problem with having the actual name in commands because
 * the parsing should be such as to parse it: all the characters which
 * can be in a URI must be treated. This could be done by making parse
 * skip the first arg, or better by making it take whatever is up to the
 * first whitespace as the verb when a whole command string is passed not
 * in arg. This seems a bit odd since it comes from a mixture between
 * the syntax imposed by the system (which is to have arguments contain
 * any character which is not (unescaped) whitespace), and that of commands,
 * which is the one defined here.
 * An additional problem is that in Java the actual name is quite long, and
 * it is an absolute URI that denotes the program, which it is likely to be
 * different from what the user has used to run the program.
 * The actual name is made available in the mainFile field of the Cli object,
 * and can be printed in reports to show the actual program which was run.
 *
 * There are no limits on the length of the intrinsic or actual name.
 *
 * It is appropriate to store the verb as the other elements for uniformity
 * so as to access it in the same way as all other data present in a command.
 * This is particularly true when parse() is told to analize a whole command
 * because e.g. if it is case insensitive, the element can reflect what has
 * actually been parsed.
 * Command is defined as subclass of Argument so as to make the element
 * array map the command also and let the first element to denote the
 * verb.
 * To access the verb with present() and value(), VERB should be passed
 * as argument.
 * The method strValue(VERB) delivers the name which is present in the command
 * string. If the command has been obtained by getcom(), it is the intrinsic
 * one, otherwise what is present in the command string.
 * There could be a problem if getcom() inserted the actual name because
 * in such a case the get_qvelem() done in strValue() might not deliver all
 * of it. In such a case a version of get_qvelem() which stopped at the
 * end of the element should be used.
 *
 *
 * The version
 *
 * In a multithreaded application there could be several threads, each
 * one reading commands, loading classes, and then executing them.
 * The program that creates and runs them calls their main() method and
 * passes it the arguments.
 * The main methods could need to get the class name, file, version, etc.
 * There is a need to be able to write those main methods in such a way
 * as to run also them directly.
 * To do it, the getMainData method takes the last (on the stack) "main"
 * invocation, retrieves its data and stores them in the Cli object.
 * This is done at the first usage.
 *
 * A similar problem holds with system properties: the classes which are
 * called expect to read the properties which are passed in the command
 * invokation, not the ones of the shell. I.e. -Dshell and COLUMNS should
 * deliver the ones of the current command and terminal. But then also
 * the technique to determine if the program is interactive does not work.
 * Unfortunately the Java VM does not handle the creation of threads
 * which inherit the environment (standard streams, properties) from the
 * creator thread, and then act on a copy of them.
 *
 *
 * Command lines
 *
 * There is no limit on the lenght of commands imposed by this class.
 * There could be limits imposed by shells.
 * Commands are made of single lines. To overcome the limitation of length,
 * lines can be continued, forming (virtually) longer lines. This is
 * performed by shells.
 * Since commands terminate ad the end of lines, there is no need to have
 * some terminator that close them (like e.g. a `;' in many programming languages).
 * Newlines end commands, including the pieces which are inside indirect files.
 *
 * Cli supports both commands in char[] and String both either as single
 * string and as vector of strings (command segments).
 * Segments make easier the extension of incomplete commands with arguments
 * that are requested interactively to complete the missing ones.
 * To support interactive commands, it is simpler to treat segments, and the
 * same applies to indirect files.
 * The parsing methods move from an argument to the next when they encounter
 * the end of the current one.
 * This allows to avoid to duplicate commands: there is no need to concatenate
 * the array vector in one single string.
 * When an argument vector is passed, separation between arguments is virtually
 * considered to be white space.
 * By convention, the first field which contains a non-null reference in this
 * order is taken:
 *
 *     field                command
 *
 *     argv                 char[][]
 *     args                 String[]
 *     com                  char[]
 *     coms                 String
 *
 *  comLen allows to set the actual length when the command is in coms or com.
 *  0 means the whole string.
 *
 * Empty commands do not exist because at least the verb is present.
 *
 * If there are inline arguments, getCommand() takes them, otherwise it reads
 * a command from the standard input only if there are mandatory arguments
 * or if STDIN is active.
 *
 * getCommand() in a program activated interactively requests any missing
 * parameters. It reads additional arguments from the standard input, appends
 * them and parses incrementally the command. If there are missing qualifiers of
 * a parameter it exits because in such a case it would be rather difficult
 * to keep all the arguments which follow the offending one in the command.
 *
 * toString() produces commands which are equivalent to the original ones if
 * they are passed directly to Cli. It is not meant to reconstruct commands
 * as introduced to shells (which can also depend on the specific shell).
 * In order not to make Cli depend much on shell differences, the argvs
 * are read and taken as if they had been quoted appropriately: the
 * characters in them have been introduced by using the appropriate
 * quoting, which may depend on the shell.
 * Cli delivers a string out of a command which Cli could read it back,
 * but not necessarily any shell. Such command string is mainly
 * meant to be printed, not to be reparsed.
 * In general, since it is not possible to rebuild exactly the original
 * command, when delivered by toString(), a command can look a bit different
 * from the original one, which could have used double quotes or backslash to
 * pass special characters.
 *
 *
 * Interface methods
 *
 * All the methods work with a Cli object so as to operate on a command passed
 * as argument, not only the one passed to the program by the shell.
 *
 * Usage sequence:
 *
 *    init() which initializes mode, env, repstream, errthrow
 *         help (and internals such as INTER)
 *
 *    check() (with the given mode): optional (called also by parse())
 *
 *    getCommand(), which       |   obtainment of command, which may depend
 *          calls parse_args()  |              on the command definition
 *                              |   parse(), which calls start() that 
 *                              or             initializes the element table
 *                              |              and the current parsing state
 *    present(), typeValue()
 *    restart()
 *    present(), typevalue()
 *    terminate() (optional)
 *
 * init() is separate so as to allow to initialize a Cli object and then
 * use it to parse several commands, possibly of several command definitions.
 * To do it, check() is not called in init(). The definition check is more
 * related to the commands definitions as such than to parsing.
 * All preferences are common to a sequence of commands.
 * The element table is (re)allocated in a separate method, start(), which
 * changes the cmddes and re-allocates the element table. Which means that
 * cmddes is not changed until the start().
 * getCommand() is used to get and parse the command line only, and thus
 * is called with a command definition only (i.e. no command set). The
 * parse_args() called in it parses only the arguments.
 * If there is a need to implement an interpreter, e.g. an application
 * which reads and parses commands, then parse() will parse also command
 * names, and will accept a command definition or a set thereof.
 *
 * Interface:
 *
 *   init()
 *   terminate()
 *   check()
 *   parse()
 *   present()
 *   value()
 *   restart()
 *   getCommand()
 *   toString()
 *   setOnErr()
 *
 *
 * Error handling
 *
 * The fields res ed excObj are cleared at the entry of all user-visible
 * methods.
 *
 * The position at which the error occurred is given in a way that makes
 * easy for the reader to spot it. Since a command is made by concatenating
 * arguments and reducing the spaces between them to one, the index of
 * the point is useless because difficult to spot. Instead, a portion of
 * the remaining string is displayed.
 * To show the position of the token in error, the head of the not yet analised
 * part of the command is printed.
 * When an error occurs, the cursor denotes the start of the token in error.
 * This is also the case when there is an error in a value. The best would
 * be to indicate exactly the character where the value is incorrect.
 * Quoting, however, makes this difficult because there would be a need to
 * have dedicated lexer methods which take into account quoting, instead of
 * using the normal ones which process already de-quoted text. Being difficult
 * to get back the original point in error from the one in the de-quoted text,
 * the cursor is left at the beginning of it.
 *
 * If ERR_ABORT is in effect, abort is done after having printed a message.
 *
 * Some errors have information attached, such as the argument indexes,
 * which is then used to print the argument name.
 *
 * Cli catches Formatter errors explicitly so as to stack a Cli ioerr on
 * top of them, which is better than stacking a "command error".
 * Errors which occur during initialization and def_check are also wrapped
 * so as to allow the user to distinguish them from errors which occur
 * in the command.
 * Stackoverflow is catched because Cli can call callbacks.
 * When an OutOfMemory error occurs, Cli terminates the object so as
 * to free some memory and report the error.
 *
 *
 * Display functions
 *
 * The usage short message displays the arguments in the order in which
 * they are declared (so as to indicate which qualifier is global and
 * which local).
 *
 * The qualifier separator and the value separator shown are the ones
 * that are selected.
 *
 * When a parameter is optional, the parameter and all its local qualifiers
 * are shown enclosed in [ ... ].
 *
 * A parameter or qualifier value which is a list is indicated by the
 * appropriate list separator followed by ellipses.
 * This standard way avoids to put the indication in the usage string,
 * which would othewisew contain delimiters which depend on the platform.
 *
 *
 * Testing
 *
 * It could be a good idea to provide a test probe that allows to exercise
 * internal procedures without exporting all of them. This is for get_parameter,
 * search, etc.
 * The probe is made by letting the user call the public methods, but
 * have in them some control that allows to call the internal methods
 * to be tested, or by having a tunelling method. This, however, seems to
 * be more complex than declaring those methods with a package visibility.
 *
 *
 * Indirect command files
 *
 * Lines in indirect files are continued with the continuation character.
 * This is needed to recognize the end of the portion of the file which is
 * to be included (virtually) in the referring command. The remaining part,
 * often delimited by `//', is application-dependent both in its syntax and
 * semantics.
 *
 * There are in principle two kinds of indirect files: the ones which are
 * replacements for the value of a parameter, (which could be indicated as,
 * e.g. file/ind) and the ones which are replacements for a portion of a
 * command (e.g. @file, file/include, /ind=file or --ind=file).
 * This characteristics of an argument could be specified in its attributes.
 * Parameters which are indirect files of the kind file/ind have qualifiers
 * like /ind, and qualifiers which can be specified on the value elements.
 * They would be defined all together. Thus, /xxx could be specified on the
 * parameter and on the value elements.
 * In order not to make confusion, if /ind is specified, then no other local
 * qualifiers should be specified. I.e. the /ind and the other qualifiers are
 * two distinct sets for two uses. However, it could be possible for a same
 * parameter to specify par/ind and par/xxx. E.g. f1/ind,f2/ind would be
 * rejected.
 * The two kinds can be integrated: in file/ind the values (elements) in the
 * indirect file are accessed with the parameter name because they are in fact
 * the values of that parameter, as if the file/ind had been replaced by the
 * text of the indirect file. After them it could be possible to specify in the
 * indirect file other arguments, as in the second kind, /ind=file. But then the
 * second form, since it can be specified in any place, is more powerful than
 * the first one. Moreover, it is a qualifier, and thus it does not have the
 * same problems as the parameters regarding the mixing of the qualifiers.
 * However, it is a case of allowed argument repetition, which needs to be
 * managed. It is appropriate to allow several occurrences of it: e.g. when
 * there are two long parameters, each one can be stored in a separate file.
 * In DCL, the @file form is a pure inclusion, and thus it can be specified
 * even in the middle of a parameter's value. This is not good because it
 * confuses the reader. A better solution is to have /ind work at the argument
 * level: it may not be specified as local qualifier since the (virtual)
 * inclusion is done only at the argument level. Since global qualifiers can
 * also be appended to parameter's values, but there end parameters, then e.g.
 * in par/ind=file/xxx, xxx would be taken as a global (command) qualifier.
 * Note that the indirect file may not contain local qualifiers or parts of a
 * parameter value. This makes simpler the access to the parameter's values
 * and their local qualifiers, which are accessed by scanning the command from
 * the start of a value element onwards without the burden to remember that
 * one such qualifier could be a /ind=file to which the scanning had to
 * switch. Indirect files can be nested.
 *
 * One alternative is to parse the indirect files while they are being read;
 * another is to read them all and then parse them. The second is chosen because:
 *
 *    1. parsing is easier because it is as if the file would be included in
 *       the command. There is no need for parsing methods which are
 *       specialised for indirect files: the handling of indirect files stays
 *       confined into the processing of the indirect file arguments.
 *    2. it allows to parse or access them a second time also when they are
 *       on sequential devices, like e.g. standard input, which is not easy
 *       if indirect files are not loaded (there would be a need to copy them
 *       automatically in temporary files).
 *    3. it is compatible with the increased memory availability. Indirect files
 *       represent parts of commands, and thus are not very large.
 *       A program that has to process large amounts of data should read them
 *       from ordinary files (possibly passed to it in its command).
 *    4. it allows to access arguments values randomly (i.e. shifting from
 *       one parameter to another one) even when the arguments are specified
 *       in distinct indirect files. Parsing and reading at the same time would
 *       need to keep a file descriptor active for each argument that denotes
 *       an indirect file. On the other hand, loading all indirect files
 *       requires only one descriptor.
 *
 * Note that loading indirect files improves little parsing because the syntax
 * errors are limited to the ones present in a value (i.e. no wrong qualifiers,
 * etc.).
 * For indirect files which are the replacement for the value of a parameter,
 * it is easier to read them when the value elements are accessed than for
 * indirect files which are replacements of arguments.
 * Indirect files are read with no limits on line lenght.
 *
 * For indirect files that are replacement of parameters (file/ind) one single
 * element descriptor would be sufficient, except for the index of the value,
 * for which there would be two indexes: one to the command where the argument
 * is and another into the indirect file. The latter could be stored in the
 * descriptor of the local qualifier /ind: its start and end indexes are
 * of little use anyway (in the case of a reference to a non-existing indirect
 * file, they can be set to point both to an empty area).
 * For indirect files which are replacement of arguments, there is a need to
 * to keep a list of load areas, needed for freeing. There is no need to
 * have element descriptors for them because after reading they are parsed
 * and the element descriptors filled. This is different from the other
 * kind of indirect files because for them a same parameter has two places
 * in which its data occur, and thus there is a need for two descriptors.
 * This is preferable to sew the command as it is parsed the first time
 * because there could otherwise be problems in printing it: the sewed form
 * would not reflect what the user provided.
 * Cleraly, when the analysis is done in a sigle pass, there is no need
 * to keep the areas: indirect files are simply read, and then forgotten.
 * A technique to store indirect files is to keep an array of pointers to
 * allocated strings for each file. This, however, would imply that there
 * is a white space at the end of each line, and that it would no longer be
 * possible to keep an index of the beginning of a value because a value can
 * be continued on the next line. Thus, a single contiguous area is used
 * instead.
 *
 * Indirect files are processed before making the global checks on the command
 * because in them there can be required parameters.
 *
 * Indirect files are specified with AR_IND on a qualifier. This is preferable
 * than having a fixed name for the indirect argument, although it would
 * relieve from the burden to declare it because it would make easier to
 * support the locale. Note, however, that the support to the locale could
 * effectively be done only by placing command definitions on some file, and
 * then also the standard indirect file name could be defined there. The solution
 * is to have a default argument definition, which can be overridden in
 * commands.
 *
 * Since access to parameter values requires reparsing, a boolean is kept in the
 * Cli object to flag the first pass (syntax check and loading of indirect files)
 * and to disable the loading afterwards.
 *
 * When an indirect file is opened, a string to hold its path is allocated.
 * It serves both to print its name if an error occurs and to propagate
 * its data over the next indirect file. It is deallocated on termination.
 *
 * It is possible to call present() only on command-specific indirect arguments,
 * not on the default one.
 *
 * The load areas for indirect file are deallocated on termination, including
 * the string for the path filename.
 *
 * Parsing inside indirect files may not restart curpar at 0 because
 * it would not make parameters in it be interpreted correctly. There is
 * only a need to disable local qualifiers in it. To do it, parse_args(),
 * which parses only whole arguemnts, is called.
 *
 * Nesting requires qual_indfile to call itself indirectly. When an indirect file
 * contains a reference to itself endless recursion occurs. It is not simple to
 * check that a opened indirect file opens itself again. A means is to link the
 * stack frames of the qual_indfiles, keep some unique identifier for a file and
 * check that it has not been opened in some previous invocation. This,
 * however, does not cover really stack overflow even if it catches almost all
 * because it is very hard to have a true nesting so deep to cause stack
 * overflow. The simpler mechanism to limit the nesting is used instead.
 *
 * The default indirect argument denotes files that can only contain arguments
 * since they are parsed entirely. Their load areas are kept in an array
 * whose reference is in the Cli object, and that are not accessed through the
 * access methods.
 * To process correctly indirect files, when an indirect file has been loaded,
 * parse_arg is called. It parses global qualifiers and parameters.
 *
 * For an indirect file element, the cursor is left at the end of the part which
 * has been processed. This allows to access the user-defined part.
 *
 * AR_USER allows to append an user-defined part at the end of an indirect
 * file. The user part is read and stored.
 * User-defined parts assign an additional meaning to indirect files besides
 * pure inclusion of arguments: they denote also extra data, Thus there should
 * be a means to name such data. If a same qualifier is used to specify indirect
 * files, and if it is repeated, it is difficult to locate the load areas.
 * In principle it is possible to provide access also to the load ares of
 * default indirect files, but it requires additional access methods.
 * Command-specific indirect arguments can allow a user part, and thus may not be
 * repeated.
 * Continuation lines serve mainly to the shell input method to determine
 * where a command ends: it is on a single line, possibly continued. After
 * that there are other commands (or input of the previous command).
 * However, in an indirect file there is no such a need: it contains arguments,
 * and thus continuation in it can be used to split a long value mainly.
 * To do it, CR and LF should be recognised as white space. This, however,
 * makes difficult the treatment of indirect files that contain additional
 * parts. If continuation is used, everything which is not continuation
 * is supposed to be specific. Once an indirect file has been loaded, the
 * continuation characters are removed. Analysis stops because the user defined
 * part is separated by a newline.
 * The index of the user part is returned in the location indicated by
 * the last field of the argument descriptor by the value() method.
 *
 * The semantics of an indirect file qualifier is the following: a command
 * containing such qualifiers is equivalent to one in which any occurrence
 * of them is replaced (recursively) by the contents of the denoted files.
 *
 * An indirect file propagates its directory and file-type to the ones
 * which follow in a command.
 *
 * The decision to use `@' to denote indirect files stems both from the use
 * in DCL of the same notatio and also in java tools. Moreover, It makes no
 * clashes with user defined arguments.
 *
 * Option files, which are meant to hold a possibly unlimited number of
 * arguments, are opened and parsed by applications. E.g. a linker can use
 * an option file to hold a long list of object file specs and linking options.
 * Parsing can by done by using Cli with the mode NOCMDNAME.
 *
 * The definition of the default indirect argument is placed in CliBundle
 * even if there is no need to localize it because it serves to display usage
 * messages.
 *
 *
 * Multi-commands
 *
 * For a command a callback can be specified that is called if the command
 * is recognised, i.e. if there are no errors in the syntax.
 *
 * This package can be used to implement an interpreter, which has a set of
 * commands. To support it the parser seeks first the command definition
 * for a command. For this the command name is kept in the command descriptors.
 * parse() can be called with a set of commands. It returns in the Cli object
 * a reference to the recognised command.
 * Commands are defined one after the other in a same table.
 *
 * Multicommands can also be implemented by loading the class corresponding
 * to the verb and by calling the main() in them. Well, it seems that tere
 * would then be no way to make the main() access the command data.
 *
 * It could be possible to implement a java shell which interprets scripts:
 * it recognizes command names, then it finds a class file (through a path
 * or directly), it loads it, it calls the main method in it which parses
 * the arguments, and executes the command. If no class file is found, it
 * can exec a OS command. Some special notation can be used to let the shell
 * pass directly strings as arguments to command instead of performing all
 * the textual passing of arguments.
 *
 * In some cases it could be useful to enable a set of commands once a given
 * one has been accepted. For this there is a need to have a data structure
 * to hold commands more flexible than an array. This, however, takes this
 * package beyond its intended usage.
 *
 * If there are many commands it could be useful to build a hash table
 * of command verbs at init time, providing that abbreviations are not used.
 * To support abbreviations, a sorted table is used instead.
 *
 * When the first command of a set is checked, all the others are assumed
 * to be checked also, and the set sorted. A set must be used as such, i.e.
 * the commands in it must not be accessed individually.
 *
 * A set of commands is stored as an array of commands. To make search
 * fast, it is ordered when checked. Since there is a need to support
 * case-insensitiveness and abbreviations, Java collections are not used.
 *
 * To let the caller know which command has beed detected, a sequence number
 * is stored in the code field of commands, which can be retrieved with
 * intValue(). It reflects the original ordering.
 * Note that the reference present in cmddes changes according to the locale,
 * and thus may not be used.
 *
 * When no command is found that matches one in a set, an error condition
 * is returned. This might not necessarily be an error. If the no match
 * condition is allowed, then the return-status mode should be used, and the
 * return status checked.
 *
 *
 * Memory
 *
 * To check allocation, a method is provided to compute the areas referred
 * to from a Cli object. This is simpler than keeping count of them when they
 * are allocated.
 * It rekons also the memory for the segments in argv/args even if such
 * memory has not been allocated by Cli. It is only an issue of convention.
 *
 *
 * Help
 *
 * Help messages are provided when a command is parsed, the program has been
 * run in interactive mode and a usage or help qualifier has been encountered.
 * A message is printed and parsing terminates.
 *
 * Internationalization
 *
 * There is a need to localise commands. There are two alternatives:
 *
 *   1. to use resource names in command definitions for all strings.
 *      this can make definitions cryptic.
 *   2. to use one resource name for each argument, to which an array of
 *      strings (name, mnemonic, etc.) is associated.
 *      This requires to change all localised command definitions when
 *      any change is done in the command (like e.g. when a new attribute
 *      is added).
 *   3. to put entire command definitions in resouce bundles. This
 *      provides enough context to translate properly commands,
 *
 * It would be wonderful to have the English definition backed up by localised
 * definitions instead of a neutral one full of keys.
 * The first two have the drawback that there is a need to interpret
 * differently the contents of strings in arguments: when command localization
 * is enabled, strings are keys; when it is not, strings are the final ones.
 * When it is enabled, the final strings must be linked in place of the
 * keys. This means that the constructors do it, but also other methods
 * in order to support change of locale on the fly.
 * Keeping individual strings as resources is also inefficient because
 * they are inserted in a hash table when read.
 *
 * It is necessary to keep aligned the default locale and the data in
 * a CLi object (and the ones referred to from it, i.e. to update the resource
 * bundle and the locale 1 of Formatter according to a possibly changed
 * default locale).
 * Upon entry in some methods there is a need to refresh the command
 * definition, and the default qualifiers if the default locale has changed.
 * In some interface methods there is a need to test for a change in the
 * current locale so as to reload the command descriptor(s). However,
 * a command must be parsed with a definition only: the definition may
 * not change in between.
 * The updating is done in: getCommand() and parse(). No update is done in
 * check because that is meant for checking a specific command definition.
 * If the application has localized commands is has to let parse() check
 * them after updating.
 * No updating is done in getMessages() because that is meant to print a
 * message for a command which has already been entered, and thus the displayed
 * data, such as argument names, must be consistent with it. Moreover,
 * an update called there could cause itself errors which prevent any display.
 *
 * Localised error messages: there is a need to keep error codes so as to
 * allow callers to test them. A solution can be to keep a message table
 * MSGTAB with the achronyms, and to print then achronyms followed by the
 * localised messages. However, since error codes must be used anyway,
 * the whole message table is localized.
 *
 * Messages are fetched as close as possible to the point in which they are
 * printed. To obey the definition of Throwable, a locale neutral error
 * message is inserted in it, but a method is provided to obtain the localised
 * one.
 *
 * Help strings are localised also. They are probably put by the calling
 * application in one bundle of its together with other strings.
 * Since they are related to commands, they are referred to from command
 * definitions.
 * The problem is that an application could wish to localise messages
 * only, and not commands. In this case all the output strings (descriptions,
 * helps, etc) need be localized only, which means that the bundles will
 * contain no commands, but these strings.
 * To have this behaviour, a bundle is registered in a Cli object by init().
 * When there is a bundle, but the command is not taken from it, the bundle
 * contains only output strings keys.
 *
 * There is a need for a locale-independent name for arguments to be
 * used in the user program. At command creation, the localised name
 * (together with the other names, mnemonics, etc.) are loaded.
 * This reopens the issue of using strings vs indexes to denote arguments
 * in programs. A possibility is to let the user define constants as
 * argument indexes.
 * A solution is to use strings, this eliminates the need to define
 * indexes long away from arguments, but introduces that of defining
 * another string for argument, to check it for uniqueness. That string
 * would not be needed for non localised commands.
 * Another is to use indexes. There would be a need to use two indexes
 * for local qualifiers because they can be shared betweed parameters.
 * There is a need to check that a local qualifier of a parameter which
 * has not previously been accessed is not requested.
 * Another idea is to use references. This is not good because a same
 * qualifier descriptor could be enlisted both as a global and a local
 * qualifier. But the strongest limitation is that references must
 * be defined in localised files, and their values, which depend on the
 * locale, may not be updated in the referring program when the locale
 * changes. Thus, indexes are used.
 *
 * Localization of names in commands is quite different from localization
 * of messages: there can be applications in which commands are not localized,
 * but messages are. System messages and default qualifiers are provided in
 * the CliBundle class; user messages and commands in some user classes.
 *
 * Localization of commands can be outside Cli, in which case the caller
 * can put the commands where it likes (and reinitialize a Cli object when
 * the locale changes), or inside Cli, in which case it should put them in
 * a resource bundle (associated to the predefined key "COMMAND", or
 * to user-defined keys) and pass it to Cli.
 *
 * If a Locale is passed to init(), Cli messages are in that locale,
 * which is useful for the applications which do not want to support
 * localization, that want Cli messages to appear in their language.
 * They do not want to set the default locale to make Cli work since they
 * do not need to set it to make themselves work.
 * To have Cli messages in a given language when an application has no
 * bundle, init() should be called by passing an empty string.
 *
 * NO and other value strings are localized only if in the application bundle
 * the commands are present.
 *
 * Messages and values are localized together. I.e. an Italian user can
 * receive messages in Italian, type numbers in Italian, but have command
 * names in English. This is so because when the user sees messages in
 * his/her language expects to see and enter values according to it also.
 *
 * Note that init() does not take a Lang, and thus does not skip the setting
 * of FIXLOC when it is a Lang. This is because it is a feature which is
 * used seldom, since most programs uses the VM-wide default locale.
 * It can be set with setLocale().
 *
 * When no localization is selected, all the strings represent themselves.
 * When only the messages are localised, the strings are keys that are
 * defined in bundles. Since the default arguments have only one definition,
 * i.e. the one in which strings are themselves, there is a need to retrieve
 * the translation by locating the localized definition of such arguments.
 * When an argument is defined by making a reference to a definition present
 * in another class (e.g. a "library" of argument definitions), there is
 * a need to retrieve the bundle which contains its keys. This is provided
 * by mentioning the bundle in the definition of such arguments. A special
 * form, in which the bundle is null, allows to detect the default arguments
 * and perform the abovementioned special translation.
 * When everything is localised there strings represent themselves.
 *
 * Java
 *
 * Command-Line Arguments warns that the use of command-line arguments in a
 * Java program may cause that program to be unportable (that is, it will
 * not be 100% Pure Java). If a program requires command-line arguments,
 * then it should follow the POSIX conventions for them.
 *
 *
 * Preferences
 *
 * The most common way to use Cli is to have the syntax preferences set
 * automatically according to the current platform. E.g. in Unix it is
 * likely that scripts contain a lot of Unix commands, which
 * make them useless in Win. It seems thus pointless to have in them
 * some commands which have a system-independent syntax. Of course,
 * if they are made only by applications which use Cli, they could be
 * made portable if the syntax is fixed. A technique can be to define
 * an environment variable that sets the syntax. Since it is difficult
 * to access the environment, a property can be used (-Dshell=UNIX);
 * When the user wants to pass the preferences to init(), FIXED must be
 * present in the mode, otherwise the preferences present in the mode passed
 * (and only the platform-specific ones) are taken from the platform or
 * the -Dshell.
 *
 *
 * Decoding of values
 *
 * The usage of classes, e.g. int.class for argument types allows more
 * freedom from one side (e.g. it allows to indicate a keytable), but
 * less from another, e.g. it does not allow to distinguish between
 * decimal and hex numbers. Attributes are used for this instead of dedicated
 * classes so as not to proliferate classes.
 *
 * The possibility to indicate a user-defined class could be useful.
 * That class would provide a parse() method. However, it would need also
 * a method to print values. This seems to be too much complicated. The
 * user can define the argument as a string and then parse it.
 *
 * When an object is passed, the argument must be a representation of one
 * value of that class, and be also one of the values stored in the object,
 * which must be an array.
 *
 * Collections are not supported as argument types because it is not possible
 * to tell the class of the values which are stored in it, unless the first
 * element is taken and examined. Moreover, collections do not seem to be
 * of much use in this context, except perhaps for maps, which are, however,
 * rather bulky for a so simple use.
 * A further problem with Collections is that the only value which can
 * be returned is a boolean telling if the element is in the collection.
 * With maps, the object associated to the key could be returned. Note that
 * there are no maps supporting basic values.
 *
 * There would be no need for ARG_LIST if classes which are arrays were
 * allowed. However, this could give the impression that arrays were
 * returned, which is not the case. Moreover, for parameters the elements
 * can have local qualifiers, which makes even less viable to return arrays.
 *
 * It would be nice to get the decoded value by calling always a same value()
 * method, but since it is not possible to overload it on the return type, then
 * there is a need to have several typeValue() methods.
 *
 * Place to store the value: if a location were to be specified in the argument
 * declarations, arguements should refer to writable objects: user ones in
 * which there is a field that can contain the value. The usual trick is to
 * have objects with an integral, a real, and a reference fields.
 * The goal is to let the user define these objects, call getCommand(), and have
 * the values read from the command and decoded into them. This means that
 * all the burden is taken by Cli, and applications are then simplified.
 * It is not possible to use the standard wrapper classes for basic types
 * because to pass a reference to an object of them defined in the application,
 * the object must be created by it, and after it is created, it may not be
 * changed. However, command descriptors should be read-only objects, possibly
 * used by several threads at the same time, having each one of them receive
 * its own values. A solution could be to let Cli allocate them and reuse them,
 * but this prevents the caller to have static references which mimic known
 * return locations where it can then fetch the values.
 * Another one is to reserve space in the elements. Note that space is reserved
 * even if there is a need to call a typeValue() method to get the value (which
 * could decode on the fly and  return the value in an object passed to it)
 * because that allows to detect errors during parsing. The methods typeValue()
 * take the values directly for global qualifiers and parameters which are not
 * lists, and in the other cases reparse the elements.
 *
 * The type code is stored in the argument to speed up decoding and to keep
 * the element type of arrays.
 *
 * To parse and decode values there is a need to scan the characters that
 * belong to it and then to interpret them. The syntax allows to quote
 * special characters in any value. This means that all the decode methods
 * would take that into account (including spare couples of quotes at the
 * beginning and at the end). Moreover, they would access every character
 * as buffer[i] or string.charAt(i) depending on the command. This makes
 * decode methods complex and error prone. Thus, qvelem builds a char[]
 * this.str while it scans the value and hands it to decode methods.
 * The lifetime of its contents is betweed qvelem and the decode routine.
 * It is reused and extended when needed.
 *
 * For primitive (scalar, real) values there is no problem of allocation: the
 * decode routine converts the string into its representation and stores it
 * always (i.e. also during the parsing phase), while for objects it must do
 * so only one time. To avoid that two subsequent calls to typeValue allocate
 * two objects, which occurs when the value is not a basic one and the argument
 * is a list, the methods skip allocation when they are in pass 1 and the
 * argument is a list.
 *
 * str_cbk() allocates each time a string, but when the value is in a whole
 * argv and there are no qualifiers for escapes, it returns the argv.
 * When a string is to be delivered, a check is done to see if the value
 * occupies a whole argument. In that case there is no need to build a new
 * string: the argument can be returned. It is the case of parameters and
 * arguments with one value only, separated with a space from the name.
 * When the value is an array, then is is a keytable, and therefore decode()
 * needs to check them. Thus, str_cbk in such a case processes the argument
 * normally.
 *
 * value() serves to determine the presence and to decode and record the value
 * when not already present.
 *
 * strValue() when called on non-list arguments rescans the element because
 * the string has not been stored in the element.
 *
 * strValue() allows to get the string of an element also when its type is
 * not a string. During parsing, it is not known that later on strValue()
 * will be called on such elements, and thus no string is stored, but the
 * appropriate internal representation. There is thus a need to rescan the
 * piece of the command string which contains it. That is done by saving
 * its start and calling qvelem (without decode). No need to restore the
 * current position since at this stage parsing has been already done.
 *
 * An array of descriptors of argument types, arg_types is kept. It serves to
 * display and to help decoding.
 *
 *
 * Environment arguments
 *
 * It would be desirable to let the user set environment variables (be means
 * of shell commands) which change the preferences of all the commands which
 * are then executed in the same shell activation.
 * This, however, would apply only to the applications which use Cli.
 * Moreover, to implement it there is a need to spawn an exec of a
 * platform dependent command (like e.g. "env").
 * This is by far not efficient.
 * For these obstacles, this feature is not provided.
 *
 *
 * Printing a command line
 *
 * To print a command, there is a need to break it at suitable places when
 * it exceeds the witdh of the line. The perfect solution would be to make
 * a loop of get_qvelem() using the appropriate syntax preferences.
 * A simpler technique to break at graphical characters and insert the
 * appropriate continuation character can be used instead.
 *
 *
 * The encoding
 *
 * To support the reading of indirect files whose encoding is different
 * from the default one, an encoding qualifier is defined in the default
 * indirect argument. Cli passes an IoStream to ShellStream to keep the
 * filespec for propagation, and passes the encoding to it as well.
 * The encoding qualifier is then allowed to user-defined indirect arguments,
 * and also on arguments which are files in genera.
 * The attribute AR_ENC is defined in the predefined encoding qualifiers
 * so as to tell if an argument which represents a file has a (possibly
 * localized) encoding qualifier defined on it.
 * Cli iterators return an array of two strings when an encoding has been
 * specified in the value of the argument.
 */
  
/* Cli object */

public class Cli {

    /* Instance fields */

    /** The command descriptors reference. */
    private Command cmddes;

    /** The command set descriptors reference. */
    private Command[] cmdSet;

    /** The default descriptor reference. */
    private Argument[] dfldes;

    /** The localized default descriptor reference. */
    private Argument[] dfldesLoc;

    /** The dfldes for fixed locale. */
    private Argument[] dfldesFix;

    /** The elements data reference. */
    private Element[] elems;

    /** The mode: set of active attributes. */
    int mode;

    /** The pass -1: check, 0: init, 1: parse, 2 access. */
    private byte pass;

    /** The bundle name if localized command. */
    private String bundle;

    /** The resource bundle for command descriptors. */
    private ResourceBundle resource;

    /** The current locale of Cli. */
    private Locale locale;

    /** The current default locale of Cli. */
    private Object defLocale;

    /** The key of command definition in bundle. */
    private String cmdKey;

    /** The localized command descriptor. */
    private Object cmdLoc;

    /** The message localisation switch. */
    private boolean locMsg;

    /** The result of the last operation. */
    public int res;

    /** The exception object. */
    CliError excObj;

    /** The error handling. On error 0: ret 1: throw 2: abort. */
    private int errthrow;

    /** The trace flags. */
    private int trc;

    /** The report stream, null = no messages. */
    private Object repstream;

    /** The formatter for reporting. */
    private Formatter report;

    /** The prompt format. */
    private String promptForm;

    /** The nesting of indirect files. */
    private int nest;

    /** The current piece of char[] command. */
    private char[] buffer;

    /** The current piece of String command. */
    private String string;

    /** The current piece type: true if current piece in string. */
    private boolean isStr;

    /** The current index to end (last+1). */
    private int end;

    /** The length of command, if not segmented (0 = natural length). */
    private int comLen;

    /** The cursor in command. */
    int cursor;

    /** The index of the start of last lexeme. */
    private int ini;

    /** The argument number of <code>ini</code>. */
    private int argni;

    /** The index of the current parameter. */
    int curpar;

    /** The head of the load list. */
    private ShellStream[] loadArr;

    /** The number of entries used. */
    private int loadNr;

    /** The io object to read indirect files. */
    private IoStream inpInd;

    /** The reference to temporary string for value decode and access. */
    private char[] str;

    /** The length of <code>str</code.>*/
    private int strLen;

    /** The path of standard input (for testing). */
    String stin;

    /** The command, if not segmented. */
    private char[] com;

    /** The string command, if not segmented. */
    private String coms;

    /** The argument vector. */
    private char[][] argv;

    /** The argument String vector. */
    private String[] args;

    /** The number of argv entries. */
    private int argc;

    /** The current argv entry. */
    private int argn;

    /** The version string. */
    private String version;

    /** The current value names strings. */
    private String[] valStr;

    /** The index of the negation in the value names string. */
    private static final int NO = 0;

    /** The localised value names strings. */
    private String[] valStrLoc;

    /** The valStr for fixed locale. */
    private String[] valStrFix;

    /** The caller's instance data. */
    private Object instance;

    /** The return status of value() methods. */

    /* It is used also by the qualifier name search methods. */
    public int status;

    /** Status code for an argument value which is not specified. */
    public static final int ABSENT  = 0;

    /** Status code for an argument value which is present. */
    public static final int PRESENT = 1;

    /** Status code for an argument value which is present in the negated form. */
    public static final int NEGATED = 2;

    /**
     * Status code for an argument value which is not the last in a list
     * separated by "<code>+</code>".
     */
    public static final int CONCAT  = 3;

    /**
     * Status code for an argument value which is not the last in a list
     * separated by "<code>:</code>" or "<code>,</code>".
     */
    public static final int CONT    = 4;

    /** String representation of status codes. */

    static final String[] STA = {
        "ABSENT","PRESENT","NEGATED","CONCAT","CONT"
    };

    /** The offset of the mask to disable the first default qualifier. */
    public static final int DFLT_OFF = 20;

    /** The lexer object to parse values. */
    private Lexer lex;

    /** Posix -- index. */
    private int posixcur;

    /** Posix -- argument number. */
    private int posixargn;

    /**
     * Constructs a new <code>Cli</code>.
     */

    public Cli(){
        this.errthrow = ERR_THROW;
    }

    /**
     * Constructs a new <code>Cli</code> with a given error handling
     * policy.
     *
     * @param      et kind of handling
     */

    public Cli(int et){
        this();
        this.errthrow = et;
    }

    /** On error return a status code. */
    public static final int RET_STATUS = 0;

    /** On error return an exception. */
    public static final int ERR_THROW  = 1;

    /** On error abort. */
    public static final int ERR_ABORT  = 2;

    /**
     * Sets the error handling policy.
     *
     * @param      et kind of handling
     */

    public void setOnErr(int et){
        this.errthrow = et;
    }

    /* Mode attributes */

    /** Case insensitive mode. */
    public static final int CASEINS  = 1 << 0;

    /** Accept abbreviated names mode. */
    public static final int ABBREV   = 1 << 1;

    /** Accept <code>=</code> as qual value separator mode. */
    public static final int QVALEQ   = 1 << 2;

    /** Accept <code>:</code> as qual value separator mode. */
    public static final int QVALCO   = 1 << 3;

    /** Convert values to uppercase mode. */
    public static final int TOUPPER  = 1 << 4;

    /** Convert values to lowercase mode. */
    public static final int TOLOWER  = 1 << 5;

    /** <code>/</code> as qualifier delimiter mode. */
    public static final int QUALSL   = 1 << 6;

    /** <code>-</code> as continuation character mode. */
    public static final int CONHY    = 1 << 7;

    /** <code>^</code> as continuation character mode. */
    public static final int CONCARET = 1 << 8;

    /** Qualifier delimiter required mode. */
    public static final int QSREQ    = 1 << 9;

    /** Longname allowed after <code>-</code> mode. */
    public static final int LNAME    = 1 << 10;

    /** Value allowed immediately after short name mode. */
    public static final int NONSEP   = 1 << 11;

    /** Combination of short names allowed mode. */
    public static final int QMASK    = 1 << 12;

    /**
     * <code>,</code> and <code>+</code> as parameter list separators
     * and <code>(,,)</code> as qualifiers list mode
     */
    public static final int DCLLSEP  = 1 << 13;

    /** Preferences fixed mode. */
    public static final int FIXED    = 1 << 14;

    /** Read command from standard input if not inline mode. */
    public static final int STDIN    = 1 << 15;

    /** No default arguments mode. */
    public static final int NODEFLT  = 1 << 16;

    /**
     * No usage arguments mode. It may not be changed after
     * <code>init()</code>.
     */
    public static final int NOUSAGE  = 1 << 17;

    /**
     * Interactive mode. It may not be changed after
     * <code>init()</code>.
     */
    static final int INTER           = 1 << 18;

    /** Localization fixed mode. */
    private static final int FIXLOC  = 1 << 19;

    /** Level of assistance. */

    /** Assistance message mode. */
    public static final int USG_SEE     = 1 << 20;

    /** Brief usage message mode. */
    public static final int USG_BRIEF   = 1 << 21;

    /** Reminder usage message mode. */
    public static final int USG_REMIND  = 1 << 22;

    /** Verbose usage message mode. */
    public static final int USG_VERBOSE = 1 << 23;

    /** All usage messages mode. */
    public static final int USG_ALL     = 1 << 24;

    /** No qualifier delimiter (name=value pairs) mode. */
    public static final int QUALNVP     = 1 << 25;

    /** Html syntax for strings mode. */
    public static final int HTMLVALUE   = 1 << 26;

    /** Lenient parsing mode. */
    public static final int LENIENT     = 1 << 27;

    /** Enable full whitespace mode. */
    public static final int WHITESPACE  = 1 << 28;

    /** No command name mode. */
    public static final int NOCMDNAME   = 1 << 29;

    /** Shell converts to uppercase mode. */
    public static final int SHELL_UPPER = 1 << 30;

    /** DCL syntax mode. */
    public static final int DCL = FIXED | USG_BRIEF |
           CASEINS | ABBREV | QVALEQ | QVALCO | TOUPPER |
           QUALSL  | CONHY  | QSREQ  | DCLLSEP | SHELL_UPPER;

    /** Windows syntax mode. */
    public static final int WIN = FIXED | USG_BRIEF |
           CASEINS | ABBREV | QVALEQ | QVALCO | TOUPPER |
           QUALSL  | CONCARET | QSREQ  | DCLLSEP;

    /** Unix syntax mode. */
    public static final int UNIX = FIXED | USG_BRIEF |
           ABBREV | QVALEQ | QVALCO | LNAME | NONSEP |
           QMASK;

    /** Html syntax mode. */
    public static final int HTML = FIXED | CASEINS | QVALEQ |
           QSREQ | QUALNVP | NODEFLT | HTMLVALUE | LENIENT |
           WHITESPACE;


    /** Max indirect file nesting. */
    private static final int MAX_NEST = 100;

    /** Elements of commands. */

    private static class Element {

        /** Index of start, -1 if not specified. */
        private int ini;

        /** Argument number of <code>ini</code>. */
        private int argni;

        /** Index of end (last+1). */
        private int end;

        /** Argument number of <code>end</code>. */
        private int argne;

        /** Current index. */
        private int cursor;

        /** Argument number of <code>cursor</code>. */
        private int argnc;

        /** Negated qualifier. */
        private boolean neg;

        /** Value, if integral. */
        private long integral;

        /** Value, if floating point. */
        private double real;

        /** Value, if object. */
        private Object obj;

        /**
         * Assign an element value to this element object.
         *
         * @param      e element containing the value
         */

        private void assign(Element e){
            this.ini = e.ini;
            this.argni = e.argni;
            this.end = e.end;
            this.argne = e.argne;
            this.cursor = e.cursor;
            this.argnc = e.argnc;
            this.neg = e.neg;
            this.integral = e.integral;
            this.real = e.real;
            this.obj = e.obj;
        }

        /**
         * Clear this element object.
         */

        private void clear(){
            this.ini = 0;
            this.argni = 0;
            this.end = 0;
            this.argne = 0;
            this.cursor = 0;
            this.argnc = 0;
            this.neg = false;
            this.integral = 0;
            this.real = 0.0D;
            this.obj = null;
        }
    }

    /**
     * Store a clone of the current elements table or restore it.
     * It is used for testing purposes.
     *
     * @param      clone true to store, false to restore
     */

    void cloneEletab(boolean clone){
        if (clone){
            eleclone = (Element[])(this.elems.clone());
            for (int i = 0; i < eleclone.length; i++){
                eleclone[i] = new Element();
                eleclone[i].assign(this.elems[i]);
            }
        } else {
            this.elems = eleclone;
        }
    }

    /** Reference to the cloned element table. */
    private static Element[] eleclone;

    /** Empty array of arguments. */
    private static final Argument[]  EMPTY_ARGS = {};

    /**
     * Common superclass for commands, parameters and qualifiers.
     * It defines argument descriptors.
     */

    public static abstract class Argument implements Serializable {

        /**
         * Full name.
         *
         * @serial
         */
        String name;

        /**
         * Mnemonic of value.
         *
         * @serial
         */
        protected Object mnem;

        /**
         * Set of attributes.
         *
         * @serial
         */
        int attr;

        /**
         * Type of value.
         *
         * @serial
         */
        protected Object type;

        /**
         * Usage description.
         *
         * @serial
         */
        protected String desc;

        /**
         * Code of the type.
         *
         * @serial
         */
        char code;

        /**
         * Reference to arguments.
         *
         * @serial
         */
        Argument[] args;

        /** SUID form JDK 1.2 */
        private static final long serialVersionUID = 4529483018681447005L;

        /**
         * Create an Argument.
         *
         * @param      n name
         * @param      m mnemonic for value in usage messages
         * @param      a attributes
         * @param      t class of values
         * @param      d description for usage messages
         */

        private Argument(String n, String m, int a, Object t, String d){
            this.name = n;
            this.mnem = m;
            this.attr = a;
            this.type = t;
            this.code = '\0';
            Class c = t.getClass();
            Object cl = t;
            if (c != Class.class){                    // an object passed
                if (c.isArray()){
                    cl = c.getComponentType();
                    this.attr |= AR_ARR;
                } else {                              // check if collection
                    cl = null;
                }
            }
            for (int i = 0; i < arg_types.length; i++){   // find type
                if (cl == arg_types[i].type){             // found
                    this.code = arg_types[i].code;
                    break;
                }
            }
            this.desc = d;
            this.args = EMPTY_ARGS;
        }

        /**
         * Create an Argument.
         *
         * @param      n name
         * @param      c class of the bundle
         * @param      m mnemonic for value in usage messages
         * @param      a attributes
         * @param      t class of values
         * @param      d description for usage messages
         */

        private Argument(String n, Class c, String m, int a, Object t,
            String d){
            this(n,null,a,t,d);
            String[] i18 = new String[2];
            i18[0] = m;
            if (c != null) i18[1] = c.getName();
            this.mnem = i18;
        }
    }

    /**
     * Commands descriptors defines the syntax and properties of commands.
     */

    public static class Command extends Argument {

        /**
         * Help string.
         *
         * @serial
         */
        private String help;

        /**
         * Map of argument indexes.
         *
         * @serial
         */
        int[] argSeq;

        /**
         * Number of arguments and local qualifiers.
         *
         * @serial
         */
        int argMax;

        /**
         * Callback.
         *
         * @serial
         */
        private Object cbk;

        /**
         * Class of callback.
         *
         * @serial
         */
        private Object cbclass;

        /**
         * Command code.
         *
         * @serial
         */
        private int cmdcode;

        /** SUID form JDK 1.2 */
        private static final long serialVersionUID = -4529483018681447005L;

        /**
         * Create a Command.
         *
         * @param      n name
         * @param      d description
         * @param      h help message
         * @param      cl name of the callback
         * @param      cb callback class
         * @param      a arguments
         */

        private Command(String n, String d, String h,
            String cl, Object cb, Argument[] a){
            super(n,null,0,"s",d);
            this.name = n;
            this.desc = d;
            this.help = h;
            if (a != null) this.args = a;
            this.cbk = cb;
            this.cbclass = cl;
            this.type = String.class;
            this.code = 0;
            sequence();
        }

        /**
         * Create a Command.
         *
         * @param      n name
         * @param      d description
         * @param      h help message
         * @param      cb callback
         * @param      a arguments
         */

        public Command(String n, String d, String h,
            CliCbk cb, Argument[] a){
            this(n,d,h,(String)null,(Object)cb,a);
        }

        /**
         * Create a Command.
         *
         * @param      n name
         * @param      d description
         * @param      h help message
         * @param      cl name of the class containing the callback
         * @param      cb name of the callback
         * @param      a arguments
         */

        public Command(String n, String d, String h,
            String cl, String cb, Argument[] a){
            this(n,d,h,(String)cl,(Object)cb,a);
        }

        /**
         * Create a Command.
         *
         * @param      n name
         * @param      d description
         * @param      h help message
         * @param      a arguments
         */

        public Command(String n, String d, String h,
            Argument[] a){
            this(n,d,h,(String)null,(Object)null,a);
        }

        /**
         * Create a Command.
         *
         * @param      n name
         * @param      d description
         * @param      a arguments
         */

        public Command(String n, String d, Argument[] a){
            this(n,d,null,(String)null,(Object)null,a);
        }

        /**
         * Create a Command.
         *
         * @param      n name
         * @param      d description
         * @param      h help message
         * @param      command code
         * @param      a arguments
         */

        public Command(String n, String d, String h,
            int cn, Argument[] a){
            this(n,d,h,(String)null,(Object)null,a);
            this.cmdcode = cn;
        }

        /**
         * Create the sequence map of the arguments of a command.
         */

        void sequence(){
            Argument[] a = this.args;
            int seq = 1;
            this.argSeq = new int[a.length];
            for (int i = 0; i < a.length; i++){
                this.argSeq[i] = seq;
                Argument ar = a[i];
                seq += ar.args.length;
                if (seq < 0) break;
                seq++;
                if (seq < 0) break;
            }
            this.argMax = seq;
        }
    }

    /**
     * Parameter descriptors defines the syntax and properties of parameters.
     */

    public static class Parameter extends Argument {   // parameter descriptor

        /** SUID form JDK 1.2 */
        private static final long serialVersionUID = -3053320024318796129L;

        /**
         * Create a Parameter.
         *
         * @param      n name, to be displayed when prompting
         * @param      c class of the bundle containing the localised
         *             mnemonics
         * @param      m mnemonic string describing the expected value,
         *             displayed in the usage of the command
         * @param      a attributes: optionality, negation, etc.
         * @param      t class of the value, or or an array of objects to
         *             which the value must belong. The class must be a
         *             primitive class, String.class, Date.class or
         *             void.class (no value).
         * @param      d mnemonic string describing the purpose of the
         *             argument, displayed in the usage of the command
         * @param      q qualifiers
         */

        public Parameter(String n, Class c, String m, int a, Object t,
            String d, Qualifier[] q){
            super(n,c,m,a | AR_PAR,t,d);
            if (q != null) this.args = q;
        }

        /**
         * Create a Parameter.
         *
         * @see        Cli.Parameter#Cli.Parameter(String,Class,String,int,Object,String,Cli.Qualifier[])
         */

        public Parameter(String n, String m, int a, Object t, String d,
            Qualifier[] q){
            super(n,m,a | AR_PAR,t,d);
            if (q != null) this.args = q;
        }

        /**
         * Create a Parameter without qualifiers.
         *
         * @see        Cli.Parameter#Cli.Parameter(String,Class,String,int,Object,String,Cli.Qualifier[])
         */

        public Parameter(String n, String m, int a, Object t, String d){
            this(n,m,a,t,d,null);
        }

        /**
         * Create a Parameter without qualifiers.
         *
         * @see        Cli.Parameter#Cli.Parameter(String,Class,String,int,Object,String,Cli.Qualifier[])
         */

        public Parameter(String n, Class c, String m, int a, Object t,
            String d){
            this(n,c,m,a,t,d,null);
        }
    }

    /**
     * Qualifier descriptors defines the syntax and properties of qualifiers.
     */

    public static class Qualifier extends Argument {

        /**
         * Short name.
         *
         * @serial
         */
        private char sname;

        /** SUID form JDK 1.2 */
        private static final long serialVersionUID = 7278374571913250776L;

        /**
         * Create a Qualifier.
         *
         * @param      s short name, blank if not defined
         * @param      n (long) name
         * @param      c class of the bundle containing the localised
         *             mnemonics
         * @param      m mnemonic string describing the expected value,
         *             displayed in the usage of the command
         * @param      a attributes: optionality, negation, etc.
         * @param      t class of the value, or or an array of objects to
         *             which the value must belong. The class must be a
         *             primitive class, String.class, Date.class or
         *             void.class (no value).
         * @param      d mnemonic string describing the purpose of the
         *             argument, displayed in the usage of the command
         * @param      q qualifiers
         */

        public Qualifier(char s, String n, String m, int a, Object t,
            String d, Qualifier[] q){
            super(n,m,a,t,d);
            this.sname = s;
            if (q != null) this.args = q;
        }

        /**
         * Create a Qualifier.
         *
         * @see        Cli.Qualifier#Cli.Qualifier(char,String,Class,String,int,Object,String,Cli.Qualifier[])
         */

        public Qualifier(char s, String n, Class bun, String m, int a, Object t,
            String d, Qualifier[] q){
            super(n,bun,m,a,t,d);
            this.sname = s;
            if (q != null) this.args = q;
        }

        /**
         * Create a Qualifier without local qualifiers.
         *
         * @see        Cli.Qualifier#Cli.Qualifier(char,String,Class,String,int,Object,String,Cli.Qualifier[])
         */

        public Qualifier(char s, String n, String m, int a, Object t,
            String d){
            super(n,m,a,t,d);
            this.sname = s;
        }

        /**
         * Create a Qualifier without local qualifiers.
         *
         * @see        Cli.Qualifier#Cli.Qualifier(char,String,Class,String,int,Object,String,Cli.Qualifier[])
         */

        public Qualifier(char s, String n, Class bun, String m, int a, Object t,
            String d){
            super(n,bun,m,a,t,d);
            this.sname = s;
        }
    }

    /* Argument attributes */

    /** List of values (default: no list) argument. */
    public  static final int AR_LIST   = 1 << 1;

    /** Negatable (default: not negatable) argument. */
    public  static final int AR_NEG    = 1 << 2;

    /** Required argument (default: optional). */
    public  static final int AR_REQ    = 1 << 3;

    /** Required value (default: optional) in argument. */
    public  static final int AR_VALREQ = 1 << 4;

    /** Alternative qualifier. */
    public  static final int AR_ALT    = 1 << 5;

    /** Indirect file argument. */
    public  static final int AR_IND    = 1 << 9;

    /** Allow empty values in argument. */
    public  static final int AR_EMPTY  = 1 << 11;

    /** User data at end of indirect file argument. */
    public  static final int AR_USER   = 1 << 12;

    /** Parameter argument. */
    private static final int AR_PAR    = 1 << 13;

    /** +x short name argument. */
    public  static final int AR_PLUS   = 1 << 14;

    /** The encoding argument. */
    static final int AR_ENC            = 1 << 15;

    /** Unsigned integer argument. */
    public  static final int AR_UNS    = 1 << 20;

    /** Binary default base for argument values. */
    public  static final int AR_BIN    = 1 << 21;

    /** Octal default base for argument values. */
    public  static final int AR_OCT    = 1 << 22;

    /** Hexadecimal default base for argument values. */
    public  static final int AR_HEX    = 1 << 23;

    /** Roman default base for argument values. */
    public  static final int AR_ROM    = 1 << 24;

    /** Unicode escapes in argument value. */
    public  static final int AR_UNI    = 1 << 25;

    /** Currency argument value. */
    public  static final int AR_MON    = 1 << 26;

    /** Argument value belonging to an array. */
    private static final int AR_ARR    = 1 << 27;

    /** Command already checked. */
    static final int CHECKED = 1 << 31;


    /** The argument types table. */

    private static final ArgType[] arg_types = new ArgType[] {
        new ArgType(byte.class,     "INT8",'B'),
        new ArgType(short.class,    "INT16",'S'),
        new ArgType(int.class,      "INT32",'I'),
        new ArgType(long.class,     "INT64",'L'),
        new ArgType(boolean.class,  "BOOL",'b'),
        new ArgType(char.class,     "CHAR",'c'),
        new ArgType(float.class,    "FLOAT",'F'),
        new ArgType(double.class,   "DOUBLE",'D'),
        new ArgType(String.class,   "STRING",'s'),
        new ArgType(Date.class,     "DATE",'d'),
        new ArgType(void.class,     "NOVALUE",'v'),
    };

    /* Indexes of default arguments */

    static final int QU_INDFILE = -2;
    static final int QU_DISPLAY = -3;
    static final int QU_HELP    = -4;
    static final int QU_USAGE   = -5;
    static final int QU_BRIEF   = -6;
    static final int QU_VERBOSE = -7;
    static final int QU_ALL     = -8;
    static final int QU_VERSION = -9;

    /* Result values and messages */

    /** Locale-neutral messages. */

    private static String[] msgtab;

    /** Parsing ended with no command delivered. */
    public static final int NULL_COMMAND  = -1;

    /** Successful operation. */
    public static final int SUCCESS       =  0;

    /** A name is missing. */
    public static final int ERR_MISNAME   =  1;

    /** A security violation has been detected. */
    public static final int ERR_SECURITY  =  2;

    /** An unknown argument has been found. */
    public static final int ERR_UNKARG    =  3;

    /** A value is missing. */
    public static final int ERR_MISVAL    =  4;

    /** A method has been called when it was not allowed to be. */
    public static final int ERR_SEQUENCE  =  5;

    /** An illegal name has been found. */
    public static final int ERR_ILLNAME   =  6;

    /** A string has not been closed. */
    public static final int ERR_STRNOCL   =  7;

    /** A list has not been closed. */
    public static final int ERR_NOCLO     =  8;

    /** Too much memory has been used. */
    public static final int ERR_NOCORE    =  9;

    /** An unexpected character has been found. */
    public static final int ERR_UNEXP     = 10;

    /** A parameter is missing. */
    public static final int ERR_MISPAR    = 11;

    /** A qualifier is missing. */
    public static final int ERR_MISQUAL   = 12;

    /** A type mismatch has been found. */
    public static final int ERR_ILLTYPE   = 13;

    /** A name is ambiguous. */
    public static final int ERR_AMBNAME   = 14;

    /** An io error has been found. */
    public static final int ERR_IOERR     = 15;

    /** An initialization error has been found. */
    public static final int ERR_INIT      = 16;

    /** An illegal indirect argument has been found. */
    public static final int ERR_ILLIND    = 17;

    /** The callback is not present. */
    public static final int ERR_NOCBK     = 18;

    /** A qualifier has been repeated. */
    public static final int ERR_REPQUAL   = 19;

    /** A list is specified for an argument which does not allow it. */
    public static final int ERR_NOLIST    = 20;

    /** A qualifier is specified where it is not allowed. */
    public static final int ERR_ILLQUAL   = 21;

    /** A combination of attributes which is illegal has been found. */
    public static final int ERR_ILLATTR   = 22;

    /** No command is present. */
    public static final int ERR_NOCMD     = 23;

    /** An empty command is present. */
    public static final int ERR_NULLCMD   = 24;

    /** Too deep nesting of indirect files. */
    public static final int ERR_NEST      = 25;

    /** An unknown command has been found. */
    public static final int ERR_UNKCMD    = 26;

    /** An illegal value has been found. */
    public static final int ERR_ILLVAL    = 27;

    /** An illegal parameter has been found. */
    public static final int ERR_ILLPAR    = 28;

    /** A value out of the allowed range has been found. */
    public static final int ERR_RANGE     = 29;

    /** An illegal number has been found. */
    public static final int ERR_ILLNUM    = 30;

    /** A value out of the allowed limits has been found. */
    public static final int ERR_OUTLIMIT  = 31;

    /** An illegal file (path) has been found. */
    public static final int ERR_ILLFILE   = 32;

    /** An invalid definition has been found. */
    public static final int ERR_INVDEF    = 33;

    /** An error on a resource bundle has occurred. */
    public static final int ERR_RESOURCE  = 34;

    /** An error while reading an indirect file has occurred. */
    public static final int ERR_INDFILE   = 35;

    /** An error occurred during initialization. */
    public static final int ERR_NOINIT    = 36;

    /**
     * A parsing error. It indicates the violation of a condition which
     * has been encountered during the execution of a method due either
     * to some external cause or to a programming error.
     */

    public static class CliError extends Failure {

        /**
         * The presence of argument data.
         *
         * @serial
         */
        public boolean argPres;

        /**
         * The argument number.
         *
         * @serial
         */
        public int an;

        /**
         * The local qualifier number.
         *
         * @serial
         */
        public int ln;

        /**
         * The file path.
         *
         * @serial
         */
        public String path;

        /**
         * The argument number of the point in error.
         *
         * @serial
         */
        public int argn;

        /**
         * The cursor of the point in error.
         *
         * @serial
         */
        public int cursor;

        /**
         * Creates a CliError.
         *
         * @param      c error code
         * @param      o stream on which it occurs
         */

        CliError(int c, Object o){
            super(c,'E',null,null,message(c),null,o); // message describing result
        }


        /**
         * Deliver the strings representing the failure.
         *
         * @param      loc locale, irrelevant. It is present for
         *             compatibility with the Failure's one
         * @return     strings
         */

        public String[] getMessages(Locale loc){
            Cli c = (Cli)(this.instance);
            int n = 1;
            String msg;
            ResourceBundle bun = null;
            if (c.report != null){
                bun = c.report.getBundle(0);
            } else {
                Locale l = loc;
                if (loc == null) l = Locale.getDefault();
                bun = ResourceBundle.getBundle(
//                    CliBundle.class.getName(),l);
                    "lbj.CliBundle",l);
            }
            String[] msgtabLoc = (String[])(bun.getObject("MSGTAB"));
            msg = msgtabLoc[this.code];
            String l1 = null;
            String l2 = null;
            String l3 = null;
            if (this.argPres){
                l1 = bun.getString("ARGUMENT") + ": " +
                    c.toArgString(this.an,this.ln);
            }
            if (this.code == ERR_IOERR){
                if (this.path != null){
                    l2 = bun.getString("ONFILE") + this.path;
                }
            } else if (this.path != null){
                l2 = this.path;
            }
            if (c.pass >= 1){                     // position defined
                if (this.argn <= -2){             // in an indirect file
                    l2 = bun.getString("ONFILE") +
                        c.loadArr[-this.argn-2].path;
                }
                String str;
                str = c.toString(this.argn,this.cursor,
                    c.argc,Integer.MAX_VALUE,10);
                if (str.length() > 0){
                    l3 = str;
                }
            }
            if (l1 != null) n++;
            if (l2 != null) n++;
            if (l3 != null) n++;
            String[] res = new String[n];
            res[0] = header("CLI",'F') + msg;
            n = 1;
            if (l1 != null) res[n++] = l1;
            if (l2 != null) res[n++] = l2;
            if (l3 != null) res[n++] = l3;
            return res;
        }
    }

    /**
     * Deliver the locale neutral message which corresponds to a given
     * error code.
     *
     * @param  c error code
     */

    private static String message(int c){
        if (msgtab == null) return Integer.toString(c);
        else if (c >= 0) return msgtab[c];
        else return Integer.toString(c);
    }

    /**
     * Initialize the exception and return status.
     */

    private void excInit(){
        this.res = 0;
        this.excObj = null;
    }

    /**
     * Terminate the exception and return status.
     */

    private void excTerm(){
        if (this.res > 0){
            signalError();
        } else {
            this.excObj = null;
        }
    }

    /**
     * Create an exception object if one is not present.
     *
     * @param      code error code
     * @param      pres argument indexes present
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     * @param      path additional string
     * @param      exc additional exception
     */

    private void registerError(int code, boolean pres, int an,
        int ln, String path, Throwable exc){
        if (exc instanceof OutOfMemoryError){
            this.elems = null;                  // free some memory
            this.argv = null;
            this.args = null;
            this.com = null;
            this.coms = null;
            this.loadArr = null;
            pres = false;
        }
        this.res = code;
        if (this.excObj == null){
            this.excObj = new CliError(code,this);
            this.excObj.argPres = pres;
            this.excObj.an = an;
            this.excObj.ln = ln;
            this.excObj.argn = this.argn;
            this.excObj.cursor = this.cursor;
            this.excObj.exc = exc;
            this.excObj.path = path;
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("registerError: " + message(code) +
                " " + this.errthrow + " " + code);
            if (exc != null){
                Trc.out.println("exc: " + this.excObj.exc.toString());
            }
        }
        if ((FL_F & this.trc) != 0){
            Trc.out.println("registerError: " + code);
            if (exc != null) Trc.out.println(exc.toString());
            Throwable t = new Throwable();
            t.printStackTrace();
            System.exit(0);
        }
    }

    /**
     * Create an exception object if one is not present.
     *
     * @param      code error code
     */

    private void registerError(int code){
        registerError(code,false,0,0,null,null);
    }

    /**
     * Create an exception object if one is not present.
     *
     * @param      code error code
     * @param      exc additional exception
     */

    private void registerError(int code, Throwable exc){
        registerError(code,false,0,0,null,exc);
    }

    /**
     * Create an exception object if one is not present.
     *
     * @param      code error code
     * @param      exc additional exception
     * @param      path additional string
     */

    private void registerError(int code, Throwable exc, String path){
        registerError(code,false,0,0,path,exc);
    }

    /**
     * Handle an error: abort the program or throw an exception.
     */

    private void signalError(){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("error signal " + this.res +
                " " + this.errthrow);
        }
        if (this.errthrow == ERR_ABORT){
            if ((FL_A & this.trc) != 0){
                Trc.out.println("error abort");
            }
            this.excObj.print(this.repstream,this.locale,false);
            System.exit(1);
        } else if (this.errthrow == ERR_THROW){
            if ((FL_A & this.trc) != 0){
                Trc.out.println("error throw");
            }
            this.excObj.fillInStackTrace();
            throw this.excObj;
        }
    }

    /**
     * Throw an error and register the error data.
     *
     * @param      code error code
     */

    private void error(int code){
        registerError(code);
        throw this.excObj;
    }

    /**
     * Throw an error and register the error data.
     *
     * @param      code error code
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     */

    private void error(int code, int an, int ln){
        registerError(code,true,an,ln,null,null);
        throw this.excObj;
    }

    /** Convenience constant to denote an error on the current argument. */

    private static final byte ARG = 0;

    /**
     * Throw an error and register the error data.
     *
     * @param      code error code
     * @param      arg the constant ARG
     */

    private void error(int code, byte arg){
        registerError(code,true,this.arg_an,this.arg_ln,null,null);
        throw this.excObj;
    }

    /**
     * Throw an error and register the error data.
     *
     * @param      code error code
     * @param      exc exception
     * @param      path path of the file on which the error occurred
     * @param      arg the constant ARG
     */

    private void error(int code, Throwable exc, String path, byte arg){
        registerError(code,false,this.arg_an,this.arg_ln,path,exc);
        throw this.excObj;
    }


    /**
     * Throw an error and register the error data.
     *
     * @param      code error code
     * @param      exc additional exception
     */

    private void error(int code, Throwable exc){
        registerError(code,false,0,0,null,exc);
        throw this.excObj;
    }

    /**
     * Throw an error and register the error data.
     *
     * @param      code error code
     * @param      path additional string
     */

    private void error(int code, String path){
        registerError(code,false,0,0,path,null);
        throw this.excObj;
    }

    /**
     * Throw an error and register the error data.
     *
     * @param      code error code
     * @param      exc additional exception
     * @param      path additional string
     */

    private void error(int code, Throwable exc, String path){
        registerError(code,false,0,0,path,exc);
        throw this.excObj;
    }

    /**
     * Throw an exception for testing.
     *
     * @param      c error code
     */

    void throwExc(int c){
        excInit();
        this.pass = -1;
        try {
            switch(c){
            case ERR_NOCORE:
                throw new OutOfMemoryError();
            case ERR_IOERR:
                Formatter fpk = new Formatter(Formatter.RET_STATUS);
                fpk.f("%aj-%h").v("tmp.cli").v(30).write();
                error(ERR_IOERR,fpk.excObj);
            case ERR_INVDEF:
                error(ERR_INVDEF);
            }
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
    }

    /* Trace */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    a   basic operations
     *    b   user trace
     *    c   actions
     *    d   check on command definition
     *    e   even more details
     *    f   fatal abort on error
     *    l   load indirect files
     *    m   allocation
     *    s   search of names
     *    v   values
     * </pre></blockquote><p>
     */

    /*
     * Internal constants for trace flags
     */

    private static final int FL_A = 1 << ('a'-0x60);
    private static final int FL_B = 1 << ('b'-0x60);
    private static final int FL_C = 1 << ('c'-0x60);
    private static final int FL_D = 1 << ('d'-0x60);
    private static final int FL_E = 1 << ('e'-0x60);
    private static final int FL_F = 1 << ('f'-0x60);
    private static final int FL_L = 1 << ('l'-0x60);
    private static final int FL_M = 1 << ('m'-0x60);
    private static final int FL_R = 1 << ('r'-0x60);
    private static final int FL_S = 1 << ('s'-0x60);
    private static final int FL_V = 1 << ('v'-0x60);

    /**
     * Deliver a trace flag.  Trace flags mapping is a = b1, b = b2 ...
     *
     * @param      c character
     */

    private boolean fl(char c){
        return ((1 << (c - 0x60)) & trc) != 0;
    }

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Test if the trace flag passed as argument is set.
     *
     * @param      f flag
     * @return     true if flag on
     */

     boolean isTrcOn(char f){
        return ((1 << (f - 0x60)) & this.trc) != 0;
    }

    /**
     * Locate the point in the command string and in the load indirect files
     * strings.
     *
     * @param      argn argument number to be located
     * @return     string representing the place
     */

    private String seek_placestr(int argn){
        String s;

        if (argn < -1){                // in an indirect file
            s = "(ind:" + (-argn-2) + ")";
        } else if (argn == -1){        // in the command
            s = "(cmd)";
        } else {                       // in a command segment
            s = "(arg:" + argn + ")";
        }
        return s;
    }

    /**
     * Trace the current point in the parsing of the command.
     * It locates the point in the command string and in the load
     * indirect files strings.
     *
     * @param      s comment string
     */

    private void trcpoint(String s){
        int    ind;
        Object str;

        if (this.isStr) str = this.string;
        else str = this.buffer;
        Formatter fpk = new Formatter();
        Trc.out.println(fpk.f("%s cur: %s %i |%sU;|").v(s)
            .v(seek_placestr(this.argn))
            .v(this.cursor).v(str,this.cursor,this.end).doString());
    }

    /**
     * Print the contents of the element's table.
     */

    void trc_eletab(){
        int seq = 0;
        Element e;
        Argument a;
        a = this.cmddes;
        e = this.elems[seq++];
        if (e.ini >= 0) trcElem(e,-1,-1);
        int amax = this.cmddes.args.length;
        for (int an = 0; an < amax; an++){
            a = this.cmddes.args[an];
            e = this.elems[seq++];
            if (e.ini >= 0) trcElem(e,an,-1);
            if (e.ini < 0){
                seq += a.args.length;
            } else {
                Argument ar = a;
                int qmax = ar.args.length;
                for (int ln = 0; ln < qmax; ln++){
                    a = ar.args[ln];
                    e = this.elems[seq++];
                    if (e.ini >= 0) trcElem(e,an,ln);
                }
            }
        }
        amax = this.dfldes.length;
        for (int an = 0; an < amax; an++){
            a = this.dfldes[an];
            e = this.elems[seq++];
            if (e.ini >= 0) trcElem(e,idxDefault(an),-1);
            if (e.ini < 0){
                seq += a.args.length;
            } else {
                Argument ar = a;
                int qmax = ar.args.length;
                for (int ln = 0; ln < qmax; ln++){
                    a = ar.args[ln];
                    e = this.elems[seq++];
                    if (e.ini >= 0) trcElem(e,idxDefault(an),ln);
                }
            }
        }
    }

    /**
     * Trace an element.
     *
     * @param      e element
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     */

    private void trcElem(Element e, int an, int ln){
        String s = toAbbrev(e.argni,e.ini,e.argne,e.end,15);
        Trc.out.println(toSeq(an,ln) + " " + toArgString(an,ln) + " " +
            seek_placestr(e.argni) + " " + e.ini + ":" +
            seek_placestr(e.argne) + " " + e.end + " " +
            (e.neg ? "negated" : "") + " " + s + " cur: " +
            seek_placestr(e.argnc) + " " + e.cursor);
    }

    /**
     * Print the list of the command segments.
     */

    void trc_cmdarg(){
        String  s;
        int     i;

        if ((FL_C & this.trc) != 0){
            Trc.out.println((this.isStr ? "String" : "char[]"));
        }
        i = 0;
        if ((this.argv != null) || (this.args != null)){  // command in argument vector
            if ((FL_C & this.trc) != 0){
                Trc.out.println("vector");
            }
            for (i = 0; i < this.argc; i++){
                if ((FL_C & this.trc) != 0){
                    String as;
                    if (this.args != null) as = this.args[i];
                    else as = String.valueOf(this.argv[i]);
                    Trc.out.println(i + ": |" + as + "|");
                }
                int len;
                if (this.argv != null) len = this.argv[i].length;
                else len = this.args[i].length();
                Trc.out.println("cmd:" + i + " " +
                    toString(i,0,i,len,0));
            }
        } else if ((this.coms != null) || (this.com != null)){
            if ((FL_C & this.trc) != 0){
                String as;
                if (this.coms != null) as = this.coms;
                else as = String.valueOf(this.com);
                if ((this.comLen > 0) && (this.comLen < this.end)){
                    as = as.substring(0,this.comLen);
                }
                Trc.out.println("|" + as + "|");
            }
            Trc.out.println("cmd " + toString());
        }
    }

    /**
     * Print the contents of the load areas.
     */

    void trc_loadlist(){
        int amax = this.cmddes.args.length;
        int lmax = (this.loadArr == null)
            ? 0 : this.loadNr;
        for (int i = 0; i < lmax; i++){
            String name = "ind";
            for (int j = 0; j < amax; j++){        // determine argument
                if ((AR_IND & this.cmddes.args[j].attr) == 0) continue;
                Element e = this.elems[toSeq(j)];
                if (e.ini == -1) continue;
                if (e.argni == -i - 2){
                    name = this.cmddes.args[j].name;
                    break;
                }
            }
            ShellStream l = this.loadArr[i];
            Trc.out.println(i + " " + name + " " +
                String.valueOf(l.load,0,l.length));
        }
    }


    /* Memory management */

    /** Mnemonics of the heap entries. */
    static final String[] HEAP_KIND = {
        "argn","argv","elemv","elemn","loadv","loadn","loada","str"};

    private static final int HEAP_ARGV   = 0;
    private static final int HEAP_ARGN   = 1;
    private static final int HEAP_ELEMV  = 2;
    private static final int HEAP_ELEMN  = 3;
    private static final int HEAP_LOADV  = 4;
    private static final int HEAP_LOADN  = 5;
    private static final int HEAP_LOADA  = 6;
    private static final int HEAP_STR    = 7;

    /**
     * Build a map of the memory used.
     *
     * @param      map array in which the sizes are returned
     */

    void map_mem(int[] map){
        if ((this.argv != null) || (this.args != null)){
            if (this.argv != null){
                map[HEAP_ARGN] = this.argv.length;
                for (int i = 0; i < this.argv.length; i++){
                    if (this.argv[i] != null){
                        map[HEAP_ARGV] += this.argv[i].length;
                        if (map[HEAP_ARGV] < 0) error(ERR_OUTLIMIT);
                    }
                }
            } else {
                map[HEAP_ARGN] = this.args.length;
                for (int i = 0; i < this.args.length; i++){
                    if (this.args[i] != null){
                        map[HEAP_ARGV] += this.args[i].length();
                        if (map[HEAP_ARGV] < 0) error(ERR_OUTLIMIT);
                    }
                }
            }
        }
        map_arr(map,this.elems,HEAP_ELEMN,HEAP_ELEMV);
        map_arr(map,this.loadArr,HEAP_LOADN,HEAP_LOADV);
        if (this.loadArr != null){
            for (int i = 0; i < this.loadArr.length; i++){
                if ((this.loadArr[i] != null) &&
                    (this.loadArr[i].load != null)){
                    map[HEAP_LOADA] += this.loadArr[i].load.length;
                    if (map[HEAP_LOADA] < 0) error(ERR_OUTLIMIT);
                }
            }
        }
        map[HEAP_STR] = (this.str == null) ? 0 :  this.str.length;
    }

    /**
     * Fill the memory map with the occupation of an array.
     *
     * @param      map array in which the sizes are stored
     * @param      a array to enroll
     * @param      ma map entry for the array size
     * @param      me map entry for the array elements number
     */

    private void map_arr(int[] map, Object[] a, int ma, int me){
        if (a != null){
            map[ma] = a.length;
            for (int i = 0; i < a.length; i++){
                if (a[i] != null) map[me]++;
                if (map[me] < 0) error(ERR_OUTLIMIT);
            }
        }
    }

    /**
     * Trace the memory map.
     */

    void trc_map_mem(){
        int[] map = new int[HEAP_KIND.length];
        map_mem(map);
        for (int i = 0; i < map.length; i++){
            Trc.out.println(HEAP_KIND[i] + " " + map[i]);
        }
    }

    /* Initialization and termination */

    /** The width of the report. */
    private static final int PRT_DEF_WIDTH = 80;

    /**
     * Initialize this Cli object.
     *
     * @see        #init(int, String, Locale , Object)
     */

    public void init(){
        init(0,null,null,System.err);
    }

    /**
     * Initialize this Cli object.
     *
     * @see        #init(int, String, Locale , Object)
     */

    public void init(int mode){
        init(mode,null,null,System.err);
    }

    /**
     * Initialize this Cli object.
     *
     * @see        #init(int, String, Locale , Object)
     */

    public void init(String bundle){
        init(0,bundle,null,System.err);
    }

    /**
     * Initialize this Cli object.
     *
     * @see        #init(int, String, Locale , Object)
     */

    public void init(String bundle, Locale loc){
        init(0,bundle,loc,System.err);
    }

    /**
     * Initialize this Cli object.
     *
     * @see        #init(int, String, Locale , Object)
     */

    public void init(String bundle, Object rep){
        init(0,bundle,null,rep);
    }

    /**
     * Initialize a command interpreter object. It sets:
     * <ul>
     * <li>the syntax preferences according to the underlying host.
     * <li>interactive mode if the program is running interactively
     * </ul>
     *
     * @param      mode preferences and other settings
     * @param      bundle name of the bundle containing the command
     *             definition(s) or the messages
     * @param      loc locale, null if the default one
     * @param      rep report stream, System.err if null
     */

    /* The initialization of the report stream is done in two steps
     * so as to have a stream to use to print a message when the registration
     * of the bundle fails.
     *
     * When there are errors in rep, they are reported because the caller
     * wanted to use a particular report stream, and must be told that his
     * request has not been honored. Then, the report stream is opened
     * on System.err so as to have a way to show the error.
     * The width is set to the value of PRT_WIDTH (display width) - 1
     * not to cause a blank line.
     */

    public void init(int mode, String bundle, Locale loc, Object rep){
        int      i;
        Argument a;
        Element  e;
        String key = "";

        excInit();
        try{
            this.pass = 0;
            this.mode = mode;

            this.buffer = null;
            this.string = null;
            this.str = null;
            this.strLen = 0;
            this.comLen = 0;
            this.isStr = false;
            this.cursor = -1;                   // no position
            this.argc = 0;
            this.argn = -1;
            this.argv = null;
            this.args = null;
            this.com = null;
            this.coms = null;
            this.resource = null;
            this.cmdKey = null;
            this.cmdLoc = null;
            this.elems = null;
            this.loadArr = null;
            this.loadNr = 0;
            this.inpInd = new IoStream(".com");
            this.cmddes = null;
            this.cmdSet = null;

            this.promptForm = null;
            this.repstream = rep;
            if (rep == null) this.repstream = System.err;
            this.report = new Formatter();
            int col = PRT_DEF_WIDTH-1;
            Integer columns = Integer.getInteger("COLUMNS");
            if (columns != null) col = columns.intValue();
            try {
                this.report.f("%al%mf").v(this.repstream).v(col)
                    .write();
            } catch (FormatterError exc){
                registerError(ERR_IOERR,exc);
                this.report.f("%al%mf").v(System.err).v(col)
                    .write();
                throw this.excObj;
            }

            this.dfldesLoc = null;
            this.valStrLoc = null;
            this.dfldesFix = null;
            this.valStrFix = null;
            this.bundle = null;
            this.defLocale = null;
            if (loc == null){
                loc = Locale.US;                // default
            }
            if (bundle == null){                // nothing localized
                this.mode |= FIXLOC;
                this.locale = loc;
            } else {
                if (bundle.length() > 0) this.bundle = bundle;
                this.locale = getDefault();
            }
            if ((FIXLOC & this.mode) != 0){
                this.report.f("%mld1").v(loc).write();
            }
            this.report.f("%ml1%mms0")
//                .v(CliBundle.class.getName()).write();
                .v("lbj.CliBundle").write();
            this.locMsg = false;
            ResourceBundle bunFix =
                ResourceBundle.getBundle
//                (CliBundle.class.getName(),loc);
                ("lbj.CliBundle",loc);
            key = "VALUES";
            this.valStrFix = (String[])(bunFix.getObject(key));
            this.valStr = this.valStrFix;
            if ((FIXLOC & this.mode) != 0){
                this.valStrLoc = this.valStrFix;
            }
            if ((NODEFLT & this.mode) == 0){
                key =
                    ((NOUSAGE & this.mode) == 0) ? "DEFARGS" : "DEFIND";
                this.dfldesFix = (Qualifier[])(bunFix.getObject(key));
            } else {
                this.dfldesFix = EMPTY_ARGS;
            }
            this.dfldes = this.dfldesFix;
            if (msgtab == null){
                key = "MSGTAB";
                msgtab = (String[])(bunFix.getObject(key));
            }

            this.stin = FileSpec.STDIN;
            this.instance = null;
            this.version = null;

            if ((FIXED & this.mode) == 0){
                this.mode &= ~(FIXED-1);      // clear platform preferences
                String shell =
                    System.getProperty("shell");
                if (shell == null){
                    if (Prg.os == Prg.VMS){   // default mode
                        this.mode |= DCL;
                    } else if (Prg.os == Prg.WIN){
                        this.mode |= WIN;
                    } else if (Prg.os == Prg.UNIX){
                        this.mode |= UNIX;
                    }
                } else {
                    if ("DCL".equals(shell)) this.mode |= DCL;
                    else if ("WIN".equals(shell)) this.mode |= WIN;
                    else if ("UNIX".equals(shell)) this.mode |= UNIX;
                }
            }
            if ((FL_A & this.trc) != 0)
                Trc.out.println("init " + Prg.os + " " +
                    Integer.toOctalString(this.mode));
            if (Prg.interactive())
                this.mode |= INTER;           // running interactively

            this.ele = new Element();         // temporary element
            ini_cmdref();                     // init indexes of command string
            start(null);                      // init parsing state
            if ((FL_A & this.trc) != 0){
                Trc.out.println("initialized " +
                    this.pass + " " + this.locale + " " +
                    this.valStr[1] + " " + this.dfldes[1].name);
            }
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (MissingResourceException exc){
            registerError(ERR_RESOURCE,exc,key);
        } catch (SecurityException exc){
            registerError(ERR_SECURITY,exc);
        } catch (FormatterError exc){
            registerError(ERR_IOERR,exc);
        } catch (CliError exc){
        } finally {
            if (this.res != 0){
                Throwable exc = this.excObj;
                this.excObj = null;
                registerError(ERR_NOINIT,exc);
            }
            excTerm();
        }
    }

    /**
     * Initialize the fields of the object which hold the current
     * state of parsing. It is used at the beginning of parsing and when
     * there is a need to reparse a command.
     *
     * @param      cmd reference to the command descriptor
     */

    void start(Command cmd){
        Argument a;
        Element  e;
        int      narg;                            // number of arguments

        if ((FL_A & this.trc) != 0)
            Trc.out.println("start " + cmd);
        this.curpar = -1;
        this.arg_an = -1;
        this.arg_ln = -1;
        this.posixcur = Integer.MAX_VALUE;        // no posix -- found
        this.posixargn = Integer.MAX_VALUE;

        this.loadNr = 0;
        this.nest = 0;
        ele: if (cmd != null){
            this.cmddes = cmd;
            narg = argNum();                      // elements for all args
            int curLen = (this.elems == null)
                ? 0 : this.elems.length;          // element table for new command
            ensureElems(narg,curLen);
            for (int i = 0; i < narg; i++){       // initialize elem table
                e = this.elems[i];
                e.ini = -1;
                e.integral = 0;
                e.real = 0.0D;
                e.obj = null;
                this.elems[i].ini = -1;
            }
            if ((FL_M & this.trc) != 0)
                Trc.out.println("element table " + narg + " elems (+" +
                    (narg-curLen) + ")");
        }
        this.pass = 1;                            // syntax check pass
        if ((FL_A & this.trc) != 0)
            Trc.out.println("cleaned " +
                ((this.cmddes != null) ? this.cmddes.name : "null"));
    }

    /**
     * Ensure that the elements table is wide enough.
     *
     * @param      narg desired length
     * @param      curLen current length
     */

    private void ensureElems(int narg, int curLen){
        if (narg < 0) error(ERR_OUTLIMIT);
        Element[] cur = this.elems;
        if (curLen < narg){
            Element[] p = new Element[narg];
            if (cur != null)
                System.arraycopy(cur,0,p,0,curLen);
            this.elems = p;
        }
        for (int i = curLen; i < narg; i++){      // allocate elements
            this.elems[i] = new Element();
        }
    }

    /**
     * Initialize the indexes of the command string.
     */

    void ini_cmdref(){
        this.res = 0;                         // no errors
        this.cursor = 0;
        if ((this.argv != null) ||            // vector
            (this.args != null)){
            reposition(0,0);
        } else if ((this.com != null) ||
            (this.coms != null)){
            reposition(-1,0);
        } else {
            this.end = 0;
        }
        this.ini = 0;
        if ((FL_C & this.trc) != 0){
            trc_cmdarg();
        }
    }


    /**
     * Reposition the input stream to a given position.
     *
     * @param      argn argument number
     * @param      cur cursor
     */

    void reposition(int argn, int cur){
        if (argn < -1){                   // in an indirect file
            ShellStream l = this.loadArr[-argn-2];
            this.buffer = l.load;
            this.end = l.length;
            this.isStr = false;
        } else if (argn == -1){           // in the command
            if (this.com != null){
                this.buffer = this.com;
                this.end = this.buffer.length;
            } else {
                this.string = this.coms;
                this.end = this.string.length();
            }
            if ((this.comLen > 0) && (this.comLen < this.end))
                this.end = this.comLen;
            this.isStr = this.coms != null;
        } else {                          // in a command segment
            if (argn < this.argc){
                if (this.argv != null){
                    this.buffer = this.argv[argn];
                    if (this.buffer.length == 0)
                        this.buffer = emptycharr;
                    this.end = this.buffer.length;
                } else {
                    this.string = this.args[argn];
                    if (this.string.length() == 0)
                        this.string = emptystring;
                    this.end = this.string.length();
                }
                this.isStr = this.args != null;
            } else {
                if (this.argv != null){
                    this.buffer = emptycharr;
                    this.isStr = false;
                } else {
                    this.string = emptystring;
                    this.isStr = true;
                }
                this.end = cur;             // make skip() return false
            }
        }
        this.cursor = cur;
        if (cur < 0) this.cursor = this.end;  // for testing
        this.argn = argn;
        if ((FL_C & this.trc) != 0){
            trcpoint("reposition");
        }
    }

    /**
     * Update a Cli object to be consistent with the default locale.
     *
     * @param      key keyword of the command, if localized, null otherwise
     */

    /* Updatelocale allocates a new resource bundle only when the locale
     * changes. Moreover, it rereads the VALUES only when the locale changes
     * and installs the fixed ones when a parse() is done with a command
     * which is not taken from the bundle.
     * Moerover, a localised command definition is read from the bundle
     * only the first time or when the key is changed or the current locale
     * is changed.
     */

    private void updateLocale(String key){
        ResourceBundle bun;
        boolean newlocale = false;
        String kwd = "";

        bun = this.report.getBundle(0);
        if ((FIXLOC & this.mode) == 0){
            if (!this.locale.equals(getDefault())){
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("updateLocale " + this.locale +
                        " " + getDefault());
                }
                this.locale = getDefault();
                newlocale = true;
            }
            if (newlocale){
                this.valStrLoc = null;
            }
            if (this.valStrLoc == null){
                kwd = "VALUES";
                this.valStrLoc = (String[])(bun.getObject(kwd));
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("updateLocale new values "
                        + this.valStrLoc[1]);
                }
            }
        }
        if (this.bundle != null){
            try {
                if (newlocale){
                    this.resource = null;
                }
                if (this.resource == null){
                    this.resource = ResourceBundle.getBundle
                        (this.bundle,this.locale);
                    if ((FL_C & this.trc) != 0){
                        Trc.out.println("updateLocale new resource");
                    }
                }
                if (newlocale){
                    this.dfldesLoc = null;
                    this.cmdLoc = null;
                }
                if (this.dfldesLoc == null){
                    if ((NODEFLT & this.mode) == 0){
                        kwd =
                            ((NOUSAGE & this.mode) == 0) ?
                            "DEFARGS" : "DEFIND";
                        this.dfldesLoc = (Qualifier[])
                            (bun.getObject(kwd));
                    }
                }
                if (this.locMsg){
                    this.valStr = this.valStrFix;  // command not localized
                    if ((NODEFLT & this.mode) == 0){
                        this.dfldes = this.dfldesFix;
                    }
                    return;                        // only messages
                }
                this.valStr = this.valStrLoc;      // make it current
                this.dfldes = this.dfldesLoc;      // make it current
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("updateLocale " +
                        this.cmdKey + " " + this.bundle +
                        " " + this.valStr[1]);
                }
                if (!key.equals(this.cmdKey) || (this.cmdLoc == null)){
                    this.cmdKey = key;
                    kwd = this.cmdKey;
                    this.cmdLoc = this.resource.getObject(kwd);
                    if ((FL_C & this.trc) != 0){
                        Trc.out.println("updateLocale getObject reload "
                            + this.cmdLoc);
                    }
                    if ((FL_C & this.trc) != 0){
                        Trc.out.println("cmdLoc: " + this.cmdLoc);
                    }
                }
                if (this.cmdLoc == null) error(ERR_INVDEF);
                if (this.cmdLoc.getClass() == Command.class){
                    this.cmddes = (Command)(this.cmdLoc);
                } else if (this.cmdLoc.getClass() == Command[].class){
                    this.cmdSet = (Command[])(this.cmdLoc);
                } else {
                    error(ERR_INVDEF);
                }
            } catch (MissingResourceException exc){
                error(ERR_INVDEF,exc,kwd);
            }
        }
    }

    /**
     * Deliver the default locale, which is the global default one
     * or a given one, if configured.
     *
     * @return     locale
     */

    private Locale getDefault(){
        if (this.defLocale != null){
            if (this.defLocale instanceof Locale){
                return (Locale)(this.defLocale);
            } else {
                return ((Lang)(this.defLocale)).getDefault();
            }
        } else {
            return Locale.getDefault();
        }
    }

    /**
     * Set a new default locale.
     *
     * @param      loc locale
     */

    public void setDefault(Object loc){
        excInit();
        try {
            if (loc == null){
                error(ERR_ILLVAL);
            }
            if ((loc instanceof Locale) || (loc instanceof Lang)){
                this.defLocale = loc;
                this.report.f("%mld1").v(loc).write();
            } else {
                error(ERR_ILLVAL);
            }
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (FormatterError exc){
            registerError(ERR_IOERR,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
    }

    /**
     * Terminate the Cli object. It is meant to be called before letting
     * the garbage collector reclaim the memory so as to free the system
     * resources before the object is garbage collected.
     * To reuse a terminated Cli object, reinitialize it.
     */

    public void terminate(){
        excInit();
        try {
            start(null);
            this.elems = null;                  // free elements table
            this.argv = null;                   // free vector
            this.args = null;
            this.com = null;
            this.coms = null;
            this.loadArr = null;
            this.report.f("%z").write();
            if ((FL_B & this.trc) != 0){
                Trc.out.println("terminated");
            }
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (FormatterError exc){
            registerError(ERR_IOERR,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
    }


    /* Arguments sequencing */

    /**
     * Trace the arguments and print their sequence numbers.
     *
     * @param      cmd command descriptor
     */

    void trc_arg_seq(Command cmd){
        Argument a;
        this.cmddes = cmd;
        int amax = cmd.args.length;
        for (int i = 0; i < amax; i++){
            a = cmd.args[i];
            Trc.out.println(toSeq(i) + " " + a.name);
            if ((FL_C & this.trc) != 0){
                Trc.out.println(this.cmddes.argSeq[i]);
            }
            Argument ar = a;
            int qmax = ar.args.length;
            for (int j = 0; j < qmax; j++){
                Trc.out.println("  " +
                   (toSeq(i,j)) + " " + ar.args[j].name);
            }
        }
        Trc.out.println(cmd.argMax);
    }

    /**
     * Deliver the total number of arguments in the command, including the
     * verb, the local qualifiers and the default arguments.
     *
     * @return     number of arguments
     */

    int argNum(){
        int narg;
        narg = this.cmddes.argMax + 1;        // elements for args + verb
        if (narg < 0) error(ERR_OUTLIMIT);
        narg += this.dfldes.length;           // dfldes elements
        if (narg < 0) error(ERR_OUTLIMIT);
        int amax = this.dfldes.length;        // and their local qualifiers
        for (int i = 0; i < amax; i++){
            narg += this.dfldes[i].args.length;
            if (narg < 0) error(ERR_OUTLIMIT);
        }
        return narg;
    }

    /**
     * Deliver the sequence number from an argument number.
     *
     * @param      an argument number
     * @return     sequence number
     */

    int toSeq(int an){
        int seq = 0;

        if (an == -1){                              // command
            seq = 0;
        } else if ((an < 0) &&
            (-an-2 < this.dfldes.length)){          // in default quals
            seq = this.cmddes.argMax - an - 2;
        } else if (an < this.cmddes.args.length){   // in command
            seq = this.cmddes.argSeq[an];
        } else {
            error(ERR_UNKARG);
        }
        if ((FL_E & this.trc) != 0){
            Trc.out.println("toSeq: " + an + " " +
                seq + " " + this.cmddes.args.length +
                " " + this.cmddes.argMax);
        }
        return seq;
    }

    /**
     * Deliver the sequence number from an argument and a local qualifier
     * numbers.
     *
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     * @return     sequence number
     */

    int toSeq(int an, int ln){
        Argument a = null;
        int      seq = 0;

        if (an == -1){                              // command
            seq = 0;
        } else if ((an < 0) &&
            (-an-2 < this.dfldes.length)){          // in default quals
            seq = this.cmddes.argMax - an - 2;
            a = this.dfldes[-an-2];
            if (ln >= 0){
                if (ln >= a.args.length){
                    error(ERR_UNKARG);
                }
                seq += ln + 1;                      // local qualifier
            }
        } else if (an < this.cmddes.args.length){   // in command
            seq = this.cmddes.argSeq[an];
            a = this.cmddes.args[an];
            if (ln >= 0){
                if (ln >= a.args.length){
                    error(ERR_UNKARG);
                }
                seq += ln + 1;                      // local qualifier
            }
        } else {
            error(ERR_UNKARG);
        }
        if ((FL_E & this.trc) != 0){
            Trc.out.println("toSeq: " + an + " " + ln + " " +
                seq + " " + this.cmddes.args.length +
                " " + this.cmddes.argMax);
        }
        return seq;
    }

    /**
     * Deliver the sequence number of the last parsed argument.
     */

    int toSeq(){
        return toSeq(this.arg_an,this.arg_ln);
    }

    /**
     * Deliver the number of a default qualifier from its (relative) number.
     *
     * @param      an qualifier (relative) number
     * @return     index
     */

    private int idxDefault(int an){
        int res = -an - 2;
        return res;
    }

    /**
     * Deliver a reference to an argument from its argument and local
     * qualifier numbers.
     *
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     * @return     argument reference
     */

    Argument toArgument(int an, int ln){
        Argument  a = null;
        Parameter par;

        if (an == -1){                              // command
            a = this.cmddes;
        } else if ((an < 0) &&
            (-an-2 < this.dfldes.length)){          // in default quals
            a = this.dfldes[-an - 2];
            if (ln >= 0){                           // local qualifier
               a = a.args[ln];
            }
        } else if (an < this.cmddes.args.length){   // in command
            a = this.cmddes.args[an];
            if (ln >= 0){                           // local qualifier
               a = a.args[ln];
            }
        }
        return a;
    }

    /**
     * Visit all arguments.
     */

    void visit(){
        int seq = 0;
        Element e;
        Argument a;
        if (this.elems == null) return;
        a = this.cmddes;
        e = this.elems[seq++];
        visitArg(e,-1,-1);
        int amax = this.cmddes.args.length;
        for (int an = 0; an < amax; an++){
            a = this.cmddes.args[an];
            e = this.elems[seq++];
            visitArg(e,an,-1);
            Argument ar = a;
            int qmax = ar.args.length;
            for (int ln = 0; ln < qmax; ln++){
                a = ar.args[ln];
                e = this.elems[seq++];
                visitArg(e,an,ln);
            }
        }
        amax = this.dfldes.length;
        for (int an = 0; an < amax; an++){
            a = this.dfldes[an];
            e = this.elems[seq++];
            visitArg(e,idxDefault(an),-1);
            Argument ar = a;
            int qmax = ar.args.length;
            for (int ln = 0; ln < qmax; ln++){
                a = ar.args[ln];
                e = this.elems[seq++];
                visitArg(e,an,ln);
            }
        }
    }

    /**
     * Visit an argument.
     *
     * @param      e element
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     */

    private void visitArg(Element e, int an, int ln){
        Trc.out.println(toSeq(an,ln) + " " + toArgString(an,ln) +
            " " + e.ini + " " + e.argni +
            " " + e.cursor + " " + e.argnc +
            " " + e.end + " " + e.argne);
    }

    /* Command definition */

    /**
     * Check a command definition. It returns the error code in the
     * Cli object.
     *
     * @param      cmd reference to the command descriptor
     */

    private void def_check(Command cmd){
        Argument   a;
        boolean    optpar;                   // true: an optional par encountered
        int        len;
        Parameter  par;
        Qualifier  qual;
        String     savstring;
        String     savcoms;
        boolean    savstr;
        byte       savpass;

        if (this.pass == 0){                 // not initialized
            error(ERR_SEQUENCE);
        }
        savpass = this.pass;                 // save it
        savstring = this.string;
        savcoms = this.coms;
        savstr = this.isStr;
        this.pass = -1;                      // check pass
        this.cmddes = cmd;
        if (cmd == null){                    // empty command
            error(ERR_NULLCMD);
        }
        if ((CHECKED & cmd.attr) != 0){      // command already checked
            if ((CASEINS & this.mode) ==     // .. and also with the same
                (CASEINS & cmd.attr))        // .. case selection
                 return;
            if ((FL_D & this.trc) != 0)
                Trc.out.println("re-checking");
        }
        cmd.attr |= CHECKED;                 // mark it
        if ((CASEINS & this.mode) != 0){
            cmd.attr |= CASEINS;             // remember case
        } else {
            cmd.attr &= ~CASEINS;            // remember case
        }
        if ((cmd.name == null) ||            // empty name
            (cmd.name.length() == 0)){
            error(ERR_MISNAME,VERB,-1);
        }
        len = cmd.name.length();
        this.isStr = true;
        this.string = cmd.name;
        this.coms = cmd.name;
        this.cursor = 0;
        this.end = len;
        if (!get_argname()){                 // illegal verb
            error(ERR_ILLNAME,VERB,-1);
        }

        if (cmd.argMax < 0) error(ERR_OUTLIMIT,VERB,-1);
        optpar = false;

        int amax = cmd.args.length;
        for (int an = 0; an < amax; an++){
            a = cmd.args[an];
            if ((FL_D & this.trc) != 0)
                Trc.out.println("checking arg nr: " + an +
                    " " + a.name);
            if ((AR_PAR & a.attr) != 0){             // parameter
                par = (Parameter)a;
                qual = null;
                if (((AR_REQ & a.attr) != 0) &&      // mandatory parameter
                    optpar){                         // .. after an optional one
                    error(ERR_ILLATTR,an,-1);
                }
                optpar = (AR_REQ & a.attr) == 0;
                check_arg(cmd,a,an,-1,par,qual);
            } else {                                 // command qualifier
                check_arg(cmd,a,an,-1,null,(Qualifier)a);
                if ((AR_LIST & a.attr) != 0){        // value list with
                    if (a.args.length > 0){          // .. local qualifiers
                        error(ERR_NOLIST,an,-1);
                    }
                }
            }
            int qmax = a.args.length;
            for (int ln = 0; ln < qmax; ln++){
                qual = (Qualifier)(a.args[ln]);
                if (qual.args != EMPTY_ARGS){
                    error(ERR_ILLQUAL,an,ln);
                }
                check_arg(cmd,qual,an,ln,a,qual);
            }
        }
        this.string = savstring;
        this.coms = savcoms;
        this.isStr = savstr;
        this.pass = savpass;                         // restore it
    }

    /**
     * Check an argument. It must not be called on default arguments.
     *
     * @param      cmd reference to the command descriptor
     * @param      a reference to the argument descriptor
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     * @param      ar reference to the enclosing argument
     * @param      qual reference to the argument, if qualifier
     */

    private void check_arg(Command cmd, Argument a, int an, int ln,
        Argument ar, Qualifier qual){
        Argument p;
        int len;

        if ((FL_D & this.trc) != 0){
            Trc.out.println("check_arg " + a.name +
                " " + a.type + " " + an + " " + ln);
        }
        if ((a.name == null) ||                  // empty name
            (a.name.length() == 0)){
            error(ERR_MISNAME,an,ln);
        }
        if (a.name.length() == 1){               // one-character name
            error(ERR_ILLNAME,an,ln);
        }
        len = a.name.length();
        this.string = a.name;
        this.coms = a.name;
        this.cursor = 0;
        this.end = len;
        if (!get_argname()){                     // illegal name
            error(ERR_ILLNAME,an,ln);
        }
        if (qual != null){                       // qualifier
            if (qual.sname != ' '){              // short name not present
                if (!get_argname(qual.sname)){   // illegal name
                    error(ERR_ILLNAME,an,ln);
                }
            }
        }
        int me = an;
        if (ln >= 0) me++;                       // local qual, check also
        for (int k = 0; k < me; k++){            // .. the parameter
            p = cmd.args[k];
            if ((FL_D & this.trc) != 0)
                Trc.out.println("cross arg nr: " + toSeq(k) +
                    " " + p.name);
            if (check_names(a,p)){
                error(ERR_AMBNAME,an,ln);        // ambiguous name
            }
        }
        if (ln >= 0){                            // local qualifier
            for (int k = 0; k < ln; k++){
                p = ar.args[k];
                if ((FL_D & this.trc) != 0)
                    Trc.out.println("cross arg loc nr: " +
                        toSeq(an,ln) + " " + p.name);
                if (check_names(a,p)){
                    error(ERR_AMBNAME,an,ln);    // ambiguous name
                }
            }
        }
        for (int k = 0; k < this.dfldes.length; k++){
            p = this.dfldes[k];
            if (check_names(a,p)){               // clash with a default
                this.status |= 1<<(DFLT_OFF+k);  // .. argument
            }
        }
        if ((FL_D & this.trc) != 0){
            Trc.out.println("check_arg type");
        }
        checkType(a,an,ln);

        if ((AR_PAR & a.attr) != 0){          // parameter
            if (((AR_NEG & a.attr) != 0) ||   // negated
                ((AR_PLUS & a.attr) != 0)){   // +x
                error(ERR_ILLATTR,an,ln);     // illegal attribute
            }
        } else {
            if ((a.type == void.class) &&
                ((AR_VALREQ & a.attr) != 0)){
                error(ERR_ILLATTR,an,ln);     // required, but no value
            }
        }
        if ((AR_IND & a.attr) != 0){          // indirect file
            if ((AR_PAR & a.attr) != 0){      // parameter
                error(ERR_ILLIND,an,ln);      // illegal
            }
            if (ar != null){                  // local qualifier
                error(ERR_ILLIND,an,ln);      // illegal
            }
            if (a.type != String.class){      // illegal type
                error(ERR_ILLTYPE,an,ln);
            }
            if ((AR_VALREQ & a.attr) == 0){
                error(ERR_ILLATTR,an,ln);     // it must have a value
            }
            if ((~(AR_IND | AR_VALREQ | AR_USER)
                & a.attr) != 0){              // disallowed attribute
                error(ERR_ILLATTR,an,ln);     // illegal attribute
            }
            if (a.args != EMPTY_ARGS){
                if (a.args.length > 1){
                    error(ERR_ILLIND,an,ln);  // too many local qualifiers
                } else if (a.args.length == 1){
                    if ((a.args[0].attr & AR_ENC) == 0){
                        error(ERR_ILLIND,an,ln);  // not the encoding one
                    }
                }
            }
        }

        // check alternatives

        if ((AR_ALT & a.attr) != 0){          // alternative
            if ((AR_PAR & a.attr) != 0){      // parameter
                error(ERR_ILLATTR,an,ln);     // AR_ALT on a parameter
            }
            Argument pa = null;
            if (ln > 0){
                pa = ar.args[ln-1];
            } else if (an > 0){
                pa = cmd.args[an-1];
            }
            if (pa != null){
                if ((AR_ALT & pa.attr) != 0){      // check AR_REQ
                    if ((AR_REQ & a.attr) !=
                        (AR_REQ & pa.attr)){
                        error(ERR_ILLATTR,an,ln);  // different AR_REQ
                    }
                }
            }
        }
        if ((FL_D & this.trc) != 0){
            Trc.out.println("check_arg end " + a.name);
        }
    }

    /**
     * Check that the name of an argument does not clashes with respect
     * to that of another argument.
     *
     * @param      a reference to the argument
     * @param      p reference to the other argument
     * @return     <code>true</code> if ambiguous
     */

    private boolean check_names(Argument a, Argument p){
        if ((FL_D & this.trc) != 0){
            Trc.out.println("check_names " + a.name + " " + p.name);
        }
        boolean ins;
        boolean res;

        res = false;
        ins = (CASEINS & this.mode) != 0;
        doit: {
            if (streq(null,p.name,null,a.name,ins)){     // compare names
                res = true;                              // ambiguous name
                break doit;
            }
            if ((AR_NEG & p.attr) != 0){                 // negation allowed for p
                if (streq(this.valStr[NO],p.name,null,   // NOp == a ?
                    a.name,ins)){
                    res = true;                          // yes, ambiguous name
                    break doit;
                }
            }
            if ((AR_NEG & a.attr) != 0){                 // negation allowed for a
                if (streq(null,p.name,this.valStr[NO],   // p == NOa ?
                    a.name,ins)){
                    res = true;                          // yes, ambiguous name
                    break doit;
                }
            }
            if (((AR_NEG & p.attr) != 0) &&              // negation on both
                ((AR_NEG & a.attr) != 0)){               // NOp == NOa
                if (streq(this.valStr[NO],p.name,
                    this.valStr[NO],a.name,ins)){
                    res = true;                          // yes, ambiguous name
                    break doit;
                }
            }
            if (((AR_PAR & a.attr) == 0) &&              // qualifier
                ((AR_PAR & p.attr) == 0)){               // qualifier
                if ((((Qualifier)p).sname ==
                    ((Qualifier)a).sname) &&
                    (((Qualifier)a).sname != ' ') &&
                    ((AR_PLUS & a.attr) ==               // both -x or +x
                    (AR_PLUS & p.attr))){
                    res = true;                          // ambiguous short name
                    break doit;
                }
            }
        } // doit
        if ((FL_D & this.trc) != 0){
            Trc.out.println("check_names " + res);
        }
        return res;
    }

    /**
     * Check if a string possibly with a prefix is equal to another possibly
     * with a prefix.
     *
     * @param      np prefix of the first string
     * @param      p first string
     * @param      na prefix of the second string
     * @param      a second string string
     * @param      ins true if case insensitive match
     */

    private boolean streq(String np, String p, String na, String a,
        boolean ins){
        int offp = 0;
        int offa = 0;
        if ((FL_D & this.trc) != 0)
            Trc.out.println("streq: " + np+p + " " +
                na+a + " " + ins);
        diffnam: {
            if (np != null){
                offa = np.length();
                if (ins){                         // case insensitive
                    if (!a.regionMatches(true,0,np,0,offa))
                        break diffnam;            // it does not start with "no"
                } else {                          // case sensitive
                    if (Character.isUpperCase(p.charAt(1))){ // uppercase name
                        if (!startsUpper(a,np))   // it does not start with "NO"
                            break diffnam;
                    } else {
                        if (!a.startsWith(np))    // it does not start with "no"
                            break diffnam;
                    }
                }
            }
            if (na != null){
                offp = na.length();
                if (ins){                         // case insensitive
                    if (!p.regionMatches(true,0,na,0,offp))
                        break diffnam;            // it does not start with "no"
                } else {                          // case sensitive
                    if (Character.isUpperCase(a.charAt(1))){ // uppercase name
                        if (!startsUpper(p,na))   // it does not start with "NO"
                            break diffnam;
                    } else {
                        if (!p.startsWith(na))    // it does not start with "no"
                            break diffnam;
                    }
                }
            }
            if (p.length()-offp != a.length()-offa){
                break diffnam;
            }
            if (!p.regionMatches(ins,offp,a,offa,p.length()-offp)){
                break diffnam;
            }
            if ((FL_D & this.trc) != 0)
                Trc.out.println("match");
            return true;
        }
        if ((FL_D & this.trc) != 0)
            Trc.out.println("no match");
        return false;
    }

    /**
     * Check if a string starts with the uppercase form of a prefix.
     *
     * @param      str string
     * @param      prefix lowercase prefix
     */

    private boolean startsUpper(String str, String prefix) {
        int si = 0;                // index in str
        int send = str.length();
        int pi = 0;
        int plen = prefix.length();
        if (plen > send){          // string shorter than prefix
            return false;
        }
        while (--plen >= 0) {
            char c = prefix.charAt(pi++);
            char u = (c < 128) ? Str.UPPER[c] :
                Character.toUpperCase(c);
            if (str.charAt(si++) != u) {
                return false;
            }
        }
        return true;
    }

    /**
     * Check a set of command definitions.
     *
     * @param      cms set of command definitions
     */

    private void def_check(Command[] cms){
        if ((CHECKED & cms[0].attr) != 0){     // commands already checked
            if ((CASEINS & this.mode) ==       // .. and also with the same
                (CASEINS & cms[0].attr))       // .. case selection
                return;
            if ((FL_D & this.trc) != 0)
                Trc.out.println("re-checking");
        }
        for (int i = 0; i < cms.length; i++){  // check all commands now
            def_check(cms[i]);
            cms[i].code = (char)i;
        }
        boolean cas = (CASEINS & this.mode) == 0;
        int bound = cms.length - 1;
        do{                                    // bubble sort the array
            int t = 0;
            for (int j = 0; j < bound; j++){
                int com;
                if (cas){
                    com = cms[j].name.compareTo(cms[j+1].name);
                } else {
                    com = cms[j].name.compareToIgnoreCase(cms[j+1].name);
                }
                if (com == 0){                 // equal names
                    this.cmddes = cms[j];
                    error(ERR_AMBNAME,VERB,-1);
                }
                if (com > 0){                  // out of order
                    Command tmp = cms[j];      // swap them
                    cms[j] = cms[j+1];
                    cms[j+1] = tmp;
                    t = j;
                }
            }
            if (t == 0) break;                 // no swaps done
            bound = t;
        } while (true);
    }


    /**
     * Check a command definition. It returns the error code in the
     * Cli object.
     *
     * @param      cmd reference to the command descriptor
     */

    public void check(Command cmd){
        excInit();
        if ((FL_D & this.trc) != 0)
            Trc.out.println("begin check " + this.mode);
        try {
            def_check(cmd);
            if ((FL_D & this.trc) != 0)
                Trc.out.println("end check " + this.res +
                    " " + message(this.res));
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (FormatterError exc){
            registerError(ERR_IOERR,exc);
        } catch (CliError exc){
            if (this.res != ERR_SEQUENCE){
                this.excObj = null;
                registerError(ERR_INVDEF,false,0,0,null,exc);
            }
        } finally {
            excTerm();
        }
    }

    /**
     * Check a command set definition. It returns the error code in the
     * Cli object.
     *
     * @param      cms reference to the commands descriptor
     */

    public void check(Command[] cms){
        excInit();
        if ((FL_D & this.trc) != 0)
            Trc.out.println("begin check " + this.mode);
        try {
            def_check(cms);
            if ((FL_D & this.trc) != 0)
                Trc.out.println("end check " + this.res +
                    " " + message(this.res));
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (FormatterError exc){
            registerError(ERR_IOERR,exc);
        } catch (CliError exc){
            if (this.res != ERR_SEQUENCE){
                this.excObj = null;
                registerError(ERR_INVDEF,false,0,0,null,exc);
            }
        } finally {
            excTerm();
        }
    }


    /* Command parsing */

    /**
     * Register the command to be parsed.
     *
     * @param     com command to be parsed
     */

    public void setCmdLine(Object com){
        setCmdLine(com,0);
    }

    /**
     * Register the command to be parsed.
     *
     * @param     com command to be parsed
     * @param     len its length, if reduced
     */

    public void setCmdLine(Object com, int len){
        Class c = com.getClass();
        this.args = null;
        this.argv = null;
        this.com = null;
        this.coms = null;
        this.argc = 0;
        this.comLen = len;
        if (c == String.class){
            this.coms = (String)com;
        } else if (c == char[].class){
            this.com = (char[])com;
        } else if (c == String[].class){
            this.args = (String[])com;
            this.argc = this.args.length;
        } else {
            this.argv = (char[][])com;
            this.argc = this.argv.length;
        }
        if (this.argc >= Integer.MAX_VALUE-2)
            error(ERR_OUTLIMIT);
        ini_cmdref();                         // init indexes of command
    }

    /** The number of the current argument (being) parsed. */
    private int arg_an;

    /** The number of the current local qualifier (being) parsed. */
    private int arg_ln;

    /**
     * Deliver the number of the current argument.
     */

    int getAn(){
        return this.arg_an;
    }

    /**
     * Deliver the number of the current local qualifier.
     */

    int getLn(){
        return this.arg_ln;
    }

    /**
     * Parse a command. It checks the syntax and prepares the object to
     * deliver the data contained in the command. If determines the command
     * definition as follows:
     * <p><blockquote><pre>
     *    cmd null, no bundle:   cmddes
     *    cmd null, bundle:      the "COMMAND" in it
     *    cmd String, bundle:    the command associated to the key String in it
     *    cmd command:           cmd
     * </pre></blockquote><p>
     * When a definition of a set of commands is passed, it checks that the
     * command name matches one in the set, and then it parses its arguments
     * according to its definition, otherwise it does not check the name.
     *
     * @param     cmd command definition
     * @param     com command to be parsed
     * @param     len its length, if reduced
     * @param     ins reference to instance data
     */

    public void parse(Object cmd, Object com, int len, Object ins){
        setCmdLine(com,len);
        this.instance = ins;
        parse(cmd);
    }

    /**
     * Parse a command.
     *
     * @see        #parse(Object, Object, int, Object)
     */

    public void parse(Object cmd, Object ins){
        this.instance = ins;
        parse(cmd);
    }

    /**
     * Parse a command.
     *
     * @see        #parse(Object, Object, int, Object)
     */

    public void parse(Object cmd){
        Argument q;
        boolean  loc;
        boolean  res;

        excInit();
        try {
            if ((FL_C & this.trc) != 0)
                Trc.out.println("parse ");
            if (this.pass == 0){                  // not initialized
                error(ERR_SEQUENCE);
            }
            get_cmd_def(cmd);
            ini_cmdref();                         // init indexes of command
            if ((FL_B & this.trc) != 0){
                trcpoint("parse");
                Trc.out.println("parse command: " + toString());
            }
            skipws();                             // skip white space
            ele.clear();
            if ((NOCMDNAME & this.mode) == 0){
                ele.ini = this.cursor;            // remember token data
                ele.argni = this.argn;
                res = get_qvelem(false,ele,null,String.class);  // get verb
                ele.cursor = ele.ini;
                ele.argnc = ele.argni;
                ele.end = this.cursor;
                ele.argne = this.argn;
                if (!res || (this.strLen == 0)){  // no verb
                    error(ERR_NOCMD,VERB,-1);
                }
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("verb: " +
                        toAbbrev(ele.argni,ele.ini,
                            ele.argne,ele.end,0));
                }
                if (this.cmdSet != null){         // search command
                    this.cmddes = search_verb(this.cmdSet);
                }
            }
            start(this.cmddes);                   // initialize parsing
            Element e = this.elems[0];            // store the verb
            e.assign(ele);
            if ((FL_C & this.trc) != 0){
                trcpoint("past verb");
            }
            this.inpInd.restart(false);           // init file defaults for
                                                  // .. the command line
            parse_args();                         // parse arguments
            restartElems(this.res >= 0);          // reposition elements
            this.pass = 2;                        // end of syntax check pass

            if (this.res == 0){
                activate();                       // call callback
            }
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (FormatterError exc){
            registerError(ERR_IOERR,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
            if ((FL_B & this.trc) != 0){
                Trc.out.println("parse: returning: " +
                    message(this.res) + " " + this.res);
                if (this.res > 0) trcpoint("at");
            }
        }
    }        

    /**
     * Obtain a command or a set of command definitions according
     * to the current locale, and record them in the Cli object.
     *
     * @param      cmd command, command set or key of the definition
     *             in the bundle.
     */

    private void get_cmd_def(Object cmd){
        String key = null;
        Class  cl;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("get_cmd_def " + cmd);
        }
        this.locMsg = false;
        if (cmd != null){
            this.cmddes = null;
            this.cmdSet = null;
            cl = cmd.getClass();
            if (cl == Command.class){
                this.cmddes = (Command)cmd;
                if (this.bundle != null) this.locMsg = true;
            } else if (cl == Command[].class){
                this.cmdSet = (Command[])cmd;
                if (this.bundle != null) this.locMsg = true;
            } else if ((cl == String.class) && (this.bundle != null)){
                key = (String)cmd;
            } else {
                error(ERR_INVDEF,new ClassCastException());
            }
        } else {
            if (this.bundle != null){
                key = "COMMAND";
            }
        }
        updateLocale(key);
        if ((FL_C & this.trc) != 0){
            Trc.out.println("get_cmd_def " + this.bundle +
                " " + this.cmdKey + " " + this.locMsg);
        }
        try {                               // check definition(s)
            if (this.cmddes != null){
                def_check(this.cmddes);
            } else {
                def_check(this.cmdSet);
            }
        } catch (CliError th){
            this.excObj = null;
            error(ERR_INVDEF,th);
        }
    }

    /**
     * Check that all the required arguments be present. Repositions
     * the cursor fields to the beginning.
     *
     * @param      check true if the check has to be done
     */

    private void restartElems(boolean check){
        if ((FL_C & this.trc) != 0){
            Trc.out.println("restartElems " + check);
        }
        Element e;
        if (check){
            int seq = 1;
            Argument a;
            int amax = this.cmddes.args.length;
            for (int an = 0; an < amax; an++){
                a = this.cmddes.args[an];
                e = this.elems[seq++];
                if (((AR_ALT & a.attr) != 0) &&         // check alternative
                    ((AR_REQ & a.attr) != 0)){
                    int f = an;
                    seq--;
                    int nr = 0;
                    for (; an < amax; an++){
                        a = this.cmddes.args[an];
                        e = this.elems[seq++];
                        if ((AR_ALT & a.attr) == 0) break;
                        if (e.ini >= 0) nr++;
                    }
                    if (nr == 0){
                        this.argn = this.argc;          // for getCommand
                        error(ERR_MISQUAL,f,-1);
                    }
                } else if (((AR_REQ & a.attr) != 0) && 
                    (e.ini < 0)){
                    this.argn = this.argc;              // for getCommand
                    if ((AR_PAR & a.attr) != 0){
                        error(ERR_MISPAR,an,-1);        // missing parameter
                    } else {
                        error(ERR_MISQUAL,an,-1);       // missing qualifier
                    }
                }
                para: {
                    Argument ar = a;
                    if (e.ini < 0){
                        seq += ar.args.length;
                        break para;
                    }
                    int qmax = ar.args.length;
                    for (int ln = 0; ln < qmax; ln++){
                        a = ar.args[ln];
                        e = this.elems[seq++];
                        if (((AR_ALT & a.attr) != 0) &&  // check alternative
                            ((AR_REQ & a.attr) != 0)){
                            int f = ln;
                            seq--;
                            int nr = 0;
                            for (; ln < qmax; ln++){
                                a = ar.args[ln];
                                e = this.elems[seq++];
                                if ((AR_ALT & a.attr) == 0) break;
                                if (e.ini >= 0) nr++;
                            }
                            if (nr == 0){
                                error(ERR_MISQUAL,an,f);
                            }
                        } else if (((AR_REQ & a.attr) != 0) && 
                            (e.ini == -1)){
                            error(ERR_MISQUAL,an,ln);   // missing qualifier
                        }
                    }
                }
            }
        }
        for (int i = 0; i < this.elems.length; i++){
            e = this.elems[i];
            e.cursor = e.ini;
            e.argnc = e.argni;
        }
        this.curpar = -1;                   // no current parameter
        this.arg_an = -1;
        this.arg_ln = -1;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("restartElems end");
        }
    }

    /**
     * Search a verb with the name equal to the last token found, or
     * equal to an abbreviation of it.
     * The <code>ini</code> fiels indicates the start of the token.
     *
     * @param      cms command set
     * @return     reference to the command descriptor, null if not found
     */

    private Command search_verb(Command[] cms){
        Command  c, cmd;
        int      p;
        int      weak;

        cmd = null;
        weak = 0;
        if ((FL_S & this.trc) != 0){
            Trc.out.println("search_verb " +
                toAbbrev(this.argni,ini,this.argn,this.cursor,0) +
                " case: " + ((CASEINS & this.mode) != 0) +
                " abbr: " + ((ABBREV & this.mode) != 0) +
                " weak: " + weak);
        }

        boolean cas = (CASEINS & this.mode) != 0;
        int lo, hi, k, i, n;                 // binary search
        lo = 0;
        hi = cms.length - 1;
        do {                                 // search
            k = (hi + lo) / 2;               // middle index
            if (this.isStr){
                i = Str.compareSlices(this.string,this.end,
                    this.ini,this.cursor-this.ini,
                    cms[k].name,cms[k].name.length(),
                    0,cms[k].name.length(),
                    cas,false);
            } else {
                i = Str.compareSlices(this.buffer,this.end,
                    this.ini,this.cursor-this.ini,
                    cms[k].name,cms[k].name.length(),
                    0,cms[k].name.length(),
                    cas,false);
            }
            if (i <= 0) hi = k-1;            // it is above
            if (i >= 0) lo = k+1;            // it is below
        } while (lo <= hi);
        if (lo-1 > hi){                      // found
            n = k;
        } else if (i < 0){                   // successor found
            n = k;
        } else {                             // predecessor found
            n = k + 1;
        }
        if (lo-1 > hi){                      // found
            cmd = cms[n];
            weak = 0;
        } else if ((ABBREV & this.mode) != 0){  // abbreviations allowed
            for (; n < cms.length; n++){
                if (!regionMatches(cas,this.ini,  
                    cms[n].name,0,this.cursor-this.ini,false))
                    break;
                cmd = cms[n];
                weak++;
            }
        }
        if ((FL_S & this.trc) != 0){
            if (cmd == null){
                Trc.out.println("not found\n");
            } else {
                Trc.out.println("found: " + cmd.name + " weak: " +
                    weak);
            }
        }
        if (weak > 1){
            this.cursor = this.ini;
            error(ERR_AMBNAME);          // ambiguous name
        } else if (cmd == null){
            this.cursor = this.ini;
            error(ERR_UNKCMD);
        }
        return cmd;
    }

    /**
     * Parse the arguments.
     */

    void parse_args(){
        boolean   res;
        Qualifier q;
        Element   e = null;

        if ((FL_B & this.trc) != 0){
            trcpoint("parse_args start");
        }
        res = true;
        parse: while (skipws()){                    // parse arguments
            if ((FL_B & this.trc) != 0){
                trcpoint("parse_args get at");
            }
            q = null;
            int elenum = 0;
            if (((NODEFLT & this.mode) == 0) && getDel('@')){
                this.ele.clear();
                this.arg_an = QU_INDFILE;
                this.arg_ln = -1;
                q = (Qualifier)(this.dfldes[0]);
                if (!get_qvalue(q)){
                    error(ERR_MISVAL,ARG);          // missing value
                }
                this.ele.ini = this.ini;
                this.ele.argni = this.argni;
                this.ele.end = this.cursor;
                this.ele.argne = this.argn;
                checkAlter(q,-1,this.ele.ini);      // check alternatives
                elenum = toSeq();
                e = this.elems[elenum];
                e.assign(this.ele);
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("indirect");
                }
            } else {
                q = get_qual(-1,GENERAL);           // get a global qualifier,
                if (q != null){                     // .. if any
                    elenum = toSeq();
                    e = this.elems[elenum];
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("qual: " + q.name + " " +
                            toAbbrev(e.argni,e.ini,
                            e.argne,e.end,0));
                    }
                }
            }
            if (q != null){                         // qualifier found
                int qn = this.arg_an;
                if ((AR_LIST & q.attr) == 0){             // not list
                    int lmax = q.args.length;
                    if (lmax > 0){
                        int en = toSeq(qn,0);
                        for (int i = 0; i < lmax; i++){   // initialize ini
                            this.elems[en++].ini = -1;
                        }
                        Qualifier qua;
                        boolean pres = false;
                        do {                              // local qualifiers
                            qua = get_qual(qn,GENERAL);   // get qualifier
                            if (qua != null) pres = true;
                        } while (qua != null);
                        this.arg_an = -1;                 // no default quals here
                        checkElem(qn,q);                  // check elements
                        if (pres){
                            if ((FL_B & this.trc) != 0){
                                trcpoint("parse_args local");
                            }
                            e.end = this.cursor;          // update end
                            e.argne = this.argn;
                        }
                    }
                }
                if ((AR_IND & q.attr) != 0){        // indirect file
                    if (this.pass == 1){ 
                        this.nest++;
                        int savc = this.cursor;
                        this.cursor = this.ini;
                        qual_indfile(q,elenum,qn == QU_INDFILE);
                        this.cursor = savc;
                        this.nest--;
                    }
                } else if (this.arg_an <= QU_INDFILE){    // default argument
                    process_qual();
                    this.res = NULL_COMMAND;
                    break parse;
                }
                continue;
            }
            if (this.curpar == -1){
                this.curpar = 0;                    // locate the first parameter
            } else {
                this.curpar++;
            }
            seekpar: {
                Argument ar;
                int amax = this.cmddes.args.length;
                for (; this.curpar < amax; this.curpar++){
                    ar = this.cmddes.args[this.curpar];
                    if ((AR_PAR & ar.attr) != 0)    // parameter
                        break seekpar; 
                }
                if ((FL_B & this.trc) != 0){
                    trcpoint("parse_args unexpected");
                }
                error(ERR_UNEXP);                   // unexpected character
            }
            this.arg_an = this.curpar;
            this.arg_ln = -1;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("trying par: " +
                    this.cmddes.args[this.curpar].name);
            }
            res = get_parameter(this.curpar);       // get it
            if ((FL_B & this.trc) != 0){
                if (res){
                    e = this.elems[toSeq(this.curpar)];
                    Trc.out.println("par: " +
                        this.cmddes.args[this.curpar].name + " " +
                        toAbbrev(e.argni,e.ini,
                        e.argne,e.end,0));
                }
            }
            if (!res){                              // no parameter
                if ((FL_B & this.trc) != 0){
                    trcpoint("parse_args unexpected");
                }
                error(ERR_UNEXP);                   // unexpected character
            }
        } // parse
        if ((FL_B & this.trc) != 0){
            Trc.out.println("parse_arg returning " +
                res + " at: " + this.cursor);
        }
        return;
    }

    /** Temporary element. */
    private Element ele;

    /**
     * If a qualifier indicator is found, try to get a qualifier
     * name and value. If the qualifier is a special one, it treats it.
     *
     * @param      p -1 if search among global qualifiers only, otherwise
     *             index of the parameter
     * @param      pre general, prefix or suffix qualifier
     * @return     reference to the qualifier descriptor, null if not found
     */

    Qualifier get_qual(int p, byte pre){
        byte        nam;
        Qualifier   q;
        Element     e = null;
        Qualifier   res;
        int         startcur;
        int         startargn;

        if ((FL_C & this.trc) != 0){
            trcpoint("get_qual");
            Trc.out.println("mode: " +
                Integer.toOctalString(this.mode) +
                " p: " + p + " " + pre + " " +
                this.posixcur + " " + this.posixargn);
        }
        res = null;
        this.ele.clear();
        endqual: {
            if (!skipws()) break endqual;               // skip white space
            if ((this.argn > this.posixargn) ||         // check if after --
                (this.argn == this.posixargn) &&
                (this.cursor > this.posixcur))          // already encountered
                break endqual;
            if (((QUALSL|QUALNVP) & this.mode) == 0){
                int back = this.cursor;
                if (getDel('-')){
                    if (getDel('-')){                   // --
                        if (isWhite()){                 // followed by whitespace
                            this.posixcur = this.cursor;
                            this.posixargn = this.argn;
                            if ((FL_C & this.trc) != 0){
                                Trc.out.println("posix --");
                            }
                            break endqual;
                        }
                    }
                }
                this.cursor = back;
            }

            startcur = this.cursor;
            startargn = this.argn;
            nam = NO_NAME;                              // look for a qual first
            getname:
            if ((QUALSL & this.mode) != 0){
                if (this.cursor >= this.end)
                    break getname;
                if (getDel('/')){                       // /name...
                    if (!skipws() || !get_argname()){
                        error(ERR_MISNAME);
                    }
                    if (this.cursor - this.ini > 1){
                        nam = LONG_NAME;                // long name expected
                    } else {
                        nam = SHORT_NAME;               // short name expected
                    }
                }
            } else if ((QUALNVP & this.mode) != 0){
                if (!skipws() || !get_argname()){
                    error(ERR_MISNAME);
                }
                nam = LONG_NAME;                        // long name expected
            } else {
                if (this.cursor >= this.end)
                    break getname;
                if (getDel('-')){                       // -: test what follows
                    if (this.cursor >= this.end){
                        this.cursor--;
                        break endqual;
                    }
                    if (getDel('-')){                   // --name ...
                        nam = LONG_NAME;                // long name expected
                        if (!get_argname()){
                            error(ERR_MISNAME);
                            break endqual;
                        }

                    } else {                            // -c ...
                        nam = SHORT_NAME;               // short name expected
                        if (!get_argname()){
                            this.cursor--;
                            break endqual;
                        }
                    }
                } else if (getDel('+')){
                    nam = PLUS_NAME;                    // + name expected
                    if (!get_argname()){
                        error(ERR_MISNAME);
                    }
                }
            }
            int savargn = this.argn;
            int savcur = this.cursor;
            boolean suff = false;
            if (pre == PREFIX){                         // prefix qualifier
                skipws();
                if (!getDel(':')){
                    reposition(startargn,startcur);     // not a prefix one
                    break endqual;
                }
                reposition(savargn,savcur);
            } else if (pre == SUFFIX){                  // suffix qualifier
                skipws();
                if (getDel(':')){
                    suff = true;
                }
                reposition(savargn,savcur);
            }
            if ((FL_C & this.trc) != 0){
                trcpoint("try qualname");
                Trc.out.println("nam: " + nam);
            }
            q = null;
            try {
                qualvalue: switch(nam){
                case LONG_NAME:                         // long name case
                    q = search_qual(p);                 // search long name
                    this.ele.neg = (this.status & NEGATION) != 0;
                    break qualvalue;
                case SHORT_NAME:                        // short name case
                    if ((LNAME & this.mode) != 0){      // try long name
                        if (this.cursor - this.ini > 1){
                            if ((FL_C & this.trc) != 0)
                                Trc.out.println("try long");
                            q = search_qual(p);
                            this.ele.neg = (this.status & NEGATION) != 0;
                            if ((this.arg_an != -1) ||  // global or
                                (this.arg_ln != -1))    // .. local
                                break qualvalue;        // .. found
                        }
                    }
                case PLUS_NAME:                         // - and + short name case
                    if ((NONSEP & this.mode) != 0){     // try short even when
                        if ((FL_C & this.trc) != 0)     // .. more than one char
                            Trc.out.println("try nonsep");
                        q = search_short_qual(p,nam == PLUS_NAME);
                        if ((q != null) && (q.type != void.class)){
                            this.ele.neg = false;
                            this.cursor = this.ini+1;   // point to start of val
                            break qualvalue;
                        }
                    }
                    if (((QMASK & this.mode) != 0) &&   // try mask of short
                        (this.cursor - this.ini > 1)){  // .. names
                        if (suff){                      // -abcd: not wanted
                            q = search_short_qual(p,
                                nam == PLUS_NAME);      // determine if
                            break qualvalue;            // .. local mask
                        }
                        if ((FL_C & this.trc) != 0)
                            Trc.out.println("try mask");
                        q = get_qmask(p,nam == PLUS_NAME);  // get qualifier mask
                        if ((q == null) && (p != -1)){
                            break qualvalue;
                        }
                        res = q;                        // return the last
                        break endqual;
                    }
                    if (this.cursor - this.ini != 1){
                        this.cursor = this.ini;         // start of error token
                        if (p != -1) break qualvalue;
                        error(ERR_UNKARG);              // unknown argument
                    } else {
                        if ((FL_C & this.trc) != 0)
                            Trc.out.println("try short");
                        this.ele.neg = false;
                        q = search_short_qual(p,
                            nam == PLUS_NAME);          // search short name
                        break qualvalue;
                    }
                case NO_NAME:                           // search a parameter
                    this.cursor = startcur;
                    this.argn = startargn;
                    break endqual;
                } // qualvalue
            } catch (Error exc) {
                this.cursor = this.ini;             // point to start of
                throw exc;                          // .. error token
            }
            if ((FL_C & this.trc) != 0){
                Trc.out.println("q: " + q + " " +
                    toSeq());
            }
            ckqual: if (q == null){
                if (p != -1){
                    reposition(startargn,startcur); // start of qualifier
//                    return null;
                    res = null;
                    break endqual;
                }
                if ((LENIENT & this.mode) != 0){
                    q = UNKNOWN_QUAL;
                    break ckqual;
                }
                this.cursor = this.ini;             // start of error token
                error(ERR_UNKARG);                  // unknown argument
            }
            if ((this.arg_an != QU_INDFILE) &&      // not a qualifier that
                (q != UNKNOWN_QUAL) &&              // .. allows repetition
                (this.pass == 1)){
                e = this.elems[toSeq()];
                if (e.ini != -1){                   // already specified
                    this.cursor = this.ini;         // start of error token
                    error(ERR_REPQUAL,ARG);
                }
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("qualifier found: " +
                    toAbbrev(this.argni,this.ini,
                        this.argn,this.cursor,0) + " " + q.type);
            }
            this.ele.ini = this.ini;
            this.ele.argni = this.argni;
            this.ele.end = -1;
            noarg: if (q.type != void.class){       // it allows a value
                if (pre == PREFIX){
                    q = null;
                    reposition(startargn,startcur); // not a prefix one
                    break endqual;
                }
                if (this.ele.neg) {
                    this.ele.ini = this.cursor;     // make value() return ABSENT
                    this.ele.argni = this.argn;                        
                    break noarg;
                }
                endarg: {
                    int valcur = this.cursor;
                    int valargn = this.argn;
                    if ((FL_C & this.trc) != 0){
                        trcpoint("get_qual search value");
                    }
                    noval: {
                        if (!skipws()) break noval;           // skip whitespace
                        if ((((QVALEQ & this.mode) != 0) &&
                            getDel('=')) ||
                            (((QVALCO & this.mode) != 0) &&
                            getDel(':'))){
                            valcur = this.cursor;
                            valargn = this.argn;
                            if (!skipws()) break noval;       // skip whitespace
                        } else if ((QSREQ & this.mode) == 0){ // no sep required
                            if ((NONSEP & this.mode) == 0){   // sep must exist
                                if ((this.argn == valargn) && // .. it does not
                                    (this.cursor == savcur)){
                                    error(ERR_UNKARG);
                                }
                            }
                        } else {
                            break noval;
                        }
                        if (get_qvalue(q)) break endarg;
                    } // noval
                    if ((AR_VALREQ & q.attr) != 0){   // value not specified
                        error(ERR_MISVAL,ARG);        // missing value
                    }
                    this.ele.ini = valcur;            // no value
                    this.ele.argni = valargn;                        
                    this.ele.end = valcur;
                    this.ele.argne = valargn;
                    break noarg;
                } // endarg
                this.ele.ini = this.ini;              // real start, after (
                this.ele.argni = this.argni;
            } else {
                if (suff){
                    reposition(startargn,startcur);   // suffix not wanted
                    this.ini = -1;                    // qualifier present,
                    res = q;                          // .. but non wanted
                    break endqual;
                }
                if (pre == PREFIX) break noarg;
                sep:
                if (this.cursor < this.end){          // check that the name
                    if ((QUALSL & this.mode) != 0){   // .. is delimited
                        if ((getDel('/') || getDel(',') ||
                            getDel('+'))){
                            this.cursor--;
                            break noarg;
                        }
                    }
                    int cur = this.cursor;
                    if (!skipws()) break sep;         // -qxxx insead of -q xxx
                    if (cur == this.cursor){
                        error(ERR_UNKARG);
                    }
                }
            } // noarg
            if (this.ele.end == -1){           // not yet set
                this.ele.end = this.cursor;
                this.ele.argne = this.argn;
            }

            if (q != UNKNOWN_QUAL){
                checkAlter(q,p,this.ele.ini);  // check alternatives
                e = this.elems[toSeq()];
                e.assign(this.ele);
            }
            if ((FL_B & this.trc) != 0){
                if (this.ele.ini != -1){
                    Trc.out.println("qualifier value found: " +
                        toAbbrev(this.ele.argni,this.ele.ini,
                        this.ele.argne,this.ele.end,0));
                }
            }
            if (pre == PREFIX){
                skipws();
                this.cursor++;                 // skip :
                skipws();
                if ((FL_C & this.trc) != 0){
                    trcpoint("pref");
                }
            }
            res = q;
        } // endqual
        if ((FL_C & this.trc) != 0){
            Trc.out.println("get_qual end: " +
                ((res != null) ? res.name : "not found"));
        }
        return res;
    }

    /** A long name has been specified. */
    private static final byte LONG_NAME  = 0;

    /** A short name has been specified. */
    private static final byte SHORT_NAME = 1;

    /** A short + name has been specified. */
    private static final byte PLUS_NAME  = 2;

    /** No name has been specified. */
    private static final byte NO_NAME    = 3;

    /** A normal search for a qualifier is requested. */
    static final byte GENERAL    = 0;

    /** The search for a prefix qualifier is requested. */
    static final byte PREFIX     = 1;

    /** The search for a suffix is requested. */
    static final byte SUFFIX     = 2;

    /** The unknown qualifier. */
    private static final Qualifier UNKNOWN_QUAL =
         new Qualifier(' ',"","",0,String.class,"");

    /**
     * Check that there are no other qualifiers specified which belong
     * to the same alternative (if any) of the one passed as argument.
     *
     * @param      q qualifier
     * @param      p number of argument, if local qualifier
     * @param      s start index of the qualifier in the command
     */

    private void checkAlter(Qualifier q, int p, int s){
        if ((AR_ALT & q.attr) != 0){
            int f = this.arg_an;
            Argument[] arg = this.cmddes.args;
            if (p >= 0){
                arg = this.cmddes.args[p].args;
                f = this.arg_ln;
            } else if (p != -1){
                arg = this.dfldes[idxDefault(p)].args;
                f = this.arg_ln;
            }
            int i = 0;
            for (i = f-1; i >= 0; i--){                 // find start
                if ((AR_ALT & arg[i].attr) == 0) break;
            }
            if ((FL_C & this.trc) != 0){
                Trc.out.println("checkAlter: " + i);
            }
            for (i++; i < arg.length; i++){                    
                if ((AR_ALT & arg[i].attr) == 0) break;
                int an = p;
                int ln = i;
                if (p == -1){
                    an = i;
                    ln = -1;
                }
                if (this.elems[toSeq(an,ln)].ini != -1){
                    this.cursor = s;
                    error(ERR_ILLQUAL,ARG);
                }
            }
        }
    }

    /**
     * Parse a qualifier which is a combination of short names.
     * In the object, <code>ini</code> points to the start of the mask,
     * <code>cur</code> to the end.
     *
     * @param      p -1 if search among global qualifiers only, otherwise
     *             index of the argument
     * @param      pl true if + shortnames, false if - shortnames
     * @return     reference to the descriptor of the last qualifier in the
     *             mask, null if none found.
     */

    private Qualifier get_qmask(int p, boolean pl){
        Qualifier q = null;
        Element   e;
        boolean   first = true;
        int       savcur = this.cursor;

        if ((FL_C & this.trc) != 0){
            Trc.out.println("qmask " + this.ini);
        }
        this.cursor = this.ini;
        while (this.ini < savcur){
            q = search_short_qual(p,pl);         // search short name
            if (q == null){
                if ((p != -1) && first){         // after a param, try then
                    return null;                 // .. with the global ones
                }
                error(ERR_UNKARG);               // unknown argument
            }
            if (q.type != void.class){
                error(ERR_ILLQUAL,ARG);          // qualifier with value
            }
            first = false;
            e = this.elems[toSeq()];
            if ((e.ini != -1) && (this.pass == 1)){    // already specified
                error(ERR_REPQUAL,ARG);
            }
            this.cursor++;
            checkAlter(q,p,this.cursor);         // check altenatives
            e.ini = this.ini;                    // save its data
            e.argni = this.argni;
            e.neg = false;
            e.end = this.ini+1;
            e.argne = this.argni;
            this.ini++;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("qualifier found: " + q.name);
            }
        }
        return q;
    }

    /**
     * Deliver the portion of command in which an element lays.
     * It is used for testing.
     *
     * @param      an parameter index
     * @param      ln local qualifier index
     * @return     string 
     */

    String elementToString(int an, int ln){
        Element e = this.elems[toSeq(an,ln)];
        if (e.ini == -1) return null;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("element " + toArgument(an,ln).name +
                " " + e.argni + " " + e.ini +
                " " + e.argne + " " + e.end);
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("element: " + toAbbrev(e.argni,e.ini,
            e.argne,e.end,0));
        }
        return toAbbrev(e.argni,e.ini,e.argne,e.end,0);
    }

    /**
     * Advance the cursor to the first non-white space character in
     * the current buffer. If it reaches the end it scans the next
     * command segment, if any.
     * <code>cursor</code> is left to indicate the first non-white space
     * character.
     * Whitespace are SP, HT, and the Unicode Zs characters.
     *
     * @return     false if there is no next character (end of command)
     */

    private boolean skipws(){
        boolean res;
        char    ch;

        res = true;
        doit: {
            if (this.argn >= 0){                     // arg processing
                if (this.cursor < this.end){
                    break doit;
                }
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("skip: " +
                        this.argc + " " + this.argn);
                }
                if (this.argn >= this.argc-1){       // already at end
                    res = false;
                    break doit;
                }
                this.argn++;                         // step to next argument
                if (this.argv != null){
                    if (this.argv[this.argn].length == 0){
                        if ((FL_C & this.trc) != 0)
                            Trc.out.println("skip: empty");
                        this.buffer = emptycharr;
                    } else {
                        this.buffer = this.argv[this.argn];
                    }
                    this.end = this.buffer.length;
                } else {
                    if (this.args[this.argn].length() == 0){
                        if ((FL_C & this.trc) != 0)
                            Trc.out.println("skip: empty");
                        this.string = emptystring;
                    } else {
                        this.string = this.args[this.argn];
                    }
                    this.end = this.string.length();
                }
                this.cursor = 0;
                break doit;
            }

            while (this.cursor < this.end){
                if (this.isStr){
                    ch = this.string.charAt(this.cursor);
                } else {
                    ch = this.buffer[this.cursor];
                }
                white:{                              // test whitespace
                    if (ch == 0x0009) break white;   // HT
                    if (ch == 0x0020) break white;   // SP
                    if (ch <  0x00A0){               // shortcut for ASCII
                        if (('\n' <= ch) && (ch <= '\r')){
                            if ((WHITESPACE & this.mode) != 0)
                                break white;
                            res = false;
                        }
                        break doit;
                    }
                    if (ch == 0x00A0) break white;   // no-break space
                    if (ch <  0x2000) break doit;
                    if (ch <= 0x200B) break white;   // en, em, etc.
                    if (ch == 0x3000) break white;   // ideographic space
                    break doit;
                }
                this.cursor++;                       // advance cursor
            }
            res = false;
        } // doit
        if ((FL_C & this.trc) != 0){
            trcpoint("skip");
            Trc.out.println("skip: " + res);
        }
        return res;
    }

    /** An empty char[], null terminated. */
    private static final char[] emptycharr = new char[] {'\0'};

    /** An empty String, null terminated. */
    private static final String emptystring = "\0";

    /**
     * Match an empty argv element and advance the cursor if it
     * finds it.
     *
     * @return     true if found
     */

    private boolean getEmptyArgv(){
        boolean res;

        res = false;
        doit: {
            if ((FL_C & this.trc) != 0)
                trcpoint("getEmptyArg");
            if (this.argn >= 0){                     // arg processing
                if (this.argn >= this.argc){
                    break doit;
                }
                int len = 0;
                if (this.argv != null){
                    len = this.argv[this.argn].length;
                } else {
                    len = this.args[this.argn].length();
                }
                if (len == 0){
                    if ((FL_C & this.trc) != 0)
                        Trc.out.println("getEmptyArgv found");
                    this.cursor++;
                    res = true;
                    break doit;
                }
            }
        }
        return res;
    }

    /**
     * Get a qualifier name from the command at the current position
     * and advances the cursor. The <code>ini</code> index indicates the first
     * character of the qualifier, and the <code>cursor</code> the last+1
     * character of the qualifier.
     *
     * @return     true if found
     */

    private boolean get_argname(char c){
        return Character.isJavaIdentifierStart(c);
    }

    /**
     * Get a qualifier name.
     *
     * @see        #get_argname(char)
     */

    private boolean get_argname(){
        char c;

        this.ini = this.cursor;                  // start of name
        this.argni = this.argn;
        done: if (this.cursor < this.end){
            if (this.isStr){
                c = this.string.charAt(this.cursor);
                if (!Character.isJavaIdentifierStart(c)) break done;
                for (; this.cursor < this.end; this.cursor++){
                    c = this.string.charAt(this.cursor);
                    if (!(Character.isJavaIdentifierPart(c)
                       || (c == '.') || (c == '-'))) break;
                }
            } else {
                c = this.buffer[this.cursor];
                if (!Character.isJavaIdentifierStart(c)) break done;
                for (; this.cursor < this.end; this.cursor++){
                    c = this.buffer[this.cursor];
                    if (!(Character.isJavaIdentifierPart(c)
                       || (c == '.') || (c == '-'))) break;
                }
            }
        }
        if ((FL_C & this.trc) != 0)
            Trc.out.println("argname: |" + 
                toAbbrev(this.argn,ini,this.argn,this.cursor,0)
                + "|");
        return this.cursor > this.ini;
    }

    /**
     * Test if at the current position a whitespace characher
     * or the end of the line is present.
     *
     * @return     true if found
     */

    private boolean isWhite(){
        if (this.cursor >= this.end) return true;
        char ch;
        if (this.isStr){
            ch = this.string.charAt(this.cursor);
        } else {
            ch = this.buffer[this.cursor];
        }
        doit: {
            white:{                              // test whitespace
                if (ch == 0x0009) break white;   // HT
                if (ch == 0x0020) break white;   // SP
                if (ch <  0x00A0){               // shortcut for ASCII
                    if (('\n' <= ch) &&          // line end
                        (ch <= '\r')){
                        break white;
                    }
                    break doit;
                }
                if (ch == 0x00A0) break white;   // no-break space
                if (ch <  0x2000) break doit;
                if (ch <= 0x200B) break white;   // en, em, etc.
                if (ch == 0x3000) break white;   // ideographic space
                break doit;
            }
            return true;
        }
        return false;
    }

    /**
     * Search a qualifier with the name equal to the last token found.
     * It searches among the global qualifiers, and among the ones
     * local to the current parameter, if specified.
     * The token is matched against a qualifier name, which has two
     * actual names when it is negatable: one as such and another prefixed
     * by the negation uppercase prefix (e.g. "NO") if the first letter of
     * the name is uppercase, otherwise by its lowercase form (e.g. "no").
     * In the object <code>ini</code> indicates the name.
     * Upon return, <code>neg</code> is true if the qualifier is found negated.
     *
     * @param      p index of the parameter, if a local qualifier is to be
     *             accepted
     * @return     reference to the qualifier's descriptor, null if not found
     */

    Qualifier search_qual(int p){
        int        qg, ql, qd;
        Qualifier  q = null;
        Argument   ar = null;
        boolean    neg;
        boolean    negg = false;
        boolean    negl = false;
        boolean    negd = false;

        if ((FL_S & this.trc) != 0){
            Trc.out.println("search_qual " + p);
        }
        neg = false;
        this.status &= ~(NEGATION | AMBIG | WEAK);    // clear status
        qg = -1;
        ql = -1;
        qd = -1;
        qg = src_qual(this.cmddes.args,0);     // search global qualifier
        negg = (this.status & NEGATION) != 0;
        boolean defexa = false;
        if ((qg < 0) ||                        // not found
            ((this.status & AMBIG) != 0)){     // .. or weak match
            qd = src_qual(this.dfldes,
                this.status >> DFLT_OFF);      // search default qualifier
            negd = (this.status & NEGATION) != 0;
            if ((qd >= 0) &&
                ((this.status & AMBIG) == 0)){ // exact match found
                qg = -1;
                defexa = true;
            }
        }
        if (p != -1){
            if (p >= 0) ar = this.cmddes.args[p];
            else ar = this.dfldes[idxDefault(p)];
            ql = src_qual(ar.args,0);          // search local qualifier
            negl = (this.status & NEGATION) != 0;
            if ((ql >= 0) && ((this.status & AMBIG) != 0) &&
                defexa){
                ql = -1;                       // local weak, default exact
            }
        }
        this.arg_an = p;
        this.arg_ln = -1;
        if ((this.status & AMBIG) == AMBIG){   // i.e. not WEAK
            this.arg_an = -1;
            this.cursor = this.ini;
            error(ERR_AMBNAME);                // ambiguous name
        } else {
            if (ql >= 0){                      // a local one found
                q = (Qualifier)(ar.args[ql]);
                neg = negl;
                this.arg_ln = ql;
            } else if (qg >= 0){               // a global one found
                q = (Qualifier)(this.cmddes.args[qg]);
                neg = negg;
                this.arg_an = qg;
            } else {
                if (qd < 0){
                    negd = false;
                } else {
                    q = (Qualifier)this.dfldes[qd];
                    this.arg_an = idxDefault(qd);
                }
                neg = negd;
            }
        }
        this.status |= (neg) ? NEGATION : 0;
        this.status &= ~WEAK;
        if (q == null){
            this.arg_an = -1;
        } else if (p != -1){                   // local required, global found
            if (ql < 0) q = null;
        }
        if ((FL_S & this.trc) != 0){
            Trc.out.println("search_qual " + this.arg_an +
                " " + toSeq() + " " + defexa);
        }
        return q;
    }

    /** Weak match found status. */
    private static int WEAK = 1<<16;

    /** Ambiguous match found status. */
    private static int AMBIG = 1<<17 | WEAK;

    /** Negation match found status. */
    static int NEGATION = 1<<18;

    /**
     * Search a qualifier (long) name in a table.
     *
     * @param      aa table
     * @param      msk mask of the qualifiers which are disabled
     * @return     number of the qualifier, -1 if not found
     */

    private int src_qual(Argument[] aa, int msk){
        int      p;
        Argument ar, qu;
        int      argnum = -1;

        if ((FL_S & this.trc) != 0){
            Trc.out.println("search " +
                toAbbrev(this.argni,this.ini,this.argn,this.cursor,0) +
                " case: " + ((CASEINS & this.mode) != 0) +
                " abbr: " + ((ABBREV & this.mode) != 0) + " " +
                (((this.status & WEAK) != 0) ? "weak" : "") + " " +
                (((this.status & AMBIG) != 0) ? "ambig" : "") + " " +
                Integer.toHexString(msk));
        }
        boolean neg = false;
        qu = null;

        int anum = aa.length;
        found: for (int an = 0; an < anum; an++){  // visit arguments
            int m = msk;
            msk >>= 1;
            if ((m & 1) != 0) continue;
            ar = aa[an];
            if ((AR_PAR & ar.attr) != 0) continue; // not a qualifier
            if ((FL_S & this.trc) != 0)
                Trc.out.println("try " + ar.name);
            p = this.ini;                          // search first the name as such

            if (regionMatches(((CASEINS & this.mode) != 0),
                this.ini,ar.name,0,this.cursor-p,false)){
                if (this.cursor-p == ar.name.length()){
                    qu = ar;
                    argnum = an;
                    this.status &= ~AMBIG;         // clear weak status
                    break found;                   // found exact match
                }
                if ((ABBREV & this.mode) != 0){    // abbreviations allowed
                    qu = ar;
                    argnum = an;
                    if ((this.status & AMBIG) == 0){
                        this.status |= WEAK;
                    } else {
                        this.status |= AMBIG;
                    }
                    if ((FL_S & this.trc) != 0){
                        Trc.out.println("weak match: " + " " +
                        (((this.status & WEAK) != 0) ? "weak" : "") + " " +
                        (((this.status & AMBIG) == AMBIG) ? "ambig" : ""));
                    }
                }
            }

            if ((FL_S & this.trc) != 0)
                Trc.out.println("try /no");
            p = this.ini;                          // search now the negation
            if (this.cursor - p <=
                this.valStr[NO].length())          // no characters after "no"
                continue;
            if ((AR_NEG & ar.attr) == 0)           // not negatable
                continue;
            if ((CASEINS & this.mode) != 0){       // case insensitive
                if (!regionMatches(true,
                    p,this.valStr[NO],0,
                    this.valStr[NO].length(),false))
                    continue;
            } else {                               // case sensitive
                if (Character.isUpperCase
                    (ar.name.charAt(1))){          // uppercase name
                    if (!regionMatches(false,
                        p,this.valStr[NO],0,
                        this.valStr[NO].length(),true))
                        continue;                  // it does not start with "NO"
                } else {
                    if (!regionMatches(false,
                        p,this.valStr[NO],0,
                        this.valStr[NO].length(),false))
                        continue;
                }
            }
            p += this.valStr[NO].length();
            neg = true;

            if ((FL_S & this.trc) != 0)
                Trc.out.println("p: " + p + " " +
                    this.cursor + " " + ar.name);
            if (regionMatches(((CASEINS & this.mode) != 0),
                p,ar.name,0,this.cursor-p,false)){
                if (this.cursor-p == ar.name.length()){
                    qu = ar;
                    argnum = an;
                    this.status &= ~AMBIG;         // clear weak status
                    break found;                   // found exact match
                }
                if ((ABBREV & this.mode) != 0){    // abbreviations allowed
                    qu = ar;
                    argnum = an;
                    if ((this.status & AMBIG) == 0){
                        this.status |= WEAK;
                    } else {
                        this.status |= AMBIG;
                    }
                    if ((FL_S & this.trc) != 0){
                        Trc.out.println("weak match: " + " " +
                        (((this.status & WEAK) != 0) ? "weak" : "") + " " +
                        (((this.status & AMBIG) == AMBIG) ? "ambig" : ""));
                    }
                }
            }
        } // found
        if ((FL_S & this.trc) != 0){
            if (qu == null){
                Trc.out.println("not found");
            } else {
                Trc.out.println("found: " + qu.name +
                    " neg: " + neg + " argnum: " + argnum);
            }
        }
        this.status &= ~NEGATION;
        if (neg) this.status |= NEGATION;
        return argnum;
    }

    /**
     * Compare a portion of the current command (segment) with a
     * portion of another string.
     *
     * @param      ignoreCase true if case insensitive
     * @param      offset start index in command
     * @param      other second string
     * @param      ooffset start index in it
     * @param      len length of the two strings
     * @param      upp true if the second string is transformed in
     *             its uppercase version before comparison
     * @return     true if equal
     */

    private boolean regionMatches(boolean ignoreCase,
        int offset, String other, int ooffset, int len, boolean upp){
        if (this.isStr){
            return Str.compareSlices(this.string,this.end,offset,len,
                other,other.length(),ooffset,len,ignoreCase,upp) == 0;
        } else {
            return Str.compareSlices(this.buffer,this.end,offset,len,
                other,other.length(),ooffset,len,ignoreCase,upp) == 0;
        }
    }

    /**
     * Search qualifiers taking short names. The negated form in this case
     * is not allowed. It searches among the global qualifiers, or among the
     * ones local to the current parameter, if specified.
     * In the object <code>ini</code> indicates the name.
     * Upon return, <code>neg</code> is true if the qualifier is found negated.
     *
     * @param      p index of the parameter, if a local qualifier is to be
     *             accepted
     * @param      pl true if + shortnames, false if - shortnames
     * @return     reference to the qualifier's descriptor, null if not found
     */

    Qualifier search_short_qual(int p, boolean pl){
        int       qn;
        Qualifier q = null;

        this.arg_an = p;
        this.arg_ln = -1;
        if (p == -1){                              // global qualifier
            qn = src_squal(this.cmddes.args,pl,0); // search global qualifier
            if (qn >= 0){
                q = (Qualifier)(this.cmddes.args[qn]);
                this.arg_an = qn;
            }
            if (q == null){
                qn = src_squal(this.dfldes,pl,
                    this.status >> DFLT_OFF);      // search default qual.
                if (qn >= 0){
                    q = (Qualifier)this.dfldes[qn];
                    this.arg_an = idxDefault(qn);
                }
            }
        } else {                                   // qualifier after an arg.
            Argument ar;
            if (p >= 0) ar = this.cmddes.args[p];
            else ar = this.dfldes[idxDefault(p)];
            qn = src_squal(ar.args,pl,0);          // search local qualifier
            if (qn >= 0){
                q = (Qualifier)(ar.args[qn]);
                this.arg_ln = qn;
            }
        }
        if (q == null){
            this.arg_an = -1;
        }
        return q;
    }

    /**
     * Search a qualifier short name in a table.
     *
     * @param      aa table
     * @param      pl true if the short name is preceded by +
     * @param      msk mask of the qualifiers which are disabled
     * @return     number of the qualifier, -1 if not found
     */

    private int src_squal(Argument[] aa, boolean pl, int msk){
        int       p;
        Argument  ar;
        Qualifier q;
        char      sname;
        int       argnum = -1;

        if ((FL_S & this.trc) != 0){
            Trc.out.println("src_squal " +
                toAbbrev(this.argni,this.ini,this.argn,this.cursor,0) +
                " case: " + ((CASEINS & this.mode) != 0) + " " +
                Integer.toHexString(msk));
        }
        q = null;
        int anum = aa.length;
        found: for (int an = 0; an < anum; an++){  // visit arguments
            int m = msk;
            msk >>= 1;
            if ((m & 1) != 0) continue;
            ar = aa[an];
            if ((AR_PAR & ar.attr) != 0) continue; // not a qualifier
            if (((AR_PLUS & ar.attr) != 0) != pl)  // not the right qualifier
                continue;
            if ((FL_S & this.trc) != 0)
                Trc.out.println("try " + ar.name);
            p = this.ini;                          // search the name
            sname = ((Qualifier)ar).sname;
            if ((CASEINS & this.mode) != 0){       // case insensitive
                char c;
                if (this.isStr){
                    c = this.string.charAt(p);
                } else {
                    c = this.buffer[p];
                }
                if (Str.compareIgnoreCase(c,sname) != 0) continue;
            } else {
                if (this.isStr){
                    if (this.string.charAt(p) != sname) continue;
                } else {
                    if (this.buffer[p] != sname) continue;
                }
            }
            q = (Qualifier)ar;
            argnum = an;
            break found;                           // found
        } // found
        if ((FL_S & this.trc) != 0){
            if (q == null){
                Trc.out.println("not found");
            } else {
                Trc.out.println("found: " + q.name);
            }
        }
        return argnum;
    }

    /**
     * Obtain the value of a qualifier. It records the indexes of the start
     * and end of the value. If it is a list, the start is the first non-white
     * space after the parens.
     * A value (or value element in a list) is any (possibly empty) sequence
     * of characters which does not include the ones defined in the syntax.
     *
     * @param      q reference to the qualifier's descriptor
     * @return     true if found
     */

    boolean get_qvalue(Qualifier q){
        boolean  res;
        boolean  pres;

        if ((FL_C & this.trc) != 0){
            Trc.out.println("get_qvalue: " + q.name);
        }
        res = false;
        this.ini = this.cursor;                  // start of value
        this.argni = this.argn;
        boolean unilist = ((AR_LIST & q.attr) != 0)
            && ((DCLLSEP & this.mode) == 0);     // unix list
        boolean list = false;
        if ((DCLLSEP & this.mode) != 0){         // DCL list
            if (getDel('(')){
                list = true;
            }
        } else {                                 // Unix list
            list = unilist;
        }
        if (list){                               // list of values
            skipws();                            // skip white space
            this.ini = this.cursor;              // real start of value
            this.argni = this.argn;
            endvlist: do {
                pres = get_qvelem(list,this.ele,q,q.type); // get value list element
                if (!pres){
                    if (((AR_VALREQ & q.attr) != 0) ||
                        ((AR_EMPTY & q.attr) == 0)){
                        error(ERR_MISVAL,ARG);   // missing value
                    }
                }
                res |= pres;
                int savargn = this.argn;
                int savcur = this.cursor;
                skipws();                        // skip white space
                if ((DCLLSEP & this.mode) != 0){ // DCL list
                    if (getDel(')')){            // closure of list
                        this.ele.end = savcur;
                        this.ele.argne = savargn;
                        break endvlist;
                    } else if (getDel(',')){     // allowed only if list
                        if ((AR_LIST & q.attr) == 0){
                            this.cursor--;
                            error(ERR_NOLIST,ARG);
                        }
                    } else {
                        error(ERR_NOCLO,ARG);
                    }
                } else {                         // Unix list
                    if (!getDel(':')){
                        reposition(savargn,savcur);  // go back to end
                        break endvlist;
                    } else {
                        savargn = this.argn;
                        savcur = this.cursor;
                        if (!skipws()){          // : at end
                            res = true;
                            reposition(savargn,savcur);
                            break endvlist;
                        }
                    }
                }
                res = true;
                skipws();                        // skip white space
            } while (true);
        } else {                                 // single value
            int savargn = this.argn;
            int savcur = this.cursor;
            skipws();                            // skip white space
            pres = get_qvelem(list,this.ele,q,q.type);
            if (!pres){
                if ((AR_VALREQ & q.attr) != 0){
                    error(ERR_MISVAL,ARG);       // missing value
                }
                this.ele.end = savcur;
                this.ele.argne = savargn;
            }
            res |= pres;
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("qvalue: " + res);
        }
        return res;
    }

    /**
     * Parse the value of a parameter or qualifier. Strings delimited by " are
     * interpreted as such only when the " is the first characters, and when the
     * command is in an indirect command file.
     *
     * @param      true if the value is part of a qualifier list of values
     *             separated by :
     * @param      ele Element in which the value is decoded
     * @param      ar argument
     * @param      type type of the argument
     * @return     true if found
     */

    private boolean get_qvelem(boolean list, Element ele, Argument ar,
        Object type){
        int     start;
        int     p, pe;
        char[]  str = null;
        boolean empty = false;

        if ((FL_C & this.trc) != 0){
            trcpoint("qvelem");
            Trc.out.println("argn: " + this.argn + " list: " + list);
        }
        start = this.cursor;                 // remember start of value
        p = 0;                               // index into return string
        if (this.str == null){
            pe = p;                          // .. pe = index to end
        } else {
            str = this.str;
            pe = str.length;
            if ((FL_V & this.trc) != 0){
                Trc.out.println("qvelem: size: " + pe);
            }
        }
        if (getEmptyArgv()){                 // empty "" in argv
            this.strLen = 0;
            if ((FL_V & this.trc) != 0){
                Trc.out.println("qvelem: empty string");
            }
            empty = true;
        }
        qualname:
        if (((QUALSL|QUALNVP) & this.mode) == 0){
            if ((this.argn > this.posixargn) ||
                (this.argn == this.posixargn) &&
                (this.cursor > this.posixcur))
                break qualname;
            if (this.cursor < this.end){
                char c;
                if (this.isStr){
                    c = this.string.charAt(this.cursor);
                } else {
                    c = this.buffer[this.cursor];
                }
                if ((c == '-') || (c == '+')){
                    if (this.cursor+1 < this.end){
                        char ch;
                        if (this.isStr){
                            ch = this.string.charAt(this.cursor+1);
                        } else {
                            ch = this.buffer[this.cursor+1];
                        }
                        if ((ch == '\u221E') ||        // infinity
                            (Character.isDigit(ch))){
                            break qualname;
                        }
                    }
                }
                if (getDel('-')){
                    if (isWhite()){          // - alone
                        this.cursor--;
                    } else {
                        this.cursor--;
                        return false;
                    }
                } else if (c == '+'){
                    return false;
                }
            }
        }
        if (((NODEFLT & this.mode) == 0) && getDel('@')){
            this.cursor--;                            // it may not start with @
            return false;
        }
        if (!list && ((DCLLSEP & this.mode) == 0)){   // unix non-list
            if ((QUALSL & this.mode) == 0){
                if (this.argn >= 0){
                    int len = this.end - this.cursor; // shortcut
                    if ((this.str == null) || (len > this.str.length)){
                        this.str = new char[len];
                    }
                    if (this.isStr){
                        this.string.getChars(this.cursor,this.end,
                            this.str,0);
                    } else {
                        System.arraycopy(this.buffer,this.cursor,
                            this.str,0,len);
                    }
                    p = len;
                    this.cursor = this.end;
                    if ((FL_C & this.trc) != 0){
                        Trc.out.println("shortcut");
                    }
                }
            }
        }
        int cursorStart = this.cursor;
        scan: while (this.cursor < this.end){
            char ch;
            if (this.isStr){
                ch = this.string.charAt(this.cursor);
            } else {
                ch = this.buffer[this.cursor];
            }
            switch (ch){
            case '\n':                               // general terminators
            case '\r':
                if (this.argn < 0) break scan;
                break;
            case '\"':
                if (this.argn >= 0){                 // not in an indirect command file
                    if (this.cursor != cursorStart) break;
                }
                this.cursor++;                       // skip "
                while (this.cursor < this.end){
                    char c;
                    if (this.isStr){
                        c = this.string.charAt(this.cursor++);
                    } else {
                        c = this.buffer[this.cursor++];
                    }
                    if (c == '\"'){                  // check end or ""
                        if ((HTMLVALUE & this.mode) != 0)
                            continue scan;           // end of string
                        if (this.cursor < this.end){
                            if (this.isStr){
                                c = this.string.charAt(this.cursor);
                            } else {
                                c = this.buffer[this.cursor];
                            }
                            if (c == '\"'){
                                this.cursor++;       // ""
                            } else {
                                continue scan;       // end of string
                            }
                        } else {
                            continue scan;           // end of string
                        }
                    }
                    if (p == pe){
                        str = extend();
                        pe = str.length;
                    }
                    str[p++] = c;                    // store in return string
                }
                error(ERR_STRNOCL,ARG);              // string not closed
                break;
            case '\'':
                if ((HTMLVALUE & this.mode) == 0) break;
                this.cursor++;                       // skip '
                while (this.cursor < this.end){
                    char c;
                    if (this.isStr){
                        c = this.string.charAt(this.cursor++);
                    } else {
                        c = this.buffer[this.cursor++];
                    }
                    if (c == '\'')                   // end of string
                        continue scan;
                    if (p == pe){
                        str = extend();
                        pe = str.length;
                    }
                    str[p++] = c;                    // store in return string
                }
                error(ERR_STRNOCL,ARG);              // string not closed
                break;
            case ' ':
            case '\t':
                if (this.argn < 0) break scan;
                break;
            case '+': case ',': case ')':            // terminators of value
                if ((DCLLSEP & this.mode) != 0) break scan;
                break;
            case '/':
                if ((QUALSL & this.mode) != 0) break scan;
                break;
            case ':':
                if (list) break scan;
                break;
            }
            if (p == pe){
                str = extend();
                pe = str.length;
            }
            if (this.argn < 0){
                if ((TOUPPER & this.mode) != 0){         // conver to upper
                    if (ch < 128) ch = Str.UPPER[ch];
                    else ch = Character.toUpperCase(ch);
                } else if ((TOLOWER & this.mode) != 0){  // conver to lower
                    if (ch < 128) ch = Str.LOWER[ch];
                    else ch = Character.toLowerCase(ch);
                }
            }
            str[p++] = ch;                       // store in return string
            this.cursor++;                       // normal character
        } // scan

        this.strLen = p;
        if ((FL_V & this.trc) != 0){
            Trc.out.println("piece: " +
                toAbbrev(this.argn,start,this.argn,this.cursor,0) +
                " value: " + ((this.str == null) ? "" :
                String.valueOf(this.str,0,this.strLen) + " mode: " +
                ((QUALSL & this.mode) != 0)));
        }
        if ((FL_B & this.trc) != 0){
            if (this.cursor - start > 0)
                Trc.out.println("element found: " +
                toAbbrev(this.argn,start,this.argn,this.cursor,0));
        }
        if ((FL_C & this.trc) != 0){
            trcpoint("qvelem end");
        }
        boolean found = (this.cursor - start > 0) || empty;
        if ((type != void.class)){                   // decode the value
            int savargn = this.argn;                 // reposition for
            int savcur = this.cursor;                // .. error reporting
            reposition(this.argn,start);
            decode(ar,ele);
            reposition(savargn,savcur);
        }
        return found;
    }

    /**
     * Extend the string for returning element values.
     *
     * @return     reference to the extended area.
     */

    private char[] extend(){
        if (this.str == null){
            if ((FL_M & this.trc) != 0){
                Trc.out.println("extend: 0");
            }
            this.str = new char[10];
            return this.str;
        }
        char[] cur = this.str;
        if ((FL_M & this.trc) != 0){
            Trc.out.println("extend: " + cur.length + " " +
                String.valueOf(cur));
        }
        int newlen = cur.length + 10;
        if (newlen < 0) error(ERR_OUTLIMIT,ARG);
        char[] p = new char[newlen];
        System.arraycopy(cur,0,p,0,cur.length);
        this.str = p;
        return p;
    }

    /**
     * Get a delimiter, and advance the cursor if found.
     *
     * @param      d delimiter
     * @return     true if found
     */

    private boolean getDel(char d){
        boolean res = false;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("getDel: " + d);
        }
        doit: {
            if (this.cursor >= this.end) break doit;
            char ch;
            if (this.isStr){
                ch = this.string.charAt(this.cursor);
            } else {
                ch = this.buffer[this.cursor];
            }
            if (ch == d){
                this.cursor++;
                res = true;
                break doit;
            }
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("getDel: " + res);
        }
        return res;
    }

    /**
     * Get a parameter. To check that a parameter is specified, it checks
     * that it scanned at least one character. This is possible
     * because a parameter may not start with a @ which is a global
     * qualifier. This check is done to detect early the absence of a
     * required parameter.
     *
     * @param      p index of the parameter
     * @return     true if found
     */

    boolean get_parameter(int p){
        Parameter par;
        Element   e;
        boolean   res;
        int       val = ABSENT;
        int       ini;
        int       argni;

        res = false;
        par = (Parameter)(this.cmddes.args[p]);
        if ((FL_C & this.trc) != 0){
            Trc.out.println("get_parameter: " +
                par.name);
        }
        this.ini = this.cursor;                    // start of parameter
        this.argni = this.argn;
        ini = -1;
        argni = 0;
        int endargn = this.argn;
        int endcur = this.cursor;
        while (skipws()){
            if (ini == -1){
                ini = this.cursor;                 // start (after white space)
                argni = this.argn;
            }
            this.arg_an = p;
            this.arg_ln = -1;
            e = this.elems[toSeq()];               // .. parameter (after skipws) for
            e.argni = argni;                       // .. getCommand missing local quals
            val = par_element(p,e);                // get a value list element
            if ((FL_C & this.trc) != 0){
                Trc.out.println("get_parameter loop " +
                    STA[val]);
                trcpoint("loop");
            }
            if (val == ABSENT) break;              // not found, not even a
            endargn = this.argn;
            endcur = this.cursor;
            res = true;                            // .. comma
            if (val == PRESENT) break;
        }
        this.arg_an = p;
        this.arg_ln = -1;
        if (ini == -1){                            // no characters
            if ((AR_REQ & par.attr) != 0){         // required parameter
                error(ERR_MISPAR,ARG);             // .. missing
            }                                      // (for testing)
        }
        if (ini == -1){
            ini = this.cursor;
            argni = this.argn;
        }
        if (res){
            e = this.elems[toSeq()];
            e.ini = ini;
            e.argni = argni;
            e.end = endcur;
            e.argne = endargn;
            if ((FL_C & this.trc) != 0){
                Trc.out.println("get_parameter stored: " + toSeq() +
                    " (" + e.argni + ") " + e.ini + " (" +
                    e.argne + ") " + e.end);
            }
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("get_parameter ini: " +
                seek_placestr(argni) + " " + ini +
                " cur: " + seek_placestr(argn) + " " + this.cursor);
        }
        return res;
    }

    /**
     * Parse the value of a parameter, possibly an element in a list
     * of values, and its local qualifiers, and record the data of the
     * local qualifiers in the element descriptors.
     * If the return string is not null, then it returns the string of
     * the value (element) in it.
     *
     * @param      p index of the parameter
     * @param      ele element for the parameter
     * @return     ABSENT  if not found
     *             PRESENT if found
     *             CONT    if found and followed by , (DCL) or another element
     *             CONCAT  if found and followed by +
     */

    private int par_element(int p, Element ele){
        Argument  q;
        Element   e;
        Argument  qua;
        boolean   val;
        int       ret;
        int       endpar;
        int       endargn;
        int       startpar;
        int       startargn;
        char      ch;

        ret = ABSENT;
        Parameter par = (Parameter)(this.cmddes.args[p]);
        int lmax = par.args.length;
        if (lmax > 0){
            int en = toSeq(p,0);
            for (int i = 0; i < lmax; i++){
                this.elems[en++].ini = -1;          // initialize ini
            }
        }
        endpar = this.cursor;
        endargn = this.argn;
        startpar = this.cursor;
        startargn = this.argn;
        if ((FL_C & this.trc) != 0){
            trcpoint("par_element");
            Trc.out.println("par: " + par.name);
        }
        pref: {                                 // match prefix
            if ((DCLLSEP & this.mode) != 0)     // no Unix list
                break pref;
            if ((QVALCO & this.mode) == 0)      // no : separator allowed
                break pref;
            if ((FL_C & this.trc) != 0){
                Trc.out.println("par_element prefix");
            }
            qua = get_qual(p,PREFIX);           // get prefix qualifier
        }
        if ((FL_C & this.trc) != 0){
            trcpoint("par_element qvelem");
        }
        val = get_qvelem(false,ele,par,par.type);   // get the value
        boolean elem = val;
        if (val){
            endpar = this.cursor;
            endargn = this.argn;
        }
        skipws();                               // skip white space
        if ((FL_C & this.trc) != 0){
            trcpoint("par_element");
            Trc.out.println("mode: " +
                Integer.toOctalString(this.mode));
        }
        boolean endlist = true;
        do {                                      // local qualifiers
            byte suf = (((DCLLSEP & this.mode) == 0) &&
                ((QVALCO & this.mode) != 0)) ? SUFFIX : GENERAL;
            qua = get_qual(p,suf);                // match qualifiers
            if ((FL_C & this.trc) != 0)
                Trc.out.println("par_element loop " +
                    qua + " " + this.ini);
            if ((qua != null) && (this.ini == -1)){
                endlist = false;                  // prefix qualifier present
                qua = null;
            }
            if (qua != null){
                endpar = this.cursor;
                endargn = this.argn;
            }
        } while (qua != null);
        if ((FL_C & this.trc) != 0){
            trcpoint("end element");
        }
        if (lmax > 0){
            val |= checkElem(p,par);
        }
        if ((FL_C & this.trc) != 0){
            // trc_eletab();
            Trc.out.println("attr " + Integer.toOctalString(par.attr)
                + " " + val + " " + lmax);
        }
        if ((AR_VALREQ & par.attr) != 0){
            if (!elem){
                reposition(startargn,startpar);
                error(ERR_MISVAL,p,-1);
            }
        }
        if ((AR_EMPTY & par.attr) == 0){
            if (!val){
                error(ERR_MISVAL,p,-1);
            }
        }
        if (val) ret = PRESENT;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("endpar: " + endpar + " " + STA[ret] +
                " " + endlist);
        }
        getlist:
        if ((AR_LIST & par.attr) != 0){
            if ((DCLLSEP & this.mode) == 0){    // Unix list
                if (!val) break getlist;
            }
            if (!skipws()) break getlist;       // skip white space
            if ((FL_C & this.trc) != 0){
                trcpoint("par_element list");
            }
            if (this.cursor >= this.end){
                break getlist;
            }
            islist:
            if ((DCLLSEP & this.mode) == 0){    // Unix list
                if (getDel('-')){
                    if (isWhite()){             // - alone
                        this.cursor--;
                        ret = CONT;
                    } else {
                        this.cursor--;
                        if (!endlist) ret = CONT;   // a prefix qualifier
                    }
                } else if (!getDel('+')){       // another element
                    ret = CONT;
                } else {
                    this.cursor--;
                    if (!endlist) ret = CONT;   // a prefix qualifier
                }
            } else {
                if (getDel(',')){
                    ret = CONT;
                } else if (getDel('+')){
                    ret = CONCAT;
                } else {
                    break getlist;
                }
                val = true;
                endpar = this.cursor;
                endargn = this.argn;
            }
        }
        reposition(endargn,endpar);             // end, at first char not of par
        if ((FL_B & this.trc) != 0){
            Trc.out.println("parameter found: " +
                toAbbrev(startargn,startpar,
                    this.argn,this.cursor,0));
        }
        if ((FL_C & this.trc) != 0)
            Trc.out.println("par_element return: " + STA[ret]);
        return ret;
    }


    /**
     * Check the elements for the local qualifiers.
     *
     * @param      an argument number
     * @param      ar reference to the argument
     * @return     true if at least one is present
     */

    private boolean checkElem(int an, Argument ar){
        Element e;
        boolean val = false;
        int en = toSeq(an,0);
        int lmax = ar.args.length;
        for (int ln = 0; ln < lmax; ln++){
            Argument a = ar.args[ln];
            e = this.elems[en++];
            e.cursor = e.ini;                 // initialize cursor, used
            e.argnc = e.argni;                // .. for testing
            if (((AR_ALT & a.attr) != 0) &&   // check alternative
                ((AR_REQ & a.attr) != 0)){
                int f = ln;
                en--;
                int nr = 0;
                for (; ln < lmax; ln++){
                    a = ar.args[ln];
                    e = this.elems[en++];
                    if ((AR_ALT & a.attr) == 0) break;
                    if (e.ini >= 0) nr++;
                }
                if (nr == 0){
                    error(ERR_MISQUAL,an,f);
                }
            } else if ((AR_REQ & a.attr) != 0){     // check required arguments
                if (e.ini == -1){
                    if ((FL_C & this.trc) != 0)
                        Trc.out.println("missing-ele: " +
                            a.name);
                    error(ERR_MISQUAL,an,ln);       // missing qualifier
                }
            }
            val |= e.ini != -1;
        }
        return val;
    }


    /* Value decode methods */

    /** The description of an argument's type. */

    private static class ArgType {

        /** Type of argument. */
        private Class type;

        /** Type name. */
        String name;

        /** Callback code. */
        char code;

        /**
         * Construct an argument type descriptor.
         *
         * @param      t class
         * @param      n key for the mnemonics of the class in CliBundle
         * @param      c callback code
         */

        private ArgType(Class t, String n, char c){
            this.type = t;
            this.name = n;
            this.code = c;
        }
    }

    /**
     * Check the type of an argument and its attributes relative to the
     * type.
     *
     * @param      ar argument
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     */

    private void checkType(Argument ar, int an, int ln){
        if (ar.code == '\0'){
            error(ERR_ILLTYPE,an,ln);
        }

        int fmask = AR_UNS | AR_BIN | AR_OCT | AR_HEX |
            AR_ROM | AR_UNI | AR_MON;
        switch (ar.code){
        case 'B': case 'S': case 'I': case 'L': {
            int amask = AR_UNS | AR_BIN | AR_OCT | AR_HEX | AR_ROM;
            if (((ar.attr & fmask) & ~amask) != 0){
                error(ERR_ILLTYPE,an,ln);
            }
            int mask = ar.attr & (AR_BIN | AR_OCT | AR_HEX | AR_ROM);
            for (int i = 1; i <= 4; i++){
                int m = 0;
                switch (i){
                case 1: m = AR_BIN; break;
                case 2: m = AR_OCT; break;
                case 3: m = AR_HEX; break;
                case 4: m = AR_ROM; break;
                }
                if ((mask & m) != 0){
                    if ((mask & ~m) != 0) error(ERR_ILLATTR,an,ln);
                }
            }
            break;}
        case 'c': case 's':
            if (((ar.attr & fmask) & ~AR_UNI) != 0){
                error(ERR_ILLATTR,an,ln);
            }
            break;
        case 'F': case 'D':
            if (((ar.attr & fmask) & ~AR_MON) != 0){
                error(ERR_ILLATTR,an,ln);
            }
            break;
        default:
            if ((ar.attr & fmask) != 0){
                error(ERR_ILLATTR,an,ln);
            }
        }
    }

    /**
     * Decode the value of an (element of an) argument.
     *
     * @param      ar argument
     * @param      ele element
     */

    private void decode(Argument ar, Element ele){
        if ((FL_V & this.trc) != 0){
            Trc.out.print("decode");
            if (ar != null){
                Trc.out.print("  " + ar.code + " " + ar.name +
                    " " + ar.type + " " + ((ar.attr & AR_ARR) != 0));
            }
            Trc.out.println();
        }
        char code = 's';
        if (ar != null) code = ar.code;
        switch (code){
        case 'B': case 'S': case 'I': case 'L':
            ele.integral = int_cbk(ar); break;
        case 'b': ele.integral = bool_cbk(ar) ? 1 : 0; break;
        case 'F': case 'D':
            ele.real = float_cbk(ar,ele); break;
        case 'c': ele.integral = char_cbk(ar); break;
        case 's': ele.obj = str_cbk(ar); break;
        case 'd': ele.obj = date_cbk(ar); break;
        }
        if (ar == null) return;
        coll: if ((ar.attr & AR_ARR) != 0){       // an array passed
            src: {
                int i = 0;
                seek: switch (code){
                case 'B': {
                    byte[] arr = (byte[])(ar.type);
                    byte val = (byte)(ele.integral);
                    for (i = 0; i < arr.length; i++){
                        if (val == arr[i]) break seek;
                    }
                    break src;}
                case 'S': {
                    short[] arr = (short[])(ar.type);
                    short val = (short)(ele.integral);
                    for (i = 0; i < arr.length; i++){
                        if (val == arr[i]) break seek;
                    }
                    break src;}
                case 'I': {
                    int[] arr = (int[])(ar.type);
                    int val = (int)(ele.integral);
                    for (i = 0; i < arr.length; i++){
                        if (val == arr[i]) break seek;
                    }
                    break src;}
                case 'L': {
                    long[] arr = (long[])(ar.type);
                    long val = ele.integral;
                    for (i = 0; i < arr.length; i++){
                        if (val == arr[i]) break seek;
                    }
                    break src;}
                case 'b': {
                    boolean[] arr = (boolean[])(ar.type);
                    boolean val = (ele.integral == 0) ? false : true;
                    for (i = 0; i < arr.length; i++){
                        if (val == arr[i]) break seek;
                    }
                    break src;}
                case 'F': {
                    float[] arr = (float[])(ar.type);
                    float val = (float)(ele.real);
                    for (i = 0; i < arr.length; i++){
                        if (val == arr[i]) break seek;
                    }
                    break src;}
                case 'D': {
                    double[] arr = (double[])(ar.type);
                    double val = ele.real;
                    for (i = 0; i < arr.length; i++){
                        if (val == arr[i]) break seek;
                    }
                    break src;}
                case 'c': {
                    char[] arr = (char[])(ar.type);
                    char val = (char)(ele.integral);
                    for (i = 0; i < arr.length; i++){
                        if (val == arr[i]) break seek;
                    }
                    break src;}
                case 's': {
                    String[] arr = (String[])(ar.type);
                    String val = (String)(ele.obj);
                    for (i = 0; i < arr.length; i++){
                        if (val.equals(arr[i])) break seek;
                    }
                    break src;}
                case 'm': {
                    break;}
                case 'd': {
                    Date[] arr = (Date[])(ar.type);
                    Date val = (Date)(ele.obj);
                    for (i = 0; i < arr.length; i++){
                        if (val.equals(arr[i])) break seek;
                    }
                    break src;}
                default: {
                    Class c = ar.type.getClass();
                    Class cl = c.getComponentType();
                    Object[] arr = (Object[])(ar.type);
                    Object val = (Object)(ele.obj);
                    for (i = 0; i < arr.length; i++){
                        if (val.equals(arr[i])) break seek;
                    }
                    break src;}
                }
                ele.integral = i;
                if ((FL_V & this.trc) != 0){
                    Trc.out.println("decode array " + i);
                }
                break coll;
            } // src
            error(ERR_ILLVAL);
        } // coll
    }

    /**
     * Decode an integral value.
     *
     * @param      ar argument
     */

    private long int_cbk(Argument ar){
        long v = 0;
        long base = 10;

        if (this.strLen == 0){
            return 0;
        }
        if ((AR_BIN & ar.attr) != 0) base = 2;
        else if ((AR_OCT & ar.attr) != 0) base = 8;
        else if ((AR_HEX & ar.attr) != 0) base = 16;
        if (this.lex == null) this.lex = new Lexer();
        Lexer l = this.lex;
        l.buffer = this.str;
        l.length = this.strLen;
        l.end = l.length;
        l.cursor = 0;
        l.mode = Lexer.BASE | Lexer.MEGA;
        l.trc = this.trc;
        if ((AR_ROM & ar.attr) != 0){      // roman numeral
            v = l.parseRoman();
            return v;
        } else {
            if ((AR_UNS & ar.attr) == 0)
               l.mode &= ~Lexer.UNSIGNED;
            else
               l.mode |= Lexer.UNSIGNED;
            LocNumData locData = this.report.getLocNumData(1);
            v = l.parseLong(base,locData);
        }
        if ((Lexer.ERROR & l.mode) != 0)
            error(ERR_ILLVAL,ARG);
        if ((Lexer.OVERFLOW & l.mode) != 0)
            error(ERR_RANGE,ARG);
        if (l.cursor != l.length)
            error(ERR_ILLVAL,ARG);
        if ((AR_ROM & ar.attr) != 0){      // roman numeral
            return v;
        }
        check: {
            if ((AR_UNS & ar.attr) == 0){
                switch (ar.code){
                case 'B':
                    if ((Byte.MIN_VALUE <= v) && (v <= Byte.MAX_VALUE))
                        break check;
                    break;
                case 'S':
                    if ((Short.MIN_VALUE <= v) && (v <= Short.MAX_VALUE))
                        break check;
                    break;
                case 'I':
                    if ((Integer.MIN_VALUE <= v) && (v <= Integer.MAX_VALUE))
                        break check;
                    break;
                default: break check;
                }
            } else {
                switch (ar.code){
                case 'B':
                    if (v <= ((long)Byte.MAX_VALUE << 1) + 1) break check;
                    break;
                case 'S':
                    if (v <= ((long)Short.MAX_VALUE << 1) + 1) break check;
                    break;
                case 'I':
                    if (v <= ((long)Integer.MAX_VALUE << 1) + 1) break check;
                    break;
                default: break check;
                }
            }
            error(ERR_RANGE,ARG);
        }
        return v;
    }

    /**
     * Decode a floating point value.
     *
     * @param      ar argument
     */

    private double float_cbk(Argument ar, Element e){
        double  result = 0.0D;
        boolean negative = false;
        int     csy = 0;
        int     i = 0;
        int     len = this.strLen;
        char[]  s   = this.str;

        if (this.strLen == 0){
            return 0.0D;
        }
        LocNumData locData = this.report.getLocNumData(1);
        if (this.lex == null) this.lex = new Lexer();
        Lexer l = this.lex;
        l.buffer = this.str;
        l.length = this.strLen;
        l.end = l.length;
        l.cursor = 0;
        l.mode = 0;
        if ((AR_MON & ar.attr) != 0) l.mode |= Lexer.MONETA;
        l.trc = this.trc;
        result = l.parseDouble(locData);
        if ((Lexer.ERROR & l.mode) != 0)
            error(ERR_ILLVAL,ARG);
        if ((Lexer.OVERFLOW & l.mode) != 0)
            error(ERR_RANGE,ARG);
        if (l.cursor != l.length)
            error(ERR_ILLVAL,ARG);
        if (ar.code == 'F'){            // check range for float
            if (((float)result < Float.MIN_VALUE) ||
               (Float.MAX_VALUE < (float)result)){
               error(ERR_RANGE,ARG);
            }
        }
        if ((AR_MON & ar.attr) != 0){          // return numeric code
            e.integral = l.integral;
        }
        return result;
    }

    /**
     * Decode a boolean value.
     *
     * @param      ar argument
     */

    private boolean bool_cbk(Argument ar){
        boolean result = false;
        int  i;

        for (i = 0; i < this.valStrLoc.length; i++){
            if ((FL_V & this.trc) != 0){
                Trc.out.println("bool_cbk: " +
                    String.valueOf(this.str,0,this.strLen) +
                    " " + this.valStrLoc[i]);
            }
            int ln = this.valStrLoc[i].length();
            if (Str.compareSlices(this.str,this.strLen,0,ln,
                this.valStrLoc[i],ln,0,ln,true,false) == 0){
                result = (i & 1) != 0;
                return result;
            }
        }
        error(ERR_ILLVAL,ARG);
        return result;
    }

    /**
     * Decode a character value.
     *
     * @param      ar argument
     */

    private char char_cbk(Argument ar){
        char result = '\0';

        if ((AR_UNI & ar.attr) != 0){           // reduce escapes
            if (this.lex == null) this.lex = new Lexer();
            Lexer l = this.lex;
            l.buffer = this.str;
            l.length = this.strLen;
            l.end = l.length;
            l.cursor = 0;
            l.mode = 0;
            l.trc = this.trc;
            this.strLen = Lexer.reduceUnicode(this.str,0,this.strLen);
            if (this.strLen < 0){
                error(ERR_ILLVAL,ARG);
            }
        }
        if (this.strLen > 1) error(ERR_ILLVAL,ARG);
        result = this.str[0];
        if ((FL_V & this.trc) != 0){
            Trc.out.println("char_cbk result: " + result);
        }
        return result;
    }

    /**
     * Decode a string value.
     *
     * @param      ar argument
     */

    private String str_cbk(Argument ar){
        String result = "";

        int attr = 0;                            //N.B. ar can be null
        if (ar != null) attr = ar.attr;

        if ((attr & AR_ARR) == 0){               // not a list of keys
            if ((AR_LIST & attr) != 0){
                if (this.pass < 2) return result;
            }
        }
        if ((this.argn >= 0) && (this.isStr) &&
            (this.argn < this.argc) &&
            (this.strLen ==                      // whole String argv,
            this.args[this.argn].length()) &&    // .. return it
            ((HTMLVALUE & this.mode) == 0) &&
            ((AR_UNI & attr) == 0)){
            result = this.args[this.argn];
            if ((FL_V & this.trc) != 0){
                Trc.out.println("str_cbk short: " + result);
            }
        } else if (this.strLen > 0){
            if (this.lex == null) this.lex = new Lexer();
            Lexer l = this.lex;
            l.buffer = this.str;
            l.length = this.strLen;
            l.end = l.length;
            l.cursor = 0;
            l.mode = 0;
            l.trc = this.trc;
            if ((HTMLVALUE & this.mode) != 0){   // reduce character entities
                this.strLen = Lexer.reduceHtml(this.str,0,this.strLen);
            } else if ((AR_UNI & attr) != 0){    // reduce escapes
                this.strLen = Lexer.reduceUnicode(this.str,0,this.strLen);
                if (this.strLen < 0){
                    error(ERR_ILLVAL,ARG);
                }
            }
            result = String.valueOf(this.str,0,this.strLen);
            if ((FL_V & this.trc) != 0){
                Trc.out.println("str_cbk allocates " + result);
            }
        }
        return result;
    }

    /**
     * Decode a date value.
     *
     * @param      ar argument
     */

    private Date date_cbk(Argument ar){
        DateFormat df;
        Date       result = null;

        try {
            // Alas, it allocates always, no way to check syntax without
            // allocating
            df = DateFormat.getDateTimeInstance(DateFormat.DEFAULT,
                DateFormat.DEFAULT,getDefault());
            String str = String.valueOf(this.str,0,this.strLen);
            if ((FL_V & this.trc) != 0){
                Trc.out.println("date_cbk parse " + str);
            }
            result = df.parse(str);
            if ((FL_V & this.trc) != 0){
                Trc.out.println("date_cbk allocates " + result);
            }
        } catch (ParseException exc){
            error(ERR_ILLVAL,exc,null,ARG);
        }
        return result;
    }


    /* Command access methods */

    /**
     * Deliver the command code of the current command.
     *
     * @return     code
     */
 
    public int commandCode(){
        int c = 0;
        if (this.cmddes != null) c = this.cmddes.cmdcode;
        return c;
    }

    /**
     * Test if a given argument is present in a command. It is equivalent
     * to <code>present(an,-1)</code>
     */
 
    public int present(int an){
        return present(an,-1);
    }

    /**
     * Test if a given argument is present in a command. If a parameter has
     * been accessed with a previous <code>value()</code>,
     * <code>present()</code> can be used to check the presence also of its
     * local qualifiers.
     * It returns ERR_UNKARG if the index is not one of those defined.
     *
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     * @return     ABSENT  if the argument has not been specified
     *             PRESENT if it has been specified in the normal form
     *             NEGATED if it has been specified in the negated form
     */

    public int present(int an, int ln){
        int res = ABSENT;

        excInit();
        try {
            res = arg_present(an,ln);
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
        return res;
    }

    /**
     * Test if a given argument is present in a command. To be used
     * internally.
     *
     * @see        #longValue(int,int)
     */

    private int arg_present(int an, int ln){
        int       res;
        int       seq = 0;
        Parameter par;
  
        if ((FL_C & this.trc) != 0){
            Trc.out.println("arg_present: " + an + " " + ln);
        }
        if ((this.pass <= 1) && (an != VERB)){     // not parsed
            error(ERR_SEQUENCE);
        }
        res = ABSENT;
        seq = toSeq(an,ln);
        done: if (this.elems[seq].ini != -1){      // specified
            res = PRESENT;
            if (this.elems[seq].neg)               // negated
                res = NEGATED;
            if (an == VERB) break done;
            if (ln == -1){
                this.curpar = an;
            } else {
                int sp = toSeq(an,-1);             // seq nr. of parameter
                if (this.elems[sp].ini == -1)      // not specified
                    res = ABSENT;                  // parameter check on
            }
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("present: " + toArgument(an,ln).name +
                " seq: " + seq);
            Trc.out.println("res: " + STA[res]);
        }
        this.arg_an = an;
        this.arg_ln = ln;
        return res;
    }

    /**
     * Deliver the next value of a parameter or of a qualifier.
     * It is equivalent to <code>value(an,-1)</code>.
     */

    private int value(int an){
        return value(an,-1);
    }

    /** Argument number for the verb. */
    public static final int VERB = -1;

    /**
     * Determine if the value of a parameter or of a qualifier is
     * present. When the value is not a list, it delivers the same
     * result at each cal, otherwise it delivers the presence of the
     * next element value.
     * It returns ERR_UNKARG if the index is not one of those defined.
     *
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     * @return     ABSENT  if the argument has not been specified
     *             NEGATED if it has been specified in the negated form
     *             PRESENT if a value is present
     *             CONT    if a value is present and is followed by ,
     *             CONCAT  if a value is present and is followed by + (for
     *                     parameter values in a list of values)
     */

    private int value(int an, int ln){
        Argument  a, lq;
        Element   e, le;
        int       res;
        boolean   qua;

        if ((FL_C & this.trc) != 0){
            Trc.out.println("value: " + an + " " + ln);
        }
        excInit();
        res = ABSENT;
        this.strLen = 0;
        try {
            res = arg_present(an,ln);            // test if present
            a = toArgument(an,ln);
            doit:
            if (res == PRESENT){                 // parameter or non-negated
                                                 // .. qualifier
                e = this.elems[toSeq()];
                reposition(e.argnc,e.cursor);
                if ((FL_C & this.trc) != 0){
                    trcpoint("value start");
                    Trc.out.println(a.name + " (" +
                       e.argnc + ") " + e.cursor + " (" +
                       e.argne + ") " + e.end);
                }
                if ((AR_PAR & a.attr) != 0){         // parameter
                    if ((e.cursor == e.end) &&
                        (e.argnc == e.argne)){
                        last: {
                            if (this.cursor == 0) break last;
                            this.cursor--;
                            if ((DCLLSEP & this.mode) != 0){
                                if (!getDel(',')) break last;
                            } else {
                                break last;
                            }
                            e.cursor = -2;           // flag last
                            res = PRESENT;           // last empty element in list
                            decode(a,e);             // fill value
                            break doit;
                        }
                        res = ABSENT;
                        break doit;
                    }
                    if (e.cursor == -2){             // also last empty
                        res = ABSENT;                // .. element exhausted
                        break doit;
                    }
                    list:
                    if ((AR_LIST & a.attr) != 0){
                        res = par_element(this.curpar,e);  // get a value list element
                        if ((this.argn == e.argne) &&      // last empty
                            (this.cursor == e.end))
                            break list;
                        skipws();
                    } else {
                        res = ((e.end > e.ini) ||
                            (e.argne > e.argni)) ? PRESENT : ABSENT;
                        break doit;
                    }
                } else if (a.type == void.class){    // it allows no value
                    res = ABSENT;
                    break doit;
                } else {                             // valued qualifier
                    if ((e.cursor == e.end) &&
                        (e.argnc == e.argne)){
                        last: if ((AR_LIST & a.attr) != 0){
                            if (this.cursor == 0) break last;
                            this.cursor--;
                            if ((DCLLSEP & this.mode) == 0){
                                if (!getDel(':')) break last;
                            } else {
                                if (!getDel(',')) break last;
                            }
                            e.cursor = -2;           // flag last
                            res = PRESENT;           // last empty element in list
                            decode(a,e);             // fill value
                            break doit;
                        }
                        res = ABSENT;
                        break doit;
                    }
                    if (e.cursor == -2){             // also last empty
                        res = ABSENT;                // .. element exhausted
                        break doit;
                    }
                    list:
                    if ((AR_LIST & a.attr) != 0){
                        boolean unilist = ((AR_LIST & a.attr) != 0)
                            && ((DCLLSEP & this.mode) == 0);   // unix list
                        qua = get_qvelem(unilist,e,a,a.type);  // get element
                        res = (qua) ? PRESENT : ABSENT;
                        if (!skipws()){
                            break list;
                        }
                        if ((DCLLSEP & this.mode) == 0){
                            if (!getDel(':')) break list;
                        } else {
                            if (!getDel(',')) break list;
                        }
                        res = CONT;                        // list, skip it
                        if ((this.argn == e.argne) &&      // last empty
                            (this.cursor == e.end)) break list;
                        skipws();
                    } else {
                        res = ((e.end > e.ini) ||
                          (e.argne > e.argni)) ? PRESENT : ABSENT;
                        break doit;
                    }
                }
                e.cursor = this.cursor;
                e.argnc = this.argn;
                if ((FL_C & this.trc) != 0){
                    trcpoint("value save");
                }
            } // doit
            if ((FL_C & this.trc) != 0){
                Trc.out.println("value " + STA[res]);
            }
            this.arg_an = an;
            this.arg_ln = ln;
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
        return res;
    }

    /**
     * Reinitialize the Cli object so as to allow to access again
     * the arguments with <code>present()</code> and
     * <i>type</i><code>Value()</code>.
     */

    public void restart(){
        excInit();
        if (this.pass <= 1){               // not initialized
            registerError(ERR_SEQUENCE);
        } else {
            restartElems(false);
        }
        excTerm();
    }

    /**
     * Reinitialize the Cli object so as to allow to access again
     * the specified argument with <code>present()</code> and
     * <i>type</i><code>Value()</code>.
     */

    public void restart(int an){
        restart(an,-1);
    }

    /**
     * Reinitialize the Cli object so as to allow to access again
     * the specified argument with <code>present()</code> and
     * <i>type</i><code>Value()</code>.
     */

    public void restart(int an, int ln){
        excInit();
        if (this.pass <= 1){               // not initialized
            registerError(ERR_SEQUENCE);
        } else {
            Element e = this.elems[toSeq(an,ln)];
            e.cursor = e.ini;
            e.argnc = e.argni;
            this.arg_an = an;
            this.arg_ln = ln;
        }
        excTerm();
    }

    /**
     * Reinitialize the Cli object as <code>restart()</code>, but
     * allows to force pass 2 for testing purposes.
     *
     * @param      force if true, pass 2 is forced
     */

    void restart(boolean force){           // for testing
        if (force) this.pass = 2;
        restartElems(false);
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #longValue(int,int)
     */

    public boolean boolValue(int an){
        return (longValue(an,-1) == 0) ? false : true;
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #longValue(int,int)
     */

    public boolean boolValue(int an, int ln){
        return (longValue(an,ln) == 0) ? false : true;
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #longValue(int,int)
     */

    public int charValue(int an){
        return (char)longValue(an,-1);
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #longValue(int,int)
     */

    public int charValue(int an, int ln){
        return (char)longValue(an,ln);
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #longValue(int,int)
     */

    public int byteValue(int an){
        return (byte)longValue(an,-1);
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #longValue(int,int)
     */

    public int byteValue(int an, int ln){
        return (byte)longValue(an,ln);
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #longValue(int,int)
     */

    public int shortValue(int an){
        return (short)longValue(an,-1);
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #longValue(int,int)
     */

    public int shortValue(int an, int ln){
        return (short)longValue(an,ln);
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #longValue(int,int)
     */

    public int intValue(int an){
        return (int)longValue(an,-1);
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #longValue(int,int)
     */

    public int intValue(int an, int ln){
        return (int)longValue(an,ln);
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #longValue(int,int)
     */

    public long longValue(int an){
        return longValue(an,-1);
    }

    /**
     * Deliver the (next) value of an argument. The value of a verb is
     * the sequence number of the command in a set of commands, starting
     * at 0. The <code>status</code> field indicates its presence.
     *
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     * @return     value
     */

    public long longValue(int an, int ln){
        Argument  a;
        Element   e = null;
        long      v = 0;

        excInit();
        doit: try {
            if (an == VERB){
                this.status = arg_present(an,ln);  // test if present
                v = this.cmddes.code;
                break doit;
            }
            a = toArgument(an,ln);
            this.arg_an = an;
            this.arg_ln = ln;
            e = this.elems[toSeq()];
            switch (a.code){
            case 'B': case 'S': case 'I':
            case 'L': case 'c': case 'b': break;
            case 'F': case 'D':
                if ((a.attr & AR_MON) == 0){
                    error(ERR_ILLTYPE);
                }
                v = e.integral;
                break doit;
            default:
                if ((a.attr & AR_ARR) == 0){
                    error(ERR_ILLTYPE);
                }
            }
            this.status = value(an,ln);
            if ((this.status == ABSENT) || (this.status == NEGATED))
                break doit;
            if ((FL_V & this.trc) != 0){
                Trc.out.println("longValue: " + toSeq());
            }
            v = e.integral;
            if ((FL_V & this.trc) != 0){
                Trc.out.println("longValue: value: " + v);
            }
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
        return v;
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #doubleValue(int,int)
     */

    public float floatValue(int an){
        return (float)doubleValue(an,-1);
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #doubleValue(int,int)
     */

    public float floatValue(int an, int ln){
        return (float)doubleValue(an,ln);
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #doubleValue(int,int)
     */

    public double doubleValue(int an){
        return doubleValue(an,-1);
    }

    /**
     * Deliver the (next) value of an argument. The <code>status</code>
     * field indicates its presence.
     *
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     * @return     value
     */

    public double doubleValue(int an, int ln){
        Argument  a;
        Element   e = null;
        double    v = 0.0D;

        excInit();
        doit: try {
            a = toArgument(an,ln);
            switch (a.code){
            case 'F': case 'D': break;
            default: error(ERR_ILLTYPE);
            }
            this.status = value(an,ln);
            if ((this.status == ABSENT) || (this.status == NEGATED))
                break doit;
            if ((FL_V & this.trc) != 0){
                Trc.out.println("doubleValue: " + toSeq());
            }
            e = this.elems[toSeq()];
            v = e.real;
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
        return v;
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #strValue(int,int)
     */

    public String strValue(int an){
        return strValue(an,-1);
    }

    /**
     * Deliver the (next) value of an argument. The <code>status</code>
     * field indicates its presence.
     *
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     * @return     value
     */

    public String strValue(int an, int ln){
        Argument  a;
        Element   e = null;
        String    v = "";

        if ((FL_V & this.trc) != 0){
            Trc.out.println("strValue init");
        }
        excInit();
        doit: try {
            this.arg_an = an;
            this.arg_ln = ln;
            e = this.elems[toSeq()];
            a = toArgument(an,ln);
            int argnc = e.argnc;
            int cursor = e.cursor;
            this.status = value(an,ln);
            if ((this.status == ABSENT) || (this.status == NEGATED))
                break doit;
            if ((FL_V & this.trc) != 0){
                Trc.out.println("strValue: " + toSeq() +
                    " " + a.name + " " + a.code);
            }
            if (a.code == 's'){
                v = (String)(e.obj);
                break doit;
            }
            reposition(argnc,cursor);
            if ((FL_V & this.trc) != 0){
                trcpoint("strValue");
            }
            boolean unilist =
                ((AR_PAR & a.attr) == 0) &&
                ((AR_LIST & a.attr) != 0) &&
                ((DCLLSEP & this.mode) == 0);        // unix list
            get_qvelem(unilist,e,a,void.class);      // get element, no decode
            if ((this.argn >= 0) && (this.isStr) &&
                (this.argn < this.argc) &&
                (this.strLen ==                      // whole String argv,
                  this.args[this.argn].length())){   // .. return it
                v = this.args[this.argn];
                if ((FL_V & this.trc) != 0){
                    Trc.out.println("strValue short: " + v);
                }
                this.strLen = 0;
            }
            if (this.strLen > 0){
                v = String.valueOf(this.str,0,this.strLen);
                if ((FL_V & this.trc) != 0){
                    Trc.out.println("strValue allocates " + v);
                }
            }
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
        if ((FL_V & this.trc) != 0){
            Trc.out.println("strValue return: " + v);
        }
        return v;
    }

    /**
     * Deliver the (next) value of an argument.
     *
     * @see        #dateValue(int,int)
     */

    public Date dateValue(int an){
        return dateValue(an,-1);
    }

    /**
     * Deliver the (next) value of an argument. The <code>status</code>
     * field indicates its presence.
     *
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     * @return     value
     */

    public Date dateValue(int an, int ln){
        Argument  a;
        Element   e = null;
        Date      v = null;

        excInit();
        doit: try {
            a = toArgument(an,ln);
            switch (a.code){
            case 'd': break;
            default: error(ERR_ILLTYPE);
            }
            this.status = value(an,ln);
            if ((this.status == ABSENT) || (this.status == NEGATED))
                break doit;
            if ((FL_V & this.trc) != 0){
                Trc.out.println("dateValue: " + toSeq());
            }
            e = this.elems[toSeq()];
            v = (Date)(e.obj);
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
        return v;
    }


    /** The iterator for visiting Cli argument values. */

    public class CliIterator implements Iterator {

        /* It keeps the data relative to the Cli object and the
         * argument to be accessed to obtain a filename string.
         */

        /** The argument number. */
        private int an;

        /** The local qualifier number. */
        private int ln;

        /** The current element. */
        private Object element;

        /** The local encoding qualifier. */
        private String[] encname;

        /** Whether an element has been delivered. */
        private boolean delivered;

        /** Whether the unique element has been delivered. */
        private boolean done;

        /**
         * Construct a CliIterator for a command argument.
         *
         * @param      an argument number
         */

        public CliIterator(int an){
            this.an = an;
            this.ln = -1;
            Argument ar = toArgument(this.an,-1);
            if (ar.args.length > 0){
                if ((ar.args[0].attr & AR_ENC) != 0){
                   this.encname = new String[2];
                }
            }
        }

        /**
         * Deliver the filespec string of the next file to be opened.
         * If the argument has a qualifier which is the (possibly localised)
         * predefined encoding qualifier, an array of two strings of the name
         * and the encoding is returned.
         *
         * @return     string of the filespec
         */

        public Object next(){
            if (!this.delivered) hasNext();
            this.delivered = false;
            if (this.element == null){
                throw new NoSuchElementException();
            }
            return this.element;
        }

        /**
         * Tell if there are any elements not yet visited.
         *
         * @return     true if there are
         */

        public boolean hasNext(){
            if (this.delivered){
                return this.element != null;
            }
            if (this.done){
                return false;
            }
            this.delivered = true;
            this.element = Cli.this.strValue(this.an,-1);
            if (Cli.this.status == Cli.ABSENT){
                this.element = null;
                return false;
            } else {
                if (this.encname != null){
                    this.encname[1] = Cli.this.strValue(this.an,0);
                    if (Cli.this.status == Cli.PRESENT){
                        this.encname[0] = (String)(this.element);
                        this.element = this.encname;
                    }
                }
                Argument ar = toArgument(this.an,-1);
                if ((AR_LIST & ar.attr) == 0){  // not a list, only once
                    done = true;
                }
                return true;
            }
        }

        /**
         * Unsupported remove.
         */

        public void remove(){
            throw new UnsupportedOperationException();
        }
    }

    /* Display qualifiers */

    /**
     * Process the default qualifiers, which are mainly the
     * ones that display usage messages.
     */

    private void process_qual(){
        Qualifier q;
        Element   e;
        int       seq;

        if ((FL_C & this.trc) != 0){
            Trc.out.println("process_qual");
        }
        if ((INTER & this.mode) == 0) return;
        if (this.repstream == null) return;
        if ((FL_C & this.trc) != 0){
            trc_eletab();
        }

        int amax = this.dfldes.length;
        int en = toSeq(QU_INDFILE);
        for (int i = 0; i < amax; i++){           // scan qualifiers
            q = (Qualifier)(this.dfldes[i]);
            e = this.elems[en++];
            if (e.ini == -1) continue;
            int idx = idxDefault(i);
            if ((FL_B & this.trc) != 0){
                trc_eletab();
            }
            switch (idx){
            case QU_INDFILE: break;
            case QU_DISPLAY:                       // display values
                qual_display(); break;
            case QU_HELP:
                this.report.f("%%%s;-I-HELP, ")
                    .v(this.cmddes.name).write();
                if (this.cmddes.help == null){
                    this.report.f("%sm%2/").v("SORRYH").write();
                } else  {
                    this.report.f("%s%2/")
                        .v(getLized(this.cmddes.help,null,null))
                        .write();
                }
                break;
            case QU_USAGE:                         // display usage message
                printUsg(this.mode,null);
                break;
            case QU_BRIEF:                         // display brief usage message
                printUsg(USG_BRIEF,null);
                break;
            case QU_VERBOSE:                       // display verbose usage message
                printUsg(USG_VERBOSE,null);
                break;
            case QU_ALL:                           // display usage all message
                printUsg(USG_ALL,null);
                break;
            case QU_VERSION:                       // display version
                this.report.f("%%%s;-I-VERSION, ")
                    .v(this.cmddes.name).write();
                if (this.version == null){
                    this.report.f("%sm%2/").v("SORRYV").write();
                } else  {
                    this.report.f("%s%2/").v(this.version).write();
                }
                break;
            }
        }
    }


    /* Command execution methods */

    /**
     * Load the indirect file whose name is the value of the qualifier
     * passed as argument. It allocates a new descriptor for it and
     * links it into the array of load areas.
     * Then, it parses the arguments contained in it.
     *
     * @param      q qualifier
     * @param      en element number
     * @param      dflt whether it is the default indirect argument
     */

    private void qual_indfile(Qualifier q, int en, boolean dflt){
        ShellStream lpk;

        if (this.nest+1 == MAX_NEST){
            error(ERR_NEST,ARG);
        }
        if ((this.loadArr == null) ||
            (this.loadNr >= this.loadArr.length)){ // extend it
            ensureLoad(this.loadNr + 3);
        }
        lpk = this.loadArr[this.loadNr++];
        if ((FL_C & this.trc) != 0){
            trcpoint("get opfile");
        }
        Element e = this.elems[en];
        lpk.path = (String)(e.obj);
        if ((FL_C & this.trc) != 0){
            Trc.out.println("file: |" + lpk.path + "|");
        }
        if (this.elems[en+1].ini >= 0){
            lpk.enc = (String)(this.elems[en+1].obj);
            if ((FL_C & this.trc) != 0){
                Trc.out.println("enc: |" + lpk.enc + "|");
            }
        }
        lpk.inp = this.inpInd;                  // it propagates filespec to next
        lpk.inter = false;
        getShellInput(lpk,ele.ini,false);
        stop: {
            if (!dflt){                         // not the default one
                e.ini = 0;                      // this to access the user part
                e.argni = -this.loadNr - 1;
                e.argne = e.argni;
                e.end = lpk.length;             // end index
            }
            int  savecur = this.cursor;         // save current
            int  savargn = this.argn;
            int  saveend = this.end;
            char savebuf[] = this.buffer;
            boolean savestr = this.isStr;
            this.cursor = 0;
            this.end = lpk.length;
            this.buffer = lpk.load;
            this.isStr = false;
            this.argn = -this.loadNr - 1;
            if ((FL_B & this.trc) != 0)
                Trc.out.println("entering ind file");
            parse_args();                       // parse now the loaded file
            if ((AR_USER & q.attr) == 0){       // user data not allowed
                if (this.cursor < this.end){
                    error(ERR_UNEXP,ARG);       // unexpected character
                }
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("exiting ind file " +
                    this.cursor);
            }
            if (!dflt){                         // not the default one
                e.ini = this.cursor;            // return index of user part
                e.obj = String.valueOf(lpk.load,
                    e.ini,e.end - e.ini);
            }
            this.cursor = savecur;              // restore it
            this.argn = savargn;
            this.end = saveend;
            this.buffer = savebuf;
            this.isStr = savestr;
        } // stop
        if ((FL_C & this.trc) != 0){
            Trc.out.println("end qual_indfile");
        }
    }

    /**
     * Ensure that the load array is large enough.
     *
     * @param      n desired length
     */

    private void ensureLoad(int n){
        if (n < 0) error(ERR_OUTLIMIT,ARG);
        ShellStream[] cur = this.loadArr;
        int curLen = (this.loadArr == null) ? 0 : cur.length;
        if (curLen < n){
            ShellStream[] p = new ShellStream[n];
            if (cur != null)
                System.arraycopy(cur,0,p,0,curLen);
            this.loadArr = p;
        }
        for (int i = curLen; i < n; i++){      // allocate elements
            this.loadArr[i] = new ShellStream();
        }
    }

    /**
     * Load shell input from a file or interactively.
     *
     * @param      lpk ShellInput object
     * @param      ini current position in command
     * @param      inter <code>true</code> to denote interactive request
     */

    private void getShellInput(ShellStream lpk, int ini, boolean inter){
        lpk.cch = contChar();
        lpk.frsize = 0;                        // default block size
        lpk.sequential = false;                // default read
        lpk.cutcrlf = true;                    // cut last cr lf
        lpk.trc = this.trc;
        lpk.report = this.report;
        lpk.read();                            // load the file
        if ((lpk.res != 0) && !inter){
            this.cursor = ini;
            error(ERR_INDFILE,lpk.exc,lpk.path,ARG);
        }
    }

    /**
     * Print the argument values.
     */

    private void qual_display(){
        if (this.repstream == null) return;
        restart(true);

        if ((FL_V & this.trc) != 0){
            Trc.out.println("qual_display");
        }
        int seq = 1;
        Element e;
        Argument a;
        int amax = this.cmddes.args.length;
        for (int i = 0; i < amax; i++){
            a = this.cmddes.args[i];
            e = this.elems[seq++];
            dis: {
                Argument ar = a;
                if (e.ini < 0){
                    seq += ar.args.length;
                    break dis;
                }
                int qmax = ar.args.length;
                displayArg(a,e,i,-1);
                for (int j = 0; j < qmax; j++){
                    e = this.elems[seq++];
                    if (e.ini < 0) continue;
                    this.report.write("  ");
                    displayArg(ar.args[j],e,i,j);
                }
            }
        }
        this.report.write("%/");
        restart(true);
    }

    /**
     * Print the value of an argument.
     *
     * @param      ar argument
     * @param      e element
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     */

    private void displayArg(Argument ar, Element e, int an, int ln){
        int  type_col  = 10;                    // type column
        int  value_col = 40;                    // value column

        int i = 0;
        for (i = 0; i < arg_types.length; i++){
             if (arg_types[i].code == ar.code) break;
        }
        this.report.f("%s").v(ar.name).write();
        if (this.report.cursor >= type_col) // show truncation
            this.report.f("%t*%e>;...").v(type_col-5).write();
        String key;
        if ((ar.attr & AR_UNS) == 0) key = arg_types[i].name;
        else key = "UN" + arg_types[i].name;
        this.report.f("%t*").v(type_col).write();
        if ((ar.attr & AR_ARR) != 0)
            this.report.f("[]").write();
        this.report.f("%sm").v(key).write();
        if (this.report.cursor >= value_col) // show truncation
            this.report.f("%t*%e>;...").v(value_col-5).write();
        if (ar.code != 'v')
            this.report.f("%t*").v(value_col).write();

        switch (ar.code){
        case 'B': case 'S': case 'I': case 'L':
            String frm = "%";
            String base = "d";
            if ((ar.attr & AR_BIN) != 0) base = "b";
            else if ((ar.attr & AR_OCT) != 0) base = "o";
            else if ((ar.attr & AR_HEX) != 0) base = "x";
            String kind = "i";
            if ((ar.attr & AR_UNS) != 0) kind = "u";
            frm += kind + base;
            this.report.f(frm).v(longValue(an,ln)).write();
            break;
        case 'c':
            this.report.f("%ce").v(charValue(an,ln)).write();
            break;
        case 'b':
            this.report.f("%s").v(boolValue(an,ln)).write();
            break;
        case 'F': case 'D':
            this.report.f("%fg").v(doubleValue(an,ln)).write();
            break;
        case 's':
            this.report.f("%se").v(strValue(an,ln)).write();
            break;
        case 'd':
            this.report.f("%ddD").v(dateValue(an,ln)).write();
            break;
        case 'v':
            break;
        }
        this.report.f("%/").write();
    }

    /**
     * Print an usage message according to the value passed.
     *
     * @param      usg kind of usage message
     * @param      cmd command descriptor
     */

    private void printUsg(int usg, Command cmd){
        if (this.repstream == null) return;
        if (cmd == null) cmd = this.cmddes;
        if ((USG_SEE & usg) != 0){        // assistance message 
            this.report.l("ASSIST")
                .v(cmd.name)
                .v(qualIndicator())
                .v(this.dfldes[idxDefault(QU_USAGE)].name).writeln();
        } else if (((USG_BRIEF |          // brief usage message
            USG_REMIND) & usg) != 0){     // reminder usage message
            printUsageBrief(usg,cmd);
        } else if (((USG_VERBOSE |        // verbose usage message
            USG_ALL) & usg) != 0){        // all usage messages
            printUsageVerbose(usg,cmd);
        }
    }

    /**
     * Deliver the qualifier indicator.
     *
     * @return     string of the indicator
     */

    private String qualIndicator(){
       if ((QUALSL & this.mode) != 0){
           return "/";
       } else if ((QUALNVP & this.mode) != 0){
           return "";
       } else {
           return "--";
       }
    }

    /**
     * Deliver the qualifier short indicator for a qualifier.
     *
     * @param      q Qualifier
     * @return     string of the indicator
     */

    private String qualShortIndicator(Qualifier q){
       if ((QUALSL & this.mode) != 0){
           return "/";
       } else if ((QUALNVP & this.mode) != 0){
           return "";
       } else {
           if ((AR_PLUS & q.attr) != 0) return "+";
           return "-";
       }
    }

    /**
     * Print a usage message for the current command according to the
     * value passed.
     *
     * @param      usg kind of usage message
     */

    public void printUsage(int usg){
        Command cm;
        if (this.repstream == null) return;
        printUsage(usg,null,true);
    }

    /**
     * Print a usage message according to the value passed.
     * The last printed command becomes the current one.
     *
     * @param      usg kind of usage message
     * @param      cmd command descriptor (see <code>parse()</code>)
     */

    public void printUsage(int usg, Object cmd){
        printUsage(usg,cmd,false);
    }

    /**
     * Print a usage message according to the value passed.
     *
     * @param      usg kind of usage message
     * @param      cmd command descriptor (see <code>parse()</code>)
     * @param      cur whether the command is the current one
     */

    private void printUsage(int usg, Object cmd, boolean cur){
        Command cm;
        excInit();
        if ((FL_B & this.trc) != 0){
            Trc.out.println("printUsage " + this.locMsg);
        }
        try {
            if (this.repstream == null) return;
            if (cur) updateLocale(this.cmdKey);    // current: update only
            else get_cmd_def(cmd);                 // recalculate definition
            usg &= ~(USG_SEE);
            if (this.cmdSet != null){
                int rem = usg & (USG_REMIND | USG_ALL);  // do not repeat
                usg &= ~(USG_REMIND | USG_ALL);          // .. the header
                usg |= USG_NOTAIL;
                for (int i = 0; i < this.cmdSet.length; i++){
                    int j;
                    for (j = 0; j < this.cmdSet.length; j++){  // order them
                        if (this.cmdSet[j].code == (char)i) break;
                    }
                    if (i == this.cmdSet.length-1) usg |= rem;
                    printUsg(usg,this.cmdSet[j]);
                    usg |= USG_NOHEAD;
                }
                this.report.write("%/N");
            } else if (this.cmddes != null){
                printUsg(usg,null);
            }
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
    }

    /* Flag to disable usage header. */
    private static final int USG_NOHEAD = 1<<31;

    /* Flag to disable usage tail. */
    private static final int USG_NOTAIL = 1<<30;

    /**
     * Print a brief description of the command syntax:
     * <ul>
     * <li>command name
     * <li>qualifiers, indicated by their short name and, for the ones
     *    which have a value, their mnemonics 
     * <li>parameters, indicated by their mnemonics
     * </ul>
     * Alternative qualifiers are separated by `<code>|</code>'.
     *
     * @param      usg kind of message
     * @param      cmd command descriptor
     */

    private void printUsageBrief(int usg, Command cmd){
        if (this.repstream == null) return;
        if ((USG_NOHEAD & usg) == 0){
            this.report.f("%sm %miw").v("USAGE")   // emit the Usage header
                .write();                          // .. and set wrap indent mode
        }
        this.report.f("%s%@ ").v(cmd.name).write();
        Argument a;
        String opn, clo;
        int amax = cmd.args.length;
        for (int i = 0; i < amax; i++){
            a = cmd.args[i];
            if ((AR_REQ & a.attr) == 0){
                this.report.f("%mbd;[").write();
            }
            opn = clo = "";
            if ((AR_ALT & a.attr) != 0){
                if ((i > 0) &&
                    ((AR_ALT & cmd.args[i-1].attr) != 0)){
                    opn = "| ";
                }
                if ((i < amax-1) &&
                    ((AR_ALT & cmd.args[i+1].attr) != 0)){
                    clo = "";
                }
            }
            printBriefArg(opn,a,clo,null);
            Argument ar = a;
            Qualifier q;
            int qmax = ar.args.length;
            if (qmax != 0) this.report.f("%mbi").write();
            for (int j = 0; j < qmax; j++){
                q = (Qualifier)(ar.args[j]);
                opn = clo = "";
                if ((AR_REQ & q.attr) == 0){
                    opn = "["; clo = "]";
                    this.report.f("%mbd").write();
                }
                if ((AR_ALT & q.attr) != 0){
                    if ((j > 0) &&
                        ((AR_ALT & ar.args[j-1].attr) != 0)){
                        opn = "| ";
                    }
                    if ((j < qmax-1) &&
                        ((AR_ALT & ar.args[j+1].attr) != 0)){
                        clo = "";
                    }
                }
                printBriefArg(opn,q,clo,ar);
                this.report.f("%mbi").write();
            }
            if ((AR_REQ & a.attr) == 0){
               this.report.f("%@;]%mbi%@ ").write();
            }
        }
        int msk = this.status >> DFLT_OFF;
        amax = this.dfldes.length;
        for (int i = 0; i < amax; i++){
            int m = msk;
            msk >>= 1;
            if ((m & 1) != 0) continue;
            a = this.dfldes[i];
            this.report.f("%mbd;[").write();
            printBriefArg("",a,"",null);
            Argument ar = a;
            Qualifier q;
            int qmax = ar.args.length;
            if (qmax != 0) this.report.f("%mbi").write();
            for (int j = 0; j < qmax; j++){
                q = (Qualifier)(ar.args[j]);
                opn = clo = "";
                if ((AR_REQ & q.attr) == 0){
                    opn = "["; clo = "]";
                    this.report.f("%mbd").write();
                }
                printBriefArg(opn,q,clo,null);
                this.report.f("%mbi").write();
            }
            this.report.f("%@;]%mbi%@ ").write();
        }

        this.report.write("%/");
        if (((USG_REMIND & usg) != 0) &&              // remainder message
            ((NODEFLT & this.mode) == 0)){
            this.report.l("BRIEFREM")
                .v(qualIndicator())
                .v(this.dfldes[idxDefault(QU_USAGE)].name).write();
            this.report.write("%/");
        }
        if ((USG_NOTAIL & usg) == 0){
            this.report.write("%mw-;%@;%/");
        }
    }

    /**
     * Deliver the localised definition of a default argument.
     * If there are no localised definition active, then it returns
     * <code>null</code>.
     *
     * @param      a Argument
     * @param      localised definition
     */

    /* It searches the argument in the CliBundle so as to locate the
     * corresponding localised one. The search is tailored to the current
     * default arguments.
     */

    private Argument argDefaultLoc(Argument a){
        if ((FL_C & this.trc) != 0){
            Trc.out.println("argDefaultLoc " + a.name);
        }
        Argument aloc = null;
        doit: if (this.dfldesLoc != null){
            int amax = this.dfldes.length;
            for (int i = 0; i < amax; i++){
                Argument ar = this.dfldes[i];
                if (a == ar){
                    aloc = this.dfldesLoc[i];
                    break doit;
                }
                int qmax = ar.args.length;
                for (int j = 0; j < qmax; j++){
                    Argument q = ar.args[j];
                    if (a == q){
                        aloc = this.dfldesLoc[i].args[j];
                        break doit;
                    }
                }
            }
        }
        if ((FL_C & this.trc) != 0){
            Trc.out.println("argDefaultLoc " +
                (aloc == null ? "" : aloc.name));
        }
        if (aloc == null) aloc = a;
        return aloc;
    }

    /**
     * Print an argument in the brief format.
     *
     * @param      opn opening string
     * @param      ar Argument
     * @param      clo closing string
     * @param      fat enclosing Argument
     */

    private void printBriefArg(String opn, Argument ar, String clo,
        Argument fat){
        String qldel;
        String vsep;

        if ((FL_B & this.trc) != 0){
            Trc.out.println("printBriefArg " + ar.name);
        }
        String ar_mnem = null;
        if (ar.mnem.getClass().isArray() &&
            (((String[])(ar.mnem))[1] == null)){
            Argument dflt = argDefaultLoc(ar);
            ar_mnem = ((String[])(dflt.mnem))[0];
        } else {
            ar_mnem = getMnem(ar,fat);
        }
        if ((QVALEQ & this.mode) != 0){            // determine value separator
            vsep = "=";
        } else if ((QVALCO & this.mode) != 0){
            vsep = ":";
        } else {
            vsep = " ";
        }
        qldel = qualIndicator();
        if ((AR_PAR & ar.attr) != 0){           // parameter
            this.report.f("%2s").v(opn).v(ar_mnem).write();
        } else {                                // qualifier
            Qualifier q = (Qualifier)ar;
            if (q.sname == ' '){                // long name only
                if (q.name.charAt(0) == '@'){
                   qldel = "";
                   vsep = "";
                }
                this.report.f("%s%2sn").v(opn).v(qldel)
                    .v(q.name).write();
            } else {
                this.report.f("%s%2sn").v(opn)
                    .v(qualShortIndicator(q))
                    .v(q.sname).write();
            }
            if (ar.type != void.class){         // value
                this.report.f("%2s").v(vsep)
                    .v(ar_mnem).write();
            }
        }
        this.report.f("%s%@ ").v(clo).write();  // insert a pending space
    }

    /**
     * Delives the mnemonic string of an argument, localizing it if
     * necessary and appending the list indication if the argument allows
     * a list of values.
     *
     * @param      ar Argument
     * @param      fat enclosing Argument
     * @return     string
     */

    private String getMnem(Argument ar, Argument fat){
        String mn = null;
        boolean mund = false;
        ResourceBundle bun;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("getMnem " + ar.name);
        }

        mn: if (ar.type != void.class){
            if (ar.type == boolean.class){ // boolean
                if (ar.mnem == null){      // mnemonic not present
                    mn = "YESNO";
                    mund = true;
                    break mn;
                }
            } else {
                if (ar.mnem == null){      // mnemonic not present
                    mn = "BOH";
                    mund = true;
                    break mn;
                }
            }
        } else {
            return null;
        }
        if (mund){
            bun = this.report.getBundle(0);
            mn = bun.getString(mn);
        } else {
            mn = getLized(ar.mnem,fat,null);
        }
        if ((AR_LIST & ar.attr) != 0){
            if ((AR_PAR & ar.attr) != 0){           // parameter
                if ((DCLLSEP & this.mode) != 0){    // DCL list
                    mn += ", ...";
                } else {
                    mn += " ...";
                }
            } else {                                // qualifier
                if ((DCLLSEP & this.mode) != 0){    // DCL list
                    mn = "(" + mn + ", ...)";
                } else {
                    mn += ":...";
                }
            }
        }
        return mn;
    }

    /**
     * Get a string from a user or a predefined bundle.
     *
     * @param      s key
     * @param      up1 first ancestor to get bundle
     * @param      up2 second ancestor to get bundle
     */

    private String getLized(Object mn, Argument up1, Argument up2){
        String s = null;
        String bun = "";
        boolean i18 = false;
        if (mn.getClass().isArray()){
            i18 = true;
            bun = ((String[])mn)[1];             // bundle
            s = ((String[])mn)[0];               // key
        } else {
            s = (String)mn;
            if ((up1 != null) &&
                up1.mnem.getClass().isArray()){
                i18 = true;
                bun = ((String[])(up1.mnem))[1];
            } else if ((up2 != null) &&
                up2.mnem.getClass().isArray()){
                i18 = true;
                bun = ((String[])(up2.mnem))[1];
            }
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("getLized " + s + " " + bun + " " + i18);
        }
        String str = null;
        if ((s == null) || (s.length() == 0)){
            return "";
        }
        if (this.locMsg){
            try {
                if (i18){
                    ResourceBundle res = ResourceBundle.getBundle
                        (bun,this.locale);
                    str = res.getString(s);
                } else {
                    str = this.resource.getString(s);
                }
            } catch (MissingResourceException exc){
                error(ERR_RESOURCE,exc,s);
            }
        } else {
            str = s;
        }
        return str;
    }

    /**
     * Print a verbose description of the command syntax:
     * <p><blockquote><pre>
     *    - command name and description (if present)
     *                            | 2             20          40 
     *    - qualifiers:
     *        without short name:   [--name mnem]             description
     *        with short name:      [-x mnem]     or --name   description
     *    - parameters:
     *        mandatory:            mnem                      description
     *        optional:             [mnem]                    description
     * </pre></blockquote><p>
     * If a fiels overflows into the next column, it is truncated and
     * ellipses are inserted.
     * Optional arguments are surrounded by [].
     * Alternative qualifiers are separated by (the localized version of)
     * "<code>-or-</code>".
     *
     * @param      usg kind of message
     * @param      cmd command descriptor
     */

    private void printUsageVerbose(int usg, Command cmd){
        if (this.repstream == null) return;
        if ((USG_NOHEAD & usg) == 0){
            this.report.f("%sm%? %:%/").v("USAGE")    // emit the Usage header
                   .v((USG_NOTAIL & usg) == 0).write();
        }
        this.report.f("%s").v(cmd.name).write();
        if ((cmd.desc != null) && (cmd.desc.length() > 0)){
            this.report.f(" - %s")                    // description of command
                .v(getLized(cmd.desc,null,null)).write();
        }
        this.report.write("%/%t=2");
        Argument a;
        int amax = cmd.args.length;
        for (int i = 0; i < amax; i++){
            a = cmd.args[i];
            if ((FL_B & this.trc) != 0){
                Trc.out.println("print: |" + a.name + "|" + this.locMsg);
            }
            if ((AR_ALT & a.attr) != 0){
                if ((i > 0) &&
                    ((AR_ALT & cmd.args[i-1].attr) != 0)){
                    this.report.f("%t>;  -%sm;-%/").v("OR").write();
                }
            }
            String op = "";
            String cl = "";
            if ((AR_REQ & a.attr) == 0){
                op = "[";
            }
            Argument ar = a;
            int qmax = ar.args.length;

            if ((AR_REQ & a.attr) == 0){
                if (qmax == 0) cl = "]";
            }
            printVerbArg(op,a,cl,null);
            for (int j = 0; j < qmax; j++){
                if ((AR_ALT & ar.args[j].attr) != 0){
                    if ((j > 0) &&
                        ((AR_ALT & ar.args[j-1].attr) != 0)){
                        this.report.f("%t>;%x4;-%sm;-%/").v("OR").write();
                    }
                }
                String opn = "";
                String clo = "";
                if ((AR_REQ & ar.args[j].attr) == 0){
                    opn = "["; clo = "]";
                }
                if ((AR_REQ & a.attr) == 0){
                    if (j == qmax-1) cl = "]";
                }
                printVerbArg("  "+opn,ar.args[j],clo+cl,ar);
            }
        }
        int msk = this.status >> DFLT_OFF;
        amax = this.dfldes.length;
        for (int i = 0; i < amax; i++){
            int m = msk;
            msk >>= 1;
            if ((m & 1) != 0) continue;
            a = this.dfldes[i];
            String op = "";
            String cl = "";
            if ((AR_REQ & a.attr) == 0){
                op = "[";
            }
            Argument ar = a;
            int qmax = ar.args.length;
            if ((AR_REQ & a.attr) == 0){
                if (qmax == 0) cl = "]";
            }
            printVerbArg(op,a,cl,null);
            for (int j = 0; j < qmax; j++){
                String opn = "";
                String clo = "";
                if ((AR_REQ & ar.args[j].attr) == 0){
                    opn = "["; clo = "]";
                }
                if ((AR_REQ & a.attr) == 0){
                    if (j == qmax-1) cl = "]";
                }
                printVerbArg("  "+opn,ar.args[j],clo+cl,null);
            }

        }
        if (((USG_ALL & usg) != 0) &&             // add all reminder messages
            ((NODEFLT & this.mode) == 0)){
            int    i;
            String s = "";
            String qldel = qualIndicator();
            this.report.write("%/");
            for (i = idxDefault(QU_DISPLAY);
                i <= idxDefault(QU_VERSION); i++){
                switch (idxDefault(i)){
                case QU_DISPLAY: s = "QU_DISPLAY"; break;
                case QU_USAGE:   s = "QU_USAGE"; break;
                case QU_BRIEF:   s = "QU_BRIEF"; break;
                case QU_VERBOSE: s = "QU_VERBOSE"; break;
                case QU_ALL:     s = "QU_ALL"; break;
                case QU_HELP:    s = "QU_HELP"; break;
                case QU_VERSION: s = "QU_VERSION"; break;
                }
                this.report.l("USGALL")
                    .v(qldel).v(this.dfldes[i].name).v(s).writeln();
            }
        }
        if ((USG_NOTAIL & usg) == 0){
            this.report.write("%mw-;%@;%/");
        }
    }

    /**
     * Print an argument in the verbose format.
     *
     * @param      op string which is printed before the argumnent
     * @param      ar Argument
     * @param      cl string which is printed after the argumnent
     * @param      fat enclosing Argument
     */

    private void printVerbArg(String op, Argument ar, String cl, Argument fat){
        String    qldel;
        String    opn, clo;
        String    vopn, vclo;
        int       comm_col = 40;                    // comment column
        int       name_col = 20;                    // (long) name column
  
        qldel = qualIndicator();
        this.report.write("%t>");
        opn = clo = "";

        String ar_mnem = null;
        String dsc = null;
        if (ar.mnem.getClass().isArray() &&
            (((String[])(ar.mnem))[1] == null)){
            Argument dflt = argDefaultLoc(ar);
            ar_mnem = ((String[])(dflt.mnem))[0];
            dsc = dflt.desc;
        } else {
            ar_mnem = getMnem(ar,fat);
            dsc = getLized(ar.desc,ar,fat);
        }
        if ((AR_VALREQ & ar.attr) == 0){        // determine value separator
            vclo = "]";
            if ((QVALEQ & this.mode) != 0) vopn = "[=";
            else if ((QVALCO & this.mode) != 0) vopn = "[:";
            else vopn = " [";
        } else {
            vclo = "";
            if ((QVALEQ & this.mode) != 0) vopn = "=";
            else if ((QVALCO & this.mode) != 0) vopn = ":";
            else vopn = " ";
        }
        if ((AR_PAR & ar.attr) != 0){           // parameter
            this.report.f("%2s").v(op)
                .v(ar_mnem).write();
            if (this.report.cursor >= comm_col) // show truncation
                this.report.f("%t*%e>;...").v(comm_col-5).write();
            this.report.f("%s").v(cl).write();
        } else {                                // qualifier
            Qualifier q = (Qualifier)ar;
            if (q.sname == ' '){                // long name only
                if (q.name.charAt(0) == '@'){
                    qldel = "";
                    vopn = "";
                }
                this.report.f("%4s").v(op).v(opn)
                    .v(qldel).v(ar.name).write();
                if (ar.type != void.class){
                    this.report.f("%3s").v(vopn)
                        .v(ar_mnem).v(vclo).write();
                }
                this.report.f("%s").v(cl).write();
                if (this.report.cursor >= comm_col)   // show truncation
                    this.report.f("%t*%e>;...")
                        .v(comm_col-4).write();
                this.report.f("%s").v(clo).write();
            } else {                                  // short name present
                this.report.f("%3s%c").v(op).v(opn)
                    .v(qualShortIndicator(q))
                    .v(q.sname).write();
                if (ar.type != void.class){
                    this.report.f("%3s").v(vopn)
                        .v(ar_mnem).v(vclo).write();
                }
                this.report.f("%s").v(cl).write();
                if (this.report.cursor >= name_col){  // show truncation
                    this.report.f("%t*%e>;...")
                        .v(name_col-5).write();
                }
                this.report.f("%s%t*%e>;%sm %2s")
                    .v(clo).v(name_col)
                    .v("OR").v(qldel).v(ar.name).write();
                if (this.report.cursor >= comm_col){  // show truncation
                    this.report.f("%t*%e>;...")
                    .v(comm_col-4).write();
                }
            }
        }
        if (ar.desc != null){
            this.report.f("%t*%s")              // description of argument
                .v(comm_col).v(dsc).write();
        }
        this.report.write("%/");
    }

    /* Command input methods */

    /**
     * Set the format of prompt. By default it is: <code>%s;>%/p</code>.
     *
     * @param      f format (as defined in Formatter)
     */

    public void setPromptForm(String f){
        this.promptForm = f;
    }

    /**
     * Get the command that activated the current program, and parses its
     * arguments.
     * If the Cli object is not initialized, it initializes it with the
     * default values.
     * If there are inline arguments, it parses them. If the actual name has
     * to be replaced, it allocates a copy of the argument vector and sets
     * in it the replacement verb.
     * If some required arguments are missing, it prompts and reads them
     * from the standard input.
     * When a global qualifier is missing, it is prompted, when a local one
     * is missing, the whole parameter is prompted.
     * Only the missing parameters are reparsed. A missing parameter which is
     * a list in Unix syntax need be terminated by a command qualifier or by
     * the end of the command. If it is followed by a missing parameter,
     * then the former is prompted so as to allow to supply additional
     * elements, and mainly to terminate it with a command qualifier.
     * This allows to have eventually a command in which the list parameter
     * is properly terminated. This is not needed when such a parameter is
     * followed by a missing required qualifier.
     * To allow it, a non-terminated list parameter is reparsed starting with
     * its first element.
     * When the parameters are read from the standard input, there is no shell
     * that intervenes to break them as it does with the inline ones. In order
     * to treat them as the inline ones, the lines read are broken by using
     * the same rules as the current shell, and its quotation and escaping
     * rules are used, but nothing else (e.g. no shell parameter substitution).
     * This to make the introduction of parameters as similar as possible to
     * that of the inline parameters, which have been just introduced.
     * It prints an error message if the command is not correct.
     *
     * @param      args segments
     * @param      cmd reference to the command descriptor
     * @param      mode preferences
     * @param      ver version, set if not empty
     */

    /*
     * It would be quite complex to keep the lines unbroken because that leads
     * to have some argvs which need be intepreted in a way and some in another
     * one.
     * If there are inline arguments, then there is a need to parse them
     * to discover if some required ones are missing so as to request them.
     * If there are no inline arguments, there is a need to determine if
     * the command has any required argument so as to prompt it.
     * If all arguments are optional, the command is executed.
     * If a local qualifier is missing, the whole parameter is prompted
     * because it is too difficult to parse only a part of a parameter.
     */

    public void getCommand(Object cmd, String[] args, int mode, String ver){
        int len;

        excInit();
        try {
            if ((FL_C & this.trc) != 0){
                Trc.out.println("getCommand: start");
                for (int i = 0; i < args.length; i++){
                    Trc.out.println("arg: " + i + " |" + args[i] + "|");
                }
            }
            if (this.pass == 0){                     // not initialized
                init(mode);
            }
            if ((ver != null) && (ver.length() > 0)){
                setVersion(ver);
            }
            this.cmddes = null;
            this.cmdSet = null;
            get_cmd_def(cmd);                    // obtain command def.
            if (this.cmdSet != null){            // set of commands
                error(ERR_INVDEF,new ClassCastException());
            }

            this.argc = args.length+1;
            ensureArgs(this.argc);
            this.args[0] = this.cmddes.name;         // insert intrinsic name
            System.arraycopy(args,0,this.args,1,args.length);
            if ((FL_C & this.trc) != 0){
                Trc.out.println("getCommand: " + this.cmddes.name);
                trc_cmdarg();
            }

            this.argv = null;
            ini_cmdref();                            // init indexes of command
            start(this.cmddes);                      // initialize parsing
            this.inpInd.restart(false);              // init file defaults for
                                                     // .. the command line
            Element e = this.elems[0];               // store the verb
            e.clear();
            e.end = this.cmddes.name.length();
            e.obj = this.cmddes.name;

            boolean readarg = true;
            int restartargn = 1;                     // start with first argv
            if (this.argc > 1){
                readarg = false;                     // inline arguments
            } else if ((STDIN & this.mode) == 0){    // prompt first required
                int amax = this.cmddes.args.length;  // determine if there is one required
                for (int i = 0; i < amax; i++){
                    Argument a = this.cmddes.args[i];
                    if ((AR_REQ & a.attr) != 0){
                        break;
                    }
                }
                readarg = false;
            }
            if ((FL_C & this.trc) != 0){
                Trc.out.println("getCommand readarg: " + readarg +
                    " " + ((this.mode & INTER) != 0));
            }
            ShellStream lpk = null;
            if (readarg){                                // request args
                lpk = new ShellStream();
                lpk.prompt = this.cmddes.name;           // prompt
            }
            load: do {
                if (readarg){                            // request args
                    lpk.path = this.stin;                // standard input
                    lpk.inter = (this.mode & INTER) != 0;  // interactive mode
                    lpk.pform = this.promptForm;         // prompt format
                    if (lpk.pform == null){
                        lpk.pform = "%s;>%/p";           // prompt format
                    }
                    lpk.noextra = true;
                    lpk.inp = this.inpInd;
                    reposition(restartargn,0);           // for error reporting
                    getShellInput(lpk,this.cursor,true);
                    if ((lpk.eof) && (lpk.length == 0)){ // no input
                        throw this.excObj;
                    }
                    argvize(lpk.load,lpk.length,Prg.os); // add the new segments
                }
                if ((FL_C & this.trc) != 0)
                    trc_cmdarg();
                try {
                    reposition(restartargn,0);
                    this.res = 0;
                    this.excObj = null;
                    parse_args();                        // parse arguments
                    if (this.res == NULL_COMMAND)        // default qual.
                        break load;
                    restartElems(true);                  // check elements
                } catch (CliError exc){
                }
                restartargn = this.argn;                 // next position
                if ((FL_C & this.trc) != 0){
                    Trc.out.println("end parse " + this.res +
                        " " + restartargn + " " + this.curpar);
                }
                if ((this.res == ERR_MISPAR) &&          // some required parameter missing
                    ((this.mode & INTER) != 0)){
                    if (lpk == null) lpk = new ShellStream();
                    lpk.prompt = this.cmddes.args[this.excObj.an].name;
                    ulist:
                    if ((DCLLSEP & this.mode) == 0){     // Unix list
                        if (this.curpar < 0){            // no parameters at all
                            break ulist;
                        }
                        int seq = toSeq(this.curpar);    // last parameter parsed
                        Argument mp =
                            this.cmddes.args[this.curpar];
                        if ((AR_LIST & mp.attr) == 0){   // not a list parameter
                            break ulist;
                        }
                        e = this.elems[seq];
                        if (e.argne != this.argn-1){     // already terminated
                            break ulist;                 // .. by a qualifier
                        }
                        int ln;
                        ln = this.args[e.argne].length();
                        if (e.end == ln){
                            lpk.prompt = this.cmddes.args
                                [this.curpar].name;
                            this.curpar--;
                            restartargn = e.argni;
                        }
                    }
                    if ((FL_C & this.trc) != 0){
                        Trc.out.println("prompt: " + lpk.prompt +
                            " " + restartargn);
                    }
                    readarg = true;
                    continue;
                } else if ((this.res == ERR_MISQUAL) &&   // some required qual missing
                    ((this.mode & INTER) != 0)){
                    if (lpk == null) lpk = new ShellStream();
                    lpk.prompt = this.cmddes.args[this.excObj.an].name;
                    if ((FL_C & this.trc) != 0){
                        Trc.out.println("missing: " + this.curpar + " " +
                            this.excObj.an + " " + this.excObj.ln);
                        trc_eletab();
                    }
                    if (this.excObj.ln >= 0){             // local
                        int seq = toSeq(this.curpar);
                        e = this.elems[seq];
                        restartargn = e.argni;
                        this.argc = e.argni;
                        this.curpar--;
                    }
                    readarg = true;
                    continue;
                }
                if (this.res > 0) throw this.excObj;
                break;
            } while (true);
            this.pass = 2;                    // end of syntax check pass
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (FormatterError exc){
            registerError(ERR_IOERR,exc);
        } catch (CliError exc){
        } finally {
            if ((FL_C & this.trc) != 0){
                Trc.out.println("getCommand: " + message(this.res));
                if (this.res > 0){
                    Trc.out.println(this.excObj);
                    Trc.out.println("at: " + this.cursor);
                }
            }
            excTerm();
        }
    }

    /**
     * Ensure that the argument char[][] vector is long enough.
     *
     * @param      n desired length
     */

    private void ensureArgv(int n){
        if ((FL_M & this.trc) != 0){
            Trc.out.println("ensure: " + n);
        }
        if (n < 0) error(ERR_OUTLIMIT);
        if (n >= Integer.MAX_VALUE-2){
            error(ERR_OUTLIMIT);
        }
        char[][] cur = this.argv;
        int curLen = (cur == null) ? 0 : cur.length;
        if (curLen < n){
            char[][] p = new char[n][];
            if (cur != null)
                System.arraycopy(cur,0,p,0,curLen);
            this.argv = p;
        }
    }

    /**
     * Ensure that the argument String[] vector is long enough.
     *
     * @param      n desired length
     */

    private void ensureArgs(int n){
        if ((FL_M & this.trc) != 0){
            Trc.out.println("ensure: " + n);
        }
        if (n < 0) error(ERR_OUTLIMIT);
        if (n >= Integer.MAX_VALUE-2){
            error(ERR_OUTLIMIT);
        }
        String[] cur = this.args;
        int curLen = (cur == null) ? 0 : cur.length;
        if (curLen < n){
            String[] p = new String[n];
            if (cur != null)
                System.arraycopy(cur,0,p,0,curLen);
            this.args = p;
        }
    }

    /**
     * The fully qualified name of the class of the program.
     */
    private String mainClass;

    /**
     * The name of the program.
     */
    private String mainName;

    /**
     * The file (actual name) of the program.
     */
    private String mainFile;

    /**
     * The version of the program.
     */
    private String mainVersion;

    /**
     * Determine the class of the main program.
     */

    private void getMainData(){
        if (this.mainClass != null) return;
        this.mainClass = Prg.getMainClass();
        if (this.mainClass == null) error(ERR_INIT);
        this.mainName = Prg.getMainName(this.mainClass);
        this.mainVersion = Prg.getMainVersion(this.mainClass);
        if ((FL_E & this.trc) != 0){
            Trc.out.println("getMainData: " + this.mainClass +
                " " + this.mainName + " " + this.mainVersion);
        }
        if (this.mainVersion == null) error(ERR_INIT);
        this.mainFile = Prg.getMainFile(this.mainClass);
        if ((FL_E & this.trc) != 0){
            Trc.out.println("mainFile: " + this.mainFile);
        }
    }

    /**
     * Determine the class of the main program. It handles the
     * errors.
     */

    private void mainData(){
        excInit();
        try {
            getMainData();
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
    }

    /**
     * Deliver the class of the main program.
     *
     * @return     class
     */

    public String getMainClass(){
        mainData();
        return this.mainClass;
    }

    /**
     * Deliver the name of the main program.
     *
     * @return     name
     */

    public String getMainName(){
        mainData();
        return this.mainName;
    }

    /**
     * Deliver the file of the main program.
     *
     * @return     file
     */

    public String getMainFile(){
        mainData();
        return this.mainFile;
    }

    /**
     * Deliver the version of the main program.
     *
     * @return     version
     */

    public String getMainVersion(){
        mainData();
        return this.mainVersion;
    }

    /**
     * Deliver the version registered in the Cli object.
     *
     * @return     version
     */

    public String getVersion(){
        if (this.version == null){
            return getMainVersion();
        } else {
            return this.version;
        }
    }

    /**
     * Set the version in the Cli object.
     *
     * @param      ver version
     */

    public void setVersion(String ver){
        this.version = ver;
    }

    /**
     * Break a line into argvs according to the rules of the configured
     * shell. It leaves the argvs into the argv vector, possibly extending
     * it.
     *
     * @param      buf line to be broken
     * @param      len its length
     * @param      os kind of shell
     */

    private void argvize(char[] buf, int len, int os){
        int j, k;
        char[] arg = new char[len];
        int p = 0;

        int na = this.argc + (len/5);            // average argument
        if (this.argv != null){                  // preallocate
            ensureArgv(na);
        } else {
            ensureArgs(na);
        }
        int off = 0;
        boolean outer = true;
        int i = 0;
        loop: for (; i < len; i++){
            char ch = buf[i];
            switch (ch){
            case ' ': case '\t':                 // end of argumemt
                if (outer){
                    if ((FL_C & this.trc) != 0){
                        Trc.out.println("|" +
                            String.valueOf(buf,off,i-off) + "|");
                    }
                    off = i+1;
                    if (this.argv != null){      // store it
                        ensureArgv(++this.argc);
                        char[] s = new char[p];
                        this.argv[this.argc-1] = s;
                        System.arraycopy(arg,0,s,0,p);
                    } else {
                        ensureArgs(++this.argc);
                        this.args[this.argc-1] =
                            String.valueOf(arg,0,p);
                    }
                    p = 0;
                    continue;
                }
                break;
            case '\\':                              // escape
                bslash:
                if (os == Prg.UNIX){
                    if (i < len-1){
                        ch = buf[i + 1];
                    } else {
                        continue;
                    }
                    if (outer){
                        i++;
                    } else {
                        switch (ch){
                        case '\\': case '`': case '\"': case '$':
                           i++;
                        }
                    }
                    break;
                } else if (os == Prg.WIN){          // \\\"" sequences
                    for (j = i; j < len; j++){
                        if (buf[j] == '\\') continue;
                        if (buf[j] == '\"'){
                            for (k = i; k <= j; k++){
                                if (buf[k] == '\\'){
                                    k++;
                                    arg[p++] = buf[k];
                                } else if (buf[k] == '\"'){
                                    i = k;
                                    break bslash;
                                }
                            }
                            i = j;
                        } else {
                            for (k = i; k < j; k++){
                                arg[p++] = buf[k];
                            }
                            i = j-1;
                        }
                        continue loop;
                    }
                    break;
                } else {
                    arg[p++] = ch;
                    continue;
                }
            case '\"':                               // quote
                emp:
                if ((p == 0) && outer){              // "" as single argv
                    if (i >= len-1) break emp;
                    if (buf[i+1] != '\"') break emp;
                    if (i+1 < len-1){
                        if ((buf[i+2] != ' ') &&
                            (buf[i+2] != '\t')){
                            break emp;
                        }
                    }
                    i++;
                    continue;
                }
                if (os == Prg.UNIX){
                    outer = !outer;
                } else if (os == Prg.WIN){           // count the "
                    for (j = i+1; j < len; j++){
                        if (buf[j] != '\"') break;
                    }
                    for (k = 0; k < (j-i)/3; k++){
                        arg[p++] = '\"';
                    }
                    if (((j-1) % 3) == 1) outer = !outer;
                    i = j-1;
                } else {                             // recognize ""
                    if (!outer){
                        if (i < len-1){
                            if (buf[i+1] == '\"'){
                                arg[p++] = ch;
                                i++;                 // "" -> "
                                continue;
                            }
                        }
                    }
                    outer = !outer;
                }
                continue;
            case '^':
                if (os == Prg.WIN) continue;
            }
            if (outer){
                if ((TOUPPER & this.mode) != 0){         // convert to upper
                    if (ch < 128) ch = Str.UPPER[ch];
                    else ch = Character.toUpperCase(ch);
                } else if ((TOLOWER & this.mode) != 0){  // convert to lower
                    if (ch < 128) ch = Str.LOWER[ch];
                    else ch = Character.toLowerCase(ch);
                }
            }
            arg[p++] = ch;
        }
        if (i > off){
            if ((FL_C & this.trc) != 0){
                Trc.out.println("|" + String.valueOf(buf,off,i-off) + "|");
            }
            if (this.argv != null){
                ensureArgv(++this.argc);
                char[] s = new char[p];
                this.argv[this.argc-1] = s;
                System.arraycopy(arg,0,s,0,p);
            } else {
                ensureArgs(++this.argc);
                this.args[this.argc-1] =
                    String.valueOf(arg,0,p);
            }
        }
    }

    /**
     * Break a string into args and then delivers a vector of arguments.
     *
     * @param      s string to be broken
     * @param      len its length
     * @param      rs true if a String[] is to be returned, otherwise a
     *             char[][] is returned.
     * @param      os kind of shell
     */

    public Object argvBreak(Object s, int len, boolean rs, int os){
        if (rs){
            setCmdLine(new String[0]);
        } else {
            setCmdLine(new char[0][]);
        }
        if (s.getClass() == String.class){
            String st = (String)s;
            int l = st.length();
            if (len < l) l = len;
            this.argvize(st.toCharArray(),l,os);
        } else {
            char[] ca = (char[])s;
            int l = ca.length;
            if (len < l) l = len;
            this.argvize(ca,l,os);
        }
        if (rs){
            String[] vec = new String[this.argc];
            System.arraycopy(this.args,0,vec,0,this.argc);
            return vec;
        } else {
            char[][] vec = new char[this.argc][];
            System.arraycopy(this.argv,0,vec,0,this.argc);
            return vec;
        }
    }

    /**
     * Deliver a fully qualified argument name, with the command,
     * parameter and local qualifier parts.
     *
     * @param      an argument number
     * @param      ln local qualifier number, -1 if none
     * @return     name
     */

    String toArgString(int an, int ln){
        String com = "";
        String cs = "";
        if (this.cmdSet != null){        // command name also
            com = this.cmddes.name;
            cs = "";
        }
        String ans;
        ans = toArgument(an,ln).name;
        String lns = "";
        String ls = "";
        if (ln >= 0){
            lns = ans;
            ans = toArgument(an,-1).name;
            ls = " ";
        }
        return com + cs + ans + ls + lns;
    }

    /**
     * Deliver the command as a string, possibly by concatenating the
     * segments.
     *
     * @return     String, null if not command
     */

    public String toString(){
        String str = null;
        excInit();
        try {
            if (this.pass == 0){                 // not initialized
                error(ERR_SEQUENCE);
            }
            if ((this.argv != null) || (this.args != null)){
                if (this.argc == 0) return "";
                str = toString(0,0,this.argc,0,0);
            } else {
                int len;
                if (this.com != null) len = this.com.length;
                else len = this.coms.length();
                if ((this.comLen > 0) && (this.comLen < len)){
                    len = this.comLen;
                }
                str = toString(-1,0,-1,len,0);
            }
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
        return str;
    }

    /**
     * Deliver a portion of the command as a string, possibly by
     * concatenating the segments, and reducing the string to a given
     * length (in the latter case, if the length allows, ellipses are
     * included at the end). This is appropriate for showing the error
     * position.
     *
     * @param      argni argn of start index
     * @param      ini start index
     * @param      argne argn of end index (reduced to the last argv if
     *             greater)
     * @param      end end index
     * @param      l maximum length, no limits if 0
     * @return     String, null if not command
     */

    String toString(int argni, int ini, int argne, int end, int l){
        int     len, ln;
        int     delta;
        char    c;
        boolean[] argquote = null;
        int     start, last;
        int     p;
        char[]  s;
        String  str = null;
        boolean isStr = false;

        if ((FL_E & this.trc) != 0){
            Trc.out.println("toString: " + argni + ":" + ini +
               " " + argne + ":" + end + " " + l);
        }
        len = 0;
        if (argni >= 0){                             // in segments
            if (this.argc == 0) return "";
            if (this.args != null){
                isStr = true;
            }
            if (argne >= this.argc){                 // after the last
                argne = this.argc-1;                 // withdraw to last
                if (this.args != null){
                    end = this.args[argne].length();
                } else {
                    end = this.argv[argne].length;
                }
            } else {
                int e = 0;
                if (this.args != null){
                    e = this.args[argne].length();
                } else {
                    e = this.argv[argne].length;
                }
                if (end > e) end = e;                // reduce if too large
            }
            argquote = new boolean[argne+1];
            for (int i = argni; i <= argne; i++){    // determine length
                int al;
                if (isStr) al = this.args[i].length();
                else al = this.argv[i].length;
                if (i == argni) start = ini;
                else start = 0;
                if (i == argne)
                    last = (end > al) ? al : end;    // empty argv
                else last = al;
                delta = 0;
                boolean special = false;
                for (int j = start; j < last; j++){
                    if (isStr) c = this.args[i].charAt(j);
                    else c = this.argv[i][j];
                    if ((c == ' ') || (c == '\t')){
                        special = true;
                    } else if (c == '\"'){
                        special = true;
                        delta++;
                    } else if ((SHELL_UPPER & this.mode) != 0){
                        if (c < 128){
                            if (c >= 'a') special = true;
                        } else {
                            if (Character.isLowerCase(c)) special = true;
                        }
                    }
                }
                if (special || (al == 0)){
                    if (start == 0) delta++;         // opening "
                    if (last == al) delta++;         // closing "
                    argquote[i] = true;
                }
                if (delta < 0) error(ERR_OUTLIMIT);
                len += last-start;
                if (len < 0) error(ERR_OUTLIMIT);
                len += delta;
                if (len < 0) error(ERR_OUTLIMIT);
                if (i <= argne-1){                   // separating blank
                    len++;
                    if (len < 0) error(ERR_OUTLIMIT);
                }
            }
        } else {
            if (end > this.end) end = this.end;
            len = end - ini;
        }
        if (l == 0) ln = len;
        else if (l > len) ln = len;
        else ln = l;
        if ((FL_E & this.trc) != 0)
            Trc.out.println("ln: " + ln + " len: " + len);
        s = new char[ln];                            // allocate area for string

        p = 0;
        copy: if (argni >= 0){                       // in segments
            for (int i = argni; i <= argne; i++){    // concatenate arguments
                int al;
                if (isStr) al = this.args[i].length();
                else al = this.argv[i].length;
                if (i == argni) start = ini;
                else start = 0;
                if (i == argne)
                    last = (end > al) ? al : end;    // empty argv
                else last = al;
                if (argquote[i]){                    // contains special chars
                    if (start == 0){                 // opening "
                        if (p < ln) s[p++] = '\"';
                        else break copy;
                    }
                    for (int j = start; j < last; j++){
                        if (isStr) c = this.args[i].charAt(j);
                        else c = this.argv[i][j];
                        if (c == '\"'){
                            if (p < ln) s[p++] = c;
                            else break copy;
                        }
                        if (p < ln) s[p++] = c;
                        else break copy;
                    }
                    if (last == al){                 // closing "
                        if (p < ln) s[p++] = '\"';
                        else break copy;
                    }
                } else {
                    int lx = last - start;
                    if (ln-p < lx) lx = ln-p;
                    if (isStr){
                        this.args[i].getChars(start,start+lx,s,p);
                    } else {
                        System.arraycopy(this.argv[i],
                            start,s,p,lx);           // copy argument
                    }
                    p += lx;
                }
                if (i <= argne-1){                   // separating blank
                    if (p < ln) s[p++] = ' ';
                    else break copy;
                }
            }
        } else {
            if ((FL_E & this.trc) != 0)
                Trc.out.println("argni: " + argni);
            int al;
            String as = null;
            char[] a = null;
            if (argni == -1){
                if (this.coms != null) as = this.coms;
                else a = this.com;
            } else {
                a = this.loadArr[-argni-2].load;
            }
            if (as != null) al = as.length();
            else al = a.length;
            start = ini;
            last = (end > al) ? al : end;            // empty argv
            int lx = last - start;
            if (ln-p < lx) lx = ln-p;
            if (as != null){
                as.getChars(start,start+lx,s,p);
            } else {
                System.arraycopy(a,start,s,p,lx);    // copy segment
            }
            p += lx;
        }
        if ((len > ln) && (ln >= 6)){                // truncation
            ("...").getChars(0,3,s,ln-3);
        }
        str = String.valueOf(s);
        if ((FL_E & this.trc) != 0)
           Trc.out.println("toString: |" + str + "|" +
               p + " " + str.length());
        return str;
    }

    /**
     * Deliver a portion of the command as a string, possibly by
     * concatenating the segments, and reducing the string to a given
     * length (in the latter case, if the length allows, ellipses are
     * included in the middle). This is appropriate for showing elements
     * for testing.
     *
     * @param      argni argn of start index
     * @param      ini start index
     * @param      argne argn of end index
     * @param      end end index
     * @param      l maximum length, no limits if 0
     * @return     String, null if not command
     */

    String toAbbrev(int argni, int ini, int argne, int end, int l){
        String str;
        int    len;
        str = toString(argni,ini,argne,end,0);
        len = str.length();
        if ((len > l) && (l > 0)){          // truncation
            if (l >= 9){                    // ellipses
                str = str.substring(0,l-6) + "..."
                    + str.substring(len-3);
            } else {
                str = str.substring(0,l);
            }
        }
        return str;
    }


    /**
     * Deliver the continuation character.
     *
     * @return     continuation character
     */

    public char contChar(){
        if ((CONHY & this.mode) != 0){
            return '-';
        } else if ((CONCARET & this.mode) != 0){
            return '^';
        }
        return '\\';
    }

    /* Command activation */

    /** The interface for command callbacks. */

    public interface CliCbk {

        /**
         * Callback.
         *
         * @param      c reference to the Cli object
         * @return     o object instance
         */

        public void cliExec(Cli c, Object o);     // callback
    }

    /**
     * Activate a command.
     *
     * @return     return status of the command
     */

    /* There can be the following ways to activate a command:
     * <ul>
     * <li>by calling a predefined method in a class which is referred
     *   to from the command descriptor (this is the usual Java callback
     *   technique). The class is one that implements CliCbk.
     * <li>by loading a class and calling a method whose name if specified
     *   in the command. This is similar to the previous one, but it is useful
     *   when the classes are known only at runtime.
     *   When the class and the method are mapped, they are kept there to
     *   speed up subsequent calls. Having a class support several commands
     *   avoids breaking operations which are closely related to each other in
     *   separate classes.
     * <li>by calling a predefined method dispatcher in a class which is
     *   referred and passing to it a unique argument that identifies
     *   the command. This defeats the idea of callback because it requires
     *   the caller to write in a unique place the list of methods that
     *   implement commands. In such a case it can as well call parse()
     *   first and immediately after switch to the appropriate method.
     *   To make it possible, a command number can be returned.
     * </ul>
     * The instance of the Cli is passed so as to allow the callback to get
     * the values, and an instance of the caller (not necessarily one of its
     * class so as to let the callback be an instance method.
     * If the class name is null, the main program's one is taken.
     */

    private int activate(){
        if ((FL_C & this.trc) != 0){
            Trc.out.println("activate start");
        }
        Class cclass;
        if (this.cmddes.cbk == null) return 0;

        cclass = this.cmddes.cbk.getClass();
        if (this.cmddes.cbk instanceof CliCbk){   // CliCbk callback
            ((CliCbk)this.cmddes.cbk).cliExec
               (this,this.instance);              // call callback
            return 0;
        }
                                                  // load class
        try {
            Object cn;
            if (this.cmddes.cbclass == null){
                getMainData();
                cn = this.mainClass;
            } else {
                cn = this.cmddes.cbclass;
            }
            if ((FL_C & this.trc) != 0){
                Trc.out.println("activate: |" + cn + "|");
            }
            Class<?> c;
            if (cn.getClass() == String.class){
                c = Class.forName((String)cn);
                this.cmddes.cbclass = c;          // replace it to speed
            } else {                              // .. up subsequent calls
                c = (Class)(this.cmddes.cbclass);
            }
            Method callback;
            if (cclass == String.class){
                Class<?>[] pars = new Class<?>[] {Cli.class};
                callback = c.getMethod((String)(this.cmddes.cbk),pars);
                this.cmddes.cbk = callback;
            } else {
                callback = (Method)(this.cmddes.cbk);
            }
            Object[] arguments = new Object[] {this};
            callback.invoke(this.instance,arguments);
        } catch (ClassNotFoundException e) {
            error(ERR_NOCBK,e);
        } catch (NoSuchMethodException e) {
            error(ERR_NOCBK,e);
        } catch (SecurityException e) {
            error(ERR_NOCBK,e);
        } catch (IllegalAccessException e) {
            error(ERR_NOCBK,e);
        } catch (IllegalArgumentException e) {
            error(ERR_NOCBK,e);
        } catch (InvocationTargetException e) {
            error(ERR_NOCBK,e);
        }
        return 0;
    }


    /* Command serialization */

    /**
     * Store a command definition in a file.
     *
     * @param      path name of the file to create
     * @param      cmd command, or set of commands
     */

    public void storeCommand(String path, Object cmd){
        excInit();
        try {
            FileOutputStream out = new FileOutputStream(path);
            ObjectOutputStream ous = new ObjectOutputStream(out);
            ous.writeObject(cmd);
            ous.close();
        } catch (IOException exc) {
            registerError(ERR_IOERR,exc,path);
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
    }

    /**
     * Retrieve a command definition from a file.
     *
     * @param      path name of the file
     * @return     command, or set of commands
     */

    public Object retrieveCommand(String path){
        Object cmd = null;

        excInit();
        try {
            FileInputStream in = new FileInputStream(path);
            ObjectInputStream ins = new ObjectInputStream(in);
            cmd = (Command)ins.readObject();
            ins.close();
        } catch (ClassNotFoundException exc) {
            registerError(ERR_IOERR,exc,path);
        } catch (IOException exc) {
            registerError(ERR_IOERR,exc,path);
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
        return cmd;
    }

    /**
     * Store a decoded cgi query string as current command. The
     * `<code>%</code><i>hh</i>' sequences in it are replaced by the
     * Unicode 00<i>hh</i> character, `<code>+</code>' replaced by space
     * and `<code>&</code>' as argument delimiter.
     * According to the http query strings specification, when a form is
     * submitted to a web server, its data are encoded as
     * <i>name</i><code>=</code><i>value</i> pairs, separated by
     * `<code>&</code>', in which space is `<code>+</code>' and reserved
     * characters (<code>; / ? : @ & = + $ ,</code>) are represented as
     * hexadecimal escapes. Line breaks are represented as
     * `<code>%0D%0A</code>'.
     *
     * @param      query string
     */

    public void decodeCgi(String s){
        excInit();
        try {
            int len = s.length();
            int p = 0;
            int cgilen = len + len/10 + 2;             // return string
            if (cgilen < 0) error(ERR_OUTLIMIT,ARG);
            Str str = new Str(cgilen);                 // return string
            int pe = str.buffer.length;
            boolean eq = false;
            doit: for (int i = 0; i < len; i++){
                char c = s.charAt(i);
                trans: {
                    num: if ((len - i >= 3) && (c == '%')){     // %hh
                        int u = 0;
                        for (int j = i+1; j < i+3; j++){
                            char ch = s.charAt(j);
                            int d = 0;
                            if (('A' <= ch) && (ch <= 'F')){
                                d = ch - 'A' + 10;
                            } else if (('a' <= ch) && (ch <= 'f')){
                                d = ch - 'a' + 10;
                            } else if (('0' <= ch) && (ch <= '9')){
                                d = ch - '0';
                            } else {
                                break num;
                            }
                            if (d > 16) break num;
                            u = (u<<4) + d;
                            if (u > Character.MAX_VALUE) break num;
                        }
                        c = (char)u;
                        i += 2;
                        break trans;
                    }
                    if (c == '+'){
                        c = ' ';
                    } else if (c == '='){
                        eq = true;
                        if (p == pe){
                            str.extend();
                            pe = str.buffer.length;
                        }
                        str.buffer[p++] = c;
                        c = '\"';
                    } else if (c == '&'){
                        for (i++; i < len; i++){           // skip multiple arg
                            if (s.charAt(i) != '&'){       // .. separators
                                i--;
                                break;
                            }
                        }
                        if (eq){
                            if (p == pe){
                                str.extend();
                                pe = str.buffer.length;
                            }
                            str.buffer[p++] = '\"';
                        }
                        if (i >= len) break doit;          // & at end
                        if (p == 0) continue;              // & at beginning
                        eq = false;
                        c = ' ';
                    }
                } // trans
                if (p == pe){
                    str.extend();
                    pe = str.buffer.length;
                }
                str.buffer[p++] = c;
            }
            if (eq){
                if (p == pe){
                    str.extend();
                    pe = str.buffer.length;
                }
                str.buffer[p++] = '\"';
            }
            str.length = p;
            if ((FL_B & this.trc) != 0){
                Trc.out.println(str.toString());
            }
            setCmdLine(str.buffer,p);
        } catch (OutOfMemoryError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StackOverflowError exc){
            registerError(ERR_NOCORE,exc);
        } catch (StringIndexOutOfBoundsException exc){
            registerError(ERR_OUTLIMIT,exc);
        } catch (CliError exc){
        } finally {
            excTerm();
        }
    }
}
