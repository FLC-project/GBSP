/*
 * @(#)HashBag.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;
import java.io.*;
import java.lang.reflect.*;
import java.lang.ref.*;

/**
 * The <code>HashBag</code> class provides hash tables with embedded
 * keys.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

/**
 * This class provides:
 * <ul>
 * <li>tables in which elements can be inserted, removed, sorted.
 * <li>support of elements which have the key inside themselves.
 * <li>the capability to redefine the search method so as to support
 *   primary and secondary keys.
 * </ul>
 * The difference between <code>HashBag</code> and <code>HashMap</code>
 * is that the former has the key, link, info, etc., in the elements, while
 * the latter has them apart. I.e. to have the key into the elements there is
 * a need to have a field, but then a HashMap has it in two places.
 * Moreover, <code>HashBag</code>s allow multiple mappings, i.e. to have
 * a same key associated to several objects.
 * <code>HashBag</code> tables do not allow duplicates. However, they
 * allow elements with the same code. They can have methods to find
 * elements which meet given criteria, like e.g. have equal code.
 * The table allows elements which have a null code and an empty code.
 * <p>
 * Elements in a <code>HashBag</code> must be instances of (sub-)classes
 * of <code>HashNode</code>, in which the data that are used as keys for
 * hashing can have any type.
 * <p>
 * <code>HashBag</code> tables can only be used for objects for which the
 * notion equality is based only on what fields, taken together, represent
 * the key. E.g. objects that have a key field which is a string, but that
 * have a notion of equality that depends on other fields too (or solely
 * on other fields) cannot be put in <code>HashBag</code> tables.
 * Moreover, objects of <code>HashBag</code> tables that need to support
 * cloneability must implement it directly since they cannot use the
 * standard clone method.
 */

/*
 * This implementation performs the linking and unlinking required to
 * insert and remove elements directly to be fast, but it requires
 * the elements to be subclasses of a defined element class.
 * An even more generic version could require objects to be only
 * implementations of an interface. This is not little since it is much
 * more difficult to require an object to be a subclass of another one,
 * while it is not a problem to implement an interface.
 * However, performance would decrease considerably.
 *
 * To make iterators fail-fast when this table has changed while iterating
 * it, a counter is kept in this table which is incremented all the times
 * elements are added, removed, or rehashed. When an iterator is created,
 * the value of that counter is kept in it so as to be compared with the
 * actual one in iterator methods, and to throw an exception when they differ.
 * This works most of the times, except when the counter wraps as result of
 * changes like e.g. pairs of add()/remove() changes. In such a case the counter
 * can take the same value as it had before, and nevertheless the table be
 * changed. To invalidate iterators, when the counter wraps, the iterators are
 * scanned and the snapshot value in them set different with the current one.
 *
 * When the load factor exceeds a fixed threshold, the directory is enlarged
 * and the table rehashed. The load factor is the length of the directory
 * divided by the number of elements in the table.
 *
 * To implement put(), HashMap allocates a key element, while HashBag does
 * not, and thus it is faster. Search, instead, is similar.
 * The use of equals() and hashCode() do not decrease much the performance
 * with respect to performing the same operations inline.
 * Sorting is much faster if done with merge sort than with radix sort
 * (approx five times faster).
 *
 * It is not possible to keep the longest code since remove() is provided.
 * However, after a sort operation that value becomes known.
 * This can be useful, e.g. when printing a table with the elements.
 * The value is thus kept in a field.
 *
 * The method search() leaves in lastElem and lastChain the pointer to the
 * previous element and the index of the chain, so as to let remove() call
 * search() and then remove the element instead of doing it directly,
 * This allows a subclass to redefine it without a need to redefine also
 * remove(). N.B. this does not apply to contains(), which has a unique
 * semantics.
 * The method remove(Object) is the same as in Collection.
 * A remove() which takes an element and removes one which is equal() to it
 * is also provided for similarity with search().
 *
 * A method search() is provided which takes an element and searches the
 * table for an element which is equals() to it. This allows to have tables
 * in which the elements redefine equals() so as to compare their codes and
 * possibly some other fields.
 *
 * Cloneable is not supported because the links are in the objects, and any
 * operation which would be done on a table, would be reflected (inconsistently)
 * on its clones.
 *
 * In order to speed up rehashing, the original hash value (not the chain index)
 * could be kept in the elements. It would speed up a little bit also search
 * when elements are not present (which is the case when a table is built).
 * Measurements show that the performance increase is 10%..20% at
 * the cost of extra memory.
 *
 *
 * Equality and ordering relations
 *
 *   - equals(): the equality relation must be defined on all values,
 *     including the value null.
 *     The methods equals() do not define entirely this relation between
 *     values, since they may not be used to compare a null value with
 *     another one. This is why in classes in which there is a need to
 *     compare values, the expression:
 *
 *          (e1 == null ? e2 == null : e1.equals(e2))
 *
 *     is used (e.g. see the Arrays class).
 *     The JDK API specifies that a.equals(null) should return false.
 *     This is not mandatory: it is up to each class to determine what
 *     (object) value is equal to another one.
 *
 *   - ordering: there is a need to note that the relation is effectively
 *     between references to objects, although what are being ordered are
 *     eventually the objects themselves, i.e. the values which are
 *     contained in them (this is why some definitions and methods
 *     do not handle well the null reference: it refers to no value).
 *     Now, a total ordering over a set requires antisymmetry, which is
 *     to say that there are no distinct elements that are equal to each other,
 *     in other words that an element can precede and follow only itself.
 *     With references, there is thus a need first to partition the set
 *     of references and then to build the odering over the partitions.
 *     Therefore, an ordering between references defines at the same time
 *     a partitioning in equivalence classes and an ordering between them.
 *     Consistency between compareTo() and equals() means that the partitions
 *     that are determined by x.compareTo(y)==0 and x.equals(y) be the
 *     same.
 *     The conditions on compareTo() of JDK (see interface Comparable) are:
 *
 *      1.  sgn(x.compareTo(y)) == -sgn(y.compareTo(x)) for all x and y.
 *          (This implies that x.compareTo(y) must throw an exception
 *          iff y.compareTo(x) throws an exception.)
 *          This is antisymmetrcal + reflexive property.
 *      2.  (x.compareTo(y)>0 && y.compareTo(z)>0) implies x.compareTo(z)>0.
 *          This is the transitive property.
 *      3.  x.compareTo(y)==0 implies that
 *            sgn(x.compareTo(z)) == sgn(y.compareTo(z)), for all z.
 *          This is the partitioning of the set of values.
 *      4.  It is strongly recommended, but not strictly required that
 *          (x.compareTo(y)==0) == (x.equals(y)). This is consistency.
 *
 *     The natural ordering must be defined on all values, including the
 *     value null. The methods compareTo() do not define entirely this
 *     relation between values, since they may not be used to compare a null
 *     value with another one. This expression may be used instead:
 *
 *         (e1 == null ? (e2 == null ? 0 : -1) :
 *             (e2 == null ? 1 : e1.compareTo(e2)))
 *
 *     Comparator.compare, instead, can be implemented in such a way to
 *     compare also null values.
 *     Strictly speaking, the conditions in JDK on Comparable and Comparator
 *     would allow a partial ordering: x.compareTo(y) could throw an
 *     exception if the x neither preceded nor followed y.
 *     This, however, makes sorting impossible. Moreover, if they did define
 *     truly a partial order, sorting would become unstable. This is why
 *     that ordering must be total.
 *     The tutorial, Collections, Object Ordering is also not correct
 *     about this.
 *
 *   - equals() and hashCode(): they must be consistent in the sense
 *     that two elements which have different hashCode() must have
 *     different equals() because search() uses first hashCode()
 *     and then equals(), and therefore, if two elements are equals(),
 *     they must have the same hashCode().
 *     The rule is thus that equals() and hashCode() must be defined
 *     in such a way as to make the following true:
 *
 *         a.equals(b) implies (a.hashCode() == b.hashCode())
 *
 *     This means that it is possible to redefine equals() without
 *     redefining hashCode(), e.g. when specializing a class and extending
 *     the set of data that must be equal in order to make two element
 *     equal.
 *
 *   - equals() and compareTo(): compareTo() must be consistent with
 *     equals() in order to allow to build sorted collections with the
 *     objects on which they are defined.
 *     The definition of consistency is, however, not correct in JDK in
 *     handling the null value.
 *     The consistency is such that all the values which are equal
 *     in one relation are also equal in the other.
 *     Thus, in all places in which comparison according to the natural
 *     ordering is done, null must be considered equal to null (and no
 *     exceptions be generated).
 *     Note that the expression above satisfies this condition for the
 *     null value.
 *     In JDK there is a lot of confusion about this: many collections do
 *     not allow null values to be stored without telling it, and some
 *     allow it, but then throw an exception when sorted. Arrays does not
 *     allow it, but do not tell it.
 *     When there is no need to build such collections, there is no need
 *     to keep such consistency.
 *     The methods equals() and hashCode() are called to store and retrieve
 *     elements in hashtables, and compareTo() is called to sort.
 *     This allows, e.g. to have a case-insensitive equal(), which allows
 *     to treat case-insensitive definitions, and to sort them in a case
 *     sensitive way. Note that this equals() would make compareTo()
 *     inconsistent with it, which means that these objects may not be
 *     stored in an ordered Set.
 *   - a Comparator is just an instance of a class which implements the
 *     interface Comparator, i.e. a compare method. The object is the vehicle
 *     to pass the method.
 *     The usefulness of a Comparator is that Collection.sort() and
 *     Arrays.sort() can take it as argument, which means that it is possible
 *     to sort by using an ordering which is different from the one built
 *     into the elements.
 */

public class HashBag extends AbstractCollection implements Serializable {

    /** SUID form JDK 1.2 */
    private static final long serialVersionUID = -2860274434286949830L;

    /**
     * The number of elements contained in the table.
     *
     * @serial
     */
    protected int elemNr;

    /**
     * The length of the longest code.
     *
     * @serial
     */
    protected int maxcode;

    /**
     * The directory of the hash chains.
     *
     * @serial
     */
    protected HashNode[] hdir;

    /**
     * The load factor.
     *
     * @serial
     */
    protected float loadFactor;

    /**
     * The threshold for the number of element, above which the table
     * is extended.
     *
     * @serial
     */
    protected int threshold;

    /**
     * The reference to an element, used as prototype to access its
     * specific equals() and hashCode() in specializations.
     * is extended.
     *
     * @serial
     */
    protected HashNode elementNode;

    /** The array of iterators. */
    protected transient WeakReference[] iterators;

    /** The modification count. */
    protected transient int modCount;

    /** The trace flags. */
    protected transient int trc;

    /*
     * Internal constants for trace flags
     */

    /*
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    a   basic operations
     *    b   user trace
     *    c   detail trace
     *    m   allocation
     * </pre></blockquote><p>
     */

    protected static final int FL_A = 1 << ('a'-0x60);
    protected static final int FL_B = 1 << ('b'-0x60);
    protected static final int FL_C = 1 << ('c'-0x60);
    protected static final int FL_M = 1 << ('m'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Construct a new <code>HashBag</code> with a directory of a
     * given capacity and with a specified load factor.
     *
     * @param   c capacity
     * @param   l load factor
     */

    public HashBag(int c, float l){
        if ((c <= 0) || (l <= 0.0)){
            throw new IllegalArgumentException();
        }
        this.hdir = new HashNode[c];
        this.loadFactor = l;
        this.threshold = (int)(c * l);
    }

    /**
     * Construct a new <code>HashBag</code> with a directory of a
     * given capacity.
     *
     * @param   c capacity
     */

    public HashBag(int c){
        this(c,2);
    }

    /**
     * Construct a new <code>HashBag</code> with a directory of a
     * default capacity.
     */

    public HashBag(){
        this(32,2);
    }

    /**
     * Update the modification counter. If the counter overflows,
     * all the iterators which are alive are accessed to invalidate
     * them by setting their snapshot of the modification count to a
     * value which is different from the current one.
     */

    protected void updateModCount(){
        this.modCount++;
        if (this.modCount == 0){                  // overflow
            WeakReference[] wa = this.iterators;
            for (int i = 0; i < wa.length; i++){
                HashBagIter hi = (HashBagIter)(wa[i].get());
                if (hi == null){
                    hi.snapshot = 1;              // make it different
                }
            }
        }
    }

    /**
     * Remove all the elements from this table.
     */

    public void clear(){
        int len = this.hdir.length;
        for (int row = 0; row < len; row++){  // clear all chains
            this.hdir[row] = null;
        }
        this.elemNr = 0;
        this.maxcode = 0;
        updateModCount();                     // table changed
    }

    /**
     * The prototype of hash table elements.
     */

    public static class HashNode implements Serializable, Comparable {

        /** SUID form JDK 1.2 */
        private static final long serialVersionUID = 8509419276430578417L;

        /**
         * The link to the next element in the hash chain.
         *
         * @serial
         */
        public HashNode hlink;

        /**
         * Deliver the lenght of the String representation of this object.
         *
         * @return  length
         */

        public int toStringLength(){
            return toString().length();
        }

        /**
         * Compare this object with the specified value. The null value
         * is considered to precede all other values.
         *
         * @param   other the object to compare
         * @return  &lt; = or &gt; 0 if this object precedes, is equal or
         *          follows the other.
         */

        public int compareTo(Object other){
            if (other == null) return 1;
            return toString().compareTo(other.toString());
        }

        /**
         * Deliver an array containing references to this element and
         * the ones linked to it.
         *
         * @return  reference to the array
         */

        public Object[] toArray(){
            int n = 0;
            for (HashNode e = this;
                e != null; e = e.hlink){          // count the elements
                n++;
            }
            Object[] arr = new Object[n];
            n = 0;
            for (HashNode e = this;
                e != null; e = e.hlink){          // build the array
                arr[n++] = e;
            }
            return arr;
        }
    }

    /**
     * Trace the contents of the hash table. Only the chains which are not
     * empty are printed. Print the average length of chains and the
     * standard deviation of the lengths.
     */

    public void trace(){
        int len = this.hdir.length;
        for (int row = 0; row < len; row++){      // scan all chains
            int nr = 0;                           // nr of elements in the chain
            for (HashNode e = this.hdir[row];
                e != null; e = e.hlink){          // scan the chain
                if (nr == 0){
                    Trc.out.println("---chain nr: " + row);
                }
                Trc.out.print(e.getClass().getName() +
                    '@' + System.identityHashCode(e) + ' ');
                Trc.literalize(e.toString().toCharArray());
                Trc.out.println();
                nr++;                             // count elements in chain
            }
        }
        statis();
    }

    /**
     * Trace the statistics of this table.
     */

    public void statis(){
        int len = this.hdir.length;
        float average = this.elemNr / len;        // average chain length
        float stdDev = 0;                         // standard deviation
        int longest = 0;
        for (int row = 0; row < len; row++){      // scan all chains
            int nr = 0;                           // nr of elements in the chain
            for (HashNode e = this.hdir[row];
                e != null; e = e.hlink){          // scan the chain
                nr++;                             // count elements in chain
            }
            stdDev += Math.pow(nr - average,2);
            if (nr > longest) longest = nr;
        }
        Trc.out.print("elements: " + this.elemNr +
            " chains: " + len +
            " average chain: " + average);
        if (this.elemNr > 0){
            Trc.out.print(" deviation: " +
               Math.sqrt(stdDev / this.elemNr) +
               " longest chain: " + longest);
        }
        Trc.out.println();
    }

    /**
     * Trace the specified list of elements.
     *
     * @parameter  head list
     */

    public void traceList(HashNode head){
        Trc.out.println("list: ");
        for (HashNode e = head;
            e != null; e = e.hlink){
            Trc.out.println(e);
        }
    }

    /**
     * Trace the specified portion of list of elements.
     *
     * @parameter  head list
     * @parameter  len number of elements
     */

    protected void traceList(HashNode head, int len){
        Trc.out.println("list: ");
        int i = 0;
        for (HashNode e = head; i < len; e = e.hlink, i++){
            Trc.out.println(e);
        }
    }

    /**
     * Search an element which is <code>equals()</code> to the specified one.
     *
     * @param   el reference to the element
     * @return  reference to the element, <code>null</code> if not found
     */

    public HashNode search(HashNode el){
        if (el == null) return null;
        int hvalue = (el.hashCode() & 0x7FFFFFFF)
            % this.hdir.length;
        HashNode pr = null;
        HashNode e = null;
        sea: for (e = this.hdir[hvalue];
            e != null; e = e.hlink){              // scan the chain
            if (e.equals(el)) break sea;
            pr = e;
        }
        this.lastList = pr;
        this.lastChain = hvalue;
        if ((FL_B & this.trc) != 0){
            Trc.out.println("search: " + el + " " + hvalue + " " + e);
        }
        return e;
    }

    /**
     * Tell if the table contains the element passed as argument.
     *
     * @param   e reference to the element
     */

    public boolean contains(Object o){
        if (o == null) return false;
        int hvalue = (o.hashCode() & 0x7FFFFFFF)
            % this.hdir.length;
        for (HashNode e = this.hdir[hvalue];
            e != null; e = e.hlink){           // scan the chain
            if (e == o) return true;           // same object
        }
        return false;
    }

    /**
     * Insert an element in this hash table. The table allows to have
     * several elements with the same code. Insertion is done on top of
     * the relevant chain. The element must be a <code>HashNode</code>.
     *
     * @param      o element
     * @return     <code>true</code>
     * @exception  NullPointerException if the argument is null
     */

    public boolean add(Object o){
        return add((HashNode)o);
    }

    /**
     * Insert an element in this hash table.
     *
     * @see        #add(Object)
     */

    public boolean add(HashNode el){
        int hvalue = (el.hashCode() & 0x7FFFFFFF)
            % this.hdir.length;
        el.hlink = this.hdir[hvalue];              // insert at beginning
        this.hdir[hvalue] = el;                    // link to last
        if (this.elemNr == Integer.MAX_VALUE){
            throw new OutOfMemoryError();
        }
        this.elemNr++;
        if (this.elemNr > this.threshold){         // directory too crowded
            rehash((int)(this.hdir.length * 1.5F));
        }
        updateModCount();                          // table changed
        this.elementNode = el;
        return true;
    }

    /** The index of the last chain searched. */
    protected transient int lastChain;

    /**
     * Insert an element in this hash table if no elements with the
     * same code are present in the table.
     *
     * @param      el element
     * @return     <code>true</code> if the element has been inserted
     * @exception  NullPointerException if the argument is null
     */

    public boolean addUnique(HashNode el){
        if (el == null) return false;
        if (search(el) != null) return false;
        el.hlink = this.hdir[this.lastChain];      // insert at beginning
        this.hdir[this.lastChain] = el;            // link to last
        if (this.elemNr == Integer.MAX_VALUE){
            throw new OutOfMemoryError();
        }
        this.elemNr++;
        if (this.elemNr > this.threshold){         // directory too crowded
            rehash((int)(this.hdir.length * 1.5F));
        }
        updateModCount();                          // table changed
        this.elementNode = el;
        return true;
    }

    /**
     * Rehash this table. The elements are inserted into a new, enlarged
     * directory.
     *
     * @param      ln length of the new directory
     */

    protected void rehash(int ln){
        HashNode[] newDir = new HashNode[ln];
        int len = this.hdir.length;
        for (int row = 0; row < len; row++){  // scan all chains
            HashNode e = this.hdir[row];
            while (e != null){                // scan the chain
                HashNode tptr = e.hlink;      // save pointer to next
                int hash = (e.hashCode() & 0x7FFFFFFF)
                    % newDir.length;
                e.hlink = newDir[hash];       // link to next
                newDir[hash] = e;             // place on top
                e = tptr;                     // step to next chain
            }
        }
        this.hdir = newDir;                   // store the new directory
        this.threshold = (int)(ln * this.loadFactor);
    }

    /**
     * Remove an element which is <code>equals()</code> to the specified
     * one from this hash table.
     *
     * @param   el element
     * @return  <code>true</code> if the element was present
     */

    public boolean remove(HashNode el){
        HashNode e = search(el);
        if (e == null){                         // not present
            return false;
        } else {
            if (this.lastList == null){
                this.hdir[this.lastChain] = e.hlink;
            } else {
                this.lastList.hlink = e.hlink;
            }
        }
        this.elemNr--;
        updateModCount();                       // table changed
        return true;
    }

    /**
     * Remove an element from this hash table.
     *
     * @see     #remove(HashBag.HashNode)
     */

    public boolean remove(Object o){
        HashNode el = (HashNode)o;
        if (el == null) return false;
        int hvalue = (el.hashCode() & 0x7FFFFFFF)
            % this.hdir.length;
        HashNode pr = null;
        HashNode e = null;
        sea: {
            for (e = this.hdir[hvalue];
                e != null; e = e.hlink){        // scan the chain
                if (e == el) break sea;         // found
                pr = e;
            }
            return false;                       // no such element
        }
        if (pr == null){
            this.hdir[hvalue] = e.hlink;
        } else {
            pr.hlink = e.hlink;
        }
        this.elemNr--;
        updateModCount();                       // table changed
        return true;
    }

    /**
     * Deliver an array containing references to all the elements.
     *
     * @return  reference to the array
     */

    public Object[] toArray(){
        Object[] a = new Object[this.elemNr];
        return toArray(a);
    }

    /**
     * Store in the array passed as argument the references to all the
     * elements, filling with <code>null</code> the unused part, or
     * enlarging it if needed.
     *
     * @return  reference to the array
     */

    public Object[] toArray(Object[] a){
        if (a.length < this.elemNr){
            a = (Object[])Array.newInstance(
                a.getClass().getComponentType(),this.elemNr);
        }
        int i = 0;
        int len = this.hdir.length;
        for (int row = 0; row < len; row++){     // scan all chains
            for (HashNode e = this.hdir[row];
                e != null; e = e.hlink){         // scan the chain
                a[i++] = e;
            }
        }
        return a;
    }

    /**
     * Deliver the number of elements present in this table.
     *
     * @return  number of elements
     */

    public int size(){
        return this.elemNr;
    }

    /**
     * Determine the length of the longest code in this table.
     * The length is returned and also stored in the <code>maxcode</code>
     * field.
     *
     * @return  length
     */

    public int maxCode(){
        int max = 0;                             // initialize max lenght
        int len = this.hdir.length;
        for (int row = 0; row < len; row++){     // scan all chains
            for (HashNode e = this.hdir[row];
                e != null; e = e.hlink){         // scan the chain
                int slen = e.toStringLength();
                if (max < slen) max = slen;
            }
        }
        this.maxcode = max;
        return max;
    }

    /**
     * Sort this table by using its natural ordering.
     * 
     * @return  a reference to the sorted list
     */

    /*
     * The algorithm used is a variant of merge sort.
     */

    public HashNode sort(){
        int max = 0;                             // initialize max length
        HashNode head = null;
        HashNode cur = null;
        int len = this.hdir.length;
        for (int row = 0; row < len; row++){     // scan all chains
            for (HashNode e = this.hdir[row];
                e != null; e = e.hlink){         // scan the chain
                if (cur == null){                // first enqueued
                    cur = e;
                    head = e;
                } else {                         // append
                    cur.hlink = e;
                }
                cur = e;                         // new last
                int slen = e.toStringLength();
                if (max < slen) max = slen;
            }
            this.hdir[row] = null;               // clear directory
        }
        this.maxcode = max;
        if ((FL_C & this.trc) != 0){
            Trc.out.println("mergesort:");
            traceList(head,this.elemNr);
        }
        head = mergeSort(head,this.elemNr);
        if ((FL_C & this.trc) != 0){
            Trc.out.println("sorted:");
            traceList(head);
        }
        this.elemNr = 0;
        updateModCount();                        // table changed
        return head;
    }

    /** The reference to the last element in the merged list. */
    protected transient HashNode lastList;

    /** The reference to the first element in the non-merged list. */
    protected transient HashNode nextList;

    /**
     * Sort the specified list of elements. The table is then left empty.
     * 
     * @param   el list
     * @param   num number of elements to sort
     */

    protected HashNode mergeSort(HashNode el, int num){
        if (num < 7){                          // short list
            HashNode head = null;              // destination list
            this.lastList = null;
            HashNode cptr = el;
            while (num-- > 0){
                this.nextList = cptr.hlink;    // save pointer to next
                                               // insert
                HashNode l = null;             // pointer to previous
                HashNode p = head;             // pointer to current
                seek: while (p != null){       // search insertion place
                    if (p.compareTo(cptr) >= 0)
                        break seek;
                    l = p;                     // pointer to previous
                    p = p.hlink;               // step to next
                }
                if (l == null){                // insert on top
                    cptr.hlink = head;
                    head = cptr;
                } else {                       // insert in the middle
                    cptr.hlink = p;
                    l.hlink = cptr;
                }
                if (cptr.hlink == null){       // last in the list
                    this.lastList = cptr;
                }
                cptr = this.nextList;          // step to next
            }
            return head;
        }
        int mid = num / 2;
        HashNode up = mergeSort(el,mid);       // sort first half
        HashNode last = this.lastList;         // last in sorted list
        el = this.nextList;                    // head of unsorted list
        int high = num - mid;
        HashNode down = mergeSort(el,high);    // sort second half
        if (last.compareTo(down) <= 0){        // no merge needed
            last.hlink = down;
            return up;
        }
        HashNode head = null;                  // merge the two sorted
        HashNode cur = null;                   // .. halves
        for (int k = 0; k < num; k++){
            if ((down == null) ||              // no more elements down
                (up != null) &&                // some in first half
                (up.compareTo(down) <= 0)){    // .. and lower
                if (cur == null) head = up;
                else cur.hlink = up;
                cur = up;
                up = up.hlink;
            } else {                           // take from second half
                if (cur == null) head = down;
                else cur.hlink = down;
                cur = down;
                down = down.hlink;
            }
        }
        this.lastList = cur;
        cur.hlink = null;
        return head;
    }

    /**
     * An iterator over this hash table.
     */

    /*
     * Insertions in the table must not be done while iterating over it.
     * Even using an implementation which allows to add elements between
     * hasNext() and a next() and have the latter return at least the ones
     * which have been placed further down in the chains, below the one
     * returned by the previous next(), there could be elements which have
     * been placed before, and that would not be visited.
     */

    public class HashBagIter implements Iterator {

        /** The reference to the next element. */
        private HashNode toVisit;
      
        /** The reference to the previous element. */
        private HashNode previous;
      
        /** The index of the current chain. */
        private int curChain;

        /** Whether a next() has been called and a remove() not. */
        private boolean located;

        /**
         * The modification count value the iterator expects the table has. */
        private int snapshot;

        /**
         * Construct a new iterator.
         */

        public HashBagIter(){
            WeakReference[] wa = HashBag.this.iterators;
            int len = (wa == null) ? 0 : wa.length;
            done: {
                for (int i = 0; i < len; i++){          // find a free one
                    if (wa[i].get() == null){
                        wa[i] = new WeakReference<HashBagIter>(this);
                        break done;
                    }
                }
                if (len + 1 < 0){
                    throw new ArithmeticException();
                }
                WeakReference[] p =                     // none, enlarge it
                    new WeakReference[len+1];
                if (len > 0) System.arraycopy(wa,0,p,0,len);
                p[len] = new WeakReference<HashBagIter>(this);
                HashBag.this.iterators = p;
            } // done
            this.snapshot = HashBag.this.modCount;
        }

        /**
         * Tell if the iteration has elements left to visit.
         *
         * @return     <code>true</code> if there are elements.
         * @exception  ConcurrentModificationException table changed
         */

        public boolean hasNext(){
            HashBag tb = HashBag.this;
            if (tb.modCount != this.snapshot){
                throw new ConcurrentModificationException();
            }
            found: if (this.toVisit == null){
                this.previous = null;           // first in chain
                int len = tb.hdir.length;
                while (this.curChain < len){
                    this.toVisit = tb.hdir[this.curChain++];
                    if (this.toVisit != null) break found;
                }
                return false;
            }
            return true;
        }

        /**
         * Return the next element to visit.
         *
         * @return     reference to the next element
         * @exception  NoSuchElementException no elements left
         * @exception  ConcurrentModificationException table changed
         */

        public Object next(){
            HashBag tb = HashBag.this;
            if (tb.modCount != this.snapshot){
                throw new ConcurrentModificationException();
            }
            found: if (this.toVisit == null){
                this.previous = null;           // first in chain
                int len = tb.hdir.length;
                while (this.curChain < len){
                    this.toVisit = tb.hdir[this.curChain++];
                    if (this.toVisit != null) break found;
                }
            }
            HashNode el = this.toVisit;
            if (el != null){
                this.previous = this.toVisit;   // save for remove()
                this.toVisit = el.hlink;
            } else {
                throw new NoSuchElementException();
            }
            this.located = true;                // element located
            if ((FL_B & tb.trc) != 0){
                Trc.out.println("next: " + this.curChain
                    + " " + el + " " + this.toVisit);
            }
            return el;
        }

        /**
         * Remove from the collection the last element returned by
         * the iterator. It can be called only once per call to
         * <code>next()</code>.
         *
         * @exception  IllegalStateException if not called after
         *             <code>next()</code> or called more than once
         * @exception  ConcurrentModificationException table changed
         */

        public void remove(){
            HashBag tb = HashBag.this;
            if (!this.located){                    // next() not done, or
                throw new IllegalStateException(); // .. remove() done
            }
            if (tb.modCount != this.snapshot){
                throw new ConcurrentModificationException();
            }
            if (this.previous == null){
                HashBag.this.hdir[this.curChain] =
                    this.toVisit;
            } else {
                this.previous.hlink = this.toVisit;
            }
            tb.elemNr--;
            this.located = false;
            tb.updateModCount();                   // table changed
            this.snapshot++;                       // keep it aligned
        }
    }

    /**
     * Return an iterator over the elements in this table. The elements
     * are delivered in no particular order.
     *
     * @return  reference to the iterator
     */

    public Iterator iterator() {
        return new HashBagIter();
    }
}
