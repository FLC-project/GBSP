/*
 * @(#)Trc.java       1.0 98/11/04
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.lang.reflect.*;

/**
 * The <code>Trc</code> class provides tracing.
 *
 * @author  Angelo Borsotti
 * @version 1.0   04 Nov 1998
 */

public class Trc {

    /** The trace stream. */
    public static PrintStream out = System.err;

    /** The trace writer. */
    public static PrintWriter wrt = new PrintWriter(System.err,true);

    /**
     * Trace a string by representing non-printable characters 
     * with escape sequences.
     *
     * @param      s pointer to the string to be printed
     */

    public static void literalize(char[] s){
        literalize(s,0,(s == null) ? 0 : s.length);
    }

    /**
     * Trace a (portion of a) string by representing non-printable characters 
     * with escape sequences.
     *
     * @param      s pointer to the string to be printed
     * @param      len number of characters of the string to be taken
     */

    public static void literalize(char[] s, int len){
        literalize(s,0,len);
    }

    /**
     * Trace a (portion of a) string by representing non-printable characters 
     * with escape sequences.
     *
     * @param      s pointer to the string to be printed
     * @param      off start index
     * @param      len number of characters of the string to be taken
     */

    public static void literalize(char[] s, int off, int len){
        char c;
        String st = "";
        if (s == null) return;

        for (int i = off; i < off+len; i++){
            c = s[i];
            switch (c){
            case '\b': st = "\\b"; break;
            case '\t': st = "\\t"; break;
            case '\n': st = "\\n"; break;
            case '\f': st = "\\f"; break;
            case '\r': st = "\\r"; break;
            case '\\': st = "\\\\"; break;
            case '\'': st = "\\\'"; break;
            case '\"': st = "\\\""; break;
            default:
                if ((c < ' ') || (c > '~')){  // others non printable
                    int rem;
                    Trc.out.print("\\u");
                    for (int j = 0; j < 4; j++){
                        rem = (c>>>((4-j-1)*4)) & 0xf;
                        Trc.out.print(
                            (char)(rem + ((rem <= 9) ? '0' : 'a' - 10)));
                    }
                    continue;
                }
                st = String.valueOf(c);
            }
            Trc.out.print(st);
        }
    }

    /** The tracer adaptors. */
    public abstract static class Tracer {

        /**
         * Trace the specified field with the specified value, if possible.
         *
         * @param      name field name
         * @param      val field value
         * @return     <code>true</code> if the field has been traced,
         *             <code>false</code> otherwise.
         */

        protected abstract boolean show(String name, Object val);
    }

    /**
     * Trace all the fields (inherited or otherwise) of the specified 
     * object. Arrays of primitive types are visited and printed.
     *
     * @param      o reference to the object
     */

    public static void printFields(Object o){
        printFields(o,null);
    }

    /**
     * Trace all the fields (inherited or otherwise) of the specified 
     * object with the specified tracer. Arrays of primitive types are
     * visited and printed. The fields that are not traced by the tracer
     * are traced in the standard way.
     *
     * @param      o reference to the object
     * @param      t reference to the tracer
     */

    public static void printFields(Object o, Tracer t){
        try {
            Class c = o.getClass();
            while (c != null){                               // visit itself and..
                Field[] fields = c.getDeclaredFields();      // .. all ancestors
                AccessibleObject.setAccessible(fields,true); // make fields accessible
                for (int i = 0; i < fields.length; i++) {    // print all fields
                    int modif = fields[i].getModifiers();
                    if (Modifier.isStatic(modif)) continue;  // static field
                    String fieldName = fields[i].getName();  // name
                    Object val = fields[i].get(o);           // value
                    Trc.out.print(" " + fieldName + ":");
                    boolean done = false;
                    if ((t != null) && (val != null)){
                        done = t.show(fieldName,val);
                    }
                    if (!done){
                        if (val instanceof char[]){
                            val = String.valueOf((char[])val);
                            Trc.out.print(" " + val);
                        } else if (val instanceof byte[]){
                            byte[] arr = (byte[])val;
                            for (int j = 0; j < arr.length; j++){
                                Trc.out.print(" " + arr[j]);
                            }
                        } else if (val instanceof int[]){
                            int[] arr = (int[])val;
                            for (int j = 0; j < arr.length; j++){
                                Trc.out.print(" " + arr[j]);
                            }
                        } else if (val instanceof short[]){
                            short[] arr = (short[])val;
                            for (int j = 0; j < arr.length; j++){
                                Trc.out.print(" " + arr[j]);
                            }
                        } else if (val instanceof long[]){
                            long[] arr = (long[])val;
                            for (int j = 0; j < arr.length; j++){
                                Trc.out.print(" " + arr[j]);
                            }
                        } else if (val instanceof float[]){
                            float[] arr = (float[])val;
                            for (int j = 0; j < arr.length; j++){
                                Trc.out.print(" " + arr[j]);
                            }
                        } else if (val instanceof double[]){
                            double[] arr = (double[])val;
                            for (int j = 0; j < arr.length; j++){
                                Trc.out.print(" " + arr[j]);
                            }
                        } else if (val instanceof boolean[]){
                            boolean[] arr = (boolean[])val;
                            for (int j = 0; j < arr.length; j++){
                                Trc.out.print(" " + arr[j]);
                            }
                        } else {
                            Trc.out.print(" " + val);
                        }
                    }
                    Trc.out.println();
                }
                c = c.getSuperclass();
            }
        } catch (Throwable th){
            Trc.out.println(" " + th);
        }
    }
}

