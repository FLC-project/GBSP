/*
 * @(#)ParserLexer.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.util.*;
import lbj.HashTbl.*;

/**
 * The <code>ParserLexer</code> class provides the lexer for the
 * <code>Parser</code>
 * class.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

/**
 * This class provides:
 * <ul>
 * <li>the method to skip whitespace and comments across lines.
 * <li>the methods for the lexemes of the <code>Parser</code>.
 * <li>the capability of backing up three lexemes.
 * </ul>
 */

/*
 * To provide backup over two lexemes, the following method is used:
 *
 *      - to backup one lexeme, cursor is set to start
 *      - to backup two lexemes, cursor is set to the start of the
 *        previous one. This is strightforward when the previous lexeme is
 *        contained in the buffer. To make this happen when the buffer is
 *        refilled, the previous lexeme is moved first immediately before
 *        the current one and the mark set to the start of it. In so
 *        doing it is not lost, and the comments between the two lexemes
 *        are not saved (which could otherwise enlarge indefinitely
 *        the buffer.
 *
 * Note that when a lexeme has been scanned and a gsep() is done to get
 * to the beginning of the next one, and that gsep() stucks the end of
 * the buffer, it reloads it, but saves the previous lexeme.
 * In so doing, each time is discards the previous piece of comment.
 * Eventually, something which is not a comment is read (or the eof reached).
 * This means that in the buffer the lexeme is possibly followed by
 * the tail of the comment following it, and then by the next lexeme.
 *
 * Since the buffer can contain characters which are contiguous in it, but
 * not in the stream, when all the characters of the last but one lexeme have
 * been scanned, there is a need to reposition to the beginning of the following
 * one. To do it, the indexes of the last but one lexeme and of the last are
 * kept, and a state indicator to tell the segment of the buffer which is
 * scanned. When the state is 1, the last but one lexeme is being scanned.
 * When append() is called in a lexical method, and the state is 1, the end
 * of the lexeme has been reached. When load() is called (which is done in
 * gsep()), and the state is 1, the state is changed to 2, and load() called
 * again to deliver the characters of the following lexeme.
 * This allows also to spare the scanning of comments between two lexemes
 * when moving from the last but one lexeme to the following one and they both
 * are in the same buffer.
 *
 * This method applies if there are no lookaheads because the characters
 * after a lexeme are not saved. Most lexemes have an implicit lookahead of
 * one character. E.g. an identifier terminates when the first non alphanumeric
 * character is found. Storing it in the first segment of the buffer means
 * that when the lexer is backed up to it, it can match a lexeme which is no
 * longer than it. This roughly means that it supports a lexicon in which the
 * number of characters which make up a lexeme is unambiguous, but those
 * characters can be interpreted as several lexemes.
 *
 * Lexical methods and backup() treat lexemes as a LIFO queue: each lexical
 * method which matches a lexeme pushes it at the end of the queue (which
 * can imply that the first one is lost). Each call to backup() takes back
 * the last one.
 * When a lexical method or backup() are called, the first action done
 * is to update the queue if the previous one recognised a lexeme.
 * This is detected by testing start.
 * At the beginning start is equal to cursor. Each time a lexeme has been
 * matched, cursor is moved past start. Each lexical method calls gsep().
 * Several lexical methods can be called at the same index to determine which
 * lexeme is present.
 * The state of the lexer with respect to the queue and its evolutions are:
 *
 *    gsep, backup:   if state == 0 and found: push
 *                    if state == 2: state = 3,  move to next
 *                    if state == 4: state = 0,  move to buffer
 *    backup(1):      if state == 0 or 4: state = 3,  move to start of last
 *                    if state == 2: state = 1, move to start of last-1
 *                    else error
 *    backup(2):      if state == 0 or 4: state = 1,  move to start of last
 *                    else error
 *  
 * Backup may not be done at the beginning, when not enough lexemes are
 * in the queue.
 * The advancing from a state 2 (end last but one lexeme) to state 3
 * (start last lexeme) and from state 4 (end last lexeme) to state 0
 * (start unlexed characters) is made by the last append() called in
 * lexical methods. This works for all lexemes which end when the first
 * character which may not belong to them is found. However, there are
 * lexemes which end in a known character, having lexical methods which
 * do not try to get the next one. gsep() and backup() when a lexeme
 * has been matched and the state is still 1 or 3, advance the state.
 *
 * State 1 moves to state 2 only in load(): when a backup(2) is done, state
 * is 1. If a lexical method is called, at the end of it an append() is
 * done. If that caused the state to become 2, the second one would be
 * scanned in the wrong state.
 *
 * Backup() restores the indexes to allow a lexical method to be called.
 * It does not restore everything, and thus it is not possible to access
 * the previous lexeme without calling a method.
 *
 * To make eof() return false when an eof has been detected, but a
 * backup() has been done, a test is made on the cursor first: if it
 * is lower than end, no eof is returned.
 *
 * When the text is an array, fill() is called at the eof and when scanning
 * lexemes in the queue. When the eof is stuck, fill() shuffles the last-1.
 *
 * When load() is called and there is a previous lexeme, that lexeme is
 * shuffled in the buffer, but the indexes are not updated (to comply to
 * the behaviour expected by the Lexer methods). This means that it is not
 * possible to access it in the buffer. This, however, does not prevent to
 * backup() and get those lexemes correctly.
*/

class ParserLexer extends LexerStream {

    /** The number of the current line. */
    public long lineNr;

    /** The cursor of the last but one lexeme. */
    private int prevCursor;

    /** Its length. */
    private int prevLen;

    /** Its index. */
    private long prevPoint;

    /** Its line number. */
    private long prevLineNr;

    /** The cursor of the last lexeme. */
    private int savedCursor;

    /** Its length. */
    private int savedLen;

    /** The end cursor of the last lexeme. */
    private int savedEnd;

    /** Its index. */
    private long savedPoint;

    /** Its line number. */
    private long savedLineNr;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    v   lexer values
     *    w   messages
     * </pre></blockquote><p>
     */

    static final int FL_W = 1 << ('w'-0x60);

    /**
     * The state of the buffer: 0 = normal, 1 = inside the last but one
     * lexeme, 2 = at the end of it 3 = at start of last lexeme,
     * 4 = at the end of it, 5 = at the end of it and at the and of
     * a block as well. */
    private int state;

    /** 
     * Construct a lexer object.
     *
     * @param      inp input stream
     */

    ParserLexer(){
        }

    ParserLexer(Object inp){
        if (inp != null){
            this.stream = new BufReader(inp,2048);
        }
        this.mode |= SKIPWS | EXACT;
        this.lineNr = 1;
        this.prevCursor = -1;
        this.savedCursor = -1;
    }

    /** 
     * Reset a lexer object. The point and line are repositioned at the
     * beginning.
     */

    void reset(){
        this.lineNr = 1;
        this.point = 0;
        this.cursor = this.start = 0;
        this.length = 0;
        this.offset = 0;
        this.end = this.offset + this.length;
        this.buffer = null;
        this.state = 0;
        this.prevCursor = -1;
        this.savedCursor = -1;
    }

    /**
     * Trace a snapshot of the text which has not yet been scanned,
     * with the indication of the point.
     *
     * @param      s comment string
     */

    void trcBuffer(String s){
        Trc.out.println(s + ':');
        int len = this.end - this.cursor;
        if (len > 128) len = 128;
        Trc.out.println("\u00a4" +
            String.valueOf(this.buffer,this.cursor,len));
    }

    /**
     * Trace the buffer and the indexes.
     *
     * @param      s comment string
     */

    public void trace(String s){
        Trc.out.print(s + ": ");
        if (this.buffer != null){
            Trc.out.print("|");
            Trc.literalize(this.buffer,0,this.cursor);
            Trc.out.print("\u00a4");
            int len = this.end;
            if (this.savedEnd > end) len = this.savedEnd;
            len -= this.cursor;
            if (len > 70) len = 70;
            Trc.literalize(this.buffer,this.cursor,len);
            Trc.out.print("| ");
            if (this.prevCursor >= 0){
                Trc.out.print("[");
                Trc.literalize(this.buffer,this.prevCursor,this.prevLen);
                Trc.out.print("]");
            }
            if (this.savedCursor >= 0){
                Trc.out.print("{");
                Trc.literalize(this.buffer,this.savedCursor,this.savedLen);
                Trc.out.print("} ");
            }
        }
        Trc.out.println("prev: " + 
            this.prevCursor + ":.+" + this.prevLen +
                "(" + this.prevPoint + ")" +
            " saved: " + this.savedCursor + ":.+" + this.savedLen +
                "(" + this.savedPoint + ") end: " + this.savedEnd +
            " current: " + this.start + ".." +
                this.cursor + ":" + this.end + "(" + this.point + ")");
        Trc.out.println("state: " + this.state +
            "  length: " + this.length + " offset: " + this.offset);
    }

    /**
     * Deliver the position (index) in the source at which the last token
     * scanned starts. If it was recognized, it is its starting point,
     * it it was not recognized, it is the point at which recognizion
     * started.
     *
     * @return     absolute position
     */

    long getPoint(){
        return getPoint(this.start);
    }

    /**
     * Deliver the current position (index) in the source.
     *
     * @return     absolute position
     */

    long index(){
        return getPoint(this.cursor);
    }

    /**
     * Deliver the line of the position (index) in the source at which the
     * last token scanned starts, as delivered by <code>getPoint()</code>.
     *
     * @return     absolute position
     */

    long getLineNr(){
        return this.lineNr;
    }

    /**
     * Test if the input is at the end, skipping separators if any.
     *
     * @return     <code>true</code> if at eof
     */

    boolean eof(){
        gsep();
        if (this.cursor < this.end){
            return false;
        }
        return this.stream.eof();
    }

    /** 
     * Load the lexer buffer.
     *
     * @return     number of characters read
     */

    protected int fill(int save){
        if ((FL_V & this.trc) != 0){
            Trc.out.println("fill: " + save + " state " +
                this.state + " " + this.savedCursor + " " + this.length);
        }
        int n = 0;
        doit: if ((this.state == 0) ||                   // normal operation
            (this.state == 5)){
            this.state = 0;
            int delta = 0;
            if (this.savedCursor >= 0){
                this.stream.markPos = save - this.savedLen;
                System.arraycopy(this.buffer,this.savedCursor,
                    this.buffer,this.stream.markPos,
                    this.savedLen);
                delta = this.stream.markPos - this.savedCursor;
                if ((FL_V & this.trc) != 0){
                    Trc.out.print("shifted: |");
                    int ln = this.stream.buffer.length;
                    if (ln > 70) ln = 70;
                    Trc.literalize(this.stream.buffer,0,ln);
                    Trc.out.println("| " + this.stream.markPos +
                        " " + this.savedLen);
                }
            } else if (save < this.end){
                this.stream.markPos = this.start;
            }
            n = this.stream.readBlock();
            if ((FL_V & this.trc) != 0){
                Trc.out.println("load: " + n + " " +
                    this.stream.cursor + " " +
                    this.stream.end);
            }
            if (this.savedCursor >= 0){
                this.savedCursor = this.stream.markPos;
            }
            if (n < 0){
                break doit;                             // eof
            }
            if (this.savedCursor >= 0){
                 if (this.stream.markPos >= 0){
                     this.start = this.stream.markPos + this.savedLen;
                 }
            } else if (save < this.end){
                 if (this.stream.markPos >= 0){
                     this.start = this.stream.markPos;  // traspose start
                 }
            }
            this.buffer = this.stream.buffer;
            this.cursor = this.stream.cursor;
            this.offset = this.cursor;
            this.end = this.stream.end;
            this.length = this.end - this.cursor;
            this.point = this.stream.index - this.length;
        } else if (this.state == 1){
            n = -1;
            this.state = 2;
        } else if (this.state == 2){
            this.cursor = this.savedCursor;
            this.offset = this.cursor;
            this.end = this.savedCursor + this.savedLen;
            this.length = this.end - this.cursor;
            this.point = this.savedPoint;
            this.lineNr = this.savedLineNr;
            this.state = 3;
            n = this.end - this.cursor;
        } else if (this.state == 3){
            n = -1;
            this.state = 4;
        } else if (this.state == 4){
            this.end = this.savedEnd;
            this.length = this.end - this.offset;
            n = this.end - this.cursor;
            if (n == 0){
                n = -1;
                this.state = 5;
            } else {
                this.state = 0;
            }
        }
        if ((FL_V & this.trc) != 0){
            trace("loaded " + n);
            Trc.out.print("|");
            Trc.literalize(this.buffer,0,this.end);
            Trc.out.println("|");
            Trc.out.println("cursor: " + this.cursor +
                " end: " + this.end);
        }
        return n;
    }

    /** 
     * Load the lexer buffer without saving the previous contents.
     *
     * @return     number of characters read
     */

    protected int load(){
        return fill(this.end);
    }

    /** 
     * Append data to the lexer buffer.
     *
     * @return     number of characters read
     */

    protected int append(){
        if ((FL_V & this.trc) != 0){
            Trc.out.println("append: " + this.state);
        }
        if (this.state == 2) return -1;
        if (this.state == 4) return -1;
        return fill(this.start);
    }


    /** 
     * Make the lexer go back the specified number of lexemes.
     *
     * @param      n number
     */

    void backup(int n){
        if (this.cursor > this.start){    // a recognised one present
            if (this.state == 0){
                this.prevCursor = this.savedCursor;
                this.prevLen = this.savedLen;
                this.prevPoint = this.savedPoint;
                this.prevLineNr = this.savedLineNr;
                this.savedCursor = this.start;
                this.savedLen = this.cursor - this.start;
                this.savedEnd = this.end;
                this.savedPoint = this.point + this.start - this.offset;
                this.savedLineNr = this.lineNr;
            } else if (this.state == 1){
                this.state = 2;
            } else if (this.state == 3){
                this.state = 4;
            }
        }
        switch (n){
        case 1:
            if (this.state == 1){
                throw new IllegalStateException();
            }
            if ((this.state == 0) || (this.state == 4)){
                if (this.savedCursor == -1){
                    throw new IllegalStateException();
                }
                this.cursor = this.savedCursor;
                this.end = this.savedCursor + this.savedLen;
                this.offset = this.cursor;
                this.length = this.end - this.cursor;
                this.point = this.savedPoint;
                this.lineNr = this.savedLineNr;
                this.state = 3;
            } else {
                if (this.prevCursor == -1){
                    throw new IllegalStateException();
                }
                this.cursor = this.prevCursor;
                this.end = this.prevCursor + this.prevLen;
                this.offset = this.cursor;
                this.length = this.end - this.cursor;
                this.point = this.prevPoint;
                this.lineNr = this.prevLineNr;
                this.state = 1;
            }
            break;
        case 2:
            if (((1 <= this.state) && (this.state <= 3)) ||
                (this.prevCursor == -1)){
                throw new IllegalStateException();
            }
            this.cursor = this.prevCursor;
            this.end = this.prevCursor + this.prevLen;
            this.offset = this.cursor;
            this.length = this.end - this.cursor;
            this.point = this.prevPoint;
            this.lineNr = this.prevLineNr;
            this.state = 1;
            break;
        default:
            throw new Error();
        }
        this.start = this.cursor;        // disable gsep save
        if ((FL_V & this.trc) != 0){
            Trc.out.println("backup: " + n + " " + this.cursor +
                " " + this.end);
        }
    }

    /** 
     * Skip all separator spaces, including newlines. Make the lexer refer to
     * the first non separator character. Upon return, <code>cursor</code>
     * indicates the first non separator character.
     */

    public void gsep(){
        long lastPoint = 0;              // the current point

        if ((FL_V & this.trc) != 0){
            trace("gsep start");
        }
        if (this.cursor > this.start){   // a recognised one present
            if (this.state == 0){
                this.prevCursor = this.savedCursor;
                this.prevLen = this.savedLen;
                this.prevPoint = this.savedPoint;
                this.prevLineNr = this.savedLineNr;
                this.savedCursor = this.start;
                this.savedLen = this.cursor - this.start;
                this.savedEnd = this.end;
                this.savedPoint = this.point + this.start - this.offset;
                this.savedLineNr = this.lineNr;
            } else if (this.state == 1){
                this.state = 2;
            } else if (this.state == 3){
                this.state = 4;
            }
        }

        if ((SKIPWS & this.mode) == 0){
            this.start = this.cursor;
            return;
        }
        int savemark = this.stream.markPos;     // save mark
        char[] buffer = this.buffer;
        int cursor = this.cursor - 1;
        int end = this.end;

        this.start = -1;                        // force load() not to retain ..
        int state = 0;                          // .. chars in the buffer
        char prev = 0;
        loop: do {
            if (++cursor == end){               // no data
                int ch = load();
                if (ch < 0){
                    if (state == 1) cursor--;   // single slash at end
                    if (this.state == 0) break loop;
                    cursor--;                   // move from end of last
                    continue;                   // .. but one lexeme to next
                }
                end = this.end;
                buffer = this.buffer;
                cursor = this.cursor;
            }
            char c = buffer[cursor];
            switch (state){
            case 0:                             // normal
                switch (c){
                case '/':
                    state = 1;
                    this.stream.markPos = cursor;   // to reposition if followed
                    break;                          // .. by chars not / or *
                case ' ': case '\t':
                    break;
                case '\r': case '\n': case '\f':
                    break;
                case '*':
                    state = 6;
                    break;
                default:
                    state = -1;
                    break loop;
                }
                break;
            case 1:                             // slash found
                switch (c){
                case '/':
                    state = 3;                  // line-end comment
                    break;
                case '*':
                    lastPoint = getPoint(cursor-1);   // for error reporting
                    state = 4;                  // comment
                    break;
                default:
                    cursor--;
                    this.stream.markPos = savemark;
                    state = -1;
                    break loop;
                }
                this.stream.markPos = savemark;
                break;
            case 3:                             // line-end comment
                switch (c){
                case '\r': case '\n': case '\f':
                    state = 0;
                    break;
                }
                break;
            case 4:                             // comment
                switch (c){
                case '*':
                    state = 5;                  // comment *
                    break;
                }
                break;
            case 5:                             // comment *
                switch (c){
                case '/':
                    state = 0;                  // comment * /
                    break;
                default:
                    state = 4;                  // back to comment
                }
                break;
            case 6:                             // * found
                switch (c){
                case '/':                             // close comment not open
                    lastPoint = getPoint(cursor-1);   // for error reporting
                    break loop;
                default:
                    cursor--;
                    this.stream.markPos = savemark;
                    state = -1;
                    break loop;
                }
            }
            switch (c){
            case '\n': case '\f':
                if (prev == '\r') break;
            case '\r':
                this.lineNr++;
            }
            prev = c;
        } while (true);
        this.cursor = cursor;
        this.start = cursor;                    // start of next token
        this.stream.markPos = savemark;
        if ((state > 1) && (state != 3)){       // for // xxxx eof
            this.mode |= ERROR;                 // comment not closed
            int err = state == 6 ? ERR_COMNOP :
                ERR_COMNCL;
            message(err,"",lastPoint,null);
            throw this.excObj;
        }
        this.mode &= ~ERROR;                    // no errors
        if ((FL_V & this.trc) != 0){
            trace("gsep return: " + this.cursor + " " + this.lineNr);
        }
        return;
    }

    /**
     * Skip a character (possibly after separators).
     *
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    boolean skipch(){
        if ((FL_V & this.trc) != 0){
            trace("skipch start");
        }
        boolean found = true;
        gsep();                       // skip separators
        if (this.cursor < this.end){
            this.cursor++;            // step to next
        } else {
            found = false;
        }
        if ((FL_V & this.trc) != 0){
            trace("skipch return",found);
        }
        return found;
    }

    /**
     * Get a non-terminal and report an error if it is malformed.
     *
     * @see        Lexer.gntr(Str)
     */

    public boolean gntr(Str s){
        boolean found = true;
        doit: if (!super.gntr(s)){
            found = false;
        } else if ((ERROR & this.mode) != 0){
            message(ParserLexer.ERR_NTNCL,
                "",getPoint(this.start),null);
        }
        return found;
    }

    /**
     * Get a string and report an error if it is malformed.
     *
     * @see        Lexer.gjstr(Str)
     */

    public boolean gjstr(Str s){
        boolean found = true;
        doit: if (!super.gjstr(s)){
            found = false;
        } else if ((ERROR & this.mode) != 0){
            message(ParserLexer.ERR_STRNCL,
                "",getPoint(this.start),null);
        }
        return found;
    }

    /**
     * Get a number and report an error if it is malformed.
     *
     * @see        Lexer.gdec(Str)
     */

    public boolean gdec(Str s){
        boolean found = true;
        doit: if (!super.gdec(s)){
            found = false;
        } else if (((ERROR | OVERFLOW) & this.mode) != 0){
            message(ParserLexer.ERR_ILLNUM,
                "",getPoint(this.start),null);
        }
        return found;
    }

    /** The table of reserved words. */

    static final String[] KEYTABLE = {
        "ALPHABET",
        "END",
        "GRAMMAR",
        "LEXIS",
        "TERMINALS",
        "PRECEDENCE",
        "OPTIONS",
    };
    static {
        Arrays.sort(KEYTABLE);
    }

    /** The table of special terminals. */

    static final String[] TERTABLE = {
        "BOL",
        "BOS",
        "EOL",
        "EOS",
    };
    static {
        Arrays.sort(TERTABLE);
    }

    /** The table of meta symbols. */

    static final String[] METATABLE = {
        "{",
        "[",
        "]",
        "|",
        "=>",
        "==",
        "={",
//        "~{",
//        "-{",
//        ":{",
        "::=",
//        "#{",
        "..",
        ".",
        "}*",
        "}+",
        "}",
        "<>",
        "<",
        ">",
        "-",
        "!",
        "^",
        "&",
        "~",
        "(",
        ")",
    };
    static {
        Arrays.sort(METATABLE);
    }

    /** 
     * Match a meta-symbol.
     *
     * @return     length of the lexeme, 0 if not found
     */

    private int meta(){
        if (this.cursor >= this.end){
            if (append() < 0){               // end of data
                return 0;
            }
        }
        int m = 0;
        int i = 0;
        int tlen = METATABLE.length;
        int ini = this.cursor - this.start;
        sea: for (; i < tlen; i++){          // scan the table
            this.cursor = this.start + ini;
            char c = this.buffer[this.cursor++];
            String key = METATABLE[i];
            int len = key.length();
            int j = 0;
            for (;;){                        // match current entry
                if (c != key.charAt(j++)) continue sea;
                if (j >= len) break;
                if (this.cursor >= this.end){
                    if (append() < 0){       // end of data
                        continue sea; 
                    }
                }
                c = this.buffer[this.cursor++];
            }
            if (len > m) m = len;            // remember longest
        }
        this.cursor = this.start + ini;
        return m;
    }

    /**
     * Get a given meta symbol. The longest match rule is applied.
     *
     * @param      s meta symbol
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean gmet(String s){
        if ((FL_V & this.trc) != 0){
            trace("gmet start");
        }
        boolean found = false;
        gsep();                                   // skip separators
        doit: {
            int m = meta();
            if (m > 0){                           // found a meta
                cmp: if (m == s.length()){
                    int j = this.start;
                    for (int i = 0; i < m; i++){
                        if (this.buffer[j++] != s.charAt(i)) break cmp;
                    }
                    this.cursor += m;             // found
                    found = true;
                    break doit;
                }
            }
        }
        if ((FL_V & this.trc) != 0){
            trace("gmet return",found);
        }
        return found;
    }

    /**
     * Get a meta symbol. The longest match rule is applied.
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean gmet(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gmet start");
        }
        boolean found = false;
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        doit: {
            int m = meta();
            if (m > 0){                       // found a meta
                for (int i = 0; i < m; i++){
                    char c = this.buffer[this.cursor];
                    if (s.length == s.buffer.length){
                        s.extend();
                    }
                    s.buffer[s.length++] = c; // append
                    this.cursor++;            // step to next
                }
                found = true;
            }
        }
        if ((FL_V & this.trc) != 0){
            trace("gmet return",found);
        }
        return found;
    }

    /**
     * Get a non-meta, i.e. sequence of printable characters (except `"'),
     * that is ended by a space, or a meta-symbol.
     *
     * @param      s string in which the token is returned
     * @return     0 if not found, 1 if an ordinary one found, 2 if a special
     *             non terminal found. In the latter two cases <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public int gnme(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gnme start");
        }
        int res = 0;
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        doit: do {
            if (this.cursor >= this.end){
                if (append() < 0){            // end of data
                    break;
                }
            }
            char c = this.buffer[this.cursor];
            if ((c != '!')){                  // all printables except "
                if ((c < '#') ||              // non allowed range
                    ('~' < c)) break;
            }
            int mt = meta();
            if (mt > 0) break;                // meta character
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] = c;         // append
            this.cursor++;                    // step to next
        } while (true);
        kw: if (this.cursor > this.start){
            if (searchKey(TERTABLE,0,         // check if special terminal
                TERTABLE.length,s,false) >= 0){
                res = 2;
                break kw;
            }
            if (searchKey(KEYTABLE,0,         // check if keyword
                KEYTABLE.length,s,false) >= 0){
                this.cursor = this.start;
                s.length = 0;
                break kw;
            }
            if (s.length > 0) res = 1;
        }
        if ((FL_V & this.trc) != 0){
            trace("gnme return",res > 0);
        }
        return res;
    }

    /**
     * Get a character.
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    private boolean gchar(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gchar start");
        }
        boolean found = true;
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        doit: {
            if (this.cursor >= this.end){
                if (append() < 0){            // end of data
                    break doit;
                }
            }
            char c = this.buffer[this.cursor];
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] = c;         // append
            this.cursor++;                    // step to next
            found = true;
        }
        if ((FL_V & this.trc) != 0){
            trace("gchar return",found);
        }
        return found;
    }

    /* Messages. */

    /** The exception object. */
    public ParserError excObj;

    /** The last element of the exception list. */
    public ParserError excLast;

    /** The number of informationals. */
    public int infcnt;

    /** The number of warnings. */
    public int warcnt;

    /** The number of errors. */
    public int errcnt;

    /** The number of fatals. */
    public int fatcnt;

    /**
     * An error. Errors are recorded as a list of failures because they
     * allow to keep all the data, including the additional exceptions
     * which occurred. Callers can then scan the list and file the elements
     * to a Listing.
     */

    public static class ParserError extends Failure {

        /** The reference to the next error. */
        public ParserError next;

        /* The position of the error. */
        public long post;

        /* The additional text. */
        public String txta;

        /**
         * Create a ParserError.
         *
         * @param      c error code
         * @param      x exception
         */

        ParserError(int c, Throwable x){
            super(c,'F',"PARSER",x,        // message describing result
                ParserBundle.MSGTAB[c],null,null);
        }

        /**
         * Deliver the strings representing the failure.
         *
         * @param      loc locale, null if no locale
         * @return     strings
         */

        public String[] getMessages(Locale loc){
            Locale l = loc;
            if (loc == null) l = Locale.getDefault();
            if (this.bundle != null){            // bundle present
                ResourceBundle bun =
                    ResourceBundle.getBundle(this.bundle,l);
                return new String[] {header(this.subSystem,this.kind) +
                    ((String[])(bun.getObject("MSGTAB")))[this.code] +
                    String.valueOf(this.txta) + " " + this.post};
            } else {
                return new String[] {header(this.subSystem,this.kind) +
                    this.getMessage() +
                    String.valueOf(this.txta) + " " + this.post};
            }
        }
    }

    /** The eof position for messages. */
    public static final long MSG_AT_EOF = Long.MAX_VALUE;

    /* The constants representing the error codes. */

    /* Informationals. */

    /** Successful operation. */
    public static final int SUCCESS =  0;

    /* Warnings. */

    /** A malformed token has been encountered. */
    public static final int ERR_BADTOK = 2;

    /** The sentence has not been recognised. */
    public static final int ERR_NOREC = 3;

    /** The string is not closed. */
    public static final int ERR_STRNCL = 5;

    /** A line which is too long has been encountered. */
    public static final int ERR_BADLIN = 6;

    /** No terminal string is produced. */
    public static final int ERR_DEADEND = 7;

    /** The symbol is not generated from the start symbol. */
    public static final int ERR_NOGEN = 8;

    /** The text has been skipped. */
    public static final int ERR_SKIP = 9;

    /** A multiple occurrence is present. */
    public static final int ERR_MULOCC = 10;

    /** The nonterminal is not closed. */
    public static final int ERR_NTNCL = 11;

    /** The element is useless. */
    public static final int ERR_ULESS = 12;

    /** The symbol id defined in LEXIS, but is not a lexeme. */
    public static final int ERR_NOLEX = 13;

    /** The alternative produces no terminal strings. */
    public static final int ERR_DEADALT = 14;

    /** The definition hides a nonterminal. */
    public static final int ERR_HIDNT = 15;

    /** The input is illegal. */
    public static final int ERR_EXERR = 17;

    /** TERMINALS used in it, ignored. */
    public static final int ERR_TRMERR = 18;

    /* Errors. */

    /** The input has ended, but something was expected. */
    public static final int ERR_PREEND = 19;

    /** Some characters are still present, but not expected. */
    public static final int ERR_EXCCHAR = 20;

    /** An illegal statement has been encountered. */
    public static final int ERR_ILLSTMT = 21;

    /** A multiple definition has been encountered. */
    public static final int ERR_MULDEF = 22;

    /** A token was expected, but it missing. */
    public static final int ERR_MISTOK = 23;

    /** The factor is illegal. */
    public static final int ERR_MISFAC = 24;

    /** A non-terminal was expected, but it is missing. */
    public static final int ERR_MISNT = 25;

    /** A number was expected, but it is missing. */
    public static final int ERR_MISNUM = 26;

    /** A symbol of one character was expected. */
    public static final int ERR_NOTCHAR = 27;

    /** A name was expected, but it is missing. */
    public static final int ERR_MISNAM = 28;

    /** A terminal was expected, but it is missing. */
    public static final int ERR_MISTER = 29;

    /** The definition is circular. */
    public static final int ERR_CIRCDEF = 30;

    /** The lexeme is used in an illegal way. */
    public static final int ERR_LEXUSE = 31;

    /** An element was expected, but it is missing. */
    public static final int ERR_MISEL = 32;

    /** The lexeme is undefined. */
    public static final int ERR_UNLEX = 33;

    /** The non-terminal is multiply defined. */
    public static final int ERR_MULNTR = 34;

    /** The non-terminal is undefined. */
    public static final int ERR_UNDEF = 35;

    /** The production duplicates another one. */
    public static final int ERR_DUPPROD = 36;

    /** The symbol does not replace itself. */
    public static final int ERR_NOUSE = 37;

    /** The symbol replace a non-terminal already replaced. */
    public static final int ERR_MULREP = 38;

    /** A syntax non-terminal is used. */
    public static final int ERR_SYNNT = 39;

    /** The lexicon is not regular. */
    public static final int ERR_NREG = 40;

    /** The constraint is useless. */
    public static final int ERR_DISEXP = 41;

    /** The syntax or the value of the number are incorrect. */
    public static final int ERR_ILLNUM = 42;

    /** The construct is not allowed here. */
    public static final int ERR_NACONS = 43;

    /** The definition is illegal. */
    public static final int ERR_ILLDEF = 44;

    /** The specified element is not allowed in this place. */
    public static final int ERR_NOTALL = 45;

    /** The lexeme produces the empty string or no string. */
    public static final int ERR_EMPLEX = 46;

    /** The range is empty. */
    public static final int ERR_EMPRNG = 47;

    /** The case-insensitivity clause is not allowed on this element. */
    public static final int ERR_CASEIN = 48;

    /** The symbol does not belong to the defined alphabet. */
    public static final int ERR_OUTALPHA = 49;

    /** The autoreference is present in an operand. */
    public static final int ERR_ILLAUTO = 50;

    /** The construct does not represent a set of characters. */
    public static final int ERR_NOTSET = 51;

    /** A keyword was expected, but it is missing. */
    public static final int ERR_MISKEY = 52;

    /** The grammar contains conflicts. */
    public static final int ERR_CONFLGR = 53;

    /* Fatals. */

    /** No memory is available. */
    public static final int ERR_NOCORE = 60;

    /** An unexpected line has been encountered. */
    public static final int ERR_UNEXLIN = 61;

    /** The grammar is empty. */
    public static final int ERR_EMPTYG = 62;

    /** GRAMMAR is missing. */
    public static final int ERR_MISGRA = 63;

    /** An i/o error has been encountered. */
    public static final int ERR_IOERR = 64;

    /** The start non-terminal is missing. */
    public static final int ERR_NOTSTART = 65;

    /** The start non-terminal is undefined. */
    public static final int ERR_UNDEFS = 66;

    /** An error on the listing has occurred. */
    public static final int ERR_LISTING = 67;

    /** A value out of the allowed limits has been found. */
    public static final int ERR_OUTLIMIT = 68;

    /** An illegal trace flag has been specified. */
    public static final int ERR_TRCFLAG = 69;

    /** The starting symbol does not produce terminal strings. */
    public static final int ERR_NOUSEST = 70;

    /** The comment is not closed. */
    public static final int ERR_COMNCL = 71;

    /** The lexer generator cannot generate a so large lexer. */
    public static final int ERR_EXCLEX = 72;

    /** The parser generator cannot generate a so large parser. */
    public static final int ERR_EXCPRS = 73;

    /** The grammar contains errors. */
    public static final int ERR_ERRGRA = 74;

    /** The cpu time cannot be measured. */
    public static final int ERR_NOCPUT = 75;

    /** The comment is not open. */
    public static final int ERR_COMNOP = 76;

// use the same technique used in jpre to determine the ranges of indexes of messages
    /**
     * Register an error.
     *
     * @param      n number of the error
     * @param      t string of additional text
     * @param      p position
     * @param      x exception
     */

    void message(int n, String t, long p, Throwable x){
        char k;
        if (n <= 1){
            k = 'I';
            this.infcnt += 1;
            if (this.infcnt < 0) this.infcnt--;
        } else if ((2 <= n) && (n <= 18)){
            k = 'W';
            this.warcnt += 1;
            if (this.warcnt < 0) this.warcnt--;
        } else if ((19 <= n) && (n <= 59)){
            k = 'E';
            this.errcnt += 1;
            if (this.errcnt < 0) this.errcnt--;
        } else {
            k = 'F';
            this.fatcnt += 1;
            if (this.fatcnt < 0) this.fatcnt--;
        }
        try {
            ParserError m = new ParserError(n,x);
            if (this.excObj == null) this.excObj = m;   // add to list
            else this.excLast.next = m;
            this.excLast = m;
            m.kind = k;
            m.post = p;
            m.txta = t;
        } catch (OutOfMemoryError exc){
            ParserError curr = this.excObj;       // pointer to first element
            if (curr != null){
                for (int i = 0; i < 100; i++){    // keep 100 only
                    if (curr.exc == null) break;
                    curr = curr.next;
                }
                curr.exc = null;
            }
            throw exc;
        }            
        if ((FL_W & this.trc) != 0){
            Trc.out.println("message " + n + " " + p);
            if (x != null) x.printStackTrace(Trc.out);
        }
    }

    /**
     * Register an error.
     *
     * @param      n number of the error
     * @param      t string of additional text
     * @param      p position
     */

    void message(int n, String t, long p){
        message(n,t,p,null);
    }

    /**
     * Register an error if one equal to it is not present in the
     * specified tail of the list of errors.
     *
     * @param      n number of the error
     * @param      t string of additional text
     * @param      p position
     * @param      m reference to the first element of the tail of the list
     */

    void messageNoDup(int n, String t, long p, ParserError m){
        if (m == null) m = this.excObj;      // it was the first one
        for (; m != null; m = m.next){
            if ((m.code == n) && (m.post == p) &&
                (m.txta == t)) return;
        }
        message(n,t,p);
    }

    /**
     * Register an error at the start of the current token.
     *
     * @param      n number of the error
     * @param      t string of additional text
     */

    void message(int n, String t){
        message(n,t,getPoint());
    }

    /**
     * Register an error at the start of the current token.
     *
     * @param      n number of the error
     */

    void message(int n){
        message(n,null);
    }
}
