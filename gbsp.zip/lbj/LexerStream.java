/*
 * @(#)LexerStream.java       1.0 98/11/04
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

/**
 * The <code>LexerStream</code> class provides lexical analysis on
 * a <code>BufReader</code>.
 *
 * @author  Angelo Borsotti
 * @version 1.0   04 Nov 1998
 */

public class LexerStream extends Lexer {

    /** The stream. */
    public BufReader stream;

    /** 
     * Load the lexer buffer without saving the previous contents.
     *
     * @return     number of characters read
     */

    protected int load(){
        this.stream.markPos = -1;
        return fill();
    }

    /** 
     * Load the lexer buffer.
     *
     * @return     number of characters read
     */

    protected int fill(){
        int n = this.stream.readBlock();
        if ((FL_V & this.trc) != 0){
            Trc.out.println("load: " + n + " " +
                this.stream.cursor + " " +
                this.stream.end);
        }
// this was so, but it is wrong: the readBlock above shuffles
// the buffer, and therefore there is a need to update the cursors
//        if (n < 0){
//            return -1;                           // eof
//        }
        if ((FL_V & this.trc) != 0){
            Trc.out.print("loaded: |");
            Trc.literalize(this.stream.buffer,0,
                this.stream.end);
            Trc.out.println("| " + this.stream.cursor);
        }
        this.buffer = this.stream.buffer;
        this.cursor = this.stream.cursor;        // traspose cursor
        this.offset = this.cursor;
        this.end = this.stream.end;
        this.length = this.end - this.cursor;
        this.point = this.stream.index - this.length;
        if (n < 0){
            return -1;                           // eof
        }
        return n;
    }

    /** 
     * Append data to the lexer buffer.
     *
     * @return     number of characters read
     */

    protected int append(){
        this.stream.markPos = this.start;
        int n = fill();
        this.start = this.stream.markPos;
        return n;
    }

    /** 
     * Restore the lexer to the start of the current, non-recognised, lexeme.
     *
     * @param      n offeset with respect to start
     */

    public void restore(){
       this.cursor = this.start;
       this.stream.unmark();
    }

    /** 
     * Reposition the stream to allow other methods to take over scanning.
     */

    public void reposition(){
        this.stream.markPos = this.cursor;
        this.cursor = this.end;
        this.stream.reset(0);
        this.stream.markPos = -1;
    }
}
