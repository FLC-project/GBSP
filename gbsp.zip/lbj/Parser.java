/*
 * @(#)Parser.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;
import java.lang.reflect.*;
import lbj.Cli;
import lbj.Cli.*;
import lbj.IoStream;
import lbj.IoStream.*;
import lbj.Listing.*;
import lbj.ParserNode.*;
import lbj.ParserGrammar.*;
import lbj.ParserLexer.*;

/**
 * The <code>Parser</code> class provides a general purpose parser.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

/**
 * This class provides a general purpose parser and parser generator.
 * <p>
 * In the simplest case, a string can be parsed creating a parser and passing a grammar and
 * a string to it, then obtaining a parse tree.
 * In the more complex case, the parser tables can be generated from a grammar read from a
 * text file, and serialized for later use. Then, a text from a file can be parser creating
 * a parser for the serialized tables and passing the text file name to it.
 * There are two operations to be done in order to parse a string:
 * <p>
 * <ol>
 * <li>generation of the parse tables</li>
 * <li>parse a string</li>
 * </ol>
 * <p>
 * Here are a number of typical use cases:
 * <ul>
 * <li>simplest case: small grammar, small text, both strings:
 *    <pre>
 *    Parser p = new Parser(grammar,text);
 *    // access the tree stored in p
 *    </pre>
 * <li>parsing several strings:
 *    <pre>
 *    Parser p = new Parser(grammar);
 *    p.parse(text1);
 *    // access the tree
 *    p.parse(text2);
 *    </pre>
 * <li>grammar in a text file:
 *    <pre>
 *    Parser p = new Parser(file);
 *    </pre>
 * <li>text in a file:
 *    <pre>
 *    p.parse(file);
 *    </pre>
 * <li>use of a dedicated lexer:
 *    <pre>
 *    ParserLex lex = new MyLexer(p.getTables());
 *    p.setLexer(lex);
 *    p.parse(file);
 *    </pre>
 * <li>serialized grammar:
 *    <pre>
 *    Parser p = new Parser(grammar);   // grammar: string or file
 *    p.serialize(file);
 *    </pre>
 *    or use the command-line Parser:
 *    <pre>
 *    java -cp .. -Xmx1g -Xss2m lbj.Parse grammar /out=serialized.ser
 *    </pre>
 *    then use it:
 *    <pre>
 *    Parser p = new Parser(serialized);
 *    p.parse(text)          
 *    </pre>
 * <li>specifying parser options:
 *    <pre>
 *    Parser p = new Parser(grammar,Parser.FOREST)
 *    </pre>
 * </ul>
 * <p>
 * After each operation, <code>p.errorList</code> indicates the success (if <code>null</code>
 * or failure (otherwise, in which case it contais a list of errors).
 *
 * <p>
 * The syntax and semantics of the grammar declaration are described
 * in the following sections.
 *
 * <h4>Declarations</h4>
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dt><b>Syntax:</b></tr>
 * <tr><td><dd><i>&lt;declarations&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp; <i>&lt;grammar&gt;</i>
 *     [ <i>&lt;constants declaration&gt;</i> ]
 *     [ <i>&lt;translation skeme&gt;</i> ]
 *     [ <i>&lt;examples&gt;</i> ] <td align=right>(1.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * The parser generator processes a <i>grammar</i> and generates a parser
 * (and a lexer) for it.
 * <p>
 * If a <i>constants declaration</i> is specified, it generates also a
 * source file that contains the declaration of constants for the grammar
 * symbols to be used in applications.
 * <p>
 * If a <i>translation skeme</i> is specified, it generates also a
 * translation skeme.
 * <p>
 * If an <i>examples</i> is specified, it parses the example texts and
 * reports on the listing the results.
 * </table>
 *
 * <h4>Grammar</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dt><b>Syntax:</b></tr>
 * <tr><td><dd><i>&lt;grammar&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;[ <i>&lt;grammar prelude&gt;</i> ]
 *     { <i>&lt;production&gt;</i> }<sup>+</sup>
 *     [ <i>&lt;lexis&gt;</i> ] [ <i>&lt;options&gt;</i> ] [ <b>END</b> ]<td align=right>(1.1)</tr>
 * <tr><td><dd><i>&lt;grammar prelude&gt;</i> ::=<td align=right>(2)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<b>GRAMMAR</b>
 *     [ "<code>{</code>"<i>&lt;start&gt;</i>
 *     [ EBNF [ <i>&lt;empty notation&gt;</i> ] ] "<code>}</code>" ]
 *     <td align=right>(2.1)</tr>
 * <tr><td><dd><i>&lt;empty notation&gt;</i> ::=<td align=right>(3)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;nonterminal&gt;
 *     <td align=right>(3.1)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;string&gt;</i> <td align=right>(3.2)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;non-meta&gt;</i> <td align=right>(3.3)</tr>
 * <tr><td><dd><i>&lt;options&gt;</i> ::=<td align=right>(4)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<b>OPTIONS</b>
 *     <i>&lt;option&gt;</i>
 *     {"<code>,</code>" <i>&lt;option&gt;</i> }<sup>*</sup><td align=right>(4.1)</tr>
 * <tr><td><dd><i>&lt;option&gt;</i> ::=<td align=right>(5)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;string&gt;</i><td align=right>(5.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * A grammar declaration consists of an optional prelude followed by one
 * or more productions, optionally followed by a lexis declaration.
 * <p>
 * The <i>start</i> defines the starting symbol. If no <i>start</i> is
 * present, the starting symbol is the <i>defining occurrence</i> in
 * the first <i>production</i>.
 * <p>
 * If <code>EBNF</code> is specified, multiple <i>production</i>s with
 * the same <i>defining occurrence</i> in them are allowed. They are
 * considered to be implicitly replaced by one production with one alternative
 * for each <i>expression</i> present in them.
 * <p>
 * If an <i>empty notation</i> is specified, that notation can be used
 * to denote the empty string. A grammar containing occurrences of
 * <i>empty notation</i>s is equivalent to one in which such occurrences
 * have been replaced by <code>""</code>
 * <p>
 * The <i>options</i> convey information regarding the grammar or the parser
 * generator. Currently, only the "<code>-tokenSets</code>" option is defined.
 * It specifies that a user-defined lexer must disregard the token sets that
 * denote the sets of tokens that share the same lexemes (i.e. that are
 * ambiguous).
 * 
 * <tr><td><dt><b>Static conditions:</b></tr><tr><td colspan=2><dl><dd>
 * The <i>start</i> symbol may not be equal to the <i>empty notation</i>.
 * It must occur as <i>defining occurrence</i> in a <i>production</i>.
 * <p>
 * The same <i>option</i> cannot be specified more than once, and it must
 * be one among the defined ones.
 * </table>
 *
 * <h4>Productions</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dt><b>Syntax:</b></tr>
 * <tr><td><dd><i>&lt;production&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;defining occurrence&gt;</i>
 *     "<code>::=</code>" <i>&lt;expression&gt;</i> [ <code>.</code> ]
 *     <td align=right>(1.1)</tr>
 *
 * <tr><td><dd><i>&lt;defining occurrence&gt;</i> ::=<td align=right>(2)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;nonterminal&gt;</i>
 *     <td align=right>(2.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * A <i>production</i> defines a rewriting rule and associates it to
 * the <i>defining occurrence</i> in it. The <i>defining occurrence</i> is
 * also called "left-hand-side" (LHS) and the <i>expression</i> "right-hand-side"
 * (RHS).
 * <p>
 * Productions can be specified in any order.
 * <p>
 * Productions can optionally be terminated by a dot (&lsquo;<code>.</code>&rsquo;) symbol.
 *
 * <tr><td><dt><b>Static conditions:</b></tr><tr><td colspan=2><dl><dd>
 * The <i>nonterminal</i> defined by a production must be derivable from the
 * start symbol and must not be the same as that of the <i>empty notation</i>.
 * <p>
 * A production must produce at least a terminal string, possibly the
 * empty string.
 * <p>
 * A production which is a <b>token rule</b> must not produce the empty string.
 * </table>
 *
 * <h4>Expressions</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dt><b>Syntax:</b></tr>
 * <tr><td><dd><i>&lt;expression&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;[ <i>&lt;alternative&gt;</i>
 *     { "<code>|</code>" <i>&lt;alternative&gt;</i> }<sup>*</sup> ]
 *     <td align=right>(1.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * An <i>expression</i> produces the set of strings which is the union of
 * the sets of strings produced by the <i>alternative</i>s which occur in it.
 * An <i>expression</i> which is empty produces the empty string.
 * <p>
 * Operators can occur in <i>expression</i>s. They are left associative
 * (e.g. op1 - op2 - op3 is interpreted as {op1 - op2} - op3), and have
 * the following precedence (highest first):
 * <table><tr><td><i>kind</i></td><td><i>operator</i></td></tr>
 * <tr><td>groups</td><td><code>{}</code>, <code>[]</code>,
 *                        <code>{}*</code>, <code>{}+</code></td></tr>
 * <tr><td>case clauses</td><td><code>(i)</code>, <code>(f)</code></td></tr>
 * <tr><td>unary operators</td><td><code>!</code>, <code>^</code>, <code>~</code></td></tr>
 * <tr><td>concatenation</td><td></td></tr>
 * <tr><td>binary operators</td><td><code>-</code>, <code>&</code></td></tr>
 * <tr><td>alternation, ranges</td><td><code>|</code>, <code>| .. |</code></td></tr>
 * </table>
 *
 * <tr><td><dt><b>Static conditions:</b></tr><tr><td colspan=2><dl><dd>
 * All <i>alternative</i>s in an <i>expression</i> must be different.
 * Two <i>alternative</i>s are equal if they are both or both are not
 * <i>range</i>s. In the former case, they are equal if they have the same
 * <i>subexpression</i>s in them, in which <i>directive</i>s are not taken into
 * account. In the latter case they are the same if the <i>range</i>s have
 * the same <i>subexpression</i>s in them.
 * N.B. equal alternatives are not allowed because the productions are
 * a set of V<sub>N</sub> &times; V<sup>*</sup> (being V<sub>N</sub> the
 * nonterminal vocabulary and V the total one) and sets have no duplicates.
 *
 * <tr><td><dt><b>Examples:</b></tr><tr><td colspan=2><dl><dd>
 * <code>a | b</code> denotes the strings "<code>a</code>" and "<code>b</code>".
 * </table>
 *
 * <h4>Alternatives</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dt><b>Syntax:</b></tr>
 * <tr><td><dd><i>&lt;alternative&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;{ <i>&lt;subexpression&gt;</i>
 *      | <i>&lt;range&gt;</i>} [<i>&lt;priority&gt;</i>]
 *      <td align=right>(1.1)</tr>
 *
 * <tr><td><dd><i>&lt;range&gt;</i> ::=<td align=right>(2)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;subexpression&gt;</i>
 *      "<code>|</code>" "<code>..</code>" "<code>|</code>"
 *      <i>&lt;subexpression&gt;</i><td align=right>(2.1)</tr>
 *
 * <tr><td><dd><i>&lt;priority&gt;</i> ::=<td align=right>(3)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>(prio</code>
 *      [ <code>:</code> <i>&lt;integer&gt;</i>] <code>)</code>
 *      <td align=right>(3.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * An <i>alternative</i> produces the strings of the <i>subexpression</i> or
 * the <i>range</i> which occur in it.
 * <p>
 * A <i>range</i> produces the set of symbols made of all the symbols
 * from the one denoted by the first <i>subexpression</i> and the second one
 * inclusive.
 * <p>
 * When a sentence has have several parse trees with the same number of terminals,
 * ambiguity is solved by taking the alternative which has the highest <b>priority</b> when
 * different, and the earliest alternative when equal.
 * Priority is ineffective when specified on <b>lexicon rule</b>s.
 *
 * <tr><td><dt><b>Static conditions:</b></tr><tr><td colspan=2><dl><dd>
 * The <i>subexpression</i>s in a <i>range</i> must denote characters, and
 * the first one precede or be the same as the second one in the Unicode
 * ordering.
 * The <i>expression</i> in which a <i>range</i> lies must occur in a
 * <b>lexicon rule</b>.
 * <p>
 * If a <i>range</i> lies in a <i>production</i>, the <i>nonterminal</i>
 * defined in it must not occur directly or indirectly in its
 * <i>subexpression</i>s.
 * <p>
 * An alternative must produce at least a terminal string, possibly the
 * empty string.
 * <p>
 * The <b>priority</b> must be equal or greater than zero and lower than 64k.
 *
 * <tr><td><dt><b>Static properties:</b></tr><tr><td colspan=2><dl><dd>
 * An <i>alternative</i> has a <b>priority</b>, which is that of the 
 * <i>priority</i>, if specified, and zero otherwise.
 * <p>
 * A <i>priority</i> has a <b>priority</b> that is the value of the <i>integer</i>
 * in it, and one otherwise.
 *
 * <tr><td><dt><b>Examples:</b></tr><tr><td colspan=2><dl><dd>
 * <code>a | .. | c</code> &nbsp; denotes the strings "<code>a</code>",
 * "<code>b</code>" and "<code>c</code>".
 * </table>
 *
 * <h4>Subexpressions</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dd><i>&lt;subexpression&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;sequence&gt;</i>
 *     <td align=right>(1.1)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;subexpression&gt;</i>
 *     <i>&lt;binary operator&gt;</i> <i>&lt;sequence&gt;</i>
 *     <td align=right>(1.2)</tr>
 *
 * <tr><td><dd><i>&lt;binary operator&gt;</i> ::=<td align=right>(2)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;"<code>-</code>" | "<code>&amp;</code>"
 *     <td align=right>(2.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * If a <i>binary operator</i> is specified, a <i>subexpression</i> produces
 * the set of strings which is the difference (<code>-</code>) or the
 * intersection (<code>&amp;</code>) of the sets of strings produced
 * by the <i>subexpression</i> and the <i>sequence</i> which occur in it,
 * otherwise it produces the strings of the <i>sequence</i> in it.
 *
 * <tr><td><dt><b>Static conditions:</b></tr><tr><td colspan=2><dl><dd>
 * The <i>expression</i> in which a <i>binary operator</i> lies must occur in a
 * <b>lexicon rule</b>.
 * <p>
 * If a <i>binary operator</i> lies in a <i>production</i>, the
 * <i>nonterminal</i> defined in it must not occur directly or indirectly
 * in the <i>subexpression</i> and <i>sequence</i> in it.
 *
 * <tr><td><dt><b>Examples:</b></tr><tr><td colspan=2><dl><dd>
 * <code>{a | .. | c} - b</code> denotes the strings "<code>a</code>" and
 * "<code>c</code>".
 * </table>
 *
 * <h4>Sequences</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dd><i>&lt;sequence&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;term&gt;</i>
 *     { [<i>&lt;priority&gt;</i>] <i>&lt;term&gt;</i> }<sup>*</sup>
 *     <td align=right>(1.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * A <i>sequence</i> produces the string made by the concatenation of the
 * strings produced by the <i>term</i>s in it.
 * <p>
 * When a sentence has several parse trees due to different matches
 * of terms, ambiguity is solved by taking the one in which
 * the <i>term</i> which has the higher <b>priority</b> generates the longer
 * text. When there are several terms with the same priority, the one in which
 * the earlier <i>term</i> is taken. If such terms generate texts of the same
 * length, the terms with decreasing priorities are taken.
 *
 * <tr><td><dt><b>Static properties:</b></tr><tr><td colspan=2><dl><dd>
 * A <i>term</i> has a <b>priority</b>, which is that of
 * the <i>priority</i>, if specified, and zero otherwise.
 *
 * <tr><td><dt><b>Examples:</b></tr><tr><td colspan=2><dl><dd>
 * <code>a b c</code> &nbsp; denotes the string "<code>abc</code>".
 * </table>
 *
 * <h4>Terms</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dd><i>&lt;term&gt;</i> ::=<td align=right>(2)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;factor&gt;</i>
 *     <td align=right>(1.1)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;unary operator&gt;</i>
 *     <i>&lt;term&gt;</i><td align=right>(1.2)</tr>
 *
 * <tr><td><dd><i>&lt;unary operator&gt;</i> ::=<td align=right>(2)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;"<code>!</code>" |
 *     "<code>^</code>" | "<code>~</code>"
 *     <td align=right>(2.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * If a <i>unary operator</i> is specified, a <i>term</i> produces
 * the set of strings which is the complement (<code>!</code>) of the set of
 * the strings produced by the <i>term</i> which occurs in it with respect
 * to the closure of the <b>alphabet</b>, or the complement(<code>^</code>)
 * of the set of characters produced by the <i>term</i> with respect to the
 * <b>alphabet</b>, or the set of all strings over the <b>alphabet</b>
 * which do not contain the ones denoted by the <i>term</i>, followed by an
 * occurrence of them (<code>~</code>).
 * Otherwise, it produces the strings of the <i>term</i> in it.
 *
 * <tr><td><dt><b>Static conditions:</b></tr><tr><td colspan=2><dl><dd>
 * The <i>expression</i> in which a <i>unary operator</i> lies must occur in a
 * <b>lexicon rule</b>.
 * <p>
 * If a <i>unary operator</i> lies in a <i>production</i>, the
 * <i>nonterminal</i> defined in it must not occur directly or indirectly
 * in its <i>term</i>.
 * <p>
 * The <i>term</i> in a <i>unary operator</i> which is <code>^</code>
 * must denote a set of characters.
 *
 * <tr><td><dt><b>Examples:</b></tr><tr><td colspan=2><dl><dd>
 * <code>!a</code> denotes all strings which are not "<code>a</code>";
 * <code>^a</code> denotes all sysmbols in the <b>alphabet</b> except
 * for "<code>a</code>", and <code>~a</code> denotes all strings up to
 * and including the first occurrence of "<code>a</code>".
 * </table>
 *
 * <h4>Factor</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dd><i>&lt;factor&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;primary&gt;</i>
 *      [<i>&lt;case clause&gt;</i> ] <td align=right>(1.1)</tr>
 *
 * <tr><td><dd><i>&lt;case clause&gt;</i> ::=<td align=right>(2)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>(i)</code> |
 *      <code>(f)</code><td align=right>(2.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * If a <i>case clause</i> which is <code>(i)</code> is specified,
 * a <i>factor</i> produces the set of strings which is made of the
 * strings produced by the <i>primary</i> in it in which each terminal
 * character is considered to denote all case variants as defined by the
 * simple case-folding of Unicode 3.1. If <code>(f)</code> is specified,
 * each characters is considered to denote all case variants as defined by
 * full case-folding.
 * Otherwise, it produces the strings of the <i>primary</i> in it.
 * <p>
 * A <i>primary</i> which is a <i>terminal</i>, followed by a
 * <i>case clause</i> is equivalent to an <i>expression</i> that generates
 * all the case variants of that terminal.
 * A <i>primary</i> which is a <i>nonterminal</i>, followed by a
 * <i>case clause</i> is equivalent to an occurrence of a nonterminal whose
 * rule is the same but has that <i>case clause</i> attached to all
 * <i>terminal</i>s which occur directly in it, except on ranges, or
 * indirectly through nonterminals, in which case the <i>case clause</i>
 * attached to the closest enclosing nonterminal applies.
 * A <i>primary</i> which is an <i>autoreference</i>, followed by a
 * <i>case clause</i> is equivalent to an occurrence the nonterminal denoted
 * by the <i>autoreference</i> followed by that <i>case clause</i>.
 *
 * <tr><td><dt><b>Static conditions:</b></tr><tr><td colspan=2><dl><dd>
 * The <i>expression</i> in which a <i>case clause</i> lies must occur in a
 * <b>lexicon rule</b>.
 *
 * <tr><td><dt><b>Examples:</b></tr><tr><td colspan=2><dl><dd>
 * <code>a(i)</code> denotes the strings "<code>a</code>" and "<code>A</code>".
 * </table>
 *
 * <h4>Primary</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dd><i>&lt;primary&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;terminal&gt;</i>
 *     [<i>&lt;store directive&gt;</i>]
 *     <td align=right>(1.1)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;nonterminal&gt;</i>
 *     [<i>&lt;store directive&gt;</i>] <td align=right>(1.2)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;autoreference&gt;<td align=right>(1.3)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;group&gt;<td align=right>(1.4)</tr>
 *
 * <tr><td><dd><i>&lt;autoreference&gt;</i> ::=<td align=right>(2)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>&lt;&gt;</code>
 *     <td align=right>(2.1)</tr>
 *
 * <tr><td><dd><i>&lt;group&gt;</i> ::=<td align=right>(3)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;simple group&gt;</i>
 *     <td align=right>(3.1)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;optional group&gt;</i><td align=right>(3.2)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;Kleene group&gt;</i><td align=right>(3.3)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;positive Kleene group&gt;</i><td align=right>(3.4)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;repetitive group&gt;</i><td align=right>(3.5)</tr>
 *
 * <tr><td><dd><i>&lt;simple group&gt;</i> ::=<td align=right>(4)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>{</code>
 *     <i>&lt;expression&gt;</i><code>}</code>
 *     <td align=right>(4.1)</tr>
 *
 * <tr><td><dd><i>&lt;optional group&gt;</i> ::=<td align=right>(5)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>[</code>
 *     <i>&lt;expression&gt;</i><code>]</code>
 *     <td align=right>(5.1)</tr>
 *
 * <tr><td><dd><i>&lt;Kleene group&gt;</i> ::=<td align=right>(6)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>{</code>
 *     <i>&lt;expression&gt;</i><code>}<sup>*</sup></code>
 *     <td align=right>(6.1)</tr>
 *
 * <tr><td><dd><i>&lt;positive Kleene group&gt;</i> ::=<td align=right>(7)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>{</code>
 *     <i>&lt;expression&gt;</i><code>}<sup>+</sup></code>
 *     <td align=right>(7.1)</tr>
 *
 * <tr><td><dd><i>&lt;repetitive group&gt;</i> ::=<td align=right>(8)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>{</code>
 *     <i>&lt;expression&gt;</i><code>}</code> <i>&lt;repetition&gt;</i>
 *     <td align=right>(8.1)</tr>
 *
 * <tr><td><dd><i>&lt;repetition&gt;</i> ::=<td align=right>(9)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>(</code>
 *     <i>&lt;lower bound&gt;</i> [<code>:</code> [ <i>&lt;upper bound&gt;</i>]]
 *     | <code>:</code><i>&lt;upper bound&gt;</i> <code>)</code>
 *     <td align=right>(9.1)</tr>
 *
 * <tr><td><dd><i>&lt;lower bound&gt;</i> ::=<td align=right>(10)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;
 *     <i>&lt;integer&gt;</i>
 *     <td align=right>(10.1)</tr>
 *
 * <tr><td><dd><i>&lt;upper bound&gt;</i> ::=<td align=right>(11)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;
 *     <i>&lt;integer&gt;</i>
 *     <td align=right>(11.1)</tr>
 *
 * <tr><td><dd><i>&lt;store directive&gt;</i> ::=<td align=right>(12)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;
 *     <code>(</code> [<code>-</code>] <code>lex</code>
 *       [<code>,</code> [<code>-</code>] <code>point</code> ] <code>)</code>
 *     <td align=right>(12.1)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <code>(</code>
 *     [<code>-</code>] <code>point</code>
 *       [<code>,</code> [<code>-</code>] <code>lex</code> ] <code>)</code>
 *     <td align=right>(12.2)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * A <i>primary</i> produces the string made by the <i>terminal</i> or
 * the strings produced by the <i>nonterminal</i>, <i>autoreference</i>,
 * or <i>group</i> in it.
 * <i>Nonterminal</i>s which denote shorthands produce recursively the elements
 * denoted by the shorthand.
 * When the <i>expression</i> occurs in a <b>lexicon rule</b>,
 * <i>nonterminal</i>s denote the <i>defining occurrence</i>s
 * to which they are <b>bound</b>, otherwise they denote the
 * <i>replacement defining occurrence</i> to which they are <b>linked</b>.
 * Note that a same rule can act both as a <b>lexicon rule</b> and as a
 * <b>grammar rule</b>.
 * The special symbol <code>&lt;&gt;</code> represents the same nonterminal
 * that is being defined by the production in which the <i>expression</i>
 * occurs.
 * The rules to bind that nonterminal with respect to the grammar or the
 * lexicon apply.
 * <p>
 * A <i>simple group</i> produces the strings produced by the <i>expression</i>
 * in it.
 * <p>
 * An <i>optional group</i> produces the empty string and the strings produced by
 * the <i>expression</i> in it. It is not considered as a repetition group in
 * the sense that when the <i>expression</i> in it produces the empty string,
 * an application of it always occurs, while for a repetition group in such
 * a case it does not.
 * <p>
 * A <i>Kleene group</i> produces the strings made by concatenating any number,
 * of times including zero, the strings produced by the <i>expression</i> in it.
 * <p>
 * A <i>positive Kleene group</i> produces the strings made by concatenating any
 * number of times, but at least one, the strings produced by the
 * <i>expression</i> in it.
 * <p>
 * A <i>repetitive group</i> produces the strings made by concatenating any
 * number of times, from its <b>lower bound</b> up to its <b>upper bound</b>
 * inclusive, the strings produced by the <i>expression</i> in it.
 * <p>
 * <i>Repetitive group</i>s with an <i>upper bound</i> in them occupy
 * a space in parser/lexer tables which is proportional to their
 * <b>upper bound</b>.
 * <p>
 * Note that groups are not equivalent to recursive rules, but to rules
 * that virtually contain as many terms as the <i>expression</i> that
 * they match. The use of right recursive rule in place of groups leads
 * to less efficient parsing, while that of left recursive rules leads
 * to more efficient parsing (at the cost of having a different, and
 * possibly inappropriate structure of the phrases).
 * <p>
 * A <i>store directive</i> which contains <code>lex</code> enables the
 * storing of the matched lexeme, and one which contains <code>point</code>
 * enables the storing of the position in the text. A &lsquo;<code>-</code>&rsquo;
 * specified in front of them disables storing.
 * Storing occurs when:
 * <ul>
 * <li>a <i>store directive</i> is specified which enables it,
 * <li>otherwise (none specified on it), the <i>primary</i> occurs in
 *   a <i>shorthand definition</i> with attached a <i>store directive</i>
 *   that enables it, or if none is attached to it, the one on the closest
 *   shorthand (defining the <i>primary</i> as lexeme) which has a
 *   <i>store directive</i> attached,
 * <li>otherwise (no shorthands specifying it), a <i>store directive</i>
 *   is specified on the <i>lexis list</i> (possibly on <code>TERMINALS</code>),
 * <li>otherwise, the <i>primary</i> is a <b>literal token</b>.
 * </ul>
 *
 * <tr><td><dt><b>Static conditions:</b></tr><tr><td colspan=2><dl><dd>
 * A <i>case clause</i> can be attached only to <i>primary</i>s which
 * occur in a <b>lexicon rule</b>.
 * <p>
 * The <b>upper bound</b> must be greater than or equal to the
 * <b>lower bound</b>. Both of them must be greater than zero and
 * lower than 64k.
 * <p>
 * A <i>store directive</i> can be attached only to <i>primary</i>s which
 * are <b>lexeme</b>s that occur in a <b>grammar rule</b>.
 *
 * <tr><td><dt><b>Static properties:</b></tr><tr><td colspan=2><dl><dd>
 * A <i>repetitive group</i> has a <b>lower bound</b>, which is the
 * value of the <i>lower bound</i> in it, if specified, and zero otherwise.
 * It has an <b>upper bound</b>, which is the value of the <i>upper bound</i>
 * in it, if specified; otherwise it is infinite if &lsquo;<code>:</code>&rsquo; is
 * specified, and else it is the same as the <b>lower bound</b>.
 * <p>
 * A <i>terminal</i> or <i>nonterminal</i> is a <b>literal token</b> if
 * it defines one string only not taking into account <i>case clause</i>s,
 * providing that its rule and the ones referred to by it do not contain
 * <i>unary operator</i>s or <i>binary operator</i>s.
 *
 * <tr><td><dt><b>Examples:</b></tr><tr><td colspan=2><dl><dd>
 * <table><tr><td><i>expression</i></td><td><i>meaning</i></td></tr>
 * <tr><td><code>[a]</code></td><td><code>empty, a</code></td></tr>
 * <tr><td><code>{a}</code></td><td><code>a</code></td></tr>
 * <tr><td><code>{a}*</code></td><td><code>empty, a, aa, aaa, ...</code></td></tr>
 * <tr><td><code>{a}+</code></td><td><code>a, aa, aaa, ...</code></td></tr>
 * </table>
 * </table>
 *
 * <h4>Lexis</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dt><b>Syntax:</b></tr>
 * <tr><td><dd><i>&lt;lexis&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<b>LEXIS</b>
 *     [ <i>&lt;lexis list&gt;</i> ]
 *     <br>{ <i>&lt;shorthand definition&gt;</i> |
 *     <i>&lt;replacement definition&gt;</i> }<sup>*</sup>
 *     [ <i>&lt;alphabet definition&gt;</i> ]
 *     <td align=right>(1.1)</tr>
 *
 * <tr><td><dd><i>&lt;lexis list&gt;</i> ::=<td align=right>(2)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;lexeme&gt;</i>
 *     { "<code>|</code>" <i>&lt;lexeme&gt;</i> }<sup>*</sup> [ <code>.</code> ]
 *     <td align=right>(2.1)</tr>
 *
 * <tr><td><dd><i>&lt;lexeme&gt;</i> ::=<td align=right>(3)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;nonterminal&gt;</i>
 *     [<i>&lt;store directive&gt;</i> | <i>&lt;ignore directive&gt;</i>]<td align=right>(3.1)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <code>TERMINALS</code>
 *     [<i>&lt;store directive&gt;</i> | <i>&lt;ignore directive&gt;</i>]<td align=right>(3.2)</tr>
 *
 * <tr><td><dd><i>&lt;alphabet definition&gt;</i> ::=<td align=right>(4)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<b>ALPHABET</b> <i>&lt;expression&gt;</i>
 *     <td align=right>(4.1)</tr>
 *
 * <tr><td><dd><i>&lt;ignore directive&gt;</i> ::=<td align=right>(5)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;
 *     <code>(</code> <code>ignore</code> <code>)</code>
 *     <td align=right>(5.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * A <i>lexis</i> defines the lexicon.
 * <p>
 * A <i>lexis list</i> can optionally be terminated by a dot (&lsquo;<code>.</code>&rsquo;) symbol.
 * <p>
 * Lexemes are considered as terminal (non-empty) symbols for the grammar proper.
 * The grammar is considered to be partitioned in two parts: the lexis
 * made by the rules which define the lexemes (together with the rules used
 * by them) and the grammar proper, made by the remaining rules. 
 * <p>
 * <b>TERMINALS</b> denotes the terminal lexemes which are not explicitly
 * specified in a <i>lexis list</i> or in the shorthands present in it.
 * <p>
 * An <i>alphabet definition</i> defines the (terminal) alphabet, which
 * is the set of characters produced by the <i>expression</i> in it.
 * During the evaluation of that set, the <b>alphabet</b> is set to
 * full Unicode.
 * <p>
 * A <i>store directive</i> specifies the storing of the string or its
 * point in the text for all occurrences of the <i>terminal</i> or
 * <i>nonterminal</i> (or, when it is a shorthand, of all the elements
 * defined by it), unless otherwise specified by <i>store directive</i>s
 * appended to occurrences.
 * <p>
 * An <i>ignore directive</i> specified that the tokens on which it is
 * defined has to be parsed, but otherwise ignored by the lexer.
 * <p>
 * All the lexemes must be declared explicitly. To group them it is possible
 * to use <i>shorthand definitions</i>.
 *
 * <tr><td><dt><b>Static properties:</b></tr><tr><td colspan=2><dl><dd>
 * All the terminals, nonterminals which do not denote shorthands, and
 * terminals and nonterminals denoted by shorthands present in the
 * <i>lexis list</i> are <b>lexeme</b>s.
 * All the terminals derivable from the start symbol, but not from
 * <b>lexeme</b>s, are <b>lexeme</b>s too.
 * <p>
 * All the productions which define <b>lexeme</b>s are <b>token rules</b>s.
 * <p>
 * All the productions directly or indirectly referred to from the start
 * symbol, but not from <b>token rule</b>s, are <b>grammar rule</b>s.
 * <p>
 * All <b>token rule</b>s and the productions directly or indirectly referred
 * to from them are <b>lexicon rule</b>s.
 * <p>
 * Note that there can be rules which are both grammar and lexicon rules.
 * For such rules, a set of rules is impliciltly introduced so as to
 * disentangle the grammar by making <b>grammar rule</b>s refer only to
 * <b>grammar rule</b>s or <b>token rule</b>s and <b>lexicon rule</b>s refer
 * only to <b>lexicon rule</b>s.
 * <p>
 * An empty <i>lexis list</i>, or no <i>lexis</i>, means that all the
 * <i>terminal</i>s are lexemes. To have no lexcon at all (i.e. that terminals
 * are the characters), no <i>terminal</i>s which are strings should be used
 * (and instead only characters).
 * <p>
 * The <b>alphabet</b> is the set of characters generated by the
 * <i>alphabet definition</i> when present, otherwise it is Unicode.
 *
 * <tr><td><dt><b>Static conditions:</b></tr><tr><td colspan=2><dl><dd>
 * All lexemes specified in a <i>lexis list</i> or in the shorthands present
 * in it, except for those implied by <b>TERMINALS</b>, must be unique.
 * <p>
 * All <i>terminal</i>s specified in a <i>lexis list</i> must occur
 * also in some <i>expression</i> in some production and be <b>lexeme</b>s.
 * <p>
 * All <b>lexeme</b>s must produce characters that belong to the <b>alphabet</b>.
 * <p>
 * The <i>expression</i> in an <i>alphabet definition</i> must produce
 * a set of characters (i.e. a set of strings of length one).
 * <p>
 * The <i>nonterminal</i>s in a <i>lexis list</i> must have rules that do not
 * contain autoiclusions, i.e. rules as A ::= alpha A beta, with alpha and beta
 * that do not produce the empty string.
 * <p>
 * The <i>ignore directive</i> can be specified only once, and on tokens that
 * are not ambiguous, i.e. that denote lexemes that are not denoted by other
 * tokens unless the "<code>-tokenSets</code>" option has been specified.
 * </table>
 *
 * <h4>Shorthand definitions</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dt><b>Syntax:</b></tr>
 * <tr><td><dd><i>&lt;shorthand definition&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;defining occurrence&gt;</i>
 *     <code>==</code>
 *     <br>{ <i>&lt;nonterminal&gt;</i>
 *         [<i>&lt;store directive&gt;</i>] |
 *     <i>&lt;terminal&gt;</i> [<i>&lt;store directive&gt;</i>] }<sup>+</sup>
 *     [ <code>.</code> ]
 *     <td align=right>(1.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * <i>Shorthand definition</i>s define names that stand for lists of lexemes.
 * They are made of terminals or nonterminals which denote either other
 * shorthands or grammar nonterminals. Occurrences of shorthands in
 * <i>expression</i>s (in grammar and replacements rules) have the same
 * semantics as groups which contain the lists of alternatives of all the
 * lexemes denoted by the shorthands. In <i>expression</i>s in
 * <b>lexicon rule</b>s, the elements they denote are bound to their
 * origin definition. In the other ones, they are bound to (possily
 * redefined) lexemes. Note that when shorthands occur in rules, their
 * definitions can contain terminals which do not occur in the grammar
 * since they act as groups, like e.g. in:
 * <pre>
 *    &lt;S&gt; ::= b &lt;A&gt;
 *    LEXIS &lt;A&gt;
 *    &lt;A&gt; == c
 * </pre>
 * Formally, a grammar which contains occurrences of shorhands in
 * <i>expression</i>s in rules is equivalent to a grammar in which those
 * occurrences have been replaced by <i>simple group</i>s containing all
 * the elements denoted by the shorthands.
 * <p>
 * A <i>shorthand definition</i> can optionally be terminated by a dot
 * (&lsquo;<code>.</code>&rsquo;) symbol.
 * <p>
 * A <i>store directive</i> specifies the storing of the string or its
 * point in the text for all occurrences of the <i>terminal</i> or
 * <i>nonterminal</i> (or, when it is a shorthand, of all the elements
 * defined by it), unless otherwise specified by <i>store directive</i>s
 * appended to occurrences.
 *
 * <tr><td><dt><b>Static conditions:</b></tr><tr><td colspan=2><dl><dd>
 * Elements in shorthand definitions may not be the empty string or the
 * empty string notation.
 * <p>
 * In a shorthand definition all elements must be unique.
 * <p>
 * A shorthand definition may not contain directly or indirectly occurrences
 * of the nonterminal defined by the <i>defining occurrence</i>.
 * I.e. shorthand definitions may not be cyclic.
 * <p>
 * All <i>terminal</i>s specified in a <i>shorthand definition</i> must occur
 * also in some <i>expression</i> in some production and be <b>lexeme</b>s.
 * </table>
 *
 * <h4>Replacement definitions</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dt><b>Syntax:</b></tr>
 * <tr><td><dd><i>&lt;replacement definition&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;replacement defining occurrence&gt;</i>
 *     <code>=&gt;</code> <i>&lt;expression&gt;</i>
 *     [ <code>.</code> ]
 *     <td align=right>(1.1)</tr>
 *
 * <tr><td><dd><i>&lt;replacement defining occurrence&gt;</i> ::=<td align=right>(2)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;lexeme&gt;</i>
 *     <td align=right>(2.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * Replacements are a means to define the precise lexical structure
 * of lexemes by adding delimiting elements such as spacing and
 * comments, or elements that define the spelling, to the defined token
 * rules. 
 * A <i>replacement definition</i> defines a production for a lexeme which
 * replaces in the grammar the original production.
 * The resulting grammar is obtained by substituting all occurrences
 * of lexemes in the <i>expression</i>s in <b>grammar rule</b>s by occurrences
 * of implicitly introduced nonterminals whose definitions are the
 * replacement rules. 
 * <p>
 * A <i>replacement defining occurrence</i> can redefine a terminal.
 * <p>
 * A <i>replacement definition</i> which has a <i>nonterminal</i>
 * in its <i>replacement defining occurrence</i> that is a shorthand
 * introduces implicilty one replacement definition for each lexeme
 * denoted by the shorthand.
 * <p>
 * Autoreferences in the <i>expression</i> denote the origin definition
 * (formally the production to which the <i>nonterminal</i> in the
 * <i>replacement defining occurrence</i> is <b>bound</b>).
 * <p>
 * Occurrences of <i>nonterminal</i>s and <i>terminal</i>s in the
 * <i>expression</i> denote the origin definitions.
 * <p>
 * A <i>replacement definition</i> can optionally be terminated by a dot
 * (&lsquo;<code>.</code>&rsquo;) symbol.
 *
 * <tr><td><dt><b>Static conditions:</b></tr><tr><td colspan=2><dl><dd>
 * The <i>lexeme</i> in a <i>replacement defining occurrence</i>
 * may not be the empty string or the empty string notation.
 * <p>
 * The <i>lexeme</i> in a <i>replacement defining occurrence</i> must
 * be a <b>lexeme</b>.
 * </table>
 *
 * <h4>Constants declaration</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dt><b>Syntax:</b></tr>
 * <tr><td><dd><i>&lt;constants declaration&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<b>CONSTANTS</b>
 *     { <i>&lt;constants element&gt;</i> }<sup>*</sup>
 *     <b>END</b> <td align=right>(1.1)
 *
 * <tr><td><dd><i>&lt;constants element&gt;</i> ::=<td align=right>(2)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp; <i>&lt;nonterminal&gt;</i>
 *       <td align=right>(2.1)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <code>n</code> "<code>(</code>"
 *       <i>&lt;symbol&gt;</i> "<code>)</code>" <td align=right>(2.2)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <code>t</code> "<code>(</code>"
 *       <i>&lt;symbol&gt;</i> {, <i>&lt;symbol&gt;</i> }<sup>*</sup>
 *       "<code>)</code>" <td align=right>(2.3)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;string&gt;</i>
 *       <td align=right>(2.4)</tr>
 *
 * <tr><td><dd><i>&lt;symbol&gt;</i> ::=<td align=right>(3)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;
 *         <i>&lt;nonterminal&gt;</i> <td align=right>(3.1)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;terminal&gt;<td align=right>(3.2)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * A <i>constants declarations</i> instructs the parser generator to
 * produce a file containing the declarations of the specified constants.
 * Each <i>constants element</i> is transferred to the file as follows:
 * <ul>
 * <li><i>nonterminal</i>: it is replaced by the number of the nonterminal
 * <li><code>n(</code><i>symbol</i><code>)</code>: it is replaced
 *   by the number of the nonterminal or the terminal in it
 * <li><code>t(</code><i>symbol</i><code>,...)</code>: it is replaced
 *   by the number of the token set of the tokens in it
 * <li><i>string</i>: it is copied by replacing occurrences of "\n"
 *   with the platform specific line separator.
 * </ul>
 * Note that <i>terminal</i>s must not be either written as <i>string</i>s
 * or separated by a following comma with a space.
 *
 * <tr><td><dt><b>Static conditions:</b></tr><tr><td colspan=2><dl><dd>
 * A <i>nonterminal</i> and a <i>terminal</i> must denote syntax elements
 * defined in the <i>grammar</i>.
 * <p>
 * A list of tokens must denote a token set recognized by the lexer.
 * <p>
 * <tr><td><dt><b>Examples:</b></tr><tr><td colspan=2><dl><dd>
 * <pre>
 *   CONSTANTS
 *       "interface MySyntax {\n"
 *       "    static final int IDENT = " <identifier> ";\n"
 *       "    static final int AA_ID = " {"aa" <identifier>} ";\n"
 *       ...
 *       "}"
 *   END
 * </pre>
 * Note that generating an interface containing the constants allows to have
 * a source file which can be compiled directly. Without an interface
 * there would be a need to include them in the application.
 * </table>
 *
 * <h4>Translation skeme</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dt><b>Syntax:</b></tr>
 * <tr><td><dd><i>&lt;translation skeme&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp; <b>TRANSLATIONS</b>
 *     { <i>&lt;translation&gt;</i> }<sup>*</sup>
 *     <b>END</b> <td align=right>(1.1)</tr>
 *
 * <tr><td><dd><i>&lt;translation&gt;</i> ::=<td align=right>(2)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;nonterminal&gt;</i>
 *     "<code>=</code>" <i>&lt;pattern&gt;</i>
 *     { "<code>|</code>" <i>&lt;pattern&gt;</i> }<sup>*</sup>
 *     [ <code>.</code> ] <td align=right>(2.1)</tr>
 *
 * <tr><td><dd><i>&lt;pattern&gt;</i> ::=<td align=right>(3)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;
 *     { <i>&lt;string&gt;</i> |
 *     <i>&lt;nonterminal&gt;</i> [<i>&lt;integer&gt;</i>]
 *     | <i>&lt;rewriting&gt;</i> }<sup>+</sup>
 *     <td align=right>(3.1)</tr>
 *
 * <tr><td><dd><i>&lt;rewriting&gt;</i> ::=<td align=right>(4)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;
 *     {<code>s</code> | <code>t</code>}
 *     "<code>(</code>" { <i>&lt;symbol&gt;</i>
 *         ["<code>,</code>" <i>&lt;integer&gt;</i>]
 *         | <i>&lt;integer&gt;</i> } "<code>)</code>"
 *     <td align=right>(4.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * Translations are a means to specify the strings to be generated
 * when an occurrence of the rule to which they are associated occurs
 * in the (source) text.
 * They associate to the rules of a <i>nonterminal</i> the patterns
 * specified in them in the same order.
 * <p>
 * Patterns are made of:
 * <p>
 * <ul>
 * <li>(constant) <i>strings</i>s, which translate to themselves.
 * <li><i>nonterminal</i>s, which denote the string matched by them,
 *   If more than one occurrence of a same nonterminal in a rule exists,
 *   the desired one can be selected by specifying its <i>integer</i>
 *   ordinal numbers (from zero upwards).
 * <li><i>rewriting</i>s, which apply to the specified occurrence
 *   (denoted by the <i>integer</i>, or the first if not present)
 *   of the specified <i>symbol</i> in the rule. The &lsquo;<code>s</code>&rsquo; rewriting
 *   is replaced by the string matched, the &lsquo;<code>t</code>&rsquo; one is replaced
 *   by the translation of the string matched.
 * </ul>
 * <p>
 * For the definitions of <i>nonterminal</i>, <i>terminal</i>, <i>string</i>,
 * <i>integer</i> and <i>symbol</i>, refer to the class Parser.
 *
 * <tr><td><dt><b>Static conditions:</b></tr><tr><td colspan=2><dl><dd>
 * The <i>nonterminal</i> in a <i>translation</i> must denote a
 * <b>grammar rule</b>.
 * <p>
 * A <i>nonterminal</i> in a <i>pattern</i> must denote a nonterminal
 * which occurs in the associated rule, and an <i>integer</i> must denote
 * an occurrence which exists.
 * </table>
 *
 * <h4>Vocabulary</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dt><b>Syntax:</b></tr>
 * <tr><td><dd><i>&lt;nonterminal&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>&lt;</code>
 *     { <i>&lt;<u>non-close</u> character&gt;</i> |
 *         <i>&lt;string&gt;</i> }<sup>+</sup>
 *     <code>&gt;</code>
 *     <td align=right>(1.1)</tr>
 *
 * <tr><td><dd><i>&lt;terminal&gt;</i> ::=<td align=right>(2)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;string&gt;</i>
 *     <td align=right>(2.1)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;non-meta symbol&gt;<td align=right>(2.2)</tr>
 *
 * <tr><td><dd><i>&lt;string&gt;</i> ::=<td align=right>(3)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>"</code>
 *     { <i>&lt;<u>non-quote</u> character&gt;</i> |
 *     <i>&lt;escape&gt;</i> }<sup>*</sup> <code>"</code>
 *     <td align=right>(3.1)</tr>
 *
 * <tr><td><dd><i>&lt;escape&gt;</i> ::=<td align=right>(4)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>\n</code> |
 *     <code>\t</code> | <code>\b</code> |
 *     <code>\r</code> | <code>\f</code> | <code>\\</code> |
 *     <code>\'</code> | <code>\"</code> | <br>
 *     <code>\</code><i>&lt;octal&gt;</i><i>&lt;octal&gt;</i><i>&lt;octal&gt;</i> | <br>
 *     { <code>\</code><code>u</code> | <code>\</code><code>U</code> }
 *         <i>&lt;hex&gt;</i><i>&lt;hex&gt;</i><i>&lt;hex&gt;</i><i>&lt;hex&gt;</i>
 *     <td align=right>(4.1)</tr>
 *
 * <tr><td><dd><i>&lt;octal&gt;</i> ::=<td align=right>(5)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>0</code> |
 *     <code>1</code> | <code>2</code> | <code>3</code> |
 *     <code>4</code> | <code>5</code> | <code>6</code> |
 *     <code>7</code><td align=right>(5.1)</tr>
 *
 * <tr><td><dd><i>&lt;hex&gt;</i> ::=<td align=right>(6)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;octal&gt;</i> |
 *     <code>8</code> | <code>9</code> | <code>a</code> | .. |
 *     <code>f</code> | <code>A</code> | .. | <code>F</code>
 *     <td align=right>(6.1)</tr>
 *
 * <tr><td><dd><i>&lt;non-meta symbol&gt;</i> ::=<td align=right>(7)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;{
 *     <i>&lt;<u>non-meta</u> character&gt;</i> }<sup>+</sup>
 *     <td align=right>(7.1)</tr>
 *
 * <tr><td><dd><i>&lt;integer&gt;</i> ::=<td align=right>(8)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;{ <code>0</code> |
 *     <code>1</code> | <code>2</code> | <code>3</code> |
 *     <code>4</code> | <code>5</code> | <code>6</code> |
 *     <code>7</code> | <code>8</code> | <code>9</code>
 *     }<sup>+</sup><td align=right>(8.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * Grammars are represented using the Unicode character set.
 * The alphabet is represented by the nonterminal <i>&lt;character&gt;</i>
 * from which any Unicode character can be derived as terminal production.
 * The lexical elements of a grammar declaration are:
 * <p>
 * <ul>
 * <li><i>nonterminal</i>s
 * <li><i>terminal</i>s
 * <li><i>integer</i>s
 * <li>reserved symbols.
 * <li>special character combinations.
 * </ul>
 * <p>
 * Lexical elements are terminated by the first character which cannot
 * belong to them, possibly by spacing and comments.
 * <>
 * <i>Nonterminal</i>s represent syntactic categories. <i>Terminal</i>s
 * represent strings over the terminal alphabet. The empty string is
 * denoted by <code>""</code> or by the nonterminal or terminal symbol
 * defined as <i>empty notation</i> in the <i>grammar prelude</i>.
 * <p>
 * A <i><u>non-close</u> character</i> is a character other than the
 * closing angular bracket (&lsquo;<code>&gt;</code>&rsquo;), the double quote
 * (&lsquo;<code>&quot;</code>&rsquo;) and the format effectors (BS, VT, HT, CR and LF).
 * <p>
 * Lowercase and uppercase letters are different.
 * <p>
 * In a <i>nonterminal</i> the characters enclosed in parentheses are
 * ignored. E.g. <code>&lt;(integer)expression&gt;</code> is the same as
 * <code>&lt;expression&gt;</code>.
 * When closing angular brackets, format effectors, double quotes,
 * or sequences of characters enclosed in parentheses need be part of
 * a nonterminal, they must be represented as <i>string</i>s. The
 * notation of <i>string</i>s can be used to introduce any sequence of
 * characters in a <i>nonterminal</i>.
 * <p>
 * A <i><u>non-quote</u> character</i> is a character other than the
 * double quote (&lsquo;<code>"</code>&rsquo;).
 * <p>
 * <i>Terminal</i>s are <i>string</i>s or <i>non-meta symbol</i>s
 * which are not reserved symbols or special character combinations.
 * <p>
 * A <i><u>non-meta</u> character</i> is an ASCII character from <code>!</code>
 * to <code>~</code> other than the double quote(&lsquo;<code>"</code>&rsquo;).
 *
 * <tr><td><dt><b>Static conditions:</b></tr><tr><td colspan=2><dl><dd>
 * A <i>non-meta symbol</i> may not be one of the special character 
 * combinations:
 * <code>{</code>     &nbsp; <code>[</code>        &nbsp; <code>]</code>    &nbsp;
 * <code>|</code>     &nbsp; <code>=></code>       &nbsp; <code>==</code>   &nbsp;
 * <code>={</code>    &nbsp; <code>::=</code>      &nbsp; <code>..</code>   &nbsp;
 * <code>.</code>     &nbsp; <code>}*</code>       &nbsp; <code>}+</code>   &nbsp;
 * <code>}</code>     &nbsp; <code>&lt;&gt;</code> &nbsp; <code>&lt;</code> &nbsp;
 * <code>&gt;</code>  &nbsp; <code>!</code>        &nbsp; <code>^</code>    &nbsp;
 * <code>-</code>     &nbsp; <code>~</code>        &nbsp; <code>(</code>    &nbsp;
 * <code>&amp;</code> &nbsp;
 * and <code>)</code> &nbsp;.
 * <p>
 * A <i>non-meta symbol</i> may not be one of the reserved symbols:
 * <b>ALPHABET</b>, <b>END</b>, <b>GRAMMAR</b>, <b>LEXIS</b>,
 * <b>TERMINALS</b> and <b>OPTIONS</b>.
 * </table>
 *
 * <h4>Spaces and comments</h4>
 *
 * <table cellspacing=0 cellpadding=0 width=100%>
 * <tr><td><dt><b>Syntax:</b></tr>
 * <tr><td><dd><i>&lt;comment&gt;</i> ::=<td align=right>(1)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<i>&lt;bracketed comment&gt;</i>
 *     <td align=right>(1.1)</tr>
 *   <tr><td><dl><dd><dl><dd>|  <i>&lt;line-end comment&gt;</i>
 *     <td align=right>(1.2)</tr>
 *   <tr><td><dl><dd><dl><dd>|  { <i>&lt;space&gt;</i> | <i>&lt;tab&gt;</i> |
 *     <i>&lt;end-of-line&gt;</i> }<sup>*</sup>
 *     <td align=right>(1.3)</tr>
 *
 * <tr><td><dd><i>&lt;bracketed comment&gt;</i> ::=<td align=right>(2)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>/</code><code>*</code>
 *     { <i>&lt;character&gt;</i> | <i>&lt;end-of-line&gt;</i> }<sup>*</sup>
 *     <code>*</code><code>/</code>
 *     <td align=right>(2.1)</tr>
 *
 * <tr><td><dd><i>&lt;line-end comment&gt;</i> ::=<td align=right>(3)</tr>
 *   <tr><td><dl><dd><dl><dd>&nbsp;&nbsp;<code>//</code>
 *     { <i>&lt;character&gt;</i> }<sup>*</sup>
 *     <i>&lt;end-of-line&gt;</i>
 *     <td align=right>(3.1)</tr>
 *
 * <tr><td><dt><b>Semantics:</b></tr><tr><td colspan=2><dl><dd>
 * Comments have no relevance for the semantics. They document a grammar
 * declaration.
 * They can be inserted before and after any lexical element.
 * <p>
 * The string produced as a sequence of <i>character</i>s in a
 * <i>bracketed comment</i> may not contain the sequence
 * <code>*</code><code>/</code>.
 * <p>
 * The string produced as a sequence of <i>character</i>s in a
 * <i>line-end comment</i> may not contain the <i>end-of-line</i>
 * <p>
 * The element <i>&lt;space&gt;</i> denotes the space character;
 * <i>&lt;tab&gt;</i> the horizontal tabulation character, and
 * <i>&lt;end-of-line&gt;</i> the end of a line, be it a character or
 * a system-dependent representation of the separation between lines.
 * </table>
 *
 * <h4>Visibility and name binding</h4>
 * A <i>nonterminal</i> is <b>visible</b> when:
 * <ul>
 * <li>there is a <i>defining occurrence</i> with that <i>nonterminal</i>
 *   in the grammar declaration. 
 *   The <i>nonterminal</i> is said to be <b>bound</b> to it.
 * <li>there is a (possibly implicit) <i>replacement defining occurrence</i>
 *   with that <i>nonterminal</i> in the grammar declaration. 
 *   The <i>nonterminal</i> is said to be <b>linked</b> to it.
 * </ul>
 * <p>
 * A <i>terminal</i> is <b>linked</b> to a (possibly implicit)
 * <i>replacement defining occurrence</i> with that <i>terminal</i> in it
 * when such a definition exists.
 * <p>
 * The following conditions must be satisfied:
 * <ul>
 * <li>a <i>nonterminal</i> must be <b>bound</b> to exactly one
 *   <i>defining occurrence</i>.
 * <li>a <i>nonterminal</i> can be <b>bound</b> to exactly one
 *   <i>replacement defining occurrence</i>.
 * <li>a <i>terminal</i> can be <b>bound</b> to exactly one
 *   <i>replacement defining occurrence</i>.
 * </ul>
 *
 * <h4>User-defined lexers</h4>
 * When the standard lexer is not sufficient to spot the lexemes, e.g. when
 * they are delimited in some particular way, or when lexemes can be omitted,
 * a user-defined lexer can be provided.
 * Such lexer must be declared as a subclass of <code>ParserLex</code>.
 * It must redefine the method <code>lex()</code>, which must return an integer
 * which is an index of an element of the <code>tokList</code> vector that is
 * an array of the matched token numbers.
 * It can access the input stream, the parse tables and the trace flags, and
 * the methods to get the token numbers.
 */

/* Rationale of this EBNF notation.
 *
 * The general principle followed is to make the notation as similar as
 * possible to the ones used in textbooks on formal languages and linguistics.
 * Extreme conciseness is not a goal, but readability is.
 *
 * Grammars and languages
 *
 * Here are some clarifications on the definitions of grammars.
 * A grammar which has an empty set of productions does not generate
 * any string, and therefore defines the empty language.
 * Note that in the definion of Grammar of Aho, the set of productions
 * can be empty.
 * Productions have a domain (RHS) which is {N union VT}*, and therefore when
 * there is no element in one, the empty string is denoted.
 * <S> ::= (or <S> ::= "", or <S> :: <empty>) represents thus the language
 * made solely by the empty string.
 * The (terminal) alphabet can also be empty since to define the empty
 * language, or the one that contains only the empty string there is no
 * need for a non-empty alphabet.
 * Remember that the empty string is the sequence of no symbols, and it
 * is also the neutral element for concatenation. Concatenation is defined
 * on all strings, it is associative and has a neutral element, and therefore
 * the set of strings with concatenation is a monoid.
 * Note also that the empty string is a string, not a symbol.
 * The empty language is the neutral element for union.
 * If L1 is a language and L0 the empty one, L1 L0 = L0.
 * Now, the importance of knowing the cases in which an empty language is
 * generated is that nonterminals generate languages and can occur in
 * rules for which the generated language is concatenated, merged, etc.,
 * with that of the other elements in such rules. !{<char>}* defines an
 * empty language.
 * A notation for the empty language is <A> ::= !{<char>}*. Since it is
 * almost useless, there is no need for a better one. It would be needed
 * only for sake of completeness (in the algebraic sense, as a neutral element
 * for union ("|")).
 * The grammar that defines the empty language has an empty set of rules,
 * and thus it is regular. It can be recognised by an automaton which
 * has one non-final state.
 * The engine can test it and announce whatever. The empty language matches
 * only the absent text (e.g. a null reference to a string).
 * This is consistent to the fact that <A> ::= !{<char>}* never matches since
 * when applied to a text it does not (because !{<char>}* matches only an
 * absent text), and when applied to a text it does not as well (because <A>
 * requires a text).
 * When !{<char>}* occurs in the middle of a rule, that rule never matches.
 *
 * Nonterminals
 *
 * The <...> form is chosen because used in the definition of many languages
 * and in textbooks. It makes evident the occurrences of nonterminals and
 * it allows great freedom in choosing their names (including names made by
 * several words.
 *
 * Ranges
 *
 * The clearer notation | .. | is used since a range is a shorthand for a
 * set of alternatives. The shorter .. notation would not hint this.
 * Another one is | ... |, but two dots is a notation which has been used
 * in Pascal and Ada and thus it is well known also.
 * The .. one would perhaps require a different precedence: a b .. c d
 * would be a {b .. c } d, while with the bars there is no doubt that it
 * must have the same precedence as alternation.
 * Another notation widely used is: a-z, but it is used here for difference.
 * Associativity is not allowed, e.g.: a | .. | c | .. | g.
 * It is useless and {a | .. | c} | .. | g is not correct since the lower bound
 * is not a character.
 * Range bounds can be any expression which produces a single character.
 * E.g. {a|b} & a represents "b" and is valid. Case-clauses and any other
 * construct can be used as long as the result is one character.
 * Note that most of the times a case-clause produces more than one character,
 * but also many other constructs. It is therefore simpler to have just one
 * overall condition.
 * Autoreferences in ranges are not allowed. E.g. <A> ::= <A> | .. | z.
 * They are meaningless here.
 * Two ranges are reported as duplicated when they have the same
 * <subexpression>s. This is so because they are likely to have been written
 * twice by error. Ideally this should be allowed as many other operations
 * on sets (like e.g. the difference with an empty set). The general idea
 * is that when two rules are identical syntactically, they are likely to
 * be a mistake, while when they are equivalent in terms of the generated
 * language, that is less likely to be a mistake, and therefore that is not
 * reported.
 *
 * Operations on languages
 *
 * The following operations on languages are supported:
 *
 *   (set) complement:       ^op1      = <alphabet> - op1
 *   difference:             op1 - op2 = op1 & !op2 = !(!op1 | op2)
 *   intersection:           op1 & op2 = !(!op1 | !op2)
 *   union:                  op1 | op2
 *   (language) complement:  !op1      = {<alphabet>}* - op1
 *   upto:                   ~op1      = [!{{<alphabet>}* op1 {<alphabet>}*}] op1
 *
 * N.B. ~"" is the empty string.
 * N.B. !"" alpha means any nonempty string followed by alpha.
 * To detect it, all the text is scannned to find the last "a" in it.
 * N.B. !{alpha} eats all text if it does not start with alpha". It has been
 * introduced mainly to implement the other operators.
 * N.B. !~<A> is different from ~!<A>.
 * The set of all characters except "a" is <alphabet> - a, i.e. ^a.
 * Note that it is not !a, which is {<alphabet>}* - a.
 *
 * ^{} is an error. If {} would be considered as an empty set of characters
 * in ^{}, then ^^ would not produce {}.
 * 
 * The meaning of difference of languages with the longest match rule
 * is that the longest string of the resulting language which is a head of
 * the text is taken.
 *
 * The set complement above is defined only when op1 is a character or a set.
 * When the operands are sets, the result is a set also. When they are
 * regular, the result is also that.
 * When set complement, difference and intersection are applied to sets
 * of characters, they produce sets of characters.
 * Autoreferences do not make any sense when they occur inside operands.
 * E.g. <A> ::= <A> {a | .. | z}+ - c | b could have a meaning, but it is not
 * much intuitive. Better disallow autoreferences when there are operators.
 * But <A> ::= <A> <B> | b. <B> ::= {a | .. | z}+ - c has a meaning.
 * They are different. What is disallowed is to make an autoreference in
 * an operand.
 * A check is done that there are no autorefernces with operands.
 * Autoreferences in the second operand could lead to the Russel paradox:
 * <X> ::= "A" - <X>.
 * Is "A" an example of <X>? If it is, then the RHS is not satisfied, and
 * if it is not, then the RHS is satisfied.
 * Autoreferences in the first operand are here not supported as well (but
 * are allowed in ISO 14977 standard EBNF notation) since it is not clear
 * what the meaning could be. E.g.
 *
 *    <A> ::= <A> b | c      means     c {b}*
 *
 *    <A> ::= <A> - b | c    means     {<A> - b | c} - b | c
 *
 * obtained by replacing the occurrence of <A> with its definition,
 * which is <A> - b - b | b - c | c, which is c. This is a simple case,
 * in the general one the solution of the equation could be much more
 * complex.
 *
 * Alphabet
 *
 * With complement there is either a need to define the alphabet, otherwise
 * it would be the full Unicode, or to specify the set of characters to
 * complement against.
 * It is convenient to define the alphabet, so as not to repeat it all
 * the times in which a notation which means "any character" is used.
 * If there were no alphabet declaration, it would be safer not to have
 * complement, but only difference. E.g. all ASCII characters except "a"
 * would be: {"\u0000" | .. | "\u00ff"}* - a.
 * An alphabet declaration allows to declare what are the terminal symbols,
 * possibly not only a range.
 * It is not possible to let the alphabet be the set of all characters
 * occurring in the grammar (including the ones implicitly declared by ranges).
 * This would mean that when there are some characters which happen not
 * to appear in any rule, but are needed in the alphabet to complement,
 * there is a need to use difference there.
 * Moreover, suppose that the alphabet it a subset of ASCII and that in
 * a rule all characters of that alphabet need occur. The rule would have
 * in it something like, e.g.: {"\u0000" | .. | "\u00ff"}* - x. This means
 * that "x" should not be rekoned in the alphabet, and thus that the
 * alphabet would not be the set of all characters occurring in rules.
 * This would also be contrary with the notion la alphabet in languages.
 * Note that when using (set) complement, some attention must be paid to
 * define the alphabet if it it not full Unicode.
 * An alphabet is a superset of what grammar generates since a language
 * is a set of strings over the alphabet. When a grammar defines a language
 * which is the union of two, there is a need to merge the two alphabets.
 *
 * In grammars which do not support complement and difference, productions
 * have a domain which is {N union VT}*, and therefore must contain either
 * nonterminals or terminals over the alphabet.
 * With complement and difference, this definition needs to be extended to
 * ensure that the genereated strings belong to VT* in presence of operations.
 * The condition is that the generated terminal strings contain characters
 * which belong to the alpabet.
 *
 * Predefined character classes
 *
 * Some lexer generators and regular expression libraries support
 * predefined character classes. This relieves the user to define them,
 * which is cumbersome, expecially for Unicode classes.
 * However, they are of little use: Unicode classes are very large and
 * contain characters of all languages. E.g. when defining lexemes such
 * as numbers, the digits used must belong to a same (set of) languages.
 * Allowing all digits of all languages at the same time is of no use.
 * Moreover, character classes are locale dependent.
 * The ASCII ones could be of some use, but they can also be easily
 * defined in source grammars. The only one which seems to be useful
 * is the definition of newlines.
 * E.g. these are the Posix ones:
 *
 *    <lower>  ::= a |..| z
 *    <upper>  ::= A |..| Z
 *    <alpha>  ::= <lower> | <upper>
 *    <digit>  ::= 0 |..| 9
 *    <alnum>  ::= <alpha> | <digit>
 *    <xdigit> :"= 0 |..| 9 | a |..| f | A |..| F
 *    <blank>  ::= " " | "\t"
 *    <space>  ::= "\t" |..| "\r" | " "
 *    <cntrl>  ::= "\u0000" |..| "\u001f" | "\u007f"
 *    <punct>  ::= "\u0021" |..| "\u002f" | "\u003a" |..| "\u0040"
 *                 | "\u005b" |..| "\u0060" | "\u007b" |..| "\u007e"
 *    <graph>  ::= <alnum> | <punct>
 *    <print>  ::= <graph>
 *
 * extended sometimes with:
 *
 *    <word>   ::= <alnum> | "_"
 *
 * There would be a need to have some dedicated notation for them, like
 * e.g. <:letter:>, or <U+letter>, <P+letter>. An appropriate definition
 * would be virtually included when an occurrence is present in the grammar.
 *
 * Types of grammars supported
 *
 * Extra BNF notations such as ranges, complement, etc. are not allowed
 * in the grammar, but only in the lexicon.
 * Ranges could be supported also in the grammar (a category table could
 * be used), but they are not for uniformity.
 * It is not a solution to generate an automaton for the nonterminals
 * which are type-3 (and treat complement, etc. in it) since that does not
 * allow to build the parse tree. Moreover, it is not clear what could
 * even be a parse tree for a complement. In such a case an automaton
 * which manifestedly does not deliver the internal structure is the only
 * one thing possible, which is not appropriate since parsing must deliver
 * a parse tree.
 *
 * Groups with repetition ranges
 *
 * The feature to specify the presence of a range of occurrences of some
 * elements is useful because it occurs in practice and it avoids to
 * clutter the grammar. The ranges of repeating elements are indicated
 * by giving the bounds. Repetition ranges cannot be appended direcly to
 * terminals and nonterminals, like e.g. "abc"(3), as "*" cannot.
 * All repetitions are surrounded by {...}, the reason being that this allows
 * to repeat expressions in general, and that this notation has long been
 * in use.
 * Since quantifiers are the most prioritary ones, they are written closer to
 * groups than case clauses, like e.g.: {...}(3:5)(i). They are not combined
 * in one single clause, like e.g.: {...}(3:5,i), because repetitions and case
 * clauses are completely different notions.
 * When the first bound is missing, it is 0, when the second is missing,
 * and ":" is specified, it is *; otherwise the second bound is the same
 * as the first one. Repetitive groups can be represented with equivalent
 * rules, like e.g.:
 *
 *     {a}(2:4) = a a [a] [a]
 *     {a}(:4)  = [a] [a] [a] [a]
 *     {a}(0:)  = {a}*
 *     {a}(2:)  = a {a}+
 *     {a}(2)   = a a
 *
 * An alternative notation could be to append the repetition to Kleene
 * and the other groups, like e.g. {a}(2)+ for {a}(2:).
 * Note that there is anyway a need to have two numbers in the notation, and
 * thus it does not help much.
 * The upper bound must be greater than or equal to the lower bound,
 * and, if specified, it must be greater than zero.
 * Zero is disallowed because it is very likely to be a mistake.
 */


/*
 * It is the control module that reads and analyses the command and activates
 * the main parts of the program.
 */



public class Parser extends ParserEngine {

    /**
     * Deliver a parser.
     *
     * @return     parser
     */

    public Parser(){
    }

    /**
     * Deliver a parser that has analysed the specified text for the specified grammar.
     *
     * @param      gram grammar
     * @param      text text
     * @return     parser
     */

    public Parser(Object gram, Object text){
        this(gram);
        if (this.errorList != null) return;
        parse(text);
    }

    /** The option that specifies that the parser must produce a forest. */
    public static final int FOREST = 1;

    /** The current options. */
    private int options;

    /**
     * Deliver a parser that has analysed the specified grammar and has the specified
     * options.
     *
     * @param      gram grammar
     * @param      opt options (option constants or'ed)
     * @return     parser
     */

    public Parser(Object gram, int opt){
        this(gram);
        this.options = opt;
        if (this.errorList != null) return;
    }

    /**
     * Deliver a parser that has analysed the specified grammar.
     *
     * @param      gram grammar
     * @return     parser
     */

    public Parser(Object gram){
        analyse(gram);
        if (this.tab == null) return;
    }

    /**
     * Analyse the specified grammar.
     *
     * @param      gram grammar
     * @return     <code>true</code> if successful, <code>false</code> otherwise
     */

    /* Parser p = new Parser(grammar) delivers an object p of a class that contains the generator.
     * The data used by the generator (actually, the object that is the generator) are cleaned
     * once the parser tables have been generated so as to reduce the footprint.
     */

    private boolean analyse(Object gram){
        this.tab = null;
        if (gram instanceof File && ((File)gram).getName().endsWith(".ser")){
            // read the serialized parses tables
            try {
                FileInputStream in = new FileInputStream((File)gram);
                ObjectInputStream ins = new ObjectInputStream(in);
                this.tab = (ParserTables)ins.readObject();
                ins.close();
            } catch (ClassNotFoundException th){
                addError(ParserLexer.ERR_IOERR," "+((File)gram).getName(),0,th);
                return false;
            } catch (IOException th){
                addError(ParserLexer.ERR_IOERR," "+((File)gram).getName(),0,th);
                return false;
            }
        } else if (gram instanceof InputStream){
            // read the serialized parses tables
            try {
                ObjectInputStream ins = new ObjectInputStream((InputStream)gram);
                this.tab = (ParserTables)ins.readObject();
                ins.close();
            } catch (ClassNotFoundException th){
                addError(ParserLexer.ERR_IOERR," "+((File)gram).getName(),0,th);
                return false;
            } catch (IOException th){
                addError(ParserLexer.ERR_IOERR," "+((File)gram).getName(),0,th);
                return false;
            }
        } else {
            this.prs = new ParserBnf();
            // possibly set prs.mode
            String pname = "rnglrgd";
            if ((FOREST & this.options) != 0){
                pname = "rnglrg";
            }
            prs.mode = ParserFactory.prsmode(pname,prs.mode);
            boolean res = prs.analyse(gram);             // parse source grammar
            if (!res){
                if (this.errorList == null){
                    this.errorList = new LinkedList<ParserError>();
                }
                for (ParserError e = this.prs.lex.excObj;     // add errors to list
                    e != null; e = e.next){
                    if (e.txta == null) e.txta = "";
                    this.errorList.add(e);
                }
                return false;
            }
            ParserFactory.getLrPilot(this.prs,pname,"","");
            this.tab = this.prs.getTables();
            this.prs = null;
        }
        return true;
    }

    /**
     * Parse the specified text.
     *
     * @param      text text
     * @return     <code>true</code> if successful, <code>false</code> otherwise
     */

    public boolean parse(Object text){
        String pname = "rnglrgd";
        if ((FOREST & this.options) != 0){
            pname = "rnglrg";
        }
        this.engine = ParserFactory.getParser(this.tab,null,"",pname);
        this.engine.mode |= ParserEngine.RETAIN_GRAM;        
        if (this.lex == null){                // create a standard lexer if none
            this.lex = new ParserLex(this.tab);
        }
        this.lex.stream = new BufReader(text,2048);
        this.engine.lex = this.lex;
        this.engine.trc = trc;
        boolean res = this.engine.parse();
        if (!res){
            addError(ParserLexer.ERR_NOREC,null,this.lex.index(),null);
        } else {
            this.engine.copyTree(this);       // copy tree data to allow access to tree from this
        }
        this.lastIndex = this.lex.index();
        try {
            this.lex.close();
        } catch (IOException exc){
        }
        return this.errorList == null;
    }

    /** The last position in the input. */
    private long lastIndex;

    /**
     * Deliver an array of the names of the tokens that are expected at the current parsing
     * position.
     *
     * @return     array
     */

    @Override
    public String[] expectedTokens(){
        return this.engine.expectedTokens();
    }

    /**
     * Serialize the parser tables.
     *
     * @param      file file
     * @return     <code>true</code> if successful, <code>false</code> otherwise
     */

    /* When the parser deserializes the tables, it does not create a generator, which
     * means that the jvm does not read or compile its methods.
     */

    public boolean serialize(File file){
        try {
            OutputStream ost = (OutputStream)(new FileOutputStream(file));
            ObjectOutputStream ous = new ObjectOutputStream(ost);
            ous.writeObject(this.tab);
            ous.close();
        } catch (IOException th){
            addError(ParserLexer.ERR_IOERR,file.getName(),0,th);
        }
        return this.errorList == null;
    }

    /**
     * Set the specified lexer to be used when parsing.
     *
     * @param      lexer lexer name
     * @return     <code>true</code> if successful, <code>false</code> otherwise
     */

    public boolean setLexer(String lexer){
        try {
            Class<?> c = Class.forName(lexer);
            Constructor<?> ctor = c.getConstructor(ParserTables.class);
            this.lex = (ParserLex)ctor.newInstance(this.tab);
        } catch (ClassNotFoundException exc){
            addError(ParserLexer.ERR_IOERR,lexer,0,exc);
            return false;
        } catch (IllegalAccessException exc){
            addError(ParserLexer.ERR_IOERR,lexer,0,exc);
            return false;
        } catch (InstantiationException exc){
            addError(ParserLexer.ERR_IOERR,lexer,0,exc);
            return false;
        } catch (NoSuchMethodException exc){
            addError(ParserLexer.ERR_IOERR,lexer,0,exc);
            return false;
        } catch (InvocationTargetException exc){
            addError(ParserLexer.ERR_IOERR,lexer,0,exc);
            return false;
        }
        return true;
    }

    /**
     * Deliver the last position reached in the input.
     *
     * @return     position
     */

    public long index(){
        return this.lastIndex;
    }

    /**
     * Set the specified lexer to be used when parsing.
     *
     * @param      lex lexer
     */

    public void setLexer(ParserLex lex){
        this.lex = lex;
    }

    /**
     * Deliver a reference to the parse tables.
     *
     * @return     reference
     */

    public ParserTables getTables(){
        return this.tab;
    }

    /**
     * Add the specified error.
     *
     * @param      msg error code
     * @param      str additional info
     * @param      point position in the input
     * @param      exc exception
     */

    private void addError(int msg, String str, long point, Throwable exc){
        ParserError re = new ParserError(msg,exc);
        if (str == null) str = "";
        re.txta = str;
        re.post = point;
        if (this.errorList == null){
            this.errorList = new LinkedList<ParserError>();
        }
        this.errorList.add(re);
    }

    /** The list of errors. */
    public List<ParserError> errorList;

    /** The parser generator. */
    private ParserBnf prs;

    /** The parser tables. */
    ParserTables tab;

    /** The parser engine. */
    ParserEngine engine;

    /** The lexer. */
    private ParserLex lex;

    /** The trace flags. */
    static int trc;

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public static void settrcflags(String s){
        trc = 0;
        for (int i = 0; i < s.length(); i++){
            trc |= 1 << (s.charAt(i) - 0x60);
        }
    }


}
