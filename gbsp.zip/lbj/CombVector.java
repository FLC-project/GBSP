/*
 * @(#)CombVector.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import lbj.HashBag.*;
import java.io.*;
import java.util.*;

/**
 * The <code>CombVector</code> class represents comb-vector compressors
 * of sparse matrices.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

/**
 * This class applies to (sparse) matrices that are made of constant elements
 * that can either be undefined (hole value) or defined (non-hole) values. 
 * Compression transforms one such matrix into one in which rows are
 * inteleaved occupying the holes that are present in each other
 * (comb-vector). The result is an object which occupies much less memory.
 * <p>
 * Each row is an array of elements, that are identified by indexes.
 * Then have elements corresponding to a range 0:n-1 of indexes.
 * Indexes >= n denote non-existing elements.
 * Accessing compressed matrix elements which correspond to non-existing
 * elements of the (origin) matrix produces an unspecified result.
 * When the holes of the (origin) matrix are known never to be accessed,
 * compression can significantly be higher.
 * In this case accessing holes delivers an unspecified result.
 * Otherwise, accessing holes delivers holes.
 * This mode of operation is specified by setting the
 * <code>HOLES_ACCESSED</code> mode.
 * <p>
 * <b>The input</b>
 * <p>
 * The matrix is provided as an array of arrays, where the latter (the rows)
 * can be null, or empty, and need not have the same length.
 * The arrays can either be ordinary arrays, or made of (index,value) pairs.
 * In the latter case, the first element contains the length of the (virtually
 * expanded) row, followed by the pairs, in increasing indexes ordering.
 * Note that the rows can have also holes at the end, which is indicated
 * by the length.
 * The rows can also be provided as a single array, which is then seen as
 * made of segments. The length of the latter is chosen automatically, unless
 * it is specified. In this case the pairs format is not supported.
 * <p>
 * The hole value is specified in the field <code>holeValue</code>.
 * <p>
 * <b>Tuning compression</b>
 * <p>
 * When there is a chance that some rows are equal, the comber could
 * improve compression at the expense of spending some compression time
 * by storing equal rows only once.
 * This mode of operation is enabled by setting the <code>FOLD_ROWS</code>
 * mode.
 * <p>
 * When there is a need to make the compressor produce smaller check values,
 * the field <code>checkBits</code> can be set to the number of bits requested
 * to represent check values (default: 32).
 * <p>
 * <b>Access</b>
 * <p>
 * Accessing elements in a compressed matrix is done as follows. The element
 * that corresponds to the element (i,j) of the input (i.e. tab[i][j]) is:
 * <ul>
 * <li>columns folded (holes accessed or not). Do this first:
 * <pre>
 *   j = jbase[j];
 * </pre>
 * <li>holes accessed:
 * <pre>
 *   idx = base[i];
 *   ele = check[idx+j] == idx & checkMask ? tabMerged[idx+j] : holeValue;
 *   checkMask: mask for checkBits, if specified
 * </pre>
 * <li>fallback (holes accessed or not, rows folded or not). Do this then:
 * <pre>
 *   idx = base[i];
 *   if (check[idx+j] == idx & checkMask){
 *       ele = tabMerged[idx+j];
 *   } else {
 *       idx = fallTable[i+prev];
 *       ele = check[idx+j] == idx & checkMask ? tabMerged[idx+j] : holeValue;
 *   }
 * </pre>
 * <li>holes not accessed:
 * <pre>
 *   idx = base[i]
 *   ele = tabMerged[idx+j];
 * </pre>
 * <li>if the rows are in a unique vector:
 * <pre>
 *   j = i % comb.segmSize;
 *   i /= comb.segmSize;
 *   ... access the element as before
 * </pre>
 * <li>if incremental combing is used (see below), use absolute row indexes.
 *   Note that when the rows are segments of a unique vector, the absolute
 *   row index is obtained by adding the number of rows previously combed
 *   even if the last one has less elements than the others:
 * <pre>
 *   j = i % comb.segmSize;
 *   i = (i / comb.segmSize) + previous;
 * </pre>
 * </ul>
 * Accessing an element of a row whose index is out of the row index range
 * causes an exception. In a comb vector this might or might not occur.
 * Sometimes an exception is caused, some others the check value tells that
 * there is no such element. This means that holes and non-existing elements
 * in origin matrices are different, but in a comb vector they might look the
 * same (however, holes in origin matrices are holes in comb vectors if
 * <code>HOLES_ACCESSED</code> set).
 * Suppose a matrix at index idx has a hole: tab[i][j] = hole.
 * It is possible to access the compressed matrix at the corresponding index
 * and determine if it contains a hole (see holes accessed, rows folded above).
 * On the other hand, it is not always possible to access the compressed matrix
 * at an index corresponding to a non-existing element. I.e. the code excerpt
 * above could cause an exception. However, if it does not, it delivers a hole.
 * When the origin rows have differing lengths, a shorter row can be treated
 * by the comber as a longer one by (virtually) adding holes at the end.
 * Since there is no guarantee of the result of accessing elements past the
 * last, except that a valid (non hole) element is not returned, what is
 * returned can as well be a hole.
 * <p>
 * <b>Performance</b>
 * <p>
 * This class is not meant to compress megabytes. It might be good enough to
 * compress images.
 * <p>
 * When <code>HOLES_ACCESSED</code> is not set, compression is almost linear
 * and slightly lower than the fill rate. I.e. matrices with a fill rate of
 * 0.4 (i.e. some fewer elements than holes) are compressed into matrices
 * which are 0.5 the total size of the origin ones. This means that
 * compression is almost complete.
 * <p>
 * When <code>HOLES_ACCESSED</code> is set, compression is almost linear and
 * half the value of the fill rate when the latter is lower than 0.35. With
 * fill rate = 0.35, the compressed matrix has the same size as origin one,
 * i.e. there is no compresson. To have some benefit, the fill rate should
 * be lower than 0.3.
 * <p>
 * Compression speed is roughly 50 values/ms in a 200 Mhz machine for 0.1 Mb,
 * for sparse matrices, and decreases rapidly (15 values/sec for 0.3 Mb).
 * <p>
 * Note that compression is meaningful with sparse tables, and not with
 * the (index,value) pairs format, that is obviously already compressed,
 * but does not allow direct access. The compression rate in this case
 * gives an idea of how much storage is needed to get direct access.
 */

/* Comb vectors have been introduced by S.C. Johnson (Yacc - yet another compiler
 * compiler, Computing Science Technical Report 32, AT&T Bell Labs, Murray Hill
 * N. J.). They allow to compress sparse matrices while keeping access time small
 * and constant.
 *
 * The input matrix
 * 
 * Since this is for sparse matrices, the input often will be in pairs
 * (index,value). When the matrix is not big, it is not important whether
 * a (index,value) pairs representation is shorter or larger than a plain
 * vector, but when it is big, the user has better to provide pairs.
 * However, there are mid cases in which it is much more comfortable for
 * the caller to provide a plain vector. Thus, both are supported.
 *
 * A vector of (buf, off, len) references to the (origin) rows is kept.
 * This makes access to rows that are segments of a unique vector and
 * separate vectors uniform in the class (normalization of rows).
 *
 * When a single sparse vector is to be compressed, it is considered as
 * made of segments. The segment size is chosen as the square root of the
 * length. This is a good compromise between number of segments and their
 * length that makes compression good.
 *
 * It is too costly to accept other types of rows, like e.g. char[].
 * Even copying internally into int[], there would then be a need to treat
 * byte[], short[], etc. The cases are too many.
 * When the origin rows have a type which is different from the supported
 * one, the caller has to copy them before calling.
 *
 * It would be possible to choose the hole value automatically by taking the
 * most frequent one, but that is not necessary since the caller knows it.
 * Note that once set, it cannot be changed in subsequent calls in incremental
 * calls.
 *
 * The output matrix
 *
 * The matrix produced is an int[]. The caller can then copy it into other
 * types of arrays, like e.g. char[] when the values allow for it.
 * To make sure that the check values can fit, checkBits must be set to the
 * number of bits to use.
 * Tha base vector can be copied in a char[] or short[] if the size of
 * tabMerged is lower than the maximum value storable in it.
 * The caller can also pack entries and check values to access both with
 * a single array access. Note that there is a need to set checkBits.
 *
 * When the matrix contain boolean values, the caller can keep only the check
 * vector when HOLES_ACCESSED (and only the merge table when it is false,
 * as usual in this case).
 *
 * Compressing rows
 *
 * Compression is achieved both by storing only once rows which are equal
 * or overlap, and by embedding rows into each other.
 * There is a big difference from matricex whose holes need be accessed and
 * matrices whose holes are never accessed.
 *
 * - holes never accessed
 *
 *   a row is placed in the first place in which it fits (i.e. in which
 *   there are holes in correspondence of its (non-hole) elements or
 *   values equal to the corresponding elements).
 *
 * - holes accessed
 *
 *   a row is placed in a place in which the intersection fits (i.e. in
 *   which there are holes in correspondence of its non-hole elements
 *   and hole elements of the row map to existing elements).
 *   If there is no place in which the row fits, the merge table is extended
 *   so as to make it fit, at worst by appending the row at the end.
 *   There is a need to tell if the element at the designed index of the
 *   merged table is an hole (for the row being accessed) or not.
 *   This is achieved by using a second vector which contains check values.
 *   When the check value at the same index is the expected one for the
 *   row, then the merged one contains a value which is not a hole.
 *   What is important for check values is that they allow uniquely to
 *   tell if an entry belongs to the given row or not. For any couple of elements
 *   (ei,ej) belonging to two different rows that are placed in the merge
 *   table so as to overlap (even partially), the check values must be
 *   different. There are the following alternatives for check values:
 *
 *      - when the rows are segments of a unique vector:
 *
 *            - index of element: each element has a unique index
 *            - start index of segment (access is uneasy since the
 *              breaking in segments is done with a segment length
 *              that is chosen by the comb vector implementation)
 *            - row number: each row has a unique number
 *            - base (see below)
 *
 *      - when the rows are separate arrays:
 *
 *            - row number: each row has a unique number
 *            - base (see below)
 *
 * The row number and the base are common to both. The base is chosen because
 * it supports folding of rows (see below).
 * It could be possible to make the elements of a row share the place in the
 * merge table allocated to equal elements of other rows if check values
 * would be sets insead of simple values. However, this is possible if the
 * number of the rows is not high, and certainly < 64, which is seldom the case.
 *
 * Sometimes it is desirable to use smaller check values to save space.
 * E.g. when check values occupy at most 16 bits, they can be stored in
 * a char[], or packed with the entries (if also them are like that).
 * In order not to limit the lengths of the rows, there is a need to
 * ensure that in the slice of the merged table in which a row is placed
 * there are no pieces of other rows with the same check value.
 * To do it, a test is made that no other row overlaps which have the same
 * (trimmed) check values.
 *
 * Check values
 *
 * Check values are the base of the corresponding row. Check values are -1
 * for entries in the merge table that are holes for any row (i.e. that
 * do not contain nonhole elements of any of the tables).
 *
 * Sharing equal rows (folding)
 *
 * To compress more, rows which have identical values are stored only once
 * (unless folding is disabled). To allow it, the bases are used as check
 * values. This imposes to assign different bases to rows which are different,
 * even to rows which are not shared but fit into each other starting at the
 * same position because otherwise, having the same base, the elements of a
 * row would be misinterpreted as elements of others.
 * However, compression does not decrease significantly because of this.
 * Therefore, bases are used as check values in all cases.
 * When a row is made of all hole values, it needs to have a unique base
 * too so as to make sure that such a base value is not used for other rows,
 * and thus appear as check in entries which by chance get overlayed on its
 * ones, generating thus entries that can feign as other entries.
 * A technique which overcomes this is to store as check value the number
 * of the rows, providing that a map is kept which tells the number of the
 * first row of each shared group, and that number is used when accessing
 * elements to test the check value. However, this requires this extra map,
 * which eventually might consume even more memory.
 * Note that it might be less than optimal to use bases as check values when
 * no sharing is requested because it shifts rows so as not to put them at
 * the same exact place (as with sharing).
 * However, the loss in practice is negligible, and the benefit is a unique
 * access method.
 *
 * When HOLES_ACCESSED is not set, holes are never accessed, there are are no
 * check values, and thus there is no need to make the bases distinct.
 *
 * The benefit of folding rows depends on the number of equal rows.
 *
 * When there is a desire to use less bits for check values, there is a
 * need to ensure that no two rows overlap which have equal masked check
 * values. This with sharing. Without sharing it is the same.
 *
 * The bases
 *
 * Null or empty rows have base = -1. When HOLES_ACCESSED is set, bases are
 * -1 only in such a case, which allows to recognise in the merged table
 * that an origin row was null, and in some cases to cause an exception.
 * This is a desirable behaviour because it makes easier to spot accesses
 * to elements which do not exist.
 * For all-holes rows when HOLES_ACCESSED is not set, base = -1 since holes are
 * not accessed. Moreover, rows which have a head of holes could happen to
 * be placed at the beginning and have thus a negative base.
 * When HOLES_ACCESSED is set bases take the values as for the other rows.
 *
 * Base vectors are stored in a dedicated array. They are not placed before
 * the merge table because the bases are used to access both the check and
 * the merge table, which would then be misaligned. Moreover, this would
 * decrease the range of values stored since they would have to be offsetted
 * by the length of the base vectors, which eventually means to restrict the
 * size of rows that can be stored (which could require to use larger data
 * types to hold the base and check tables).
 *
 * Embedding rows
 *
 * Merging is done by fitting rows into the first place which allows it.
 * Note that this is done in such a way that all elements of rows which
 * are accessible have a corresponding element in the merge table:
 *
 *    - holes accessed:
 *
 *        all holes of each row have a corresponding element, including
 *        the ones at the head and tail
 *
 *    - holes not accessed:
 *
 *        the hole at the head and tail need not map to elements.
 *
 *    merge:   ||
 *    row:     |...xxx...|
 *    result:  |...xxx...|  with holes accessed  base: 0
 *             |xxx|        without              base: -3
 *
 *    merge:   |xxxx|
 *    row:     |......yyy|
 *    result:  |xxxx..yyy|  with holes accessed
 *    result:  |xxxxyyy|    without
 *
 * Note that when the current row has a head of holes, and there are enough
 * elements in the merge table, the current row is stored with its head stuck
 * in the tail of the merge table (possibly with a gap of some holes if
 * HOLES_ACCESSED).
 *
 * When there is no suitable place to fit a row, the merged table is extended
 * by the minimum which is needed to fit then the row.
 *
 * Finding an optimal sequence for inserting rows is quite a complex problem.
 * A simple heuristics is used here.
 * The merging is in practice higher when starting with the rows which are
 * more dense.
 * It would also be possible to order the rows that are equally dense using
 * the longest sequence of nonholes as secondary keys, but compression in
 * practice does not improve on average.
 * Fitting is done by determining the places that are unoccupied on the
 * basis of the values contained in the merge table: they are the ones
 * that contain the hole value. It could be possible to use the check vector
 * instead, but it is not present in some cases.
 *
 * Fallbacking, column folding, pairs format could be supported by building
 * an int[][] matrix, pruning and folding it. This could make this class
 * simpler, at the expense of memory. It would use a lot of memory that
 * soon after becomes garbage. Therefore, the origin rows are not changed.
 * Fallbacking determines only what rows can fall back on what othes, and
 * column folding what columns fold in what others. When merging rows, each
 * row is first pruned and its columns folded, and then it is merged.
 * The entire rows would not be copied, but the single row will be, one at
 * a time.
 *
 * Fallbacking and folding columns do compress matrices that have similar
 * rows and similar columns; they do not on random matrices. It is also
 * rather difficult to generate random matrices with such characteristics
 * to determine their usefulness in general. However, that is not useful
 * either since callers do not comb random matrices. What the user can do
 * is to try fallbacking and/or column folding in some representative cases,
 * and see the benefit.
 *
 * Incremental combing
 *
 * Several maxtrices could be merged into a single comb vector by calling
 * merge() for each of them on the same comb object. Whether such matrices
 * are distinct or are blocks of rows of an overall matrix is irrelevant
 * for the compression process. However, all the rows are assigned absolute,
 * sequential numbers, as if they were part of a same overall matrix.
 * Basically, the merge table is used just as memory.
 * Since bases are used always as check values, FOLD_ROWS can be changed
 * at each call. Moreover, also FALL_BACK and FOLD_COLS can be changed.
 * The fallTable and the jbase could be build anew at each call (in which
 * case, to compute the total size of the tables, the size of the newly
 * built one must be added to the total).
 * The user would have to save them not to make them destroyed in subsequent
 * calls. For the fallTable, it could even be enlarged, as it is now, but
 * not for the jbase.
 * It depends on how the user accesses the tables. One common use is to
 * comb different matrices, in which case the caller would then like to
 * access them with the origin indexes. Another is to comb big pieces of
 * a matrix, in which case the caller would access with the indexes of the
 * overall matrix.
 * In the first case, it must copy the relevant piece of the base in a
 * new vector if a total one is delivered. In the second, then it would
 * have to sew the pieces if a partial one is delivered.
 * There is no good solution for all the seasons.
 * Note that storing the bases in the falltable makes it independent on
 * whether total or partial tables are delivered, which is instead not
 * the case if row indexes were stored (a total falltable would need
 * absolute indexes, and a partial one relative indexes).
 * Of course, it is not allowed to change accessholes.
 *
 * The combing mode is implemented as a bit set because this is more
 * readeable than passing true/false values to constructors or merge().
 *
 * Sanity check
 *
 * A method to perform sanity check is provided to allow callers to
 * troubleshoot problems. It accesses all the elements of the matrix in
 * the merge one and checks that the values are the same.
 *
 * Performance
 *
 * When HOLES_ACCESSED, since space is taken by the check values, the merge
 * table occupies (in total) at least twice as much the elements, which means
 * that the fill rate should be at most 0.5 to have some compression.
 *
 * Compression of boolean matrices
 *
 * For boolean matrices, comb vectors are not much practical because they
 * require a check vector that are large compared to the size of the matrix,
 * which can be stored as a (sparse) bit matrix.
 * Other techniques could exist, e.g. that swap rows and columns so as to
 * concentrate the 1's in a smaller area towards the beginning so as to have
 * the rest all 0's (and not to store it). However, this might not perform
 * well in general (e.g. when the matrix contains the identity it cannot
 * since there would be a 1 in every column).
 * Other techniques are mentioned in the literature (e.g. jagged diagonal,
 * BBCS, ITPACK).
 *
 * References
 *
 *  - Johnson S.C. "Yacc - yet another compiler compiler", Computing Science
 *    Technical Report 32, AT&T Bell Laboratories, Murray Hill, N.J., 1975
 *  - Dencker, P.K. Durre and J. Heuft, "Optimization of parser tables for
 *    portable compilers", TOPLAS 6:4, 546-572, 1984
 *  - Tarjan R.E and A.C. Jao, "Storing a sparse table", CACM 22:11, 606-611,
 *    1979
 *  - Fredman M.L., J. Komlos and E. Szemeredi, "Storing a sparse table with
 *    O(1) worst access time", JACM 31:3, 538-544, 1984
 */

public class CombVector {

    /** The comb-vector merge table. */
    public int[] tabMerged;

    /** The comb-vector base table. */
    public int[] base;

    /** The comb-vector check table. */
    public int[] check;

    /** The fallback table. */
    public int[] fallTable;

    /** The map of the folded columns. */
    public int[] jbase;

    /** The value which is considered the hole. */
    public int holeValue;

    /** The mode. */
    private int mode;

    /** Holes accessed mode. */
    public static final int HOLES_ACCESSED = 1 << 0;

    /** Fold rows mode. */
    public static final int FOLD_ROWS = 1 << 1;

    /** Fold columns mode. */
    public static final int FOLD_COLS = 1 << 2;

    /** Fallback mode. */
    public static final int FALL_BACK = 1 << 3;

    /** Input rows in (index,value) pairs format mode. */
    public static final int PAIRS = 1 << 4;

    /** The matrix to be compressed. */
    Object tabs;

    /** The size of the largest segment. */
    public int segmSize;

    /** The number of segments to merge. */
    private int segms;

    /** The number of segments already merged. */
    private int oldSegms;

    /** The references to the rows. */
    private int[][] bufs;

    /** The offsets at which the rows start. */
    private int[] offs;

    /** The lengths of the pruned/folCols rows. */
    private int[] lengths;

    /** The origin lengths of the rows. */
    private static int[] origLen;

    /** The size of the matrix. */
    public long tabsSize;

    /** The size of this compressed matrix. */
    public long size;

    /** The number of (non-hole) entries in the matrix. */
    public int entries;

    /** The number of holes in the matrix. */
    public int holes;

    /** The percentage of compression. */
    public int compression;

    /** The percentage of elements over the elements. */
    public int fillRate;

    /** The number of bits used for check values. */
    public int checkBits = 32;

    /** The mask for check values. */
    private int checkMask = -1;

    /** The table that maps rows to the shared ones. */
    private int[] share;

    /** The number of the rows shared. */
    private int sharedRows;

    /** The number of the columns shared. */
    private int sharedCols;

    /** The number of columns represented as one character in show. */
    public int showCompr = 1;

    /** The trace flags. */
    int trc;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    a   top trace
     *    b   details
     *    c   inconsistent values in tables of pairs
     * </pre></blockquote><p>
     */

    static final int FL_A = 1 << ('a'-0x60);
    static final int FL_B = 1 << ('b'-0x60);
    static final int FL_C = 1 << ('c'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Construct a new <code>CombVector</code> with the default compression
     * mode.
     */

    public CombVector(){
    }

    /**
     * Construct a new <code>CombVector</code> with the specified compression
     * mode.
     *
     * @param   hole the value which is the hole
     * @param   mode compression mode
     */

    public CombVector(int hole, int mode){
        this.holeValue = hole;
        this.mode = mode;
        if (((HOLES_ACCESSED & mode) == 0) &&
            ((FALL_BACK & mode) != 0)){
            throw new IllegalArgumentException();
        }
    }

    /**
     * Expand a row made by pairs into a normal subtable.
     *
     * @param      tab reference to the row
     * @param      row reference to the expanded row
     */

    void expandPairs(int[] tab, int[] row){
        if (tab == null) return;
        Arrays.fill(row,this.holeValue);
        for (int i = 1; i < tab.length; i++){
            int j = tab[i++];         // index
            if (j < 0) break;
            row[j] = tab[i];          // value
        }
    }

    /**
     * Deliver a string representing a row in which groups of elements are
     * rendered with one character. The row is shifted in such a way that
     * the first element of the row (index = off) is placed at the transposed
     * index. The string represents the contents of the transposed indexes
     * from zero to the last of the row. The range from 0 to the first element
     * of the row (excluded) is rendered with spaces.
     *
     * @param      ind transposed index
     * @param      tab reference to the row
     * @param      off offset
     * @param      len row length
     * @param      pairs <code>true</code> if the row contains pairs
     * @param      compr number of values represented as one character
     * @param      hole hole value
     * @return     string
     */

    /* The row elements are transposed and reckoned.
     * Row elements are scanned and for each non-hole, the darkness of the
     * corresponding transposed element increment. This works also with
     * pairs. The array contains the number of elements that fall in each
     * block, converted at the end in suitable characters that represent
     * darkness. Element at index off + i is displayed at ind + i, that
     * condensed becomes (ind + i) / compr.
     */

    static String showTab(int ind, int[] tab, int off, int len,
        boolean pairs, int compr, int hole){
        int blocks = (ind + len + compr - 1) / compr;
        int l = blocks;
        char[] arr = new char[l];            // picture
        int tot = 0;
        mrk: if (pairs){
            if (tab == null) break mrk;
            for (int i = 1; i < tab.length; i++){
                int k = tab[i++] - off ;     // index
                if (k < 0) break;            // sentinel
                arr[(ind + k) / compr]++;
                tot++;
            }
        } else {
            if (tab == null) break mrk;
            for (int i = 0; i < len; i++){   // scan elements
                if (tab[off + i] != hole){
                    arr[(ind + i) / compr]++;
                    tot++;
                }
            }
        }
        int olimit = ind / compr;            // nr of elements in leading white blocks
        for (int i = 0; i < arr.length; i++){
            if (i < olimit){
                arr[i] = ' ';
                continue;
            }                                // render darkness with ..
            int k = arr[i];                  // .. characters
            if (k > 16) k = 16;
            arr[i] = ".123456789abcdef#".charAt(k);
        }
        return String.valueOf(arr);
    }

    /**
     * Display a row by representing blocks of elements with one character.
     *
     * @param      ind indent for display
     * @param      tab reference to the row
     * @param      off offset
     * @param      len row length
     * @param      pairs <code>true</code> if the row contains pairs
     */

    private void showTab(int ind, int[] tab, int off, int len,
        boolean pairs){
        Trc.out.println(
            showTab(ind,tab,off,len,pairs,this.showCompr,this.holeValue) +
            " ind: " + ind + " len: " + len);
    }

    /**
     * Display the input matrix by representing blocks of elements with
     * one character.
     */

    public void showTables(){
        for (int i = 0; i < this.segms; i++){
            Trc.out.println(showTab(0,this.bufs[i],this.offs[i],
                this.lengths[i+this.oldSegms],(PAIRS & this.mode) != 0,
                this.showCompr,this.holeValue));
        }
    }

    /**
     * Display the input matrix as a piece of java source.
     *
     * @param      tabs the input matrix
     */

    public void showMatrix(Object tabs){
        int[][] matrix;
        if (tabs instanceof int[][]){
            matrix = (int[][])tabs;
        } else if (tabs instanceof int[]){
            matrix = new int[][] {(int[])tabs};
        } else {
            return;
        }
        Trc.out.println("{");
        for (int i = 0; i < matrix.length; i++){
            int[] tab = matrix[i];
            if (tab == null){
                Trc.out.print("   null");
            } else {
                Trc.out.print("   {");
                for (int j = 0; j < tab.length; j++){
                    if (j > 0) Trc.out.print(",");
                    Trc.out.print((int)tab[j]);
                }
                Trc.out.print("}");
            }
            if (i < matrix.length-1) Trc.out.print(",");
            Trc.out.println();
        }
        Trc.out.println("};");
    }

    /**
     * Compress a matrix into a comb-vector.
     *
     * @see        #merge()
     * @param      tab matrix to merge
     */

    public void merge(Object tab){
        this.tabs = tab;
        merge();
    }

    /**
     * Compress a matrix into a comb-vector.
     *
     * @see        #merge()
     * @param      tab matrix to merge
     */

    public void merge(Object tab, int mode){
        this.tabs = tab;
        merge(mode);
    }

    /**
     * Compress a matrix into a comb-vector.
     *
     * @see        #merge()
     * @param      tab matrix to merge
     * @param      mode compression mode
     */

    public void merge(int mode){
        if ((HOLES_ACCESSED & mode) != (HOLES_ACCESSED & this.mode)){
            throw new IllegalArgumentException();
        }
        if (((HOLES_ACCESSED & mode) == 0) &&
            ((FALL_BACK & mode) != 0)){
            throw new IllegalArgumentException();
        }
        this.mode = mode;
        merge();
    }

    /**
     * Compress the current matrix into a comb-vector.
     * Compression can be done incrementally by calling this method
     * several times. Compression could result lower than that obtained
     * by supplying all the matrices at once, and is usually more expensive.
     * Note that the rows that are added by subsequent calls have row
     * numbers which are higher than those of the ones previously combed
     * (and thus bases which are placed in the base vector after the existing
     * ones).
     */

    /*
     * These are the indexes in the tables when fitting:
     *
     *                   0    k                max
     * merge table      |....|................|
     * row to fit             xx.xxx.xxxxx
     *                        |<-tablen->|
     * row to fit             xxxx.xxxx.xxxx.xxxxxxx
     *                        |<---tablen---->|
     *
     *                          0    off             |end
     * row to fit       tabs[] |....|.x.xxx..xxx.xxx.|......|
     *
     * When HOLES_ACCESSED is not set, the off and end of the row are adjusted
     * to remove holes at head and tail first, then the row is dig (and
     * its base offsetted properly).
     *
     * The merge table (and check vector) in initially created as large as the
     * number of elements plus 30% (which is an average expected result), and
     * at the end resized (if needed). When there is no space, they are
     * enlarged by the amount demanded. They are not enlarged by bigger
     * amounts because hopefully there is no need.
     * At the end they are resized so as to reduce them to the minimum
     * required.
     * This is not optimal if the merge table is to be used stright away.
     * E.g. if it is larger by a 10%, then it might not be worth: resizing
     * means allocating a new table and copying the old in it.
     * Another example is when the table has to be written into a file,
     * e.g. serialized, it is not worth resizing either since it is better to
     * copy only the significant part. It is also not worth in incremental
     * combing in all calls but the last one.
     * However, the usage would become cumbersome: to disable resizing
     * initially, and to enable it lastly, and in non-incremental call
     * to take only the relevant part (e.g. when the merge table is copied
     * somewhere else). Thus, it is always resized.
     *
     * The check vector is initialised with values which are different
     * from the values which will ever hold. This allows to recognize
     * unassigned elements in the merge tables as holes.
     *
     * To speed up testing whether a row fits, and also the digging of its
     * elements, a vector nonholes is build of the indexes of its elements
     * which are not holes (i.e. a representation of the row in pairs
     * format). Since the nonholes are supposed to be fewer than the holes
     * (possibly much fewer), the test is faster.
     * This has the same form as the (index,value) pairs rows so that
     * when the input is made of pairs, there is no need to build it.
     * When finding a fitting place, and progressing along the merged table,
     * a place could be reached that the piece of the merged table past
     * it is shorter than the row to fit. In such a case only the piece
     * of the row that would overlap is checked to fit. This is done by
     * scanning sequentially the row, and stopping when an index is reached
     * that falls outside the overlap. To scan sequentially the row, the
     * indexes in (index,value) pairs must be ordered (when the row is
     * provided in this form). If they were not ordered there would be a need
     * to order them, or to test all indexes (which is time consuming).
     * Additionally, there would be a need to scan the row to determine the
     * head and the tail of holes.
     *
     * To keep compression speed high when HOLES_ACCESSED, some fast
     * mechanisms is needed to detect the rows which overlap with a given
     * one. This could be done by using two b-trees, one that represents the
     * rows ordered by start place and the other by the end place.
     * A TreeMap is not useful here because there is a need for a query
     * operation that delivers the element which is closer to the one asked
     * for (like the Arrays.binarySearch). However, ordered vectors are slow
     * in adding, b-trees in searching.
     * The solution used is to subdivide the base space in blocks and keep
     * a vector of the lists of rows which lie (in whole or in part) on
     * a block, or a map of such rows. Note that a row can lie on several
     * blocks).
     * Since testing whether a row fits in a place is rather fast because
     * the place is often found quite earley, the overlap check is done only
     * when a the result of such a test is positive (i.e. the intersection
     * of the row and the merge table is null) meaning that the place is
     * fit for digging.
     * When merge() is called to compress rows in an incremental way, the
     * size of blocks is computed again, and if greater than the previous one,
     * the vector recomputed with the new block size. Note that this does not
     * occur all the times.
     *
     * The reason for making an overlap check is explained in the following.
     * When two rows overlap, and their check values (masked) are the same,
     * another placement should be found. This occurs also when one of the
     * two is empty. Note that when a hole is accessed, the check value must
     * be different from that of the row, otherwise it is mistaken for a
     * non-hole.
     * To check this condition, it is not sufficient to test that the check
     * values of a zone in the merged table be different from the ones that
     * will be stored because when a row is digged, the check vector in
     * correspondence of its holes is not written, and therefore testing it
     * later (when fitting another row) does not reveal that a previous
     * row was there. An overlap test instead caters for holes.
     *
     * Compression can be done in incremental mode, but this is meant to
     * be used sparingly since the resulting compression is lower than
     * that done in one single operation. For this reason, no specific
     * support is provided to allocate larger tables, to enlarge them by
     * quanta, to resize them, etc.
     *
     * Combing is not a fast process. Time is not spent to extend the merge
     * table, and not in the management of blocks. It is due to the fact that
     * the merge table is scanned always from the beginning (as time passes
     * by, it gets longer and thus to find a place, a longer portion of the
     * table is scanned). E.g. with 1000 rows, 200 positions are attempted
     * to find a suitable one, and with 2000 rows, 400 positiona are attempted.
     * I.e. the number of attempts is not constant, but increases with the
     * number of rows, which explains why speed decreases rapidly.
     * The problem is that the occupied portion of the merge table tends
     * to remain evenly dense for most of the combing process. Only at the
     * end the rows with few elements are dug, filling the free slots.
     * This means that we can not use any notion of density to find a suitable
     * place in a fast way, and also of patterns because they tend to be
     * present all over the table.
     * Another method is then used: when testing whether a row can be
     * dig at a place, the first, median and last element of the row
     * are checked to fit. If they can, then all the elements are checked.
     * This allows to discart immedialtely most places.
     */

    private void merge(){
        boolean ck = (HOLES_ACCESSED & this.mode) != 0;
        boolean foldEqual = (FOLD_ROWS & this.mode) != 0;
        boolean foldCols = (FOLD_COLS & this.mode) != 0;
        boolean fallBack = (FALL_BACK & this.mode) != 0;
        boolean pairs = (PAIRS & this.mode) != 0;
        if ((FL_A & this.trc) != 0){
            Trc.out.println("merge start acc " + ck +
                " row " + foldEqual + " col " + foldCols +
                " fback " + fallBack + " pairs " + pairs);
            showMatrix(this.tabs);
        }
        if (!this.tabs.getClass().isArray()){
            throw new IllegalArgumentException();
        }
        if ((FL_C & this.trc) != 0){
            // check consistency of argument
            if (pairs){
                int[][] tabs = (int[][])this.tabs;
                for (int i = 0; i < tabs.length; i++){
                    if (tabs[i] == null) continue;
                    if ((tabs[i].length & 0x1) != 1){
                        Trc.out.printf("row: %d length not odd\n",i);
                        continue;
                    }
                    int len = tabs[i][0];
                    int prev = -1;
                    for (int j = 1; j < tabs[i].length; j+= 2){
                        if (tabs[i][j] > len-1 || tabs[i][j] < 0 || tabs[i][j] <= prev){
                            Trc.out.printf("row: %d element at %d: incorrect index\n",
                                i,tabs[i][j]);
                        }
                        prev = tabs[i][j];
                    }
                }
            }
        }

        int hole = this.holeValue;
        this.oldSegms += this.segms;
        int oldSegms = this.oldSegms;
        mapTables();                               // build the rows

        int nh = this.segmSize*2 + 1;
        if (nh < 3) nh = 3;
        int[] nonholes = new int[nh];              // table of indexes of non-holes

        if (foldEqual) buildSharedRows();          // build shared map for rows
        int[] dense = new int[this.segms];         // density map
        int[] idense = new int[this.segms];        // indexes of density
        if (fallBack){                             // build fallback table
            buildFallback(dense,idense);
        }
        if (foldCols){                             // same for columns
            buildSharedCols(dense,idense,nonholes);
        }

        long entries = 0;
        int num = 0;
        for (int i = 0; i < this.segms; i++){      // determine density of rows
            if (foldEqual &&
                (this.share[i] >= 0)){
                continue;                          // skip the shared ones
            }
            int[] tab = this.bufs[i];
            int d = 0;
            if (tab != null){
                if (!fallBack && !foldCols){
                    if (pairs){
                        if (tab.length > 1){
                            d = (tab.length - 1) >>> 1;   // nr of pairs
                        }
                    } else {
                        int end = this.offs[i] +
                            this.lengths[i+oldSegms];
                        for (int j = this.offs[i];        // scan row
                            j < end; j++){
                            if (tab[j] != hole) d++;
                        }
                    }
                } else {
                    nh = getPairs(i,nonholes);     // cope with fallback and foldCols
                    d = (nh - 1) >>> 1;            // nr of pairs
                }
            }
            dense[num] = d;
            entries += d;
            idense[num++] = i;
        }
        sort(dense,idense,0,num);                  // sort density

        int oldLen = this.tabMerged == null ? 0 :
            this.tabMerged.length;
        int[] tabMerged = enlarge(this.tabMerged,  // create/extend and initialize
            (int)(entries*1.3),hole);              // first guess for size

        int[] check = null;
        if (ck){
            check = enlarge(this.check,            // create/extend and initialize
                tabMerged.length,-1);              // ... with impossible values
        }

        this.checkMask = (int)((1L << this.checkBits) - 1);
        int checkMask = this.checkMask;

        int blockBits = 0;
        if (ck){
            int n = tabMerged.length - 1;          // compute nr of bits ..
            while (n > 0){                         // .. of blocks taking the ..
                blockBits++;                       // .. estimate table length
                n >>>= 1;
            }
            blockBits >>>= 1;                      // half the bits
            if (blockBits == 0) blockBits = 1;     // at least one
            if ((FL_B & this.trc) != 0){
                Trc.out.println("blockBits: " + blockBits);
            }
            if (oldSegms == 0){
                this.blockBits = blockBits;
                this.blocks = new int[1 << blockBits][];
            } else if (blockBits > this.blockBits){
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("re-block: " + blockBits +
                        " " + this.blockBits);
                }
                this.blockBits = blockBits;        // reconstruct table
                for (int i = 0; i < this.blocks.length; i++){
                    int[] cur = this.blocks[i];
                    if (cur == null) continue;
                    cur[0] = 1;                    // clear blocks lists
                }
                for (int i = 0; i < this.base.length; i++){
                    if (base[i] < 0) continue;
                    addBlocks(i,base[i]);
                }
            }
        }

        int[] base = enlarge(this.base,            // create/extend and initialize
            this.segms,-1);
        int max = oldLen;                          // filled part of tabMerge
        //int attempts = 0;
        for (int i = num-1; i >= 0; i--){          // scan segments
            int sn = idense[i];                    // segment number
            int asn = sn + oldSegms;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("fitting: " + i + " sn " + sn + "(" + asn + ")");
            }
            int[] tab = this.bufs[sn];
            if (tab == null) continue;             // null row
            if (this.lengths[sn+oldSegms] == 0){   // empty row
                continue;
            }
            if (dense[i] == 0){                    // row full of holes
                if (!ck) continue;                 // holes not accessed
            }

            int head = 0;                          // compute the number of ..
            int off = 0;                           // .. holes at head and tail
            int len = this.lengths[asn];

            // n.b. head represents the translation of indexes
            // to see the row as starting with the first non-hole
            nh = getPairs(sn,nonholes);
            if (!ck){
                // map the slice of the row from the first
                // non-hole to the last non-hole
                head = nonholes[1];                // holes at head
                int tail = nonholes[nh-2];
                tail = len - tail - 1;             // holes at end
                len -= head + tail;
                off = head;

                if ((FL_B & this.trc) != 0){
                    Trc.out.println("head: " + head +
                        " tail: " + tail + " len: " + len);
                }
            }

            int first = 0;                // first, mid and last ..
            int mid = 0;                  // .. indexes and values
            int last = 0;                 // if nh = 1, they are not used
            int firstVal = 0;
            int midVal = 0;
            int lastVal = 0;
            if (nh > 2){
                first = nonholes[1];
                mid = nonholes[(nh/2)|1];
                last = nonholes[nh-2];
                firstVal = nonholes[2];
                midVal = nonholes[((nh/2)|1)+1];
                lastVal = nonholes[nh-1];
            }
            if (!ck){
                first -= head;
                mid -= head;
                last -= head;
            }
            fit: {                                    // find suitable place
                int tablen = 0;
                int k = 0;                            // index of non-visited part
                seek: for (; k < max; k++){           // dig
                    tablen = max - k;                 // non-visited part
                    if (len < tablen) tablen = len;   // part of table to check
                    if (ck){
                        if (nh > 1){                  // fast fit test
                            if (((first < tablen) &&
                                (tabMerged[k+first] != hole)) ||
                                ((mid < tablen) &&
                                (tabMerged[k+mid] != hole)) ||
                                ((last < tablen) &&
                                (tabMerged[k+last] != hole))) continue seek;
                        }
                        //attempts++;
                        for (int j = 3; j < nh; j++){ // test if fits
                            int h = nonholes[j++];    // displacement of element
                            if (h >= tablen) break;   // falls out
                            if (tabMerged[k+h] != hole) continue seek;
                        }
                        if (!uniqueBase(k,blockBits,  // base not unique
                            len,base,asn)) continue seek;
                    } else {
                        if (nh > 1){                  // fast fit test
                            int m;
                            if (first < tablen){
                                m = tabMerged[k+first];
                                if ((m != hole) && (m != firstVal))
                                    continue seek;
                            }
                            if (mid < tablen){
                                m = tabMerged[k+mid];
                                if ((m != hole) && (m != midVal))
                                    continue seek;
                            }
                            if (last < tablen){
                                m = tabMerged[k+last];
                                if ((m != hole) && (m != lastVal))
                                    continue seek;
                            }
                        }
                        for (int j = 3; j < nh; j++){      // test if fits
                            int h = nonholes[j++] - head;  // displacement of element
                            if (h >= tablen) break;        // falls out
                            int m = tabMerged[k+h];
                            if ((m != hole) &&
                               (m != nonholes[j])) continue seek;
                        }
                    }
                    if (tablen < len) break;          // no space, enlarge
                    // copy the non-holes of the row
                    for (int j = 1; j < nh; j++){
                        int h = nonholes[j++] - head;
                        tabMerged[k+h] = nonholes[j];
                        if (ck) check[k+h] = k & checkMask;
                    }
                    base[asn] = k - head;
                    if (ck) addBlocks(asn,base[asn]);
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("fit in merge at: " + k);
                        showTab(0,tabMerged,0,max,false);
                        showTab(k,nonholes,off,len,true);
                    }
                    break fit;
                }
                int curlen = max;                     // enlarge tabMerge

//int newlen = (int)(tabMerged.length * 1.5);
//if (newlen < k + len) newlen = k + len;
                int newlen = k + len;
                if (newlen < 0){
                    throw new OutOfMemoryError();
                }
                if (newlen > tabMerged.length){
                    int[] newtab = new int[newlen];
                    System.arraycopy(tabMerged,0,newtab,0,curlen);
                    tabMerged = newtab;
                    if (hole != 0){
                        Arrays.fill(tabMerged,curlen,tabMerged.length,hole);
                    }
                    if (ck){
                        int[] newcheck = new int[newlen];
                        System.arraycopy(check,0,newcheck,0,curlen);
                        check = newcheck;
                        Arrays.fill(check,curlen,tabMerged.length,-1);
                    }
                }
                max = newlen;
                // place the row then at the end
                for (int j = 1; j < nh; j++){         // store row
                    int h = nonholes[j++] - head;
                    tabMerged[k+h] = nonholes[j];
                    if (ck) check[k+h] = k & checkMask;
                }
                base[asn] = k - head;
                if (ck) addBlocks(asn,base[asn]);
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("appended to merge: " +
                        k + " " + max);
                    showTab(0,tabMerged,0,max,false);
                    showTab(k,nonholes,off,len,true);
                }
            }
        }
        //Trc.out.println("attempts: " + attempts + " " +
        //    num + " " + (attempts/num));
        if (max < tabMerged.length){                  // reduce size
            int[] newtab = new int[max];
            System.arraycopy(tabMerged,0,newtab,0,max);
            tabMerged = newtab;
            if (ck){
                int[] newcheck = new int[max];
                System.arraycopy(check,0,newcheck,0,max);
                check = newcheck;
            }
        }
        this.tabMerged = tabMerged;
        this.base = base;
        this.check = check;
        complete();
    }

    /**
     * Test if the current place in the merge table is an unique base
     * for the row to be merged.
     *
     * @param      k place
     * @param      blockBits number of bits in idexes to denote blocks
     * @param      len length of row
     * @param      base base vector
     * @param      asn absolute row number
     * @return     <code>true</code> if it is unique
     */

    private boolean uniqueBase(int k, int blockBits, int len,
        int[] base, int asn){
        int checkMask = this.checkMask;
                                                      // find unique base
        int bsize = 1 << blockBits;                   // visit segments that ..
        int bmask = bsize - 1;                        // .. overlap this block
        int bstart = k | bmask;
        int bend = (k + len) | bmask;
        for (int j = bstart; j <= bend; j += bsize){  // visit blocks in ..
            int bn = j >>> blockBits;                 // .. which the place lies
            if (bn >= this.blocks.length) break;
            int[] blist = this.blocks[bn];
            if (blist == null) continue;
            for (int w = 1; w < blist[0]; w++){       // visit the list of the block
                int sw = blist[w];                    // segment (row) number
                int s2 = base[sw];
                int l2 = this.lengths[sw];
                if ((s2 - k < len) &&
                    (s2 >= k - l2)){                  // they intersect
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("segm: " + sw +
                            " " + s2 + ":" + (s2+l2) +
                            " " + k + ":" + (k+len));
                    }
                    if ((k & checkMask) ==
                        (s2 & checkMask)){
                        return false;
                    }
                }
            }
        }
        return true;
    }

    /**
     * Complete the compression.
     */

    private void complete(){
        if ((FOLD_ROWS & this.mode) != 0){
            for (int i = 0; i < this.segms; i++){     // complete the bases ..
                if (this.share[i] >= 0){              // .. for shared rows
                    this.base[i+this.oldSegms] =
                        this.base[this.share[i]];
                }
            }
        }
        if ((FALL_BACK & this.mode) != 0){
            for (int i = 0; i < this.segms; i++){     // relocate the fallback
                this.fallTable[i+this.oldSegms] =
                     this.base[this.fallTable[i+this.oldSegms]];
            }
        }
        if (this.jbase != null){                          // adjust the base ..
            for (int i = 0; i < this.jbase.length; i++){  // .. for columns
                int b = this.jbase[i];
                if (b < 0){                               // maps onto another
                    this.jbase[i] = -b - 1;
                }
            }
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("base");
            for (int i = 0; i < this.base.length; i++){
                Trc.out.println(i +  ": " + this.base[i]);
            }
            if (this.jbase != null){
                Trc.out.println("jbase");
                for (int i = 0; i < this.jbase.length; i++){
                    Trc.out.println(i +  ": " + this.jbase[i]);
                }
            }
            if ((HOLES_ACCESSED & this.mode) != 0){
                Trc.out.println("check");
                for (int i = 0; i < this.check.length; i++){
                    Trc.out.println(i +  ": " + this.check[i]);
                }
            }
            Trc.out.println("tabMerged");
            for (int i = 0; i < this.tabMerged.length; i++){
                Trc.out.println(i +  ": " + this.tabMerged[i]);
            }
            if (this.fallTable != null){
                Trc.out.println("fallTable");
                for (int i = 0; i < this.fallTable.length; i++){
                    Trc.out.println(i +  ": " + this.fallTable[i]);
                }
            }
        }
        this.size = tabMerged.length * 4 + 4;
        this.size += this.base.length * 4 + 4;
        if ((HOLES_ACCESSED & this.mode) != 0){
            this.size += this.check.length * 4 + 4;
        }
        if ((FALL_BACK & this.mode) != 0){
            this.size += this.fallTable.length * 4 + 4;
        }
        if ((FOLD_COLS & this.mode) != 0){
            this.size += this.jbase.length * 4 + 4;
        }
        this.compression = (int)(((float)this.size/this.tabsSize)*100);
        this.fillRate = (int)(((float)this.entries * 100) /
            (this.entries + this.holes));  // n.b. the origin holes and entries
    }

    /**
     * Enlarge an array.
     *
     * @param      arr reference to the array
     * @param      len increment
     * @param      val initial value for the enlarged part
     * @return     reference to the resized array
     */

    private int[] enlarge(int arr[], int len, int val){
        int[] cur = arr;                     // current array
        int curLen = cur == null ? 0 : cur.length;
        int newLen = curLen + len;           // new total length
        if (newLen < 0){
            throw new OutOfMemoryError();
        }
        int[] p = new int[newLen];
        if (cur != null){
            System.arraycopy(cur,0,p,0,curLen);
        }
        if (val != 0){                       // initialize if needed
            Arrays.fill(p,curLen,newLen,val);
        }
        return p;
    }

    /** The directory of blocks. */
    private int[][] blocks;

    /** The number of bits of the size of blocks. */
    private int blockBits;

    /**
     * Enlist the identity of the specified row in all the blocks
     * that it overlaps.
     *
     * @param      tn absolute rows number
     * @param      base index of its first element in merge table
     */

    /* The directory of blocks contains vectors with the row numbers
     * of the rows which have at least one element in the block in index.
     * The first entry in vectors contains the number of row numbers
     * stored in it.
     */

    private void addBlocks(int tn, int base){
        int bits = this.blockBits;
        int bsize = 1 << bits;
        int bmask = bsize - 1;
        int end = base + this.lengths[tn] - 1;
        if ((FL_B & this.trc) != 0){
            Trc.out.println("addBlocks: " + base + " " + end);
        }
        base |= bmask;
        end |= bmask;
        for (int i = base; i <= end; i += bsize){
            int j = i >>> bits;                           // block number
            if ((FL_B & this.trc) != 0){
                Trc.out.println("block: " + j);
            }
            int curLen = this.blocks.length;
            if (j >= curLen){                             // enlarge directory
                int newlen = curLen + 10;
                int[][] p = new int[newlen][];
                System.arraycopy(this.blocks,0,p,0,curLen);
                this.blocks = p;
            }
            int[] cur = this.blocks[j];
            curLen = (cur == null) ? 0 : cur.length;      // enlarge
            if ((cur == null) || (cur[0] == curLen)){
                int newlen = curLen + 10;
                int[] p = new int[newlen];
                if (cur != null){
                    System.arraycopy(cur,0,p,0,curLen);
                } else {
                    p[0] = 1;
                }
                this.blocks[j] = p;
                cur = p;
            }
            int k = cur[0];
            cur[k] = tn;
            cur[0]++;
        }
        if ((FL_B & this.trc) != 0){
            for (int i = 0; i < this.blocks.length; i++){
                int[] cur = this.blocks[i];
                Trc.out.print("b: " + i);
                if (cur != null){
                    for (int j = 1; j < cur[0]; j++){
                        Trc.out.print(" " + cur[j]);
                    }
                }
                Trc.out.println();
            }
        }
    }

    /**
     * Create a map of row references to the rows.
     */

    /* The map is made of an array of references, one of offsets and
     * another of the lenghts. The first two map the current rows being
     * merged, while the lengths is kept for all segments, including the
     * one merged in previous calls because it is used in the overlap check.
     */

    void mapTables(){
        int hole = this.holeValue;
        boolean pairs = (PAIRS & this.mode) != 0;
        int oldSegms = this.oldSegms;
        this.segms = 0;                                 // determine nr of rows
        long tot = 0;
        long entries = 0;
        if (this.tabs instanceof int[][]){              // segmented rows
            int[][] t = (int[][])this.tabs;
            this.segms = t.length;
            this.tabsSize += this.segms * 4 + 4;
            this.offs = new int[this.segms];
            this.lengths = enlarge(this.lengths,this.segms,0);
            this.segmSize = 0;
            ln: for (int i = 0; i < this.segms; i++){   // compute lengths
                if (t[i] == null) continue;
                int ai = i + oldSegms;
                int[] tab = t[i];
                if (pairs){
                    this.lengths[ai] = tab[0];          // first = length
                } else {
                    this.lengths[ai] = tab.length;
                }
                if (this.lengths[ai] > this.segmSize){  // compute max row
                    this.segmSize = this.lengths[ai];   // .. length
                }
                for (int j = 0; j < i; j++){
                    if (tab == t[j]) continue ln;       // identical
                }
                this.tabsSize += this.lengths[ai] * 4 + 4;
                if (pairs){                             // count entries
                    if (tab.length > 1){
                        entries += (tab.length - 1) >>> 1;  // nr of pairs
                    }
                } else {
                    int end = tab.length;
                    for (int j = 0; j < end; j++){      // scan row
                        if (tab[j] != hole) entries++;
                    }
                }
                tot += this.lengths[ai];
            }
            this.bufs = t;
        } else {                                        // unique vector
            if (pairs){
                throw new IllegalArgumentException();
            }
            int[] t = (int[])this.tabs;
            if (this.segmSize == 0){                    // not defined
                this.segmSize = (int)
                    Math.sqrt(t.length);                // default one
            }
            int len = t.length;
            if (this.segmSize > 0){
                this.segms = (len + this.segmSize - 1)  // number of segments
                    / this.segmSize;
            }
            this.tabsSize += len * 4 + 4;
            this.offs = new int[this.segms];
            this.bufs = new int[this.segms][];
            this.lengths = enlarge(this.lengths,this.segms,0);
            for (int i = 0; i < this.segms; i++){       // compute offsets
                this.offs[i] = i * this.segmSize;
                int ai = i + oldSegms;
                this.lengths[ai] = this.segmSize;
                if (i == (this.segms - 1)){
                    this.lengths[ai] = len - this.offs[i];
                }
                this.bufs[i] = t;
            }
            int end = t.length;                         // compute entries
            for (int j = 0; j < end; j++){
                if (t[j] != hole) entries++;
            }
            tot += end;
        }
        tot -= entries;                        // update nr of holes and entries
        if (tot > Integer.MAX_VALUE){
            throw new OutOfMemoryError();
        }
        if (entries > Integer.MAX_VALUE){
            throw new OutOfMemoryError();
        }
        this.holes += (int)tot;
        this.entries += (int)entries;

        if ((FL_A & this.trc) != 0){
            Trc.out.println("segms: " + this.segms +
                " segmSize: " + this.segmSize + " oldSegms: " + oldSegms);
            for (int i = 0; i < this.segms; i++){
                int ai = i + oldSegms;
                Trc.out.print("segm i: " + i + " " +
                    this.offs[i] + " " + this.lengths[ai] + " " +
                    (this.bufs[i]==null ? " null" : ""));
                showTab(0,this.bufs[i],this.offs[i],
                    this.lengths[ai],pairs);
            }
        }
    }

    /* Sharing rows */

    /* Sharing rows is done by building an hash table in which the rows
     * are entered and checked for equality. This serves to build a map
     * that makes equal rows refer to one that represents them all.
     * Sharing of rows does not increase access time since a map for rows
     * (base) must exist anyway.
     *
     * Sharing common heads
     *
     * A row shares one that is equal, but can share also onto another
     * that is longer, but has a head equal to it.
     * This can be done by keeping three hash tables, with hashing functions
     * that take the first 8, 16 and 32 elements.
     * A row |t| < 8 would be searched among all rows, one < 8 in the
     * second, one < 16 in the third, and so on.
     * There would be no need to order rows by length to make a row that is
     * longer and that is processed after another that is shorter share onto
     * it, having them a common tail.
     * This can be solved when comparing, but if row t and s are compared,
     * and s is found to be a head of t, then s shares onto t, and all the
     * rows that shared onto s should then share onto t.
     * Alternatively, a trie could be used, but it requires to built a state
     * diagram that takes a lot of memory (being another representation of
     * the rows). The trie would need to be represented in sparse or pairs
     * format. E.g. we could pack a row before inserting it in the trie,
     * and then consider each pair as a single entity.
     * Another solution is to scan columns building partitions of equivalence
     * classes of partial rows. The first column is scanned, and all the rows
     * that have the same elements put in a partition. Then the second column
     * is scanned, and the rows repartitioned. At the end, i.e. when all
     * columns have been scanned, or when only one row remains, the partitions
     * contain the rows that have a common head. There is a need to keep rows
     * that have exhaused their elements in their partition. This solution has
     * the drawback to be somehow complex in accessing the columns when they
     * are in the pairs format and when applied after fallbacking, and in not
     * being applicable with incremental calls.
     * There is no simple solution. However, in most of the cases the rows
     * have the same length (and some can be null). Therefore having a
     * complex implementation does not pay off.
     *
     * When HOLES_ACCESSED is not set, there is no need to check holes
     * when hashing. Note also that in this case a row can map into any
     * place in the merge table in which there are the same values, holes
     * excluded. In this case, scanning the merge table and noting the fit
     * that fills less holes (stopping when one is found that fills no holes,
     * or when the end is reached) would obtain better results than the
     * detection of common heads. Currently, the first place in the merge
     * table that fits (either because it has the same nonholes, or because
     * it has holes in correspondence with nonholes) is taken. Finding the
     * best would imply a much heavier search, and therefore it is not done.
     *
     * With HOLES_ACCESSED, a row cannot map in a place of the merge table
     * at which there are the same elements since the elements that are
     * not holes would belong to several rows, but the check values are not
     * sets, and thus cannot represent this. The only one case would be a
     * row that fits in a place in which the check values for its nonhole
     * elements are all the same value C, and those for its holes elements
     * are all different from C. In such a case, the row would effectively
     * share the other one. Let's make an example:
     *
     *    row          1.1.11..   base = 2
     *    merge      ..1.1.11..
     *    check      ..2.2.22..
     *    row            1.11
     *
     * However, the second row would need a base of 4 so as to access the
     * merge table at the proper offsets, but its elements have check = 2.
     * There would be a need for a second map telling the check values for
     * each row since they could be different from bases.
     * Of course, we can restrict to the cases in which the base is the same,
     * which would exactly be the same as detecting common heads.
     * Sharing in the middle, however, could not be considered as sharing for
     * fallbacking purposes. Note that fallTable contains the number of
     * the rows that share into others. Two rows that share in fallbacking
     * have simply the same fallback row number. This means that when
     * accessing, first the merge table is accessed as usual, and then if a
     * hole is found, it is accessed again using the fallback table number in
     * place of the origin one.
     * This means that fallbacking is done for heads, not for tails or
     * intermediate pieces. This makes sharing in the middle unpractical.
     *
     * Sharing rows combed in a previous call
     *
     * The hash table could be kept to share new rows with others already
     * combed.
     * However, it is not possible to keep references to the origin rows
     * combed in previous calls because the user could have reused them,
     * and even if it did not, it would be a waste of memory.
     * It would then be useless to comb incrementally since the caller would
     * not save memory. The hash table should then point into the merge table.
     * Incremental combing is ment to be used to place in a single table
     * different kinds of matrices, increasing the likeliness to save memory.
     * This means that it is unlikely that the rows combed in a call are
     * equal to the ones of a previous call. Thus, keeping the hash table
     * between calls is likely not to improve much compression.
     * Practical measurements confirm this.
     */

    /**
     * Build the map of the shared rows. Its elements contain the
     * absolute numbers of the rows which are equal to the ones
     * at index.
     */

    private void buildSharedRows(){
        int dirlen = Math.max(32,this.segms);
        HashBag set = new HashBag(dirlen);
        this.share = new int[this.segms];           // row sharing map
        Arrays.fill(share,-1);
        HashComb el = new HashComb();
        for (int i = 0; i < this.segms; i++){       // scan segments
            if ((FL_B & this.trc) != 0){
                Trc.out.println("sharing: " + i);
            }
            int[] tab = this.bufs[i];
            if (tab == null) continue;
            el.code = tab;
            el.off = this.offs[i];
            if ((PAIRS & this.mode) != 0){
                el.length = tab.length;             // the actual one
            } else {
                el.length = this.lengths[i+this.oldSegms];
            }
            el.seq = i + this.oldSegms;
            HashComb d = (HashComb)set.search(el);
            if (d != null){                         // present
                if ((FL_A & this.trc) != 0){
                    Trc.out.println("same as abs: " + d.seq);
                }
                this.share[i] = d.seq;
                this.sharedRows++;
            } else {                                // not present
                set.add(el);                        // add it
                el = new HashComb();                // create a new temp
            }
        }
    }

    /** An element of the hash table. */

    private class HashComb extends HashNode {

        /** The reference to the object to hash. */
        int[] code;

        /** The offset at which it starts. */
        int off;

        /** Its length. */
        int length;

        /** The sequence number of the object. */
        int seq;

        /** Whether it has the index,value pairs format. */
        boolean pairs;

        /**
         * Deliver a string representing this element.
         */

        public String toString(){
            return this.seq + " " +
                CombVector.showTab(0,this.code,this.off,
                    this.length,this.pairs,CombVector.this.showCompr,
                    holeValue);
        }

        /**
         * Determine if this object is equal to the specified object.
         * It delivers <code>true</code> when the argument is not
         * <code>null</code> and is an object of the same type that
         * contains the same data.
         *
         * @param   other the object to compare
         * @return  true if equal
         */

        public boolean equals(Object other){
            if (this == other) return true;
            if (other == null) return false;
            if (!(other instanceof HashComb)) return false;
            HashComb s = (HashComb)other;
            if ((this.code == null) && (s.code == null)) return true;
            if ((this.code == null) || (s.code == null)) return false;
            if (this.length != s.length) return false;
            if ((this.code == s.code) && (this.off == s.off)) return true;
            for (int i = this.off, j = s.off;
                i < this.off + this.length; i++, j++){
                if (this.code[i] != s.code[j]){
                    return false;
                }
            }
            return true;
        }

        /**
         * Return the hashcode for this element.
         *
         * @return  hash code value
         */

        public int hashCode(){
            if (this.code == null) return 0;
            int h = 0;
            int[] buf = this.code;
            int len = this.length;
            if (len > 0){
                int end = this.off + len;
                for (int i = this.off; i < end; i++){  // String hash
                    h = 31*h + buf[i];
                }
            }
            return h;
        }
    }

    /**
     * Check the consistency of this merged table.
     */

    /* Consistency it verified by accessing the elements and checking
     * that they have the same values as the origin ones. Holes are
     * also accessed when configured.
     * A test is made to ensure that the merged table has no more elements
     * than the origin rows. This test may not be done when merging
     * rows in an incremental way since there would be a need to keep
     * a reference to all the rows merged so far (when folding is enabled
     * such references exist in the hash table, but they are not kept when
     * it is not enabled). The check is done at the first merge.
     */

    boolean sanityCheck(){
        boolean res = false;
        boolean accessHoles = (HOLES_ACCESSED & this.mode) != 0;

        // test by accessing the rows through the mapped ones

        if (this.tabMerged == null){
            Trc.out.println("merge() not called");
        }
        int[] row = new int[this.segmSize];
        int oldSegms = this.oldSegms;
        boolean[] touch = null;
        if (oldSegms == 0){                    // only when first merge
            touch = new boolean[this.tabMerged.length];
        }
        ck: for (int i = 0; i < this.segms; i++){
            int tn = i + oldSegms;
            int idx = this.base[tn];
            int[] tab = this.bufs[i];
            if ((PAIRS & this.mode) != 0){
                expandPairs(tab,row);          // produce a normal row
                tab = row;
            }
            int len = this.lengths[i+oldSegms];
            if (this.jbase != null){
                len = this.origLen[i];
            }
            int off = this.offs[i];
            int end = off + len;
            bas: {                             // null, empty, etc. rows
                nobas: {
                    if (tab == null) break nobas;
                    if (len == 0) break nobas;
                    if (accessHoles) break bas;
                    for (int j = off; j < end; j++){
                        if (tab[j] != this.holeValue) break bas;
                    }
                }
                // empty, all holes, no accessHoles rows
                if (idx != -1){
                    Trc.out.println("invalid: " + i + " " + idx);
                    res = true;
                    break ck;
                }
                if (idx < 0) continue;
            }

            for (int j = off; j < end; j++){     // access each element
                int ind = j;
                int orig = tab[ind];
                if (!accessHoles &&
                    (orig == this.holeValue)) continue;
                int en = 
                    ((this.jbase == null) ? (ind-off) :
                    (this.jbase[ind-off]));
                int r = idx + en;
                int elem = this.tabMerged[r];
                if (touch != null) touch[r] = true;
                int checkValue = 0;
                err: {
                    if (accessHoles){
                        checkValue = this.check[r] & checkMask;
                        int ck = idx & this.checkMask;
                        if (checkValue != ck){                // no entry of this tab
                            if ((FALL_BACK & this.mode) != 0){
                                int ix = this.fallTable[tn];  // use fallback table
                                r = ix + en;
                                elem = this.tabMerged[r];     // contents
                                if (this.check[r] !=
                                    (ix & this.checkMask)){   // got a hole
                                    if (orig != this.holeValue) break err;
                                }
                            } else {
                                if (orig != this.holeValue) break err;
                            }
                            continue;
                        }
                    } else {
                        if (orig == this.holeValue) continue;
                    }
                    if (orig != elem) break err;
                    continue;
                }
                Trc.out.println("invalid entry in row: " + i + " at: " +
                    ind + " expected: " + orig + " actual: " + elem);
                Trc.out.println("base: " + idx + " check: " + checkValue);
                res = true;
                break ck;
            }
        }
        if (touch != null){
            for (int i = 0; i < touch.length; i++){   // test no extra elements
                if (touch[i]) continue;
                if (this.tabMerged[i] != this.holeValue){
                    if (this.tabMerged[i] == 0){      // can be an element never ..
                        continue;                     // .. written
                    }
                    Trc.out.println("spurious element: " + i);
                    res = true;
                    break;
                }
            }
        }

        // test made by accessing the origin rows

        if (this.tabs instanceof int[][]){            // segmented rows
            int[][] tabs = (int[][])this.tabs;
            ckg: for (int i = 0; i < tabs.length; i++){
                int[] tab = tabs[i];
                if (tab == null) continue;
                int len = tab.length;
                if ((PAIRS & this.mode) != 0){
                    len = tab[0];
                    expandPairs(tab,row);           // produce a normal row
                    tab = row;
                }
                for (int j = 0; j < len; j++){
                    int orig = tab[j];
                    if (!accessHoles &&
                        (orig == this.holeValue)) continue;
                    int actual = 0;
                    actual = get(i+oldSegms,j);
                    if (orig != actual){
                        Trc.out.println("get mismatch on row: " + i +
                            " at: " + j + " expected: " + orig +
                            " actual: " + actual);
                        res = true;
                        break ckg;
                    }
                }
            }
        } else {
            int[] tabs = (int[])this.tabs;
            ckg: for (int i = 0; i < tabs.length; i++){
                int orig = tabs[i];
                if (!accessHoles &&
                    (orig == this.holeValue)) continue;
                int actual = get(i+oldSegms);
                if (orig != actual){
                    Trc.out.println("get mismatch at: " + i +
                        " expected: " + orig + " actual: " + actual);
                    res = true;
                    break ckg;
                }
            }
        }
        return res;
    }

    /**
     * Deliver the contents of an element. If this merged table has
     * been constructed with <code>HOLES_ACCESSED</code> enabled and
     * the origin row contained a hole at the specified index, an
     * hole is returned, otherwise the returned value is unspecified.
     * N.B. When speed is important, this table can be accessed
     * directly without calling this method.
     *
     * @param      tab number of the row
     * @param      ele index of the element in the row
     * @return     value
     */

    public int get(int tab, int ele){
        int idx = this.base[tab];                   // base of row
        if ((HOLES_ACCESSED & this.mode) != 0){     // holes accessed
            if (idx < 0){
                return this.holeValue;
            }
        }
        if (this.jbase != null){
            ele = this.jbase[ele];
        }
        int elem = this.tabMerged[idx+ele];         // contents
        if ((HOLES_ACCESSED & this.mode) != 0){     // holes accessed
            if (this.check[idx+ele] !=
                (idx & this.checkMask)){            // got a hole
                elem = this.holeValue;
                if ((FALL_BACK & this.mode) != 0){
                    idx = this.fallTable[tab];      // use fallback table
                    elem = this.tabMerged[idx+ele]; // contents
                    if (this.check[idx+ele] !=
                        (idx & this.checkMask)){    // got a hole
                        elem = this.holeValue;
                    }
                }
            }
        }
        return elem;
    }

    /**
     * Deliver the contents of an element when the rows are segments
     * in an unique vector.
     *
     * @see        #get(int,int)
     *
     * @param      ele index of the element in the row
     * @return     value
     */

    public int get(int ele){
        int tab = ele / this.segmSize;
        ele %= this.segmSize;
        return get(tab,ele);
    }

    /**
     * Print the statistics of the compression of this matrix.
     */

    public void statistics(){
        if (this.tabMerged == null) return;
        Trc.out.println("compression: " + this.tabsSize + " to: " +
            this.size + " bytes " + this.compression + "%");
        Trc.out.println("lengths: merge: " + this.tabMerged.length +
            " check: " + (this.check == null ? 0 : this.check.length) +
            " base: " + this.base.length);
        Trc.out.println("origin entries: " +
            this.entries + " holes: " + this.holes +
            " fillRate: " + this.fillRate +
            "% shared rows: " + this.sharedRows +
            " shared cols: " + this.sharedCols);
        int entries = 0;
        for (int i = 0; i < this.tabMerged.length; i++){
            if (this.tabMerged[i] != this.holeValue) entries++;
        }
        int fillRate = (int)(((float)entries * 100) /
            this.tabMerged.length);
        Trc.out.println("entries: " + entries + " holes: " +
            (this.tabMerged.length - entries) +
            " fillRate: " + fillRate + "%");
    }

    /**
     * Build the map of the equal (shared) columns.
     */

    /* Folding columns means storing only once the equal ones. Effectively,
     * when HOLES_ACCESSED, a columnn can share another when its existing
     * elements are equal to the corresponding ones of the other.
     * When the rows have differing lengths, the last columns have nonexisting
     * elements.
     * When HOLES_ACCESSED is not set, a column can share another when its
     * nonholes elements are equal to the corresponding ones of the other.
     * It is straightforward to fold equal columns when the rows are plain
     * (sparse) because each column can be visited randomly and compared with
     * any other to find the equal ones.
     * When they are in the (index,value) pairs format, one solution is to build
     * the columns (in a (index,value) pairs format) by scanning the rows, and
     * then do the folding. Folding could then be done with an hash table in
     * which columns are inserted.
     * A simple implementation is to do this in all cases (i.e. to build the
     * transpose matrix in pairs form always). A better one is to create the
     * transpose only when the input is in pairs form. This requires to have
     * a specific hash table, that performs equality and hashing accessing
     * the elements according to their representation.
     * Note that it would be possible to access the elements also without
     * building the transpose, but it would be very lengthy since at best
     * they could be sought with a binary search on the pairs.
     * An alternative solution is to build the partition of equal columns by
     * processing the rows one at a time. The first is taken, and its elements
     * ordered. Sequences of equal values represent columns that are equal so
     * far. This is a partition of columns in equivalence classes. The second
     * row is then taken, its elements ordered, and the sequences of equal
     * values taken.
     * Each sequence is intersected with the classes, possibly leading to a
     * finer partitioning. I.e. if the partition is p0,p1,...,pn, and the
     * sequence is the set s, then the new partition is:
     *
     *    p0 & s, p0-s, p1 & s, p1-s, ..., s & {p0 | p1 | .. | pn}
     *
     * (where `&' is intersection and the last is always empty here since we
     * start with a partition that contains all possible columns). Empty sets
     * are discarted.
     * This can be implemented in the following way. Each set (class) in a
     * partition can be represented by the index I of the lowest column in it
     * (the class number).
     * A vector v is kept, long as the longest row, in which each element
     * corresponds to a column and contains the I of its class.
     * At the beginning there is only one class 0 with all the columns in it.
     * When a row is processed, the sets s of equal columns in it are taken
     * one at a time.
     * Taken a set s, the lowest column l in s is taken, v[l] noted, and for
     * all the columns i in s that have v[i] = v[l], v[i] is marked (i.e. the
     * intersection is done between s and p0). Then v is scanned, and if there
     * are elements whose value is = v[l], but are not marked, they are put in
     * a new partition. The latter are the elements of the difference p0 - s.
     * This is done by changing the class number of the intersection or the
     * difference, whichever comes first.
     * Columns in s that have the corresponding v marked are then deleted, and
     * the process done again until s becomes empty. Each time, the marks are
     * cleared.
     * Note that elements in partitions for which there is no column in the
     * current row are not moved from their partition. E.g. with a longest
     * row of 5 elements, when processing one of 3, only the first 3 columns
     * are visited to preform repartitioning. Consider this case:
     *
     *    row 0:  1 2 1
     *    row 1:  1 2 1 2 1
     *
     * after row 0 has been processed, the partition is:
     *
     *    class 0: {0,3-4} class 1: {1}
     *
     * This is consistent with the fact that columns 3 and 4 have no elements
     * so far, and thus they are considered equal to column 0.
     * However, when processing row 1, column 3 would be put in a class of
     * its own with this choice. Note that when processing row 1, column 3
     * could also be put in class 1. The problem is solved processing rows
     * in descending lenght order.
     * In set terms, denoting with r the set of all columns of the new row,
     * the new partition is:
     *
     *    p0 & s | p0 - r, (p0 & r) - s,
     *    ...
     *    pn & s | pn - r, (pn & r) - s,
     *    s & {p0 | p1 | .. | pn}
     *
     * Columns folding does not make rows be seen as longer than they are
     * because the storing is done row by row, and each row is reduced by
     * removing elements corresponding to folded columns. Storing by columns
     * would instead add elements.
     *
     * When HOLES_ACCESSED is not set, checking whether a column can fold into
     * another is different. Only the nonholes elements must be considered.
     * However, holes can be in the middle, leading to a relation of folding
     * that could be quite complex, and not representable a simple partition.
     * If not all the possible columns that can fold can be found with
     * partitioning, still many can be found.
     * The algorithm used is to remove the holes at the end of rows, and then
     * order them longest first. Then the partitions are built by considering
     * only nonholes. The longest row is processed first, and all columns
     * partitioned. The subsequent rows can only repartition existing columns;
     * the ones corresponding to elements that do not exist are left in an
     * existing partition. This is an example of less than optimal folding:
     *
     *    row 0:  ***1    part: {0-2}, {3}
     *    row 1:  1*2     part: {0},{1-2},{3}  part: {0},{1},{2},{3}
     *
     * The two partitions in row 1 are the ones obtained by processing
     * the first column, and then the third one. Here the problem is that
     * the first time holes are put in a class of their own.
     * There is no simple solution: putting hole in the first class ever made
     * does not work since column 3 would then map to 0, which is not correct.
     * Putting the first time all the holes in the class of the first nonhole
     * would not work as well because the longest row could be made entirely
     * of holes (besides making such a class have a number that is not that
     * of the lower among its columns, forcing to scan v always entirely).
     * The issue here is that after the first row has been processed, we
     * cannot tell whether a column could be moved to another class. E.g.
     *
     *    row 0:  *1*
     *    row 1:  1
     *    row 2:  121
     *
     * After row 0 has been processed all elements are in a class 0.
     * When row 1 is processed we put col 0 in a new class, and keep all the
     * others in another, but we do not remember which where holes and which
     * not. The ones that were holes could be moved to another partition.
     * Row 2 would put col 2 in a class of its own, even if it could stay
     * in the same as the first. To detect this, columns must be compared.
     * However, even comparing columns would not obtain the maximum column
     * folding possible. Consider this case:
     *
     *    row 0:  *1
     *    row 1:  1*
     *
     * We could store only one column 1 1 since holes are not accessed.
     *
     * Access:
     *
     * A map jbase is built, indexed with column numbers, that has values
     * >= 0 denoting transposed indexes of columns that are retained (because
     * they are the representatives of a class), and < 0 values denoting
     * columns that fold onto some others. A value v < 0 denotes a transposed
     * index = -v - 1; Column 0 will have map value zero.
     * This serves for the removal of columns, but it is not convenient for
     * accessing, for which a normal map is better. Then merge() changes these
     * values into the transposed indexes.
     * When accessing, to avoid to test jbase != null, j = jbase[j] is
     * always done with FOLD_COLS (even if there are no shared columns
     * actually).
     *
     * Column folding does not depend on fallbacking. Let's take a row t
     * and another f on which t falls back. Let be t' the pruned t.
     * Two columns that are equal on t and f, are still equal on t' and f
     * (because they are both pruned or both kept), and two that were
     * different cannot become the same in t' and f (if
     * they are different in f, they cannot be equal in t' and f, otherwise
     * they are different in t, and cannot become equal with pruning).
     *
     * After having folded the columns, some rows that did not share before
     * can share. E.g.:
     *
     *    row 0:  *1*2*1**    *12
     *    row 1:  *1          *1
     *    row 2:  *1*2        *12
     *
     * rows 0 and 2 share. However, for the reasons reported below (see
     * fallbacking), this is not done.
     *
     * It is meaningless to be used in incremental mode. An error is issued.
     *
     * Folding of columns increases access time since there is a need to
     * map the column number.
     */

    void buildSharedCols(){
        int[] longest = new int[this.segms];
        int[] ilongest = new int[this.segms];
        int[] row = new int[this.segmSize];
        buildSharedCols(longest,ilongest,row);
    }

    /**
     * Build the map of shared columns.
     *
     * @param      longest reference to a temporary array long as the
     *             number of rows
     * @param      ilongest reference to a temporary array long as
     *             number of rows
     * @param      row reference to a temporary array to expand rows
     */

    void buildSharedCols(int[] longest, int[] ilongest, int[] row){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("foldColumns");
        }
        boolean accessHoles = (HOLES_ACCESSED & this.mode) != 0;
        int hole = this.holeValue;
        int oldSegms = this.oldSegms;
        int[] idx = new int[this.segmSize];           // temp indexes
        int[] parts = new int[this.segmSize];         // partitions
        boolean[] marks = new boolean[this.segmSize]; // marks
        for (int i = 0; i < this.segms; i++){         // order by longest
            longest[i] = -this.lengths[i+oldSegms];
            ilongest[i] = i;
        }
        sort(longest,ilongest,0,this.segms);
        for (int y = 0; y < this.segms; y++){         // process rows
            int i = ilongest[y];
            if ((FL_B & this.trc) != 0){
                Trc.out.println("row: " + i);
            }
            int[] tab = this.bufs[i];
            if (tab == null) continue;
            int len = this.lengths[i+oldSegms];
            if (len == 0) continue;

            // expand tab into row. There is no gain in generating
            // instead a pairs row because the holes must be treated

            if ((PAIRS & this.mode) != 0){            // expand them
                for (int j = 0; j < len; j++){        // fill used part with holes
                    row[j] = this.holeValue;
                }
                for (int j = 1; j < tab.length; j++){
                    int k = tab[j++];                 // index
                    if (k < 0) break;                 // sentinel
                    row[k] = tab[j];                  // value
                }
            } else {                                  // copy row because ..
                int off = this.offs[i];               // .. it must be sorted then
                for (int j = 0; j < len; j++, off++){
                    row[j] = tab[off];
                }
            }
            int trimLen = len;
            if (!accessHoles){
                int j = len - 1;
                for (; j >= 0; j--){                  // holes at tail
                    if (row[j] != hole) break;
                }
                trimLen = j + 1;
            }
            for (int j = 0; j < idx.length; j++){
                idx[j] = j;
            }
            sort(row,idx,0,len);                      // sort
            if ((FL_B & this.trc) != 0){
                Trc.out.print("current part:");
                for (int w = 0; w < parts.length; w++){
                    Trc.out.print(" " + parts[w]);
                }
                Trc.out.println();
                Trc.out.print("values:");
                for (int w = 0; w < len; w++){
                    Trc.out.print(" " + row[w]);
                }
                Trc.out.println();
            }

            // here each sequence of equal values is processed in turn.
            // If all the values in a sequence belong to a same partition,
            // the loop counter is advanced to the next sequence, otherwise
            // it is advanced to the index of the first value in the sequence
            // that does not. Values that have already been processed are
            // skipped by changing their index to -1, that never occurs.
            // Eventually all values in a sequence are processed, and the
            // index is advanced to the next one.

            for (int j = 0; j < len;){                // scan sequences
                if (idx[j] == -1){
                    j++;
                    continue;
                }
                int val = row[j];                     // value
                if (!accessHoles && (val == hole)){
                    j++;
                    continue;
                }
                int ix = idx[j];                      // index
                int partNr = parts[ix];               // partition number
                int dif = -1;
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("set: " + val + " " + partNr);
                }
                for (; j < len; j++){
                    if (idx[j] == -1) continue;
                    int v = row[j];                   // value
                    if (v != val) break;              // end of equal cols
                    ix = idx[j];                      // index
                    if (parts[ix] == partNr){         // in this partition
                        idx[j] = -1;                  // remove it
                        marks[ix] = true;
                    } else {
                        if (dif < 0){                 // no difference yet
                            dif = j;
                        }
                    }
                }
                if (dif >= 0){
                    j = dif;                          // restart
                    if ((FL_B & this.trc) != 0){
                        Trc.out.println("restart: " + j);
                    }
                }

                // repartition: if the first element of the class is marked,
                // then all the marked ones stay in the same class,
                // otherwise they are all put in a new one (and the unmarked
                // ones do not change class number)

                int newpart = -1;                     // new part number
                boolean keep = marks[partNr];         // intersection keeps part number
                for (int w = partNr; w < trimLen; w++){   // split partition
                    if ((parts[w] == partNr) &&       // of this partition
                        (marks[w] != keep)){          // not as the first's
                        if (newpart < 0){             // new part number
                            newpart = w;
                        }
                        parts[w] = newpart;
                    }
                    marks[w] = false;
                }
                if ((FL_B & this.trc) != 0){
                    Trc.out.print("split:");
                    for (int w = 0; w < parts.length; w++){
                        Trc.out.print(" " + parts[w]);
                    }
                    Trc.out.println();
                }
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.print("new part:");
                for (int w = 0; w < parts.length; w++){
                    Trc.out.print(" " + parts[w]);
                }
                Trc.out.println();
            }
        }

        // build the map

        int[] max = idx;                       // max transposed col, reuse idx
        int n = 0;                             // translated cols index
        for (int i = 0; i < parts.length; i++){
            int c = parts[i];
            if (c < i){                        // a duplicated one
                parts[i] = -parts[c] - 1;      // translated of its class nr
                                               // -1 to make negative: it can be 0
            } else {                           // a unique one
                parts[i] = n++;                // the translated one
            }
            max[i] = n - 1;
        }
        this.jbase = parts;

        // compute the new lengths

        this.origLen = new int[this.segms];    // keep origin lengths
        for (int i = 0; i < this.segms; i++){  // for all rows
            int[] tab = this.bufs[i];
            int ai = i + oldSegms;
            int len = this.lengths[ai];
            this.origLen[i] = len;
            if (tab == null) continue;
            if (len == 0) continue;            // empty row
            this.lengths[ai] = max[len-1] + 1; // highest transposed index + 1
            if ((FL_B & this.trc) != 0){
                Trc.out.println("new length for: " + i +
                    " " + this.lengths[ai]);
            }
        }
        this.sharedCols = 0;
        for (int i = 0; i < parts.length; i++){  // count the shared ones
            if (parts[i] != i) this.sharedCols++;
        }
        if ((FL_A & this.trc) != 0){
            Trc.out.println(sharedCols + " equal columns " +
                this.segmSize + " total");
            for (int i = 0; i < this.jbase.length; i++){
                Trc.out.println("jbase i: " + i + ": " + this.jbase[i]);
            }
        }
    }

    /**
     * Deliver a pairs representation of the specified row, having applied
     * column folding and fallback pruning.
     *
     * @param      rn number of the row
     * @param      row reference to the row in which the values are stored
     * @return     index of the last value in row + 1
     */

    /* The origin row is copied in the case of pairs because it is not
     * big, and makes simpler the management of the temporary row.
     * Instead of copying it, a reference to the origin row could be
     * returned (in which case there is a need to return a second value).
     *
     * Note that the fallback table is accessed with nonfolded indexes in
     * the case of column folding. Then, if the entry is not pruned, and
     * not folded, it is recorded with its translated index in the row.
     */

    int getPairs(int rn, int[] nonholes){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("getPairs row: " + rn);
        }
        int[] tab = this.bufs[rn];
        int arn = rn + this.oldSegms;
        int len = this.lengths[arn];
        int hole = this.holeValue;
        int[] jbase = this.jbase;
        int nh = 1;
        nonholes[0] = len;

        int[] ftab = null;
        int foff = 0;
        int flen = 0;
        if ((this.fallTable != null) &&           // fallback done
            (this.fallTable[arn] != arn)){        // it has a fallback
            int f = this.fallTable[arn];
            f -= this.oldSegms;
            ftab = this.bufs[f];
            foff = this.offs[f];
            flen = ((PAIRS & this.mode) != 0) ? ftab.length :
                ((jbase == null) ?
                this.lengths[f+this.oldSegms] : this.origLen[f]);
        }
        coll: if ((PAIRS & this.mode) != 0){      // copy/prune origin row
            if (tab == null) break coll;
            int l = tab.length;
            int r = 1;                            // index in ftab when pairs
            pr: for (int i = 1; i < l; i++){
                int ix = tab[i];
                int v = tab[++i];                 // value
                while (r < flen){
                    int fx = ftab[r];             // index
                    if (ix == fx){                // found
                        int w = ftab[++r];        // value
                        r++;
                        if (v != w) break;        // keep
                        continue pr;
                    } else if (ix > fx){          // continue ftab scan
                        r++;
                    } else {                      // ftab has it not
                        break;
                    }
                }
                if (jbase != null){               // folded columns
                    if (jbase[ix] < 0) continue;  // skip
                    ix = jbase[ix];               // traslate index
                }
                nonholes[nh++] = ix;              // traslate index
                nonholes[nh++] = v;
            }
        } else {                                  // build pairs
            if (tab == null) break coll;
            int off = this.offs[rn];
            int end = off +
                ((jbase == null) ? len :          // length
                this.origLen[rn]);                // origin length
            for (int i = off; i < end; i++){
                if (tab[i] != hole){
                    int ix = i - off;
                    if (ix < flen){
                        if (tab[i] == ftab[foff+ix]) continue;
                    }
                    if (jbase != null){           // folded columns
                        if (jbase[ix] < 0){       // skip
                            continue;
                        }
                        ix = jbase[ix];           // traslate index
                    }
                    nonholes[nh++] = ix;
                    nonholes[nh++] = tab[i];
                }
            }
        }
        if (nh < nonholes.length){                // place sentinel
            nonholes[nh] = -1;
        }
        return nh;
    }

    /**
     * Sort the specified array into ascending numerical order, and
     * report the origin indexes of the elements in the index array.
     * The algorithm is an adapted version of: Jon L. Bentley and
     * M. Douglas McIlroy's "Engineering a Sort Function",
     * Software-Practice and Experience, Vol. 23(11) P. 1249-1265 (November
     * 1993). The index array must be initialized with the indexes of the
     * elements.
     *
     * @param      x reference to the array to sort
     * @param      idx reference to the index array
     */

    static void sort(int[] x, int[] idx, int off, int len){
        int tmp;
        int end = off + len;
        if (len < 7){                       // small arrays: insertion sort
            for (int i = off+1; i < end; i++){
                int v = x[i];
                if (v >= x[i-1]) continue;  // in order
                int iv = idx[i];
                int j = i-1;                // not in order
                for (; j >= off; j--){      // find place and make room ..
                    if (v >= x[j]) break;   // .. shifting down
                    x[j+1] = x[j];
                    idx[j+1] = idx[j];
                }
                x[++j] = v;                 // put element in its place
                idx[j] = iv;
            }
            return;
        }

        // choose a partition element, v
        int m = off + len/2;                // small arrays, middle element
        if (len > 7){
            int l = off;
            int n = off + len - 1;
            if (len > 40){                  // big arrays, pseudomedian of 9
                int s = len/8;
                l = median(x,l,l+s,l+2*s);  // 0, 1/8, 2/8
                m = median(x,m-s,m,m+s);    // 3/8, 4/8, 5/8
                n = median(x,n-2*s,n-s,n);  // 6/8, 7/8, 1
            }
            m = median(x,l,m,n);            // medium size, median of 3
        }
        int v = x[m];

        // move elements so as to have: all < v | all = v | all > v
        // by moving the v's to the borders first, and then back in the middle.
        // First step:
        //     <--p1-><-p2-><--p3-><--p4-->
        //     off    a    cb     d        end
        //     vvvvvvvxxxxxxyyyyyyyvvvvvvvv
        //        = v | < v | > v |  = v

        int a = off;
        int b = a;
        int c = end - 1;
        int d = c;
        for (;;){
            while ((b <= c) && (x[b] <= v)){  // move v's at beginning
                if (x[b] == v){
                    tmp = x[a];               // swap x[a] and x[b];
                    x[a] = x[b];
                    x[b] = tmp;
                    tmp = idx[a];             // and indexes
                    idx[a] = idx[b];
                    idx[b] = tmp;
                    a++;
                }
                b++;
            }
            while ((c >= b) && (x[c] >= v)){  // move v's at end
                if (x[c] == v){
                    tmp = x[c];               // swap x[c] and x[d];
                    x[c] = x[d];
                    x[d] = tmp;
                    tmp = idx[c];             // and indexes
                    idx[c] = idx[d];
                    idx[d] = tmp;
                    d--;
                }
                c--;
            }
            if (b > c) break;
            tmp = x[b];                     // swap x[b] and x[c];
            x[b] = x[c];
            x[c] = tmp;
            tmp = idx[b];                   // and indexes
            idx[b] = idx[c];
            idx[c] = tmp;
            b++;
            c--;
        }

        // swap elements = v to middle
        int s = a - off;
        if ((b - a) < s) s = b - a;         // smaller between p1 and p2
        sliceSwap(x,idx,off,b-s,s);         // swap what part of p1 is needed
        s = end - d - 1;
        if ((d - c) < s) s = d - c;         // same, for p3 and p4
        sliceSwap(x,idx,b,end-s,s);

        s = b - a;                          // recursively sort p2
        if (s > 1){
            sort(x,idx,off,s);
        }
        s = d - c;                          // same, on p3
        if (s > 1){
            sort(x,idx,end-s,s);
        }
    }

    /**
     * Swap the first slices of the specified arrays with the second ones.
     *
     * @param      x reference to the array
     * @param      idx reference to the second array
     * @param      a start of the first slices
     * @param      b start of the second slices
     * @param      n slice length
     */

    private static void sliceSwap(int x[], int[] idx, int a, int b, int n){
        int tmp;
        for (int i = 0; i < n; i++, a++, b++){
            tmp = x[a];             // swap x[a] and x[b];
            x[a] = x[b];
            x[b] = tmp;
            tmp = idx[a];           // and indexes
            idx[a] = idx[b];
            idx[b] = tmp;
        }
    }

    /**
     * Deliver the index of the median of the specified three array elements.
     *
     * @param      x reference to the array
     * @param      a index of the first element
     * @param      b index of the second element
     * @param      b index of the third element
     * @return     index
     */

    private static int median(int x[], int a, int b, int c){
        return (x[a] < x[b]) ?
            ((x[b] < x[c]) ? b : (x[a] < x[c] ? c : a)) :
            ((x[b] > x[c]) ? b : (x[a] > x[c] ? c : a));
    }

    /* Fallback */

    /* The whole technique is based on the idea to prune rows so as to
     * make them much more sparse and thus apt to be merged, which is
     * otherwise much less convenient. Pruning means encoding them as few
     * exceptions with respect to some other row. I.e. we remove entries
     * in rows which are the same as those of other rows which can act as
     * second choice. Nonhole entries in a row that are the same as
     * corresponding holes in its fallback table are (virtually) turned into
     * holes. When a hole is found by accessing a row, its fallback is
     * accessed then.
     *
     *        row       fallback       pruned row
     *
     *        hole      hole           hole
     *        nonhole   same           hole          <===== pruned
     *        nonhole   nonhole diff   nonhole
     *        hole      nonhole        --does not occur--
     *
     * A special case occurs for entries that are holes: the corresponding
     * entries in the fallback must also be holes. Since holes causes the
     * fallback to be accessed, the value obtained at that index must be the
     * same.
     * To avoid to access a sequence of fallback rows when looking for an
     * element, the ones which already have a fallback one are not considered
     * as fallback targets for other rows. I.e. fallbacking is done with
     * one hop only.
     * There is another reason not to do it: a row that will be pruned will
     * have few nonholes, and therefore would not be a good target. Moreover,
     * there would be a need to prune it before comparing. Note that if we
     * prune a row before comparing, we can take it as fallback target with
     * one hop only.
     *
     * The whole point here is to find out as many similarities as possible.
     * Rows can glue together more or less depending on the ordering of visit.
     * It is not so simple to find an ordering which maximizes compression.
     * Rows are linked in a similarity relation which is reflexive,
     * symmetrical, but not always transitive. This means that a row has
     * a number of similar rows, which in turn have similar rows, and so on.
     * The graph is more dense on some points than others. Depending on
     * the criteria to partition it, pruning changes.
     * E.g. in a lexer, taking a row of a keyword, and making all the
     * ones of the other keywords fallback to it, vs taking the one of the
     * indentifier, and making all the keyword ones fallback to it does not
     * deliver the same compression (see below).
     * The problem then is to find a reasonable criterion for visiting
     * rows.
     * For specific matrixes, a dedicated criterion could be used. E.g.
     * in a lexer we could take first the ones which belong to non-literal
     * lexemes, and then the others. However, that is not simple to do
     * because what is evident in an automaton are the lexemes recognised
     * in final states, but not the ones on the way in the intermediate states.
     * Moreover, that would be not general.
     *
     *  -  An alternative is to visit rows sequentially and seek doublets
     *     only among the preceding ones. If a row is similar to one that
     *     follows, it will be the latter to be pruned.
     *     In so doing the falling back of a row onto another one which has
     *     already a fallback does not occur.
     *     I.e. if doublets are sought also ahead, and one is found, then the
     *     current one could fallback onto it.
     *     The other one does not already have a fallback and thus, up to this
     *     point, it is valid. However, when proceeding and visiting it, no
     *     knowledge is there to remember that it was a fallback target, and
     *     thus that it must be left as it is.
     *     When a row fallsback onto a following one, the latter must be
     *     skipped when it is visited, otherwise it could fallback and thus make
     *     two hops for the first one.
     *     The problem is that processing rows in ascending order is not
     *     optimal. E.g. the row which catches most letters in a lexer, in a
     *     looping state of a rule for an indentifier can come after that of
     *     several keywords, which would not fallback to it.
     *  -  Another altenative is to visit them sequentially, but make each
     *     row fallback onto the one at the shortest distance from it among
     *     all the others.
     *     First, the rows which are shared among states are marked so as
     *     to skip them when finding doublets. Keeping them causes problems
     *     because when a rows is found to be similar to a following one,
     *     the second is locked (see below), but if there are other entries
     *     pointing to it, also them must be locked.
     *     The second is locked by making it fallback to itself: this is an
     *     allowed value which stands for lock. When visiting rows, the
     *     locked ones are skipped because they must not fallback.
     *     At the end, locks are removed. Note that locks are placed only
     *     on the first among shared rows, and thus do not conflict with
     *     the recording of the fallbacks of the others.
     *     A row can not fallback onto one which already has a fallback,
     *     but it can on a locked one.
     *  -  Another alternative for a lexer is to count the number of incoming
     *     arcs, and start by taking the states which have the highest number
     *     of them. This resembles tunnelling since those states are the
     *     catch-all ones, to which tunnelling is done.
     *  -  Another alternative is to determine the number of rows which
     *     are similar to each row, and then to take the ones which have the
     *     highest number first.
     *  -  Another alternative is to start with a partitioning and then apply
     *     some Brownian shaking giving each partition the goal to grow by
     *     eating what is at its border. Big partitions have less coherence
     *     and thus can loose elements more easily than small partitions.
     *  -  Another alternative is to order the rows for numbers of entries
     *     and process the less dense first. Since rows can be similar to
     *     others which have less elements, but not to the ones which have more,
     *     chances are greater to compress.
     *     Rows which have many identical entries (purity) are more likely to
     *     act as fallbacks than others (see below). Thus, the rows with the
     *     same density are reordered by saturation.
     *     This is an ordering which provides good results in practice.
     *     Only unique rows are visited. Visiting them more than once changes
     *     the ordering and makes the result unpredictable.
     *     When two rows contain very few elements, all different, they seem
     *     close, but are not. This is detected by seeing how many elements
     *     are removed: if none, no fallback is done. This is the alternative
     *     chosen here.
     *
     * The algorithm takes the rows and sorts them by increasing number
     * of nonholes and among the ones which have the same nonholes, by
     * decreasing number of same entries (i.e. frequency of nonhole values,
     * a.k.a purity).
     * Then it takes each row at once and compares it to find the one that
     * is closer to it, that becomes its fallback row.
     * When searching for a fallback row, the preceding rows are taken
     * and the distance with the current one computed. This is so since a
     * row can only fallback onto less dense ones when the rows have
     * the same length. When the lenghts differ, there is still a higher
     * chance to fallback on a less denser one. Moreover, having an ordering
     * avoids circular fallbacking.
     * It would be possible to try first the rows which are closer, scanning
     * the rows in reverse ordering since they are likely to be less distant,
     * and also to stop when the distance surpasses the threshold.
     * However, fallbacking is meaningful when it finds many rows to prune.
     * In such a case, as the process goes on, most of the previous rows have
     * a fallback target, and thus the comparison is done with very few
     * rows. Moreover, stopping at the threshold does no guarantee that the
     * closest row would be found.
     *
     * Note that it is not convenient to use fallback rows which have a
     * number of elements that differ more than a threshold.
     * The reason is that without a threshold, the second row is likely to
     * fallback on the first one, and then the third cannot fallback on the
     * second (since it has already a fallback) and thus it falls on the
     * first. The same happens for most of the following ones. However, this
     * is not an optimal choice since the distance tends to be big between
     * rows and their fallbacks.
     * A threshold breaks this allowing some rows in the middle to become
     * targets of some that follow.
     * To determine the purity of a row, if we knew that the values were
     * bounded, we could use a frequency table f, scan the elements of the
     * row, and for each element e increment f[e]. When they are not bounded,
     * which is the general case, the values are sorted, and the longest
     * sequence of equal values determined.
     * The reason for sorting by purity is that more pure rows are better
     * targets than less pure ones. E.g. in a lexer, each state of a keyword
     * has a row that goes to another state with a letter, and to a
     * different one for all the others, e.g. 111121111. This can fallback on
     * the row used for indentifiers, that has the same state on all letters,
     * e.g.: 111111111. Of course, it is possible to make the latter fallback
     * on the former, but it is less convenient since the other rows of
     * keywords are closer to it than between themselves.
     *
     * The threshold can be varied. A higher threshold increases the number
     * of rows which are fallbacked, but leaves in them more elements.
     * The threshold is a percentage of the row density, currently 20%.
     * In practive compression does not improve much (or even at all)
     * when it is above this value.
     *
     * Transition tables of lexers are large mainly because of the presence
     * of keywords, for which there are many rows very similar, and all
     * the other rows rather distanct. Thus there is no need to use a
     * complex algorithm to determine the order to process rows.
     *
     * Pruning can also be done by removing the restrictions that fallback
     * targets must have holes in the elements where that are holes in the
     * origin row to be pruned. To do it, a special "fallback" value can
     * be used. However, it leaves the entries nonempty, which impairs then
     * compression.
     *
     * Fallback and row sharing
     *
     * Supporting sharing in comb-vectors could be important with pruning.
     * Without row sharing, equal rows which are pruned are replicated
     * keeping the elements which are left in each of them.
     * If the first among shared rows has a fallback, the others will not
     * fallback onto it, but on that of the first. 
     * This should not be a problem if two identical rows are guaranteed
     * to fallback one onto another, but depending on the similarities among
     * them it could be more convenient to prune all of them against another
     * one. This shows that finding a good solution is not simple, and that
     * the simplest way is to use a good heuristic.
     *
     * After having pruned the rows, rows that were different can share,
     * though retaining their specific fallback. E.g.:
     *
     *   row 1      1.2.3.4
     *   fallback   1.2.3..       pruned  ......4
     *   row 2      ..2.3.4
     *   fallback   ..2.3..       pruned  ......4
     *
     * This would suggest to find a solution in which the sharing of rows
     * is computed before and/or after so as to maximize compression.
     * Let's consider these rows, and two possible fallbacking:
     *
     *          row    fallback pruned  fallback pruned
     *   f      11233    none   11233     none   11233
     *   t0     11444    t0     ..444     t0     ..444
     *   t1     11444    t0     ..444     t1     .....
     *
     * Let's try to decouple fallbacking with row sharing, and see if
     * it is possibe to prune without having previously determined the
     * equal rows.
     * Let's study first the case FOLD_ROWS. Note that the first
     * fallbacking above is better than the second if t0 and t1 share.
     * When determining fallback targets, we can check whether a row is
     * equal to the target.
     * This occurs when the distance is zero because it measures the
     * differences. In such a case, we take the fallback of the target.
     * Basically, we are taking the same target as that of an equal row
     * because that is a good target.
     * Since the rows are processed in order, the target has its fallback
     * (if any) already determined.
     * Note that we must do this test also when f has already a fallback.
     * When f in turn is equal to a row s we would get the fallback of s.
     * Note that t1 must not fallback on t0 if they share the same place
     * in the merge table: suppose we say that t1 fallsback on t0. Then t0
     * will be pruned and stored, and then t1 will not be stored, and have
     * the same base as t0, but have t0 as fallback, which is wrong.
     * It must have f.
     * Then, because of sharing, f could share the merge table with s, but
     * that is not a problem since t' = f'. Since sharing places two rows
     * in the same place when they are actually equal (i.e. the pruned ones),
     * there is no problem even when t and f actually share other rows
     * instead of themselves.
     * However, the distance can be zero also in cases in which the rows
     * are not equal (e.g. f can have extra elements at the end).
     * In this case making t not fallback on f could be a loss. To avoid
     * this, there is a need to note that these rows must share, and make
     * the algorithm for row sharing take this into account..
     *
     * Let's study then the case FOLD_ROWS disabled. In this case we simply take
     * equal rows as good targets. We can fallback t on f thus achieving
     * similar benefits as row sharing. Of course, here t cannot fallback on
     * f if f has already a fallback.
     *
     * Decoupling fallbacking with row sharing is a good idea since the latter
     * could be done after, and on pruned rows.
     * However, finding what rows can share after is complex (it has to
     * take into account what rows fallbacking has already doomed to do)
     * and is time consuming since the hash table should prune rows on the
     * fly. Moreover, the gain is not certain. This is why it is not done.
     *
     * Access is slower in general since the chance that fallback rows must
     * be accessed is larger if pruning has removed most elements. It is also
     * not convenient to access fallback rows before the nominal ones.
     * It is also not possible to have fallback rows to be accessed before
     * the others when they contain no-state since no pruning will be done.
     *
     * Pruning does not decrease columns, but the rows become not so full
     * as before, and thus more apt to be compressed.
     * Rows which have no fallback are fallbacked onto themselves
     * (autofallback) so as to avoid a test when accessing: the fallback
     * table is always accessed when a hole is found and in this case a
     * hole is found again.
     * Autofallback increases speed by 2%.
     *
     * The fallTable could be put at the beginning of the merge table
     * (but it would waste space in the check vector). Anoter solution,
     * alternative to keeping a separate vector is to place the index f of
     * the fallback target of row t in the merge table immediately before t.
     * This is possible when there is no sharing of rows. This requires that
     * the base vector maps rows by taking this into account (i.e. that it
     * contains the indexes of the start of the rows and not those of the
     * elements that are prepended). Note that this solution wastes space
     * in the check vector too.
     *
     * Relocating fallbacks
     *
     * The values stored in the fallback table are eventually the bases
     * and not the row indexes. This makes faster the access. At first, the
     * indexes are stored because that is more convenient, and at the end
     * of merge() they are converted into bases (that are known only at
     * that point).
     */

    /**
     * Determine the fallback rows.
     */

    /* The fallTable contains the number of the row to access as a second
     * choice. In the case of FOLD_ROWS disabled, there is a need to have the
     * number of the fallback row because that is used to test the check
     * value. Thus, the fallTable must contain row numbers. However, with
     * FOLD_ROWS enabled, that is not needed, and we can store the bases in
     * fallTable, thus shortening the access.
     * This is not done here; it can be easily done by the caller if it
     * cooses this approach.
     *
     * no HOLES_ACCESSED:
     *
     * When finding a fallback row, the holes in the origin row should
     * not be considered (which instead are when HOLES_ACCESSED).
     * The problem here is that when the merge table is accessed, we must be
     * able to tell whether there is an hole at that place. It is true that
     * the merge table is not accessed at places that correspond to holes in
     * the origin rows, but it is at places that have become holes because
     * of pruning. Now, to tell that an element contains a hole, the check
     * table must be there, or it must stay so and must not get filled by some
     * other value of some other row. The result is not much different from
     * that of HOLES_ACCESSED; even more, it can be worse since the check
     * vector takes as much space as the merge one. My guess is that
     * fallbacking does not pay off here. This is disallowed then.
     *
     * Fallbacking is not influenced by column folding. Let's take a row t
     * and another f. Let be t' and f' the rows derived from t and s by
     * removing equal columns. If t can fallback on f, then t' can fallback
     * on f'. Fallbacking is actually done when the distance t - f is lower
     * than the threshold. Since t' - f', is lower than t - f, is is also
     * lower than the threshold.
     *
     * Fallbacking can be used also in incremental mode. It can be disabled
     * in an intermediate call, but if in a later one it is enabled again,
     * the fallTable is enlarged to reach the highest absolute row number.
     * However, fallback targets are not searched among the rows merged in
     * previous calls. It is likely to be of little use because there is
     * little chance that the rows in a call are similar to the ones in a
     * previous one.
     *
     * Pruning is done before column folding because it could reduce
     * considerably the number of entries, and thus make column folding
     * cheaper.
     *
     */

    private void buildFallback(int[] dense, int[] idense){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("prune start");
        }
        int hole = this.holeValue;
        boolean pairs = (PAIRS & this.mode) != 0;
        int num = 0;                                // determine density
        for (int i = 0; i < this.segms; i++){
            if (((FOLD_ROWS & this.mode) != 0) &&
                (this.share[i] >= 0)){
                continue;
            }
            int[] tab = this.bufs[i];
            if (tab == null) continue;
            int d = 0;
            if (pairs){
                if (tab.length > 1){
                    d = (tab.length - 1) >>> 1;     // nr of pairs
                }
            } else {
                int end = this.offs[i] + this.lengths[i+this.oldSegms];
                for (int j = this.offs[i]; j < end; j++){  // scan row
                    if (tab[j] != hole) d++;
                }
            }
            dense[num] = d;
            idense[num++] = i;
        }
        sort(dense,idense,0,num);                   // sort density, lower first
        if ((FL_A & this.trc) != 0){
            for (int i = 0; i < num; i++){
                Trc.out.println(i + ": " + idense[i] + " " + dense[i]);
            }
        }

        int[] entries = (int[])(dense.clone());     // remember density
        int[] freq = new int[this.segmSize];        // sort by highest purity
        for (int i = 0; i < num;){
            int d = dense[i];
            int start = i;                          // locate slot with
            for (i = i+1; i < num; i++){            // .. the same density
                int dd = dense[i];
                if (dd != d) break;
            }
            if ((FL_A & this.trc) != 0){
                Trc.out.println("slot: " + start + ".." + i + " : " + d);
            }
            for (int k = start; k < i; k++){        // visit slot
                int t = idense[k];
                int[] tab = this.bufs[t];
                int n = 0;
                if (pairs){
                    int end = tab.length;
                    for (int j = 1; j < end; j++){  // collect nonholes
                        freq[n++] = tab[++j];
                    }
                } else {
                    int end = this.offs[t] +
                        this.lengths[t+this.oldSegms];
                    for (int j = this.offs[t];      // collect nonholes
                        j < end; j++){
                        if (tab[j] != hole) freq[n++] = tab[j];
                    }
                }
                Arrays.sort(freq,0,n);              // sort it
                int high = 0;                       // repeated values are ..
                for (int j = 0; j < n; j++){        // .. adjacent now
                    int val = freq[j];
                    int w = j+1;
                    for (; w < n; w++){             // determine the highest number ..
                        if (freq[w] != val) break;  // .. of repeated values
                    }
                    w -= j;
                    if (w > high) high = w;
                }
                dense[k] = -high;                   // highest, descending
            }
            sort(dense,idense,start,i-start);       // sort slot
        }
        if ((FL_A & this.trc) != 0){
            Trc.out.println("purity:");
            for (int i = 0; i < num; i++){
                int n = idense[i];
                int f = -dense[i];
                Trc.out.println(i + ": row: " + n + ": " + f);
            }
        }
        int threshold = 0;
        int[] fallTable = enlarge(this.fallTable,   // create/extend and initialize
            this.segms,0);
        this.fallTable = fallTable;
        for (int i = this.oldSegms; i < fallTable.length; i++){
            fallTable[i] = i;                       // autofallback
        }
        int removed = 0;
        int defaulted = 0;
        for (int y = 0; y < num; y++){              // determine fallback rows
            int i = idense[y];
            int ai = i + this.oldSegms;
            int[] tab = this.bufs[i];
            if (tab == null) continue;
            int len = this.lengths[i+this.oldSegms];
            if (len == 0) continue;
            threshold = (entries[y] * 20) / 100;    // max difference allowed
            if (threshold < 4) threshold = 4;       // too little, increase it a bit
            int min = len;
            int closest = -1;
            int delta = 0;
            seek: for (int w = 0; w < y; w++){      // seek the closest one
                int j = idense[w];                  // row number
                int aj = j + this.oldSegms;
                if (fallTable[aj] != aj) continue;  // already a fallback
                delta = fall(i,j);                  // determine distance
                if (delta < 0) continue;            // no overlap
                if (delta == entries[y]) continue;  // totally different
                if (delta < min){                   // a closer one found
                    min = delta;
                    closest = j;
                }
            }
            if ((FL_A & this.trc) != 0){
                Trc.out.println("row: " + i +
                    " closest: " + closest + " delta: " + min +
                    " threshold: " + threshold + " entries: " + entries[y]);
            }
            if ((closest >= 0) && (min <= threshold)){    // fallback
                int[] el = this.bufs[closest];
                fallTable[ai] = closest + this.oldSegms;
                defaulted++;
                if ((FL_A & this.trc) != 0){
                    Trc.out.println(i + " fallback " +
                        closest + " diff " + min);
                    showTab(0,this.bufs[i],this.offs[i],
                        len,pairs);
                    showTab(0,this.bufs[closest],this.offs[closest],
                        this.lengths[closest+this.oldSegms],pairs);
                    int n = entries[y] - min;
                    removed += n;
                    Trc.out.println("removed: " + n);
                }
            }
        }

        if (this.share != null){
            for (int i = 0; i < this.segms; i++){         // complete the shared ones
                if (this.share[i] >= 0){
                    fallTable[i+this.oldSegms] =
                        fallTable[this.share[i]];
                }
            }
        }

        if ((FL_A & this.trc) != 0){
            Trc.out.println("fallback table");
            for (int i = 0; i < this.segms; i++){
                if (this.bufs[i] == null) continue;
                int ai = i + this.oldSegms;
                if (fallTable[ai] != ai){
                    Trc.out.println(ai + " fallback " +
                        fallTable[ai] + " rel: " + i + " " +
                        (fallTable[ai]-this.oldSegms));
                }
            }
            Trc.out.println("fallback partitions");
            int[] fback = (int[])fallTable.clone();   // print fallback ..
            for (int i = this.oldSegms;               // .. partitions
                i < fback.length; i++){
                boolean first = true;
                for (int j = this.oldSegms; j < fback.length; j++){
                    if (i == j) continue;
                    if (fback[j] == i){
                        if (first) Trc.out.print(i);
                        first = false;
                        Trc.out.print(" " + j);
                        fback[j] = 0;                 // no longer print it
                    }
                }
                if (!first) Trc.out.println();
            }
            Trc.out.println("origin rows");
            showTables();
            Trc.out.println("pruned rows");
            int nh = this.segmSize*2 + 1;
            int[] nonholes = new int[nh];
            for (int i = 0; i < this.segms; i++){
                getPairs(i,nonholes);
                showTab(0,nonholes,0,
                    this.lengths[i+this.oldSegms],true);
            }
        }
        if ((FL_A & this.trc) != 0){
            Trc.out.println("prune removed: " + removed +
                " defaulted: " +  defaulted);
        }
    }

    /**
     * Test whether a row can fall back onto another, and deliver the
     * number of elements that that would remain after pruning.
     *
     * @param      i number of the fallback row
     * @param      j number of the row to test
     * @return     < 0 if no fallback possible, otherwise the number of
     *             non-prunable elements
     */

    /* A row t can fallback on a row s if all its holes correspond
     * to existing holes in s. The number of prunable elements is that
     * of nonholes elements of t that are different from the corresponding
     * elements of s or are mapped to no elements of s.
     * Note that non-existing elements of t can fallback onto elements of s.
     * In the following cases, no fallback is done:
     *
     *    row      candidate
     *    null     any
     *    any      null
     *    any      identical
     *    empty    any
     *    any      empty
     *
     * They are cases in which fallback would not produce any gain.
     * An empty or null row does not fallback onto another empty one, and any
     * row does not fallback onto an empty one because fallback is done
     * only between rows which have at least one element equal.
     * When two rows are identical, one can fallsback into the other: the
     * pruned row becomes full of holes. 
     *
     * To test the conditions above in the case of pairs, the pairs are
     * examined in parallel until one or both ends. Then, the parallel scan
     * ends eith one of these cases:
     *
     *    - row ended, candidate ended: they can end together only when
     *      the last elements compared have the same indexes, otherwise only
     *      one of the pairs is advanced. We check then that the row has
     *      the same or less holes at the end:
     *
     *          row        xxxxx...
     *          candidate  yyyyy....
     *
     *    - row ended, candidate not: this can occur only when the
     *      indexes of the last two pairs compared are equal or that of the
     *      row is lower than that of the candidate. The length of the row
     *      must be lower or equal to that of the candidate (otherwise it has
     *      holes that correspond to nonexisting elements in candidate), and
     *      the last hole of the row must have an index that is lower than
     *      that of the first unexpended pair in the candidate:
     *
     *          row        xxxxx...
     *          candidate  yyyyyy..y....
     *
     *    - row not ended, candidate ended: this can occur only when the
     *      indexes of the last two pairs compared are equal. If the row
     *      has holes at the end, then its length must be equal or lower than
     *      that of the candidate. Moreover, starting at the first index in
     *      the row that corresponds to a nonexisting one in the candidate,
     *      all elements of the row must be nonholes.
     *
     *          row        xxxx.x...xxx
     *          candidate  yyyy.....
     */

    int fall(int i, int j){
        if (bufs == null) return -1;          // for completeness, check ..
        int hole = this.holeValue;            // .. also these (they occur in tests)
        int[] tab = this.bufs[i];
        if (tab == null) return -1;
        int[] el = this.bufs[j];
        if (el == null) return -1;
        if ((el == tab) &&                    // identical rows
            (this.offs[j] == this.offs[i])){  // it occurs in tests only
            return 0;
        }
        int len = this.lengths[i+this.oldSegms];
        if (len == 0) return -1;
        int lenj = this.lengths[j+this.oldSegms];
        if (lenj == 0) return -1;
        int delta = 0;
        cmp: if ((PAIRS & this.mode) != 0){
            int k = 1;
            int h = 1;
            int endk = tab.length;
            int endh = el.length;
            while ((k < endk) && (h < endh)){
                int ik = tab[k];              // index in row
                int ih = el[h];               // index in fallback
                if (ik == ih){                // found
                    int t = tab[++k];         // value
                    int e = el[++h];          // value
                    k++;
                    h++;
                    if (t != e) delta++;      // it must be kept
                } else if (ik < ih){          // hole in el
                    k += 2;
                    delta++;                  // keep it
                } else {                      // hole in tab, not in el
                    return -1;
                }
            }
            // at this point one of the lists of pairs has ended
            if ((k == endk) && (h == endh)){  // both ended
                if (lenj < len){              // candidate shorter
                    return -1;
                }
            } else if (k == endk){            // row ended
                if (lenj < len){              // candidate shorter
                    return -1;
                }
                if (len-1 >= el[h]){          // holes in tab corresponding
                    return -1;                // to nonholes in el
                }
            } else {                          // candidate ended
                int last = tab[tab.length-2];
                if (last != len-1){           // holes at end of tab
                    if (lenj < len){          // candidate shorter
                        return -1;
                    }
                }
                while (k < endk){             // find first in row that ..
                    int ix = tab[k++];        // .. does not overlap
                    k++;
                    delta++;
                    if (ix == lenj){          // found
                        int seq = ix + 1;
                        while (k < endk){     // check that the remaining ..
                            ix = tab[k++];    // .. are in sequence
                            k++;
                            if (ix != seq++){
                                return -1;    // leaves an unmappable hole
                            }
                            delta++;
                        }
                        break;                // found
                    } else if (ix > lenj){
                        return -1;            // leaves an unmappable hole
                    }
                }
            }
        } else {
            int end = lenj;
            if (len < end) end = len;         // overlapping part
            end += this.offs[i];
            for (int k = this.offs[i], h = this.offs[j];
                k < end; k++, h++){
                int t = tab[k];               // check the overlapping part
                int e = el[h];
                if (t != e) delta++;
                if ((t == hole) && (e != hole)){
                    return -1;
                }
            }
            if (lenj > len) break cmp;        // candidate longer
            if (lenj < len){                  // exceeding part ..
                end = this.offs[i] + len;     // .. all nonholes
                for (int k = this.offs[i] + lenj;
                    k < end; k++){
                    if (tab[k] == hole) return -1;
                    delta++;
                }
            }
        }
        return delta;
    }
}
