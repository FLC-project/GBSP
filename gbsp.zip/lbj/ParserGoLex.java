/*
 * @(#)ParserGoLex.java       1.0 2000/01/29
 *
 * Copyright (c) 2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;
import lbj.IoStream;
import lbj.ParserLex;

/**
 * The <code>ParserGoLex</code> represents lexical analyzer for GO.
 *
 * @author  Angelo Borsotti
 * @version 1.0   12 Jun 2020
 */

class ParserGoLex extends ParserLex {

    public ParserGoLex(){
        super();
    }
    public ParserGoLex(ParserTables au){
        super(au);
    }

    private int tokDelimiter = -1;
    private int tokSemicolon;
    private int tokIdentifier;
    private int tokIntLit;
    private int tokFloatLit;
    private int tokImaginaryLit;
    private int tokRuneLit;
    private int tokStringLit;
    private int tokBreak;
    private int tokContinue;
    private int tokFallthrough;
    private int tokReturn;
    private int tokPP;
    private int tokMM;
    private int tokClp;
    private int tokCls;
    private int tokClb;
    private int tokColon;

    private int[] toksemiclist;

    private int[] fifo = new int[5];
    private String[] fifostr = new String[fifo.length];
    private int fifosp;

    private int semicset;

    /*
    The construct label: nl } is not correct since a statement is always followed by a ;,
    therefore in addition to the ones specified in the language reference, when a label is at
    the end of the line, a semicolon is added (to recognize the text; in a real parser this
    whole matter of semicolons must be treated properly)
    */

    public int lex(){
        int res = 0;
        if (this.tokDelimiter < 0){    // initialize
            // for (int i = 0; i < this.aut.tokStrings.length; i++){
            //     Trc.out.println(this.aut.tokStrings[i]);
            // }
            this.catMap = this.aut.catMap;
            this.catMap0 = this.aut.catMap0;
            this.transTable = this.aut.transTable;
            this.tabMerged = this.aut.tabMerged;
            this.stateAttrs = this.aut.stateAttrs;
            this.initialState = this.aut.initialState;

            this.tokDelimiter = this.aut.symNr("delimiter");
            this.tokSemicolon = this.aut.symNr('t',";");
            this.tokIdentifier = this.aut.symNr("identifier");
            this.tokIntLit = this.aut.symNr("int_lit");
            this.tokFloatLit = this.aut.symNr("float_lit");
            this.tokImaginaryLit = this.aut.symNr("imaginary_lit");
            this.tokRuneLit = this.aut.symNr("rune_lit");
            this.tokStringLit = this.aut.symNr("string_lit");
            this.tokBreak = this.aut.symNr('t',"break");
            this.tokContinue = this.aut.symNr('t',"continue");
            this.tokFallthrough = this.aut.symNr('t',"fallthrough");
            this.tokReturn = this.aut.symNr('t',"return");
            this.tokPP = this.aut.symNr('t',"++");
            this.tokMM = this.aut.symNr('t',"--");
            this.tokClp = this.aut.symNr('t',")");
            this.tokCls = this.aut.symNr('t',"]");
            this.tokClb = this.aut.symNr('t',"}");
            this.tokColon = this.aut.symNr('t',":");
            this.toksemiclist = new int[]{this.tokIdentifier,
                this.tokIntLit,this.tokFloatLit,this.tokImaginaryLit,
                this.tokRuneLit,this.tokStringLit,this.tokBreak,
                this.tokContinue,this.tokFallthrough,this.tokReturn,
                this.tokPP,this.tokMM,this.tokClp,this.tokCls,
                this.tokClb,this.tokColon};

            // find the set in which there is the semicolon (to return)
            for (int i = 0; i < this.aut.tokLists.length; i++){
                if (this.aut.tokLists[i] == null) continue;
                if (this.aut.tokLists[i][0] == this.tokSemicolon){
                    this.semicset = i;
                    break;
                }
            }
        }
        if ((FL_B & trc) != 0){Trc.out.printf("fifo at start: %s\n",fifoToString());}
        int set = 0;
        doit: {
            add: if (this.fifosp == 0){        // fifo empty, add
                if ((FL_B & trc) != 0){Trc.out.printf("fifo empty\n");}
                do {                           // skip delimiters, get next
                    set = getToken();
                    if (eof()){
                        break add;
                    }
                    if (set < 0){
                        break doit;
                    }
                    res = this.aut.tokLists[set][0];   // earliest preferred
                } while (res == this.tokDelimiter);
                this.fifo[this.fifosp] = set;          // add it
                this.fifostr[this.fifosp++] = this.laststr;
                if ((FL_B & trc) != 0){Trc.out.printf("fifo added %s\n",addedToString());}

                boolean found = false;
                for (int i = 0; i < toksemiclist.length; i ++){
                    if (res == this.toksemiclist[i]){
                        found = true;              // one that wants ;
                        break;
                    }
                }
                boolean newline = false;
                if (found){
                    if ((FL_B & trc) != 0){Trc.out.printf("got token that wants ;\n");}
                    for (;;){
                        set = getToken();
                        if (eof()){
                            newline = true;
                            break;
                        } else if (set >= 0){
                            res = this.aut.tokLists[set][0];   // earliest preferred
                            if (res == this.tokDelimiter){
                                String str = this.laststr;
                                if (str.indexOf('\r') >= 0 || str.indexOf('\n') >= 0){
                                    newline = true;
                                    break;
                                }
                            } else {
                                break;
                            }
                        } else {
                            break doit;
                        }
                    }
                    if (newline){
                        this.fifo[this.fifosp] = this.semicset;       // add ;
                        this.fifostr[this.fifosp++] = ";";
                        if ((FL_B & trc) != 0){Trc.out.printf("fifo nl ; added %s\n",addedToString());}
                        break add;
                    } else {
                        if (res == this.tokClp || res == this.tokClb){  // e.g. id closing
                            this.fifo[this.fifosp] = this.semicset;       // add ;
                            this.fifostr[this.fifosp++] = ";";
                            if ((FL_B & trc) != 0){Trc.out.printf("fifo clo ; added %s\n",addedToString());}
                        }
                        this.backup = true;
                        if ((FL_B & trc) != 0){Trc.out.printf("backup\n");}
                        break add;
                    }
                }
                // it is not one that can have an automatic ;
                if (res == tokSemicolon){
                    break add;
                }
                // it is not a ;
                // check if followed by a newline
                if ((FL_B & trc) != 0){Trc.out.printf("not ;\n");}

                // a ; can be omitted before a closing parenthesis, but this does not mean that it
                // must be added if not present because there are constructs in which it does not appear
                // To cope with this I changed the grammar adding an optional semicolon before
                // closing parentheses (it can never appear before a ]).
                newline = false;
                for (;;){
                    set = getToken();
                    if (eof()){
                        newline = true;
                        break;
                    } else if (set >= 0){
                        res = this.aut.tokLists[set][0];
                        if (res == this.tokDelimiter){
                            String str = this.laststr;
                            if (str.indexOf('\r') >= 0 || str.indexOf('\n') >= 0){
                                newline = true;
                                break;
                            }
                        } else {
                            break;
                        }
                    } else {
                        break doit;
                    }
                }
                if ((FL_B & trc) != 0){Trc.out.printf("newline %s\n",newline);}
                if (!newline){
                    res = this.aut.tokLists[set][0];
                    if (res == this.tokClp || res == this.tokClb){
                        this.fifo[this.fifosp] = this.semicset;   // add ;
                        this.fifostr[this.fifosp++] = ";";
                        if ((FL_B & trc) != 0){Trc.out.printf("fifo clo ; added %s\n",addedToString());}
                    }
                    this.backup = true;
                    if ((FL_B & trc) != 0){Trc.out.printf("fifo clo backup\n");}
                }
            } // add
        } // doit
        if ((FL_B & trc) != 0){Trc.out.printf("fifo after add: %s\n",fifoToString());}
        set = 0;
        if (this.fifosp > 0){         // dequeue
            set = this.fifo[0];
            this.retString = this.fifostr[0];
            for (int i = 0; i < this.fifosp-1; i++){  // shift
                this.fifo[i] = this.fifo[i+1];
                this.fifostr[i] = this.fifostr[i+1];
            }
            this.fifosp--;
        }
        if ((FL_B & trc) != 0){Trc.out.printf("fifo at return: %s\n",fifoToString());}
        if ((FL_A & trc) != 0){Trc.out.printf("golex return %s\n",addedToString(set));}
        return set;
    }

    private int lastset;
    private String laststr;
    private boolean backup;
    private int getToken(){
        if (this.backup){
            this.backup = false;
            if ((FL_B & trc) != 0){Trc.out.printf("getToken backup\n");}
            if (this.lastset >= 0){
                if ((FL_B & trc) != 0){Trc.out.printf("getToken back lexeme: %s |%s|\n",this.aut.tokSetToString(this.lastset),this.laststr);}
            }
            return this.lastset;
        }
        int set = super.lex();
        if (eof()){
            if ((FL_B & trc) != 0){Trc.out.printf("getToken --eof--\n");}
            set = -1;
        } else if (set == 0){
            if ((FL_B & trc) != 0){Trc.out.printf("getToken unrecognised lexeme\n");}
            set = -1;
        } else {
            if ((FL_B & trc) != 0){Trc.out.printf("getToken golex lexeme: %s |%s|\n",this.aut.tokSetToString(set),super.toString());}
        }
        this.lastset = set;
        this.laststr = super.toString();
        return set;
    }

    private String addedToString(){
        return this.aut.tokLitName(this.aut.tokLists[this.fifo[this.fifosp-1]][0]) +
            "|" + this.fifostr[this.fifosp-1] + "|";
    }
    private String addedToString(int set){
        if (set > 0){
            return this.aut.tokLitName(this.aut.tokLists[set][0]);
        }
        return "";
    }

    private String fifoToString(){
        String str = "";
        for (int i = 0; i < this.fifosp; i++){
            if (i > 0) str += " ";
            str += addedToString(fifo[i]);
            str += "|" + fifostr[i] + "|";
        }
        return str;
    }

    private String retString;
    public String toString(){
        return this.retString;
    }

    public static void main(String[] args){
        IoStream gra = new IoStream();           // init gram stream
        IoStream inp = new IoStream();           // init text stream
        try {
            gra.open(args[0],IoStream.CHARS);
            inp.open(args[1],"UTF8",IoStream.CHARS);
        } catch (Throwable exc){
            Trc.out.println("no file");
            return;
        }
        ParserBnf prs = new ParserBnf();
        if (!prs.analyse(gra)){                      // parse source grammar
            Trc.out.println("erroneous grammar");
        }
        gra.close();                                 // terminate input
        if ((prs.lex.fatcnt != 0) ||                 // errors or fatals
            (prs.lex.errcnt != 0)) return;
        ParserGoLex lex = new ParserGoLex(prs.getTables());
        lex.stream = new BufReader(inp,1024);

        if (args.length > 2){
            lex.settrc(args[2]);
        }
        doit: for (;;){
            if (lex.eof()) break;
            int set = lex.lex();
            if (lex.eof()){
                Trc.out.print("eof");
                break;
            }
            if (set <= 0){
                Trc.out.print("unknown lexeme");
                break;
            }
            Trc.out.printf("tokenizer lexeme: %s |%s| %s\n\n",
                prs.getTables().tokSetToString(set),
                lex.toString(),
                (int)lex.aut.tokLists[set][0]);
        }
        try {
            inp.close();
        } catch (Throwable exc){
            Trc.out.println("close error");
            return;
        }
    }
}
